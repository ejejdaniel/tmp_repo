# Linux 安裝與首次測試交接手冊

更新日期：2026-09-14。對象：第一次接觸本專案、只有程式壓縮包的接手人。

本手冊現已更新為「Docker 內產 PDF」版本，預設映像為 `py312-v3`。
**之前已交付的 9/11 壓縮包及 `ai-coscientist-linux-20260914-7f6a9f6.tar.gz`
還沒有這次程式改動，不能只重建映像就取得新功能。請取得包含本次修改的新程式包。**
新包檔名由交付者告知；下方 `ARCHIVE` 請使用你實際收到的檔名。
若暫時仍使用舊包，依該包內的歷史部署說明操作；其 PDF 仍需主機瀏覽器。

## 先看這一頁

你拿到的是「研究系統的程式與技能」，不是已安裝好的電腦環境。
只拿到這個壓縮包是可以開始部署的，不需要先取得來源電腦的 Docker 備份。
但壓縮包不是離線安裝大全：Python 套件、Linux 套件和 Docker 基底仍需取得。

本手冊的目標是：

1. 在 Linux 解開並安裝專案。
2. 在該 Linux 本機建立計算環境，不使用 `docker load`。
3. 設定可連線的 LLM 與私有資料中心。
4. 啟動 CLI，先確認能對話，再交付一個真正的計算或研究任務。
5. 找得到狀態、成果及錯誤紀錄，知道怎麼退出與接續。

**不能傳送 Docker 映像，與禁止使用 Docker，是兩件事。** 請先向管理員確認：

| 條件 | 若不符合 |
| --- | --- |
| 允許在 Linux 上執行 Docker 容器 | 停在安裝前。現版計算流程需要 Docker，不能靠少加一個參數取代。 |
| 能從核准的網路或內部鏡像取得 Python／Linux 套件及 Docker 基底 | 請管理員提供核准來源；不能只靠這個程式包完成全離線安裝。 |
| Linux 能連到 LLM API | 請管理員提供該 Linux 可達的網址、模型名稱及金鑰。 |
| 需要查內部文獻時，能連到私有資料中心 API | 請資料中心負責人提供介面及權限；沒有設定就不能查到該中心內容。 |

本手冊不教繞過安全政策。沒有 `sudo`、Docker 權限或網路權限時，把卡住的步驟交給管理員。

## 1. 認識三個位置

| 名稱 | 白話用途 | 安裝什麼 |
| --- | --- | --- |
| Linux 主機 | 跟使用者聊天、規劃研究、管理成果的地方 | Python 3.12、本專案、Docker |
| 主機上的 `.venv` | 專案自己的 Python 套件區，不影響其他專案 | `pyproject.toml` 列出的依賴 |
| Docker 計算與產檔環境 | 執行科研程式，另以臨時容器產 PDF | GPAW、RDKit 等科研套件，以及 Chromium、中文字型 |

Materializer 是負責實作與執行計算的技能。Route 是可重用的具體計算工具；
部分舊 Route 另外鎖定了自己的環境，限制見第 14 節。

**把套件安裝進主機 `.venv`，不等於 Docker 裡也裝好了；反之亦然。**
本手冊讓主機跑研究系統、Docker 跑科研程式，不要求把整套 CLI 放進容器。

### 指令怎麼看

- 以下 `bash` 區塊貼到 Linux 終端機，不是 Windows PowerShell。
- 一段做完、確認沒有錯誤，再貼下一段。不要一次執行整份文件。
- `$HOME` 是你的家目錄；`$PWD` 是目前所在目錄。
- `sudo` 需要管理權限，輸入密碼時不顯示字元是正常的。
- 行尾的 `\` 表示指令還沒結束，後面不能再加空白。
- `you>` 出現後，輸入的是跟研究系統的對話，不是 shell 指令。
- `nano` 編輯器用 `Ctrl+O`、Enter 儲存，用 `Ctrl+X` 離開。

## 2. 確認 Linux 版本

```bash
cat /etc/os-release
uname -m
whoami
df -h "$HOME"
```

本手冊的安裝指令以 **Ubuntu 24.04、x86_64／amd64** 為主。後面的容器與計算會占用
數 GB 以上磁碟空間，實際用量隨套件快取與任務增加；先確認不是已滿的磁碟。

若是 Ubuntu 22.04、Debian、Rocky Linux 或 ARM，先請管理員準備 Python 3.12、
可用 Docker 及瀏覽器，不要直接照抄下面的 `apt` 套件安裝指令。
`whoami` 不應是 `root`；日常 CLI 與 PDF 渲染請使用一般使用者。

## 3. 解壓縮，記住專案位置

### 3.1 還沒有解壓縮

以下假設壓縮包在 `~/Downloads/`。檔案放在別處時，修改第一行的路徑：

```bash
ARCHIVE="$HOME/Downloads/請換成實際收到的新版本檔名.tar.gz"
ls -lh "$ARCHIVE"
tar -tzf "$ARCHIVE" | head -n 12
```

應看到檔案存在，內容開頭是 `ai-coscientist/`。不要把舊檔案改名成新版；
改名不會更新內部程式。

接著解到家目錄下的 `ai-research`。**如果目的位置已有 `ai-coscientist` 目錄，
先不要覆蓋；改用另一個空目錄，或直接走 3.2。**

```bash
mkdir -p "$HOME/ai-research"
tar -xzf "$ARCHIVE" -C "$HOME/ai-research"
cd "$HOME/ai-research/ai-coscientist"
export PROJECT_ROOT="$PWD"
```

### 3.2 已經解壓縮

不用重解。進入你原先解開的目錄，例如：

```bash
cd "$HOME/ai-research/ai-coscientist"
export PROJECT_ROOT="$PWD"
```

如果你解在 `/data/...`，將上面的 `cd` 換成那個位置。

### 3.3 核對版本與檔案

```bash
pwd
ls
cat RELEASE.txt
sha256sum -c SHA256SUMS
```

應看到 `src`、`skills`、`scripts`、`docker`、`pyproject.toml` 等；雜湊檢查應都是 `OK`。
SHA256SUMS 是每個檔案的校驗表，用來檢查解壓後的內容是否完整，不是額外要下載的檔案。

**先核對，再改 config。** 修改 config 之後，普通 `sha256sum -c` 會指出它已改變；
後面的專案部署檢查允許這一份 config 的本機設定變更，不允許偷偷改正式程式。

## 4. 安裝主機 Python 環境

若管理員已提供 Python 3.12，先執行 `python3.12 --version`，不必重裝 Python；
下面其他工具若尚未安裝，仍需由管理員補齊。
以下安裝段只適用前述 Ubuntu 24.04：

```bash
sudo apt update
sudo apt install -y python3.12 python3.12-venv ca-certificates curl nano tmux
```

不要替換作業系統預設 Python，也不要用 `sudo pip install`。

```bash
cd "$PROJECT_ROOT"
python3.12 --version
python3.12 -m venv .venv
source .venv/bin/activate
python --version
python -m pip install -e .
python -m pip check
```

應看到 Python 3.12.x，最後是 `No broken requirements found.`。
`.venv` 是新建的本機環境，不是從 Windows 搬來的環境。這是 Python 官方提供的
[虛擬環境用法](https://docs.python.org/3.12/tutorial/venv.html)。

管理員若提供 Conda 的 Python 3.12，也可以先啟用那個環境、再執行 `python -m pip install -e .`，
不必再建立第二層 `.venv`；後文所有 Python 指令都要使用同一個已啟用的環境。

若下載失敗、公司憑證不受信任或套件來源被擋，請管理員設定核准的套件鏡像與憑證。
不要加 `--trusted-host` 或停用 TLS 驗證來繞過政策。

## 5. 準備 Docker 權限

先檢查既有 Docker，**已經能使用就不要重裝**：

```bash
docker --version
docker info
```

`docker info` 正常列出 Client 與 Server 資訊，就可以到第 6 節。

若尚未安裝，而且管理員准許使用 Ubuntu 的套件版本，可請管理員執行：

```bash
sudo apt update
sudo apt install -y docker.io
sudo systemctl enable --now docker
```

這裡採 Ubuntu 提供的 `docker.io`，依據 [Ubuntu 官方安裝說明](https://ubuntu.com/server/docs/how-to/containers/docker-for-system-admins/)。
若主機已有 Docker CE、Podman 或其他容器環境，不要再混裝，交給管理員處理。

CLI 需要能在**不打 `sudo`** 的情況下呼叫 Docker。若公司採 Docker 群組授權，
請管理員核准後執行下面指令，接著你必須完整登出 SSH、重新登入：

```bash
sudo usermod -aG docker "$USER"
```

Docker 群組具有很高的主機權限，因此這一步須由管理員決定；不要用
`chmod 777 /var/run/docker.sock`。參見 [Docker 權限說明](https://docs.docker.com/engine/install/linux-postinstall/)。

重新登入後恢復位置與環境，再檢查：

```bash
cd "$HOME/ai-research/ai-coscientist"
export PROJECT_ROOT="$PWD"
source .venv/bin/activate
docker info
```

若仍是 `permission denied` 或 `Cannot connect to the Docker daemon`，停在這一步。
不要改成用 `sudo` 執行整套研究 CLI。

## 6. 在 Linux 本機建立科研計算環境

**這一步是 `docker build`，不是 `docker load`。不需要任何舊 Docker 映像檔。**

先看看環境是否已經建好：

```bash
docker image inspect ai-coscientist-native-science:py312-v3 --format '{{.Id}}'
```

若顯示 `No such image`，首次安裝時是正常的，執行下面建置。
若管理員已建好，請確認是用這個包的 Dockerfile 建置，再跳到 6.2。

### 6.1 建置

```bash
cd "$PROJECT_ROOT"
mkdir -p deploy-logs
set -o pipefail
docker build -t ai-coscientist-native-science:py312-v3 \
  -f docker/native-science-py312/Dockerfile \
  docker/native-science-py312 2>&1 | tee deploy-logs/docker-build.log
```

Dockerfile 會下載指定的 Python 基底，安裝編譯工具及科研套件；GPAW 可能需要編譯，
因此第一次可能較久。不要因為一段時間沒新輸出就立即重跑建置。

主機和 Docker 的下載連線可能受不同代理設定影響。Docker pull、容器內 `apt` 或 `pip`
任何一段被擋，都應拿 `deploy-logs/docker-build.log` 請管理員處理，不能以改 hash 解決。

這個 Dockerfile 已包含 GPAW、GPAW 資料、ASE、RDKit、NumPy、SciPy、Pandas；
**它沒有宣告 PySCF 或 Psi4 已安裝。** 不要因為主機有某套件，就假設計算環境也有。

建置完成後，後續產檔與科研計算共用這個映像，不需要匯入來源電腦的舊映像。

### 6.2 驗證套件與 GPAW 資料路徑

```bash
docker image inspect ai-coscientist-native-science:py312-v3 --format '{{.Id}}'
docker run --rm -i ai-coscientist-native-science:py312-v3 python - <<'PY'
import os
from pathlib import Path
import ase, gpaw, numpy, pandas, scipy
from rdkit import Chem
from rdkit.Chem import AllChem

setups = os.environ.get("GPAW_SETUP_PATH", "")
assert setups and Path(setups).is_dir(), "GPAW data path is unavailable"
assert any(Path(setups).iterdir()), "GPAW data directory is empty"
mol = Chem.AddHs(Chem.MolFromSmiles("O"))
assert AllChem.EmbedMolecule(mol, randomSeed=1) == 0
print("Scientific imports and RDKit geometry: OK")
print("GPAW_SETUP_PATH:", setups)
PY
```

應看到 `Scientific imports and RDKit geometry: OK`，資料路徑為 `/opt/gpaw-setups`。
這是環境檢查，不是正式科研成果，也還沒證明 DFT 能收斂。

**本機重建得到的 image ID 通常與來源電腦不同，這本身不是失敗。**
目前 CLI 預設會從本機 `ai-coscientist-native-science:py312-v3` 標籤取得真實 image ID。
不要照抄舊文件的 `sha256:71b5...` 或 `sha256:401f...` 當作自己已經有的映像。

## 7. 確認 Docker 內的 PDF 瀏覽器

**主機不需安裝 Chrome、Chromium 或中文字型，也不需設定 `CHROME_BIN`。**
第 6 節的新版映像已裝好瀏覽器與字型：

```bash
docker run --rm --network none ai-coscientist-native-science:py312-v3 chromium --version
docker run --rm --network none ai-coscientist-native-science:py312-v3 fc-match 'Noto Sans CJK TC'
```

應分別看到 Chromium 版本與 Noto CJK 字型。只有這兩項輸出仍不算 PDF 通過；
第 10 節會使用正式產檔入口，真的生成一份含繁體中文的 PDF。

產檔由程式自動操作：主機整理 HTML，臨時容器列印，PDF 回存主機，最後移除容器。
不需要啟動常駐瀏覽器服務、不用對外開 port，也不會每產一份 PDF 就重建映像。
CSS、SVG、原始文件頁面圖像均由現有產檔器放入 HTML；容器不會自動上網補素材，
也不掛載整個研究目錄。

瀏覽器用非 root 身分、保留沙箱執行。包內
`docker/native-science-py312/chromium-seccomp.json` 是它需要的 Linux 系統呼叫限制設定，
程式會自動使用。管理員須允許此設定及建立使用者命名空間；這是一種 Linux 隔離機制。
若公司禁止，交給管理員確認相容性，不使用 `--privileged`、`--no-sandbox`
或偷偷改回主機瀏覽器來掩蓋問題。設定來源與權限說明見同目錄的 `README.md`。

舊工具的明確 `--browser-executable` 指定仍保留，但只是手動相容入口；
正常 CLI 不要加它。正式 PDF 與心智圖、假說 PDF 都預設使用 Docker。

## 8. 設定 LLM，先測一個小請求

### 8.1 修改設定檔

```bash
cd "$PROJECT_ROOT"
nano config_deepseek_v4_flash.cfg
```

以包內設定為起點。若需要重新對照，必要內容如下：

```ini
[LLM]
provider = local
model_name = deepseek-ai/DeepSeek-V4-Flash-0731
api_base = http://192.168.1.118:8000/v1
api_key = no-key
temperature = 0.0
max_tokens = 12000
timeout = 1800
reasoning_effort = none
scientific_reasoning_effort = medium
repair_reasoning_effort = medium
planning_reasoning_effort = medium
```

請管理員確認 `api_base` 與 `model_name`。`192.168.1.118` 是來源環境使用的內網位址，
**遠端 Linux 不一定連得到**；`localhost` 則是這台 Linux 自己，不是你原本的 Windows。
不要把網址寫成 `/v1/chat/completions`，程式會自行接上端點路徑。

需要認證時，`api_key` 改成真實金鑰；只有伺服器明確不需要金鑰才留 `no-key`。
不要將真實金鑰貼進工單或對話。其餘思考設定先沿用，不以空字串代替 `none`。

### 8.2 發送小型連線測試

下段只傳「只回答 OK」，會真的呼叫一次 LLM，但不傳研究資料、不建立研究任務：

```bash
cd "$PROJECT_ROOT"
python - <<'PY'
import configparser
import requests

config = configparser.ConfigParser(interpolation=None)
config.read("config_deepseek_v4_flash.cfg", encoding="utf-8")
c = config["LLM"]
response = requests.post(
    c["api_base"].rstrip("/") + "/chat/completions",
    headers={"Authorization": "Bearer " + c["api_key"]},
    json={
        "model": c["model_name"],
        "messages": [{"role": "user", "content": "Reply only OK."}],
        "max_tokens": 64,
        "reasoning_effort": "none",
        "stream": False,
    },
    timeout=(10, 120),
)
print("HTTP:", response.status_code)
response.raise_for_status()
data = response.json()
print("Answer:", data["choices"][0]["message"].get("content"))
PY
```

應看到 HTTP 200 和模型回覆。這只證明基本 API 可用，不代表工具呼叫、研究或計算已通過。
若 401／403，檢查金鑰與服務權限；若 timeout／connection refused，找管理員確認網路及服務。
若 400，核對模型名稱及這個伺服器是否接受 `reasoning_effort`，不要直接啟動長任務反覆試。

## 9. 關閉 SearXNG，設定私有資料中心

在**稍後啟動 CLI 的同一個終端**執行：

```bash
export AI_COSCIENTIST_SEARXNG_URL=''
unset AI_COSCIENTIST_PRIVATE_KNOWLEDGE_MOCK
```

這會停用 SearXNG，不需另外部署它。不要把 MOCK 打開來假裝資料中心可用。

接著把下列示意網址換成管理員給的實際 API：

```bash
export AI_COSCIENTIST_PRIVATE_KNOWLEDGE_URL='https://your-knowledge-center/query'
```

如果 API 使用 Bearer token，以下用隱藏輸入讀取，不把金鑰直接寫進命令列歷史：

```bash
read -r -s -p 'Knowledge center token: ' AI_COSCIENTIST_PRIVATE_KNOWLEDGE_TOKEN
printf '\n'
export AI_COSCIENTIST_PRIVATE_KNOWLEDGE_TOKEN
```

不需認證時，改用 `unset AI_COSCIENTIST_PRIVATE_KNOWLEDGE_TOKEN`。
若此次只做不需查資料的計算，可先不設定 URL；但這不算私有資料中心已驗通。

### 現行資料中心介面不是任意格式都能接

程式用 HTTP POST 傳送：

```json
{
  "question": "要查的問題",
  "why": "為什麼要查",
  "resource_url": "",
  "permission_hint": ""
}
```

預期 JSON 回應外層是：

```json
{
  "markdown": "實際查得的非空內容",
  "metadata": {"url": "來源定位"}
}
```

以上只是介面說明，不是可拿來冒充查詢成果的測試資料。`metadata` 必須是物件，
其中的 `url` 是例子，不是唯一必要欄位。
若服務回 `data.answer`、串流或其他格式，光換網址不能解決；請負責人修改並測試
`src/ai_coscientist/domain/private_knowledge_center_adapter.py`，
回應整理在 `normalize_private_knowledge_response()`。
這會改變已發布程式，須按專案流程留存新版，不能再宣稱雜湊仍是原版。

可在管理員確認介面後，用以下無研究資料的問題檢查連線：

```bash
python - <<'PY'
import os
import requests

url = os.environ.get("AI_COSCIENTIST_PRIVATE_KNOWLEDGE_URL", "")
assert url and "your-knowledge-center" not in url, "Set the real API URL first"
headers = {"Content-Type": "application/json"}
token = os.environ.get("AI_COSCIENTIST_PRIVATE_KNOWLEDGE_TOKEN", "")
if token:
    headers["Authorization"] = "Bearer " + token
r = requests.post(url, headers=headers, json={
    "question": "請說明這個資料中心目前可查詢哪些資料範圍。",
    "why": "首次部署連線與回應格式檢查，不作為科研證據。",
    "resource_url": "", "permission_hint": ""
}, timeout=(10, 90))
print("HTTP:", r.status_code)
r.raise_for_status()
raw = r.json()
assert isinstance(raw, dict)
assert isinstance(raw.get("markdown"), str) and raw["markdown"].strip()
assert isinstance(raw.get("metadata"), dict)
print("Response format: OK")
print(raw["markdown"][:300])
PY
```

HTTP 200 加上 `Response format: OK` 表示這份回應符合基本格式，不保證每次查詢都有文獻。
終端輸出可能含內部資訊，交接紀錄應按公司規範遮蔽。

## 10. 執行專案部署檢查

```bash
cd "$PROJECT_ROOT"
python scripts/check_linux_deployment.py
```

應看到：檔案校驗、Python dependencies、CLI parser、Managed packages、Default scientific environment、
Production PDF renderer 均通過，最後是 `Deployment checks complete`。

注意：

- config 因設定本機 LLM 而改變，會顯示 locally changed，這是允許的。
- Managed packages 通過，只表示既有能力檔案與 hash 一致，**不代表所有舊 Route 的環境都存在**。
- 此檢查列出 Route 所需的映像身分，但不逐一執行那些 Route。
- `--skip-docker`、`--skip-pdf` 可用於診斷，略過不算通過。要求 PDF 的案例，不應略過 PDF 檢查就當環境完成。
- 此檢查不發 LLM 請求；它不會替代第 8、9 節的連線測試。

## 11. 首次進入 CLI：先驗對話

CLI 就是終端裡的聊天介面。第一次不必先傳題目檔，也不必指定歷史資料集。

```bash
cd "$PROJECT_ROOT"
mkdir -p inputs runs
export SOURCE_ROOT="$PROJECT_ROOT/inputs"
export RUN_DIR="$PROJECT_ROOT/runs/first-chat"
PYTHON_BIN="$(command -v python)" bash scripts/run_scientific_chat_linux.sh \
  --output "$RUN_DIR" \
  --source-root "$SOURCE_ROOT" \
  --config "$PROJECT_ROOT/config_deepseek_v4_flash.cfg" \
  --human-in-loop
```

`PYTHON_BIN` 會使用目前已啟用環境的 Python；先確認 `python --version` 是 3.12.x。
使用 Conda 也相同，不需指向不存在的 `.venv`。

應看到：

```text
AI Co-scientist Research Chat
模式：前置對話（尚未建立正式任務）
you>
```

在 `you>` 後依序輸入：

```text
/status
先不要展開研究，請只用繁體中文回答：對話連線正常。
/exit
```

第一行不呼叫 LLM；第二行會呼叫。收到回答、`/exit` 返回 shell 後，基本聊天測試完成。

三個參數的意思：

| 參數 | 意思 |
| --- | --- |
| `--output` | 這段對話與研究的保存位置；同一位置可嘗試接續，新位置才是新工作階段。 |
| `--source-root` | 交給系統查找題目與研究資料的目錄；不應隨便設成整台機器的根目錄。 |
| `--config` | LLM 設定檔。 |

`--human-in-loop` 表示研究可以停下問人。無人在場才改成 `--no-human-in-loop`；
關閉它不會補出缺失資訊，也不保證任務一定能完成。
這個一般 CLI 入口**不用** `--goal-relative-path`、`--historical-relative-path` 或 `--expected-record-count`。

## 12. 開始第一個真正的案例

### 12.1 開新的研究工作階段

離開前面的聊天後，在 shell 執行：

```bash
cd "$PROJECT_ROOT"
export RUN_DIR="$PROJECT_ROOT/runs/first-research-$(date +%Y%m%d-%H%M%S)"
printf 'Record this run directory: %s\n' "$RUN_DIR"
PYTHON_BIN="$(command -v python)" bash scripts/run_scientific_chat_linux.sh \
  --output "$RUN_DIR" \
  --source-root "$PROJECT_ROOT/inputs" \
  --config "$PROJECT_ROOT/config_deepseek_v4_flash.cfg" \
  --human-in-loop
```

**記下顯示的完整工作目錄。** 之後接續時不能再產生新時間戳。

### 12.2 沒有任何研究資料檔：可以先做小型計算案例

只有壓縮包、尚未取得 LIT 原始資料時，可以在 `you>` 貼以下完整一行。
這是一個新的部署試題，不是之前極化率或 LIT 測試的替代結果：

```text
請計算孤立 H2 分子的 DFT 單點總能量。請自行建立合理的初始幾何、選擇設定並交代近似，使用目前主機已建好的通用科研 Docker 環境中的 GPAW，撰寫並實際執行程式，不是只提供計算說明；本次不要求極化率、表面吸附或幾何最佳化。數值計算預算以 5 分鐘為目標，不包含 LLM 等待；若未完成請保存進度並如實說明。請以繁體中文回報實際算出的數值、單位、方法、輸入幾何及程式與執行證據位置，不能捏造結果。開始研究。
```

這裡的 5 分鐘是題目要求，**不是系統保證的整段任務硬性上限**。
模型選定的方法、主機速度與收斂情況仍會影響成敗。
手冊沒有提供答案、座標或修好的程式；由系統自行規劃與實作，不指定技能執行順序。

### 12.3 要跑 LIT 或自己的科研題目

壓縮包不包含之前的 LIT 原始資料、歷史樣本或研究成果。
要重現 LIT，請專案負責人另行提供**實際題目、結構說明及對應資料集**，
或確認私有資料中心能提供它們，不能拿手冊範例填補真正資料。

檔案若已在 Linux，例如管理員放在 `/data/lit-case`，離開 CLI 後，以新 `--output`
及 `--source-root /data/lit-case` 重新啟動。先在 shell 檢查檔案確實存在：

```bash
ls -lah /data/lit-case
```

若沒有這個目錄，先取得資料，不要照抄路徑。
確認資料已備齊後，用下列完整指令啟動；若管理員放在其他位置，修改 `SOURCE_ROOT`：

```bash
cd "$PROJECT_ROOT"
export SOURCE_ROOT="/data/lit-case"
export RUN_DIR="$PROJECT_ROOT/runs/lit-$(date +%Y%m%d-%H%M%S)"
printf 'Record this run directory: %s\n' "$RUN_DIR"
PYTHON_BIN="$(command -v python)" bash scripts/run_scientific_chat_linux.sh \
  --output "$RUN_DIR" \
  --source-root "$SOURCE_ROOT" \
  --config "$PROJECT_ROOT/config_deepseek_v4_flash.cfg" \
  --human-in-loop
```

於 `you>` 用自然語言委託，例如：

```text
請先查閱目前來源目錄的題目與資料，確認這次 LIT 研究要交付什麼，以及哪些資料能用來計算。先說明你的理解，有關鍵歧義請問我；確認後再展開研究。最後要有心智圖、假說、可解釋代理公式、實作與趨勢計分、樣本演化及附證據的 HTML/PDF 報告。演化最多 3 輪有效計分，新樣本優於最佳既有樣本可提前結束，否則如實報告名次。不要捏造未提供的結構或量測。
```

若研究資訊只在私有資料中心，可明確委託先查該中心並確認資料可取得；
對方必須真的回傳內容，設定了 URL 不等於任務資料已經匯入。

### 12.4 怎樣才算有跑起來，怎樣才算完成

看到 `[llm:start]` 表示送出模型請求，`[llm:finish]` 表示一次模型呼叫結束，
不表示整個任務完成。正式定題後，會出現任務狀態與成果紀錄。

對小型計算，至少檢查：有實際數值及單位、方法／近似說明、可追溯的程式及執行紀錄。
對科研報告，還要核對題目要求的各項交付及最終回覆。
「程式寫完」、「某個 skill complete」、「PDF 存在」都不單獨代表整題完成。

本版本仍有已知框架及模型問題；操作步驟已對照程式，
**實際部署與科研案例是否成功，仍要以目的主機上的執行結果為準**。

## 13. 看進度、找成果、退出及接續

### 13.1 當 CLI 回到 `you>` 時

```text
/status
/details
/graph
/artifacts
```

分別查看狀態、驗收細節、目前工作圖與正式成果索引。
系統若正忙，這些指令不會立即被處理；不要反覆輸入或把文字混進等待中的人類回答。

### 13.2 系統執行中，用第二個 SSH 視窗查看檔案

把第一行換成第 12 節記下的真實工作目錄：

```bash
RUN_DIR="$HOME/ai-research/ai-coscientist/runs/first-research-實際時間戳"
ls -lh "$RUN_DIR"
find "$RUN_DIR" -maxdepth 2 -type f -name 'agent-state.json'
tail -n 5 "$RUN_DIR/events.jsonl"
find "$RUN_DIR" -type f \( -name '*.html' -o -name '*.pdf' \)
```

正式任務尚未啟動時，`agent-state.json` 或 `events.jsonl` 可能還不存在。
正式研究、frame 或 child 也可能保存於工作目錄下的子目錄；可依 `/details`、
`/artifacts` 或系統實際回報路徑定位，不用手動改檔。

一行事件可能很長，所以先只看尾端少量紀錄。
`llm-reasoning-debug.jsonl` 含除錯用模型內容，不是正式科學證據；不要整份公開貼出。

若有報告，系統回覆的 HTML/PDF 路徑是這台 Linux 的檔案，不會自動出現在你自己的電腦。
有圖形桌面可開 HTML/PDF；只有 SSH 時，按公司核准方式取回檔案。

### 13.3 正常離開

回到 `you>` 時輸入 `/exit`。若必須在研究執行中中斷，按一次 `Ctrl+C`，
等系統回報已中斷再處理；不要一開始就 `kill -9` 或刪除工作目錄。
中斷時仍可能有外部計算需確認狀態，不能假設所有 subprocess 都已自動結束。

### 13.4 重新接續

重新 SSH 後，回到同一個專案，重新啟用 Python、設定第 9 節的環境變數。
下面 `RUN_DIR` 要改成之前記下的目錄，`SOURCE_ROOT` 要與該次研究相同：

```bash
cd "$HOME/ai-research/ai-coscientist"
export PROJECT_ROOT="$PWD"
source .venv/bin/activate
export AI_COSCIENTIST_SEARXNG_URL=''
export SOURCE_ROOT="$PROJECT_ROOT/inputs"
export RUN_DIR="$PROJECT_ROOT/runs/first-research-實際時間戳"
PYTHON_BIN="$(command -v python)" bash scripts/run_scientific_chat_linux.sh \
  --output "$RUN_DIR" \
  --source-root "$SOURCE_ROOT" \
  --config "$PROJECT_ROOT/config_deepseek_v4_flash.cfg" \
  --human-in-loop
```

同一個輸出目錄會載入原狀態，必要時嘗試接續未完成回合；不保證任意失敗都能恢復。
不要同時啟動兩個程序操作同一個工作目錄，也不要在接續前重建／覆蓋它原本使用的計算映像。

長任務建議使用 `tmux`，避免 SSH 網路中斷直接帶走終端工作：

```bash
tmux new -s cosci
```

進入新畫面後，再執行本節的環境設定與 CLI 啟動。暫時離開用 `Ctrl+B`，放開後按 `D`；
下次登入用 `tmux attach -t cosci` 回到原畫面，**不是再啟動第二份 CLI**。
tmux 只保留終端工作，不會替科研系統修復錯誤。

## 14. 舊 Route 為什麼可能還不能用

**通用計算環境可用，不等於包內所有歷史 Route 都已還原。**

包內受管理能力位於 `managed_capabilities/`。其中部分 Route 的 `runtime.lock.json`
鎖定來源機器的精確映像身分；你新建的映像即使有相同套件，也不是同一份身分。

因此：

- 不要隨意改 `runtime.lock.json`、package hash 或人類核准紀錄。
- 不要把新映像掛成舊 tag 就宣稱舊身分已恢復。
- 不要從舊文件照抄 `--capability-docker-additional-runtime sha256:...`，除非本機確實有那個映像。
- 第一個直接程式計算案例使用新建通用環境；若系統改選鎖定舊環境的 Route 而失敗，
  保存精確缺口，交給維護者安排相應能力的環境移植或新版驗證，不把它當作原能力已通過。

可查看有哪些鎖定檔：

```bash
cd "$PROJECT_ROOT"
find managed_capabilities/routes -name runtime.lock.json -print
```

其中以公開 registry digest 鎖定的基底，可能可由核准鏡像源取得；本機 image ID 鎖定的
自製映像則不能假設網路上存在。本手冊不以修改鎖定檔冒充原精確版本。
這不妨礙先安裝系統及建立通用環境，但會影響依賴那些舊 Route 的任務。

## 15. 常見卡點：先看這張表

| 畫面或現象 | 先做什麼 |
| --- | --- |
| `python3.12: command not found` | 請管理員提供 Python 3.12；不要改系統 Python 連結。 |
| `No module named ai_coscientist` | 確認已啟用正確環境，在有 pyproject.toml 的目錄做 `python -m pip install -e .`，並使用本手冊的 chat 腳本。 |
| Docker `permission denied` | 回第 5 節；主機 CLI 必須能以一般使用者呼叫 Docker。 |
| Docker `No such image` | 本機尚未建好第 6 節的標籤，或指定了不存在的舊映像身分。 |
| 建置卡在 `apt`／`pip`／pull | 留下 docker-build.log，請管理員檢查網路、公司憑證、鏡像及 Docker 的代理設定。 |
| `GPAW_SETUP_PATH`、PAW datasets 找不到 | 跑第 6.2 節，確認是本包 Dockerfile 建出的環境；不是在主機補一個環境變數就結束。 |
| `llm_config_keys_missing` | 核對第 8 節的必要欄位，尤其 max_tokens、timeout、api_key。 |
| LLM HTTP 401／403／400 | 檢查服務授權、模型名稱與 API 格式，不要用長研究任務試錯。 |
| `private_knowledge_unavailable` | 私有 API 未設定，或變數不是設在啟動 CLI 的那個終端。 |
| `private_knowledge_failed` | 依回條分辨 HTTP／JSON／回應格式失敗；交給 API／adapter 維護者。 |
| `scientific_report_pdf_browser_not_found` | 檢查是否誤加手動 `--browser-executable`；正常新流程不找主機瀏覽器。 |
| PDF 啟動失敗或缺中文字 | 先驗第 7、10 節，核對 v3 映像、seccomp 檔與主機命名空間政策；不需要安裝主機 Snap 瀏覽器。 |
| CLI 問問題後停住 | 可能是在等待人類回答；回到 `you>` 後直接回答。 |
| 長時間只有 `[llm:start]` | 先查看 LLM 後台及檔案更新；不要立即認定卡死，也不要連開第二份同目錄任務。 |
| 報告有了但尚未結案 | 檢查題目要求與 `/details`；產檔、Final LCA 及整體完成不是同一件事。 |

## 16. 出錯時交給維護者哪些東西

請保留原工作目錄，先不要重跑到蓋掉最早失敗。

1. 執行的完整 CLI 指令，以及你在 `you>` 輸入的任務。
2. `RELEASE.txt`、Linux 版本、CPU 架構、Python 版本與使用的 image ID。
3. 卡在哪一節、實際錯誤文字、發生時間。
4. `deploy-logs/docker-build.log` 或該次工作目錄內的狀態與事件紀錄。
5. 若是科學內容有問題，指出哪個正式成果、哪個數值或引用不對。

**先移除金鑰、token 及不得外傳的研究資料。** 不必把龐大的全部除錯內容貼進聊天。

## 17. 完成核對表

- [ ] 解壓後檔案校驗通過，知道是哪個 Git commit 的包。
- [ ] 正確 Python 環境已啟用，`pip check` 通過。
- [ ] 一般使用者可操作 Docker；通用科研映像已在 Linux 本機建立。
- [ ] 科研套件與 GPAW 資料路徑檢查通過。
- [ ] LLM 小請求成功。
- [ ] SearXNG 已停用；需要私有資料中心的任務已確認其連線與格式。
- [ ] 正式部署檢查通過；若要求 PDF，PDF 檢查不可略過。
- [ ] CLI `/status` 與簡單對話可用。
- [ ] 已開新工作階段交付一個實際案例，保留其輸出目錄。
- [ ] 已區分「成功啟動案例」與「題目要求全部完成」，沒有把前者回報成後者。

## 維護者備註

本手冊以 7f6a9f6 為基礎，依其後本次 Docker PDF 修改更新，對照實際 CLI、Dockerfile、
LLM 設定、私有資料中心 adapter 及 PDF renderer 撰寫。僅使用已收到的包即可依序操作，不要求傳輸舊 Docker 映像。
包內較早的部署文件若主張先 `docker load`，那是「能搬移映像」的另一條路，
不是本手冊這種受限傳輸情境的必要步驟。

來源機器已做過 Linux 容器中的解壓、套件安裝及空白 CLI 檢查；沒有登入你的目的主機
實際完成本手冊的安裝，也沒有因此證明第一個科研案例必定成功。
新手冊另存於 `docs/`，列入後續打包清單；已交付的舊壓縮包不會因本機補文件而自動改變。
