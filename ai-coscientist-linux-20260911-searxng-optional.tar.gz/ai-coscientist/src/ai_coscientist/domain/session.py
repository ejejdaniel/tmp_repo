from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

from ai_coscientist.common.capabilities import CapabilityRegistry
from ai_coscientist.common.memory_lifecycle.dialogue_memory import DialogueMemory
from ai_coscientist.common.memory_lifecycle.events import EventLog
from ai_coscientist.common.model import ChatModel
from ai_coscientist.common.runtime import CommonAgent

from .dialogue_task_bootstrap import (
    DialogueTaskLaunch,
    PreformulatedTask,
    formulate_dialogue_task_before_c0,
)
from .source_authority import SourceSpec
from .workflow import (
    COORDINATOR_INSTRUCTIONS,
    SCIENTIFIC_TASK_FORMULATION_SKILL_ID,
    ScientificWorkflow,
    scientific_skill_catalog,
)


SCIENTIFIC_EVALUATION_REQUEST = (
    "Evaluate completion from the explicit requirements in the authoritative "
    "objective and accepted stored artifacts. Do not add a criterion that "
    "requires stored evidence of this evaluator's own current verdict."
)


@dataclass(frozen=True)
class ScientificSession:
    workflow: ScientificWorkflow
    agent: CommonAgent
    objective: str
    evaluation_summary: str = SCIENTIFIC_EVALUATION_REQUEST


def create_scientific_session(
    *,
    run_root: Path,
    source_spec: SourceSpec | None,
    source_root: Path | None = None,
    model: ChatModel,
    project_root: Path,
    capability_registry: CapabilityRegistry,
    max_rounds: int,
    human_in_loop_enabled: bool,
    python_executable: str | None = None,
    materializer_timeout_seconds: float = 60.0,
    objective_override: str | None = None,
    task_authority_mode: str = "configured_source",
    dialogue_launch: DialogueTaskLaunch | None = None,
    dialogue_memory: DialogueMemory | None = None,
) -> ScientificSession:
    """Build one authoritative scientific runtime for batch or chat hosts."""
    normalized_authority_mode = str(task_authority_mode).strip()
    if normalized_authority_mode not in {
        "configured_source",
        "dialogue_launch",
    }:
        raise ValueError(
            "scientific_session_task_authority_mode_invalid:"
            f"{normalized_authority_mode}"
        )
    normalized_override = (
        str(objective_override).strip()
        if objective_override is not None
        else ""
    )
    if normalized_authority_mode == "configured_source" and source_spec is None:
        raise ValueError("configured_source_spec_required")
    resolved_source_root = (
        source_spec.source_root.resolve()
        if source_spec is not None
        else (source_root.resolve() if source_root is not None else None)
    )
    if resolved_source_root is None:
        raise ValueError("dialogue_launch_source_root_required")
    resolved_run_root = run_root.resolve()
    resolved_project_root = project_root.resolve()
    executable = str(python_executable or sys.executable)
    workflow = ScientificWorkflow.create(
        run_root=resolved_run_root,
        source_spec=source_spec,
        source_root=resolved_source_root,
        run_id=resolved_run_root.name,
        python_executable=executable,
        capability_registry=capability_registry,
        materializer_timeout_seconds=float(materializer_timeout_seconds),
    )
    skills = scientific_skill_catalog(
        resolved_project_root / "skills",
        capability_registry=capability_registry,
    )
    preformulated: PreformulatedTask | None = None
    state_exists = (resolved_run_root / "agent-state.json").is_file()
    if normalized_authority_mode == "dialogue_launch":
        if state_exists:
            if not normalized_override:
                raise ValueError("dialogue_launch_objective_override_required")
            objective = normalized_override
        else:
            if dialogue_launch is None or dialogue_memory is None:
                raise ValueError("dialogue_launch_handoff_required_before_c0")
            preformulated = formulate_dialogue_task_before_c0(
                launch=dialogue_launch,
                dialogue=dialogue_memory.dialogue,
                artifacts=workflow.artifacts,
                observations=workflow.observations,
                routes=workflow.routes,
                skills=skills,
                model=model,
                events=EventLog(resolved_run_root / "events.jsonl"),
                skill_id=SCIENTIFIC_TASK_FORMULATION_SKILL_ID,
                evaluation_summary=SCIENTIFIC_EVALUATION_REQUEST,
            )
            objective = preformulated.objective
    else:
        if workflow.source_authority is None:
            raise RuntimeError("configured_source_authority_missing")
        objective = workflow.source_authority.goal()
    agent = CommonAgent(
        agent_id="scientific-coordinator",
        model=model,
        skills=skills,
        artifacts=workflow.artifacts,
        observations=workflow.observations,
        code_artifacts=workflow.code_artifacts,
        development_projects=workflow.development_projects,
        routes=workflow.routes,
        closure_evaluator=lambda _: workflow.closure.validate(),
        event_log_path=resolved_run_root / "events.jsonl",
        state_path=resolved_run_root / "agent-state.json",
        role_instructions=COORDINATOR_INSTRUCTIONS,
        max_rounds=max_rounds,
        human_in_loop_enabled=human_in_loop_enabled,
        project_workspace_root=resolved_project_root,
        workspace_excluded_relative_paths=project_workspace_exclusions(
            project_root=resolved_project_root,
            source_spec=source_spec,
        ),
        task_formulation_skill_id=SCIENTIFIC_TASK_FORMULATION_SKILL_ID,
        task_authority_mode=normalized_authority_mode,
        dialogue_memory=dialogue_memory,
        preformulated_task_spec_ref=(
            preformulated.task_spec_ref if preformulated is not None else ""
        ),
        preformulated_task_input_refs=(
            preformulated.input_refs if preformulated is not None else ()
        ),
    )
    return ScientificSession(
        workflow=workflow,
        agent=agent,
        objective=objective,
    )


def project_workspace_exclusions(
    *,
    project_root: Path,
    source_spec: SourceSpec | None,
) -> tuple[str, ...]:
    """Hide exact evaluator-authority source files from workspace exploration."""
    if source_spec is None:
        return ()
    root = project_root.resolve()
    held_out_source = (
        source_spec.source_root.resolve()
        / source_spec.historical_relative_path
    ).resolve()
    if not held_out_source.is_relative_to(root):
        return ()
    return (held_out_source.relative_to(root).as_posix(),)
