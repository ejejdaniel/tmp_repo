from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

import requests

from ai_coscientist.common.routes import Route


class PrivateKnowledgeCenterError(RuntimeError):
    pass


DocumentSink = Callable[..., dict[str, Any]]


def normalize_private_knowledge_response(raw: Any) -> dict[str, Any]:
    """Normalize the current markdown-plus-metadata API response contract."""
    if not isinstance(raw, Mapping):
        raise PrivateKnowledgeCenterError(
            "private_knowledge_response_must_be_object"
        )
    markdown = raw.get("markdown")
    metadata = raw.get("metadata")
    if not isinstance(markdown, str) or not markdown.strip():
        raise PrivateKnowledgeCenterError(
            "private_knowledge_response_markdown_required"
        )
    if not isinstance(metadata, Mapping):
        raise PrivateKnowledgeCenterError(
            "private_knowledge_response_metadata_required"
        )
    return {
        "markdown": markdown.strip(),
        "metadata": json.loads(
            json.dumps(dict(metadata), ensure_ascii=False, default=str)
        ),
    }


class PrivateKnowledgeCenterAdapter:
    """Isolate the replaceable private API call and response normalization."""

    def __init__(
        self,
        *,
        endpoint_url: str | None,
        mock_response_path: Path | None,
        document_sink: DocumentSink,
        audit_path: Path,
        session: Any | None = None,
    ) -> None:
        self._endpoint_url = str(endpoint_url or "").strip()
        self._mock_response_path = (
            mock_response_path.resolve() if mock_response_path else None
        )
        self._document_sink = document_sink
        self._audit_path = audit_path.resolve()
        self._session = session or requests.Session()

    def route(self, *, skill_ids: Sequence[str]) -> Route:
        return Route(
            name="literature_private_search",
            description=(
                "Ask the configured private knowledge center one natural-language "
                "question. The current adapter accepts a real HTTP endpoint or one "
                "explicit mock response file; absent configuration returns an "
                "unavailable result and never invents demo content."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "question": {"type": "string", "minLength": 3},
                    "why": {"type": "string", "minLength": 3},
                    "resource_url": {"type": "string"},
                    "permission_hint": {"type": "string"},
                },
                "required": ["question", "why"],
                "additionalProperties": False,
            },
            handler=self.query,
            skill_ids=tuple(str(value) for value in skill_ids),
            validator=_validate_private_query,
        )

    def query(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        _validate_private_query(arguments)
        request_payload = {
            "question": str(arguments["question"]).strip(),
            "why": str(arguments["why"]).strip(),
            "resource_url": str(arguments.get("resource_url") or "").strip(),
            "permission_hint": str(
                arguments.get("permission_hint") or ""
            ).strip(),
        }
        if self._mock_response_path is not None:
            if not self._mock_response_path.is_file():
                return {
                    "status": "private_knowledge_unavailable",
                    "reason": (
                        "configured mock response file does not exist:"
                        f"{self._mock_response_path}"
                    ),
                }
            raw = json.loads(
                self._mock_response_path.read_text(encoding="utf-8")
            )
            transport = "explicit_mock_file"
        elif self._endpoint_url:
            headers = {"Content-Type": "application/json"}
            token = str(
                os.environ.get("AI_COSCIENTIST_PRIVATE_KNOWLEDGE_TOKEN") or ""
            ).strip()
            if token:
                headers["Authorization"] = f"Bearer {token}"
            try:
                response = self._session.post(
                    self._endpoint_url,
                    json=request_payload,
                    headers=headers,
                    timeout=(10, 90),
                )
                response.raise_for_status()
                raw = response.json()
            except Exception as exc:
                self._append_audit(
                    {
                        "operation": "private_knowledge_query",
                        "request": request_payload,
                        "endpoint_url": self._endpoint_url,
                        "status": "failed",
                        "reason": f"{type(exc).__name__}: {exc}",
                    }
                )
                return {
                    "status": "private_knowledge_failed",
                    "reason": f"{type(exc).__name__}: {exc}",
                }
            transport = "http_api"
        else:
            return {
                "status": "private_knowledge_unavailable",
                "reason": (
                    "no private endpoint or explicit mock response file configured"
                ),
            }

        try:
            normalized = normalize_private_knowledge_response(raw)
        except Exception as exc:
            self._append_audit(
                {
                    "operation": "private_knowledge_query",
                    "request": request_payload,
                    "transport": transport,
                    "status": "normalization_failed",
                    "raw_response": raw,
                    "reason": f"{type(exc).__name__}: {exc}",
                }
            )
            return {
                "status": "private_knowledge_failed",
                "reason": f"{type(exc).__name__}: {exc}",
            }

        metadata = dict(normalized["metadata"])
        source_url = str(
            metadata.get("url")
            or metadata.get("source_url")
            or request_payload["resource_url"]
            or self._endpoint_url
            or self._mock_response_path
            or "private-knowledge://mock"
        )
        record = self._document_sink(
            source_url=source_url,
            raw_content=json.dumps(raw, ensure_ascii=False, default=str).encode(
                "utf-8"
            ),
            normalized_text=str(normalized["markdown"]),
            media_type="text/markdown",
            source_kind="private_knowledge",
            evidence_scope="full_text",
            metadata=metadata,
        )
        self._append_audit(
            {
                "operation": "private_knowledge_query",
                "request": request_payload,
                "transport": transport,
                "status": "ready",
                "document_ref": record["document_ref"],
                "raw_response": raw,
            }
        )
        return {
            "status": "private_knowledge_ready",
            "transport": transport,
            **record,
        }

    def _append_audit(self, value: Mapping[str, Any]) -> None:
        self._audit_path.parent.mkdir(parents=True, exist_ok=True)
        with self._audit_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(value, ensure_ascii=False, default=str) + "\n")


def _validate_private_query(arguments: Mapping[str, Any]) -> None:
    if len(str(arguments.get("question") or "").strip()) < 3:
        raise PrivateKnowledgeCenterError("private_knowledge_question_required")
    if len(str(arguments.get("why") or "").strip()) < 3:
        raise PrivateKnowledgeCenterError("private_knowledge_reason_required")
