from __future__ import annotations

import copy
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ai_coscientist.common.routes import Route


class SourceAuthorityError(RuntimeError):
    pass


@dataclass(frozen=True)
class SourceSpec:
    source_root: Path
    goal_relative_path: str
    historical_relative_path: str
    goal_sha256: str
    historical_sha256: str
    expected_record_count: int


@dataclass
class SourceAuthority:
    spec: SourceSpec

    def manifest(self) -> dict[str, Any]:
        goal_path, goal_digest = self._verified_path(
            self.spec.goal_relative_path, self.spec.goal_sha256
        )
        historical_path, historical_digest = self._verified_path(
            self.spec.historical_relative_path,
            self.spec.historical_sha256,
        )
        data = self._historical_from_path(historical_path)
        return {
            "source_root": str(self.spec.source_root.resolve()),
            "goal": {
                "relative_path": self.spec.goal_relative_path.replace("\\", "/"),
                "sha256": goal_digest,
            },
            "historical_data": {
                "relative_path": self.spec.historical_relative_path.replace(
                    "\\", "/"
                ),
                "sha256": historical_digest,
                "record_count": len(data["records"]),
            },
        }

    def goal(self) -> str:
        path, _ = self._verified_path(
            self.spec.goal_relative_path, self.spec.goal_sha256
        )
        value = path.read_text(encoding="utf-8")
        if not value.strip():
            raise SourceAuthorityError("source_goal_empty")
        return value

    def visible_historical(self) -> dict[str, Any]:
        visible = copy.deepcopy(self._private_historical())
        for field in (
            "avg_score",
            "score_MoO3",
            "score_WO3",
            "substrate_scores",
            "substrate_kpis",
        ):
            visible.pop(field, None)
        for record in visible["records"]:
            record.pop("ground_truth_kpi", None)
            record.pop("ground_truth_description", None)
            metadata = record.get("metadata")
            if isinstance(metadata, dict):
                for field in (
                    "avg_score",
                    "score_MoO3",
                    "score_WO3",
                    "substrate_scores",
                ):
                    metadata.pop(field, None)
        return visible

    def private_historical_for_evaluator(self) -> dict[str, Any]:
        """Internal only. Never register this method as a planner-visible route."""
        return copy.deepcopy(self._private_historical())

    def routes(self) -> tuple[Route, ...]:
        return (
            Route(
                name="scientific_source_manifest",
                description=(
                    "Return pinned real-input identity and row count without "
                    "held-out KPI values."
                ),
                parameters={
                    "type": "object",
                    "properties": {},
                    "additionalProperties": False,
                },
                handler=lambda _: self.manifest(),
            ),
            Route(
                name="scientific_source_goal",
                description="Read the authoritative scientific goal text.",
                parameters={
                    "type": "object",
                    "properties": {},
                    "additionalProperties": False,
                },
                handler=lambda _: {"goal": self.goal()},
                skill_ids=("problem-formulation",),
            ),
            Route(
                name="scientific_source_visible_historical",
                description=(
                    "Read sanitized historical records with held-out KPI "
                    "fields mechanically removed."
                ),
                parameters={
                    "type": "object",
                    "properties": {},
                    "additionalProperties": False,
                },
                handler=lambda _: self.visible_historical(),
                skill_ids=(
                    "mindmap-builder",
                    "final-kpi-proxy-discovery",
                    "auxiliary-proxy",
                    "sample",
                ),
            ),
        )

    def _private_historical(self) -> dict[str, Any]:
        path, _ = self._verified_path(
            self.spec.historical_relative_path,
            self.spec.historical_sha256,
        )
        return self._historical_from_path(path)

    def _historical_from_path(self, path: Path) -> dict[str, Any]:
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise SourceAuthorityError(f"source_data_invalid_json:{exc}") from exc
        if not isinstance(value, dict) or not isinstance(value.get("records"), list):
            raise SourceAuthorityError("source_data_requires_records_array")
        records = value["records"]
        if len(records) != self.spec.expected_record_count:
            raise SourceAuthorityError(
                "source_record_count_mismatch:"
                f"expected={self.spec.expected_record_count}:actual={len(records)}"
            )
        ids: set[str] = set()
        for index, record in enumerate(records):
            if not isinstance(record, dict):
                raise SourceAuthorityError(f"source_record_invalid:{index}")
            record_id = str(record.get("id", "")).strip()
            if not record_id or record_id in ids:
                raise SourceAuthorityError(
                    f"source_record_id_invalid:{index}:{record_id}"
                )
            ids.add(record_id)
        return value

    def _verified_path(
        self, relative_path: str, expected_sha256: str
    ) -> tuple[Path, str]:
        root = self.spec.source_root.resolve()
        path = (root / relative_path).resolve()
        if not path.is_relative_to(root):
            raise SourceAuthorityError(f"source_path_escaped:{relative_path}")
        if not path.is_file():
            raise SourceAuthorityError(f"source_file_missing:{relative_path}")
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != expected_sha256:
            raise SourceAuthorityError(
                "source_hash_mismatch:"
                f"path={relative_path}:expected={expected_sha256}:actual={digest}"
            )
        return path, digest
