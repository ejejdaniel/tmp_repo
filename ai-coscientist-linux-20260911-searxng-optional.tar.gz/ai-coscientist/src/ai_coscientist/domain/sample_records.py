from __future__ import annotations

import copy
from typing import Any, Mapping, Sequence

from .materialization_inputs import record_path_present


def _paths(source_paths: Sequence[str]) -> list[list[str]]:
    paths = sorted(set(source_paths), key=lambda path: (len(path.split(".")), path))
    if not paths:
        raise ValueError("sample_structured_formula_source_paths_required")
    selected: list[list[str]] = []
    for path in paths:
        parts = path.split(".")
        if parts[0] != "record" or any(not part for part in parts):
            raise ValueError(f"sample_source_path_invalid:{path}")
        parts = parts[1:]
        if not any(parts[:len(parent)] == parent for parent in selected):
            selected.append(parts)
    return selected


def _metadata_wrapped(paths: Sequence[Sequence[str]]) -> bool:
    data_paths = [path for path in paths if path not in (["id"], ["input_description"])]
    return bool(data_paths) and all(path and path[0] == "metadata" for path in data_paths)


def candidate_from_source(
    record: Mapping[str, Any], source_paths: Sequence[str]
) -> dict[str, Any]:
    """Project only explicitly bound inputs; never change the stored source row."""
    paths = _paths(source_paths)
    projected: dict[str, Any] = {}
    for parts in paths:
        path = ".".join(["record", *parts])
        if not record_path_present(record, path):
            raise ValueError(f"structured_sample_required_source_path_missing:{path}")
        value: Any = record
        for part in parts:
            value = value[part]
        if not parts:
            projected = copy.deepcopy(dict(record))
            break
        parent = projected
        for part in parts[:-1]:
            parent = parent.setdefault(part, {})
        parent[parts[-1]] = copy.deepcopy(value)
    projected.pop("id", None)
    projected.pop("input_description", None)
    metadata = projected["metadata"] if _metadata_wrapped(paths) else projected
    result = {"id": str(record["id"]), "metadata": metadata}
    if record.get("input_description"):
        result["input_description"] = str(record["input_description"])
    return result


def candidate_to_source(
    candidate: Mapping[str, Any], source_paths: Sequence[str]
) -> dict[str, Any]:
    """Restore the scorer's native paths from the existing candidate envelope."""
    paths = _paths(source_paths)
    metadata = copy.deepcopy(dict(candidate["metadata"]))
    result = {"metadata": metadata} if _metadata_wrapped(paths) else metadata
    result["id"] = str(candidate["id"])
    if any(not path or path == ["input_description"] for path in paths):
        result["input_description"] = str(candidate.get("input_description") or "")
    return result


def validate_candidate_inputs(
    candidate: Mapping[str, Any],
    reference_records: Sequence[Mapping[str, Any]],
    source_paths: Sequence[str],
) -> list[dict[str, Any]]:
    references = [candidate_from_source(record, source_paths) for record in reference_records]
    if not references:
        raise ValueError("sample_historical_references_required")
    restored = candidate_to_source(candidate, source_paths)
    for path in source_paths:
        if not record_path_present(restored, path):
            raise ValueError(f"structured_sample_required_source_path_missing:{path}")
    issues = [
        json_shape_issues(candidate["metadata"], ref["metadata"], path="metadata")
        for ref in references
    ]
    if not any(not issue for issue in issues):
        closest = min(issues, key=lambda issue: (len(issue), tuple(issue)))
        raise ValueError("structured_sample_metadata_shape_mismatch:" + ";".join(closest[:8]))
    return references


def json_shape_issues(candidate: Any, reference: Any, *, path: str) -> list[str]:
    if isinstance(candidate, Mapping) and isinstance(reference, Mapping):
        candidate_keys = set(candidate)
        reference_keys = set(reference)
        issues = [f"missing={path}.{key}" for key in sorted(reference_keys - candidate_keys)]
        issues.extend(f"unexpected={path}.{key}" for key in sorted(candidate_keys - reference_keys))
        for key in sorted(candidate_keys & reference_keys):
            issues.extend(json_shape_issues(candidate[key], reference[key], path=f"{path}.{key}"))
        return issues
    if (
        isinstance(candidate, Sequence) and not isinstance(candidate, (str, bytes))
        and isinstance(reference, Sequence) and not isinstance(reference, (str, bytes))
    ):
        if not candidate:
            return []
        if not reference:
            return [f"unexpected_items={path}"]
        issues = []
        for index, item in enumerate(candidate):
            alternatives = [json_shape_issues(item, template, path=f"{path}[{index}]") for template in reference]
            if not any(not alternative for alternative in alternatives):
                issues.extend(min(alternatives, key=lambda issue: (len(issue), tuple(issue))))
        return issues
    if isinstance(candidate, bool) or isinstance(reference, bool):
        matches = type(candidate) is type(reference)
    elif isinstance(candidate, (int, float)) and isinstance(reference, (int, float)):
        matches = True
    else:
        matches = type(candidate) is type(reference)
    return [] if matches else [f"type={path}:expected_{type(reference).__name__}:actual_{type(candidate).__name__}"]
