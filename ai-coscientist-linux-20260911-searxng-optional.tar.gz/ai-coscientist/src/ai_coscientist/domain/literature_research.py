from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import re
import socket
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence
from urllib.parse import urljoin, urlparse

import requests

from ai_coscientist.common.routes import Route

from .private_knowledge_center_adapter import PrivateKnowledgeCenterAdapter


_MAX_SEARCH_RESULTS = 12
_MAX_RESPONSE_BYTES = 10 * 1024 * 1024
_MAX_DOCUMENT_CHARS = 2_000_000
_MAX_READ_CHARS = 12_000
_REDIRECT_CODES = {301, 302, 303, 307, 308}
_SOURCE_GROUPS = {
    "scholarly": {"engines": "arxiv,crossref,pubmed"},
    "repositories": {"categories": "repos"},
    "web": {"engines": "bing,brave"},
}


class LiteratureResearchError(RuntimeError):
    pass


class LiteratureDocumentStore:
    """C4 store for exact fetched documents and normalized readable content."""

    def __init__(self, root: Path) -> None:
        self._root = (root.resolve() / "workspace" / "literature-documents")
        self._root.mkdir(parents=True, exist_ok=True)
        self._index_path = self._root / "index.json"
        if not self._index_path.exists():
            self._write_json(self._index_path, {"entries": {}})

    def store(
        self,
        *,
        source_url: str,
        raw_content: bytes,
        normalized_text: str,
        media_type: str,
        source_kind: str,
        evidence_scope: str,
        metadata: Mapping[str, Any],
    ) -> dict[str, Any]:
        text = str(normalized_text).strip()
        if not text:
            raise LiteratureResearchError("literature_document_text_required")
        text = text[:_MAX_DOCUMENT_CHARS]
        raw_digest = hashlib.sha256(raw_content).hexdigest()
        digest = hashlib.sha256(
            (source_url + "\n" + raw_digest + "\n" + text).encode("utf-8")
        ).hexdigest()[:20]
        document_ref = f"literature_document:{digest}"
        document_root = self._root / digest
        document_root.mkdir(parents=True, exist_ok=True)
        raw_suffix = _raw_suffix(media_type, source_url)
        raw_path = document_root / f"raw{raw_suffix}"
        text_path = document_root / "content.md"
        metadata_path = document_root / "metadata.json"

        if not raw_path.exists():
            raw_path.write_bytes(raw_content)
        if not text_path.exists():
            text_path.write_text(text + "\n", encoding="utf-8")

        normalized_metadata = _normalize_document_metadata(
            metadata,
            document_ref=document_ref,
            source_url=source_url,
            source_kind=source_kind,
            evidence_scope=evidence_scope,
            media_type=media_type,
            raw_sha256=raw_digest,
            char_count=len(text),
        )
        self._write_json(metadata_path, normalized_metadata)
        index = self._read_index()
        index["entries"][document_ref] = {
            "document_ref": document_ref,
            "content_path": str(text_path),
            "metadata_path": str(metadata_path),
            "raw_path": str(raw_path),
        }
        self._write_json(self._index_path, index)
        return self.describe(document_ref, preview_chars=4_000)

    def describe(
        self,
        document_ref: str,
        *,
        preview_chars: int = 0,
    ) -> dict[str, Any]:
        entry = self._entry(document_ref)
        metadata_path = self._safe_path(entry["metadata_path"])
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        result = {
            "document_ref": document_ref,
            "metadata": metadata,
            "evidence_ready": True,
        }
        if preview_chars > 0:
            text_path = self._safe_path(entry["content_path"])
            result["content_preview"] = text_path.read_text(
                encoding="utf-8"
            )[:preview_chars]
        return result

    def read(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        document_ref = str(arguments.get("document_ref") or "").strip()
        offset = _bounded_int(
            arguments.get("char_offset"), default=0, minimum=0, maximum=2_000_000
        )
        limit = _bounded_int(
            arguments.get("char_limit"),
            default=8_000,
            minimum=1,
            maximum=_MAX_READ_CHARS,
        )
        entry = self._entry(document_ref)
        text_path = self._safe_path(entry["content_path"])
        content = text_path.read_text(encoding="utf-8")
        page = content[offset : offset + limit]
        next_offset = offset + len(page)
        return {
            "status": "literature_document_page",
            "document_ref": document_ref,
            "char_offset": offset,
            "content": page,
            "next_char_offset": next_offset if next_offset < len(content) else None,
            "total_chars": len(content),
            "metadata": self.describe(document_ref)["metadata"],
        }

    def _entry(self, document_ref: str) -> Mapping[str, Any]:
        if not document_ref.startswith("literature_document:"):
            raise LiteratureResearchError(
                f"literature_document_ref_invalid:{document_ref}"
            )
        entry = self._read_index()["entries"].get(document_ref)
        if not isinstance(entry, Mapping):
            raise LiteratureResearchError(
                f"literature_document_ref_unknown:{document_ref}"
            )
        return entry

    def _safe_path(self, value: Any) -> Path:
        path = Path(str(value)).resolve()
        if not path.is_relative_to(self._root):
            raise LiteratureResearchError(f"literature_document_path_outside:{path}")
        return path

    def _read_index(self) -> dict[str, Any]:
        return json.loads(self._index_path.read_text(encoding="utf-8"))

    @staticmethod
    def _write_json(path: Path, value: Mapping[str, Any]) -> None:
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(
            json.dumps(value, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, path)


class LiteratureResearchResources:
    """Bounded search and retrieval routes owned by literature-researcher."""

    def __init__(
        self,
        *,
        run_root: Path,
        searxng_url: str | None = None,
        private_endpoint_url: str | None = None,
        private_mock_response_path: Path | None = None,
        session: Any | None = None,
        resolver: Callable[[str], Sequence[str]] | None = None,
    ) -> None:
        self._run_root = run_root.resolve()
        self._documents = LiteratureDocumentStore(self._run_root)
        self._searxng_url = str(searxng_url or "").strip().rstrip("/")
        self._session = session or requests.Session()
        self._resolver = resolver or _resolve_host_addresses
        self._leads: dict[str, dict[str, Any]] = {}
        self._audit_path = self._run_root / "logs" / "literature-http.jsonl"
        self._audit_path.parent.mkdir(parents=True, exist_ok=True)
        self._private = PrivateKnowledgeCenterAdapter(
            endpoint_url=private_endpoint_url,
            mock_response_path=private_mock_response_path,
            document_sink=self._documents.store,
            audit_path=self._audit_path,
            session=self._session,
        )

    @classmethod
    def from_environment(cls, *, run_root: Path) -> "LiteratureResearchResources":
        mock_path = str(
            os.environ.get("AI_COSCIENTIST_PRIVATE_KNOWLEDGE_MOCK") or ""
        ).strip()
        return cls(
            run_root=run_root,
            searxng_url=os.environ.get("AI_COSCIENTIST_SEARXNG_URL"),
            private_endpoint_url=os.environ.get(
                "AI_COSCIENTIST_PRIVATE_KNOWLEDGE_URL"
            ),
            private_mock_response_path=Path(mock_path) if mock_path else None,
        )

    def routes(self, *, skill_ids: Sequence[str]) -> tuple[Route, ...]:
        owners = tuple(str(skill_id) for skill_id in skill_ids)
        if not owners:
            raise ValueError("literature_research_skill_ids_required")
        routes = (
            Route(
                name="literature_public_search",
                description=(
                    "Ask one natural-language literature question through the "
                    "configured SearXNG service. Results are candidate leads only; "
                    "they cannot be cited until literature_document_fetch stores "
                    "evidence-ready content."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "minLength": 3},
                        "why": {"type": "string", "minLength": 3},
                        "source_group": {
                            "type": "string",
                            "enum": ["scholarly", "repositories", "web"],
                        },
                        "limit": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": _MAX_SEARCH_RESULTS,
                        },
                    },
                    "required": ["query", "why", "source_group"],
                    "additionalProperties": False,
                },
                handler=self.search_public,
                skill_ids=owners,
                validator=_validate_public_search,
            ),
            Route(
                name="literature_document_fetch",
                description=(
                    "Fetch one exact prior search result, extract bounded HTML, "
                    "Markdown, text, or PDF content, and store it as a C4 document. "
                    "Static retrieval is bounded and never recursively crawls links."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "result_id": {"type": "string"},
                        "why": {"type": "string", "minLength": 3},
                    },
                    "required": ["result_id", "why"],
                    "additionalProperties": False,
                },
                handler=self.fetch_document,
                skill_ids=owners,
                validator=_validate_document_fetch,
            ),
            Route(
                name="literature_document_read",
                description=(
                    "Read one exact C4 literature document in bounded character "
                    "pages. Use next_char_offset to continue without duplicating the "
                    "stored content in prompts."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "document_ref": {"type": "string"},
                        "char_offset": {"type": "integer", "minimum": 0},
                        "char_limit": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": _MAX_READ_CHARS,
                        },
                    },
                    "required": ["document_ref"],
                    "additionalProperties": False,
                },
                handler=self._documents.read,
                skill_ids=owners,
                validator=_validate_document_read,
            ),
            self._private.route(skill_ids=owners),
        )
        return tuple(
            route for route in routes
            if route.name != "literature_public_search" or self._searxng_url
        )

    def search_public(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        _validate_public_search(arguments)
        query = str(arguments["query"]).strip()
        why = str(arguments["why"]).strip()
        source_group = str(arguments["source_group"]).strip()
        limit = _bounded_int(
            arguments.get("limit"),
            default=8,
            minimum=1,
            maximum=_MAX_SEARCH_RESULTS,
        )
        if not self._searxng_url:
            return {
                "status": "public_search_unavailable",
                "reason": "SearXNG is disabled: AI_COSCIENTIST_SEARXNG_URL is empty or unset",
                "query": query,
                "why": why,
                "source_group": source_group,
                "results": [],
            }

        group_config = _source_group_config(source_group)
        params: dict[str, Any] = {
            "q": query,
            "format": "json",
            "language": "all",
            "safesearch": 0,
            **group_config,
        }
        request_url = f"{self._searxng_url}/search"
        try:
            response = self._session.get(request_url, params=params, timeout=(10, 60))
            response.raise_for_status()
            raw = response.json()
            if not isinstance(raw, Mapping):
                raise LiteratureResearchError("searxng_response_must_be_object")
        except Exception as exc:
            self._append_audit(
                {
                    "operation": "public_search",
                    "query": query,
                    "why": why,
                    "source_group": source_group,
                    "status": "failed",
                    "reason": f"{type(exc).__name__}: {exc}",
                }
            )
            return {
                "status": "public_search_failed",
                "reason": f"{type(exc).__name__}: {exc}",
                "query": query,
                "why": why,
                "source_group": source_group,
                "results": [],
            }

        normalized: list[dict[str, Any]] = []
        for raw_result in list(raw.get("results") or ()):
            if not isinstance(raw_result, Mapping):
                continue
            result = _normalize_search_result(raw_result, source_group=source_group)
            if result is None:
                continue
            self._leads[result["result_id"]] = result
            normalized.append(result)
            if len(normalized) >= limit:
                break
        unresponsive = _normalize_unresponsive_engines(
            raw.get("unresponsive_engines")
        )
        self._append_audit(
            {
                "operation": "public_search",
                "query": query,
                "why": why,
                "source_group": source_group,
                "request": {"url": request_url, "params": params},
                "status": "ready",
                "raw_response": raw,
            }
        )
        return {
            "status": "public_search_ready",
            "query": query,
            "why": why,
            "source_group": source_group,
            "results": normalized,
            "unresponsive_engines": unresponsive,
        }

    def fetch_document(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        _validate_document_fetch(arguments)
        result_id = str(arguments["result_id"]).strip()
        why = str(arguments["why"]).strip()
        lead = self._leads.get(result_id)
        if lead is None:
            raise LiteratureResearchError(
                f"literature_search_result_unknown:{result_id}"
            )
        url = str(lead["url"])
        try:
            final_url, response, raw_content = self._safe_get(url)
            media_type = str(response.headers.get("Content-Type") or "").split(
                ";", 1
            )[0].strip().lower()
            text, extracted_metadata = _extract_document(
                raw_content,
                media_type=media_type,
                source_url=final_url,
            )
            _assert_substantive_document(
                text,
                media_type=media_type,
                extracted_metadata=extracted_metadata,
            )
            metadata = _merge_document_metadata(lead, extracted_metadata)
            record = self._documents.store(
                source_url=final_url,
                raw_content=raw_content,
                normalized_text=text,
                media_type=media_type,
                source_kind=str(lead["source_kind"]),
                evidence_scope="full_text",
                metadata=metadata,
            )
            status = "literature_document_ready"
            reason = ""
        except Exception as exc:
            abstract = str(lead.get("abstract") or "").strip()
            if bool(lead.get("credible_abstract")) and abstract:
                record = self._documents.store(
                    source_url=url,
                    raw_content=json.dumps(
                        lead, ensure_ascii=False, sort_keys=True
                    ).encode("utf-8"),
                    normalized_text=abstract,
                    media_type="application/json",
                    source_kind=str(lead["source_kind"]),
                    evidence_scope="abstract",
                    metadata=lead,
                )
                status = "literature_abstract_ready"
                reason = f"full_text_unavailable:{type(exc).__name__}: {exc}"
            else:
                self._append_audit(
                    {
                        "operation": "document_fetch",
                        "result_id": result_id,
                        "url": url,
                        "why": why,
                        "status": "lead_only",
                        "reason": f"{type(exc).__name__}: {exc}",
                    }
                )
                return {
                    "status": "literature_lead_only",
                    "result_id": result_id,
                    "url": url,
                    "why": why,
                    "reason": f"{type(exc).__name__}: {exc}",
                    "evidence_ready": False,
                }

        self._append_audit(
            {
                "operation": "document_fetch",
                "result_id": result_id,
                "url": url,
                "why": why,
                "status": status,
                "document_ref": record["document_ref"],
                "reason": reason,
            }
        )
        return {
            "status": status,
            "result_id": result_id,
            "why": why,
            "reason": reason,
            **record,
        }

    def _safe_get(self, initial_url: str) -> tuple[str, Any, bytes]:
        current_url = initial_url
        for _redirect in range(6):
            _assert_public_http_url(current_url, resolver=self._resolver)
            response = self._session.get(
                current_url,
                timeout=(10, 60),
                allow_redirects=False,
                stream=True,
                headers={
                    "User-Agent": "ai-coscientist-literature-researcher/0.1"
                },
            )
            if response.status_code in _REDIRECT_CODES:
                location = str(response.headers.get("Location") or "").strip()
                response.close()
                if not location:
                    raise LiteratureResearchError(
                        "literature_redirect_location_missing"
                    )
                current_url = urljoin(current_url, location)
                continue
            if response.status_code < 200 or response.status_code >= 300:
                response.close()
                raise LiteratureResearchError(
                    f"literature_http_status:{response.status_code}"
                )
            raw_content = _bounded_response_bytes(response)
            final_url = str(getattr(response, "url", "") or current_url)
            _assert_public_http_url(final_url, resolver=self._resolver)
            return final_url, response, raw_content
        raise LiteratureResearchError("literature_redirect_limit_exceeded")

    def _append_audit(self, value: Mapping[str, Any]) -> None:
        with self._audit_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(value, ensure_ascii=False, default=str) + "\n")


def _source_group_config(source_group: str) -> dict[str, str]:
    defaults = _SOURCE_GROUPS.get(source_group)
    if defaults is None:
        raise LiteratureResearchError(
            f"literature_source_group_unknown:{source_group}"
        )
    env_key = f"AI_COSCIENTIST_SEARXNG_{source_group.upper()}_ENGINES"
    configured_engines = str(os.environ.get(env_key) or "").strip()
    if configured_engines:
        return {"engines": configured_engines}
    return dict(defaults)


def _normalize_search_result(
    raw: Mapping[str, Any], *, source_group: str
) -> dict[str, Any] | None:
    url = str(raw.get("url") or "").strip()
    title = str(raw.get("title") or "").strip()
    if not url or not title:
        return None
    engines = _string_list(raw.get("engines") or raw.get("engine"))
    engine_names = {value.lower() for value in engines}
    abstract = str(raw.get("content") or raw.get("abstract") or "").strip()
    source_kind = _source_kind(source_group, engine_names, url)
    result_id = "literature_result:" + hashlib.sha256(
        (url + "\n" + title).encode("utf-8")
    ).hexdigest()[:16]
    return {
        "result_id": result_id,
        "title": title[:1_000],
        "url": url,
        "abstract": abstract[:8_000],
        "authors": _authors(raw.get("authors") or raw.get("author")),
        "published": str(
            raw.get("publishedDate")
            or raw.get("published")
            or raw.get("date")
            or ""
        ).strip()[:200],
        "doi": str(raw.get("doi") or "").strip()[:500],
        "site": str(raw.get("site") or urlparse(url).netloc).strip()[:500],
        "engines": engines,
        "source_kind": source_kind,
        "credible_abstract": bool(
            len(abstract) >= 200
            and source_kind == "journal_or_preprint"
            and engine_names.intersection({"arxiv", "crossref", "pubmed"})
        ),
    }


def _source_kind(source_group: str, engines: set[str], url: str) -> str:
    if engines.intersection({"arxiv", "crossref", "pubmed"}):
        return "journal_or_preprint"
    host = urlparse(url).netloc.lower()
    if source_group == "repositories" or "github.com" in host:
        return "software_repository"
    return "web_page"


def _normalize_unresponsive_engines(value: Any) -> list[dict[str, str]]:
    normalized: list[dict[str, str]] = []
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return normalized
    for item in value:
        if isinstance(item, Mapping):
            normalized.append(
                {
                    "engine": str(item.get("engine") or ""),
                    "reason": str(item.get("reason") or ""),
                }
            )
        elif isinstance(item, Sequence) and not isinstance(item, (str, bytes)):
            values = list(item)
            normalized.append(
                {
                    "engine": str(values[0] if values else ""),
                    "reason": str(values[1] if len(values) > 1 else ""),
                }
            )
        else:
            normalized.append({"engine": str(item), "reason": ""})
    return normalized


def _extract_document(
    raw_content: bytes, *, media_type: str, source_url: str
) -> tuple[str, dict[str, Any]]:
    is_pdf = media_type == "application/pdf" or urlparse(source_url).path.lower().endswith(
        ".pdf"
    )
    if is_pdf:
        return _extract_pdf(raw_content), {}
    encoding = "utf-8"
    text = raw_content.decode(encoding, errors="replace")
    if media_type in {"text/markdown", "text/plain", "application/json"}:
        normalized = text.strip()
        if not normalized:
            raise LiteratureResearchError("literature_document_empty")
        return normalized, {}
    return _extract_html(text, source_url=source_url)


def _assert_substantive_document(
    text: str,
    *,
    media_type: str,
    extracted_metadata: Mapping[str, Any],
) -> None:
    if not media_type.startswith("text/html"):
        return
    normalized_length = len(" ".join(text.split()))
    has_document_metadata = bool(
        _authors(extracted_metadata.get("authors"))
        or str(extracted_metadata.get("published") or "").strip()
        or str(extracted_metadata.get("doi") or "").strip()
    )
    if normalized_length < 400 and not has_document_metadata:
        raise LiteratureResearchError(
            "literature_html_non_substantive_or_access_interstitial"
        )


def _extract_pdf(raw_content: bytes) -> str:
    try:
        import pymupdf  # type: ignore
    except ImportError as exc:
        raise LiteratureResearchError("pdf_parser_unavailable:pymupdf") from exc
    try:
        document = pymupdf.open(stream=raw_content, filetype="pdf")
        pages = [page.get_text("text") for page in document]
        document.close()
    except Exception as exc:
        raise LiteratureResearchError(f"pdf_parse_failed:{exc}") from exc
    text = "\n\n".join(page.strip() for page in pages if page.strip()).strip()
    if not text:
        raise LiteratureResearchError("pdf_text_empty")
    return text


def _extract_html(html: str, *, source_url: str) -> tuple[str, dict[str, Any]]:
    parser = _DocumentHTMLParser()
    parser.feed(html)
    parser.close()
    fallback = parser.text()
    extracted = ""
    try:
        import trafilatura  # type: ignore

        extracted = str(
            trafilatura.extract(
                html,
                url=source_url,
                output_format="markdown",
                include_comments=False,
                include_tables=True,
            )
            or ""
        ).strip()
    except ImportError:
        extracted = ""
    except Exception:
        extracted = ""
    text = extracted or fallback
    if not text:
        raise LiteratureResearchError("html_text_empty_or_dynamic_page")
    return text, parser.metadata()


class _DocumentHTMLParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._skip_depth = 0
        self._in_title = False
        self._text: list[str] = []
        self._title: list[str] = []
        self._metadata: dict[str, list[str]] = {}

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        lowered = tag.lower()
        if lowered in {"script", "style", "noscript", "svg"}:
            self._skip_depth += 1
        if lowered == "title":
            self._in_title = True
        if lowered != "meta":
            return
        values = {str(key).lower(): str(value or "") for key, value in attrs}
        name = (values.get("name") or values.get("property") or "").lower()
        content = values.get("content", "").strip()
        if name and content:
            self._metadata.setdefault(name, []).append(content)

    def handle_endtag(self, tag: str) -> None:
        lowered = tag.lower()
        if lowered == "title":
            self._in_title = False
        if lowered in {"script", "style", "noscript", "svg"} and self._skip_depth:
            self._skip_depth -= 1

    def handle_data(self, data: str) -> None:
        value = " ".join(data.split()).strip()
        if not value:
            return
        if self._in_title:
            self._title.append(value)
        if self._skip_depth == 0:
            self._text.append(value)

    def text(self) -> str:
        return "\n".join(self._text).strip()

    def metadata(self) -> dict[str, Any]:
        def first(*keys: str) -> str:
            for key in keys:
                values = self._metadata.get(key, [])
                if values:
                    return values[0]
            return ""

        authors = self._metadata.get("citation_author", [])
        return {
            "title": first("citation_title", "og:title")
            or " ".join(self._title).strip(),
            "authors": authors,
            "published": first(
                "citation_publication_date",
                "article:published_time",
                "date",
            ),
            "doi": first("citation_doi", "dc.identifier"),
            "site": first("og:site_name"),
        }


def _merge_document_metadata(
    lead: Mapping[str, Any], extracted: Mapping[str, Any]
) -> dict[str, Any]:
    return {
        "title": str(extracted.get("title") or lead.get("title") or "").strip(),
        "authors": _authors(extracted.get("authors") or lead.get("authors")),
        "published": str(
            extracted.get("published") or lead.get("published") or ""
        ).strip(),
        "doi": str(extracted.get("doi") or lead.get("doi") or "").strip(),
        "site": str(extracted.get("site") or lead.get("site") or "").strip(),
        "engines": _string_list(lead.get("engines")),
        "result_id": str(lead.get("result_id") or ""),
    }


def _normalize_document_metadata(
    metadata: Mapping[str, Any],
    *,
    document_ref: str,
    source_url: str,
    source_kind: str,
    evidence_scope: str,
    media_type: str,
    raw_sha256: str,
    char_count: int,
) -> dict[str, Any]:
    return {
        "document_ref": document_ref,
        "title": str(metadata.get("title") or source_url).strip()[:2_000],
        "url": source_url,
        "source_kind": source_kind,
        "evidence_scope": evidence_scope,
        "authors": _authors(metadata.get("authors")),
        "published": str(metadata.get("published") or "").strip()[:500],
        "doi": str(metadata.get("doi") or "").strip()[:500],
        "site": str(
            metadata.get("site") or urlparse(source_url).netloc
        ).strip()[:500],
        "media_type": media_type,
        "raw_sha256": raw_sha256,
        "char_count": char_count,
    }


def _bounded_response_bytes(response: Any) -> bytes:
    content_length = str(response.headers.get("Content-Length") or "").strip()
    if content_length.isdigit() and int(content_length) > _MAX_RESPONSE_BYTES:
        response.close()
        raise LiteratureResearchError("literature_response_too_large")
    chunks: list[bytes] = []
    total = 0
    iterator = getattr(response, "iter_content", None)
    if callable(iterator):
        for chunk in iterator(chunk_size=64 * 1024):
            if not chunk:
                continue
            total += len(chunk)
            if total > _MAX_RESPONSE_BYTES:
                response.close()
                raise LiteratureResearchError("literature_response_too_large")
            chunks.append(bytes(chunk))
        response.close()
        return b"".join(chunks)
    content = bytes(getattr(response, "content", b""))
    response.close()
    if len(content) > _MAX_RESPONSE_BYTES:
        raise LiteratureResearchError("literature_response_too_large")
    return content


def _assert_public_http_url(
    url: str, *, resolver: Callable[[str], Sequence[str]]
) -> None:
    parsed = urlparse(str(url))
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise LiteratureResearchError(f"literature_url_invalid:{url}")
    host = parsed.hostname.lower()
    if host == "localhost":
        raise LiteratureResearchError(f"literature_url_private:{host}")
    addresses = tuple(resolver(host))
    if not addresses:
        raise LiteratureResearchError(f"literature_url_unresolved:{host}")
    for address in addresses:
        try:
            ip = ipaddress.ip_address(address)
        except ValueError as exc:
            raise LiteratureResearchError(
                f"literature_url_address_invalid:{address}"
            ) from exc
        if not ip.is_global:
            raise LiteratureResearchError(f"literature_url_private:{address}")


def _resolve_host_addresses(host: str) -> tuple[str, ...]:
    return tuple(
        dict.fromkeys(
            str(item[4][0])
            for item in socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
        )
    )


def _validate_public_search(arguments: Mapping[str, Any]) -> None:
    query = str(arguments.get("query") or "").strip()
    why = str(arguments.get("why") or "").strip()
    group = str(arguments.get("source_group") or "").strip()
    if len(query) < 3:
        raise LiteratureResearchError("literature_query_required")
    if len(why) < 3:
        raise LiteratureResearchError("literature_query_reason_required")
    if group not in _SOURCE_GROUPS:
        raise LiteratureResearchError(f"literature_source_group_unknown:{group}")
    _bounded_int(
        arguments.get("limit"),
        default=8,
        minimum=1,
        maximum=_MAX_SEARCH_RESULTS,
    )


def _validate_document_fetch(arguments: Mapping[str, Any]) -> None:
    if not str(arguments.get("result_id") or "").strip():
        raise LiteratureResearchError("literature_result_id_required")
    if len(str(arguments.get("why") or "").strip()) < 3:
        raise LiteratureResearchError("literature_fetch_reason_required")


def _validate_document_read(arguments: Mapping[str, Any]) -> None:
    document_ref = str(arguments.get("document_ref") or "").strip()
    if not document_ref.startswith("literature_document:"):
        raise LiteratureResearchError(
            f"literature_document_ref_invalid:{document_ref}"
        )
    _bounded_int(
        arguments.get("char_offset"), default=0, minimum=0, maximum=2_000_000
    )
    _bounded_int(
        arguments.get("char_limit"),
        default=8_000,
        minimum=1,
        maximum=_MAX_READ_CHARS,
    )


def _bounded_int(value: Any, *, default: int, minimum: int, maximum: int) -> int:
    if value is None:
        return default
    if isinstance(value, bool):
        raise LiteratureResearchError("bounded_integer_invalid")
    try:
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise LiteratureResearchError("bounded_integer_invalid") from exc
    if parsed < minimum or parsed > maximum:
        raise LiteratureResearchError(
            f"bounded_integer_out_of_range:{parsed}:{minimum}:{maximum}"
        )
    return parsed


def _authors(value: Any) -> list[str]:
    if isinstance(value, str):
        candidates = re.split(r"\s*(?:;|\band\b)\s*", value)
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        candidates = [
            str(item.get("name") or "") if isinstance(item, Mapping) else str(item)
            for item in value
        ]
    else:
        candidates = []
    return [item.strip()[:500] for item in candidates if item.strip()][:100]


def _string_list(value: Any) -> list[str]:
    if isinstance(value, str):
        values = [value]
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        values = [str(item) for item in value]
    else:
        values = []
    return [item.strip()[:500] for item in values if item.strip()]


def _raw_suffix(media_type: str, source_url: str) -> str:
    if media_type == "application/pdf":
        return ".pdf"
    if media_type == "text/markdown":
        return ".md"
    if media_type == "application/json":
        return ".json"
    if media_type.startswith("text/html"):
        return ".html"
    suffix = Path(urlparse(source_url).path).suffix
    return suffix[:12] if suffix else ".bin"
