from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ai_coscientist.domain.scientific_content_deepening import (
    SCIENTIFIC_CLAIM_CALIBRATION_GUIDE,
    deepen_proxy_formula_explanation,
)
from ai_coscientist.domain.source_inspection import SOURCE_CONTEXT_GUIDE, SourceInspection


FormulaValidator = Callable[[Mapping[str, Any]], list[str]]


class ProxySourceGroundingGap(ValueError):
    """P2 found no suitable quantity; the owning skill returns bounded_gap."""


_FIRST_PRINCIPLES_SCHEMA = {
    "type": "object",
    "properties": {
        "candidate_quantities": {
            "type": "array",
            "minItems": 1,
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "meaning": {"type": "string"},
                    "first_principles_link": {"type": "string"},
                    "expected_effect_on_target": {"type": "string"},
                    "low_cost_calculation_idea": {"type": "string"},
                },
                "required": [
                    "name",
                    "meaning",
                    "first_principles_link",
                    "expected_effect_on_target",
                    "low_cost_calculation_idea",
                ],
                "additionalProperties": False,
            },
        },
        "formula_design_notes": {
            "type": "array",
            "items": {"type": "string"},
        },
    },
    "required": ["candidate_quantities", "formula_design_notes"],
    "additionalProperties": False,
}

_HISTORICAL_GROUNDING_SCHEMA = {
    "type": "object",
    "properties": {
        "grounded_quantities": {
            "type": "array",
            "minItems": 0,
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "minLength": 1},
                    "meaning": {"type": "string", "minLength": 1},
                    "source_inputs": {
                        "type": "array",
                        "minItems": 1,
                        "items": {"type": "string", "minLength": 1},
                    },
                    "calculation_method": {"type": "string", "minLength": 1},
                    "visible_variation": {"type": "string", "minLength": 1},
                    "expected_effect_on_target": {
                        "type": "string",
                        "minLength": 1,
                    },
                },
                "required": [
                    "name",
                    "meaning",
                    "source_inputs",
                    "calculation_method",
                    "visible_variation",
                    "expected_effect_on_target",
                ],
                "additionalProperties": False,
            },
        },
        "excluded_quantities": {
            "type": "array",
            "items": {"type": "string"},
        },
        "historical_summary": {"type": "string"},
    },
    "required": [
        "grounded_quantities",
        "excluded_quantities",
        "historical_summary",
    ],
    "additionalProperties": False,
}

_FORMULA_CORE_SCHEMA = {
    "type": "object",
    "properties": {
        "artifact_kind": {
            "type": "string",
            "enum": ["proxy_formula_candidate"],
        },
        "formula_id": {"type": "string", "minLength": 1},
        "version": {"type": "integer"},
        "formula_expression": {"type": "string", "minLength": 1},
        "selected_candidate_proxy_quantity_refs": {
            "type": "array",
            "minItems": 1,
            "items": {"type": "string", "minLength": 1},
        },
        "expected_final_kpi_link": {"type": "string", "minLength": 1},
        "expected_relation": {
            "type": "string",
            "enum": [
                "higher_proxy_higher_kpi",
                "lower_proxy_higher_kpi",
            ],
        },
        "side_effect_notes": {
            "type": "array",
            "minItems": 1,
            "items": {"type": "string", "minLength": 1},
        },
        "claim_boundary": {"type": "string", "minLength": 1},
        "validation_criteria": {
            "type": "object",
            "additionalProperties": True,
        },
    },
    "required": [
        "artifact_kind",
        "formula_id",
        "version",
        "formula_expression",
        "selected_candidate_proxy_quantity_refs",
        "expected_final_kpi_link",
        "expected_relation",
        "side_effect_notes",
        "claim_boundary",
        "validation_criteria",
    ],
    "additionalProperties": False,
}

_PRIVATE_REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "score": {"type": "integer", "enum": [0, 4]},
        "reason": {"type": "string", "minLength": 1, "maxLength": 4000},
    },
    "required": ["score", "reason"],
    "additionalProperties": False,
}

_RELATION_DIRECTION_GUIDE = """\
Expected-relation truth table (the legacy _kpi suffix means the current target,
including an auxiliary condition):
- higher_proxy_higher_kpi: a larger numeric proxy value means better
  satisfaction of the current target.
- lower_proxy_higher_kpi: a smaller numeric proxy value means better
  satisfaction of the current target.
If the scientific explanation says a larger proxy is better, only the first
value is valid. If it says a smaller proxy is better, only the second is valid.
Apply this relation to the complete numeric result of formula_expression, never
to an inner estimate, one input variable, or an untransformed scientific driver.
"""

_TARGET_SATISFACTION_GUIDE = """\
The formula is a fallible physical proxy whose target relation is tested later,
not a numeric imitation of the target function. It may represent a mechanistic
driver, a competing-channel balance, or a source-bound estimate of the target.
State one falsifiable expected relation for the visible scientific regime; weak
or wrong later correlation is a valid research result and must not be hidden by
reshaping the proxy to resemble the target.

When the target is centered on a value, bounded by a range, or otherwise
non-monotonic, do not automatically copy that mathematical shape into the proxy.
Use a target reference inside the expression only when selected grounded
quantities produce a source-bound estimate with commensurate physical units and
numeric scale, or when the reference is intrinsic to the grounded quantity and
has an explicit scientific derivation. A dimensionless or arbitrarily scaled
descriptor cannot be centered at an invented value such as 1.0, multiplied by a
public target number, or subtracted from a dimensional target merely because
both are numeric. If no commensurate estimate exists, publish an interpretable
driver or trade-off index and bound the claimed direction to the supported
regime; explicitly leave the unknown optimum and possible overshoot for later
evaluation. Do not invent a transfer function, calibration, or ideal reference.

The complete published expression remains frozen: Materializer implements it
and must not append a target transformation. Never make the declared direction
conditional on a hidden per-record target value.
"""


_RELATIONSHIP_REVIEW_SYSTEM = f"""\
Perform one binary producer-red-line review of whether this proxy candidate has
a scientifically coherent relation to the stated target. Return 0 for a hard
defect in the candidate as written and 4 when no hard defect is established.
Do not grade general quality or propose a replacement.

{_RELATION_DIRECTION_GUIDE}

{SCIENTIFIC_CLAIM_CALIBRATION_GUIDE}

Use this authority order:
1. target_metric defines target identity, scientific meaning, units or numeric
   reference expressed in that meaning, and what better satisfaction means.
2. historical_grounding defines the available quantities, their physical or
   dimensionless meaning, source boundary, and calculation method.
3. formula_expression and expected_relation define the candidate mathematics.
4. declared_target_link and other candidate explanations are claims to audit;
   they are never evidence that changes the first three authorities.

For an auxiliary condition, the legacy `_kpi` suffix in the relation enum does
not turn the condition into the final KPI.

Before assigning a score, first follow the complete formula numerically and
compare its final output with better or worse target satisfaction. Do not replace
the final output with an inner estimate when interpreting expected_relation. For
example, in `-abs(z - target)`, values closer to zero are larger and represent
closer target agreement; `higher_proxy_higher_kpi` is therefore directionally
coherent even though `z` itself is not globally higher-is-better. Then inspect
the input effects against the stated mechanistic claims. A target-shaped formula
may legitimately change an input's local direction on opposite sides of its
optimum; that alone is not a contradiction unless the candidate claims a global
monotonic input effect. Follow inverses, subtraction, signs, and target
transformations numerically rather than by intuition.

Check commensurability separately from direction. Return 0 when the expression
uses a target numeric reference to scale, center, or transform an unrelated
ordinal or dimensionless descriptor without a public source-bound derivation
connecting their units and numeric scale. Calling the target, descriptor, or
coefficient "dimensionless", "structural", or "not fitted" does not create that
derivation. A target-shaped formula is not coherent merely because it resembles
the target mathematically. Also return 0 for hidden-target leakage, target
substitution, fake sources, a complete-output directional contradiction, or a
claim that contradicts grounded expected effects. A repairable defect remains a
red line.

Do not reject a physically interpretable driver or competing-channel index only
because it does not reproduce a centered target's mathematical shape. When the
candidate clearly bounds its expected relation to a supported regime, judge
whether that direction is physically plausible from the supplied context.
Unknown optimum location, possible overshoot, and lack of correlation proof are
scientific uncertainty for later evaluation, not by themselves producer red
lines.

Return 4 when no such hard defect is established. Weak evidence, limited
coverage, uncertain fidelity, an ambitious boundary, or disagreement with an
upstream hypothesis may be stated in the reason but are not producer red lines.
Return only score and one concise reason.
"""

_OPERATIONALIZATION_REVIEW_SYSTEM = f"""\
Perform one binary producer-red-line review of whether every selected quantity
has at least one faithful, objective, low-cost computational operationalization
from the visible source boundary. Return 0 for a hard defect and 4 otherwise.
Do not grade general quality or prescribe one unique code implementation. The
producer must define each scientific concept, its target relationship, source
relationship, and claim boundary well enough to distinguish a faithful surrogate
from an unrelated easy-to-compute quantity. Materializer owns choosing and
testing the concrete library, parser, numerical method, approximation, physical
regime, reference scale, structural surrogate, or transparent numeric mapping.
Those choices may produce method-dependent values and must be disclosed and
judged later; their existence is not a producer defect. Materializer still may
not change the frozen target, formula expression, expected direction, or replace
the declared concept with an unrelated one.
Compare every required record input against sanitized_source_shape, and its
interpretation and calculation against the exact source definitions as well.
Do not assume unnamed subfields, measurements, spectra, database values, or
instrument outputs exist. A field naming a method does not contain that method's
result. A visible representation describes a particular record entity; it cannot
be silently substituted for a different named entity. A supposedly known
external entity, an "if available" descriptor, or a fallback with no defensible
relationship to the declared concept is not a source-bound operationalization.
The calling research skill is responsible for the concept, relation, source
boundary, and target-defining invariants. Materializer is responsible for
operationalizing that concept and testing its chosen method. Final-KPI Proxy
Discovery does not need to prescribe one unique implementation, and the same
boundary applies to any other research skill that uses this route.

Return 0 when every plausible implementation needs forbidden or unavailable
data, invents a source, assigns one entity's representation to another entity's
property, computes a different quantity, violates a target-defining invariant,
or provides neither a scientific concept nor a source relationship from which a
defensible computation could be developed. Multiple plausible approximations,
regimes, exponents, reference scales, structural surrogates, or transparent
numeric mappings are not producer defects: Materializer owns selecting,
implementing, and disclosing a reasonable method, while later review judges its
strength. A visible machine-readable representation may support that work even
when no numeric property column exists. Return 4 when at least one faithful,
low-cost route is scientifically plausible. Edge cases, method sensitivity, and
uncertainty may be stated in the reason but are not red lines. Return only score
and one concise reason.

{SCIENTIFIC_CLAIM_CALIBRATION_GUIDE}
"""

_OBSERVABILITY_REVIEW_SYSTEM = f"""\
Perform one binary producer-red-line review of whether materialization and later
evaluation can produce a discriminating result under the stated boundary.
Return 0 for a hard defect and 4 otherwise. Do not grade general quality, demand
target-correlation proof, or propose a replacement.

Trace the complete expression using the supplied historical grounding. Return 0
when the available source facts establish that the complete output is identical
across every visible historical record because inputs are fixed, varying factors
cancel exactly, or a transformation reduces them to an invariant. Such a formula
cannot rank the visible records or support historical target-trend evaluation,
even though a program can compute its constant value. Also return 0 for use of
ungranted target data, circular self-proof, or attribution of the
visible record to the wrong entity. Return 4 when variation remains possible;
small samples, uncertain validation strength, or partial coverage may be stated
in the reason but are not red lines. Return only score and one concise reason.

{SCIENTIFIC_CLAIM_CALIBRATION_GUIDE}
"""

_DRAFT_SYSTEM = f"""\
Produce the scientific core of one interpretable, low-computation formula that
can later be implemented against every sanitized historical record. The proxy
should plausibly track the supplied target trend; it is not the target itself
and it is not an LLM score.

Use this authority order:
1. target_metric defines what better target satisfaction means.
2. historical_grounding selects the grounded quantities and declared methods.
   Exact source definitions remain evidence authority, not their model retelling.
3. first_principles_basis, formal_scientific_context, and any evaluated formula
   history are scientific inspiration and comparative evidence. They may be
   challenged and must not override the target or grounded source facts.

When research_mode is explore, first_principles_basis is the independent P1
result and the full formal_scientific_context is the later reconciliation
context. Preserve useful novelty, but use the restored context to detect known
conflicts, duplication, and unsupported links before composing the formula.

Do not copy a prior idea merely because it appears in shared research assets.
Do not invent a quantitative transfer function, calibration constant, or ideal
reference to force a raw mechanistic driver into the target's numeric shape.

Use direct visible record values, explicitly sourced fixed process settings, or
quantities deterministically computed from record content interpreted through
the inspected source definitions. Follow the supplied materializer_capability
for available methods, source boundaries and task-relative computation cost.
Do not assume new measurements or human qualitative ratings. A process constant may be included for
mechanistic context but cannot be claimed as observed historical variation. For
target_kind auxiliary_condition, describe and validate better satisfaction of
that condition; do not claim direct final-KPI correlation unless supplied
evidence establishes it.

{_RELATION_DIRECTION_GUIDE}

{_TARGET_SATISFACTION_GUIDE}

{SCIENTIFIC_CLAIM_CALIBRATION_GUIDE}

Define the scientific quantity, relation, source boundary, invariants, and
formula. Identify at least one plausible faithful low-cost route, but do not
prescribe the only implementation. Materializer later chooses and tests the
concrete operationalization. The formula published here is nevertheless the
complete frozen proxy-score computation; Materializer may implement its grounded
quantities but must not append a target transformation or alter the scientific
objective. Do not calculate per-record proxy values here.

`formula_id` names the stable scientific method lineage, not one attempt. Use a
concise lower_snake_case method name without a version suffix such as `_v2`;
put the positive integer revision only in `version`. A scientifically distinct
challenger may use a new formula_id. A repair of the same candidate must keep
its existing formula_id and version.

Return only the formula-design fields declared by this stage. The route host
mechanically injects target_kind and target_id, then projects input_variables,
source_binding, historical_variation_evidence, and materialization_contract from
the selected historical-grounding entries. Do not restate or rename those
mechanically owned fields.
`expected_final_kpi_link` records the scientific link to the supplied
target for the current public contract. formula_expression must be one
Python/SciPy scalar expression with numeric constants and selected grounded
quantity names, never an assignment, raw record path, collection expression,
or placeholder weights. Every expression variable and every entry in
selected_candidate_proxy_quantity_refs must use the exact same name from
historical_grounding.grounded_quantities; do not introduce implementation
variables or revive an excluded or merely first-principles quantity.
Include limitations, claim boundary,
and evidence-proportionate validation criteria. Use expected_relation only as
higher_proxy_higher_kpi or lower_proxy_higher_kpi. Never include hidden target
values or per-sample results.
When evaluated_formula_history is present, use the whole ranked history as
comparative evidence. Propose a scientifically distinct, interpretable
correction or diversification; do not merely rename, rescale, or cosmetically
rewrite an already evaluated computation.
"""

_PRIVATE_REDLINE_REPAIR_SYSTEM = f"""\
Repair one rejected proxy formula core after private pre-publication review.
Return the complete existing formula-core shape, not a patch and not a review.
Resolve every supplied red-line reason while preserving fields that the reasons
do not invalidate.

The supplied target_metric is the only target authority. The public field name
`expected_final_kpi_link` is retained for backward compatibility, but its value
must describe the direct scientific link between the formula and this current
target. When target_kind is auxiliary_condition, do not replace that condition
with a downstream final KPI and do not use a possible downstream benefit as the
field's answer. Explain how formula movement represents better or worse
satisfaction of target_metric.scientific_meaning itself.

{_RELATION_DIRECTION_GUIDE}

{_TARGET_SATISFACTION_GUIDE}

{SCIENTIFIC_CLAIM_CALIBRATION_GUIDE}

Use first_principles_basis and formal_scientific_context as nonbinding scientific
context. historical_grounding supplies this stage's selected quantities and
declared source boundaries; exact source definitions remain evidence authority.
Use only names in historical_grounding.grounded_quantities
and keep their source paths, calculation methods, and visible variation intact.
If a red-line reason identifies a mathematical direction conflict, follow the
formula numerically and repair the expression, expected_relation, or scientific
link as needed so they agree. Do not invent a quantitative transfer function,
calibration constant, ideal reference, or new evidence merely to silence the
review. Do not calculate per-record values or broaden the claim. Return only the
repaired formula core.
"""

MATERIALIZER_CAPABILITY = (
    Path(__file__).resolve().parents[3]
    / "skills/final-kpi-proxy-discovery/references/implementation-capability.md"
).read_text(encoding="utf-8")


def develop_proxy_formula(
    runtime: Any,
    *,
    target_metric: Mapping[str, Any],
    formal_scientific_context: Sequence[Mapping[str, Any]],
    first_principles_scientific_context: Sequence[Mapping[str, Any]] | None = None,
    source_manifest: Mapping[str, Any],
    sanitized_historical_data: Mapping[str, Any],
    source_background: Mapping[str, Any] | None = None,
    source_inspection: SourceInspection | None = None,
    authorized_task_data: Mapping[str, Any] | None = None,
    evaluated_formula_history: Sequence[Mapping[str, Any]] = (),
    first_principles_formula_history: Sequence[Mapping[str, Any]] | None = None,
    research_mode: Mapping[str, Any] | None = None,
    validate_formula_core: FormulaValidator,
    validate_formula_candidate: FormulaValidator,
    purpose_prefix: str = "draft-proxy",
) -> dict[str, Any]:
    """Run the reusable P1-P4 proxy-discovery route.

    The route owns only bounded discovery and local repair. Its caller owns
    artifact identity, versioning, deduplication, publication, and readback.
    """

    target_kind = str(target_metric.get("target_kind") or "").strip()
    target_id = str(target_metric.get("target_id") or "").strip()
    if target_kind not in {"final_kpi", "auxiliary_condition"}:
        raise ValueError(f"proxy_target_kind_invalid:{target_kind}")
    if not target_id:
        raise ValueError("proxy_target_id_required")

    compact_formal_context = _formal_scientific_context_projection(
        formal_scientific_context
    )
    compact_first_principles_context = _formal_scientific_context_projection(
        first_principles_scientific_context
        if first_principles_scientific_context is not None
        else formal_scientific_context
    )
    first_principles_history = (
        list(first_principles_formula_history)
        if first_principles_formula_history is not None
        else list(evaluated_formula_history)
    )
    first_principles_payload: dict[str, Any] = {
        "target_metric": dict(target_metric),
        "formal_scientific_context": compact_first_principles_context,
    }
    if research_mode:
        first_principles_payload["research_mode"] = dict(research_mode)
    if first_principles_history:
        first_principles_payload["evaluated_formula_history"] = [
            dict(item) for item in first_principles_history
        ]
    first_principles = _generate_stage(
        runtime,
        system_prompt=f"""\
Reason from the supplied target's scientific meaning and formal scientific
context only. Propose several physically meaningful quantities that could
cheaply track the target trend. You are deliberately not seeing historical
records in this step. Do not draft the final formula and do not assume a
quantity already exists as a column. A quantity may later be computed from a
molecular representation.

Shared scientific assets and evaluated formula history are prior research for
inspiration and differentiation, not constraints on what first-principles
quantities may be proposed. You may extend, challenge, or depart from them.
Honor research_mode as a caller-owned visibility policy. In explore mode, any
shared assets absent here are deliberately withheld for an independent P1;
do not reconstruct them. They return before formula composition.
When the formal context contains an explicit `hypothesis_evidence_support`
objective, use it to trace the hypothesis claim through its difficult physical
quantity to a faithful low-cost substitute, its relation to the original
mechanism, its expected final-target linkage, and its failure boundary. This is
an evidence objective, not authority to force an unsupported quantity.

{SCIENTIFIC_CLAIM_CALIBRATION_GUIDE}
""",
        user_payload=first_principles_payload,
        purpose="first-principles-quantity-basis",
        schema=_FIRST_PRINCIPLES_SCHEMA,
    )
    materializer_capability = (
        MATERIALIZER_CAPABILITY + "\n\n"
        + runtime.describe_execution_capability("materializer")
    )
    historical_payload: dict[str, Any] = {
        "target_metric": dict(target_metric),
        "formal_scientific_context": [
            item for item in compact_formal_context
            if item.get("artifact_kind") == "task_spec"
        ],
        "first_principles_candidates": first_principles,
        "source_manifest": dict(source_manifest),
        "sanitized_historical_data": dict(sanitized_historical_data),
        "source_path_catalog": _source_path_catalog(sanitized_historical_data),
        "materializer_capability": materializer_capability,
        "source_authority_note": (
            "This route input, not background literature coverage, determines "
            "whether historical records exist."
        ),
    }
    if source_background:
        historical_payload["direct_source_background"] = dict(source_background)
    if authorized_task_data:
        historical_payload["authorized_task_data"] = dict(authorized_task_data)
    if evaluated_formula_history:
        historical_payload["evaluated_formula_history"] = [
            dict(item) for item in evaluated_formula_history
        ]
    inspection_prompt = """\
Use the supplied read-only source tools when relevant definitions, structures,
units or process conditions are referenced but not present here. Start from the
exact refs in source_transport_metadata or locate task-named files with targeted
source_inventory/source_search. Read relevant pages and follow next_line_offset
as needed before declaring their contents unavailable. This is source inspection,
not new data preparation. The host retains successful source_read pages through
authoring, review and publication provenance; do not retype them as tool output.
""" if source_inspection is not None else ""
    historical_system_prompt = f"""\
{inspection_prompt}
Use the supplied first-principles ideas as scientific motivation, then build a
grounded set from the actual sanitized records and the stated implementation
capability. Every source path must exist on every supplied record. Its stored
content together with explicitly read source definitions must support the
proposed calculation. A method label,
provenance string, or prose description is not the measurement result itself.
The entity represented by a source field must match the entity whose property is
being proposed. Do not use a candidate sample representation as if it were a
fixed precursor, substrate, environment, or other named entity. Do not import a
"known" entity that is absent from the authoritative input.
You may replace an unavailable first-principles quantity with a
cheap objective descriptor that tracks the same mechanism. Identify quantities
with a clear scientific meaning and at least one plausible faithful low-cost
computational route. For each quantity, put a lower_snake_case Python identifier
in `name`, its human-readable scientific label and definition in `meaning`,
and exact downstream-executable record paths in `source_inputs`. This stage
grounds primitive quantities only. If a scientific idea is a ratio, difference,
weighted sum, or other deterministic combination, ground its directly
record-computable component quantities separately; the later formula-composition
stage owns the combination. Never put another grounded quantity name in
`source_inputs`. The supplied source_path_catalog lists retrievable stored paths
and their value shapes;
choose paths from that catalog rather than inventing descendants. Dot paths
traverse objects only and do not implicitly map over arrays. When a stored
value is an array of objects, bind the array path itself in `source_inputs`
and describe iteration over item fields in `calculation_method`. For example,
if `record.metadata.fragments` is an array whose items contain `smiles`, use
`record.metadata.fragments`, not `record.metadata.fragments.smiles`.
Narrative fields may support scientific interpretation but must not be listed as
`source_inputs` when the stated Materializer capability excludes them. Use
paths beginning with `record.`, such as `record.metadata.smiles`. Bookkeeping
`record.id` and narrative `record.input_description` paths are not executable
scientific inputs. Absence of a
precomputed numeric column is not a gap when a visible representation can
support a calculation. Give the method at the level a teacher would hand to an
implementer: name the scientific invariant and a plausible route, but do not
write executable code or pretend to settle every implementation choice. A
package name alone is not a method. Define the physical concept, its relationship
to the visible source, and at least one plausible low-cost route. You may leave
the concrete approximation, regime, exponent, reference scale, structural
surrogate, or transparent numeric mapping for Materializer to select and audit;
do not falsely claim that one such choice is uniquely established. Materializer
owns operationalization, while this stage owns the scientific meaning and source
relationship.
Exclude quantities for which every plausible method needs unavailable or
forbidden inputs, undeclared fitted constants, or violates the task's compute
constraints. Follow materializer_capability instead of assuming that a numerical
engine is unavailable or that a prebuilt Route is required. Do not draft the
final formula yet. Describe only raw record variation that is observable without
executing the proposed calculation method; label fixed process values as constant
rather than evidence of variation.

Distinguish an input missing from the selected execution table from scientific
information absent from an inspected source. A richer background table or source
document can explain a missing distinction, but does not silently replace the
selected execution table or create a new record path. In `historical_summary`
and `excluded_quantities`, identify the selected table and its ref, missing
scientific inputs, and the exact sources/pages actually read. An unread or
incompletely inspected source is not proof that information does not exist.
Your primary responsibility is to find useful calculable quantities, not only
to reject P1 suggestions. Before concluding none are suitable, consider what
can be derived from the available representations and source definitions using
the disclosed computation capability, including a defensible approximation or
alternative quantity for the same objective. Read relevant available definitions
when they can resolve a specific uncertainty. A missing precomputed column,
missing prebuilt function or Route, one failed P1 idea, or non-unique numerical
implementation is not by itself a reason to return no quantity. You need a
plausible faithful method, not completed code or a guaranteed calculation result.
If that investigation still leaves no suitable quantity, return
`grounded_quantities: []`. Explain in the existing summary/exclusions the
specific scientific input or constraint that prevents calculation, the relevant
evidence actually inspected, and why the plausible alternatives considered do
not resolve it. State inspection limits honestly; do not claim an exhaustive
search or spend the entire read quota as a ritual. The skill then returns
bounded_gap without composing or publishing a formula. Do not fabricate a
substitute merely to fill the array or prescribe a subsequent skill. When
suitable quantities exist, retain them even if other P1 ideas are unavailable;
not every P1 idea must survive.

For `visible_variation`, report only variation directly visible in the supplied
records. You may quote literal stored values or describe qualitative differences
in the source representations. Never calculate, estimate, or report per-record
derived descriptor values, ratios, formula components, or proxy outputs. If the
variation of a grounded quantity can be known only by executing its
`calculation_method`, state only that the required source representations vary
and defer all derived values to Materializer. For `expected_effect_on_target`,
state a calibrated scientific expectation rather than presenting a confounded
comparison as an isolated effect.

{SCIENTIFIC_CLAIM_CALIBRATION_GUIDE}
"""
    historical_grounding = _generate_stage(
        runtime,
        system_prompt=historical_system_prompt,
        user_payload=historical_payload,
        purpose="historical-source-grounding",
        schema=_HISTORICAL_GROUNDING_SCHEMA,
        scientific_call=True,
        source_inspection=source_inspection,
    )
    grounding_issues = _historical_grounding_issues(
        historical_grounding,
        sanitized_historical_data,
    )
    if grounding_issues:
        historical_grounding = _generate_stage(
            runtime,
            system_prompt=(
                historical_system_prompt
                + "\nRepair every listed structural grounding issue. The "
                + "`name` field is the lower_snake_case Python symbol used by "
                + "the later formula; the human-readable label belongs in "
                + "`meaning`. Preserve the scientific intent, but do not "
                + "preserve an invalid derived quantity as a record source: "
                + "replace it with its directly record-computable primitive "
                + "quantities and leave their combination to the formula "
                + "stage. Return the complete grounded set, including an empty "
                + "set when no suitable quantity remains under the same contract."
            ),
            user_payload={
                **historical_payload,
                "validator_issues": grounding_issues,
                "rejected_historical_grounding": historical_grounding,
            },
            purpose="repair-historical-source-grounding",
            schema=_HISTORICAL_GROUNDING_SCHEMA,
            repair_call=True,
            source_inspection=source_inspection,
        )
    remaining_grounding_issues = _historical_grounding_issues(
        historical_grounding,
        sanitized_historical_data,
    )
    if remaining_grounding_issues:
        raise ValueError(
            "historical_source_grounding_invalid_after_local_repair:"
            + "; ".join(remaining_grounding_issues)
        )
    if historical_grounding["grounded_quantities"] == []:
        raise ProxySourceGroundingGap(
            "No suitable source-grounded quantity for this invocation. "
            + json.dumps(
                {
                    "historical_summary": historical_grounding["historical_summary"],
                    "excluded_quantities": historical_grounding["excluded_quantities"],
                },
                ensure_ascii=False,
            )
        )

    formula_context: dict[str, Any] = {
        "materializer_capability": materializer_capability,
        "target_metric": dict(target_metric),
        "formal_scientific_context": compact_formal_context,
        "first_principles_basis": first_principles,
        "historical_grounding": historical_grounding,
        "sanitized_source_shape": _source_path_catalog(
            sanitized_historical_data
        ),
    }
    if source_background:
        formula_context["direct_source_background"] = dict(source_background)
    if authorized_task_data:
        formula_context["authorized_task_data"] = dict(authorized_task_data)
    if research_mode:
        formula_context["research_mode"] = dict(research_mode)
    if evaluated_formula_history:
        formula_context["evaluated_formula_history"] = [
            dict(item) for item in evaluated_formula_history
        ]
    return _generate_complete_candidate(
        runtime,
        context=formula_context,
        purpose_prefix=purpose_prefix,
        validate_formula_core=validate_formula_core,
        validate_formula_candidate=validate_formula_candidate,
    )


def _generate_complete_candidate(
    runtime: Any,
    *,
    context: Mapping[str, Any],
    purpose_prefix: str,
    validate_formula_core: FormulaValidator,
    validate_formula_candidate: FormulaValidator,
) -> dict[str, Any]:
    core = _generate_stage(
        runtime,
        system_prompt=_DRAFT_SYSTEM,
        user_payload=_formula_authoring_context(context),
        purpose=f"{purpose_prefix}-formula-core",
        schema=_FORMULA_CORE_SCHEMA,
        scientific_call=True,
    )
    core = _apply_target_authority(core, context.get("target_metric"))
    core = _apply_grounding_authority(
        core,
        context.get("historical_grounding"),
    )
    core_issues = [
        *validate_formula_core(core),
        *_formula_grounding_issues(core, context.get("historical_grounding")),
    ]
    if core_issues:
        core = _generate_stage(
            runtime,
            system_prompt=_core_repair_system_prompt(core_issues),
            user_payload={
                "validator_issues": core_issues,
                "rejected_formula_core": _generation_formula_core(core),
                "authoritative_context": _formula_core_repair_context(context),
            },
            purpose=f"repair-{purpose_prefix}-formula-core",
            schema=_FORMULA_CORE_SCHEMA,
            repair_call=True,
        )
        core = _apply_target_authority(core, context.get("target_metric"))
        core = _apply_grounding_authority(
            core,
            context.get("historical_grounding"),
        )
    remaining_core_issues = [
        *validate_formula_core(core),
        *_formula_grounding_issues(core, context.get("historical_grounding")),
    ]
    if remaining_core_issues:
        raise ValueError(
            "proxy_formula_core_invalid_after_local_repair:"
            + "; ".join(remaining_core_issues)
        )

    candidate = _candidate_from_core(
        core,
        context.get("historical_grounding"),
        validate_formula_candidate,
    )
    candidate = deepen_proxy_formula_explanation(
        runtime,
        candidate=candidate,
        source_background=context.get("direct_source_background"),
        authorized_task_data=context.get("authorized_task_data"),
        materializer_capability=context.get("materializer_capability"),
        shared_research_assets=[
            dict(item)
            for item in [
                *(context.get("formal_scientific_context") or []),
                *(context.get("evaluated_formula_history") or []),
            ]
            if isinstance(item, Mapping)
        ],
        historical_grounding=(
            dict(context["historical_grounding"])
            if isinstance(context.get("historical_grounding"), Mapping)
            else {}
        ),
        validate_candidate=validate_formula_candidate,
        purpose_prefix=purpose_prefix,
    )
    reviews = _review_formula_candidate(
        runtime,
        candidate=candidate,
        context=context,
        purpose_prefix=purpose_prefix,
    )
    redlines = _private_redline_reasons(reviews)
    if not redlines:
        return candidate

    repaired_core = _generate_stage(
        runtime,
        system_prompt=_PRIVATE_REDLINE_REPAIR_SYSTEM,
        user_payload={
            "redline_review_reasons": redlines,
            "rejected_formula_core": _generation_formula_core(core),
            "authoritative_context": _private_redline_repair_context(context),
        },
        purpose=f"repair-{purpose_prefix}-private-redline",
        schema=_FORMULA_CORE_SCHEMA,
        repair_call=True,
    )
    repaired_core = _apply_target_authority(
        repaired_core,
        context.get("target_metric"),
    )
    repaired_core = {
        **dict(repaired_core),
        "formula_id": core.get("formula_id"),
        "version": core.get("version"),
    }
    repaired_core = _apply_grounding_authority(
        repaired_core,
        context.get("historical_grounding"),
    )
    repaired_issues = [
        *validate_formula_core(repaired_core),
        *_formula_grounding_issues(
            repaired_core, context.get("historical_grounding")
        ),
    ]
    if repaired_issues:
        raise ValueError(
            "proxy_formula_redline_repair_invalid:"
            + "; ".join(repaired_issues)
        )
    repaired_candidate = _candidate_from_core(
        repaired_core,
        context.get("historical_grounding"),
        validate_formula_candidate,
    )
    repaired_candidate = deepen_proxy_formula_explanation(
        runtime,
        candidate=repaired_candidate,
        source_background=context.get("direct_source_background"),
        authorized_task_data=context.get("authorized_task_data"),
        materializer_capability=context.get("materializer_capability"),
        shared_research_assets=[
            dict(item)
            for item in [
                *(context.get("formal_scientific_context") or []),
                *(context.get("evaluated_formula_history") or []),
            ]
            if isinstance(item, Mapping)
        ],
        historical_grounding=(
            dict(context["historical_grounding"])
            if isinstance(context.get("historical_grounding"), Mapping)
            else {}
        ),
        validate_candidate=validate_formula_candidate,
        purpose_prefix=f"repair-{purpose_prefix}",
    )
    repeated_reviews = _review_formula_candidate(
        runtime,
        candidate=repaired_candidate,
        context=context,
        purpose_prefix=f"recheck-{purpose_prefix}",
    )
    repeated_redlines = _private_redline_reasons(repeated_reviews)
    if repeated_redlines:
        raise ValueError(
            "proxy_formula_private_redline_after_local_repair:"
            + "; ".join(repeated_redlines)
        )
    return repaired_candidate


def _candidate_from_core(
    core: Mapping[str, Any],
    historical_grounding: Any,
    validate_formula_candidate: FormulaValidator,
) -> dict[str, Any]:
    contract = _materialization_contract_from_grounding(
        core,
        historical_grounding,
    )
    candidate = {**dict(core), "materialization_contract": contract}
    issues = validate_formula_candidate(candidate)
    if issues:
        raise ValueError(
            "proxy_formula_invalid_after_local_workflow:"
            + "; ".join(issues)
        )
    return candidate


def _review_formula_candidate(
    runtime: Any,
    *,
    candidate: Mapping[str, Any],
    context: Mapping[str, Any],
    purpose_prefix: str,
) -> list[dict[str, Any]]:
    relationship_candidate = {
        key: candidate.get(key)
        for key in (
            "target_kind",
            "target_id",
            "formula_expression",
            "input_variables",
            "expected_relation",
            "claim_boundary",
            "historical_variation_evidence",
            "side_effect_notes",
        )
    }
    relationship_candidate["declared_target_link"] = candidate.get(
        "expected_final_kpi_link"
    )
    operationalization_candidate = {
        key: candidate.get(key)
        for key in (
            "target_kind",
            "target_id",
            "formula_expression",
            "input_variables",
            "source_binding",
            "materialization_contract",
            "claim_boundary",
        )
    }
    observability_candidate = {
        key: candidate.get(key)
        for key in (
            "target_kind",
            "target_id",
            "formula_expression",
            "expected_final_kpi_link",
            "expected_relation",
            "claim_boundary",
            "validation_criteria",
            "side_effect_notes",
            "input_variables",
            "source_binding",
            "historical_variation_evidence",
        )
    }
    review_specs = (
        (
            "scientific-relationship",
            _RELATIONSHIP_REVIEW_SYSTEM,
            {
                "target_metric": context.get("target_metric"),
                "formal_scientific_context": context.get(
                    "formal_scientific_context"
                ),
                "historical_grounding": context.get("historical_grounding"),
                "candidate": relationship_candidate,
            },
            False,
        ),
        (
            "operationalization",
            _OPERATIONALIZATION_REVIEW_SYSTEM,
            {
                "candidate": operationalization_candidate,
                "historical_grounding": context.get("historical_grounding"),
                "sanitized_source_shape": context.get("sanitized_source_shape"),
                "materializer_capability": context["materializer_capability"],
            },
            True,
        ),
        (
            "observability",
            _OBSERVABILITY_REVIEW_SYSTEM,
            {
                "target_metric": context.get("target_metric"),
                "candidate": observability_candidate,
                "historical_grounding": context.get("historical_grounding"),
                "sanitized_source_shape": context.get("sanitized_source_shape"),
            },
            False,
        ),
    )
    reviews: list[dict[str, Any]] = []
    for dimension, system_prompt, user_payload, scientific_call in review_specs:
        if context.get("direct_source_background"):
            user_payload["direct_source_background"] = context["direct_source_background"]
        if context.get("authorized_task_data"):
            user_payload["authorized_task_data"] = context["authorized_task_data"]
        result = _generate_stage(
            runtime,
            system_prompt=system_prompt,
            user_payload=user_payload,
            purpose=f"{purpose_prefix}-{dimension}-review",
            schema=_PRIVATE_REVIEW_SCHEMA,
            scientific_call=scientific_call,
        )
        reviews.append({"dimension": dimension, **result})
    return reviews


def _private_redline_reasons(
    reviews: Sequence[Mapping[str, Any]],
) -> list[str]:
    return [
        f"{review.get('dimension')}:{review.get('reason')}"
        for review in reviews
        if review.get("score") == 0
    ]


def _historical_grounding_issues(
    historical_grounding: Mapping[str, Any],
    sanitized_historical_data: Mapping[str, Any],
) -> list[str]:
    issues: list[str] = []
    seen: set[str] = set()
    records = [
        item
        for item in sanitized_historical_data.get("records") or []
        if isinstance(item, Mapping)
    ]
    for index, item in enumerate(
        historical_grounding.get("grounded_quantities") or []
    ):
        if not isinstance(item, Mapping):
            issues.append(f"grounded_quantity_must_be_object:{index}")
            continue
        name = str(item.get("name") or "").strip()
        if not name.isidentifier():
            issues.append(f"grounded_quantity_name_invalid:{index}:{name}")
        elif name in seen:
            issues.append(f"grounded_quantity_name_duplicate:{name}")
        else:
            seen.add(name)
        source_inputs = item.get("source_inputs")
        if not isinstance(source_inputs, list) or not source_inputs:
            issues.append(f"grounded_source_inputs_required:{name or index}")
        elif any(
            not isinstance(path, str) or not path.startswith("record.")
            for path in source_inputs
        ):
            issues.append(
                f"grounded_source_paths_must_start_with_record:{name or index}"
            )
        else:
            for source_path in source_inputs:
                if source_path == "record.id" or source_path.startswith(
                    "record.input_description"
                ):
                    issues.append(
                        "grounded_source_path_not_executable:"
                        f"{name or index}:{source_path}"
                    )
                    continue
                path_failures = [
                    _record_path_failure(record, source_path)
                    for record in records
                ]
                collection_paths = sorted(
                    {
                        detail
                        for kind, detail in path_failures
                        if kind == "collection" and detail
                    }
                )
                if collection_paths:
                    issues.append(
                        "grounded_source_path_descends_through_collection:"
                        f"{name or index}:{source_path}:"
                        f"bind_collection={collection_paths[0]}"
                    )
                elif records and any(
                    kind != "" for kind, _detail in path_failures
                ):
                    issues.append(
                        "grounded_source_path_missing_from_records:"
                        f"{name or index}:{source_path}"
                    )
    return issues


def _record_path_failure(
    record: Mapping[str, Any],
    source_path: str,
) -> tuple[str, str]:
    parts = source_path.split(".")
    if not parts or parts[0] != "record":
        return "missing", ""
    value: Any = record
    traversed = ["record"]
    for part in parts[1:]:
        if isinstance(value, list):
            return "collection", ".".join(traversed)
        if not isinstance(value, Mapping) or part not in value:
            return "missing", ".".join(traversed)
        value = value[part]
        traversed.append(part)
    return "", ""


def _apply_grounding_authority(
    core: Mapping[str, Any],
    historical_grounding: Any,
) -> dict[str, Any]:
    result = dict(core)
    grounded = _grounded_by_name(historical_grounding)
    names = [
        str(value).strip()
        for value in result.get("selected_candidate_proxy_quantity_refs") or []
    ]
    result["input_variables"] = [
        {
            "name": name,
            "meaning": str(grounded.get(name, {}).get("meaning") or "").strip(),
        }
        for name in names
    ]
    result["source_binding"] = {
        name: {
            "source_inputs": list(grounded[name].get("source_inputs") or []),
            "calculation_method": str(
                grounded[name].get("calculation_method") or ""
            ).strip(),
        }
        for name in names
        if name in grounded
    }
    result["historical_variation_evidence"] = [
        {
            "quantity": name,
            "evidence": str(
                grounded[name].get("visible_variation") or ""
            ).strip(),
        }
        for name in names
        if name in grounded
    ]
    return result


def _apply_target_authority(
    core: Mapping[str, Any],
    target_metric: Any,
) -> dict[str, Any]:
    if not isinstance(target_metric, Mapping):
        raise ValueError("proxy_target_metric_required")
    target_kind = str(target_metric.get("target_kind") or "").strip()
    target_id = str(target_metric.get("target_id") or "").strip()
    if target_kind not in {"final_kpi", "auxiliary_condition"}:
        raise ValueError(f"proxy_target_kind_invalid:{target_kind}")
    if not target_id:
        raise ValueError("proxy_target_id_required")
    result = dict(core)
    result["target_kind"] = target_kind
    result["target_id"] = target_id
    return result


def _formula_grounding_issues(
    core: Mapping[str, Any],
    historical_grounding: Any,
) -> list[str]:
    grounded = _grounded_by_name(historical_grounding)
    names = [
        str(item.get("name") or "").strip()
        for item in core.get("input_variables") or []
        if isinstance(item, Mapping)
    ]
    issues: list[str] = []
    for name in names:
        item = grounded.get(name)
        if item is None:
            issues.append(f"formula_variable_not_historically_grounded:{name}")
            continue
        source_inputs = item.get("source_inputs")
        if not isinstance(source_inputs, list) or not source_inputs:
            issues.append(f"grounded_source_inputs_required:{name}")
        elif any(
            not isinstance(path, str) or not path.startswith("record.")
            for path in source_inputs
        ):
            issues.append(f"grounded_source_paths_must_start_with_record:{name}")
        if not str(item.get("calculation_method") or "").strip():
            issues.append(f"grounded_calculation_method_required:{name}")
    return issues


def _materialization_contract_from_grounding(
    core: Mapping[str, Any],
    historical_grounding: Any,
) -> dict[str, Any]:
    grounded = _grounded_by_name(historical_grounding)
    names = [
        str(item.get("name") or "").strip()
        for item in core.get("input_variables") or []
        if isinstance(item, Mapping)
    ]
    candidate_contracts: dict[str, Any] = {}
    for name in names:
        item = grounded.get(name)
        if item is None:
            raise ValueError(f"formula_variable_not_historically_grounded:{name}")
        candidate_contracts[name] = {
            "required_inputs": list(item.get("source_inputs") or []),
            "algorithmic_steps": [str(item.get("calculation_method") or "").strip()],
            "missing_value_policy": (
                "Do not guess. If faithful visible-source derivation still cannot "
                "resolve this component, return a materialization gap "
                "instead of a partial successful result."
            ),
            "external_data_or_measurement_required": False,
        }
    return {
        "inputs": names,
        "formula_expression": str(core.get("formula_expression") or "").strip(),
        "output": {"name": "proxy_formula_value", "type": "numeric"},
        "candidate_contracts": candidate_contracts,
        "missing_value_policy": (
            "Do not guess missing values. Complete materialization requires every "
            "formula component for every record; otherwise return a structured "
            "materialization gap with the exact missing authoritative input."
        ),
    }


def _grounded_by_name(
    historical_grounding: Any,
) -> dict[str, Mapping[str, Any]]:
    if not isinstance(historical_grounding, Mapping):
        return {}
    result: dict[str, Mapping[str, Any]] = {}
    for item in historical_grounding.get("grounded_quantities") or []:
        if not isinstance(item, Mapping):
            continue
        name = str(item.get("name") or "").strip()
        if name:
            result[name] = item
    return result


def _core_repair_system_prompt(issues: Sequence[str]) -> str:
    prompt = (
        _DRAFT_SYSTEM
        + "\nRepair every listed issue and return the complete formula core, "
        + "not a patch. Preserve valid scientific grounding."
    )
    if any(
        str(issue).startswith("formula_duplicates_evaluated_history")
        for issue in issues
    ):
        prompt += (
            "\nThe structural validator found that the rejected formula is "
            "the same operational computation as an evaluated formula. Keep "
            "the target and valid grounded quantities, but produce a "
            "scientifically justified alternative computation. Changing only "
            "parentheses, names, version, or an overall scalar does not make "
            "a new challenger. Use the ranked evaluated history to change the "
            "selected quantity set or their functional relationship in a way "
            "that tests a distinct mechanistic idea."
        )
    return prompt


def _generation_formula_core(core: Mapping[str, Any]) -> dict[str, Any]:
    allowed = set(_FORMULA_CORE_SCHEMA["properties"])
    return {key: value for key, value in core.items() if key in allowed}


def _formula_authoring_context(
    context: Mapping[str, Any],
) -> dict[str, Any]:
    return _selected_context_fields(
        context,
        (
            "materializer_capability",
            "target_metric",
            "formal_scientific_context",
            "first_principles_basis",
            "historical_grounding",
            "evaluated_formula_history",
            "research_mode",
            "direct_source_background",
            "authorized_task_data",
        ),
    )


def _formula_core_repair_context(
    context: Mapping[str, Any],
) -> dict[str, Any]:
    return _formula_authoring_context(context)


def _private_redline_repair_context(
    context: Mapping[str, Any],
) -> dict[str, Any]:
    return _formula_authoring_context(context)


def _selected_context_fields(
    context: Mapping[str, Any],
    fields: Sequence[str],
) -> dict[str, Any]:
    return {
        field: context[field]
        for field in fields
        if field in context and context[field] not in (None, "", [], {})
    }


def _formal_scientific_context_projection(
    items: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    return [_formal_context_item_projection(item) for item in items]


def _formal_context_item_projection(item: Mapping[str, Any]) -> dict[str, Any]:
    context_role = str(item.get("context_role") or "").strip()
    if context_role == "hypothesis_evidence_support":
        hypothesis = item.get("hypothesis")
        findings = item.get("quality_findings")
        return {
            "context_role": context_role,
            "hypothesis": (
                _formal_context_item_projection(hypothesis)
                if isinstance(hypothesis, Mapping)
                else {}
            ),
            "quality_findings": [
                _formal_context_item_projection(finding)
                for finding in findings or []
                if isinstance(finding, Mapping)
            ],
            "reasoning_objective": str(
                item.get("reasoning_objective") or ""
            ).strip(),
        }

    artifact_kind = str(item.get("artifact_kind") or "").strip()
    payload = item.get("machine_payload")
    if not isinstance(payload, Mapping):
        payload = item
    projected_payload = _scientific_payload_projection(
        artifact_kind,
        payload,
    )
    result: dict[str, Any] = {
        "artifact_ref": item.get("artifact_ref"),
        "artifact_kind": artifact_kind,
    }
    if projected_payload:
        result["machine_payload"] = projected_payload
    elif str(item.get("summary") or "").strip():
        result["summary"] = str(item["summary"]).strip()
    return result


def _scientific_payload_projection(
    artifact_kind: str,
    payload: Mapping[str, Any],
) -> dict[str, Any]:
    if artifact_kind == "task_spec":
        return _selected_context_fields(
            payload,
            (
                "artifact_kind",
                "id",
                "goal",
                "constraints",
                "constraint_registry",
                "evaluation_priority",
                "output_format",
                "iteration_limit",
                "mind_map_taxonomy",
            ),
        )
    if artifact_kind == "hypothesis_mind_map":
        landscape = payload.get("mechanism_landscape")
        landscape = landscape if isinstance(landscape, Mapping) else payload
        compact_landscape = _mind_map_landscape_projection(landscape)
        return {
            "artifact_kind": payload.get(
                "artifact_kind",
                "hypothesis_mind_map",
            ),
            "mechanism_landscape": compact_landscape,
        }
    if artifact_kind == "hypothesis":
        return _selected_context_fields(
            payload,
            (
                "artifact_kind",
                "id",
                "task_id",
                "title",
                "description",
                "mechanism",
                "core_claim",
                "risks",
                "verification_plan",
                "direction_card",
            ),
        )
    if artifact_kind == "hypothesis_leaderboard":
        return _selected_context_fields(
            payload,
            ("artifact_kind", "version", "ranked_entries"),
        )
    if artifact_kind == "scientific_method_review":
        return _selected_context_fields(
            payload,
            (
                "artifact_kind",
                "version",
                "method_artifact_ref",
                "review_score",
                "reason",
            ),
        )
    if artifact_kind == "final_lca_judgment":
        return _selected_context_fields(
            payload,
            ("artifact_kind", "final_lca_judgment"),
        )
    return _selected_context_fields(
        payload,
        (
            "artifact_kind",
            "id",
            "title",
            "description",
            "scientific_meaning",
            "reason",
        ),
    )


def _mind_map_landscape_projection(
    landscape: Mapping[str, Any],
) -> dict[str, Any]:
    raw_families = landscape.get("families")
    families = [
        _selected_context_fields(
            family,
            (
                "family_id",
                "title",
                "causal_role",
                "core_mechanism",
                "mechanism_chain",
                "interaction_motif",
                "scope_mode",
                "key_prerequisites",
                "main_bottleneck",
                "expected_failure_mode",
                "viability_band",
                "tension_ids",
                "tension_strategy",
            ),
        )
        for family in raw_families or []
        if isinstance(family, Mapping)
    ]
    result = _selected_context_fields(
        landscape,
        (
            "mechanism_landscape_summary",
            "landscape_summary",
            "supported_relationships",
            "unresolved_gaps",
            "evidence_boundary_summary",
        ),
    )
    if families:
        result["families"] = families
    return result


def _source_path_catalog(source: Mapping[str, Any]) -> list[dict[str, Any]]:
    records = [
        item
        for item in source.get("records") or []
        if isinstance(item, Mapping)
    ]
    if not records:
        return []
    paths_by_record = [_record_stored_paths(record) for record in records]
    common_paths = set(paths_by_record[0])
    for paths in paths_by_record[1:]:
        common_paths.intersection_update(paths)
    catalog: list[dict[str, Any]] = []
    for path in sorted(common_paths):
        values = [paths[path] for paths in paths_by_record]
        entry: dict[str, Any] = {
            "path": path,
            "value_types": sorted({_json_value_type(value) for value in values}),
        }
        items = [
            item
            for value in values
            if isinstance(value, list)
            for item in value
        ]
        if items:
            entry["array_item_types"] = sorted(
                {_json_value_type(item) for item in items}
            )
            object_items = [item for item in items if isinstance(item, Mapping)]
            if object_items:
                entry["array_item_fields"] = sorted(
                    {str(key) for item in object_items for key in item}
                )
        catalog.append(entry)
    return catalog


def _record_stored_paths(record: Mapping[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}

    def visit(value: Any, path: str) -> None:
        if path != "record":
            result[path] = value
        if isinstance(value, Mapping):
            for key, child in value.items():
                visit(child, f"{path}.{key}")

    visit(record, "record")
    return result


def _json_value_type(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, Mapping):
        return "object"
    if isinstance(value, list):
        return "array"
    if isinstance(value, (int, float)):
        return "number"
    if isinstance(value, str):
        return "string"
    return type(value).__name__


def _generate_stage(
    runtime: Any,
    *,
    system_prompt: str,
    user_payload: Mapping[str, Any],
    purpose: str,
    schema: Mapping[str, Any],
    repair_call: bool = False,
    scientific_call: bool = False,
    source_inspection: SourceInspection | None = None,
) -> dict[str, Any]:
    inspection_options = {}
    if source_inspection is not None:
        inspection_options = {
            "inspection_routes": source_inspection.routes,
            "inspection_caller": source_inspection.call_route,
        }
    return runtime.generate_json(
        (system_prompt if purpose == "first-principles-quantity-basis"
         else system_prompt + "\n\n" + SOURCE_CONTEXT_GUIDE),
        json.dumps(user_payload, ensure_ascii=False, indent=2),
        purpose=purpose,
        schema=schema,
        repair_call=repair_call,
        scientific_call=scientific_call,
        **inspection_options,
    )
