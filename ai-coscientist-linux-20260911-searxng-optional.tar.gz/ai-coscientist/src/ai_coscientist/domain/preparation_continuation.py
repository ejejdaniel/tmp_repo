"""Exact preparation-run recovery; scientific contract decisions stay in the skill."""

from __future__ import annotations

import json
from typing import Any, Mapping, Sequence

from .prepared_sources import _read_all_pages


def source_bindings(catalog: Mapping[str, Mapping[str, Any]]) -> list[dict[str, str]]:
    return [{"relative_path": path, "source_ref": str(entry["source_ref"])}
            for path, entry in sorted(catalog.items())]


def output_contract(design: Mapping[str, Any], name: str) -> dict[str, Any] | None:
    for raw in design.get("outputs", ()):
        if raw.get("name") == name:
            contract = dict(raw)
            if design.get("evaluation_binding"):
                contract["evaluation_binding"] = dict(design["evaluation_binding"])
            return contract
    return None


def matching_contract(
    prior: Mapping[str, Any], contract: Mapping[str, Any],
    catalog: Mapping[str, Mapping[str, Any]],
) -> bool:
    design = prior.get("preparation_design")
    bindings = prior.get("source_bindings")
    if not isinstance(design, Mapping) or not isinstance(bindings, list):
        return False
    if output_contract(design, str(contract["name"])) != dict(contract):
        return False
    old_sources = {item["relative_path"]: item["source_ref"] for item in bindings}
    return all(path in catalog and old_sources.get(path) == catalog[path]["source_ref"]
               for path in contract["source_paths"])


def restore_probe(
    runtime: Any, manifest_ref: str, *, source_refs: Sequence[str],
) -> tuple[dict[str, Any], str]:
    parts = manifest_ref.split(":")
    if len(parts) != 3 or parts[0] != "source_probe" or not parts[1] or parts[2] != "manifest":
        raise ValueError(f"preparation_run_ref_invalid:{manifest_ref}")
    manifest = json.loads(_read_all_pages(runtime, manifest_ref))
    if not isinstance(manifest, Mapping) or manifest.get("probe_id") != parts[1]:
        raise ValueError(f"preparation_run_identity_mismatch:{manifest_ref}")
    if manifest.get("source_refs") != list(source_refs):
        raise ValueError(
            f"preparation_run_inputs_mismatch:{manifest_ref}:"
            f"expected={list(source_refs)}:actual={manifest.get('source_refs')}"
        )
    prefix = f"source_probe:{parts[1]}:"
    probe = dict(manifest)
    probe.update({f"{key}_ref": prefix + key for key in ("code", "stdout", "stderr", "manifest")})
    code = _read_all_pages(runtime, probe["code_ref"])
    probe["stdout_preview"] = _read_all_pages(runtime, probe["stdout_ref"])
    probe["stderr_preview"] = _read_all_pages(runtime, probe["stderr_ref"])
    return probe, code


def restore_output(
    runtime: Any, prior: Mapping[str, Any], contract: Mapping[str, Any],
    catalog: Mapping[str, Mapping[str, Any]],
    *, dependency_refs: Sequence[str] = (),
) -> dict[str, Any] | None:
    if not matching_contract(prior, contract, catalog):
        return None
    review = prior["reviews_by_name"].get(contract["name"], {})
    transform_ref = review.get("transformation_run_ref")
    validator_ref = review.get("validation_run_ref")
    if not transform_ref:
        return None
    refs = [catalog[path]["source_ref"] for path in contract["source_paths"]]
    if dependency_refs:
        refs = list(dict.fromkeys([*refs, *dependency_refs]))
        manifest = json.loads(_read_all_pages(runtime, transform_ref))
        if not isinstance(manifest, Mapping):
            raise ValueError(f"preparation_run_identity_mismatch:{transform_ref}")
        # A changed/previously unstaged upstream body invalidates this result,
        # even if the dependent output's own source bindings are unchanged.
        if manifest.get("source_refs") != refs:
            return None
    probe, code = restore_probe(runtime, transform_ref, source_refs=refs)
    validation_probe, validator_code = {}, ""
    if validator_ref:
        validation_probe, validator_code = restore_probe(
            runtime, validator_ref, source_refs=[*refs, probe["stdout_ref"]],
        )
    accepted = prior["accepted_outputs"].get(contract["name"])
    if accepted:
        if accepted["content_ref"] != probe["stdout_ref"]:
            raise ValueError(f"preparation_accepted_body_mismatch:{contract['name']}")
        verdict = json.loads(validation_probe.get("stdout_preview") or "null")
        if (probe.get("status") != "source_probe_succeeded"
                or validation_probe.get("status") != "source_probe_succeeded"
                or not isinstance(verdict, Mapping) or verdict.get("accepted") is not True):
            raise ValueError(f"preparation_accepted_verdict_mismatch:{contract['name']}")
    return {"probe": probe, "code": code, "validation_probe": validation_probe,
            "validator_code": validator_code, "accepted_output": accepted}
