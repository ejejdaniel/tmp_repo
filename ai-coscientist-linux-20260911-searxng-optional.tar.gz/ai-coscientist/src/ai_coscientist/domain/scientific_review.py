from __future__ import annotations

import copy
import json
import math
from typing import Any, Mapping, Sequence


_METHOD_KINDS = {"hypothesis", "proxy_formula_candidate"}


def review_scientific_method(
    runtime: Any,
    *,
    method: Mapping[str, Any],
    public_evidence: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Return one non-blocking public-quality score for a stored method."""
    method_kind = str(method.get("artifact_kind") or "")
    method_ref = str(method.get("artifact_ref") or "")
    if method_kind not in _METHOD_KINDS:
        raise ValueError(f"scientific_review_method_kind_invalid:{method_kind}")
    if not method_ref.startswith("artifact:"):
        raise ValueError("scientific_review_method_ref_invalid")

    result = runtime.generate_json(
        _method_review_prompt(method_kind),
        json.dumps(
            {
                "method": _bounded_artifact(method),
                "public_evidence": [
                    _bounded_artifact(item) for item in public_evidence
                ],
                "score_scale": {
                    "minimum": 0,
                    "maximum": 100,
                    "meaning": (
                        "Overall scientific-method quality. This is ranking "
                        "evidence, not a publication gate."
                    ),
                },
            },
            ensure_ascii=False,
            indent=2,
            ),
            purpose=f"review-{method_kind}-method-quality",
            scientific_call=True,
            schema={
            "type": "object",
            "properties": {
                "review_score": {
                    "type": "number",
                    "minimum": 0,
                    "maximum": 100,
                },
                "reason": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 1800,
                },
            },
            "required": ["review_score", "reason"],
            "additionalProperties": False,
        },
    )
    score = _score(result.get("review_score"), "scientific_method_review")
    reason = str(result.get("reason") or "").strip()
    if not reason:
        raise ValueError("scientific_method_review_reason_required")
    return {"review_score": score, "reason": reason}


def review_hypothesis_sample_batch(
    runtime: Any,
    *,
    hypothesis: Mapping[str, Any],
    task: Mapping[str, Any],
    current_iteration_mission: str,
    samples: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Score one bounded comparison batch against one frozen hypothesis."""
    hypothesis_ref = str(hypothesis.get("artifact_ref") or "")
    if hypothesis.get("artifact_kind") != "hypothesis":
        raise ValueError("hypothesis_sample_review_hypothesis_kind_invalid")
    if not hypothesis_ref.startswith("artifact:"):
        raise ValueError("hypothesis_sample_review_hypothesis_ref_invalid")
    sample_rows = [_sample_projection(item) for item in samples]
    sample_ids = [str(item["sample_id"]) for item in sample_rows]
    if not sample_ids or len(set(sample_ids)) != len(sample_ids):
        raise ValueError("hypothesis_sample_review_sample_ids_invalid")

    result = runtime.generate_json(
        _HYPOTHESIS_SAMPLE_REVIEW_PROMPT,
        json.dumps(
            {
                "current_iteration_mission": str(current_iteration_mission),
                "task": _bounded_artifact(task),
                "frozen_hypothesis": _bounded_artifact(hypothesis),
                "comparison_batch": sample_rows,
                "score_scale": {
                    "minimum": 0,
                    "maximum": 100,
                    "meaning": (
                        "How faithfully the concrete sample instantiates the "
                        "frozen hypothesis under the stated task constraints."
                    ),
                },
            },
            ensure_ascii=False,
            indent=2,
            ),
            purpose="review-hypothesis-sample-batch",
            scientific_call=True,
            schema={
            "type": "object",
            "properties": {
                "evaluations": {
                    "type": "array",
                    "minItems": len(sample_ids),
                    "maxItems": len(sample_ids),
                    "items": {
                        "type": "object",
                        "properties": {
                            "sample_id": {
                                "type": "string",
                                "enum": sample_ids,
                            },
                            "score": {
                                "type": "number",
                                "minimum": 0,
                                "maximum": 100,
                            },
                            "reason": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": 1000,
                            },
                        },
                        "required": ["sample_id", "score", "reason"],
                        "additionalProperties": False,
                    },
                }
            },
            "required": ["evaluations"],
            "additionalProperties": False,
        },
    )
    raw_evaluations = result.get("evaluations")
    if not isinstance(raw_evaluations, list):
        raise ValueError("hypothesis_sample_review_evaluations_required")
    evaluations: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in raw_evaluations:
        if not isinstance(raw, Mapping):
            raise ValueError("hypothesis_sample_review_evaluation_invalid")
        sample_id = str(raw.get("sample_id") or "")
        if sample_id not in sample_ids or sample_id in seen:
            raise ValueError(
                f"hypothesis_sample_review_sample_id_invalid:{sample_id}"
            )
        reason = str(raw.get("reason") or "").strip()
        if not reason:
            raise ValueError(
                f"hypothesis_sample_review_reason_required:{sample_id}"
            )
        evaluations.append(
            {
                "sample_id": sample_id,
                "score": _score(
                    raw.get("score"),
                    f"hypothesis_sample_review:{sample_id}",
                ),
                "reason": reason,
            }
        )
        seen.add(sample_id)
    if seen != set(sample_ids):
        raise ValueError(
            "hypothesis_sample_review_coverage_invalid:"
            f"expected={sorted(sample_ids)}:actual={sorted(seen)}"
        )
    order = {sample_id: index for index, sample_id in enumerate(sample_ids)}
    evaluations.sort(key=lambda item: order[str(item["sample_id"])])
    return evaluations


def _method_review_prompt(method_kind: str) -> str:
    if method_kind == "hypothesis":
        focus = (
            "Judge the bounded mechanism, explanatory coherence, falsifiability, "
            "evidence discipline, and usefulness as a research direction."
        )
    else:
        focus = (
            "Judge the formula's scientific plausibility, interpretability, "
            "low-computation character, source binding, and stated applicability "
            "boundary. Do not guess empirical KPI performance."
        )
    return f"""\
You are the shared scientific-method reviewer. Review one already published
method and return one simple 0-100 score with a concise reason.

{focus}

This is a public ranking review, not a red-line gate. Do not reject, repair,
rewrite, or select a next workflow action. Use only the supplied public method
and evidence. Held-out final-KPI values and private trend scores are absent by
design; do not infer or request them. A high score must not claim experimental
or computational support that the supplied artifacts do not contain.

Reserve a score of 100 for a method whose material claims have explicit public
support and whose stated scope has no meaningful remaining evidence gap. In one
concise reason, state the score basis, the strongest remaining evidence gap,
and the type of public evidence that would most improve confidence. Describe
the evidence need without prescribing a workflow route or next skill.
"""


_HYPOTHESIS_SAMPLE_REVIEW_PROMPT = """\
You are the shared scientific reviewer evaluating a bounded batch of concrete
samples for one frozen hypothesis. Score each sample independently from 0 to
100 for how faithfully its explicit representation instantiates the
hypothesis mechanism and core claim while respecting visible task constraints.

Use the hypothesis verification plan as evaluation guidance, not as proof that
an experiment was performed. Judge only properties represented or explicitly
set by the sample. Do not invent missing measurements, infer held-out KPI
values, use absent proxy scores, or rewrite the hypothesis. The scores guide
search within this hypothesis lineage; they do not establish final-KPI
improvement or scientific validation.
"""


def _bounded_artifact(artifact: Mapping[str, Any]) -> dict[str, Any]:
    payload = artifact.get("machine_payload")
    return {
        "artifact_ref": artifact.get("artifact_ref"),
        "artifact_kind": artifact.get("artifact_kind"),
        "title": artifact.get("title"),
        "summary": artifact.get("summary"),
        "machine_payload": dict(payload) if isinstance(payload, Mapping) else {},
    }


def _sample_projection(sample: Mapping[str, Any]) -> dict[str, Any]:
    sample_id = str(sample.get("sample_id") or sample.get("id") or "").strip()
    smiles = str(sample.get("smiles") or "").strip()
    description = str(sample.get("input_description") or "").strip()
    metadata = sample.get("metadata")
    has_metadata = isinstance(metadata, Mapping) and bool(metadata)
    if not sample_id or (not smiles and not description and not has_metadata):
        raise ValueError("hypothesis_sample_review_sample_shape_invalid")
    result = {
        "sample_id": sample_id,
        "is_novel": bool(sample.get("is_novel")),
    }
    if smiles:
        result["smiles"] = smiles
    if description:
        result["input_description"] = description
    if has_metadata:
        result["metadata"] = copy.deepcopy(dict(metadata))
    prior_score = sample.get("proxy_value")
    if isinstance(prior_score, (int, float)) and not isinstance(prior_score, bool):
        prior = float(prior_score)
        if math.isfinite(prior):
            result["prior_fidelity_score"] = prior
    return result


def _score(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label}_score_non_numeric")
    score = float(value)
    if not math.isfinite(score) or not 0.0 <= score <= 100.0:
        raise ValueError(f"{label}_score_out_of_range")
    return round(score, 6)



def validate_scientific_method_review(
    artifact: Mapping[str, Any],
    *,
    expected_method_ref: str | None = None,
) -> dict[str, Any]:
    """Validate and return the approved public scientific-review payload."""
    if artifact.get("artifact_kind") != "scientific_method_review":
        raise ValueError("scientific_method_review_artifact_kind_invalid")
    payload = artifact.get("machine_payload")
    if not isinstance(payload, Mapping):
        raise ValueError("scientific_method_review_payload_required")
    expected_fields = {
        "artifact_kind",
        "version",
        "method_artifact_ref",
        "review_score",
        "reason",
    }
    if set(payload) != expected_fields:
        raise ValueError("scientific_method_review_shape_invalid")
    if payload.get("artifact_kind") != "scientific_method_review":
        raise ValueError("scientific_method_review_payload_kind_invalid")
    method_ref = str(payload.get("method_artifact_ref") or "")
    if not method_ref.startswith("artifact:"):
        raise ValueError("scientific_method_review_method_ref_invalid")
    if expected_method_ref is not None and method_ref != expected_method_ref:
        raise ValueError("scientific_method_review_method_ref_mismatch")
    if method_ref not in {str(ref) for ref in artifact.get("depends_on") or []}:
        raise ValueError("scientific_method_review_dependency_missing")
    version = payload.get("version")
    if isinstance(version, bool) or not isinstance(version, int) or version < 1:
        raise ValueError("scientific_method_review_version_invalid")
    score = _score(payload.get("review_score"), "scientific_method_review")
    reason = str(payload.get("reason") or "").strip()
    if not reason:
        raise ValueError("scientific_method_review_reason_required")
    return {
        "artifact_kind": "scientific_method_review",
        "version": version,
        "method_artifact_ref": method_ref,
        "review_score": score,
        "reason": reason,
    }
