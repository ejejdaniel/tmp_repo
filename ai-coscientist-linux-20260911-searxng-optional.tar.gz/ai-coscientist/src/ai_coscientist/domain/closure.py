from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Mapping

from ai_coscientist.common.artifacts import ArtifactStore
from ai_coscientist.common.observations import ObservationStore
from ai_coscientist.common.routes import Route

from .scientific_review import validate_scientific_method_review
from .source_authority import SourceAuthority


_REQUIRED_KINDS = (
    "task_spec",
    "hypothesis_mind_map",
    "hypothesis",
    "proxy_formula_leaderboard",
    "proxy_formula_candidate",
    "quantitative_proxy_materialization_result",
    "sample_evolution_result",
    "final_lca_judgment",
)
_FORBIDDEN_PRIVATE_KEYS = {
    "ground_truth_kpi",
    "ground_truth_description",
    "avg_score",
    "score_MoO3",
    "score_WO3",
    "substrate_scores",
}


@dataclass
class ScientificWorkflowClosure:
    artifacts: ArtifactStore
    observations: ObservationStore
    source_authority: SourceAuthority | None

    def route(self) -> Route:
        return Route(
            name="scientific_validate_closure",
            description=(
                "Validate formal workflow completeness, dependency lineage, "
                "execution evidence, private-data isolation, and Final-LCA outcome."
            ),
            parameters={
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            handler=lambda _: self.validate(),
            skill_ids=("final-lca",),
        )

    def validate(self) -> dict[str, Any]:
        index = list(self.artifacts.list())
        artifacts = {
            item["artifact_ref"]: self.artifacts.read(item["artifact_ref"])
            for item in index
        }
        order = [item["artifact_ref"] for item in index]
        by_kind: dict[str, list[str]] = {}
        for artifact_ref in order:
            kind = str(artifacts[artifact_ref].get("artifact_kind") or "")
            by_kind.setdefault(kind, []).append(artifact_ref)
        missing = [kind for kind in _REQUIRED_KINDS if not by_kind.get(kind)]

        dangling: list[dict[str, str]] = []
        for artifact_ref, artifact in artifacts.items():
            for dependency_ref in artifact.get("depends_on", []):
                dependency = str(dependency_ref)
                if dependency.startswith("artifact:"):
                    if dependency not in artifacts:
                        dangling.append(
                            {
                                "artifact_ref": artifact_ref,
                                "dependency_ref": dependency,
                            }
                        )
                elif dependency.startswith("execution_observation:"):
                    try:
                        self.observations.read(dependency)
                    except (KeyError, ValueError):
                        dangling.append(
                            {
                                "artifact_ref": artifact_ref,
                                "dependency_ref": dependency,
                            }
                        )

        final_refs = by_kind.get("final_lca_judgment", [])
        final_ref = final_refs[-1] if final_refs else ""
        reachable = _reachable_artifacts(final_ref, artifacts)
        unreachable_required = [
            kind
            for kind in _REQUIRED_KINDS
            if not any(ref in reachable for ref in by_kind.get(kind, []))
        ]

        def latest_reachable(kind: str) -> str:
            return next(
                (ref for ref in reversed(by_kind.get(kind, [])) if ref in reachable),
                "",
            )

        leakage_paths = (
            _collect_forbidden_keys({"artifacts": artifacts})
            if self.source_authority is not None else []
        )
        evidence_issues: list[str] = []
        expected_count = (
            self.source_authority.spec.expected_record_count
            if self.source_authority is not None
            else None
        )

        leaderboard_ref = latest_reachable("proxy_formula_leaderboard")
        top_entry: dict[str, Any] | None = None
        if leaderboard_ref:
            try:
                top_entry = _proxy_leaderboard_top(
                    artifacts[leaderboard_ref].get("machine_payload")
                )
            except ValueError as exc:
                evidence_issues.append(str(exc))
        else:
            evidence_issues.append("proxy_formula_leaderboard_not_reachable")

        formula_ref = (
            str(top_entry["formula_artifact_ref"]) if top_entry is not None else ""
        )
        materialization_ref = (
            str(top_entry["materialization_artifact_ref"])
            if top_entry is not None
            else ""
        )
        evaluation_ref = (
            str(top_entry["evaluation_observation_ref"])
            if top_entry is not None
            else ""
        )
        review_ref = (
            str(top_entry["review_artifact_ref"]) if top_entry is not None else ""
        )

        if top_entry is not None:
            if (
                formula_ref not in reachable
                or artifacts.get(formula_ref, {}).get("artifact_kind")
                != "proxy_formula_candidate"
            ):
                evidence_issues.append("leaderboard_top_formula_not_reachable")
            if (
                materialization_ref not in reachable
                or artifacts.get(materialization_ref, {}).get("artifact_kind")
                != "quantitative_proxy_materialization_result"
            ):
                evidence_issues.append("leaderboard_top_materialization_not_reachable")
            else:
                dependencies = {
                    str(ref)
                    for ref in artifacts[materialization_ref].get("depends_on", [])
                }
                if formula_ref not in dependencies:
                    evidence_issues.append(
                        "leaderboard_materialization_formula_mismatch"
                    )
            review_artifact = artifacts.get(review_ref, {})
            if (
                review_ref not in reachable
                or review_artifact.get("artifact_kind") != "scientific_method_review"
            ):
                evidence_issues.append("leaderboard_scientific_review_not_reachable")
            else:
                try:
                    review_payload = validate_scientific_method_review(
                        review_artifact,
                        expected_method_ref=formula_ref,
                    )
                except ValueError as exc:
                    evidence_issues.append(str(exc))
                else:
                    if not math.isclose(
                        float(review_payload["review_score"]),
                        float(top_entry["review_score"]),
                        rel_tol=0.0,
                        abs_tol=1e-12,
                    ):
                        evidence_issues.append(
                            "leaderboard_scientific_review_score_mismatch"
                        )
            try:
                observation = self.observations.read(evaluation_ref)
            except (KeyError, ValueError):
                evidence_issues.append(
                    "leaderboard_private_evaluation_observation_missing"
                )
            else:
                if not self.observations.is_inspected(evaluation_ref):
                    evidence_issues.append(
                        "leaderboard_private_evaluation_not_inspected"
                    )
                metadata = observation.get("metadata")
                result = observation.get("result")
                if (
                    observation.get("namespace") != "private-evaluator"
                    or not isinstance(metadata, Mapping)
                    or metadata.get("formula_artifact_ref") != formula_ref
                    or metadata.get("materialization_artifact_ref")
                    != materialization_ref
                ):
                    evidence_issues.append(
                        "leaderboard_private_evaluation_authority_mismatch"
                    )
                try:
                    score = _private_trend_score(result)
                except ValueError as exc:
                    evidence_issues.append(str(exc))
                else:
                    if not math.isclose(
                        score,
                        float(top_entry["trend_alignment_score"]),
                        rel_tol=0.0,
                        abs_tol=1e-6,
                    ):
                        evidence_issues.append(
                            "leaderboard_private_evaluation_score_mismatch"
                        )

        if materialization_ref and materialization_ref in artifacts:
            materialization_artifact = artifacts[materialization_ref]
            materialization = materialization_artifact["machine_payload"]
            if materialization.get("materialization_status") != "complete":
                evidence_issues.append("materialization_status_not_complete")
            implementation_ref = str(materialization.get("implementation_ref") or "")
            if not implementation_ref.startswith(("code_artifact:", "artifact:")):
                evidence_issues.append("materialization_implementation_invalid")
            elif implementation_ref.startswith("artifact:"):
                implementation = artifacts.get(implementation_ref)
                if (
                    implementation is None
                    or implementation.get("artifact_kind")
                    != "development_project_snapshot"
                ):
                    evidence_issues.append(
                        "materialization_project_snapshot_not_reachable"
                    )
                else:
                    implementation_payload = implementation.get("machine_payload")
                    implementation_dependencies = (
                        {
                            str(ref)
                            for ref in implementation_payload.get("dependency_refs", [])
                        }
                        if isinstance(implementation_payload, Mapping)
                        else set()
                    )
                    if formula_ref not in implementation_dependencies:
                        evidence_issues.append(
                            "materialization_project_formula_mismatch"
                        )
            unresolved = materialization.get("unresolved_components")
            if not isinstance(unresolved, list) or unresolved:
                evidence_issues.append("materialization_has_unresolved_components")
            proxy_values = materialization.get("proxy_values_by_sample")
            if (
                not isinstance(proxy_values, Mapping)
                or not proxy_values
                or (expected_count is not None and len(proxy_values) != expected_count)
                or not all(_finite(value) for value in proxy_values.values())
            ):
                evidence_issues.append("materialization_proxy_population_invalid")
            execution_refs = materialization.get("execution_observation_refs")
            if not isinstance(execution_refs, list) or not any(
                self._materializer_execution_passed(str(ref)) for ref in execution_refs
            ):
                evidence_issues.append("materialization_execution_evidence_missing")
            elif not any(
                self._observation_matches_implementation(
                    str(ref), implementation_ref=implementation_ref
                )
                for ref in execution_refs
            ):
                evidence_issues.append(
                    "materialization_implementation_observation_mismatch"
                )

        sample_ref = latest_reachable("sample_evolution_result")
        if sample_ref:
            sample_artifact = artifacts[sample_ref]
            sample = sample_artifact["machine_payload"]
            best_sample = sample.get("best_sample")
            if not isinstance(best_sample, Mapping) or (
                best_sample.get("is_novel") is not True
            ):
                evidence_issues.append("sample_best_candidate_not_novel")
            ranked = sample.get("ranked_samples")
            if (
                not isinstance(ranked, list)
                or not ranked
                or not all(
                    isinstance(item, Mapping) and _finite(item.get("proxy_value"))
                    for item in ranked
                )
            ):
                evidence_issues.append("sample_ranked_population_invalid")
            sample_dependencies = {
                str(ref) for ref in sample_artifact.get("depends_on", [])
            }
            expected_dependencies = {
                leaderboard_ref,
                formula_ref,
                materialization_ref,
                evaluation_ref,
            } - {""}
            if not expected_dependencies.issubset(sample_dependencies):
                evidence_issues.append("sample_leaderboard_top_dependency_mismatch")
            if not any(
                str(ref).startswith("execution_observation:")
                and not str(ref).startswith("execution_observation:private-evaluator:")
                and self._replay_passed(str(ref), minimum=2)
                for ref in sample_dependencies
            ):
                evidence_issues.append("sample_replay_evidence_missing")

        final_outcome = ""
        if final_ref:
            payload = artifacts[final_ref].get("machine_payload", {})
            judgment = payload.get("final_lca_judgment", {})
            if isinstance(judgment, Mapping):
                final_outcome = str(judgment.get("outcome") or "")
            if not final_outcome:
                final_outcome = str(payload.get("outcome") or "")
        allowed_outcomes = {"released", "bounded_reject", "hard_block"}
        manifest = (
            self.source_authority.manifest()
            if self.source_authority is not None
            else None
        )
        complete = (
            not missing
            and not unreachable_required
            and not dangling
            and not leakage_paths
            and not evidence_issues
            and final_outcome in allowed_outcomes
        )
        return {
            "status": (
                "workflow_closure_valid" if complete else "workflow_closure_incomplete"
            ),
            "complete": complete,
            "required_artifact_kinds": list(_REQUIRED_KINDS),
            "latest_refs_by_kind": {
                kind: latest_reachable(kind) or refs[-1]
                for kind, refs in by_kind.items()
            },
            "missing_artifact_kinds": missing,
            "unreachable_required_artifact_kinds": unreachable_required,
            "dangling_artifact_dependencies": dangling,
            "forbidden_private_key_paths": leakage_paths,
            "evidence_issues": evidence_issues,
            "source_hashes": (
                {
                    "goal": manifest["goal"]["sha256"],
                    "historical_data": manifest["historical_data"]["sha256"],
                }
                if manifest is not None
                else {}
            ),
            "final_lca_outcome": final_outcome,
            "scientific_release": final_outcome == "released",
        }

    def _observation_exists(self, observation_ref: str) -> bool:
        if not observation_ref:
            return False
        try:
            self.observations.read(observation_ref)
        except (KeyError, ValueError):
            return False
        return True

    def _replay_passed(self, observation_ref: str, *, minimum: int) -> bool:
        try:
            observation = self.observations.read(observation_ref)
        except (KeyError, ValueError):
            return False
        metadata = observation.get("metadata")
        return (
            isinstance(metadata, Mapping)
            and metadata.get("deterministic_replay") is True
            and int(metadata.get("replay_count") or 0) >= minimum
        )

    def _materializer_execution_passed(self, observation_ref: str) -> bool:
        try:
            observation = self.observations.read(observation_ref)
        except (KeyError, ValueError):
            return False
        metadata = observation.get("metadata")
        return (
            isinstance(metadata, Mapping)
            and int(metadata.get("replay_count") or 0) >= 1
        )

    def _observation_matches_implementation(
        self,
        observation_ref: str,
        *,
        implementation_ref: str,
    ) -> bool:
        try:
            observation = self.observations.read(observation_ref)
        except (KeyError, ValueError):
            return False
        metadata = observation.get("metadata")
        return isinstance(metadata, Mapping) and (
            metadata.get("implementation_ref") == implementation_ref
        )


def _proxy_leaderboard_top(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, Mapping):
        raise ValueError("proxy_formula_leaderboard_payload_required")
    if set(payload) != {"artifact_kind", "version", "ranked_entries"}:
        raise ValueError("proxy_formula_leaderboard_shape_invalid")
    if payload.get("artifact_kind") != "proxy_formula_leaderboard":
        raise ValueError("proxy_formula_leaderboard_kind_invalid")
    version = payload.get("version")
    if not isinstance(version, int) or isinstance(version, bool) or version < 1:
        raise ValueError("proxy_formula_leaderboard_version_invalid")
    entries = payload.get("ranked_entries")
    if not isinstance(entries, list) or not entries:
        raise ValueError("proxy_formula_leaderboard_entries_required")
    expected_keys = {
        "rank",
        "formula_artifact_ref",
        "materialization_artifact_ref",
        "evaluation_observation_ref",
        "trend_alignment_score",
        "review_artifact_ref",
        "review_score",
        "pareto_tier",
    }
    seen_formulas: set[str] = set()
    for rank, raw in enumerate(entries, start=1):
        if not isinstance(raw, Mapping) or set(raw) != expected_keys:
            raise ValueError("proxy_formula_leaderboard_entry_shape_invalid")
        if raw.get("rank") != rank:
            raise ValueError("proxy_formula_leaderboard_rank_invalid")
        formula_ref = str(raw.get("formula_artifact_ref") or "")
        materialization_ref = str(raw.get("materialization_artifact_ref") or "")
        evaluation_ref = str(raw.get("evaluation_observation_ref") or "")
        if not formula_ref.startswith("artifact:"):
            raise ValueError("proxy_formula_leaderboard_formula_ref_invalid")
        if not materialization_ref.startswith("artifact:"):
            raise ValueError("proxy_formula_leaderboard_materialization_ref_invalid")
        if not evaluation_ref.startswith("execution_observation:private-evaluator:"):
            raise ValueError("proxy_formula_leaderboard_evaluation_ref_invalid")
        review_ref = str(raw.get("review_artifact_ref") or "")
        if not review_ref.startswith("artifact:"):
            raise ValueError("proxy_formula_leaderboard_review_ref_invalid")
        if formula_ref in seen_formulas:
            raise ValueError("proxy_formula_leaderboard_formula_ref_duplicate")
        seen_formulas.add(formula_ref)
        for score_name in ("trend_alignment_score", "review_score"):
            score = raw.get(score_name)
            if not _finite(score) or not 0.0 <= float(score) <= 100.0:
                raise ValueError(
                    f"proxy_formula_leaderboard_score_invalid:{score_name}"
                )
        tier = raw.get("pareto_tier")
        if isinstance(tier, bool) or not isinstance(tier, int) or tier < 1:
            raise ValueError("proxy_formula_leaderboard_pareto_tier_invalid")
    return dict(entries[0])


def _private_trend_score(result: Any) -> float:
    if not isinstance(result, Mapping):
        raise ValueError("private_proxy_evaluation_result_required")
    if result.get("raw_kpi_values_disclosed") is not False:
        raise ValueError("private_proxy_evaluation_disclosed_raw_kpi_values")
    values: list[float] = []
    for name in (
        "direction_adjusted_spearman_rho",
        "direction_adjusted_kendall_tau_b",
    ):
        value = result.get(name)
        if not _finite(value) or not -1.0 <= float(value) <= 1.0:
            raise ValueError(f"private_proxy_evaluation_metric_invalid:{name}")
        values.append(float(value))
    return round(25.0 * (values[0] + values[1] + 2.0), 6)


def _reachable_artifacts(
    final_ref: str, artifacts: Mapping[str, Mapping[str, Any]]
) -> set[str]:
    reachable: set[str] = set()
    pending = [final_ref] if final_ref else []
    while pending:
        artifact_ref = pending.pop()
        if artifact_ref in reachable or artifact_ref not in artifacts:
            continue
        reachable.add(artifact_ref)
        pending.extend(
            str(ref)
            for ref in artifacts[artifact_ref].get("depends_on", [])
            if str(ref).startswith("artifact:")
        )
    return reachable


def _collect_forbidden_keys(
    value: Any, path: str = "$", found: list[str] | None = None
) -> list[str]:
    result = found if found is not None else []
    if isinstance(value, Mapping):
        for key, item in value.items():
            item_path = f"{path}.{key}"
            if key in _FORBIDDEN_PRIVATE_KEYS:
                result.append(item_path)
            _collect_forbidden_keys(item, item_path, result)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            _collect_forbidden_keys(item, f"{path}[{index}]", result)
    return result


def _finite(value: Any) -> bool:
    return (
        not isinstance(value, bool)
        and isinstance(value, (int, float))
        and math.isfinite(float(value))
    )
