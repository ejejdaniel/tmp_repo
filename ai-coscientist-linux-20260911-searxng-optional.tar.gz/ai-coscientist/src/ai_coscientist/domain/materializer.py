from __future__ import annotations

import ast
import copy
import hashlib
import json
import math
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ai_coscientist.common.artifacts import ArtifactStore
from ai_coscientist.common.capabilities import CapabilityRegistry
from ai_coscientist.common.code_artifacts import CodeArtifactStore
from ai_coscientist.common.memory_lifecycle.prompt import tool_result_prompt_projection
from ai_coscientist.common.observations import ObservationStore
from ai_coscientist.common.routes import Route

from .computational_property_protocol import (
    validate_computational_property_protocol,
)
from .computational_property_result import (
    validate_computational_property_result,
)
from .source_authority import SourceAuthority
from .materialization_inputs import validate_execution_input_paths
from .prepared_evaluation import (
    execution_prepared_source_ref, prepared_source_ref_schema,
    validate_prepared_source_ref,
)


_BLOCKED_IMPORT_ROOTS = frozenset(
    {
        "asyncio",
        "builtins",
        "ctypes",
        "fcntl",
        "ftplib",
        "http",
        "importlib",
        "io",
        "mmap",
        "multiprocessing",
        "os",
        "pathlib",
        "pwd",
        "resource",
        "runpy",
        "shutil",
        "signal",
        "socket",
        "ssl",
        "subprocess",
        "sys",
        "tempfile",
        "threading",
        "urllib",
        "webbrowser",
    }
)
_HARNESS = r"""
import ast
import builtins
import hashlib
import json
import math
import pathlib
import statistics
import subprocess
import sys
from rdkit import Chem
from rdkit.Chem import Crippen, Descriptors, Lipinski, rdMolDescriptors
caught_exceptions = []
_BLOCKED_IMPORT_ROOTS = {
    "asyncio", "builtins", "ctypes", "fcntl", "ftplib", "http",
    "importlib", "io", "mmap", "multiprocessing", "os", "pathlib", "pwd",
    "resource", "runpy", "shutil", "signal", "socket", "ssl", "subprocess",
    "sys", "tempfile", "threading", "urllib", "webbrowser",
}


def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
    if level:
        raise ImportError("forbidden_relative_import")
    root = str(name).split(".", 1)[0]
    if root in _BLOCKED_IMPORT_ROOTS:
        raise ImportError("forbidden_import:" + root)
    return builtins.__import__(name, globals, locals, fromlist, level)


def trace_generated(frame, event, argument):
    if event == "exception" and frame.f_code.co_filename == "<materializer>":
        exc_type, exc_value, _ = argument
        caught_exceptions.append(
            f"{exc_type.__name__}:{exc_value}:line={frame.f_lineno}"
        )
    return trace_generated


def schema_issues(value, schema, path="$"):
    issues = []
    expected = schema.get("type")
    matches = {
        "object": isinstance(value, dict),
        "array": isinstance(value, list),
        "string": isinstance(value, str),
        "integer": isinstance(value, int) and not isinstance(value, bool),
        "number": isinstance(value, (int, float)) and not isinstance(value, bool),
        "boolean": isinstance(value, bool),
        "null": value is None,
    }
    if expected and not matches.get(expected, True):
        return [path + ":expected_" + str(expected)]
    if "enum" in schema and value not in schema["enum"]:
        issues.append(path + ":value_not_in_enum")
    if isinstance(value, dict):
        properties = schema.get("properties", {})
        required = schema.get("required", [])
        for key in required:
            if key not in value:
                issues.append(path + "." + str(key) + ":required")
        additional = schema.get("additionalProperties", True)
        for key, item in value.items():
            child = properties.get(key)
            if isinstance(child, dict):
                issues.extend(schema_issues(item, child, path + "." + str(key)))
            elif additional is False:
                issues.append(path + "." + str(key) + ":additional_property_not_allowed")
            elif isinstance(additional, dict):
                issues.extend(schema_issues(item, additional, path + "." + str(key)))
    elif isinstance(value, list):
        if isinstance(schema.get("minItems"), int) and len(value) < schema["minItems"]:
            issues.append(path + ":min_items_" + str(schema["minItems"]))
        if isinstance(schema.get("maxItems"), int) and len(value) > schema["maxItems"]:
            issues.append(path + ":max_items_" + str(schema["maxItems"]))
        child = schema.get("items")
        if isinstance(child, dict):
            for index, item in enumerate(value):
                issues.extend(schema_issues(item, child, path + "[" + str(index) + "]"))
    elif isinstance(value, str):
        if isinstance(schema.get("minLength"), int) and len(value) < schema["minLength"]:
            issues.append(path + ":min_length_" + str(schema["minLength"]))
        if isinstance(schema.get("maxLength"), int) and len(value) > schema["maxLength"]:
            issues.append(path + ":max_length_" + str(schema["maxLength"]))
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        if isinstance(schema.get("minimum"), (int, float)) and value < schema["minimum"]:
            issues.append(path + ":minimum_" + str(schema["minimum"]))
        if isinstance(schema.get("maximum"), (int, float)) and value > schema["maximum"]:
            issues.append(path + ":maximum_" + str(schema["maximum"]))
    return issues


code_path, input_path, output_path, binding_path, cache_path, replay_mode = sys.argv[1:7]
with open(binding_path, "r", encoding="utf-8") as handle:
    binding = json.load(handle)
if replay_mode not in {"record", "sequence_replay", "lookup_replay"}:
    raise ValueError("approved_route_replay_mode_invalid:" + replay_mode)
expected_calls = []
if replay_mode != "record":
    with open(cache_path, "r", encoding="utf-8") as handle:
        expected_calls = json.load(handle)["calls"]
actual_calls = []
consumed_lookup_indices = set()


def canonical_json(value):
    return json.dumps(
        value,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def call_route_broker(route_ref, payload, call_index):
    broker = binding.get("broker")
    if not isinstance(broker, dict):
        raise RuntimeError("approved_route_broker_configuration_missing")
    runtime_root = pathlib.Path(binding_path).resolve().parent
    request_path = runtime_root / ("broker-request-" + str(call_index) + ".json")
    response_path = runtime_root / ("broker-response-" + str(call_index) + ".json")
    with open(request_path, "w", encoding="utf-8") as handle:
        json.dump(
            {"route_ref": route_ref, "payload": payload},
            handle,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
        )
    completed = subprocess.run(
        [
            str(broker["python_executable"]),
            "-I",
            "-B",
            str(broker["script_path"]),
            str(binding_path),
            str(request_path),
            str(response_path),
        ],
        cwd=str(runtime_root),
        capture_output=True,
        text=True,
        timeout=float(broker["timeout_seconds"]) + 15.0,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            "approved_route_broker_failed:"
            + route_ref
            + ":"
            + str(completed.returncode)
            + ":"
            + completed.stderr[-4000:]
        )
    if not response_path.is_file():
        raise RuntimeError("approved_route_broker_response_missing:" + route_ref)
    with open(response_path, "r", encoding="utf-8") as handle:
        envelope = json.load(handle)
    if not isinstance(envelope, dict) or not isinstance(envelope.get("result"), dict):
        raise RuntimeError("approved_route_broker_response_invalid:" + route_ref)
    route_stdout = envelope.get("stdout")
    route_stderr = envelope.get("stderr")
    if isinstance(route_stdout, str) and route_stdout:
        print(route_stdout, end="" if route_stdout.endswith("\n") else "\n")
    if isinstance(route_stderr, str) and route_stderr:
        print(
            route_stderr,
            end="" if route_stderr.endswith("\n") else "\n",
            file=sys.stderr,
        )
    return envelope["result"]


def invoke_managed_route(route_ref, payload):
    if not isinstance(route_ref, str):
        raise TypeError("managed_route_ref_must_be_string")
    descriptor = binding["routes"].get(route_ref)
    if not isinstance(descriptor, dict):
        raise PermissionError("managed_route_not_bound:" + route_ref)
    input_json = canonical_json(payload)
    input_hash = hashlib.sha256(input_json.encode("utf-8")).hexdigest()
    call_index = len(actual_calls)
    if replay_mode == "sequence_replay":
        if call_index >= len(expected_calls):
            raise RuntimeError("approved_route_replay_has_extra_call")
        expected = expected_calls[call_index]
        if expected["route_ref"] != route_ref or expected["input_sha256"] != input_hash:
            raise RuntimeError("approved_route_replay_sequence_mismatch")
        result = expected["result"]
    elif replay_mode == "lookup_replay":
        matched_index = None
        for index, expected in enumerate(expected_calls):
            if index in consumed_lookup_indices:
                continue
            if expected["route_ref"] == route_ref and expected["input_sha256"] == input_hash:
                matched_index = index
                break
        if matched_index is None:
            raise RuntimeError("approved_route_authority_replay_input_mismatch")
        consumed_lookup_indices.add(matched_index)
        result = expected_calls[matched_index]["result"]
    else:
        if call_index >= binding["max_route_calls"]:
            raise RuntimeError("approved_route_call_quota_exceeded")
        input_issues = schema_issues(payload, descriptor["input_schema"])
        if input_issues:
            raise ValueError("approved_route_input_invalid:" + repr(input_issues))
        result = call_route_broker(route_ref, payload, call_index)
        output_issues = schema_issues(result, descriptor["output_schema"])
        if output_issues:
            raise ValueError("approved_route_output_invalid:" + repr(output_issues))
    output_json = canonical_json(result)
    output_hash = hashlib.sha256(output_json.encode("utf-8")).hexdigest()
    actual_calls.append(
        {
            "route_ref": route_ref,
            "input_sha256": input_hash,
            "output_sha256": output_hash,
            "result": result,
        }
    )
    return result


invoke_approved_route = invoke_managed_route


with open(code_path, "r", encoding="utf-8") as handle:
    code = handle.read()
tree = ast.parse(code, filename="<materializer>")
for node in ast.walk(tree):
    if isinstance(node, ast.Global):
        raise ValueError("forbidden_syntax:" + type(node).__name__)
    if isinstance(node, ast.Name) and node.id.startswith("__"):
        raise ValueError("dunder_name_forbidden:" + node.id)
    if isinstance(node, ast.Attribute) and node.attr.startswith("__"):
        raise ValueError("dunder_attribute_forbidden:" + node.attr)

safe_builtins = {
    "abs": abs, "all": all, "any": any, "ArithmeticError": ArithmeticError,
    "AssertionError": AssertionError, "AttributeError": AttributeError,
    "bool": bool, "dict": dict, "enumerate": enumerate,
    "Exception": Exception, "filter": filter,
    "float": float, "int": int, "isinstance": isinstance, "len": len,
    "ImportError": ImportError, "IndexError": IndexError,
    "list": list, "map": map, "max": max, "min": min, "next": next,
    "LookupError": LookupError, "NameError": NameError,
    "NotImplementedError": NotImplementedError, "OverflowError": OverflowError,
    "pow": pow, "range": range, "reversed": reversed, "round": round,
    "set": set, "sorted": sorted, "str": str, "sum": sum, "tuple": tuple,
    "type": type, "ValueError": ValueError, "KeyError": KeyError,
    "RuntimeError": RuntimeError, "TypeError": TypeError,
    "ZeroDivisionError": ZeroDivisionError, "__import__": guarded_import,
    "zip": zip,
}
namespace = {
    "__builtins__": safe_builtins,
    "Chem": Chem,
    "Crippen": Crippen,
    "Descriptors": Descriptors,
    "Lipinski": Lipinski,
    "rdMolDescriptors": rdMolDescriptors,
    "invoke_managed_route": invoke_managed_route,
    "invoke_approved_route": invoke_approved_route,
    "math": math,
    "statistics": statistics,
}
exec(compile(tree, "<materializer>", "exec"), namespace, namespace)
run = namespace.get("run")
if not callable(run):
    raise ValueError("run_function_required")
with open(input_path, "r", encoding="utf-8") as handle:
    records = json.load(handle)["records"]
sys.settrace(trace_generated)
try:
    result = run(records)
finally:
    sys.settrace(None)
if replay_mode != "record" and len(actual_calls) != len(expected_calls):
    raise RuntimeError("approved_route_replay_call_count_mismatch")
if not isinstance(result, dict):
    raise ValueError("run_must_return_object")
proxy_values = result.get("proxy_values_by_sample")
invalid_proxy = not isinstance(proxy_values, dict)
if not invalid_proxy:
    invalid_proxy = any(
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(float(value))
        for value in proxy_values.values()
    )
if caught_exceptions and (result.get("unresolved_components") or invalid_proxy):
    raise RuntimeError("generated_code_caught_exception:" + caught_exceptions[0])
if replay_mode == "record":
    with open(cache_path, "w", encoding="utf-8") as handle:
        json.dump({"calls": actual_calls}, handle, ensure_ascii=False, allow_nan=False, sort_keys=True)
with open(output_path, "w", encoding="utf-8") as handle:
    json.dump(result, handle, ensure_ascii=False, allow_nan=False, sort_keys=True)
"""

_PROTOCOL_HARNESS = r"""
import ast
import builtins
import hashlib
import json
import math
import pathlib
import statistics
import subprocess
import sys
from rdkit import Chem
from rdkit.Chem import Crippen, Descriptors, Lipinski, rdMolDescriptors

caught_exceptions = []
_BLOCKED_IMPORT_ROOTS = {
    "asyncio", "builtins", "ctypes", "fcntl", "ftplib", "http",
    "importlib", "io", "mmap", "multiprocessing", "os", "pathlib", "pwd",
    "resource", "runpy", "shutil", "signal", "socket", "ssl", "subprocess",
    "sys", "tempfile", "threading", "urllib", "webbrowser",
}


def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
    if level:
        raise ImportError("forbidden_relative_import")
    root = str(name).split(".", 1)[0]
    if root in _BLOCKED_IMPORT_ROOTS:
        raise ImportError("forbidden_import:" + root)
    return builtins.__import__(name, globals, locals, fromlist, level)


def trace_generated(frame, event, argument):
    if event == "exception" and frame.f_code.co_filename == "<materializer-protocol>":
        exc_type, exc_value, _ = argument
        caught_exceptions.append(
            f"{exc_type.__name__}:{exc_value}:line={frame.f_lineno}"
        )
    return trace_generated


def canonical_json(value):
    return json.dumps(
        value,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


code_path, input_path, output_path, binding_path, cache_path, replay_mode = sys.argv[1:7]
with open(binding_path, "r", encoding="utf-8") as handle:
    binding = json.load(handle)
if replay_mode not in {"record", "sequence_replay"}:
    raise ValueError("managed_route_replay_mode_invalid:" + replay_mode)
expected_calls = []
if replay_mode != "record":
    with open(cache_path, "r", encoding="utf-8") as handle:
        expected_calls = json.load(handle)["calls"]
actual_calls = []


def call_route_broker(route_ref, payload, call_index):
    broker = binding.get("broker")
    if not isinstance(broker, dict):
        raise RuntimeError("managed_route_broker_configuration_missing")
    runtime_root = pathlib.Path(binding_path).resolve().parent
    request_path = runtime_root / ("broker-request-" + str(call_index) + ".json")
    response_path = runtime_root / ("broker-response-" + str(call_index) + ".json")
    with open(request_path, "w", encoding="utf-8") as handle:
        json.dump(
            {"route_ref": route_ref, "payload": payload},
            handle,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
        )
    completed = subprocess.run(
        [
            str(broker["python_executable"]),
            "-I",
            "-B",
            str(broker["script_path"]),
            str(binding_path),
            str(request_path),
            str(response_path),
        ],
        cwd=str(runtime_root),
        capture_output=True,
        text=True,
        timeout=float(broker["timeout_seconds"]) + 15.0,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            "managed_route_broker_failed:"
            + route_ref
            + ":"
            + str(completed.returncode)
            + ":"
            + completed.stderr[-4000:]
        )
    if not response_path.is_file():
        raise RuntimeError("managed_route_broker_response_missing:" + route_ref)
    with open(response_path, "r", encoding="utf-8") as handle:
        envelope = json.load(handle)
    if not isinstance(envelope, dict) or not isinstance(envelope.get("result"), dict):
        raise RuntimeError("managed_route_broker_response_invalid:" + route_ref)
    route_stdout = envelope.get("stdout")
    route_stderr = envelope.get("stderr")
    if isinstance(route_stdout, str) and route_stdout:
        print(route_stdout, end="" if route_stdout.endswith("\n") else "\n")
    if isinstance(route_stderr, str) and route_stderr:
        print(
            route_stderr,
            end="" if route_stderr.endswith("\n") else "\n",
            file=sys.stderr,
        )
    return envelope["result"]


def invoke_managed_route(route_ref, payload):
    if not isinstance(route_ref, str):
        raise TypeError("managed_route_ref_must_be_string")
    if route_ref not in binding.get("routes", {}):
        raise PermissionError("managed_route_not_bound:" + route_ref)
    input_json = canonical_json(payload)
    input_hash = hashlib.sha256(input_json.encode("utf-8")).hexdigest()
    call_index = len(actual_calls)
    if replay_mode == "sequence_replay":
        if call_index >= len(expected_calls):
            raise RuntimeError("managed_route_replay_has_extra_call")
        expected = expected_calls[call_index]
        if expected["route_ref"] != route_ref or expected["input_sha256"] != input_hash:
            raise RuntimeError("managed_route_replay_sequence_mismatch")
        result = expected["result"]
    else:
        if call_index >= binding["max_route_calls"]:
            raise RuntimeError("managed_route_call_quota_exceeded")
        result = call_route_broker(route_ref, payload, call_index)
    output_json = canonical_json(result)
    output_hash = hashlib.sha256(output_json.encode("utf-8")).hexdigest()
    actual_calls.append(
        {
            "route_ref": route_ref,
            "input_sha256": input_hash,
            "output_sha256": output_hash,
            "result": result,
        }
    )
    return result


invoke_approved_route = invoke_managed_route


with open(code_path, "r", encoding="utf-8") as handle:
    code = handle.read()
tree = ast.parse(code, filename="<materializer-protocol>")
for node in ast.walk(tree):
    if isinstance(node, ast.Global):
        raise ValueError("forbidden_syntax:" + type(node).__name__)
    if isinstance(node, ast.Name) and node.id.startswith("__"):
        raise ValueError("dunder_name_forbidden:" + node.id)
    if isinstance(node, ast.Attribute) and node.attr.startswith("__"):
        raise ValueError("dunder_attribute_forbidden:" + node.attr)

safe_builtins = {
    "abs": abs, "all": all, "any": any, "ArithmeticError": ArithmeticError,
    "AssertionError": AssertionError, "AttributeError": AttributeError,
    "bool": bool, "dict": dict, "enumerate": enumerate,
    "Exception": Exception, "filter": filter,
    "float": float, "int": int, "isinstance": isinstance, "len": len,
    "ImportError": ImportError, "IndexError": IndexError,
    "list": list, "map": map, "max": max, "min": min, "next": next,
    "LookupError": LookupError, "NameError": NameError,
    "NotImplementedError": NotImplementedError, "OverflowError": OverflowError,
    "pow": pow, "range": range, "reversed": reversed, "round": round,
    "set": set, "sorted": sorted, "str": str, "sum": sum, "tuple": tuple,
    "type": type, "ValueError": ValueError, "KeyError": KeyError,
    "RuntimeError": RuntimeError, "TypeError": TypeError,
    "ZeroDivisionError": ZeroDivisionError, "__import__": guarded_import,
    "zip": zip,
}
namespace = {
    "__builtins__": safe_builtins,
    "Chem": Chem,
    "Crippen": Crippen,
    "Descriptors": Descriptors,
    "Lipinski": Lipinski,
    "rdMolDescriptors": rdMolDescriptors,
    "invoke_managed_route": invoke_managed_route,
    "invoke_approved_route": invoke_approved_route,
    "math": math,
    "statistics": statistics,
}
exec(compile(tree, "<materializer-protocol>", "exec"), namespace, namespace)
run = namespace.get("run")
if not callable(run):
    raise ValueError("run_function_required")
with open(input_path, "r", encoding="utf-8") as handle:
    execution_input = json.load(handle)
protocol = execution_input["protocol"]
inputs = execution_input["inputs"]
sys.settrace(trace_generated)
try:
    result = run(protocol, inputs)
finally:
    sys.settrace(None)
if caught_exceptions:
    raise RuntimeError("generated_code_caught_exception:" + caught_exceptions[0])
if replay_mode != "record" and len(actual_calls) != len(expected_calls):
    raise RuntimeError("managed_route_replay_call_count_mismatch")
if not isinstance(result, dict):
    raise ValueError("run_must_return_object")
if replay_mode == "record":
    with open(cache_path, "w", encoding="utf-8") as handle:
        json.dump(
            {"calls": actual_calls},
            handle,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
        )
with open(output_path, "w", encoding="utf-8") as handle:
    json.dump(result, handle, ensure_ascii=False, allow_nan=False, sort_keys=True)
"""


@dataclass
class MaterializerExecutor:
    artifacts: ArtifactStore
    code_artifacts: CodeArtifactStore
    observations: ObservationStore
    source_authority: SourceAuthority | None
    run_root: Path
    record_resolver: Callable[[str, str], Sequence[Mapping[str, Any]]] | None = None
    capability_registry: CapabilityRegistry | None = None
    python_executable: str = sys.executable
    timeout_seconds: float = 60.0

    def routes(self) -> tuple[Route, ...]:
        return (
            Route(
                name="scientific_materializer_execute",
                description=(
                    "Deterministically execute one exact stored Python run(records) "
                    "for one exact proxy formula against sanitized records."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "formula_artifact_ref": {"type": "string"},
                        "code_artifact_ref": {"type": "string"},
                        "prepared_source_ref": prepared_source_ref_schema(),
                        "max_route_calls": {
                            "type": "integer",
                            "minimum": 0,
                            "maximum": 10000,
                        },
                    },
                    "required": ["formula_artifact_ref", "code_artifact_ref"],
                    "additionalProperties": False,
                },
                handler=self.execute,
                skill_ids=("materializer",),
            ),
            Route(
                name="scientific_protocol_materializer_execute",
                description=(
                    "Deterministically execute one exact stored Python "
                    "run(protocol, inputs) for one exact computational "
                    "property protocol."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "protocol_artifact_ref": {"type": "string"},
                        "code_artifact_ref": {"type": "string"},
                        "input_bindings": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "input_id": {"type": "string"},
                                    "artifact_ref": {"type": "string"},
                                },
                                "required": ["input_id", "artifact_ref"],
                                "additionalProperties": False,
                            },
                        },
                        "max_route_calls": {
                            "type": "integer",
                            "minimum": 0,
                            "maximum": 10000,
                        },
                    },
                    "required": [
                        "protocol_artifact_ref",
                        "code_artifact_ref",
                        "input_bindings",
                        "max_route_calls",
                    ],
                    "additionalProperties": False,
                },
                handler=self.execute_protocol,
                skill_ids=("materializer",),
            ),
        )

    def execute(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        formula_ref = str(arguments.get("formula_artifact_ref") or "")
        code_ref = str(arguments.get("code_artifact_ref") or "")
        source_ref = (validate_prepared_source_ref(arguments["prepared_source_ref"])
                      if "prepared_source_ref" in arguments else None)
        formula_artifact = self.artifacts.read(formula_ref)
        if formula_artifact.get("artifact_kind") != "proxy_formula_candidate":
            raise ValueError(
                "artifact_kind_mismatch:"
                f"{formula_ref}:expected=proxy_formula_candidate:"
                f"actual={formula_artifact.get('artifact_kind')}"
            )
        formula = formula_artifact.get("machine_payload")
        if not isinstance(formula, Mapping):
            raise ValueError(f"artifact_machine_payload_required:{formula_ref}")
        completed_refs = [
            str(receipt["artifact_ref"])
            for receipt in self.artifacts.list()
            if receipt.get("artifact_kind")
            == "quantitative_proxy_materialization_result"
            and formula_ref in list(receipt.get("depends_on") or ())
            and self.artifacts.read(str(receipt["artifact_ref"]))
            .get("machine_payload", {})
            .get("materialization_status")
            == "complete"
            and self.artifacts.read(str(receipt["artifact_ref"]))["machine_payload"].get("implementation_ref") == code_ref
            and execution_prepared_source_ref(
                self.artifacts.read(str(receipt["artifact_ref"])), self.observations.read,
            ) == source_ref
        ]
        if completed_refs:
            raise ValueError(
                "formula_already_completely_materialized:"
                f"formula_artifact_ref={formula_ref}:"
                f"materialization_artifact_refs={completed_refs}"
            )
        code = self.code_artifacts.read(code_ref)
        python_code = str(code["code"])
        if formula_ref not in list(code.get("depends_on") or ()):
            raise ValueError(
                "code_artifact_formula_dependency_required:"
                f"code_artifact_ref={code_ref}:"
                f"formula_artifact_ref={formula_ref}:"
                "do_not_retry_same_execution:"
                "read_exact_prior_code_then_write_new_immutable_revision:"
                "depends_on_must_include_exact_formula_ref_and_prior_code_ref:"
                "unchanged_source_is_allowed_when_still_faithful"
            )
        protocol_refs = self._protocol_refs_from_code(code)
        protocols = self._bound_protocols(
            formula_ref=formula_ref,
            formula=formula,
            protocol_refs=protocol_refs,
        )
        expression = formula.get("formula_expression")
        if not isinstance(expression, str) or not expression.strip():
            raise ValueError("formula_expression_required")

        route_refs = self._validated_managed_route_refs(code)
        raw_max_route_calls = arguments.get("max_route_calls", 0)
        if (
            isinstance(raw_max_route_calls, bool)
            or not isinstance(raw_max_route_calls, int)
            or not 0 <= raw_max_route_calls <= 10000
        ):
            raise ValueError("max_route_calls_must_be_integer_0_to_10000")
        if route_refs and raw_max_route_calls < 1:
            raise ValueError("max_route_calls_required_for_approved_route_dependencies")
        if not route_refs and raw_max_route_calls != 0:
            raise ValueError("max_route_calls_requires_approved_route_dependency")

        try:
            _validate_generated_python(python_code)
            code = self.code_artifacts.read(code_ref)
            records = self.records_for_formula(formula_ref, prepared_source_ref=source_ref)
            execution = self._execute_formal_formula_once(
                code_path=Path(code["path"]),
                code=code,
                records=records,
                label="historical-materialization",
                max_route_calls=raw_max_route_calls,
            )
        except Exception as exc:
            raise RuntimeError(
                "materializer_code_attempt_failed:"
                f"code_artifact_ref={code_ref}:"
                f"{type(exc).__name__}:{exc}"
            ) from exc

        def build_result(observation_ref: str) -> Mapping[str, Any]:
            raw = execution["result"]
            return {
                "artifact_kind": "quantitative_proxy_materialization_result",
                "materialization_status": "complete",
                "execution_input_paths": raw["execution_input_paths"],
                "resolved_components": raw["resolved_components"],
                "unresolved_components": raw["unresolved_components"],
                "implementation_ref": code_ref,
                "execution_observation_refs": [observation_ref],
                "component_values_by_sample": raw["component_values_by_sample"],
                "proxy_values_by_sample": raw["proxy_values_by_sample"],
            }

        observation = self.observations.publish_with_ref(
            namespace="materializer",
            result_factory=build_result,
            metadata={
                "implementation_ref": code_ref,
                "formula_artifact_ref": formula_ref,
                **({"prepared_source_ref": source_ref} if source_ref is not None else {}),
                "deterministic_replay": False,
                "replay_count": 1,
                "max_route_calls": raw_max_route_calls,
                "process_evidence": execution["process_evidence"],
                "approved_route_calls": execution["approved_route_calls"],
            },
        )
        return {
            "status": "materializer_execution_complete",
            "observation_ref": observation["observation_ref"],
            "code_artifact_ref": code_ref,
            "sample_count": len(records),
            "replay_count": 1,
            "deterministic_replay": False,
            "approved_route_call_count": len(execution["approved_route_calls"]),
        }

    def execute_protocol(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        protocol_ref = str(arguments.get("protocol_artifact_ref") or "")
        code_ref = str(arguments.get("code_artifact_ref") or "")
        protocol_artifact = self.artifacts.read(protocol_ref)
        if protocol_artifact.get("artifact_kind") != (
            "computational_property_protocol"
        ):
            raise ValueError(
                "artifact_kind_mismatch:"
                f"{protocol_ref}:expected=computational_property_protocol:"
                f"actual={protocol_artifact.get('artifact_kind')}"
            )
        protocol = protocol_artifact.get("machine_payload")
        validate_computational_property_protocol(protocol)
        assert isinstance(protocol, Mapping)

        completed_refs = [
            str(receipt["artifact_ref"])
            for receipt in self.artifacts.list()
            if receipt.get("artifact_kind") == "computational_property_result"
            and protocol_ref in list(receipt.get("depends_on") or ())
        ]
        if completed_refs:
            raise ValueError(
                "protocol_already_completely_materialized:"
                f"protocol_artifact_ref={protocol_ref}:"
                f"result_artifact_refs={completed_refs}"
            )

        code = self.code_artifacts.read(code_ref)
        dependencies = set(str(ref) for ref in code.get("depends_on") or ())
        if protocol_ref not in dependencies:
            raise ValueError(
                "code_artifact_protocol_dependency_required:"
                f"code_artifact_ref={code_ref}:"
                f"protocol_artifact_ref={protocol_ref}:"
                "do_not_retry_same_execution:"
                "write_new_immutable_revision_with_exact_protocol_dependency"
            )
        input_bindings, inputs = self._protocol_input_bindings(
            protocol=protocol,
            raw_bindings=arguments.get("input_bindings"),
        )
        protocol_dependencies = {
            str(ref) for ref in protocol_artifact.get("depends_on") or ()
        }
        authorized_input_dependencies = dependencies | protocol_dependencies
        missing_input_dependencies = sorted(
            binding["artifact_ref"]
            for binding in input_bindings
            if binding["artifact_ref"] not in authorized_input_dependencies
        )
        if missing_input_dependencies:
            raise ValueError(
                "code_artifact_protocol_input_dependency_required:"
                f"artifact_refs={missing_input_dependencies}"
            )

        route_refs = self._validated_managed_route_refs(code)

        max_route_calls = arguments.get("max_route_calls")
        if (
            isinstance(max_route_calls, bool)
            or not isinstance(max_route_calls, int)
            or not 0 <= max_route_calls <= 10000
        ):
            raise ValueError("max_route_calls_must_be_integer_0_to_10000")
        if route_refs and max_route_calls < 1:
            raise ValueError("max_route_calls_required_for_managed_route_dependencies")
        if not route_refs and max_route_calls != 0:
            raise ValueError("max_route_calls_requires_managed_route_dependency")

        python_code = str(code["code"])
        try:
            _validate_generated_protocol_python(python_code)
            execution = self._execute_formal_protocol_once(
                code_path=Path(code["path"]),
                code=code,
                protocol=protocol,
                inputs=inputs,
                label="protocol-materialization",
                max_route_calls=max_route_calls,
            )
        except Exception as exc:
            raise RuntimeError(
                "protocol_materializer_code_attempt_failed:"
                f"code_artifact_ref={code_ref}:"
                f"{type(exc).__name__}:{exc}"
            ) from exc

        def build_result(observation_ref: str) -> Mapping[str, Any]:
            raw = execution["result"]
            result = {
                "artifact_kind": "computational_property_result",
                "protocol_artifact_ref": protocol_ref,
                "output_id": raw["output_id"],
                "value": copy.deepcopy(raw["value"]),
                "unit": raw["unit"],
                "implementation_ref": code_ref,
                "execution_observation_refs": [observation_ref],
            }
            validate_computational_property_result(result)
            return result

        observation = self.observations.publish_with_ref(
            namespace="materializer-protocol",
            result_factory=build_result,
            metadata={
                "implementation_ref": code_ref,
                "protocol_artifact_ref": protocol_ref,
                "input_bindings": copy.deepcopy(input_bindings),
                "deterministic_replay": False,
                "replay_count": 1,
                "max_route_calls": max_route_calls,
                "process_evidence": execution["process_evidence"],
                "approved_route_calls": execution["approved_route_calls"],
            },
        )
        return {
            "status": "protocol_materializer_execution_complete",
            "observation_ref": observation["observation_ref"],
            "protocol_artifact_ref": protocol_ref,
            "code_artifact_ref": code_ref,
            "input_binding_count": len(input_bindings),
            "replay_count": 1,
            "deterministic_replay": False,
            "approved_route_call_count": len(execution["approved_route_calls"]),
        }

    def _protocol_input_bindings(
        self,
        *,
        protocol: Mapping[str, Any],
        raw_bindings: Any,
    ) -> tuple[list[dict[str, str]], dict[str, Mapping[str, Any]]]:
        if not isinstance(raw_bindings, Sequence) or isinstance(
            raw_bindings, (str, bytes)
        ):
            raise ValueError("protocol_input_bindings_must_be_array")
        declared_input_ids = {
            str(item.get("input_id") or "")
            for item in protocol.get("required_inputs") or ()
            if isinstance(item, Mapping)
        }
        bindings: list[dict[str, str]] = []
        inputs: dict[str, Mapping[str, Any]] = {}
        for index, raw in enumerate(raw_bindings):
            if not isinstance(raw, Mapping) or set(raw) != {
                "input_id",
                "artifact_ref",
            }:
                raise ValueError(f"protocol_input_binding_shape_invalid:{index}")
            input_id = str(raw.get("input_id") or "").strip()
            artifact_ref = str(raw.get("artifact_ref") or "").strip()
            if input_id not in declared_input_ids:
                raise ValueError(
                    "protocol_input_binding_id_undeclared:"
                    f"input_id={input_id}:declared={sorted(declared_input_ids)}"
                )
            if input_id in inputs:
                raise ValueError(f"protocol_input_binding_id_duplicate:{input_id}")
            if not artifact_ref.startswith("artifact:"):
                raise ValueError(
                    "protocol_input_binding_artifact_ref_invalid:"
                    f"input_id={input_id}:artifact_ref={artifact_ref}"
                )
            stored = self.artifacts.read(artifact_ref)
            machine_payload = stored.get("machine_payload")
            if not isinstance(machine_payload, Mapping):
                raise ValueError(
                    "protocol_input_binding_machine_payload_required:"
                    f"input_id={input_id}:artifact_ref={artifact_ref}"
                )
            bindings.append({"input_id": input_id, "artifact_ref": artifact_ref})
            inputs[input_id] = copy.deepcopy(dict(machine_payload))
        return bindings, inputs

    def _execute_formal_protocol_once(
        self,
        *,
        code_path: Path,
        code: Mapping[str, Any],
        protocol: Mapping[str, Any],
        inputs: Mapping[str, Mapping[str, Any]],
        label: str,
        max_route_calls: int,
    ) -> dict[str, Any]:
        workspace = self.run_root.resolve() / "workspace"
        workspace.mkdir(parents=True, exist_ok=True)
        safe_label = _file_label(label)
        input_path = workspace / f"{safe_label}-input.json"
        input_path.write_text(
            json.dumps(
                {
                    "protocol": copy.deepcopy(dict(protocol)),
                    "inputs": copy.deepcopy(dict(inputs)),
                },
                ensure_ascii=False,
                indent=2,
                allow_nan=False,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        output_path = workspace / f"{safe_label}-output.json"
        with tempfile.TemporaryDirectory(
            prefix=f"{safe_label}-route-runtime-",
            dir=str(workspace),
            ignore_cleanup_errors=True,
        ) as runtime_directory:
            runtime_root = Path(runtime_directory)
            binding_path = runtime_root / "binding.json"
            cache_path = runtime_root / "route-call-cache.json"
            binding = self._route_binding_manifest(
                code,
                runtime_root=runtime_root,
                max_route_calls=max_route_calls,
            )
            _write_json_file(binding_path, binding)
            process_evidence = [
                self._execute_protocol_process(
                    code_path=code_path,
                    input_path=input_path,
                    output_path=output_path,
                    binding_path=binding_path,
                    cache_path=cache_path,
                    replay_mode="record",
                    timeout_seconds=_materializer_process_timeout_seconds(
                        self.timeout_seconds,
                        max_route_calls=max_route_calls,
                    ),
                )
            ]
            raw = json.loads(output_path.read_text(encoding="utf-8"))
            result = _validate_protocol_execution_result(raw, protocol)
            route_cache = (
                json.loads(cache_path.read_text(encoding="utf-8"))
                if cache_path.is_file()
                else {"calls": []}
            )
            approved_route_calls = self._store_route_call_results(
                route_cache.get("calls", ()),
                label=safe_label,
            )
        return {
            "result": result,
            "process_evidence": process_evidence,
            "approved_route_calls": approved_route_calls,
        }

    def _execute_protocol_process(
        self,
        *,
        code_path: Path,
        input_path: Path,
        output_path: Path,
        binding_path: Path,
        cache_path: Path,
        replay_mode: str,
        timeout_seconds: float | None = None,
    ) -> dict[str, Any]:
        creationflags = 0
        if os.name == "nt":
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        completed = subprocess.run(
            [
                self.python_executable,
                "-I",
                "-B",
                "-c",
                _PROTOCOL_HARNESS,
                str(code_path),
                str(input_path),
                str(output_path),
                str(binding_path),
                str(cache_path),
                replay_mode,
            ],
            cwd=str(self.run_root.resolve() / "workspace"),
            capture_output=True,
            text=True,
            timeout=(
                self.timeout_seconds
                if timeout_seconds is None
                else float(timeout_seconds)
            ),
            check=False,
            creationflags=creationflags,
            env={
                **os.environ,
                "PYTHONHASHSEED": "0",
                "PYTHONDONTWRITEBYTECODE": "1",
            },
        )
        if completed.returncode != 0:
            raise RuntimeError(
                "python_execution_failed:"
                f"{completed.returncode}:{completed.stderr[-4000:]}"
            )
        if not output_path.is_file():
            raise RuntimeError("python_output_missing")
        return {
            "stdout": completed.stdout[-4000:],
            "stderr": completed.stderr[-4000:],
        }

    def execute_records(
        self,
        *,
        code_artifact_ref: str,
        records: Sequence[Mapping[str, Any]],
        label: str,
        max_route_calls: int | None = None,
    ) -> dict[str, Any]:
        """Execute one immutable scorer for domain-owned record preparation."""
        code = self.code_artifacts.read(code_artifact_ref)
        route_refs = self._validated_managed_route_refs(code)
        if route_refs and max_route_calls is None:
            raise ValueError(
                "execute_records_max_route_calls_required_for_approved_routes"
            )
        return self._execute_formal_formula_once(
            code_path=Path(code["path"]),
            code=code,
            records=records,
            label=label,
            max_route_calls=int(max_route_calls or 0),
        )

    def validate_observation_authority(self, observation_ref: str) -> None:
        """Reject materializations that depend on narrative, IDs, or row order."""
        observation = self.observations.read(observation_ref)
        result = observation.get("result")
        if not isinstance(result, Mapping) or result.get("artifact_kind") != (
            "quantitative_proxy_materialization_result"
        ):
            return

        metadata = observation.get("metadata")
        if not isinstance(metadata, Mapping):
            raise ValueError("materializer_observation_metadata_required")
        implementation_ref = str(metadata.get("implementation_ref") or "")
        formula_ref = str(metadata.get("formula_artifact_ref") or "")
        if not implementation_ref or not formula_ref:
            raise ValueError("materializer_observation_authority_refs_required")
        records = self.records_for_formula(
            formula_ref, prepared_source_ref=metadata.get("prepared_source_ref"),
        )
        validate_execution_input_paths(result.get("execution_input_paths"), records=records)
        if set(result.get("proxy_values_by_sample", {})) != {str(row["id"]) for row in records}:
            raise ValueError("materializer_execution_source_ids_mismatch")
        if implementation_ref.startswith("artifact:"):
            implementation = self.artifacts.read(implementation_ref)
            if implementation.get("artifact_kind") != ("development_project_snapshot"):
                raise ValueError("materializer_implementation_artifact_kind_invalid")
            payload = implementation.get("machine_payload")
            if not isinstance(payload, Mapping) or formula_ref not in list(
                payload.get("dependency_refs") or ()
            ):
                raise ValueError("materializer_formula_project_ref_mismatch")
            return
        code = self.code_artifacts.read(implementation_ref)
        if formula_ref not in list(code.get("depends_on") or ()):
            raise ValueError("materializer_formula_code_ref_mismatch")
        formula_artifact = self.artifacts.read(formula_ref)
        formula = formula_artifact.get("machine_payload")
        if not isinstance(formula, Mapping):
            raise ValueError(f"artifact_machine_payload_required:{formula_ref}")
        self._bound_protocols(
            formula_ref=formula_ref,
            formula=formula,
            protocol_refs=self._protocol_refs_from_code(code),
        )

        alias_to_original: dict[str, str] = {}
        challenged_records: list[dict[str, Any]] = []
        for index, record in enumerate(records):
            original_id = str(record["id"])
            alias = (
                "opaque_"
                + hashlib.sha256(
                    f"{observation_ref}\0{index}\0{original_id}".encode("utf-8")
                ).hexdigest()[:16]
            )
            alias_to_original[alias] = original_id
            challenged = copy.deepcopy(dict(record))
            challenged["id"] = alias
            challenged_records.append(challenged)
        challenged_records.reverse()

        try:
            challenged_result = self._execute_once(
                code_path=Path(code["path"]),
                code=code,
                records=challenged_records,
                label=f"{observation_ref}-authority-challenge",
                approved_route_calls=tuple(
                    item
                    for item in metadata.get("approved_route_calls", ())
                    if isinstance(item, Mapping)
                ),
            )
        except Exception as exc:
            raise ValueError(
                "materializer_non_authoritative_input_dependency:"
                "record_identity_or_order_affected_execution:"
                f"{type(exc).__name__}:{exc}"
            ) from exc

        remapped = _materializer_comparable_result(challenged_result)
        remapped["component_values_by_sample"] = _remap_record_keyed_object(
            challenged_result["component_values_by_sample"],
            alias_to_original,
        )
        remapped["proxy_values_by_sample"] = _remap_record_keyed_object(
            challenged_result["proxy_values_by_sample"],
            alias_to_original,
        )
        authority_difference = _materializer_difference(
            _materializer_comparable_result(result),
            remapped,
        )
        if authority_difference:
            raise ValueError(
                "materializer_non_authoritative_input_dependency:"
                "record_identity_or_order_changed_non_keyed_output:"
                "resolved_components_and_unresolved_components_must_list_"
                "formula_variable_names_not_sample_ids:"
                f"{authority_difference}"
            )

    def records_for_formula(self, formula_ref: str, *, prepared_source_ref: str | None = None) -> list[dict[str, Any]]:
        if prepared_source_ref is not None:
            validate_prepared_source_ref(prepared_source_ref)
            if self.record_resolver is None:
                raise ValueError("materializer_prepared_source_resolver_unavailable")
            raw_records = self.record_resolver(formula_ref, prepared_source_ref)
        elif self.source_authority is not None:
            raw_records = self.source_authority.visible_historical()["records"]
        else:
            raise ValueError(
                "materializer_prepared_source_ref_required:"
                f"formula_ref={formula_ref}:select_data_for_this_execution_not_formula_research_lineage"
            )
        return _materializer_execution_records(raw_records)

    def records_for_materialization(self, materialization_ref: str) -> list[dict[str, Any]]:
        materialization = self.artifacts.read(materialization_ref)
        source_ref = execution_prepared_source_ref(materialization, self.observations.read)
        observations = materialization["machine_payload"]["execution_observation_refs"]
        formula_ref = self.observations.read(observations[0])["metadata"]["formula_artifact_ref"]
        if source_ref is None:
            formula = self.artifacts.read(formula_ref)
            if any(self.artifacts.read(ref).get("artifact_kind") == "prepared_source_data"
                   for ref in formula.get("depends_on", ()) if str(ref).startswith("artifact:")):
                raise ValueError("legacy_prepared_materialization_requires_explicit_execution")
        return self.records_for_formula(formula_ref, prepared_source_ref=source_ref)

    def _execute_formal_formula_once(
        self,
        *,
        code_path: Path,
        code: Mapping[str, Any] | None = None,
        records: Sequence[Mapping[str, Any]],
        label: str,
        max_route_calls: int = 0,
    ) -> dict[str, Any]:
        if code is None:
            code = {
                "code": (
                    code_path.read_text(encoding="utf-8") if code_path.is_file() else ""
                ),
                "depends_on": [],
            }
        workspace = self.run_root.resolve() / "workspace"
        workspace.mkdir(parents=True, exist_ok=True)
        safe_label = _file_label(label)
        input_path = workspace / f"{safe_label}-input.json"
        input_path.write_text(
            json.dumps({"records": list(records)}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        expected_ids = [str(record["id"]) for record in records]
        output_path = workspace / f"{safe_label}-output.json"
        with tempfile.TemporaryDirectory(
            prefix=f"{safe_label}-route-runtime-",
            dir=str(workspace),
            ignore_cleanup_errors=True,
        ) as runtime_directory:
            runtime_root = Path(runtime_directory)
            binding_path = runtime_root / "binding.json"
            cache_path = runtime_root / "route-call-cache.json"
            binding = self._route_binding_manifest(
                code,
                runtime_root=runtime_root,
                max_route_calls=max_route_calls,
            )
            _write_json_file(binding_path, binding)
            process_evidence = [
                self._execute_process(
                    code_path=code_path,
                    input_path=input_path,
                    output_path=output_path,
                    binding_path=binding_path,
                    cache_path=cache_path,
                    replay_mode="record",
                    timeout_seconds=_materializer_process_timeout_seconds(
                        self.timeout_seconds,
                        max_route_calls=max_route_calls,
                    ),
                )
            ]
            raw = json.loads(output_path.read_text(encoding="utf-8"))
            result = _validate_proxy_result(raw, expected_ids, records=records)
            route_cache = (
                json.loads(cache_path.read_text(encoding="utf-8"))
                if cache_path.is_file()
                else {"calls": []}
            )
            approved_route_calls = self._store_route_call_results(
                route_cache.get("calls", ()),
                label=safe_label,
            )
        return {
            "result": result,
            "process_evidence": process_evidence,
            "approved_route_calls": approved_route_calls,
        }

    def _execute_once(
        self,
        *,
        code_path: Path,
        code: Mapping[str, Any],
        records: Sequence[Mapping[str, Any]],
        label: str,
        approved_route_calls: Sequence[Mapping[str, Any]] = (),
    ) -> dict[str, Any]:
        workspace = self.run_root.resolve() / "workspace"
        workspace.mkdir(parents=True, exist_ok=True)
        safe_label = _file_label(label)
        input_path = workspace / f"{safe_label}-input.json"
        output_path = workspace / f"{safe_label}-output.json"
        input_path.write_text(
            json.dumps({"records": list(records)}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        route_refs = self._validated_managed_route_refs(code)
        with tempfile.TemporaryDirectory(
            prefix=f"{safe_label}-route-runtime-",
            dir=str(workspace),
        ) as runtime_directory:
            runtime_root = Path(runtime_directory)
            binding_path = runtime_root / "binding.json"
            cache_path = runtime_root / "route-call-cache.json"
            binding = self._route_binding_manifest(
                code,
                runtime_root=runtime_root,
                max_route_calls=len(approved_route_calls),
            )
            _write_json_file(binding_path, binding)
            if route_refs:
                cache = {"calls": self._load_route_call_results(approved_route_calls)}
                _write_json_file(cache_path, cache)
                replay_mode = "lookup_replay"
            else:
                replay_mode = "record"
            self._execute_process(
                code_path=code_path,
                input_path=input_path,
                output_path=output_path,
                binding_path=binding_path,
                cache_path=cache_path,
                replay_mode=replay_mode,
            )
        raw = json.loads(output_path.read_text(encoding="utf-8"))
        return _validate_proxy_result(
            raw,
            [str(record["id"]) for record in records],
            records=records,
        )

    def _validated_managed_route_refs(self, code: Mapping[str, Any]) -> tuple[str, ...]:
        source_refs = _managed_route_refs_from_python(str(code.get("code") or ""))
        dependency_refs = {
            str(ref)
            for ref in code.get("depends_on", ())
            if str(ref).startswith(("approved_route:", "pending_route:"))
        }
        if source_refs != dependency_refs:
            raise ValueError(
                "managed_route_source_dependency_mismatch:"
                f"source_refs={sorted(source_refs)}:"
                f"dependency_refs={sorted(dependency_refs)}"
            )
        if source_refs and self.capability_registry is None:
            raise ValueError("managed_route_registry_not_configured")
        for route_ref in sorted(source_refs):
            assert self.capability_registry is not None
            descriptor = self.capability_registry.resolve_managed_route_ref(route_ref)
            if descriptor.get("code_callable") is not True:
                raise PermissionError(f"managed_route_not_code_callable:{route_ref}")
            if "materializer" not in descriptor.get("visible_to_skill_ids", ()):
                raise PermissionError(
                    f"managed_route_not_visible_to_materializer:{route_ref}"
                )
            if route_ref.startswith("pending_route:"):
                candidate_refs = self._candidate_artifact_refs_for_route(route_ref)
                if not set(candidate_refs).intersection(
                    set(code.get("depends_on") or ())
                ):
                    raise ValueError(
                        "pending_route_candidate_dependency_required:"
                        f"route_ref={route_ref}:"
                        f"candidate_refs={sorted(candidate_refs)}"
                    )
        return tuple(sorted(source_refs))

    def _route_binding_manifest(
        self,
        code: Mapping[str, Any],
        *,
        runtime_root: Path,
        max_route_calls: int,
    ) -> dict[str, Any]:
        route_refs = self._validated_managed_route_refs(code)
        del runtime_root
        routes: dict[str, Any] = {}
        for route_ref in route_refs:
            assert self.capability_registry is not None
            descriptor = self.capability_registry.resolve_managed_route_ref(route_ref)
            routes[route_ref] = {
                "input_schema": copy.deepcopy(descriptor["input_schema"]),
                "output_schema": copy.deepcopy(descriptor["output_schema"]),
            }
        broker: dict[str, Any] | None = None
        if route_refs:
            assert self.capability_registry is not None
            broker = {
                **self.capability_registry.invocation_broker_spec(
                    timeout_seconds=max(1.0, self.timeout_seconds - 30.0),
                ),
                "script_path": str(
                    (
                        Path(__file__).resolve().parents[1]
                        / "common"
                        / "capabilities"
                        / "invocation_broker.py"
                    ).resolve()
                ),
            }
        return {
            "broker": broker,
            "max_route_calls": int(max_route_calls),
            "routes": routes,
        }

    def _bound_protocols(
        self,
        *,
        formula_ref: str,
        formula: Mapping[str, Any],
        protocol_refs: Sequence[str],
    ) -> tuple[Mapping[str, Any], ...]:
        if not protocol_refs:
            return ()
        formula_inputs = _formula_input_names(formula)
        quantity_ids: set[str] = set()
        protocols: list[Mapping[str, Any]] = []
        for protocol_ref in protocol_refs:
            stored = self.artifacts.read(protocol_ref)
            if stored.get("artifact_kind") != "computational_property_protocol":
                raise ValueError(
                    "materializer_protocol_kind_mismatch:"
                    f"ref={protocol_ref}:actual={stored.get('artifact_kind')}"
                )
            payload = stored.get("machine_payload")
            validate_computational_property_protocol(payload)
            assert isinstance(payload, Mapping)
            if formula_ref not in tuple(stored.get("depends_on") or ()):
                raise ValueError(
                    "materializer_protocol_formula_dependency_required:"
                    f"protocol_ref={protocol_ref}:formula_ref={formula_ref}"
                )
            quantity_id = str(payload["quantity_id"])
            if quantity_id not in formula_inputs:
                raise ValueError(
                    "materializer_protocol_quantity_not_in_formula:"
                    f"protocol_ref={protocol_ref}:quantity_id={quantity_id}"
                )
            if quantity_id in quantity_ids:
                raise ValueError(
                    "materializer_protocol_quantity_duplicate:"
                    f"quantity_id={quantity_id}"
                )
            quantity_ids.add(quantity_id)
            protocols.append(copy.deepcopy(dict(payload)))
        return tuple(protocols)

    def _protocol_refs_from_code(self, code: Mapping[str, Any]) -> tuple[str, ...]:
        """Resolve specialist protocols from the existing code lineage contract."""
        protocol_refs: list[str] = []
        for raw_ref in code.get("depends_on") or ():
            ref = str(raw_ref)
            if not ref.startswith("artifact:"):
                continue
            stored = self.artifacts.read(ref)
            if stored.get("artifact_kind") == "computational_property_protocol":
                protocol_refs.append(ref)
        if len(protocol_refs) != len(set(protocol_refs)):
            raise ValueError("code_artifact_protocol_dependency_duplicate")
        return tuple(protocol_refs)

    def _candidate_artifact_refs_for_route(self, route_ref: str) -> tuple[str, ...]:
        if self.capability_registry is None:
            raise ValueError("managed_route_registry_not_configured")
        descriptor = self.capability_registry.resolve_managed_route_ref(route_ref)
        expected = descriptor.get("candidate_payload")
        if not isinstance(expected, Mapping):
            return ()
        matches: list[str] = []
        for receipt in self.artifacts.list():
            if receipt.get("artifact_kind") != "capability_candidate":
                continue
            ref = str(receipt.get("artifact_ref") or "")
            stored = self.artifacts.read(ref)
            if stored.get("machine_payload") == expected:
                matches.append(ref)
        if not matches:
            raise ValueError(
                "pending_route_candidate_artifact_required:"
                f"route_ref={route_ref}:package_hash={descriptor.get('package_hash')}"
            )
        return tuple(matches)

    def _store_route_call_results(
        self,
        calls: Any,
        *,
        label: str,
    ) -> list[dict[str, Any]]:
        if not isinstance(calls, list):
            raise ValueError("approved_route_call_cache_invalid")
        result_root = self.run_root.resolve() / "workspace" / "approved-route-results"
        result_root.mkdir(parents=True, exist_ok=True)
        receipts: list[dict[str, Any]] = []
        for index, raw_call in enumerate(calls):
            if not isinstance(raw_call, Mapping) or set(raw_call) != {
                "route_ref",
                "input_sha256",
                "output_sha256",
                "result",
            }:
                raise ValueError(f"approved_route_call_cache_entry_invalid:{index}")
            result = copy.deepcopy(raw_call["result"])
            output_hash = hashlib.sha256(
                _canonical_json(result).encode("utf-8")
            ).hexdigest()
            if output_hash != raw_call["output_sha256"]:
                raise ValueError(f"approved_route_call_output_hash_mismatch:{index}")
            stored = {
                "route_ref": str(raw_call["route_ref"]),
                "input_sha256": str(raw_call["input_sha256"]),
                "output_sha256": output_hash,
                "result": result,
            }
            digest = hashlib.sha256(_canonical_json(stored).encode("utf-8")).hexdigest()
            result_path = result_root / f"{_file_label(label)}-{digest}.json"
            if result_path.exists():
                existing = json.loads(result_path.read_text(encoding="utf-8"))
                if existing != stored:
                    raise ValueError(
                        f"approved_route_result_ref_conflict:{result_path}"
                    )
            else:
                _write_json_file(result_path, stored)
            receipts.append(
                {
                    "call_index": index,
                    "route_ref": stored["route_ref"],
                    "input_sha256": stored["input_sha256"],
                    "output_sha256": stored["output_sha256"],
                    "result_ref": (
                        "workspace:approved-route-results/" + result_path.name
                    ),
                }
            )
        return receipts

    def _load_route_call_results(
        self, receipts: Sequence[Mapping[str, Any]]
    ) -> list[dict[str, Any]]:
        result_root = (
            self.run_root.resolve() / "workspace" / "approved-route-results"
        ).resolve()
        calls: list[dict[str, Any]] = []
        for index, receipt in enumerate(receipts):
            if (
                set(receipt)
                != {
                    "call_index",
                    "route_ref",
                    "input_sha256",
                    "output_sha256",
                    "result_ref",
                }
                or receipt.get("call_index") != index
            ):
                raise ValueError(f"approved_route_call_receipt_invalid:{index}")
            result_ref = str(receipt.get("result_ref") or "")
            prefix = "workspace:approved-route-results/"
            if not result_ref.startswith(prefix):
                raise ValueError(f"approved_route_result_ref_invalid:{result_ref}")
            path = (result_root / result_ref[len(prefix) :]).resolve()
            if not path.is_relative_to(result_root) or not path.is_file():
                raise ValueError(f"approved_route_result_ref_missing:{result_ref}")
            stored = json.loads(path.read_text(encoding="utf-8"))
            expected = {
                "route_ref": receipt["route_ref"],
                "input_sha256": receipt["input_sha256"],
                "output_sha256": receipt["output_sha256"],
            }
            if any(stored.get(key) != value for key, value in expected.items()):
                raise ValueError(f"approved_route_result_receipt_mismatch:{result_ref}")
            actual_output_hash = hashlib.sha256(
                _canonical_json(stored.get("result")).encode("utf-8")
            ).hexdigest()
            if actual_output_hash != receipt["output_sha256"]:
                raise ValueError(
                    f"approved_route_result_content_hash_mismatch:{result_ref}"
                )
            calls.append(
                {
                    **expected,
                    "result": copy.deepcopy(stored["result"]),
                }
            )
        return calls

    def _execute_process(
        self,
        *,
        code_path: Path,
        input_path: Path,
        output_path: Path,
        binding_path: Path,
        cache_path: Path,
        replay_mode: str,
        timeout_seconds: float | None = None,
    ) -> dict[str, Any]:
        creationflags = 0
        if os.name == "nt":
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        completed = subprocess.run(
            [
                self.python_executable,
                "-I",
                "-B",
                "-c",
                _HARNESS,
                str(code_path),
                str(input_path),
                str(output_path),
                str(binding_path),
                str(cache_path),
                replay_mode,
            ],
            cwd=str(self.run_root.resolve() / "workspace"),
            capture_output=True,
            text=True,
            timeout=(
                self.timeout_seconds
                if timeout_seconds is None
                else float(timeout_seconds)
            ),
            check=False,
            creationflags=creationflags,
            env={
                **os.environ,
                "PYTHONHASHSEED": "0",
                "PYTHONDONTWRITEBYTECODE": "1",
            },
        )
        if completed.returncode != 0:
            raise RuntimeError(
                "python_execution_failed:"
                f"{completed.returncode}:{completed.stderr[-4000:]}"
            )
        if not output_path.is_file():
            raise RuntimeError("python_output_missing")
        return {
            "stdout": completed.stdout[-4000:],
            "stderr": completed.stderr[-4000:],
        }


def observation_inspect_route(
    observations: ObservationStore,
    *,
    materializer: MaterializerExecutor | None = None,
    raw_output_loader: Callable[[str], Mapping[str, Any]] | None = None,
) -> Route:
    roots = ("result", "metadata", "raw_output")
    root_description = "`result`, `metadata`, or `raw_output`"

    def selected_inspection_paths(
        arguments: Mapping[str, Any],
    ) -> tuple[str, ...]:
        selected_paths = arguments.get("selected_paths") or ()
        if not isinstance(selected_paths, Sequence) or isinstance(
            selected_paths, (str, bytes)
        ):
            raise ValueError("selected_paths_must_be_array")
        paths: list[str] = []
        for raw_path in selected_paths:
            path = str(raw_path).strip()
            if not path:
                continue
            if path.split(".", 1)[0] not in roots or any(
                not segment or "/" in segment or "\\" in segment
                for segment in path.split(".")
            ):
                raise ValueError(f"observation_selected_path_root_invalid:{path}")
            paths.append(path)
        return tuple(paths)

    def validate(arguments: Mapping[str, Any]) -> None:
        selected_inspection_paths(arguments)

    def inspect(arguments: Mapping[str, Any]) -> Mapping[str, Any]:
        selected_paths = selected_inspection_paths(arguments)
        observation_ref = str(arguments.get("observation_ref") or "")
        extra_sources = {}
        if any(path.split(".", 1)[0] == "raw_output" for path in selected_paths):
            if raw_output_loader is None:
                raise ValueError("observation_raw_output_unavailable")
            extra_sources["raw_output"] = raw_output_loader(observation_ref)
        if materializer is not None:
            materializer.validate_observation_authority(observation_ref)
        return observations.inspect(
            observation_ref,
            selected_paths=selected_paths,
            extra_sources=extra_sources,
        )

    def project_inspection(result: Mapping[str, Any]) -> Mapping[str, Any]:
        # Selected C4 fields are the requested read body, not a receipt summary.
        projected = dict(tool_result_prompt_projection(result))
        projected["selected_paths"] = copy.deepcopy(result.get("selected_paths", {}))
        return projected

    return Route(
        name="scientific_observation_inspect",
        description=(
            "Inspect one exact stored execution observation before using it "
            "to publish or judge a result. Selected dot paths are rooted at the "
            f"inspection sources {root_description}. result is the normalized "
            "publication payload; metadata is execution provenance; raw_output "
            "is the exact project's original result JSON, available only for "
            "completed project executions. It is diagnostic evidence, not a "
            "replacement publication payload. Inspection remains available after "
            "a prior read. Materializer observations also undergo an opaque-ID and "
            "record-order authority challenge."
        ),
        parameters={
            "type": "object",
            "properties": {
                "observation_ref": {"type": "string"},
                "selected_paths": {
                    "type": "array",
                    "description": (
                        f"Optional dot paths rooted at {root_description}, e.g. "
                        "`result.proxy_values_by_sample`, `metadata.process_evidence`, "
                        "or `raw_output.diagnostics`. Use dots, not filesystem paths. "
                        "Only requested raw-output fields are returned."
                    ),
                    "items": {
                        "type": "string",
                        "description": (
                            f"A root or dot path under {root_description}."
                        ),
                    },
                },
            },
            "required": ["observation_ref"],
            "additionalProperties": False,
        },
        handler=inspect,
        result_projector=project_inspection,
        skill_ids=(
            "materializer",
            "sample",
            "review-scientific-method",
            "rank-proxy-formula",
        ),
        validator=validate,
    )


def _validate_generated_python(code: str) -> None:
    _validate_generated_python_entrypoint(
        code,
        argument_names=("records",),
        signature_error="python_run_records_function_required",
    )


def _validate_generated_protocol_python(code: str) -> None:
    _validate_generated_python_entrypoint(
        code,
        argument_names=("protocol", "inputs"),
        signature_error="python_run_protocol_inputs_function_required",
    )


def _validate_generated_python_entrypoint(
    code: str,
    *,
    argument_names: Sequence[str],
    signature_error: str,
) -> None:
    if not code.strip():
        raise ValueError("python_code_required")
    if len(code) > 120_000:
        raise ValueError("python_code_too_large")
    try:
        tree = ast.parse(code, filename="<materializer>")
    except SyntaxError as exc:
        raise ValueError(f"python_syntax_error:{exc}") from exc
    run_functions = [
        node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == "run"
    ]
    if len(run_functions) != 1:
        raise ValueError(signature_error)
    run_function = run_functions[0]
    if isinstance(run_function, ast.AsyncFunctionDef):
        raise ValueError("async_run_not_supported")
    if tuple(argument.arg for argument in run_function.args.args) != tuple(
        argument_names
    ):
        raise ValueError(signature_error)
    forbidden_calls = {
        "eval",
        "exec",
        "compile",
        "open",
        "input",
        "breakpoint",
        "__import__",
    }
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported_roots = [alias.name.split(".", 1)[0] for alias in node.names]
        elif isinstance(node, ast.ImportFrom):
            imported_roots = [str(node.module or "").split(".", 1)[0]]
        else:
            imported_roots = []
        for imported_root in imported_roots:
            if imported_root in _BLOCKED_IMPORT_ROOTS:
                raise ValueError(f"forbidden_import:{imported_root}")
        if isinstance(node, ast.Global):
            raise ValueError(f"forbidden_syntax:{type(node).__name__}")
        if isinstance(node, ast.Name) and node.id.startswith("__"):
            raise ValueError(f"dunder_name_forbidden:{node.id}")
        if isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            raise ValueError(f"dunder_attribute_forbidden:{node.attr}")
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id in forbidden_calls
        ):
            raise ValueError(f"forbidden_call:{node.func.id}")


def _validate_protocol_execution_result(
    raw: Any,
    protocol: Mapping[str, Any],
) -> dict[str, Any]:
    if not isinstance(raw, Mapping):
        raise ValueError("protocol_materializer_result_must_be_object")
    required_keys = {"output_id", "value", "unit"}
    missing_keys = required_keys - set(raw)
    if missing_keys:
        raise ValueError(
            "protocol_materializer_result_keys_invalid:"
            f"missing={sorted(missing_keys)}"
        )
    result_contract = protocol.get("result_contract")
    if not isinstance(result_contract, Mapping):
        raise ValueError("protocol_result_contract_required")
    output_id = str(raw.get("output_id") or "").strip()
    expected_output_id = str(result_contract.get("output_id") or "").strip()
    if output_id != expected_output_id:
        raise ValueError(
            "protocol_materializer_output_id_mismatch:"
            f"expected={expected_output_id}:actual={output_id}"
        )
    unit = str(raw.get("unit") or "").strip()
    expected_unit = str(result_contract.get("unit") or "").strip()
    if unit != expected_unit:
        raise ValueError(
            "protocol_materializer_unit_mismatch:"
            f"expected={expected_unit}:actual={unit}"
        )
    value = raw.get("value")
    candidate = {
        "artifact_kind": "computational_property_result",
        "protocol_artifact_ref": "artifact:validation:protocol",
        "output_id": output_id,
        "value": value,
        "unit": unit,
        "implementation_ref": "code_artifact:validation:code",
        "execution_observation_refs": ["execution_observation:validation:000001"],
    }
    validate_computational_property_result(candidate)
    return {
        "output_id": output_id,
        "value": copy.deepcopy(value),
        "unit": unit,
    }


def _managed_route_refs_from_python(code: str) -> set[str]:
    try:
        tree = ast.parse(code, filename="<materializer>")
    except SyntaxError as exc:
        raise ValueError(f"python_syntax_error:{exc}") from exc
    static_refs = _statically_bound_route_refs(tree)
    refs: set[str] = set()
    direct_function_nodes: set[int] = set()
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id in {"invoke_approved_route", "invoke_managed_route"}
        ):
            continue
        direct_function_nodes.add(id(node.func))
        raw_ref = _validate_managed_route_call_contract(
            node,
            static_refs=static_refs,
        )
        route_ref = str(raw_ref or "")
        if not route_ref.startswith(("approved_route:", "pending_route:")):
            raise ValueError(
                "managed_route_ref_must_be_static_literal:"
                "use_an_inline_literal_or_one_plain_variable_assigned_once"
            )
        refs.add(route_ref)
    indirect = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Name)
        and node.id in {"invoke_approved_route", "invoke_managed_route"}
        and id(node) not in direct_function_nodes
    ]
    if indirect:
        raise ValueError("managed_route_indirect_invocation_forbidden")
    return refs


def _statically_bound_route_refs(tree: ast.AST) -> dict[str, str]:
    binding_counts: dict[str, int] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and not isinstance(node.ctx, ast.Load):
            binding_counts[node.id] = binding_counts.get(node.id, 0) + 1
        elif isinstance(node, ast.arg):
            binding_counts[node.arg] = binding_counts.get(node.arg, 0) + 1
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            binding_counts[node.name] = binding_counts.get(node.name, 0) + 1
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in node.names:
                bound_name = alias.asname or alias.name.split(".", 1)[0]
                binding_counts[bound_name] = binding_counts.get(bound_name, 0) + 1
        elif isinstance(node, ast.ExceptHandler) and node.name:
            binding_counts[node.name] = binding_counts.get(node.name, 0) + 1

    candidates: dict[str, str] = {}
    for node in ast.walk(tree):
        target: ast.expr | None = None
        value: ast.expr | None = None
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
        ):
            target = node.targets[0]
            value = node.value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            target = node.target
            value = node.value
        if (
            isinstance(target, ast.Name)
            and isinstance(value, ast.Constant)
            and isinstance(value.value, str)
            and binding_counts.get(target.id) == 1
        ):
            candidates[target.id] = value.value
    return candidates


def _validate_managed_route_call_contract(
    node: ast.Call,
    *,
    static_refs: Mapping[str, str] | None = None,
) -> str:
    if any(keyword.arg is None for keyword in node.keywords):
        raise _managed_route_call_contract_error()
    keyword_values = {str(keyword.arg): keyword.value for keyword in node.keywords}
    if (
        len(node.args) > 2
        or set(keyword_values) - {"route_ref", "payload"}
        or (node.args and "route_ref" in keyword_values)
        or (len(node.args) > 1 and "payload" in keyword_values)
    ):
        raise _managed_route_call_contract_error()
    route_node = node.args[0] if node.args else keyword_values.get("route_ref")
    payload_node = node.args[1] if len(node.args) > 1 else keyword_values.get("payload")
    if route_node is None or payload_node is None:
        raise _managed_route_call_contract_error()
    if not (isinstance(route_node, ast.Constant) and isinstance(route_node.value, str)):
        if isinstance(route_node, ast.Name):
            return str((static_refs or {}).get(route_node.id) or "")
        return ""
    return route_node.value


def _managed_route_call_contract_error() -> ValueError:
    return ValueError(
        "managed_route_call_contract_invalid:"
        "expected=invoke_managed_route(route_ref,payload_mapping):"
        "put_every_route_input_field_inside_the_single_payload_mapping"
    )


def _formula_input_names(formula: Mapping[str, Any]) -> set[str]:
    raw_inputs = formula.get("input_variables")
    if not isinstance(raw_inputs, Sequence) or isinstance(raw_inputs, (str, bytes)):
        raise ValueError("formula_input_variables_must_be_array")
    names: set[str] = set()
    for index, item in enumerate(raw_inputs):
        name = (
            str(item.get("name") or "").strip()
            if isinstance(item, Mapping)
            else str(item).strip()
        )
        if not name:
            raise ValueError(f"formula_input_variable_name_required:{index}")
        if name in names:
            raise ValueError(f"formula_input_variable_duplicate:{name}")
        names.add(name)
    return names


def _validate_proxy_result(
    raw: Any, expected_ids: Sequence[str], *, records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    if not isinstance(raw, Mapping):
        raise ValueError("materializer_result_must_be_object")
    input_paths = validate_execution_input_paths(raw.get("execution_input_paths"), records=records)
    unresolved = raw.get("unresolved_components")
    if not isinstance(unresolved, list):
        raise ValueError("unresolved_components_must_be_array")
    if unresolved:
        raise ValueError(f"unresolved_components_present:{unresolved}")
    proxy_values = raw.get("proxy_values_by_sample")
    if not isinstance(proxy_values, Mapping):
        raise ValueError("proxy_values_by_sample_required")
    actual_proxy_ids = sorted(str(key) for key in proxy_values)
    expected_sample_ids = sorted(expected_ids)
    if actual_proxy_ids != expected_sample_ids:
        raise ValueError(
            "proxy_sample_ids_mismatch:"
            f"expected={expected_sample_ids}:actual={actual_proxy_ids}"
        )
    for sample_id, value in proxy_values.items():
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"proxy_value_not_numeric:{sample_id}")
        if not math.isfinite(float(value)):
            raise ValueError(f"proxy_value_not_finite:{sample_id}")
    resolved = raw.get("resolved_components")
    if not isinstance(resolved, list):
        raise ValueError("resolved_components_must_be_array")
    components = raw.get("component_values_by_sample")
    if not isinstance(components, Mapping):
        raise ValueError("component_values_by_sample_required")
    actual_component_ids = sorted(str(key) for key in components)
    if actual_component_ids != expected_sample_ids:
        raise ValueError(
            "component_sample_ids_mismatch:"
            f"expected={expected_sample_ids}:actual={actual_component_ids}"
        )
    return {
        "execution_input_paths": input_paths,
        "resolved_components": list(resolved),
        "unresolved_components": list(unresolved),
        "component_values_by_sample": dict(components),
        "proxy_values_by_sample": dict(proxy_values),
    }


def _canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def _write_json_file(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(
            value,
            ensure_ascii=False,
            indent=2,
            allow_nan=False,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _materializer_process_timeout_seconds(
    base_timeout_seconds: float,
    *,
    max_route_calls: int,
) -> float:
    """Budget one base process window plus one window per managed Route call."""
    base_timeout = float(base_timeout_seconds)
    route_calls = max(0, int(max_route_calls))
    return base_timeout * float(route_calls + 1)


def _materializer_difference(
    expected: Any,
    actual: Any,
    *,
    path: str = "$",
) -> str:
    """Return the first concrete JSON difference for a repair prompt."""
    if isinstance(expected, Mapping) and isinstance(actual, Mapping):
        expected_keys = sorted(str(key) for key in expected)
        actual_keys = sorted(str(key) for key in actual)
        if expected_keys != actual_keys:
            return (
                f"path={path}:expected_keys={_diagnostic_preview(expected_keys)}:"
                f"actual_keys={_diagnostic_preview(actual_keys)}"
            )
        for key in expected_keys:
            difference = _materializer_difference(
                expected[key],
                actual[key],
                path=_json_child_path(path, key),
            )
            if difference:
                return difference
        return ""
    if isinstance(expected, list) and isinstance(actual, list):
        if len(expected) != len(actual):
            return (
                f"path={path}:expected_length={len(expected)}:"
                f"actual_length={len(actual)}"
            )
        for index, (expected_item, actual_item) in enumerate(
            zip(expected, actual, strict=True)
        ):
            difference = _materializer_difference(
                expected_item,
                actual_item,
                path=f"{path}[{index}]",
            )
            if difference:
                return difference
        return ""
    if type(expected) is not type(actual) or expected != actual:
        return (
            f"path={path}:expected={_diagnostic_preview(expected)}:"
            f"actual={_diagnostic_preview(actual)}"
        )
    return ""


def _json_child_path(path: str, key: str) -> str:
    if key and all(character.isalnum() or character == "_" for character in key):
        return f"{path}.{key}"
    return f"{path}[{json.dumps(key, ensure_ascii=False)}]"


def _diagnostic_preview(value: Any) -> str:
    rendered = _canonical_json(value)
    if len(rendered) <= 240:
        return rendered
    return rendered[:237] + "..."


def _materializer_execution_records(
    records: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    projected: list[dict[str, Any]] = []
    for record in records:
        executable = copy.deepcopy(dict(record))
        executable.pop("input_description", None)
        projected.append(executable)
    return projected


def _materializer_comparable_result(result: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "execution_input_paths": copy.deepcopy(result.get("execution_input_paths")),
        "resolved_components": copy.deepcopy(result.get("resolved_components", [])),
        "unresolved_components": copy.deepcopy(result.get("unresolved_components", [])),
        "component_values_by_sample": copy.deepcopy(
            result.get("component_values_by_sample", {})
        ),
        "proxy_values_by_sample": copy.deepcopy(
            result.get("proxy_values_by_sample", {})
        ),
    }


def _remap_record_keyed_object(
    value: Mapping[str, Any],
    alias_to_original: Mapping[str, str],
) -> dict[str, Any]:
    remapped: dict[str, Any] = {}
    for alias, item in value.items():
        original = alias_to_original.get(str(alias))
        if original is None:
            raise ValueError(f"materializer_opaque_id_not_returned:{alias}")
        remapped[original] = copy.deepcopy(item)
    return remapped


def _file_label(value: str) -> str:
    normalized = "".join(
        character if character.isalnum() else "-" for character in value
    ).strip("-")
    return normalized or "execution"
