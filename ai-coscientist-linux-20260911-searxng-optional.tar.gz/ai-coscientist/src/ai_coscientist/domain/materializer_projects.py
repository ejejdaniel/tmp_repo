from __future__ import annotations

import copy
import hashlib
import json
import mimetypes
import os
import re
import shutil
import subprocess
import tempfile
import time

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ai_coscientist.common.artifacts import ArtifactStore
from ai_coscientist.common.capabilities import (
    CapabilityRegistry,
    ManagedRouteBrokerSessions,
)
from ai_coscientist.common.development import DevelopmentProjectStore
from ai_coscientist.common.observations import ObservationStore
from ai_coscientist.common.routes import Route
from ai_coscientist.common.text_pages import read_text_page

from .computational_property_protocol import (
    validate_computational_property_protocol,
)
from .computational_property_result import (
    validate_computational_property_result,
)
from .materializer import (
    _materializer_process_timeout_seconds,
    _validate_protocol_execution_result,
    _validate_proxy_result,
)
from .prepared_evaluation import prepared_source_ref_schema, validate_prepared_source_ref


_SPEC_KINDS = frozenset({"proxy_formula_candidate", "computational_property_protocol"})
_EXECUTION_WORKSPACE_REF = re.compile(
    r"materializer_execution_workspace:([0-9a-f]{32})"
)
_MAX_EXECUTION_INVENTORY_ENTRIES = 500
_MAX_EXECUTION_READ_LINES = 2_000


@dataclass
class MaterializerProjectExecutor:
    """Execute one immutable multi-file implementation without owning science."""

    artifacts: ArtifactStore
    observations: ObservationStore
    projects: DevelopmentProjectStore
    run_root: Path
    records_for_formula: Callable[..., Sequence[Mapping[str, Any]]]
    managed_route_brokers: ManagedRouteBrokerSessions | None = None
    capability_registry: CapabilityRegistry | None = None
    timeout_seconds: float = 300.0

    def routes(self) -> tuple[Route, ...]:
        return (
            Route(
                name="scientific_materializer_run_project",
                description=(
                    "Execute one immutable multi-file, potentially multi-language "
                    "development_project_snapshot against one exact Formula or "
                    "Protocol. The project reads a JSON job and writes a JSON result "
                    "through environment-provided paths. Exact pending or approved "
                    "Routes remain in their own managed environments behind the "
                    "language-neutral Route broker."
                    " Optional resume_from copies only selected runtime files from "
                    "a retained execution of the same project, never its old code "
                    "or completion receipt. Inspect files and assess compatibility "
                    "before selecting them; hashes are computed by Runtime."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "spec_artifact_ref": {"type": "string"},
                        "project_snapshot_ref": {"type": "string"},
                        "prepared_source_ref": prepared_source_ref_schema(),
                        "input_bindings": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "input_id": {"type": "string"},
                                    "artifact_ref": {"type": "string"},
                                },
                                "required": ["input_id", "artifact_ref"],
                                "additionalProperties": False,
                            },
                        },
                        "max_route_calls": {
                            "type": "integer",
                            "minimum": 0,
                            "maximum": 10000,
                        },
                        "resume_from": {
                            "type": "object",
                            "properties": {
                                "execution_workspace_ref": {"type": "string"},
                                "relative_paths": {
                                    "type": "array", "minItems": 1,
                                    "uniqueItems": True,
                                    "items": {"type": "string", "minLength": 1},
                                },
                            },
                            "required": ["execution_workspace_ref", "relative_paths"],
                            "additionalProperties": False,
                        },
                    },
                    "required": [
                        "spec_artifact_ref",
                        "project_snapshot_ref",
                        "input_bindings",
                        "max_route_calls",
                    ],
                    "additionalProperties": False,
                },
                handler=self.execute,
                skill_ids=("materializer",),
            ),
        )

    def execute(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        spec_ref = str(arguments.get("spec_artifact_ref") or "").strip()
        snapshot_ref = str(arguments.get("project_snapshot_ref") or "").strip()
        source_ref = (validate_prepared_source_ref(arguments["prepared_source_ref"])
                      if "prepared_source_ref" in arguments else None)
        spec_artifact = self.artifacts.read(spec_ref)
        spec_kind = str(spec_artifact.get("artifact_kind") or "")
        if spec_kind not in _SPEC_KINDS:
            raise ValueError(f"materializer_project_spec_kind_invalid:{spec_kind}")
        spec = spec_artifact.get("machine_payload")
        if not isinstance(spec, Mapping):
            raise ValueError(f"artifact_machine_payload_required:{spec_ref}")
        if spec_kind == "computational_property_protocol":
            if source_ref is not None:
                raise ValueError("protocol_uses_input_bindings_not_prepared_source_ref")
            validate_computational_property_protocol(spec)

        (
            snapshot,
            dependencies,
            route_refs,
            max_route_calls,
            environment_descriptor,
        ) = self._execution_contract(
            spec_ref=spec_ref,
            snapshot_ref=snapshot_ref,
            raw_max_route_calls=arguments.get("max_route_calls"),
        )

        bindings, bound_inputs = self._input_bindings(
            spec_kind=spec_kind,
            spec=spec,
            raw=arguments.get("input_bindings"),
        )
        spec_dependencies = {
            str(ref) for ref in spec_artifact.get("depends_on") or ()
        }
        authorized_input_dependencies = dependencies | spec_dependencies
        missing_dependencies = sorted(
            binding["artifact_ref"]
            for binding in bindings
            if binding["artifact_ref"] not in authorized_input_dependencies
        )
        if missing_dependencies:
            raise ValueError(
                "materializer_project_input_dependencies_required:"
                f"{missing_dependencies}"
            )

        job, expected_ids = self._job(
            spec_ref=spec_ref,
            spec_kind=spec_kind,
            spec=spec,
            bindings=bindings,
            bound_inputs=bound_inputs,
            prepared_source_ref=source_ref,
        )
        try:
            execution = self._execute_once(
                snapshot_ref=snapshot_ref,
                snapshot=snapshot,
                job=job,
                spec_kind=spec_kind,
                spec=spec,
                expected_ids=expected_ids,
                route_refs=route_refs,
                max_route_calls=max_route_calls,
                environment_descriptor=environment_descriptor,
                resume_from=arguments.get("resume_from"),
            )
        except (RuntimeError, ValueError) as exc:
            marker = f"project_snapshot_ref={snapshot_ref}:"
            if marker in str(exc):
                raise
            raise type(exc)(
                "materializer_project_attempt_failed:"
                f"{marker}{exc}"
            ) from exc

        namespace = (
            "materializer-project" if spec_kind == "proxy_formula_candidate"
            else "materializer-protocol-project"
        )
        if execution.get("status") in {
            "materializer_project_execution_interrupted", "tool_error",
        }:
            result = {key: value for key, value in execution.items()
                      if key != "execution_workspace"}
            if result["status"] == "tool_error":
                result["reason"] = (
                    "materializer_project_attempt_failed:"
                    f"project_snapshot_ref={snapshot_ref}:{result['reason']}"
                )
            else:
                result.update(spec_artifact_ref=spec_ref, implementation_ref=snapshot_ref)
            observation = self.observations.publish_with_ref(
                namespace=namespace,
                result_factory=lambda _ref: result,
                status=str(result["status"]),
                metadata={
                    "implementation_ref": snapshot_ref,
                    "formula_artifact_ref" if spec_kind == "proxy_formula_candidate"
                    else "protocol_artifact_ref": spec_ref,
                    "input_bindings": copy.deepcopy(bindings),
                    **({"prepared_source_ref": source_ref} if source_ref is not None else {}),
                    "execution_workspace": execution["execution_workspace"],
                },
            )
            return {**result, "observation_ref": observation["observation_ref"]}

        def build_result(observation_ref: str) -> Mapping[str, Any]:
            raw = execution["result"]
            if spec_kind == "proxy_formula_candidate":
                return {
                    "artifact_kind": ("quantitative_proxy_materialization_result"),
                    "materialization_status": "complete",
                    "execution_input_paths": raw["execution_input_paths"],
                    "resolved_components": raw["resolved_components"],
                    "unresolved_components": raw["unresolved_components"],
                    "implementation_ref": snapshot_ref,
                    "execution_observation_refs": [observation_ref],
                    "component_values_by_sample": raw["component_values_by_sample"],
                    "proxy_values_by_sample": raw["proxy_values_by_sample"],
                }
            result = {
                "artifact_kind": "computational_property_result",
                "protocol_artifact_ref": spec_ref,
                "output_id": raw["output_id"],
                "value": copy.deepcopy(raw["value"]),
                "unit": raw["unit"],
                "implementation_ref": snapshot_ref,
                "execution_observation_refs": [observation_ref],
            }
            validate_computational_property_result(result)
            return result

        metadata = {
            "implementation_ref": snapshot_ref,
            "input_bindings": copy.deepcopy(bindings),
            **({"prepared_source_ref": source_ref} if source_ref is not None else {}),
            "deterministic_replay": False,
            "replay_count": 1,
            "max_route_calls": max_route_calls,
            "process_evidence": execution["process_evidence"],
            "managed_route_calls": execution["managed_route_calls"],
            "execution_environment": copy.deepcopy(environment_descriptor),
            "execution_workspace": execution["execution_workspace"],
        }
        metadata[
            "formula_artifact_ref"
            if spec_kind == "proxy_formula_candidate"
            else "protocol_artifact_ref"
        ] = spec_ref

        observation = self.observations.publish_with_ref(
            namespace=namespace,
            result_factory=build_result,
            metadata=metadata,
        )
        return {
            "status": "materializer_project_execution_complete",
            "observation_ref": observation["observation_ref"],
            "spec_artifact_ref": spec_ref,
            "implementation_ref": snapshot_ref,
            "replay_count": 1,
            "deterministic_replay": False,
            "managed_route_call_count": len(execution["managed_route_calls"]),
        }

    def execution_inventory(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        workspace_ref = str(arguments.get("execution_workspace_ref") or "").strip()
        requested = str(arguments.get("relative_path") or "").strip()
        max_entries = _bounded_int(
            arguments.get("max_entries"),
            default=200,
            minimum=1,
            maximum=_MAX_EXECUTION_INVENTORY_ENTRIES,
        )
        project_root, snapshot_files = self._execution_workspace(workspace_ref)
        requested_path = _execution_relative_path(
            project_root,
            requested,
            allow_root=True,
        )
        if not requested_path.exists():
            raise ValueError(
                "materializer_execution_workspace_path_missing:"
                f"{requested or '.'}"
            )
        paths = _execution_files(requested_path)
        all_entries = [
            _execution_file_entry(
                path,
                project_root=project_root,
                snapshot_files=snapshot_files,
            )
            for path in paths
        ]
        all_entries.sort(key=_execution_inventory_entry_order)
        entries = all_entries[:max_entries]
        execution = self._latest_workspace_execution(workspace_ref)
        if execution is None:
            raise ValueError("materializer_execution_observation_missing:"
                             "restore the exact execution record before inspection")
        result = {
            "status": "materializer_execution_workspace_inventory_ready",
            "execution_workspace_ref": workspace_ref,
            "execution_observation_ref": execution["observation_ref"],
            "requested_relative_path": requested,
            "entry_count": len(entries),
            "total_file_count": len(paths),
            "truncated": len(paths) > len(entries),
            "entries": entries,
        }
        observation = self.observations.publish_with_ref(
            namespace="materializer-execution-inventory",
            status=result["status"],
            result_factory=lambda _ref: result,
            metadata={"execution_observation_ref": execution["observation_ref"]},
        )
        return {**result, "observation_ref": observation["observation_ref"]}

    def _latest_workspace_execution(self, workspace_ref: str) -> Mapping[str, Any] | None:
        execution_id = workspace_ref.removeprefix("materializer_execution_workspace:")
        for ref in reversed(self.observations.ordered_refs()):
            stored = self.observations.read(ref)
            if stored.get("namespace") not in {
                "materializer-project", "materializer-protocol-project",
            }:
                continue
            workspace = str(stored.get("metadata", {}).get("execution_workspace") or "")
            if workspace.replace("\\", "/").rstrip("/").rsplit("/", 1)[-1] == execution_id:
                return stored
        return None

    def execution_read(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        workspace_ref = str(arguments.get("execution_workspace_ref") or "").strip()
        relative = str(arguments.get("relative_path") or "").strip()
        if not relative:
            raise ValueError("materializer_execution_workspace_read_path_required")
        offset = _bounded_int(
            arguments.get("line_offset"),
            default=0,
            minimum=0,
            maximum=10**9,
        )
        limit = _bounded_int(
            arguments.get("line_limit"),
            default=200,
            minimum=1,
            maximum=_MAX_EXECUTION_READ_LINES,
        )
        project_root, snapshot_files = self._execution_workspace(workspace_ref)
        path = _execution_relative_path(project_root, relative, allow_root=False)
        if not path.is_file() or path.is_symlink():
            raise ValueError(
                "materializer_execution_workspace_file_missing:"
                f"{relative}"
            )
        entry = _execution_file_entry(
            path,
            project_root=project_root,
            snapshot_files=snapshot_files,
        )
        if not entry["text_likely"]:
            return {
                "status": "materializer_execution_workspace_binary",
                "execution_workspace_ref": workspace_ref,
                "relative_path": entry["path"],
                "size_bytes": entry["size_bytes"],
                "media_type": entry["media_type"],
                "runtime_state": entry["runtime_state"],
            }
        return {
            "status": "materializer_execution_workspace_page_ready",
            "execution_workspace_ref": workspace_ref,
            "relative_path": entry["path"],
            "runtime_state": entry["runtime_state"],
            **read_text_page(path, offset=offset, limit=limit, errors="replace"),
        }

    def resolve_development_execution(self, project_id: str, workspace_ref: str) -> Path:
        """Resolve retained C4 data without copying it into the authoring project."""
        root, _ = self._execution_workspace(workspace_ref)
        identity = _read_json_object(root.parent / "control" / "execution.json")
        snapshot = self.projects.snapshot_payload(str(identity["snapshot_ref"]))
        if snapshot["project_id"] != project_id:
            raise ValueError("materializer_execution_workspace_requires_same_project")
        if self._latest_workspace_execution(workspace_ref) is None:
            raise ValueError("materializer_execution_observation_missing")
        # A directory mount must not expose another directory through a link.
        if any(path.is_symlink() or path.is_junction() for path in (root, *root.rglob("*"))):
            raise ValueError("materializer_execution_workspace_symlink_forbidden")
        return root

    def read_raw_output(self, observation_ref: str) -> Mapping[str, Any]:
        """Read exact completed output without executing or copying control files."""
        observation = self.observations.read(observation_ref)
        if (
            observation.get("namespace") not in {"materializer-project", "materializer-protocol-project"}
            or observation.get("status") != "code_artifact_executed"
        ):
            raise ValueError("observation_raw_output_requires_completed_project")
        metadata = observation["metadata"]
        execution_root = Path(str(metadata.get("execution_workspace") or "")).resolve()
        workspace_ref = "materializer_execution_workspace:" + execution_root.name
        project_root, _ = self._execution_workspace(workspace_ref)
        if execution_root != project_root.parent:
            raise ValueError("observation_raw_output_workspace_mismatch")
        control_root = execution_root / "control"
        result_path = control_root / "result.json"
        identity_path = control_root / "execution.json"
        completion_path = control_root / "completion.json"
        for path in (execution_root, control_root, result_path, identity_path, completion_path):
            if path.is_symlink() or path.is_junction():
                raise ValueError("observation_raw_output_link_forbidden")
        identity = _read_json_object(identity_path)
        completion = _read_json_object(completion_path)
        snapshot_ref = metadata.get("implementation_ref")
        if identity.get("snapshot_ref") != snapshot_ref or completion.get("snapshot_ref") != snapshot_ref:
            raise ValueError("observation_raw_output_snapshot_mismatch")
        if completion.get("process_evidence") != metadata.get("process_evidence"):
            raise ValueError("observation_raw_output_execution_mismatch")
        data = result_path.read_bytes()
        if hashlib.sha256(data).hexdigest() != completion.get("result_sha256"):
            raise ValueError("observation_raw_output_hash_mismatch")
        raw = json.loads(data)
        if not isinstance(raw, Mapping):
            raise ValueError("observation_raw_output_must_be_object")
        return raw

    def _execution_workspace(
        self,
        workspace_ref: str,
    ) -> tuple[Path, Mapping[str, bytes]]:
        match = _EXECUTION_WORKSPACE_REF.fullmatch(str(workspace_ref))
        if match is None:
            raise ValueError("materializer_execution_workspace_ref_invalid")
        execution_id = match.group(1)
        execution_root = (
            self.run_root.resolve() / "workspace" / "mpr" / execution_id
        ).resolve()
        expected_root = (self.run_root.resolve() / "workspace" / "mpr").resolve()
        if not execution_root.is_relative_to(expected_root):
            raise ValueError("materializer_execution_workspace_ref_escaped")
        identity_path = execution_root / "control" / "execution.json"
        project_root = execution_root / "project"
        if not identity_path.is_file() or not project_root.is_dir():
            raise ValueError("materializer_execution_workspace_missing")
        identity = _read_json_object(identity_path)
        snapshot_hash = str(identity.get("snapshot_hash") or "")
        job_hash = str(identity.get("job_sha256") or "")
        expected_id = _execution_id(identity)
        if expected_id != execution_id:
            raise ValueError("materializer_execution_workspace_identity_invalid")
        snapshot_ref = str(identity.get("snapshot_ref") or "")
        if self.projects.snapshot_payload(snapshot_ref)["snapshot_hash"] != snapshot_hash:
            raise ValueError("materializer_execution_snapshot_identity_invalid")
        return project_root, self.projects.snapshot_files(snapshot_ref)

    def execute_formula_records(
        self,
        *,
        implementation_ref: str,
        formula_artifact_ref: str,
        records: Sequence[Mapping[str, Any]],
        max_route_calls: int,
    ) -> dict[str, Any]:
        """Replay one frozen project implementation on caller-owned records."""
        formula_ref = str(formula_artifact_ref).strip()
        snapshot_ref = str(implementation_ref).strip()
        formula_artifact = self.artifacts.read(formula_ref)
        if formula_artifact.get("artifact_kind") != "proxy_formula_candidate":
            raise ValueError(
                "materializer_project_formula_kind_invalid:"
                f"{formula_artifact.get('artifact_kind')}"
            )
        formula = formula_artifact.get("machine_payload")
        if not isinstance(formula, Mapping):
            raise ValueError(f"artifact_machine_payload_required:{formula_ref}")
        (
            snapshot,
            _dependencies,
            route_refs,
            route_call_quota,
            environment_descriptor,
        ) = self._execution_contract(
            spec_ref=formula_ref,
            snapshot_ref=snapshot_ref,
            raw_max_route_calls=max_route_calls,
        )
        frozen_records = [copy.deepcopy(dict(item)) for item in records]
        job = {
            "contract_version": 1,
            "specification": {
                "artifact_ref": formula_ref,
                "artifact_kind": "proxy_formula_candidate",
                "machine_payload": copy.deepcopy(dict(formula)),
            },
            "input_bindings": [],
            "inputs": {},
            "mode": "formula_records",
            "records": frozen_records,
        }
        execution = self._execute_once(
            snapshot_ref=snapshot_ref,
            snapshot=snapshot,
            job=job,
            spec_kind="proxy_formula_candidate",
            spec=formula,
            expected_ids=[str(item["id"]) for item in frozen_records],
            route_refs=route_refs,
            max_route_calls=route_call_quota,
            environment_descriptor=environment_descriptor,
        )
        if execution.get("status") == "tool_error":
            raise RuntimeError(str(execution["reason"]))
        return execution

    def _execution_contract(
        self,
        *,
        spec_ref: str,
        snapshot_ref: str,
        raw_max_route_calls: Any,
    ) -> tuple[
        Mapping[str, Any],
        set[str],
        tuple[str, ...],
        int,
        Mapping[str, Any],
    ]:
        snapshot = self.projects.snapshot_payload(snapshot_ref)
        environment_ref = str(snapshot.get("environment_ref") or "")
        dependencies = {str(ref) for ref in snapshot.get("dependency_refs") or ()}
        if spec_ref not in dependencies:
            raise ValueError(
                f"materializer_project_spec_dependency_required:{spec_ref}"
            )
        available_route_refs = tuple(
            sorted(
                ref
                for ref in dependencies
                if ref.startswith(("approved_route:", "pending_route:"))
            )
        )
        if (
            isinstance(raw_max_route_calls, bool)
            or not isinstance(raw_max_route_calls, int)
            or not 0 <= raw_max_route_calls <= 10_000
        ):
            raise ValueError("max_route_calls_must_be_integer_0_to_10000")
        if not available_route_refs and raw_max_route_calls != 0:
            raise ValueError(
                "max_route_calls_requires_managed_route_dependency:"
                "bind_each_selected_exact_route_ref_to_the_development_project_"
                "then_checkpoint_and_execute_the_new_snapshot"
            )
        route_refs = available_route_refs if raw_max_route_calls > 0 else tuple()
        if route_refs and self.managed_route_brokers is None:
            raise ValueError("managed_route_broker_unavailable")

        if self.capability_registry is None:
            environment_descriptor: Mapping[str, Any] = {
                "environment_ref": environment_ref,
                "environment_scope": "host",
                "runtime_kind": "host",
            }
        else:
            expected_environment_ref = (
                self.capability_registry.default_project_environment_ref
            )
            if environment_ref != expected_environment_ref:
                raise ValueError(
                    "materializer_project_runtime_environment_stale:"
                    f"snapshot={environment_ref}:runtime={expected_environment_ref}"
                )
            environment_descriptor = {
                "environment_ref": expected_environment_ref,
                "environment_scope": "runtime_default",
                "runtime_kind": (
                    "docker"
                    if expected_environment_ref.startswith("docker-image:")
                    else "host"
                ),
            }
        return (
            snapshot,
            dependencies,
            route_refs,
            raw_max_route_calls,
            environment_descriptor,
        )

    def _input_bindings(
        self,
        *,
        spec_kind: str,
        spec: Mapping[str, Any],
        raw: Any,
    ) -> tuple[list[dict[str, str]], dict[str, Mapping[str, Any]]]:
        if not isinstance(raw, Sequence) or isinstance(raw, (str, bytes)):
            raise ValueError("materializer_project_input_bindings_must_be_array")
        if spec_kind == "proxy_formula_candidate":
            if raw:
                raise ValueError(
                    "formula_materializer_project_input_bindings_must_be_empty"
                )
            return [], {}
        required_ids = {
            str(item.get("input_id") or "")
            for item in spec.get("required_inputs") or ()
            if isinstance(item, Mapping)
        }
        bindings: list[dict[str, str]] = []
        inputs: dict[str, Mapping[str, Any]] = {}
        for index, item in enumerate(raw):
            if not isinstance(item, Mapping) or set(item) != {
                "input_id",
                "artifact_ref",
            }:
                raise ValueError(f"materializer_project_input_binding_invalid:{index}")
            input_id = str(item["input_id"]).strip()
            artifact_ref = str(item["artifact_ref"]).strip()
            if input_id in inputs:
                raise ValueError(
                    f"materializer_project_input_binding_duplicate:{input_id}"
                )
            stored = self.artifacts.read(artifact_ref)
            payload = stored.get("machine_payload")
            if not isinstance(payload, Mapping):
                raise ValueError(f"artifact_machine_payload_required:{artifact_ref}")
            bindings.append({"input_id": input_id, "artifact_ref": artifact_ref})
            inputs[input_id] = copy.deepcopy(dict(payload))
        if set(inputs) != required_ids:
            raise ValueError(
                "materializer_project_input_ids_mismatch:"
                f"required={sorted(required_ids)}:actual={sorted(inputs)}"
            )
        return bindings, inputs

    def _job(
        self,
        *,
        spec_ref: str,
        spec_kind: str,
        spec: Mapping[str, Any],
        bindings: Sequence[Mapping[str, str]],
        bound_inputs: Mapping[str, Mapping[str, Any]],
        prepared_source_ref: str | None = None,
    ) -> tuple[dict[str, Any], list[str]]:
        job = {
            "contract_version": 1,
            "specification": {
                "artifact_ref": spec_ref,
                "artifact_kind": spec_kind,
                "machine_payload": copy.deepcopy(dict(spec)),
            },
            "input_bindings": copy.deepcopy(list(bindings)),
            "inputs": copy.deepcopy(dict(bound_inputs)),
        }
        if spec_kind == "proxy_formula_candidate":
            selected_records = (
                self.records_for_formula(spec_ref, prepared_source_ref=prepared_source_ref)
                if prepared_source_ref is not None else self.records_for_formula(spec_ref)
            )
            records = [
                copy.deepcopy(dict(item)) for item in selected_records
            ]
            if prepared_source_ref is not None:
                # Include source identity in the existing job hash, even for equal rows.
                job["input_bindings"] = [{"input_id": "records", "artifact_ref": prepared_source_ref}]
            job["mode"] = "formula_records"
            job["records"] = records
            return job, [str(item["id"]) for item in records]
        job["mode"] = "computational_protocol"
        job["records"] = []
        return job, []

    def _execute_once(
        self,
        *,
        snapshot_ref: str,
        snapshot: Mapping[str, Any],
        job: Mapping[str, Any],
        spec_kind: str,
        spec: Mapping[str, Any],
        expected_ids: Sequence[str],
        route_refs: Sequence[str],
        max_route_calls: int,
        environment_descriptor: Mapping[str, Any],
        resume_from: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        execution_root, job_path, result_path, completion_path = (
            self._prepare_execution_workspace(
                snapshot_ref=snapshot_ref,
                snapshot=snapshot,
                job=job,
                resume_from=resume_from,
            )
        )
        completed_execution = self._completed_execution(
            completion_path=completion_path,
            result_path=result_path,
            spec_kind=spec_kind,
            spec=spec,
            expected_ids=expected_ids,
            records=job["records"],
        )
        if completed_execution is not None:
            return {
                **completed_execution,
                "execution_workspace": str(execution_root),
            }

        result_path.unlink(missing_ok=True)
        record_binding: dict[str, Any] | None = None
        binding = None
        if route_refs:
            assert self.managed_route_brokers is not None
            binding = self.managed_route_brokers.create(
                route_refs=route_refs,
                caller_skill_id="materializer",
                require_code_callable=True,
                max_route_calls=max_route_calls,
                timeout_seconds=max(1.0, self.timeout_seconds - 15.0),
            )
            record_binding = binding
        started = time.monotonic()
        try:
            evidence = self._execute_process(
                execution_root=execution_root,
                snapshot=snapshot,
                job_path=job_path,
                result_path=result_path,
                binding=binding,
                environment_descriptor=environment_descriptor,
                timeout_seconds=_materializer_process_timeout_seconds(
                    self.timeout_seconds,
                    max_route_calls=max_route_calls,
                ),
            )
        except subprocess.TimeoutExpired as exc:
            return {
                "status": "materializer_project_execution_interrupted",
                "timed_out": True,
                "interruption_reason": "timeout",
                "execution_workspace_ref": (
                    f"materializer_execution_workspace:{execution_root.name}"
                ),
                "duration_seconds": round(time.monotonic() - started, 6),
                "stdout_tail": _bounded_process_text(exc.output),
                "stderr_tail": _bounded_process_text(exc.stderr),
                "execution_workspace": str(execution_root),
            }
        except (OSError, RuntimeError, ValueError) as exc:
            return {"status": "tool_error", "reason": str(exc),
                    "execution_workspace": str(execution_root)}
        try:
            raw = _read_result(result_path)
            if spec_kind == "proxy_formula_candidate":
                validated = _validate_proxy_result(raw, expected_ids, records=job["records"])
            else:
                validated = _validate_protocol_execution_result(raw, spec)
        except (OSError, RuntimeError, ValueError) as exc:
            return {"status": "tool_error", "reason": str(exc),
                    "execution_workspace": str(execution_root)}
        managed_calls: list[dict[str, Any]] = []
        if record_binding is not None:
            assert self.managed_route_brokers is not None
            ledger = self.managed_route_brokers.read_ledger(
                Path(record_binding["binding_path"])
            )
            managed_calls = [
                copy.deepcopy(dict(item["receipt"]))
                for item in ledger["calls"]
                if isinstance(item, Mapping)
                and isinstance(item.get("receipt"), Mapping)
            ]
        completion = {
            "snapshot_ref": snapshot_ref,
            "result_sha256": hashlib.sha256(result_path.read_bytes()).hexdigest(),
            "process_evidence": [evidence],
            "managed_route_calls": managed_calls,
        }
        _write_json(completion_path, completion)
        return {
            "result": validated,
            "process_evidence": [evidence],
            "managed_route_calls": managed_calls,
            "execution_workspace": str(execution_root),
        }

    def _prepare_execution_workspace(
        self,
        *,
        snapshot_ref: str,
        snapshot: Mapping[str, Any],
        job: Mapping[str, Any],
        resume_from: Mapping[str, Any] | None = None,
    ) -> tuple[Path, Path, Path, Path]:
        snapshot_hash = str(snapshot.get("snapshot_hash") or "")
        if len(snapshot_hash) != 64:
            raise ValueError("materializer_project_snapshot_hash_invalid")
        job_body = _json_bytes(job)
        job_hash = hashlib.sha256(job_body).hexdigest()
        expected_identity = {
            "snapshot_ref": snapshot_ref,
            "snapshot_hash": snapshot_hash,
            "job_sha256": job_hash,
            "environment_ref": str(snapshot.get("environment_ref") or ""),
        }
        workspace_root = self.run_root.resolve() / "workspace" / "mpr"
        workspace_root.mkdir(parents=True, exist_ok=True)
        snapshot_files = self.projects.snapshot_files(snapshot_ref)
        # Stage exact bytes before deriving identity. Changed seed contents must
        # never collide with a previously completed execution of the new code.
        with tempfile.TemporaryDirectory(prefix=".stage-", dir=workspace_root) as temporary:
            staged = Path(temporary) / "execution"
            staged_project = staged / "project"
            staged_control = staged / "control"
            staged_project.mkdir(parents=True)
            staged_control.mkdir()
            if resume_from is not None:
                expected_identity["resume_from"] = self._stage_resume_files(
                    resume_from, snapshot=snapshot, snapshot_files=snapshot_files,
                    destination_root=staged_project,
                )
            execution_root = workspace_root / _execution_id(expected_identity)
            control_root = execution_root / "control"
            identity_path = control_root / "execution.json"
            if identity_path.is_file():
                if _read_json_object(identity_path) != expected_identity:
                    raise ValueError("materializer_project_workspace_identity_conflict")
            else:
                if execution_root.exists():
                    raise ValueError("materializer_project_workspace_incomplete")
                for relative, body in snapshot_files.items():
                    destination = staged_project / Path(relative)
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    destination.write_bytes(body)
                (staged_control / "job.json").write_bytes(job_body)
                _write_json(staged_control / "execution.json", expected_identity)
                staged.rename(execution_root)
        job_path = control_root / "job.json"
        if job_path.is_file():
            if job_path.read_bytes() != job_body:
                raise ValueError("materializer_project_workspace_job_conflict")
        else:
            job_path.write_bytes(job_body)
        return (
            execution_root,
            job_path,
            control_root / "result.json",
            control_root / "completion.json",
        )

    def _stage_resume_files(
        self,
        resume_from: Mapping[str, Any],
        *,
        snapshot: Mapping[str, Any],
        snapshot_files: Mapping[str, bytes],
        destination_root: Path,
    ) -> dict[str, Any]:
        if not isinstance(resume_from, Mapping) or set(resume_from) != {
            "execution_workspace_ref", "relative_paths",
        }:
            raise ValueError("materializer_resume_from_invalid")
        workspace_ref = str(resume_from["execution_workspace_ref"])
        source_root, _ = self._execution_workspace(workspace_ref)
        source_identity = _read_json_object(source_root.parent / "control" / "execution.json")
        source_snapshot = self.projects.snapshot_payload(source_identity["snapshot_ref"])
        if source_snapshot["project_id"] != snapshot["project_id"]:
            raise ValueError("materializer_resume_requires_same_project")
        source_observation = self._latest_workspace_execution(workspace_ref)
        if source_observation is None:
            raise ValueError("materializer_resume_execution_observation_required")
        paths = resume_from["relative_paths"]
        if not isinstance(paths, list) or not paths or not all(isinstance(p, str) for p in paths):
            raise ValueError("materializer_resume_relative_paths_required")
        files = []
        selected: set[str] = set()
        for relative in paths:
            source = _execution_relative_path(source_root, relative, allow_root=False)
            canonical = source.relative_to(source_root).as_posix()
            if not source.is_file() or source.is_symlink():
                raise ValueError(f"materializer_resume_file_missing:{relative}")
            if canonical in selected:
                raise ValueError(f"materializer_resume_duplicate_path:{canonical}")
            selected.add(canonical)
            if any(
                canonical == name or canonical.startswith(name + "/")
                or name.startswith(canonical + "/") for name in snapshot_files
            ):
                raise ValueError(f"materializer_resume_would_replace_snapshot_file:{canonical}")
            destination = destination_root / canonical
            destination.parent.mkdir(parents=True, exist_ok=True)
            before = source.stat()
            shutil.copyfile(source, destination)
            after = source.stat()
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise ValueError(f"materializer_resume_source_changed_during_copy:{canonical}")
            with destination.open("rb") as handle:
                digest = hashlib.file_digest(handle, "sha256").hexdigest()
            files.append({"path": canonical, "size_bytes": after.st_size, "sha256": digest})
        return {
            "execution_workspace_ref": workspace_ref,
            "execution_observation_ref": source_observation["observation_ref"],
            "files": sorted(files, key=lambda item: item["path"]),
        }

    def _completed_execution(
        self,
        *,
        completion_path: Path,
        result_path: Path,
        spec_kind: str,
        spec: Mapping[str, Any],
        expected_ids: Sequence[str],
        records: Sequence[Mapping[str, Any]],
    ) -> dict[str, Any] | None:
        if not completion_path.is_file():
            return None
        completion = _read_json_object(completion_path)
        required = {
            "snapshot_ref",
            "result_sha256",
            "process_evidence",
            "managed_route_calls",
        }
        if set(completion) != required or not result_path.is_file():
            raise ValueError("materializer_project_completion_receipt_invalid")
        actual_hash = hashlib.sha256(result_path.read_bytes()).hexdigest()
        if completion["result_sha256"] != actual_hash:
            raise ValueError("materializer_project_completed_result_changed")
        raw = _read_result(result_path)
        if spec_kind == "proxy_formula_candidate":
            validated = _validate_proxy_result(raw, expected_ids, records=records)
        else:
            validated = _validate_protocol_execution_result(raw, spec)
        return {
            "result": validated,
            "process_evidence": copy.deepcopy(completion["process_evidence"]),
            "managed_route_calls": copy.deepcopy(completion["managed_route_calls"]),
        }

    def _execute_process(
        self,
        *,
        execution_root: Path,
        snapshot: Mapping[str, Any],
        job_path: Path,
        result_path: Path,
        binding: Mapping[str, Any] | None,
        environment_descriptor: Mapping[str, Any],
        timeout_seconds: float | None = None,
    ) -> dict[str, Any]:
        project_root = execution_root / "project"
        working_directory = project_root
        relative = str(snapshot["working_directory"])
        if relative != ".":
            working_directory = (project_root / relative).resolve()
        if (
            not working_directory.is_relative_to(project_root)
            or not working_directory.is_dir()
        ):
            raise ValueError("materializer_project_working_directory_invalid")
        environment_ref = str(environment_descriptor["environment_ref"])
        started = time.monotonic()
        timeout = (
            float(self.timeout_seconds)
            if timeout_seconds is None
            else float(timeout_seconds)
        )
        route_call_timeout = max(
            1.0,
            min(float(self.timeout_seconds), 86_400.0),
        )
        if self.capability_registry is None:
            environment = os.environ.copy()
            environment.update(
                {
                    "AI_COSCIENTIST_MATERIALIZER_JOB": str(job_path),
                    "AI_COSCIENTIST_MATERIALIZER_RESULT": str(result_path),
                    "AI_COSCIENTIST_ROUTE_BROKER_COMMAND_JSON": json.dumps(
                        list(binding["command_argv_prefix"]) if binding else [],
                        ensure_ascii=False,
                    ),
                    "AI_COSCIENTIST_ROUTE_BROKER_MODE": (
                        str(binding.get("mode")) if binding else "disabled"
                    ),
                }
            )
            completed = subprocess.run(
                list(snapshot["entry_command"]),
                cwd=str(working_directory),
                env=environment,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
                check=False,
            )
        else:
            bridge = None
            if binding is not None:
                assert self.managed_route_brokers is not None
                bridge = self.managed_route_brokers.project_bridge(
                    Path(str(binding["binding_path"])),
                    shared_control_root=execution_root / "control",
                    timeout_seconds=route_call_timeout,
                )
            docker_runtime = (
                str(environment_descriptor.get("runtime_kind") or "") == "docker"
            )
            broker_command: list[str] = []
            if bridge is not None:
                if docker_runtime:
                    broker_command = list(bridge.command_argv_prefix)
                else:
                    broker_command = [
                        self.capability_registry.python_executable,
                        str(bridge.client_path),
                        str(bridge.mailbox_root),
                    ]
            environment = {
                "AI_COSCIENTIST_MATERIALIZER_JOB": (
                    "/workspace/control/job.json"
                    if docker_runtime
                    else str(job_path)
                ),
                "AI_COSCIENTIST_MATERIALIZER_RESULT": (
                    "/workspace/control/result.json"
                    if docker_runtime
                    else str(result_path)
                ),
                "AI_COSCIENTIST_ROUTE_BROKER_COMMAND_JSON": (
                    json.dumps(broker_command, ensure_ascii=False)
                    if bridge is not None
                    else "[]"
                ),
                "AI_COSCIENTIST_ROUTE_BROKER_MODE": (
                    str(binding.get("mode")) if binding else "disabled"
                ),
                "AI_COSCIENTIST_ROUTE_BROKER_CLIENT_TIMEOUT": str(
                    route_call_timeout
                ),
            }
            if bridge is None:
                completed = self.capability_registry.execute_project_in_default_environment(
                    project_root=execution_root,
                    entry_command=snapshot["entry_command"],
                    working_directory=(
                        "project"
                        if relative == "."
                        else f"project/{Path(relative).as_posix()}"
                    ),
                    environment=environment,
                    timeout_seconds=timeout,
                )
            else:
                with bridge:
                    completed = self.capability_registry.execute_project_in_default_environment(
                        project_root=execution_root,
                        entry_command=snapshot["entry_command"],
                        working_directory=(
                            "project"
                            if relative == "."
                            else f"project/{Path(relative).as_posix()}"
                        ),
                        environment=environment,
                        timeout_seconds=timeout,
                    )
        evidence = {
            "execution_index": 1,
            "environment_ref": environment_ref,
            "returncode": completed.returncode,
            "duration_seconds": round(time.monotonic() - started, 6),
            "stdout_tail": completed.stdout[-12_000:],
            "stderr_tail": completed.stderr[-12_000:],
        }
        if completed.returncode != 0:
            raise RuntimeError(
                "materializer_project_process_failed:"
                f"returncode={completed.returncode}:"
                f"stderr={completed.stderr[-4000:]}"
            )
        if not result_path.is_file():
            raise RuntimeError("materializer_project_result_missing")
        return evidence


def _read_result(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping) or set(value) != {"result"}:
        raise ValueError("materializer_project_result_envelope_invalid")
    result = value.get("result")
    if not isinstance(result, Mapping):
        raise ValueError("materializer_project_result_must_be_object")
    return copy.deepcopy(dict(result))


def _read_json_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError(f"materializer_project_json_object_required:{path.name}")
    return copy.deepcopy(dict(value))


def _execution_id(identity: Mapping[str, Any]) -> str:
    key = f"{identity['snapshot_hash']}:{identity['job_sha256']}"
    if "resume_from" in identity:
        key += ":" + hashlib.sha256(_json_bytes(identity["resume_from"])).hexdigest()
    return hashlib.sha256(key.encode("ascii")).hexdigest()[:32]


def _json_bytes(value: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n"
    ).encode("utf-8")


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_bytes(_json_bytes(value))
    os.replace(temporary, path)


def _bounded_int(
    value: Any,
    *,
    default: int,
    minimum: int,
    maximum: int,
) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("materializer_execution_integer_invalid")
    if not minimum <= value <= maximum:
        raise ValueError("materializer_execution_integer_out_of_range")
    return value


def _execution_relative_path(
    project_root: Path,
    relative_path: str,
    *,
    allow_root: bool,
) -> Path:
    value = str(relative_path).strip().replace("\\", "/")
    if not value:
        if allow_root:
            return project_root.resolve()
        raise ValueError("materializer_execution_workspace_relative_path_required")
    relative = Path(value)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError("materializer_execution_workspace_path_invalid")
    path = (project_root.resolve() / relative).resolve()
    if not path.is_relative_to(project_root.resolve()):
        raise ValueError("materializer_execution_workspace_path_escaped")
    return path


def _execution_files(root: Path) -> list[Path]:
    if root.is_file() or root.is_symlink():
        return [root]
    files: list[Path] = []
    for current, directory_names, file_names in os.walk(root, followlinks=False):
        current_path = Path(current)
        directory_names[:] = sorted(
            name
            for name in directory_names
            if not (current_path / name).is_symlink()
        )
        for name in sorted(file_names):
            files.append(current_path / name)
    return sorted(files, key=lambda item: item.as_posix())


def _execution_file_entry(
    path: Path,
    *,
    project_root: Path,
    snapshot_files: Mapping[str, bytes],
) -> dict[str, Any]:
    relative = path.relative_to(project_root.resolve()).as_posix()
    if path.is_symlink():
        return {
            "path": relative,
            "kind": "symlink",
            "size_bytes": None,
            "media_type": "application/octet-stream",
            "text_likely": False,
            "runtime_state": "runtime_created",
        }
    size_bytes = path.stat().st_size
    snapshot_body = snapshot_files.get(relative)
    if snapshot_body is None:
        with path.open("rb") as handle:
            sample = handle.read(8192)
        runtime_state = "runtime_created"
    else:
        body = path.read_bytes()
        sample = body[:8192]
        runtime_state = (
            "snapshot_unchanged" if body == snapshot_body else "runtime_modified"
        )
    return {
        "path": relative,
        "kind": "file",
        "size_bytes": size_bytes,
        "media_type": mimetypes.guess_type(path.name)[0]
        or "application/octet-stream",
        "text_likely": _bytes_text_likely(sample),
        "runtime_state": runtime_state,
    }


def _bytes_text_likely(body: bytes) -> bool:
    sample = body[:8192]
    if b"\x00" in sample:
        return False
    try:
        sample.decode("utf-8")
    except UnicodeDecodeError:
        return False
    return True


def _execution_inventory_entry_order(entry: Mapping[str, Any]) -> tuple[Any, ...]:
    state = str(entry.get("runtime_state") or "")
    return (
        0 if state in {"runtime_created", "runtime_modified"} else 1,
        0 if bool(entry.get("text_likely")) else 1,
        str(entry.get("path") or ""),
    )


def _bounded_process_text(value: str | bytes | None, limit: int = 12_000) -> str:
    if value is None:
        return ""
    text = (
        value.decode("utf-8", errors="replace")
        if isinstance(value, bytes)
        else str(value)
    )
    return text[-limit:]
