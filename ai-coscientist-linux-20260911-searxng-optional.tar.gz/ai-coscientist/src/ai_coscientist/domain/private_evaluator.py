from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from ai_coscientist.common.artifacts import ArtifactStore
from ai_coscientist.common.observations import ObservationStore
from ai_coscientist.common.routes import Route

from .source_authority import SourceAuthority


@dataclass
class PrivateProxyEvaluator:
    artifacts: ArtifactStore
    observations: ObservationStore
    source_authority: SourceAuthority | None
    target_resolver: Callable[[Mapping[str, Any], Mapping[str, Any]], Mapping[str, float] | None] | None = None

    def routes(self) -> tuple[Route, ...]:
        return (
            Route(
                name="scientific_private_proxy_evaluate",
                description=(
                    "Compare one exact materialized proxy with its execution-selected dataset's "
                    "target values and return aggregate historical-fit diagnostics only."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "formula_artifact_ref": {"type": "string"},
                        "materialization_artifact_ref": {"type": "string"},
                    },
                    "required": [
                        "formula_artifact_ref",
                        "materialization_artifact_ref",
                    ],
                    "additionalProperties": False,
                },
                handler=self.evaluate,
                skill_ids=("review-scientific-method", "rank-proxy-formula"),
            ),
        )

    def evaluate(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        formula_ref = str(arguments.get("formula_artifact_ref") or "")
        materialization_ref = str(
            arguments.get("materialization_artifact_ref") or ""
        )
        formula_artifact = _artifact(
            self.artifacts, formula_ref, "proxy_formula_candidate"
        )
        materialization_artifact = _artifact(
            self.artifacts,
            materialization_ref,
            "quantitative_proxy_materialization_result",
        )
        if formula_ref not in materialization_artifact.get("depends_on", []):
            raise ValueError("materialization_formula_dependency_mismatch")
        formula = formula_artifact["machine_payload"]
        if formula.get("target_kind") != "final_kpi":
            raise ValueError("private_evaluator_requires_final_kpi_formula")

        materialization = materialization_artifact["machine_payload"]
        proxy_values = materialization.get("proxy_values_by_sample")
        if not isinstance(proxy_values, Mapping):
            raise ValueError("proxy_values_by_sample_required")

        targets = self.target_resolver(formula_artifact, materialization_artifact) if self.target_resolver else None
        if targets is None:
            if self.source_authority is None:
                raise ValueError("private_evaluator_dataset_required")
            private = self.source_authority.private_historical_for_evaluator()
            targets = {str(record["id"]): _finite(record.get("ground_truth_kpi"))
                       for record in private["records"]}
        ids = list(targets)
        if not ids:
            raise ValueError("private_evaluator_records_required")
        if materialization.get("materialization_status") != "complete":
            raise ValueError("private_evaluator_materialization_incomplete")
        if sorted(str(key) for key in proxy_values) != sorted(ids):
            raise ValueError("private_evaluator_sample_ids_mismatch")
        proxies = [_finite(proxy_values[record_id]) for record_id in ids]
        kpis = [_finite(targets[record_id]) for record_id in ids]
        relation = str(formula.get("expected_relation") or "").strip()
        if relation == "higher_proxy_higher_kpi":
            sign = 1.0
        elif relation == "lower_proxy_higher_kpi":
            sign = -1.0
        else:
            raise ValueError(f"unsupported_expected_relation:{relation}")

        tau = _kendall_tau_b(proxies, kpis)
        spearman = _pearson(_average_ranks(proxies), _average_ranks(kpis))
        aggregate = {
            "evaluation_kind": "historical_proxy_calibration",
            "sample_count": len(ids),
            "expected_relation": relation,
            "kendall_tau_b": tau["value"],
            "direction_adjusted_kendall_tau_b": sign * tau["value"],
            "spearman_rho": spearman,
            "direction_adjusted_spearman_rho": sign * spearman,
            "pair_counts": {
                "concordant": tau["concordant_pairs"],
                "discordant": tau["discordant_pairs"],
                "proxy_only_ties": tau["proxy_only_ties"],
                "kpi_only_ties": tau["kpi_only_ties"],
                "joint_ties": tau["joint_ties"],
            },
            "raw_kpi_values_disclosed": False,
        }
        observation = self.observations.publish(
            namespace="private-evaluator",
            result=aggregate,
            metadata={
                "formula_artifact_ref": formula_ref,
                "materialization_artifact_ref": materialization_ref,
            },
        )
        return {
            "status": "private_proxy_evaluation_complete",
            "observation_ref": observation["observation_ref"],
            "aggregate": aggregate,
        }


def _artifact(
    store: ArtifactStore, artifact_ref: str, expected_kind: str
) -> dict[str, Any]:
    artifact = store.read(artifact_ref)
    if artifact.get("artifact_kind") != expected_kind:
        raise ValueError(
            "artifact_kind_mismatch:"
            f"{artifact_ref}:expected={expected_kind}:"
            f"actual={artifact.get('artifact_kind')}"
        )
    if not isinstance(artifact.get("machine_payload"), Mapping):
        raise ValueError(f"artifact_machine_payload_required:{artifact_ref}")
    return artifact


def _finite(value: Any) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("private_evaluator_non_finite_value")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("private_evaluator_non_finite_value")
    return number


def _average_ranks(values: Sequence[float]) -> list[float]:
    indexed = sorted(
        ((value, index) for index, value in enumerate(values)),
        key=lambda item: (item[0], item[1]),
    )
    ranks = [0.0] * len(values)
    cursor = 0
    while cursor < len(indexed):
        end = cursor + 1
        while end < len(indexed) and indexed[end][0] == indexed[cursor][0]:
            end += 1
        average = (cursor + 1 + end) / 2.0
        for position in range(cursor, end):
            ranks[indexed[position][1]] = average
        cursor = end
    return ranks


def _pearson(left: Sequence[float], right: Sequence[float]) -> float:
    left_mean = sum(left) / len(left)
    right_mean = sum(right) / len(right)
    numerator = 0.0
    left_squared = 0.0
    right_squared = 0.0
    for left_value, right_value in zip(left, right):
        a = left_value - left_mean
        b = right_value - right_mean
        numerator += a * b
        left_squared += a * a
        right_squared += b * b
    denominator = math.sqrt(left_squared * right_squared)
    return 0.0 if denominator == 0.0 else numerator / denominator


def _kendall_tau_b(
    left: Sequence[float], right: Sequence[float]
) -> dict[str, float | int]:
    concordant = 0
    discordant = 0
    left_only_ties = 0
    right_only_ties = 0
    joint_ties = 0
    for first in range(len(left)):
        for second in range(first + 1, len(left)):
            left_sign = _sign(left[first] - left[second])
            right_sign = _sign(right[first] - right[second])
            if left_sign == 0 and right_sign == 0:
                joint_ties += 1
            elif left_sign == 0:
                left_only_ties += 1
            elif right_sign == 0:
                right_only_ties += 1
            elif left_sign == right_sign:
                concordant += 1
            else:
                discordant += 1
    denominator = math.sqrt(
        (concordant + discordant + left_only_ties)
        * (concordant + discordant + right_only_ties)
    )
    return {
        "value": (
            0.0
            if denominator == 0.0
            else (concordant - discordant) / denominator
        ),
        "concordant_pairs": concordant,
        "discordant_pairs": discordant,
        "proxy_only_ties": left_only_ties,
        "kpi_only_ties": right_only_ties,
        "joint_ties": joint_ties,
    }


def _sign(value: float) -> int:
    if value > 0:
        return 1
    if value < 0:
        return -1
    return 0
