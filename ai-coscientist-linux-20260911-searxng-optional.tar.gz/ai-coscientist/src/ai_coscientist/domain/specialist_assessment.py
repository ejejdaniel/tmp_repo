from __future__ import annotations

import copy
from typing import Any, Mapping


_SPECIALIST_ASSESSMENT_PAYLOAD = {
    "artifact_kind": "specialist_assessment",
}
_SPECIALIST_ASSESSMENT_SCHEMA = {
    "type": "object",
    "properties": {
        "artifact_kind": {
            "type": "string",
            "enum": ["specialist_assessment"],
        }
    },
    "required": ["artifact_kind"],
    "additionalProperties": False,
}


def specialist_assessment_schema() -> dict[str, Any]:
    return copy.deepcopy(_SPECIALIST_ASSESSMENT_SCHEMA)


def validate_specialist_assessment(payload: Any) -> None:
    """Validate the existing marker-only Specialist assessment payload."""
    if not isinstance(payload, Mapping) or dict(payload) != (
        _SPECIALIST_ASSESSMENT_PAYLOAD
    ):
        raise ValueError(
            "specialist_assessment_machine_payload_must_equal:"
            '{"artifact_kind":"specialist_assessment"}'
        )
