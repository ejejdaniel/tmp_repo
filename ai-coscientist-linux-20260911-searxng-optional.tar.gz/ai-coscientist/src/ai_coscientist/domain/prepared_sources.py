from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from .prepared_evaluation import validate_evaluation_binding


_MAX_ENCODED_BODY_CHARS = 2_000_000
_BASE64_LINE_CHARS = 1_000


class PreparedSourceDataError(ValueError):
    """Raised when an explicitly supplied prepared-source handoff is unusable."""


@dataclass(frozen=True)
class PreparedOutputBody:
    name: str
    content_ref: str
    media_type: str
    description: str
    content: Any
    trace_refs: tuple[str, ...]


@dataclass(frozen=True)
class PreparedSourceData:
    artifact_ref: str
    outputs: tuple[PreparedOutputBody, ...]
    evaluation_binding: Mapping[str, str] | None = None

    @property
    def trace_refs(self) -> tuple[str, ...]:
        refs: list[str] = []
        for output in self.outputs:
            refs.extend(output.trace_refs)
        return tuple(dict.fromkeys(refs))

    def prompt_projection(self) -> dict[str, Any]:
        projection = {
            "artifact_ref": self.artifact_ref,
            "artifact_kind": "prepared_source_data",
            "prepared_outputs": [
                {
                    "name": output.name,
                    "content_ref": output.content_ref,
                    "media_type": output.media_type,
                    "description": output.description,
                    "content": output.content,
                }
                for output in self.outputs
            ],
        }
        if self.evaluation_binding is not None:
            projection["evaluation_binding"] = dict(self.evaluation_binding)
        return projection


def resolve_prepared_source_data(
    runtime: Any,
    resolved_inputs: Sequence[Mapping[str, Any]],
    *,
    consumer: str,
    output_names: Sequence[str] | None = None,
) -> PreparedSourceData | None:
    """Resolve zero or one exact prepared-source artifact and selected C4 bodies."""
    by_ref: dict[str, Mapping[str, Any]] = {}
    for raw in resolved_inputs:
        if not isinstance(raw, Mapping):
            continue
        if raw.get("artifact_kind") != "prepared_source_data":
            continue
        artifact_ref = str(raw.get("artifact_ref") or "").strip()
        if not artifact_ref.startswith("artifact:"):
            raise PreparedSourceDataError(
                f"{consumer}_prepared_source_artifact_ref_invalid"
            )
        by_ref[artifact_ref] = raw

    if not by_ref:
        return None
    if len(by_ref) != 1:
        raise PreparedSourceDataError(
            f"{consumer}_prepared_source_selection_ambiguous:"
            f"refs={sorted(by_ref)}"
        )

    artifact_ref, raw = next(iter(by_ref.items()))
    artifact = dict(raw)
    if not isinstance(artifact.get("machine_payload"), Mapping):
        artifact = dict(runtime.read_artifact(artifact_ref))
    if str(artifact.get("artifact_ref") or "") != artifact_ref:
        raise PreparedSourceDataError(
            f"{consumer}_prepared_source_readback_ref_mismatch"
        )
    if artifact.get("artifact_kind") != "prepared_source_data":
        raise PreparedSourceDataError(
            f"{consumer}_prepared_source_readback_kind_mismatch"
        )

    machine_payload = artifact.get("machine_payload")
    if not isinstance(machine_payload, Mapping):
        raise PreparedSourceDataError(
            f"{consumer}_prepared_source_payload_required"
        )
    if machine_payload.get("artifact_kind") != "prepared_source_data":
        raise PreparedSourceDataError(
            f"{consumer}_prepared_source_payload_kind_mismatch"
        )
    raw_outputs = machine_payload.get("prepared_outputs")
    if not isinstance(raw_outputs, list) or not raw_outputs:
        raise PreparedSourceDataError(
            f"{consumer}_prepared_source_outputs_required"
        )

    binding = (
        validate_evaluation_binding(machine_payload["evaluation_binding"])
        if "evaluation_binding" in machine_payload else None
    )
    requested_names = (
        tuple(dict.fromkeys(str(item).strip() for item in output_names))
        if output_names is not None
        else None
    )
    if requested_names is not None and (
        not requested_names or any(not item for item in requested_names)
    ):
        raise PreparedSourceDataError(
            f"{consumer}_prepared_source_output_selection_invalid"
        )

    names: set[str] = set()
    metadata: list[tuple[str, str, str, str]] = []
    for index, raw_output in enumerate(raw_outputs):
        if not isinstance(raw_output, Mapping):
            raise PreparedSourceDataError(
                f"{consumer}_prepared_source_output_invalid:index={index}"
            )
        name = str(raw_output.get("name") or "").strip()
        content_ref = str(raw_output.get("content_ref") or "").strip()
        media_type = str(raw_output.get("media_type") or "").strip()
        description = str(raw_output.get("description") or "").strip()
        if not name or name in names:
            raise PreparedSourceDataError(
                f"{consumer}_prepared_source_output_name_invalid:index={index}"
            )
        if not content_ref.startswith("source_probe:"):
            raise PreparedSourceDataError(
                f"{consumer}_prepared_source_content_ref_invalid:index={index}"
            )
        if not media_type or not description:
            raise PreparedSourceDataError(
                f"{consumer}_prepared_source_output_metadata_required:index={index}"
            )
        names.add(name)
        metadata.append((name, content_ref, media_type, description))

    if requested_names is not None:
        unknown = [name for name in requested_names if name not in names]
        if unknown:
            raise PreparedSourceDataError(
                f"{consumer}_prepared_source_output_not_found:names={unknown}"
            )
        selected_names = set(requested_names)
        metadata = [item for item in metadata if item[0] in selected_names]

    outputs: list[PreparedOutputBody] = []
    for name, content_ref, media_type, description in metadata:
        outputs.append(
            read_prepared_output(runtime, {
                "name": name, "content_ref": content_ref,
                "media_type": media_type, "description": description,
            }, consumer=consumer)
        )

    return PreparedSourceData(
        artifact_ref=artifact_ref,
        outputs=tuple(outputs),
        evaluation_binding=binding,
    )


def read_prepared_output(runtime: Any, metadata: Mapping[str, str], *, consumer: str) -> PreparedOutputBody:
    """Read an explicitly selected C4 body, also before its manifest is published."""
    ref = metadata["content_ref"]
    if not ref.startswith("source_probe:"):
        raise PreparedSourceDataError("prepared_source_content_ref_invalid")
    body, trace_refs = _read_exact_prepared_body(runtime, ref)
    return PreparedOutputBody(
        name=metadata["name"], content_ref=ref, media_type=metadata["media_type"],
        description=metadata["description"],
        content=_decode_body(body, media_type=metadata["media_type"], consumer=consumer),
        trace_refs=trace_refs,
    )


def _read_exact_prepared_body(
    runtime: Any,
    content_ref: str,
) -> tuple[bytes, tuple[str, ...]]:
    probe = runtime.call_route(
        "source_probe",
        {
            "purpose": "project one exact prepared source body for consumption",
            "source_refs": [content_ref],
            "python_code": _base64_projection_code(),
            "timeout_seconds": 120,
        },
    )
    if not isinstance(probe, Mapping) or probe.get("status") != "source_probe_succeeded":
        detail = str(
            probe.get("stderr_preview") if isinstance(probe, Mapping) else probe
        ).strip()
        raise PreparedSourceDataError(
            "prepared_source_content_projection_failed:" + detail[:1000]
        )
    stdout_ref = str(probe.get("stdout_ref") or "").strip()
    if not stdout_ref.startswith("source_probe:"):
        raise PreparedSourceDataError(
            "prepared_source_content_projection_ref_required"
        )
    encoded = _read_all_pages(runtime, stdout_ref)
    compact = "".join(encoded.splitlines())
    if not compact:
        raise PreparedSourceDataError("prepared_source_content_empty")
    if len(compact) > _MAX_ENCODED_BODY_CHARS:
        raise PreparedSourceDataError(
            "prepared_source_content_exceeds_consumer_budget:"
            f"encoded_chars={len(compact)}"
        )
    try:
        body = base64.b64decode(compact, validate=True)
    except (ValueError, TypeError) as exc:
        raise PreparedSourceDataError(
            "prepared_source_content_projection_invalid_base64"
        ) from exc
    trace_refs = tuple(
        dict.fromkeys(
            ref
            for ref in (
                content_ref,
                str(probe.get("code_ref") or ""),
                stdout_ref,
                str(probe.get("stderr_ref") or ""),
                str(probe.get("manifest_ref") or ""),
            )
            if ref
        )
    )
    return body, trace_refs


def _read_all_pages(runtime: Any, source_ref: str) -> str:
    parts: list[str] = []
    offset = 0
    for _ in range(512):
        page = runtime.call_route(
            "source_read",
            {
                "source_ref": source_ref,
                "line_offset": offset,
                "line_limit": 2000,
            },
        )
        if not isinstance(page, Mapping) or page.get("status") != "source_page_ready":
            raise PreparedSourceDataError(
                "prepared_source_content_page_invalid"
            )
        content = str(page.get("content") or "")
        if "...[line clipped]" in content:
            raise PreparedSourceDataError(
                "prepared_source_content_projection_line_clipped"
            )
        parts.append(content)
        if sum(len(part) for part in parts) > _MAX_ENCODED_BODY_CHARS + 4096:
            raise PreparedSourceDataError(
                "prepared_source_content_exceeds_consumer_budget"
            )
        next_offset = page.get("next_line_offset")
        if next_offset is None:
            return "".join(parts)
        if isinstance(next_offset, bool) or not isinstance(next_offset, int):
            raise PreparedSourceDataError(
                "prepared_source_content_next_offset_invalid"
            )
        if next_offset <= offset:
            raise PreparedSourceDataError(
                "prepared_source_content_pagination_stalled"
            )
        offset = next_offset
    raise PreparedSourceDataError("prepared_source_content_page_budget_exhausted")


def _decode_body(body: bytes, *, media_type: str, consumer: str) -> Any:
    try:
        text = body.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise PreparedSourceDataError(
            f"{consumer}_prepared_source_body_not_utf8:media_type={media_type}"
        ) from exc
    normalized_media_type = media_type.lower().split(";", 1)[0].strip()
    if normalized_media_type == "application/json" or normalized_media_type.endswith(
        "+json"
    ):
        try:
            return json.loads(text)
        except json.JSONDecodeError as exc:
            raise PreparedSourceDataError(
                f"{consumer}_prepared_source_json_invalid:{exc}"
            ) from exc
    return text


def _base64_projection_code() -> str:
    return (
        "import base64\n"
        "paths = sorted(path for path in SOURCE_ROOT.rglob('*') if path.is_file())\n"
        "if len(paths) != 1:\n"
        "    raise RuntimeError(f'expected_one_prepared_body:actual={len(paths)}')\n"
        "encoded = base64.b64encode(paths[0].read_bytes()).decode('ascii')\n"
        f"for offset in range(0, len(encoded), {_BASE64_LINE_CHARS}):\n"
        f"    print(encoded[offset:offset + {_BASE64_LINE_CHARS}])\n"
    )
