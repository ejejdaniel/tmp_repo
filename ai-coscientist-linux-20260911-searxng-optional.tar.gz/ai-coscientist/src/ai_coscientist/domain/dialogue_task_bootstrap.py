from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from ai_coscientist.common.artifacts import ArtifactStore
from ai_coscientist.common.dialogue import (
    DialogueStore,
    publish_human_conversation_input,
)
from ai_coscientist.common.memory_lifecycle.events import EventLog
from ai_coscientist.common.model import ChatModel
from ai_coscientist.common.observations import ObservationStore
from ai_coscientist.common.routes import RouteRegistry
from ai_coscientist.common.skill_workflows import SkillWorkflowRuntime
from ai_coscientist.common.skills import SkillCatalog


@dataclass(frozen=True)
class DialogueTaskLaunch:
    user_message_id: str
    context_message_ids: tuple[str, ...] = ()
    supporting_refs: tuple[str, ...] = ()


@dataclass(frozen=True)
class PreformulatedTask:
    objective: str
    task_spec_ref: str
    input_refs: tuple[str, ...]
    user_message_id: str


def formulate_dialogue_task_before_c0(
    *,
    launch: DialogueTaskLaunch,
    dialogue: DialogueStore,
    artifacts: ArtifactStore,
    observations: ObservationStore,
    routes: RouteRegistry,
    skills: SkillCatalog,
    model: ChatModel,
    events: EventLog,
    skill_id: str,
    evaluation_summary: str,
) -> PreformulatedTask:
    """Publish selected exact inputs and formulate TaskSpec before C0 exists."""
    latest, selected = _selected_dialogue_messages(
        dialogue=dialogue,
        user_message_id=launch.user_message_id,
        context_message_ids=launch.context_message_ids,
    )
    supporting_refs = tuple(
        dict.fromkeys(
            str(ref).strip()
            for ref in launch.supporting_refs
            if str(ref).strip()
        )
    )
    for ref in supporting_refs:
        _read_input_ref(
            ref,
            artifacts=artifacts,
            observations=observations,
        )

    input_refs: list[str] = []
    context_observation_refs: list[str] = []
    for message in selected:
        if message["role"] == "user":
            input_refs.append(
                publish_human_conversation_input(
                    artifacts=artifacts,
                    events=events,
                    user_message=message,
                    declared_response_role="scientific_input",
                )
            )
        else:
            receipt = observations.publish(
                namespace="dialogue-launch-context",
                status="dialogue_launch_context_selected",
                result={"messages": [copy.deepcopy(dict(message))]},
                metadata={
                    "turn_id": str(latest["turn_id"]),
                    "selected_message_ids": [str(message["message_id"])],
                },
            )
            observation_ref = str(receipt["observation_ref"])
            context_observation_refs.append(observation_ref)
            input_refs.append(observation_ref)
    latest_ref = publish_human_conversation_input(
        artifacts=artifacts,
        events=events,
        user_message=latest,
        declared_response_role="scientific_input",
    )
    input_refs.extend((latest_ref, *supporting_refs))
    input_refs = list(dict.fromkeys(input_refs))
    events.append(
        "dialogue_pre_task_handoff",
        {
            "turn_id": latest["turn_id"],
            "user_message_id": latest["message_id"],
            "promoted_ref": latest_ref,
            "context_message_ids": [
                str(item["message_id"]) for item in selected
            ],
            "supporting_refs": list(supporting_refs),
            "context_observation_refs": context_observation_refs,
            "input_refs": list(input_refs),
        },
    )

    resolved_inputs = [
        _read_input_ref(
            ref,
            artifacts=artifacts,
            observations=observations,
        )
        for ref in input_refs
    ]
    call_index = 0

    def call_tool(name: str, arguments: Mapping[str, Any]) -> Any:
        nonlocal call_index
        call_index += 1
        call_id = f"pre-c0-{skill_id}-{call_index}"
        if name == "artifact_publish":
            result = artifacts.publish(**dict(arguments))
        elif name == "artifact_read":
            ref = str(arguments.get("artifact_ref") or "")
            stored = artifacts.read(ref)
            result = {
                "status": "artifact_resolved",
                "artifact_ref": ref,
                "artifact_kind": stored["artifact_kind"],
            }
        elif name == "artifact_list":
            result = {
                "artifacts": [
                    receipt
                    for receipt in artifacts.list()
                    if str(receipt.get("artifact_ref") or "") in input_refs
                ]
            }
        else:
            result = routes.execute(name, arguments, skill_id=skill_id)
        events.append(
            "tool_result",
            {
                "round": 0,
                "call_id": call_id,
                "tool": name,
                "executed_arguments": dict(arguments),
                "raw_result": result,
                "source": "pre_c0_skill_workflow",
            },
        )
        return result

    runtime = SkillWorkflowRuntime(
        skill_id=skill_id,
        model=model,
        events=events,
        round_number=0,
        allowed_artifact_refs=input_refs,
        call_tool=call_tool,
        read_stored_artifact=lambda ref: _read_input_ref(
            ref,
            artifacts=artifacts,
            observations=observations,
        ),
        record_model_prompt=lambda purpose, messages, tools: events.append(
            "prompt_snapshot",
            {
                "call_site": purpose,
                "messages": list(messages),
                "tools": list(tools),
                "source": "pre_c0_task_formulation",
            },
        ),
    )
    result = skills.workflow(skill_id)(
        {
            "skill_id": skill_id,
            "task_request": str(latest["content"]),
            "evaluation_summary": str(evaluation_summary),
            "task_authority_mode": "dialogue_launch",
            "is_child_agent": False,
            "task_contract_state": {"phase": "pre_c0_task_formulation"},
            "resolved_inputs": resolved_inputs,
        },
        runtime,
    )
    if not isinstance(result, Mapping):
        raise TypeError("pre_c0_task_formulation_result_must_be_object")
    runtime.ensure_complete()
    candidates = list(
        dict.fromkeys(
            [
                *runtime.published_refs,
                str(result.get("artifact_ref") or "").strip(),
            ]
        )
    )
    task_spec_refs = [
        ref
        for ref in candidates
        if ref and artifacts.read(ref).get("artifact_kind") == "task_spec"
    ]
    if len(task_spec_refs) != 1:
        raise RuntimeError(
            "pre_c0_task_formulation_requires_one_task_spec:"
            f"actual={len(task_spec_refs)}"
        )
    task_spec_ref = task_spec_refs[0]
    task_spec = artifacts.read(task_spec_ref)
    payload = task_spec.get("machine_payload")
    objective = (
        str(payload.get("goal") or "").strip()
        if isinstance(payload, Mapping)
        else ""
    )
    if not objective:
        raise RuntimeError("pre_c0_task_spec_goal_required")
    events.append(
        "pre_c0_task_formulation_completed",
        {
            "task_spec_ref": task_spec_ref,
            "input_refs": list(input_refs),
            "user_message_id": latest["message_id"],
        },
    )
    return PreformulatedTask(
        objective=objective,
        task_spec_ref=task_spec_ref,
        input_refs=tuple(input_refs),
        user_message_id=str(latest["message_id"]),
    )


def _selected_dialogue_messages(
    *,
    dialogue: DialogueStore,
    user_message_id: str,
    context_message_ids: Sequence[str],
) -> tuple[dict[str, Any], tuple[dict[str, Any], ...]]:
    latest = dialogue.get(str(user_message_id))
    if latest["role"] != "user":
        raise ValueError("dialogue_task_start_requires_user_message")
    transcript = dialogue.read()
    positions = {
        str(message["message_id"]): index
        for index, message in enumerate(transcript)
    }
    latest_position = positions[str(latest["message_id"])]
    selected: list[dict[str, Any]] = []
    seen = {str(latest["message_id"])}
    for raw_message_id in context_message_ids:
        message_id = str(raw_message_id).strip()
        if not message_id:
            raise ValueError("dialogue_launch_context_message_id_required")
        if message_id in seen:
            raise ValueError(
                f"dialogue_launch_context_message_id_duplicated:{message_id}"
            )
        if message_id not in positions:
            raise KeyError(f"dialogue_message_unknown:{message_id}")
        if positions[message_id] >= latest_position:
            raise ValueError(
                "dialogue_launch_context_message_must_precede_latest:"
                f"{message_id}"
            )
        selected.append(dialogue.get(message_id))
        seen.add(message_id)
    selected.sort(key=lambda message: positions[str(message["message_id"])])
    return latest, tuple(selected)


def _read_input_ref(
    ref: str,
    *,
    artifacts: ArtifactStore,
    observations: ObservationStore,
) -> dict[str, Any]:
    if ref.startswith("artifact:"):
        return artifacts.read(ref)
    if ref.startswith("execution_observation:"):
        return observations.read(ref)
    raise ValueError(f"dialogue_task_input_ref_unsupported:{ref}")
