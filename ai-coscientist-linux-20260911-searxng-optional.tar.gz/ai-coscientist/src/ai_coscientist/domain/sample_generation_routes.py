from __future__ import annotations

import copy
import json
from typing import Any, Mapping, Sequence

from .materialization_inputs import validate_execution_input_paths
from .sample_records import validate_candidate_inputs


_CANDIDATE_SCHEMA = {
    "type": "object",
    "properties": {
        "id": {"type": "string", "minLength": 1},
        "smiles": {"type": "string", "minLength": 1},
        "input_description": {"type": "string"},
    },
    "required": ["id", "smiles"],
    "additionalProperties": False,
}

_DESCRIBED_CANDIDATE_SCHEMA = {
    "type": "object",
    "properties": {
        "id": {"type": "string", "minLength": 1},
        "input_description": {"type": "string", "minLength": 1},
    },
    "required": ["id", "input_description"],
    "additionalProperties": False,
}

_STRUCTURED_RECORD_CANDIDATE_SCHEMA = {
    "type": "object",
    "properties": {
        "id": {"type": "string", "minLength": 1},
        "input_description": {"type": "string", "minLength": 1},
        "metadata": {
            "type": "object",
            "properties": {},
            "additionalProperties": True,
            "minProperties": 1,
        },
    },
    "required": ["id", "input_description", "metadata"],
    "additionalProperties": False,
}

_CANDIDATE_EVIDENCE_CONTRACT = """\
Candidate evidence boundary (shared by generation, fidelity and repair):
This stage proposes inputs BEFORE the new candidate is executed. input_description
describes the controllable change and its scientific rationale, not completed
results. Express expected effects as hypotheses. Reference results belong to
their named reference samples; they do not measure or validate this candidate.
Do not put a self-estimated score or a claim of completed execution, measurement,
or validation into the candidate description. The later execution supplies the
actual computed values. A frozen proxy scorer computes the selected proxy; it
does not measure the final KPI, and a target identifier does not change that role.
Do not promise that later execution will supply an observable outside the
selected scorer's output. Saying "will be measured" or "to be supplied" does
not make that capability available. Keep final-KPI effects as unverified
scientific hypotheses; a proposed effect and an executable output are different.
In fidelity, identify what the selected scorer actually computes before checking
the prose. Rewrite input_description from the candidate inputs and sponsor,
preserving valid design intent rather than preserving draft sentences by default.
Remove unsupported completed results AND unsupported promises about later tools.
Calling a self-estimated score a hypothesis does not make it execution evidence.
In repair, correct the reported input defect without introducing result claims.
"""

_DRAFT_SYSTEM = """\
You are the SMILES generation route for one Sample iteration. Create one new
molecular candidate that advances current_iteration_mission.

The task states the problem and constraints. method_sponsor names the one exact
solution method served by this iteration. In hypothesis mode, create a concrete
sample that more faithfully instantiates or tests the frozen hypothesis; do not
claim final-KPI improvement. In final-KPI proxy mode, use the frozen formula landscape and
its ranked examples; do not change the formula. Do not automatically blend a
different public method merely because it is visible elsewhere.

The SMILES must encode every structural claim in input_description. Do not claim
that non-structural properties are already verified. Do not copy a current
sample, expose held-out KPI values, or invent a score. Return exactly id, smiles,
and optional input_description.
""" + _CANDIDATE_EVIDENCE_CONTRACT
_FIDELITY_SYSTEM = """\
You are the SMILES fidelity stage for one Sample iteration. Return the same id,
smiles, and optional input_description fields after correcting the draft.

Use current_iteration_mission and the exact method_sponsor. Ensure the SMILES
encodes every structural claim, remove claims that a molecular representation
cannot establish, and keep the candidate distinct from the current population.
Do not switch sponsor, change a frozen formula or hypothesis, or invent a score.
""" + _CANDIDATE_EVIDENCE_CONTRACT
_REPAIR_SYSTEM = """\
You are the bounded repair stage for the SMILES generation route. Repair only
the exact candidate identity or representation error returned by controlled
validation. Change the id only when it collides with the current population.
Preserve the task boundary and exact method_sponsor. The repaired candidate must
differ in the field implicated by the error. Do not repair the scientific
method, scorer, or materialization, and never invent a score.
""" + _CANDIDATE_EVIDENCE_CONTRACT

_DESCRIBED_DRAFT_SYSTEM = """\
You are the described-sample generation route for one Sample iteration. Create
one new concrete sample when the scientific object is represented by a complete
input_description rather than one canonical molecular string.

Use the task, exact method_sponsor, current_iteration_mission, and bounded
population references. Preserve the source representation grammar and include
all settings needed to distinguish the proposed sample from its references.
Change the actual sample, not only its id or prose style. State unknown or
unverified properties as unknown; do not invent measurements, scores, hidden KPI
values, or claims that a sample already passed validation. Return exactly id and
input_description as plain strings.
""" + _CANDIDATE_EVIDENCE_CONTRACT
_DESCRIBED_FIDELITY_SYSTEM = """\
You are the fidelity stage for one described-sample candidate. Return the same
id and one complete input_description after correcting the draft.

The description must identify one concrete sample, preserve task constraints and
the exact method sponsor, and make the actual proposed change unambiguous. Remove
unsupported claims of measured or computed success. Keep it distinct from the
current population. Do not switch the sponsor or invent a score.
""" + _CANDIDATE_EVIDENCE_CONTRACT
_DESCRIBED_REPAIR_SYSTEM = """\
You are the bounded repair stage for one described-sample candidate. Repair only
the exact identity, missing-description, or duplicate-description error returned
by controlled validation. Preserve the task and exact method sponsor. Change the
id only for an id collision; otherwise change the concrete sample description,
not merely wording. Never invent a score or validation result.
""" + _CANDIDATE_EVIDENCE_CONTRACT

_STRUCTURED_RECORD_INPUT_CONTRACT = """\
required_source_paths are the selected implementations' exact execution-input paths, not
a request to copy every historical column. The reference samples' metadata is
already projected to those inputs. Return the same projected keys, nesting and
value types; do not add other historical columns or workflow provenance.
The sponsor's source_binding explains its research sources; its paths may differ
from this executed implementation. Do not restore that older layout or change
the scientific formula to reconcile field positions.

metadata is the candidate transport container, not necessarily a field in the
scorer's source row. When all data paths begin with record.metadata, the
container holds that nested object's inputs. Otherwise it holds the declared
top-level inputs, including a nested metadata object if a path requires it.
The executor restores the original field positions before calling the frozen
scorer. Keep id and input_description in their existing envelope fields.
Do not fabricate measurements or hidden KPI values. If a declared input cannot
be obtained honestly, do not disguise an invented value as a measurement.
"""

_STRUCTURED_RECORD_DRAFT_SYSTEM = """\
You are the structured-record generation route for one Sample iteration. Create
one new scientific sample with complete declared inputs for execution by
the exact frozen scorer.

Use the task, exact method_sponsor, current_iteration_mission, required source
paths, and bounded population references. Change actual controllable sample
inputs rather than only id or prose. Never invent a score or claim that the
sample already passed validation. Return exactly id, input_description, and
metadata.
""" + _STRUCTURED_RECORD_INPUT_CONTRACT + _CANDIDATE_EVIDENCE_CONTRACT
_STRUCTURED_RECORD_FIDELITY_SYSTEM = """\
You are the fidelity stage for one structured-record candidate. Return the same
id, one complete input_description, and one complete metadata object after
correcting the draft.

The candidate must describe a genuine input change relative to the bounded
references. Check its metadata against the projected reference inputs and the
following shared input contract. Do not change the sponsor or formula or invent
a score.
""" + _STRUCTURED_RECORD_INPUT_CONTRACT + _CANDIDATE_EVIDENCE_CONTRACT
_STRUCTURED_RECORD_REPAIR_SYSTEM = """\
You are the bounded repair stage for one structured-record candidate. Repair
only the exact identity, shape, required-path, or duplicate-record error from
controlled validation. Preserve the task, exact method sponsor, source metadata
grammar, and all valid fields. The validation error names missing, unexpected,
or type-mismatched paths; correct those exact paths. Workflow provenance does
not belong inside the projected inputs. Never alter the frozen scorer or invent
a score. Return the complete
corrected id, input_description, and metadata object.
""" + _STRUCTURED_RECORD_INPUT_CONTRACT + _CANDIDATE_EVIDENCE_CONTRACT


class SmilesGenerationRoute:
    route_id = "smiles"

    def supports(
        self,
        source_paths: Sequence[str],
        *,
        source_records: Sequence[Mapping[str, Any]] = (),
    ) -> bool:
        source_inputs = set(source_paths)
        if not source_inputs or not source_inputs <= {"record.metadata.smiles"}:
            return False
        return not source_records or self.supports_records(source_records)


    @staticmethod
    def supports_records(records: Sequence[Mapping[str, Any]]) -> bool:
        return bool(records) and all(
            str(record.get("metadata", {}).get("smiles") or "").strip()
            for record in records
        )

    def validate_candidate(
        self,
        candidate: Mapping[str, Any],
        *,
        reference_samples: Sequence[Mapping[str, Any]],
        required_source_paths: Sequence[str] = (),
    ) -> dict[str, Any]:
        normalized = _normalize_candidate(candidate)
        sample_id = str(normalized.get("id") or "")
        smiles = str(normalized.get("smiles") or "")
        if not sample_id or not smiles:
            raise ValueError("invalid_sample_candidate_smiles")
        reference_ids = {
            str(item.get("id") or item.get("sample_id") or "")
            for item in reference_samples
        }
        if sample_id in reference_ids:
            raise ValueError("sample_candidate_id_conflicts_with_historical")
        try:
            from rdkit import Chem
        except ImportError as exc:
            raise RuntimeError(
                "sample_generation_smiles_validation_unavailable"
            ) from exc
        params = Chem.SmilesParserParams()
        params.parseName = False
        molecule = Chem.MolFromSmiles(smiles, params)
        if molecule is None:
            raise ValueError("invalid_sample_candidate_smiles")
        canonical = Chem.MolToSmiles(molecule, canonical=True)
        reference_canonical: set[str] = set()
        for item in reference_samples:
            metadata = item.get("metadata")
            nested_smiles = (
                metadata.get("smiles")
                if isinstance(metadata, Mapping)
                else None
            )
            reference_smiles = str(
                item.get("smiles") or nested_smiles or ""
            ).strip()
            reference_molecule = Chem.MolFromSmiles(reference_smiles, params)
            if reference_molecule is None:
                raise ValueError("invalid_historical_sample_smiles")
            reference_canonical.add(
                Chem.MolToSmiles(reference_molecule, canonical=True)
            )
        if canonical in reference_canonical:
            raise ValueError("duplicate_historical_sample_candidate")
        return normalized

    def generate(
        self,
        runtime: Any,
        context: Mapping[str, Any],
    ) -> dict[str, Any]:
        draft = runtime.generate_json(
            _DRAFT_SYSTEM,
            json.dumps(context, ensure_ascii=False, indent=2),
            purpose="draft-sample-candidate",
            scientific_call=True,
            schema=_CANDIDATE_SCHEMA,
        )
        draft = _normalize_candidate(draft)
        candidate = runtime.generate_json(
            _FIDELITY_SYSTEM,
            json.dumps(
                {**dict(context), "draft_candidate": draft},
                ensure_ascii=False,
                indent=2,
            ),
            purpose="refine-sample-representation-fidelity",
            scientific_call=True,
            schema=_CANDIDATE_SCHEMA,
        )
        return _normalize_candidate(candidate)

    def repair(
        self,
        runtime: Any,
        context: Mapping[str, Any],
        *,
        rejected_candidate: Mapping[str, Any],
        execution_error: str,
    ) -> dict[str, Any]:
        candidate = runtime.generate_json(
            _REPAIR_SYSTEM,
            json.dumps(
                {
                    **dict(context),
                    "rejected_candidate": dict(rejected_candidate),
                    "execution_error": execution_error,
                    "instruction": (
                        "Repair only the candidate identity or representation."
                    ),
                },
                ensure_ascii=False,
                indent=2,
            ),
            purpose="repair-sample-representation",
            schema=_CANDIDATE_SCHEMA,
            repair_call=True,
        )
        return _normalize_candidate(candidate)

    @staticmethod
    def can_repair(execution_error: str) -> bool:
        return any(
            token in execution_error
            for token in {
                "invalid_sample_candidate_smiles",
                "duplicate_historical_sample_candidate",
                "duplicate_sample_candidate",
                "sample_candidate_id_conflicts_with_historical",
                "duplicate_sample_candidate_id",
            }
        )


class DescribedSampleGenerationRoute:
    route_id = "described-sample"

    def supports(
        self,
        source_paths: Sequence[str],
        *,
        source_records: Sequence[Mapping[str, Any]] = (),
    ) -> bool:
        return False

    @staticmethod
    def supports_records(records: Sequence[Mapping[str, Any]]) -> bool:
        return (
            bool(records)
            and not SmilesGenerationRoute.supports_records(records)
            and all(
                str(record.get("id") or "").strip()
                and str(record.get("input_description") or "").strip()
                for record in records
            )
        )

    def validate_candidate(
        self,
        candidate: Mapping[str, Any],
        *,
        reference_samples: Sequence[Mapping[str, Any]],
        required_source_paths: Sequence[str] = (),
    ) -> dict[str, Any]:
        normalized = _normalize_described_candidate(candidate)
        sample_id = str(normalized.get("id") or "")
        description = str(normalized.get("input_description") or "")
        if not sample_id or not description:
            raise ValueError("invalid_described_sample_candidate")
        reference_ids = {
            str(item.get("id") or item.get("sample_id") or "").strip()
            for item in reference_samples
        }
        if sample_id in reference_ids:
            raise ValueError("sample_candidate_id_conflicts_with_historical")
        reference_descriptions = {
            _description_identity(item.get("input_description"))
            for item in reference_samples
            if _description_identity(item.get("input_description"))
        }
        if _description_identity(description) in reference_descriptions:
            raise ValueError("duplicate_historical_sample_candidate")
        return normalized

    def generate(
        self,
        runtime: Any,
        context: Mapping[str, Any],
    ) -> dict[str, Any]:
        draft = runtime.generate_json(
            _DESCRIBED_DRAFT_SYSTEM,
            json.dumps(context, ensure_ascii=False, indent=2),
            purpose="draft-described-sample-candidate",
            scientific_call=True,
            schema=_DESCRIBED_CANDIDATE_SCHEMA,
        )
        draft = _normalize_described_candidate(draft)
        candidate = runtime.generate_json(
            _DESCRIBED_FIDELITY_SYSTEM,
            json.dumps(
                {**dict(context), "draft_candidate": draft},
                ensure_ascii=False,
                indent=2,
            ),
            purpose="refine-described-sample-fidelity",
            scientific_call=True,
            schema=_DESCRIBED_CANDIDATE_SCHEMA,
        )
        return _normalize_described_candidate(candidate)

    def repair(
        self,
        runtime: Any,
        context: Mapping[str, Any],
        *,
        rejected_candidate: Mapping[str, Any],
        execution_error: str,
    ) -> dict[str, Any]:
        candidate = runtime.generate_json(
            _DESCRIBED_REPAIR_SYSTEM,
            json.dumps(
                {
                    **dict(context),
                    "rejected_candidate": dict(rejected_candidate),
                    "execution_error": execution_error,
                },
                ensure_ascii=False,
                indent=2,
            ),
            purpose="repair-described-sample-representation",
            schema=_DESCRIBED_CANDIDATE_SCHEMA,
            repair_call=True,
        )
        return _normalize_described_candidate(candidate)

    @staticmethod
    def can_repair(execution_error: str) -> bool:
        return any(
            token in execution_error
            for token in {
                "invalid_described_sample_candidate",
                "duplicate_historical_sample_candidate",
                "sample_candidate_id_conflicts_with_historical",
                "duplicate_sample_candidate_id",
            }
        )


class StructuredRecordGenerationRoute:
    route_id = "structured-record"

    def supports(
        self,
        source_paths: Sequence[str],
        *,
        source_records: Sequence[Mapping[str, Any]] = (),
    ) -> bool:
        if not source_paths or set(source_paths) <= {"record.metadata.smiles"}:
            return False
        return bool(source_records)

    @staticmethod
    def supports_records(records: Sequence[Mapping[str, Any]]) -> bool:
        return False

    def validate_candidate(
        self,
        candidate: Mapping[str, Any],
        *,
        reference_samples: Sequence[Mapping[str, Any]],
        required_source_paths: Sequence[str] = (),
    ) -> dict[str, Any]:
        normalized = _normalize_structured_record_candidate(candidate)
        sample_id = str(normalized["id"])
        reference_ids = {
            str(item.get("id") or item.get("sample_id") or "").strip()
            for item in reference_samples
        }
        if sample_id in reference_ids:
            raise ValueError("sample_candidate_id_conflicts_with_historical")

        references = validate_candidate_inputs(
            normalized, reference_samples, required_source_paths
        )
        metadata = normalized["metadata"]
        candidate_identity = _canonical_json(metadata)
        reference_identities = {
            _canonical_json(reference["metadata"])
            for reference in references
        }
        if candidate_identity in reference_identities:
            raise ValueError("duplicate_historical_sample_candidate")
        return normalized

    def generate(
        self,
        runtime: Any,
        context: Mapping[str, Any],
    ) -> dict[str, Any]:
        draft = runtime.generate_json(
            _STRUCTURED_RECORD_DRAFT_SYSTEM,
            json.dumps(context, ensure_ascii=False, indent=2),
            purpose="draft-structured-record-candidate",
            scientific_call=True,
            schema=_STRUCTURED_RECORD_CANDIDATE_SCHEMA,
        )
        draft = _normalize_structured_record_candidate(draft)
        candidate = runtime.generate_json(
            _STRUCTURED_RECORD_FIDELITY_SYSTEM,
            json.dumps(
                {**dict(context), "draft_candidate": draft},
                ensure_ascii=False,
                indent=2,
            ),
            purpose="refine-structured-record-fidelity",
            scientific_call=True,
            schema=_STRUCTURED_RECORD_CANDIDATE_SCHEMA,
        )
        return _normalize_structured_record_candidate(candidate)

    def repair(
        self,
        runtime: Any,
        context: Mapping[str, Any],
        *,
        rejected_candidate: Mapping[str, Any],
        execution_error: str,
    ) -> dict[str, Any]:
        candidate = runtime.generate_json(
            _STRUCTURED_RECORD_REPAIR_SYSTEM,
            json.dumps(
                {
                    **dict(context),
                    "rejected_candidate": dict(rejected_candidate),
                    "execution_error": execution_error,
                },
                ensure_ascii=False,
                indent=2,
            ),
            purpose="repair-structured-record-candidate",
            schema=_STRUCTURED_RECORD_CANDIDATE_SCHEMA,
            repair_call=True,
        )
        return _normalize_structured_record_candidate(candidate)

    @staticmethod
    def can_repair(execution_error: str) -> bool:
        return any(
            token in execution_error
            for token in {
                "invalid_structured_sample_candidate",
                "structured_sample_reference_metadata_required",
                "structured_sample_metadata_shape_mismatch",
                "structured_sample_required_source_path_missing",
                "duplicate_historical_sample_candidate",
                "duplicate_sample_candidate",
                "sample_candidate_id_conflicts_with_historical",
                "duplicate_sample_candidate_id",
            }
        )


def select_generation_route(
    *,
    source_records: Sequence[Mapping[str, Any]] = (),
    required_source_paths: Sequence[str] | None = None,
) -> (
    SmilesGenerationRoute
    | DescribedSampleGenerationRoute
    | StructuredRecordGenerationRoute
):
    paths = (validate_execution_input_paths(list(required_source_paths), records=source_records)
             if required_source_paths is not None else None)
    routes = (
        SmilesGenerationRoute(),
        StructuredRecordGenerationRoute(),
        DescribedSampleGenerationRoute(),
    )
    matches = [
        route
        for route in routes
        if (
            route.supports(paths, source_records=source_records)
            if paths is not None
            else route.supports_records(source_records)
        )
    ]
    if len(matches) != 1:
        raise ValueError(
            "sample_generation_route_unavailable:"
            f"matching_routes={[route.route_id for route in matches]}"
        )
    return matches[0]


def _normalize_candidate(candidate: Mapping[str, Any]) -> dict[str, Any]:
    normalized = dict(candidate)
    normalized["id"] = str(normalized.get("id") or "").strip()
    # Preserve the raw model turn in the event log, but remove the known
    # whitespace transport defect before the controlled SMILES validator.
    normalized["smiles"] = "".join(
        str(normalized.get("smiles") or "").split()
    )
    if "input_description" in normalized:
        normalized["input_description"] = str(
            normalized.get("input_description") or ""
        ).strip()
    return normalized


def _normalize_described_candidate(
    candidate: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "id": str(candidate.get("id") or "").strip(),
        "input_description": str(
            candidate.get("input_description") or ""
        ).strip(),
    }


def _normalize_structured_record_candidate(
    candidate: Mapping[str, Any],
) -> dict[str, Any]:
    metadata = candidate.get("metadata")
    if not isinstance(metadata, Mapping) or not metadata:
        raise ValueError("invalid_structured_sample_candidate")
    sample_id = str(candidate.get("id") or "").strip()
    description = str(candidate.get("input_description") or "").strip()
    if not sample_id or not description:
        raise ValueError("invalid_structured_sample_candidate")
    return {
        "id": sample_id,
        "input_description": description,
        "metadata": copy.deepcopy(dict(metadata)),
    }


def _canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def _description_identity(value: Any) -> str:
    return " ".join(str(value or "").split()).casefold()
