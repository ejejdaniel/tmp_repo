from __future__ import annotations

import copy
import hashlib
import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from ai_coscientist.common.artifacts import ArtifactStore
from ai_coscientist.common.code_artifacts import CodeArtifactStore
from ai_coscientist.common.observations import ObservationStore
from ai_coscientist.common.routes import Route

from .materializer import MaterializerExecutor
from .materialization_inputs import materialization_input_paths
from .materializer_projects import MaterializerProjectExecutor
from .multi_index import rank_multi_index_rows
from .sample_records import candidate_to_source, validate_candidate_inputs
from .source_authority import SourceAuthority


@dataclass
class SampleExecutor:
    artifacts: ArtifactStore
    code_artifacts: CodeArtifactStore
    observations: ObservationStore
    source_authority: SourceAuthority | None
    materializer: MaterializerExecutor
    materializer_projects: MaterializerProjectExecutor | None = None
    python_executable: str = sys.executable
    timeout_seconds: float = 30.0

    def routes(self) -> tuple[Route, ...]:
        return (
            Route(
                name="scientific_sample_execute",
                description=(
                    "Validate novel candidate source records, replay immutable "
                    "primary and auxiliary scorers, and score candidates with "
                    "their exact frozen Materializer implementation. Candidates "
                    "use either "
                    "a SMILES representation or metadata containing the formulas' "
                    "declared inputs, restored to their native record paths before "
                    "execution; the two forms cannot be mixed in one call."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "formula_artifact_ref": {"type": "string"},
                        "materialization_artifact_ref": {"type": "string"},
                        "auxiliary_scorer_pairs": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "formula_artifact_ref": {"type": "string"},
                                    "materialization_artifact_ref": {
                                        "type": "string"
                                    },
                                },
                                "required": [
                                    "formula_artifact_ref",
                                    "materialization_artifact_ref",
                                ],
                                "additionalProperties": False,
                            },
                        },
                        "candidates": {
                            "type": "array",
                            "minItems": 1,
                            "items": {
                                "type": "object",
                                "properties": {
                                    "id": {"type": "string"},
                                    "smiles": {"type": "string"},
                                    "input_description": {"type": "string"},
                                    "metadata": {"type": "object"},
                                },
                                "required": ["id"],
                                "additionalProperties": False,
                            },
                        },
                    },
                    "required": [
                        "formula_artifact_ref",
                        "materialization_artifact_ref",
                        "candidates",
                    ],
                    "additionalProperties": False,
                },
                handler=self.execute,
                skill_ids=("sample",),
            ),
            Route(
                name="scientific_sample_candidate_bundle_read",
                description=(
                    "Read one exact immutable Sample C4 candidate bundle by its "
                    "workspace ref linked by a selected sample result for "
                    "continuation, final audit or reporting. It does not search for the latest "
                    "bundle or infer a sponsor."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "candidate_bundle_ref": {"type": "string"},
                    },
                    "required": ["candidate_bundle_ref"],
                    "additionalProperties": False,
                },
                handler=self.read_candidate_bundle,
                skill_ids=("sample", "final-lca", "scientific-report-writer"),
            ),
        )

    def execute(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        formula_ref = str(arguments.get("formula_artifact_ref") or "")
        materialization_ref = str(
            arguments.get("materialization_artifact_ref") or ""
        )
        primary = self._load_scorer_pair(
            formula_ref=formula_ref,
            materialization_ref=materialization_ref,
            expected_target_kind="final_kpi",
        )
        auxiliary_arguments = _normalize_auxiliary_pairs(
            arguments.get("auxiliary_scorer_pairs")
        )
        scorers = [
            primary,
            *[
                self._load_scorer_pair(
                    formula_ref=pair["formula_artifact_ref"],
                    materialization_ref=pair[
                        "materialization_artifact_ref"
                    ],
                    expected_target_kind="auxiliary_condition",
                )
                for pair in auxiliary_arguments
            ],
        ]
        target_ids = [str(scorer["target_id"]) for scorer in scorers]
        if len(set(target_ids)) != len(target_ids):
            raise ValueError("sample_scorer_target_id_duplicate")

        candidates, representation = _normalize_candidates(
            arguments.get("candidates")
        )
        historical_records = self.materializer.records_for_materialization(
            materialization_ref
        )
        # Equal replayed values alone do not establish the same execution inputs.
        historical_by_id = {record["id"]: record for record in historical_records}
        for scorer in scorers[1:]:
            auxiliary_records = self.materializer.records_for_materialization(
                str(scorer["materialization_ref"])
            )
            if (
                scorer["prepared_source_ref"] != primary["prepared_source_ref"]
                or {record["id"]: record for record in auxiliary_records}
                != historical_by_id
            ):
                raise ValueError(
                    "sample_scorer_execution_source_mismatch:"
                    f"target_id={scorer['target_id']}"
                )
        historical_ids = {str(record["id"]) for record in historical_records}
        if any(record["id"] in historical_ids for record in candidates):
            raise ValueError("sample_candidate_id_conflicts_with_historical")
        candidate_records = candidates
        if representation == "smiles":
            candidate_canonical = self._canonicalize_smiles(
                [str(record["metadata"]["smiles"]) for record in candidates]
            )
            if any(value is None for value in candidate_canonical):
                raise ValueError("invalid_sample_candidate_smiles")
            historical_canonical = self._canonicalize_smiles(
                [
                    str(record.get("metadata", {}).get("smiles", ""))
                    for record in historical_records
                ]
            )
            if any(value is None for value in historical_canonical):
                raise ValueError("invalid_historical_sample_smiles")
            historical_canonical_set = set(historical_canonical)
            if any(
                value in historical_canonical_set
                for value in candidate_canonical
            ):
                raise ValueError("duplicate_historical_sample_candidate")
            if len(set(candidate_canonical)) != len(candidate_canonical):
                raise ValueError("duplicate_sample_candidate")
        else:
            candidate_records = self._validate_structured_candidates(
                candidates,
                historical_records=historical_records,
                scorers=scorers,
            )

        process_evidence: list[Any] = []
        for scorer in scorers:
            replay = self._execute_scorer(
                scorer=scorer,
                records=historical_records,
                label=f"sample-historical-replay-{scorer['target_id']}",
            )
            replay_values = replay["result"]["proxy_values_by_sample"]
            if _canonical_json(replay_values) != _canonical_json(
                scorer["historical_values"]
            ):
                raise ValueError(
                    "sample_historical_replay_mismatch:"
                    f"target_id={scorer['target_id']}"
                )
            candidate_execution = self._execute_scorer(
                scorer=scorer,
                records=candidate_records,
                label=f"sample-candidate-scoring-{scorer['target_id']}",
            )
            candidate_values = candidate_execution["result"][
                "proxy_values_by_sample"
            ]
            if {
                str(sample_id) for sample_id in candidate_values
            } != {str(record["id"]) for record in candidates}:
                raise ValueError(
                    "sample_candidate_values_id_mismatch:"
                    f"target_id={scorer['target_id']}"
                )
            scorer["candidate_values"] = dict(candidate_values)
            process_evidence.extend(list(replay["process_evidence"]))
            process_evidence.extend(
                list(candidate_execution["process_evidence"])
            )

        primary_target_id = str(primary["target_id"])
        index_relations = {
            str(scorer["target_id"]): str(scorer["relation"])
            for scorer in scorers
        }
        generated = []
        for index, record in enumerate(candidates):
            row = {
                "sample_id": record["id"],
                **_public_representation_fields(record, representation),
                "is_novel": True,
                "proxy_value": primary["candidate_values"][record["id"]],
                "index_values": {
                    str(scorer["target_id"]): scorer["candidate_values"][
                        record["id"]
                    ]
                    for scorer in scorers
                },
            }
            if representation == "smiles":
                row["canonical_smiles"] = candidate_canonical[index]
            generated.append(row)

        historical = []
        for index, record in enumerate(historical_records):
            sample_id = str(record["id"])
            row = {
                "sample_id": sample_id,
                **_public_representation_fields(record, representation),
                "is_novel": False,
                "proxy_value": primary["historical_values"][sample_id],
                "index_values": {
                    str(scorer["target_id"]): scorer["historical_values"][
                        sample_id
                    ]
                    for scorer in scorers
                },
            }
            if representation == "smiles":
                row["canonical_smiles"] = historical_canonical[index]
            historical.append(row)
        ranked = rank_multi_index_rows(
            [*historical, *generated],
            index_relations=index_relations,
            primary_target_id=primary_target_id,
        )
        best_generated = next(
            row for row in ranked if row.get("is_novel") is True
        )
        sample_result = {
            "artifact_kind": "sample_evolution_result",
            "best_sample": dict(best_generated),
            "ranked_samples": ranked,
            "rank_history": [
                {
                    "iteration": 1,
                    "ranked_sample_ids": [
                        item["sample_id"] for item in ranked
                    ],
                }
            ],
            "iteration_count": 1,
            "residual_issues": [],
        }
        candidate_bundle_ref = self._write_candidate_bundle(candidates)
        replay_count = len(historical_records) * len(scorers)
        observation = self.observations.publish(
            namespace="sample",
            result=sample_result,
            metadata={
                "implementation_ref": primary["implementation_ref"],
                "formula_artifact_ref": formula_ref,
                "materialization_artifact_ref": materialization_ref,
                "deterministic_replay": True,
                "replay_count": replay_count,
                "candidate_bundle_ref": candidate_bundle_ref,
                "process_evidence": process_evidence,
            },
        )
        return {
            "status": "sample_scoring_complete",
            "observation_ref": observation["observation_ref"],
            "candidate_count": len(candidates),
            "novel_candidate_count": len(candidates),
            "candidate_bundle_ref": candidate_bundle_ref,
            "replay_count": replay_count,
            "deterministic_replay": True,
        }

    def read_candidate_bundle(
        self,
        arguments: Mapping[str, Any],
    ) -> dict[str, Any]:
        bundle_ref = str(arguments.get("candidate_bundle_ref") or "").strip()
        prefix = "workspace:sample-candidate-bundles/"
        if not bundle_ref.startswith(prefix) or not bundle_ref.endswith(".json"):
            raise ValueError("sample_candidate_bundle_ref_invalid")
        digest = bundle_ref[len(prefix) : -len(".json")]
        if len(digest) != 16 or any(
            character not in "0123456789abcdef" for character in digest
        ):
            raise ValueError("sample_candidate_bundle_ref_invalid")
        bundle_root = self._candidate_bundle_root()
        path = (bundle_root / f"{digest}.json").resolve()
        if not path.is_relative_to(bundle_root) or not path.is_file():
            raise ValueError("sample_candidate_bundle_missing")
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, Mapping) or not isinstance(
            value.get("records"), list
        ):
            raise ValueError("sample_candidate_bundle_shape_invalid")
        actual_digest = hashlib.sha256(
            _canonical_json(value).encode("utf-8")
        ).hexdigest()[:16]
        if actual_digest != digest:
            raise ValueError("sample_candidate_bundle_hash_mismatch")
        return {
            "candidate_bundle_ref": bundle_ref,
            "records": copy.deepcopy(list(value["records"])),
        }

    def _write_candidate_bundle(
        self,
        candidates: Sequence[Mapping[str, Any]],
    ) -> str:
        bundle = {
            "records": [copy.deepcopy(dict(record)) for record in candidates]
        }
        canonical = _canonical_json(bundle)
        digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]
        bundle_root = self._candidate_bundle_root()
        path = bundle_root / f"{digest}.json"
        if not path.exists():
            temporary = path.with_suffix(".json.tmp")
            temporary.write_text(
                json.dumps(bundle, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
            os.replace(temporary, path)
        return f"workspace:sample-candidate-bundles/{digest}.json"

    def _candidate_bundle_root(self) -> Path:
        root = (
            self.artifacts.root.resolve()
            / "workspace"
            / "sample-candidate-bundles"
        )
        root.mkdir(parents=True, exist_ok=True)
        return root

    @staticmethod
    def _validate_structured_candidates(
        candidates: Sequence[Mapping[str, Any]],
        *,
        historical_records: Sequence[Mapping[str, Any]],
        scorers: Sequence[Mapping[str, Any]],
    ) -> list[dict[str, Any]]:
        required_paths = sorted({
            str(path)
            for scorer in scorers
            for path in scorer.get("source_paths", ())
        })
        if not required_paths:
            raise ValueError("sample_structured_formula_source_paths_required")
        candidate_identities: list[str] = []
        records: list[dict[str, Any]] = []
        for index, candidate in enumerate(candidates):
            metadata = candidate.get("metadata")
            if not isinstance(metadata, Mapping) or not metadata:
                raise ValueError(
                    f"invalid_structured_sample_candidate:{index}"
                )
            references = validate_candidate_inputs(
                candidate, historical_records, required_paths
            )
            historical_identities = {
                _canonical_json(reference["metadata"]) for reference in references
            }
            identity = _canonical_json(metadata)
            if identity in historical_identities:
                raise ValueError("duplicate_historical_sample_candidate")
            candidate_identities.append(identity)
            records.append(candidate_to_source(candidate, required_paths))
        if len(set(candidate_identities)) != len(candidate_identities):
            raise ValueError("duplicate_sample_candidate")
        return records

    def _load_scorer_pair(
        self,
        *,
        formula_ref: str,
        materialization_ref: str,
        expected_target_kind: str,
    ) -> dict[str, Any]:
        formula_artifact = _artifact(
            self.artifacts,
            formula_ref,
            "proxy_formula_candidate",
        )
        materialization_artifact = _artifact(
            self.artifacts,
            materialization_ref,
            "quantitative_proxy_materialization_result",
        )
        if formula_ref not in materialization_artifact.get("depends_on", []):
            actual_formula_refs = [
                str(ref)
                for ref in materialization_artifact.get("depends_on", [])
                if str(ref).startswith("artifact:")
            ]
            raise ValueError(
                "sample_formula_code_ref_mismatch:"
                f"requested_formula_ref={formula_ref};"
                f"materialization_ref={materialization_ref};"
                "materialization_formula_refs="
                f"{json.dumps(actual_formula_refs, separators=(',', ':'))}"
            )
        formula = formula_artifact["machine_payload"]
        materialization = materialization_artifact["machine_payload"]
        if formula.get("target_kind") != expected_target_kind:
            raise ValueError(
                "sample_formula_target_kind_mismatch:"
                f"formula_ref={formula_ref}:expected={expected_target_kind}:"
                f"actual={formula.get('target_kind')}"
            )
        target_id = str(formula.get("target_id") or "").strip()
        if not target_id:
            raise ValueError(
                f"sample_formula_target_id_required:{formula_ref}"
            )
        relation = str(formula.get("expected_relation") or "").strip()
        if relation not in {
            "higher_proxy_higher_kpi",
            "lower_proxy_higher_kpi",
        }:
            raise ValueError(f"unsupported_expected_relation:{relation}")
        if materialization.get("materialization_status") != "complete":
            raise ValueError(
                "sample_materialization_incomplete:"
                f"materialization_ref={materialization_ref}"
            )
        historical_values = materialization.get("proxy_values_by_sample")
        if not isinstance(historical_values, Mapping):
            raise ValueError("materialization_proxy_values_required")
        implementation_ref = str(
            materialization.get("implementation_ref") or ""
        ).strip()
        if not implementation_ref.startswith(("code_artifact:", "artifact:")):
            raise ValueError("materialization_implementation_ref_invalid")
        execution_refs = materialization.get("execution_observation_refs")
        if not isinstance(execution_refs, list) or len(execution_refs) != 1:
            raise ValueError("single_execution_observation_ref_required")
        execution_observation = self.observations.read(str(execution_refs[0]))
        execution_metadata = execution_observation.get("metadata")
        if not isinstance(execution_metadata, Mapping) or (
            execution_metadata.get("implementation_ref") != implementation_ref
        ):
            raise ValueError("materialization_implementation_authority_mismatch")
        max_route_calls = execution_metadata.get("max_route_calls", 0)
        if (
            isinstance(max_route_calls, bool)
            or not isinstance(max_route_calls, int)
            or not 0 <= max_route_calls <= 10_000
        ):
            raise ValueError("materialization_max_route_calls_invalid")
        self._validate_frozen_implementation_lineage(
            current_formula_ref=formula_ref,
            materialization_artifact=materialization_artifact,
            implementation_ref=implementation_ref,
        )
        return {
            "formula_ref": formula_ref,
            "materialization_ref": materialization_ref,
            "target_id": target_id,
            "relation": relation,
            "source_paths": materialization_input_paths(materialization_artifact),
            "implementation_ref": implementation_ref,
            "max_route_calls": max_route_calls,
            "historical_values": dict(historical_values),
            "prepared_source_ref": execution_metadata.get("prepared_source_ref"),
        }

    def _validate_frozen_implementation_lineage(
        self,
        *,
        current_formula_ref: str,
        materialization_artifact: Mapping[str, Any],
        implementation_ref: str,
    ) -> None:
        materialization_formula_refs = [
            str(ref)
            for ref in materialization_artifact.get("depends_on", [])
            if str(ref).startswith("artifact:")
        ]
        if implementation_ref.startswith("code_artifact:"):
            implementation = self.code_artifacts.read(implementation_ref)
            implementation_formula_refs = [
                str(ref)
                for ref in implementation.get("depends_on", [])
                if str(ref).startswith("artifact:")
            ]
        else:
            implementation = self.artifacts.read(implementation_ref)
            if implementation.get("artifact_kind") != (
                "development_project_snapshot"
            ):
                raise ValueError("sample_implementation_artifact_kind_invalid")
            payload = implementation.get("machine_payload")
            if not isinstance(payload, Mapping):
                raise ValueError(
                    f"artifact_machine_payload_required:{implementation_ref}"
                )
            implementation_formula_refs = [
                str(ref)
                for ref in payload.get("dependency_refs", [])
                if str(ref).startswith("artifact:")
            ]
        if (
            current_formula_ref not in materialization_formula_refs
            or current_formula_ref not in implementation_formula_refs
        ):
            raise ValueError(
                "sample_formula_implementation_ref_mismatch:"
                f"requested_formula_ref={current_formula_ref};"
                "materialization_formula_refs="
                f"{json.dumps(materialization_formula_refs, separators=(',', ':'))};"
                "implementation_formula_refs="
                f"{json.dumps(implementation_formula_refs, separators=(',', ':'))}"
            )

    def _execute_scorer(
        self,
        *,
        scorer: Mapping[str, Any],
        records: Sequence[Mapping[str, Any]],
        label: str,
    ) -> dict[str, Any]:
        implementation_ref = str(scorer["implementation_ref"])
        if implementation_ref.startswith("code_artifact:"):
            execution = self.materializer.execute_records(
                code_artifact_ref=implementation_ref,
                records=records,
                label=label,
                max_route_calls=int(scorer["max_route_calls"]),
            )
        else:
            if self.materializer_projects is None:
                raise ValueError("materializer_project_executor_unavailable")
            execution = self.materializer_projects.execute_formula_records(
                implementation_ref=implementation_ref,
                formula_artifact_ref=str(scorer["formula_ref"]),
                records=records,
                max_route_calls=int(scorer["max_route_calls"]),
            )
        actual = execution["result"]["execution_input_paths"]
        if set(actual) != set(scorer["source_paths"]):
            raise ValueError(
                "sample_execution_input_contract_mismatch:"
                f"materialization_ref={scorer['materialization_ref']}:"
                f"implementation_ref={implementation_ref}:"
                f"expected={scorer['source_paths']}:actual={actual}"
            )
        return execution

    def _canonicalize_smiles(self, values: Sequence[str]) -> list[str | None]:
        script = (
            "import json,sys\n"
            "from rdkit import Chem\n"
            "values=json.loads(sys.argv[1])\n"
            "params=Chem.SmilesParserParams()\n"
            "params.parseName=False\n"
            "out=[]\n"
            "for value in values:\n"
            " mol=Chem.MolFromSmiles(value,params)\n"
            " out.append(None if mol is None else Chem.MolToSmiles(mol,canonical=True))\n"
            "print(json.dumps(out))\n"
        )
        creationflags = 0
        if os.name == "nt":
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        completed = subprocess.run(
            [self.python_executable, "-I", "-c", script, json.dumps(values)],
            capture_output=True,
            text=True,
            timeout=self.timeout_seconds,
            check=False,
            creationflags=creationflags,
            env={**os.environ, "PYTHONHASHSEED": "0"},
        )
        if completed.returncode != 0:
            raise RuntimeError(
                f"smiles_canonicalization_failed:{completed.stderr[-4000:]}"
            )
        result = json.loads(completed.stdout.strip())
        if not isinstance(result, list) or len(result) != len(values):
            raise RuntimeError("smiles_canonicalization_shape_invalid")
        return [None if value is None else str(value) for value in result]


def _artifact(
    store: ArtifactStore, artifact_ref: str, expected_kind: str
) -> dict[str, Any]:
    artifact = store.read(artifact_ref)
    if artifact.get("artifact_kind") != expected_kind:
        raise ValueError(
            "artifact_kind_mismatch:"
            f"{artifact_ref}:expected={expected_kind}:"
            f"actual={artifact.get('artifact_kind')}"
        )
    if not isinstance(artifact.get("machine_payload"), Mapping):
        raise ValueError(f"artifact_machine_payload_required:{artifact_ref}")
    return artifact


def _normalize_auxiliary_pairs(value: Any) -> list[dict[str, str]]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValueError("auxiliary_scorer_pairs_must_be_array")
    normalized: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for index, pair in enumerate(value):
        if not isinstance(pair, Mapping):
            raise ValueError(
                f"auxiliary_scorer_pair_must_be_object:{index}"
            )
        if set(pair) != {
            "formula_artifact_ref",
            "materialization_artifact_ref",
        }:
            raise ValueError(
                f"auxiliary_scorer_pair_shape_invalid:{index}"
            )
        formula_ref = str(pair.get("formula_artifact_ref") or "").strip()
        materialization_ref = str(
            pair.get("materialization_artifact_ref") or ""
        ).strip()
        if not formula_ref.startswith("artifact:"):
            raise ValueError(
                f"auxiliary_formula_artifact_ref_invalid:{index}"
            )
        if not materialization_ref.startswith("artifact:"):
            raise ValueError(
                f"auxiliary_materialization_artifact_ref_invalid:{index}"
            )
        identity = (formula_ref, materialization_ref)
        if identity in seen:
            raise ValueError(f"auxiliary_scorer_pair_duplicate:{index}")
        seen.add(identity)
        normalized.append(
            {
                "formula_artifact_ref": formula_ref,
                "materialization_artifact_ref": materialization_ref,
            }
        )
    return normalized


def _normalize_candidates(value: Any) -> tuple[list[dict[str, Any]], str]:
    if not isinstance(value, list) or not value:
        raise ValueError("sample_candidates_required")
    allowed = {"id", "smiles", "input_description", "metadata"}
    normalized: list[dict[str, Any]] = []
    representations: list[str] = []
    for index, candidate in enumerate(value):
        if not isinstance(candidate, Mapping):
            raise ValueError(f"sample_candidate_must_be_object:{index}")
        extras = set(candidate) - allowed
        if extras:
            raise ValueError(
                f"sample_candidate_forbidden_fields:{index}:{sorted(extras)}"
            )
        sample_id = str(candidate.get("id") or "").strip()
        smiles = str(candidate.get("smiles") or "").strip()
        description = str(candidate.get("input_description") or "").strip()
        metadata = candidate.get("metadata")
        has_metadata = isinstance(metadata, Mapping) and bool(metadata)
        if not sample_id:
            raise ValueError(f"sample_candidate_id_required:{index}")
        if bool(smiles) == bool(has_metadata):
            raise ValueError(
                f"sample_candidate_representation_exclusive:{index}"
            )
        if smiles:
            representations.append("smiles")
            normalized.append(
                {
                    "id": sample_id,
                    "input_description": description,
                    "metadata": {"smiles": smiles},
                }
            )
            continue
        if not description:
            raise ValueError(
                f"structured_sample_input_description_required:{index}"
            )
        representations.append("structured-record")
        normalized.append(
            {
                "id": sample_id,
                "input_description": description,
                "metadata": copy.deepcopy(dict(metadata)),
            }
        )
    ids = [record["id"] for record in normalized]
    if len(set(ids)) != len(ids):
        raise ValueError("duplicate_sample_candidate_id")
    if len(set(representations)) != 1:
        raise ValueError("sample_candidate_representation_mixed")
    return normalized, representations[0]


def _public_representation_fields(
    record: Mapping[str, Any],
    representation: str,
) -> dict[str, Any]:
    description = str(record.get("input_description") or "").strip()
    result: dict[str, Any] = {}
    if representation == "smiles":
        result["smiles"] = str(record.get("metadata", {}).get("smiles") or "")
    if description:
        result["input_description"] = description
    return result


def _canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )
