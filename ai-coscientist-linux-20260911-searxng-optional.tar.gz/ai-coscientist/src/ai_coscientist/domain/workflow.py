from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from ai_coscientist.common.artifacts import ArtifactStore
from ai_coscientist.common.code_artifacts import CodeArtifactStore
from ai_coscientist.common.coding import CommonCodingTools
from ai_coscientist.common.dialogue import validate_human_conversation_input
from ai_coscientist.common.development import (
    CodeInspector,
    DevelopmentProjectRoutes,
    DevelopmentProjectStore,
    DevelopmentTerminalManager,
    validate_development_project_snapshot,
)
from ai_coscientist.common.capabilities import (
    AuthorizedSkillCatalog,
    CapabilityApprovalService,
    CapabilityDevelopmentRoutes,
    CapabilityRegistry,
    ManagedRouteBrokerSessions,
)
from ai_coscientist.common.children import MissionWorkspacePathPolicy
from ai_coscientist.common.observations import ObservationStore
from ai_coscientist.common.memory_lifecycle.events import EventLog
from ai_coscientist.common.source_exploration import SourceExplorer
from ai_coscientist.common.routes import RouteRegistry
from ai_coscientist.common.skills import SkillCatalog

from .closure import ScientificWorkflowClosure
from .computational_property_protocol import (
    computational_property_protocol_schema,
    validate_computational_property_protocol,
)
from .computational_property_result import (
    validate_computational_property_result,
)
from .literature_research import LiteratureResearchResources
from .materializer import MaterializerExecutor, observation_inspect_route
from .materializer_projects import MaterializerProjectExecutor
from .prepared_evaluation import (
    resolve_prepared_records, resolve_materialization_evaluation,
)
from .private_evaluator import PrivateProxyEvaluator
from .sample_executor import SampleExecutor
from .scientific_reporting import report_readers, scientific_report_route
from .source_authority import SourceAuthority, SourceSpec
from .specialist_assessment import (
    specialist_assessment_schema,
    validate_specialist_assessment,
)


COORDINATOR_INSTRUCTIONS = """\
You are the sole scientific coordinator. CommonAgent owns the generic plan,
skill-selection loop, exact artifact transitions, memory lifecycle, and closure
bookkeeping. This workflow currently coordinates its active production skills
in one agent; that workflow choice does not remove CommonAgent's optional
delegation capability.

Common bootstrap establishes the active `task_spec` and matching Global
Evaluation gate before Graph planning. Treat that exact task specification as
the current task authority. Do not schedule `problem-formulation` as ordinary
Graph work. At a settled Frame boundary, common control may retain the contract
or reopen bootstrap from exact newly accepted sources; only that control phase
may replace the active task specification and gate. `prepare-source-data` remains
a normal reviewable scientific work product when source transformation is needed,
and `source-observation` remains optional C3 exploration rather than a formal
cross-skill handoff. Coordinate production skills from their stated prerequisites
and formal outputs.

Measurements in task-scoped prepared data are readable for research and
implementation checks, including paired scoring targets. A scoring role is
not an access restriction; do not request a new task or data-use grant merely
to read ordinary measurements. Explicit source restrictions and mission scope
remain binding. Reading measurements does not authorize silently changing a
Formula or fitting its implementation to answers. Final-KPI Proxy Discovery
publishes formulas only. Review Scientific Method produces a new public review
and may update the formula leaderboard. Rank Proxy Formula instead preserves an
explicitly supplied review while scoring an exact formula/materialization pair
and updating `proxy_formula_leaderboard`; it does not reassess method quality.
Choose between them from the current work's intent and available evidence, not
from a fixed sequence. Both may serve the same Graph node. Dataset fit
must not be presented as an independent blind test. The active plan selects the
exact hypothesis or ranked formula sponsor; Sample validates and serves that
sponsor without choosing among visible research methods. Each skill detail owns
disclosure of its low-level routes and domain evidence rules.
"""


SCIENTIFIC_SKILL_IDS = (
    "source-observation",
    "prepare-source-data",
    "problem-formulation",
    "mindmap-builder",
    "hypothesis-gen",
    "literature-researcher",
    "final-kpi-proxy-discovery",
    "review-scientific-method",
    "rank-proxy-formula",
    "auxiliary-proxy",
    "materializer",
    "sample",
    "final-lca",
    "scientific-report-writer",
)

SCIENTIFIC_TASK_FORMULATION_SKILL_ID = "problem-formulation"


def scientific_skill_catalog(
    skills_root: Path,
    *,
    capability_registry: CapabilityRegistry | None = None,
) -> AuthorizedSkillCatalog:
    """Mount only the currently active scientific workflow skills."""
    overlays = (
        capability_registry.active_skill_roots()
        if capability_registry is not None
        else {}
    )
    include_ids = tuple(dict.fromkeys((*SCIENTIFIC_SKILL_IDS, *sorted(overlays))))
    production = SkillCatalog(
        skills_root,
        include_ids=include_ids,
        overlay_roots=overlays,
        capability_registry=capability_registry,
    )
    return AuthorizedSkillCatalog(
        production,
        meta_root=skills_root.resolve().parent / "meta_skills",
    )


@dataclass
class ScientificWorkflow:
    run_root: Path
    source_authority: SourceAuthority | None
    artifacts: ArtifactStore
    observations: ObservationStore
    code_artifacts: CodeArtifactStore
    development_projects: DevelopmentProjectStore
    routes: RouteRegistry
    closure: ScientificWorkflowClosure
    capability_registry: CapabilityRegistry | None = None

    def approve_capability_candidate(
        self,
        *,
        candidate_ref: str,
        review_ref: str,
        package_hash: str,
        approved_by: str,
        event_log_path: Path,
    ) -> dict[str, object]:
        """Execute one explicit human promotion outside CommonAgent action space."""
        if self.capability_registry is None:
            raise RuntimeError("capability_registry_not_configured")
        project_root = Path(__file__).resolve().parents[3]
        service = CapabilityApprovalService(
            registry=self.capability_registry,
            artifacts=self.artifacts,
            production_skills_root=project_root / "skills",
            reserved_route_names=tuple(route.name for route in self.routes.all()),
            event_log=EventLog(event_log_path.resolve()),
        )
        return service.approve(
            candidate_ref=candidate_ref,
            review_ref=review_ref,
            package_hash=package_hash,
            approved_by=approved_by,
        )

    @classmethod
    def create(
        cls,
        *,
        run_root: Path,
        source_spec: SourceSpec | None,
        source_root: Path | None = None,
        agent_id: str = "scientific-coordinator",
        run_id: str = "scientific-run",
        python_executable: str,
        capability_registry: CapabilityRegistry | None = None,
        materializer_timeout_seconds: float = 60.0,
    ) -> "ScientificWorkflow":
        run_root = run_root.resolve()
        run_root.mkdir(parents=True, exist_ok=True)
        source_authority = (
            SourceAuthority(source_spec) if source_spec is not None else None
        )
        if source_authority is not None:
            source_authority.manifest()
            visible_source_root = run_root / "workspace" / "sanitized-source"
            visible_source_root.mkdir(parents=True, exist_ok=True)
            visible_source_path = visible_source_root / "historical-visible.json"
            visible_goal_path = visible_source_root / "authoritative-goal.md"
            visible_goal_path.write_text(
                source_authority.goal(),
                encoding="utf-8",
            )
            visible_source_path.write_text(
                json.dumps(
                    source_authority.visible_historical(),
                    ensure_ascii=False,
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
            )
            allowed_relative_paths = (
                visible_goal_path.name,
                visible_source_path.name,
            )
            source_path_policy = None
        else:
            if source_root is None:
                raise ValueError("scientific_workflow_source_root_required")
            visible_source_root = source_root.resolve()
            allowed_relative_paths = (".",)
            source_path_policy = MissionWorkspacePathPolicy()
        source_explorer = SourceExplorer(
            source_root=visible_source_root,
            workspace_root=run_root / "workspace" / "source-exploration",
            allowed_relative_paths=allowed_relative_paths,
            python_executable=python_executable,
            path_policy=source_path_policy,
        )
        artifacts = ArtifactStore(
            run_root,
            agent_id=agent_id,
            run_id=run_id,
            payload_validators={
                "specialist_assessment": validate_specialist_assessment,
                "computational_property_protocol": (
                    validate_computational_property_protocol
                ),
                "computational_property_result": (
                    validate_computational_property_result
                ),
                "human_conversation_input": validate_human_conversation_input,
                "development_project_snapshot": (validate_development_project_snapshot),
            },
            payload_schemas={
                "specialist_assessment": specialist_assessment_schema(),
                "computational_property_protocol": (
                    computational_property_protocol_schema()
                ),
            },
        )
        if capability_registry is not None:
            _project_pending_capability_candidates(
                artifacts=artifacts,
                capability_registry=capability_registry,
            )
        observations = ObservationStore(run_root)
        code_artifacts = CodeArtifactStore(run_root)
        development_projects = DevelopmentProjectStore(
            run_root,
            artifacts=artifacts,
            environment_ref=(
                capability_registry.default_project_environment_ref
                if capability_registry is not None
                else f"host-python:{Path(python_executable).resolve()}"
            ),
        )
        managed_route_brokers = (
            ManagedRouteBrokerSessions(
                run_root,
                registry=capability_registry,
            )
            if capability_registry is not None
            else None
        )
        materializer = MaterializerExecutor(
            artifacts=artifacts,
            code_artifacts=code_artifacts,
            observations=observations,
            source_authority=source_authority,
            run_root=run_root,
            record_resolver=(
                lambda formula_ref, prepared_source_ref: _prepared_records_for_execution(
                    artifacts=artifacts,
                    source_explorer=source_explorer,
                    formula_ref=formula_ref,
                    prepared_source_ref=prepared_source_ref,
                )
            ),
            capability_registry=capability_registry,
            python_executable=python_executable,
            timeout_seconds=float(materializer_timeout_seconds),
        )
        materializer_projects = MaterializerProjectExecutor(
            artifacts=artifacts,
            observations=observations,
            projects=development_projects,
            run_root=run_root,
            records_for_formula=materializer.records_for_formula,
            managed_route_brokers=managed_route_brokers,
            capability_registry=capability_registry,
            timeout_seconds=float(materializer_timeout_seconds),
        )
        development_project_routes = DevelopmentProjectRoutes(
            development_projects,
            CodeInspector(development_projects),
            DevelopmentTerminalManager(
                development_projects,
                shell_launch=(
                    capability_registry.default_project_shell_launch
                    if capability_registry is not None else None
                ),
            ),
            managed_route_brokers,
            execution_workspace_resolver=materializer_projects.resolve_development_execution,
            execution_inventory=materializer_projects.execution_inventory,
            execution_read=materializer_projects.execution_read,
        )
        sample = SampleExecutor(
            artifacts=artifacts,
            code_artifacts=code_artifacts,
            observations=observations,
            source_authority=source_authority,
            materializer=materializer,
            materializer_projects=materializer_projects,
            python_executable=python_executable,
        )
        private_evaluator = PrivateProxyEvaluator(
            artifacts=artifacts,
            observations=observations,
            source_authority=source_authority,
            target_resolver=lambda formula, materialization: resolve_materialization_evaluation(
                _PreparedSourceResolverRuntime(artifacts, source_explorer, observations),
                formula, materialization,
            ),
        )
        literature = LiteratureResearchResources.from_environment(run_root=run_root)
        closure = ScientificWorkflowClosure(
            artifacts=artifacts,
            observations=observations,
            source_authority=source_authority,
        )
        common_coding = CommonCodingTools(
            code_artifacts,
            environment_inspector=(
                capability_registry.inspect_python_environment
                if capability_registry is not None
                else None
            ),
        )
        project_root = Path(__file__).resolve().parents[3]
        capability_development = (
            CapabilityDevelopmentRoutes(
                capability_registry,
                source_roots=(project_root, run_root),
                production_skills_root=project_root / "skills",
                skill_validator_path=(
                    project_root
                    / ".agents"
                    / "skills"
                    / "ai-coscientist-skill-creator"
                    / "scripts"
                    / "validate_project_skill.py"
                ),
                development_projects=development_projects,
            )
            if capability_registry is not None
            else None
        )
        routes = RouteRegistry(
            [
                *(source_authority.routes() if source_authority is not None else ()),
                *common_coding.routes(
                    skill_ids=(
                        "materializer",
                        "route-creation",
                        "python-package-resolver",
                    )
                ),
                *development_project_routes.routes(
                    skill_ids=(
                        "materializer",
                        "route-creation",
                        "python-package-resolver",
                    )
                ),
                *source_explorer.routes(
                    skill_ids=(
                        "source-observation",
                        "prepare-source-data",
                        "problem-formulation",
                        "mindmap-builder",
                        "hypothesis-gen",
                        "final-kpi-proxy-discovery",
                        "sample",
                        "materializer",
                    )
                ),
                *materializer.routes(),
                *materializer_projects.routes(),
                *sample.routes(),
                *private_evaluator.routes(),
                *literature.routes(skill_ids=("literature-researcher",)),
                observation_inspect_route(
                    observations,
                    materializer=materializer,
                    raw_output_loader=materializer_projects.read_raw_output,
                ),
                closure.route(),
                scientific_report_route(
                    run_root=run_root,
                    artifacts=artifacts,
                    reference_resolver=report_readers(
                        run_root, artifacts, source_explorer.reference_bytes,
                    )[1],
                ),
                *(
                    capability_development.routes()
                    if capability_development is not None
                    else ()
                ),
                *(
                    capability_registry.agent_routes()
                    if capability_registry is not None
                    else ()
                ),
            ]
        )
        return cls(
            run_root=run_root,
            source_authority=source_authority,
            artifacts=artifacts,
            observations=observations,
            code_artifacts=code_artifacts,
            development_projects=development_projects,
            routes=routes,
            closure=closure,
            capability_registry=capability_registry,
        )


def _project_pending_capability_candidates(
    *,
    artifacts: ArtifactStore,
    capability_registry: CapabilityRegistry,
) -> tuple[str, ...]:
    """Project pending packages into one task without globally approving them."""
    payloads = capability_registry.pending_candidate_payloads()
    route_candidate_refs: dict[tuple[str, str], str] = {}
    projected_refs: list[str] = []

    for payload in payloads:
        if payload["asset_type"] != "route_package":
            continue
        receipt = artifacts.publish(
            artifact_kind="capability_candidate",
            artifact_id=(
                "managed-pending-route-package-"
                f"{payload['asset_id']}-{payload['package_hash']}"
            ),
            title=f"Pending Route package: {payload['asset_id']}",
            markdown=(
                "Mechanically projected from the authoritative capability "
                "Registry. Use remains pending and must propagate lineage."
            ),
            machine_payload=payload,
            status="proposed",
            summary=str(payload["purpose"]),
        )
        candidate_ref = str(receipt["artifact_ref"])
        projected_refs.append(candidate_ref)
        snapshot = capability_registry.pending_candidate_snapshot(
            str(payload["package_ref"]),
            max_text_chars=0,
        )
        for route in snapshot["manifest"]["routes"]:
            route_candidate_refs[
                (
                    str(route["route_name"]),
                    str(payload["package_hash"]),
                )
            ] = candidate_ref

    for payload in payloads:
        if payload["asset_type"] != "skill":
            continue
        dependency_refs: list[str] = []
        dependencies_available = True
        for dependency in payload.get("route_dependencies") or ():
            identity = (
                str(dependency["route_name"]),
                str(dependency["package_hash"]),
            )
            candidate_ref = route_candidate_refs.get(identity)
            if candidate_ref is not None:
                dependency_refs.append(candidate_ref)
                continue
            try:
                capability_registry.resolve_route_ref(
                    f"approved_route:{identity[0]}:{identity[1]}"
                )
            except (KeyError, RuntimeError, ValueError):
                dependencies_available = False
                break
        if not dependencies_available:
            continue
        receipt = artifacts.publish(
            artifact_kind="capability_candidate",
            artifact_id=(
                f"managed-pending-skill-{payload['asset_id']}-{payload['package_hash']}"
            ),
            title=f"Pending Skill: {payload['asset_id']}",
            markdown=(
                "Mechanically projected from the authoritative capability "
                "Registry. Use remains pending and must propagate lineage."
            ),
            machine_payload=payload,
            status="proposed",
            summary=str(payload["purpose"]),
            depends_on=tuple(dict.fromkeys(dependency_refs)),
        )
        projected_refs.append(str(receipt["artifact_ref"]))

    return tuple(projected_refs)


@dataclass(frozen=True)
class _PreparedSourceResolverRuntime:
    artifacts: ArtifactStore
    source_explorer: SourceExplorer
    observations: ObservationStore | None = None

    def read_artifact(self, artifact_ref: str) -> dict[str, Any]:
        return self.artifacts.read(artifact_ref)

    def read_ref(self, ref: str) -> dict[str, Any]:
        if ref.startswith("execution_observation:") and self.observations is not None:
            return self.observations.read(ref)
        return self.artifacts.read(ref)

    def call_route(self, name: str, arguments: Mapping[str, Any]) -> Any:
        if name == "source_probe":
            return self.source_explorer.probe(arguments)
        if name == "source_read":
            return self.source_explorer.read(arguments)
        if name == "read_ref":
            return self.read_ref(str(arguments["ref"]))
        raise KeyError(f"prepared_source_route_unavailable:{name}")


def _prepared_records_for_execution(
    *,
    artifacts: ArtifactStore,
    source_explorer: SourceExplorer,
    formula_ref: str,
    prepared_source_ref: str,
) -> Sequence[Mapping[str, Any]]:
    """Resolve the execution-selected table, independently of research lineage."""
    formula = artifacts.read(formula_ref)
    resolver = _PreparedSourceResolverRuntime(artifacts, source_explorer)
    prepared, records = resolve_prepared_records(resolver, prepared_source_ref, consumer="materializer")
    if (formula["machine_payload"].get("target_kind") == "final_kpi"
            and prepared.evaluation_binding is not None
            and prepared.evaluation_binding["target_id"] != formula["machine_payload"].get("target_id")):
        raise ValueError(
            "prepared_evaluation_target_id_mismatch:"
            f"formula_ref={formula_ref}:prepared_source_ref={prepared_source_ref}:"
            f"expected={formula['machine_payload'].get('target_id')}:"
            f"actual={prepared.evaluation_binding['target_id']}"
        )
    return records
