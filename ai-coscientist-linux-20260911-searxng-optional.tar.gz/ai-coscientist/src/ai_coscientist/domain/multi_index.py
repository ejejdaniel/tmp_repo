from __future__ import annotations

import math
from typing import Any, Mapping, Sequence


_ALLOWED_RELATIONS = {
    "higher_proxy_higher_kpi",
    "lower_proxy_higher_kpi",
}


def rank_multi_index_rows(
    rows: Sequence[Mapping[str, Any]],
    *,
    index_relations: Mapping[str, str],
    primary_target_id: str,
) -> list[dict[str, Any]]:
    target_ids = [str(target_id) for target_id in index_relations]
    if not target_ids:
        raise ValueError("multi_index_relations_required")
    if not primary_target_id or primary_target_id not in index_relations:
        raise ValueError("multi_index_primary_target_required")
    for target_id, relation in index_relations.items():
        if relation not in _ALLOWED_RELATIONS:
            raise ValueError(
                f"multi_index_relation_unsupported:{target_id}:{relation}"
            )

    normalized = [
        _normalize_row(row, expected_target_ids=set(target_ids))
        for row in rows
    ]
    sample_ids = [row["sample_id"] for row in normalized]
    if len(set(sample_ids)) != len(sample_ids):
        raise ValueError("multi_index_sample_id_duplicate")

    rank_maps = {
        target_id: _dense_rank(
            normalized,
            target_id=target_id,
            descending=(
                index_relations[target_id] == "higher_proxy_higher_kpi"
            ),
        )
        for target_id in target_ids
    }
    fronts = _pareto_fronts(
        normalized,
        target_ids=target_ids,
        index_relations=index_relations,
    )
    tier_by_id = {
        sample_id: tier
        for tier, sample_ids_in_front in enumerate(fronts, start=1)
        for sample_id in sample_ids_in_front
    }
    auxiliary_target_ids = sorted(
        target_id for target_id in target_ids if target_id != primary_target_id
    )

    ranked: list[dict[str, Any]] = []
    for row in normalized:
        sample_id = row["sample_id"]
        enriched = dict(row)
        enriched["index_values"] = dict(row["index_values"])
        enriched["index_ranks"] = {
            target_id: rank_maps[target_id][sample_id]
            for target_id in target_ids
        }
        enriched["pareto_tier"] = tier_by_id[sample_id]
        ranked.append(enriched)
    ranked.sort(
        key=lambda row: (
            int(row["pareto_tier"]),
            int(row["index_ranks"][primary_target_id]),
            tuple(
                int(row["index_ranks"][target_id])
                for target_id in auxiliary_target_ids
            ),
            str(row["sample_id"]),
        )
    )
    return ranked


def _normalize_row(
    row: Mapping[str, Any],
    *,
    expected_target_ids: set[str],
) -> dict[str, Any]:
    sample_id = str(row.get("sample_id") or "").strip()
    if not sample_id:
        raise ValueError("multi_index_sample_id_required")
    values = row.get("index_values")
    if not isinstance(values, Mapping):
        raise ValueError(f"multi_index_values_required:{sample_id}")
    actual_target_ids = {str(target_id) for target_id in values}
    if actual_target_ids != expected_target_ids:
        raise ValueError(
            "multi_index_target_set_mismatch:"
            f"sample_id={sample_id}:expected={sorted(expected_target_ids)}:"
            f"actual={sorted(actual_target_ids)}"
        )
    result = dict(row)
    result["sample_id"] = sample_id
    result["index_values"] = {
        target_id: _finite(values[target_id], sample_id=sample_id, target_id=target_id)
        for target_id in sorted(expected_target_ids)
    }
    return result


def _dense_rank(
    rows: Sequence[Mapping[str, Any]],
    *,
    target_id: str,
    descending: bool,
) -> dict[str, int]:
    ordered_values = sorted(
        {
            float(row["index_values"][target_id])
            for row in rows
        },
        reverse=descending,
    )
    value_rank = {
        value: rank
        for rank, value in enumerate(ordered_values, start=1)
    }
    return {
        str(row["sample_id"]): value_rank[
            float(row["index_values"][target_id])
        ]
        for row in rows
    }


def _pareto_fronts(
    rows: Sequence[Mapping[str, Any]],
    *,
    target_ids: Sequence[str],
    index_relations: Mapping[str, str],
) -> list[list[str]]:
    remaining = {str(row["sample_id"]): row for row in rows}
    fronts: list[list[str]] = []
    while remaining:
        front = [
            sample_id
            for sample_id, candidate in remaining.items()
            if not any(
                other_id != sample_id
                and _dominates(
                    other,
                    candidate,
                    target_ids=target_ids,
                    index_relations=index_relations,
                )
                for other_id, other in remaining.items()
            )
        ]
        if not front:
            raise RuntimeError("multi_index_pareto_front_empty")
        ordered_front = sorted(front)
        fronts.append(ordered_front)
        for sample_id in ordered_front:
            del remaining[sample_id]
    return fronts


def _dominates(
    left: Mapping[str, Any],
    right: Mapping[str, Any],
    *,
    target_ids: Sequence[str],
    index_relations: Mapping[str, str],
) -> bool:
    not_worse = True
    strictly_better = False
    for target_id in target_ids:
        left_value = float(left["index_values"][target_id])
        right_value = float(right["index_values"][target_id])
        if index_relations[target_id] == "lower_proxy_higher_kpi":
            left_value = -left_value
            right_value = -right_value
        if left_value < right_value:
            not_worse = False
            break
        if left_value > right_value:
            strictly_better = True
    return not_worse and strictly_better


def _finite(value: Any, *, sample_id: str, target_id: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(
            f"multi_index_value_non_numeric:{sample_id}:{target_id}"
        )
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(
            f"multi_index_value_non_finite:{sample_id}:{target_id}"
        )
    return number