from __future__ import annotations

import copy
from typing import Any, Mapping, Sequence


def _nonempty_text_schema() -> dict[str, Any]:
    return {"type": "string", "minLength": 1}


def _exact_object_schema(
    properties: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": dict(properties),
        "required": list(properties),
        "additionalProperties": False,
    }


_REQUIRED_INPUT_SCHEMA = _exact_object_schema(
    {
        "input_id": _nonempty_text_schema(),
        "requirements": _nonempty_text_schema(),
    }
)
_RESULT_CONTRACT_SCHEMA = _exact_object_schema(
    {
        "output_id": _nonempty_text_schema(),
        "unit": _nonempty_text_schema(),
        "calculation_expression": _nonempty_text_schema(),
        "interpretation": _nonempty_text_schema(),
    }
)
_COMPUTATIONAL_PROPERTY_PROTOCOL_SCHEMA = _exact_object_schema(
    {
        "artifact_kind": {
            "type": "string",
            "enum": ["computational_property_protocol"],
        },
        "quantity_id": _nonempty_text_schema(),
        "scientific_definition": _nonempty_text_schema(),
        "required_inputs": {
            "type": "array",
            "items": _REQUIRED_INPUT_SCHEMA,
        },
        "result_contract": _RESULT_CONTRACT_SCHEMA,
    }
)

_TOP_LEVEL_KEYS = frozenset(
    _COMPUTATIONAL_PROPERTY_PROTOCOL_SCHEMA["properties"]
)
_REQUIRED_INPUT_KEYS = frozenset(_REQUIRED_INPUT_SCHEMA["properties"])
_RESULT_CONTRACT_KEYS = frozenset(_RESULT_CONTRACT_SCHEMA["properties"])


class ComputationalPropertyProtocolError(ValueError):
    pass


def computational_property_protocol_schema() -> dict[str, Any]:
    """Return the public protocol shape for authoring, validation and repair."""
    return copy.deepcopy(_COMPUTATIONAL_PROPERTY_PROTOCOL_SCHEMA)


def validate_computational_property_protocol(payload: Any) -> None:
    """Validate structure and exact internal refs without judging science."""
    if not isinstance(payload, Mapping):
        raise ComputationalPropertyProtocolError(
            "computational_property_protocol_must_be_object"
        )
    _require_exact_keys(payload, _TOP_LEVEL_KEYS, "protocol")
    if payload.get("artifact_kind") != "computational_property_protocol":
        raise ComputationalPropertyProtocolError(
            "computational_property_protocol_kind_invalid"
        )
    _required_text(payload.get("quantity_id"), "quantity_id")
    _required_text(payload.get("scientific_definition"), "scientific_definition")

    required_inputs = _object_array(
        payload.get("required_inputs"),
        "required_inputs",
        allow_empty=True,
    )
    input_ids: set[str] = set()
    for index, item in enumerate(required_inputs):
        _require_exact_keys(item, _REQUIRED_INPUT_KEYS, f"required_inputs:{index}")
        input_id = _required_text(item.get("input_id"), f"required_inputs:{index}:input_id")
        _required_text(item.get("requirements"), f"required_inputs:{index}:requirements")
        if input_id in input_ids:
            raise ComputationalPropertyProtocolError(
                f"computational_property_protocol_input_id_duplicate:{input_id}"
            )
        input_ids.add(input_id)

    result = payload.get("result_contract")
    if not isinstance(result, Mapping):
        raise ComputationalPropertyProtocolError(
            "computational_property_protocol_result_contract_must_be_object"
        )
    _require_exact_keys(result, _RESULT_CONTRACT_KEYS, "result_contract")
    _required_text(result.get("output_id"), "result_contract:output_id")
    _required_text(result.get("unit"), "result_contract:unit")
    _required_text(
        result.get("calculation_expression"),
        "result_contract:calculation_expression",
    )
    _required_text(result.get("interpretation"), "result_contract:interpretation")


def _require_exact_keys(
    value: Mapping[str, Any], expected: frozenset[str], label: str
) -> None:
    actual = set(value)
    if actual != expected:
        raise ComputationalPropertyProtocolError(
            f"computational_property_protocol_{label}_keys_invalid:"
            f"missing={sorted(expected - actual)}:extra={sorted(actual - expected)}"
        )


def _required_text(value: Any, label: str) -> str:
    text = str(value or "").strip()
    if not text:
        raise ComputationalPropertyProtocolError(
            f"computational_property_protocol_{label}_required"
        )
    return text


def _object_array(
    value: Any, label: str, *, allow_empty: bool
) -> tuple[Mapping[str, Any], ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise ComputationalPropertyProtocolError(
            f"computational_property_protocol_{label}_must_be_array"
        )
    if not value and not allow_empty:
        raise ComputationalPropertyProtocolError(
            f"computational_property_protocol_{label}_required"
        )
    if any(not isinstance(item, Mapping) for item in value):
        raise ComputationalPropertyProtocolError(
            f"computational_property_protocol_{label}_items_must_be_objects"
        )
    return tuple(item for item in value if isinstance(item, Mapping))
