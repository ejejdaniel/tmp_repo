from __future__ import annotations

import json
import math
from typing import Any, Mapping, Sequence

from .prepared_evaluation import materialization_dataset_scope, validate_evaluation_binding
from .scientific_review import validate_scientific_method_review


def terminal_proxy_formula_leaderboard(
    artifacts: Sequence[Mapping[str, Any]],
) -> dict[str, Any] | None:
    boards = [
        dict(item)
        for item in artifacts
        if item.get("artifact_kind") == "proxy_formula_leaderboard"
    ]
    if not boards:
        return None
    for board in boards:
        validate_proxy_formula_leaderboard(board.get("machine_payload"))
    if len(boards) == 1:
        return boards[0]
    refs = {str(item.get("artifact_ref") or "") for item in boards}
    superseded = {
        str(ref)
        for item in boards
        for ref in item.get("depends_on") or []
        if str(ref) in refs
    }
    tips = [
        item
        for item in boards
        if str(item.get("artifact_ref") or "") not in superseded
    ]
    if len(tips) != 1:
        raise ValueError("proxy_formula_leaderboard_lineage_ambiguous")
    return tips[0]


def update_proxy_formula_leaderboard(
    runtime: Any,
    *,
    formula: Mapping[str, Any],
    materialization: Mapping[str, Any] | None,
    review: Mapping[str, Any],
    prior_leaderboard: Mapping[str, Any] | None,
) -> str | None:
    """Rank one explicitly reviewed formula without exposing private KPI values."""
    formula_ref = str(formula.get("artifact_ref") or "")
    review_payload = validate_scientific_method_review(
        review,
        expected_method_ref=formula_ref,
    )
    review_ref = str(review.get("artifact_ref") or "")

    prior_entries: list[dict[str, Any]] = []
    prior_entry: dict[str, Any] | None = None
    if prior_leaderboard is not None:
        prior_payload = prior_leaderboard.get("machine_payload")
        validate_proxy_formula_leaderboard(prior_payload)
        prior_entries = [dict(item) for item in prior_payload["ranked_entries"]]
        selected_materialization = materialization
        if selected_materialization is None:
            matches = [entry for entry in prior_entries if entry["formula_artifact_ref"] == formula_ref]
            if len(matches) == 1:
                selected_materialization = runtime.read_artifact(matches[0]["materialization_artifact_ref"])
        scope = (materialization_dataset_scope(runtime, selected_materialization)
                 if selected_materialization is not None else None)
        target_id = formula["machine_payload"].get("target_id")
        same_scope = []
        for entry in prior_entries:
            prior_formula = (
                formula if entry["formula_artifact_ref"] == formula_ref
                else runtime.read_artifact(entry["formula_artifact_ref"])
            )
            if (
                materialization_dataset_scope(runtime, runtime.read_artifact(entry["materialization_artifact_ref"])) == scope
                and prior_formula["machine_payload"].get("target_id") == target_id
            ):
                same_scope.append(entry)
        prior_entries = same_scope
        matches = [
            item
            for item in prior_entries
            if item["formula_artifact_ref"] == formula_ref
        ]
        if len(matches) > 1:
            raise ValueError("proxy_formula_leaderboard_formula_ref_duplicate")
        prior_entry = matches[0] if matches else None

    if (prior_entry is not None and materialization is not None
            and prior_entry["materialization_artifact_ref"] != materialization["artifact_ref"]):
        prior_entries = [entry for entry in prior_entries if entry["formula_artifact_ref"] != formula_ref]
        prior_entry = None

    if prior_entry is not None:
        if materialization is not None:
            materialization_ref = _validate_formula_materialization_pair(
                formula,
                materialization,
            )
            if prior_entry["materialization_artifact_ref"] != materialization_ref:
                raise ValueError(
                    "proxy_formula_leaderboard_materialization_ref_changed"
                )
        if (
            prior_entry["review_artifact_ref"] == review_ref
            and float(prior_entry["review_score"])
            == float(review_payload["review_score"])
        ):
            return str(prior_leaderboard.get("artifact_ref") or "")
        refreshed = []
        for entry in prior_entries:
            candidate = dict(entry)
            if candidate["formula_artifact_ref"] == formula_ref:
                candidate["review_artifact_ref"] = review_ref
                candidate["review_score"] = float(review_payload["review_score"])
            refreshed.append(candidate)
        result = _publish_leaderboard_snapshot(
            runtime,
            prior_leaderboard=prior_leaderboard,
            entries=refreshed,
            action_summary=(
                f"Refreshed the public review for {formula_ref} and recomputed "
                "the Pareto-ranked proxy formula leaderboard."
            ),
        )
        return str(result["artifact_ref"])

    if materialization is None:
        return None
    materialization_ref = _validate_formula_materialization_pair(
        formula,
        materialization,
    )
    evaluation = runtime.call_route(
        "scientific_private_proxy_evaluate",
        {
            "formula_artifact_ref": formula_ref,
            "materialization_artifact_ref": materialization_ref,
        },
    )
    aggregate = evaluation.get("aggregate")
    if not isinstance(aggregate, Mapping):
        raise ValueError("private_proxy_evaluation_aggregate_required")
    observation_ref = str(evaluation.get("observation_ref") or "")
    if not observation_ref:
        raise ValueError("private_proxy_evaluation_observation_ref_required")
    inspected = runtime.call_route(
        "scientific_observation_inspect",
        {
            "observation_ref": observation_ref,
            "selected_paths": ["result"],
        },
    )
    _validate_private_evaluation_observation(
        inspected,
        formula_ref=formula_ref,
        materialization_ref=materialization_ref,
        aggregate=aggregate,
    )
    trend_score = _trend_alignment_score(aggregate)
    entries = [
        *prior_entries,
        {
            "rank": 0,
            "formula_artifact_ref": formula_ref,
            "materialization_artifact_ref": materialization_ref,
            "evaluation_observation_ref": observation_ref,
            "trend_alignment_score": trend_score,
            "review_artifact_ref": review_ref,
            "review_score": float(review_payload["review_score"]),
            "pareto_tier": 0,
        },
    ]
    result = _publish_leaderboard_snapshot(
        runtime,
        prior_leaderboard=prior_leaderboard,
        entries=entries,
        action_summary=(
            f"Evaluated {formula_ref} at {trend_score:.3f}/100 historical "
            f"trend alignment with public review score "
            f"{float(review_payload['review_score']):.3f}/100 and published "
            "the Pareto-ranked proxy formula leaderboard."
        ),
    )
    return str(result["artifact_ref"])


def validate_proxy_formula_leaderboard(payload: Any) -> None:
    if not isinstance(payload, Mapping):
        raise ValueError("proxy_formula_leaderboard_payload_required")
    if set(payload) != {"artifact_kind", "version", "ranked_entries"}:
        raise ValueError("proxy_formula_leaderboard_root_shape_invalid")
    if payload.get("artifact_kind") != "proxy_formula_leaderboard":
        raise ValueError("proxy_formula_leaderboard_kind_invalid")
    version = payload.get("version")
    if isinstance(version, bool) or not isinstance(version, int) or version < 1:
        raise ValueError("proxy_formula_leaderboard_version_invalid")
    entries = payload.get("ranked_entries")
    if not isinstance(entries, list) or not entries:
        raise ValueError("proxy_formula_leaderboard_entries_required")
    expected_entry = {
        "rank",
        "formula_artifact_ref",
        "materialization_artifact_ref",
        "evaluation_observation_ref",
        "trend_alignment_score",
        "review_artifact_ref",
        "review_score",
        "pareto_tier",
    }
    formula_refs: set[str] = set()
    for expected_rank, raw in enumerate(entries, start=1):
        if not isinstance(raw, Mapping) or set(raw) != expected_entry:
            raise ValueError("proxy_formula_leaderboard_entry_shape_invalid")
        if raw.get("rank") != expected_rank:
            raise ValueError("proxy_formula_leaderboard_rank_invalid")
        formula_ref = str(raw.get("formula_artifact_ref") or "")
        materialization_ref = str(raw.get("materialization_artifact_ref") or "")
        observation_ref = str(raw.get("evaluation_observation_ref") or "")
        review_ref = str(raw.get("review_artifact_ref") or "")
        if not formula_ref.startswith("artifact:"):
            raise ValueError("proxy_formula_leaderboard_formula_ref_invalid")
        if not materialization_ref.startswith("artifact:"):
            raise ValueError("proxy_formula_leaderboard_materialization_ref_invalid")
        if not observation_ref.startswith(
            "execution_observation:private-evaluator:"
        ):
            raise ValueError("proxy_formula_leaderboard_evaluation_ref_invalid")
        if not review_ref.startswith("artifact:"):
            raise ValueError("proxy_formula_leaderboard_review_ref_invalid")
        if formula_ref in formula_refs:
            raise ValueError("proxy_formula_leaderboard_formula_ref_duplicate")
        formula_refs.add(formula_ref)
        for score_name in ("trend_alignment_score", "review_score"):
            score = raw.get(score_name)
            if (
                isinstance(score, bool)
                or not isinstance(score, (int, float))
                or not math.isfinite(float(score))
                or not 0.0 <= float(score) <= 100.0
            ):
                raise ValueError(
                    f"proxy_formula_leaderboard_score_invalid:{score_name}"
                )
        tier = raw.get("pareto_tier")
        if isinstance(tier, bool) or not isinstance(tier, int) or tier < 1:
            raise ValueError("proxy_formula_leaderboard_pareto_tier_invalid")


def _validate_formula_materialization_pair(
    formula: Mapping[str, Any],
    materialization: Mapping[str, Any],
) -> str:
    formula_ref = str(formula.get("artifact_ref") or "")
    materialization_ref = str(materialization.get("artifact_ref") or "")
    if formula_ref not in {str(ref) for ref in materialization.get("depends_on") or []}:
        raise ValueError("proxy_formula_leaderboard_materialization_pair_invalid")
    payload = materialization.get("machine_payload")
    if (
        not isinstance(payload, Mapping)
        or payload.get("materialization_status") != "complete"
    ):
        raise ValueError("proxy_formula_leaderboard_materialization_incomplete")
    return materialization_ref


def _trend_alignment_score(aggregate: Mapping[str, Any]) -> float:
    if aggregate.get("raw_kpi_values_disclosed") is not False:
        raise ValueError("private_proxy_evaluation_disclosed_raw_kpi_values")
    values: list[float] = []
    for name in (
        "direction_adjusted_spearman_rho",
        "direction_adjusted_kendall_tau_b",
    ):
        value = aggregate.get(name)
        if (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(float(value))
            or not -1.0 <= float(value) <= 1.0
        ):
            raise ValueError(f"private_proxy_evaluation_metric_invalid:{name}")
        values.append(float(value))
    return round(25.0 * (values[0] + values[1] + 2.0), 6)


def _validate_private_evaluation_observation(
    inspected: Mapping[str, Any],
    *,
    formula_ref: str,
    materialization_ref: str,
    aggregate: Mapping[str, Any],
) -> None:
    observation = inspected.get("observation")
    if not isinstance(observation, Mapping):
        raise ValueError("private_proxy_evaluation_observation_required")
    if observation.get("namespace") != "private-evaluator":
        raise ValueError("private_proxy_evaluation_namespace_invalid")
    metadata = observation.get("metadata")
    if not isinstance(metadata, Mapping):
        raise ValueError("private_proxy_evaluation_metadata_required")
    if metadata.get("formula_artifact_ref") != formula_ref:
        raise ValueError("private_proxy_evaluation_formula_ref_mismatch")
    if metadata.get("materialization_artifact_ref") != materialization_ref:
        raise ValueError("private_proxy_evaluation_materialization_ref_mismatch")
    if observation.get("result") != dict(aggregate):
        raise ValueError("private_proxy_evaluation_result_mismatch")
    _trend_alignment_score(aggregate)


def _publish_leaderboard_snapshot(
    runtime: Any,
    *,
    prior_leaderboard: Mapping[str, Any] | None,
    entries: Sequence[Mapping[str, Any]],
    action_summary: str,
) -> dict[str, Any]:
    prior_version = 0
    prior_ref = ""
    if prior_leaderboard is not None:
        prior_payload = prior_leaderboard.get("machine_payload")
        validate_proxy_formula_leaderboard(prior_payload)
        prior_version = int(prior_payload["version"])
        prior_ref = str(prior_leaderboard.get("artifact_ref") or "")
    ranked = _rank_formula_entries(runtime, entries)
    payload = {
        "artifact_kind": "proxy_formula_leaderboard",
        "version": prior_version + 1,
        "ranked_entries": ranked,
    }
    validate_proxy_formula_leaderboard(payload)
    dependencies: list[str] = [prior_ref] if prior_ref else []
    trace_refs: list[str] = []
    for entry in ranked:
        dependencies.extend(
            [
                str(entry["formula_artifact_ref"]),
                str(entry["materialization_artifact_ref"]),
                str(entry["evaluation_observation_ref"]),
                str(entry["review_artifact_ref"]),
            ]
        )
        trace_refs.append(str(entry["evaluation_observation_ref"]))
    receipt = runtime.publish_artifact(
        artifact_kind="proxy_formula_leaderboard",
        artifact_id=f"proxy-formula-leaderboard-v{payload['version']}",
        title=f"Proxy Formula Leaderboard v{payload['version']}",
        markdown=_render_leaderboard_markdown(runtime, payload),
        summary=(
            "Evaluated proxy formulas grouped into Pareto tiers using public "
            "scientific-review score and private historical trend alignment."
        ),
        machine_payload=payload,
        depends_on=list(dict.fromkeys(ref for ref in dependencies if ref)),
        trace_refs=list(dict.fromkeys(trace_refs)),
        self_review={"leaderboard_contract_validated": True},
    )
    board_ref = str(receipt["artifact_ref"])
    stored = runtime.read_artifact(board_ref)
    if stored.get("machine_payload") != payload:
        raise ValueError("published_proxy_formula_leaderboard_readback_mismatch")
    return {
        "status": "completed",
        "artifact_ref": board_ref,
        "summary": action_summary,
    }


def _rank_formula_entries(
    runtime: Any,
    entries: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    ranked = [dict(entry) for entry in entries]
    _assign_pareto_tiers(ranked)
    tier_one = [entry for entry in ranked if entry["pareto_tier"] == 1]
    selected_ref = ""
    if len(tier_one) == 1:
        selected_ref = str(tier_one[0]["formula_artifact_ref"])
    elif len(tier_one) > 1:
        options = [_formula_selection_context(runtime, entry) for entry in tier_one]
        allowed_refs = [str(item["formula_artifact_ref"]) for item in options]
        selection = runtime.generate_json(
            (
                "Choose one formula from Pareto tier 1 as the current rank-1 "
                "method. Balance scientific interpretability, applicability, "
                "public review, and historical trend evidence. Select only an "
                "exact supplied formula_artifact_ref. Do not rewrite a formula "
                "or prescribe the next skill. Give one concise selection reason."
            ),
            json.dumps(
                {"pareto_tier_1_options": options},
                ensure_ascii=False,
                indent=2,
            ),
            purpose="select-pareto-tier-one-proxy-formula",
            schema={
                "type": "object",
                "properties": {
                    "formula_artifact_ref": {
                        "type": "string",
                        "enum": allowed_refs,
                    },
                    "reason": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 1200,
                    },
                },
                "required": ["formula_artifact_ref", "reason"],
                "additionalProperties": False,
            },
        )
        selected_ref = str(selection["formula_artifact_ref"])
    ranked.sort(
        key=lambda item: (
            int(item["pareto_tier"]),
            0 if item["formula_artifact_ref"] == selected_ref else 1,
            -float(item["trend_alignment_score"]),
            -float(item["review_score"]),
            str(item["formula_artifact_ref"]),
        )
    )
    for rank, entry in enumerate(ranked, start=1):
        entry["rank"] = rank
    return ranked


def _assign_pareto_tiers(entries: list[dict[str, Any]]) -> None:
    remaining = set(range(len(entries)))
    tier = 1
    while remaining:
        front = [
            index
            for index in sorted(remaining)
            if not any(
                _dominates(entries[other], entries[index])
                for other in remaining
                if other != index
            )
        ]
        if not front:
            raise ValueError("proxy_formula_pareto_front_empty")
        for index in front:
            entries[index]["pareto_tier"] = tier
            remaining.remove(index)
        tier += 1


def _dominates(left: Mapping[str, Any], right: Mapping[str, Any]) -> bool:
    left_values = (
        float(left["trend_alignment_score"]),
        float(left["review_score"]),
    )
    right_values = (
        float(right["trend_alignment_score"]),
        float(right["review_score"]),
    )
    return all(a >= b for a, b in zip(left_values, right_values)) and any(
        a > b for a, b in zip(left_values, right_values)
    )


def _formula_selection_context(
    runtime: Any,
    entry: Mapping[str, Any],
) -> dict[str, Any]:
    formula = runtime.read_artifact(str(entry["formula_artifact_ref"]))
    review = runtime.read_artifact(str(entry["review_artifact_ref"]))
    formula_payload = formula.get("machine_payload")
    review_payload = validate_scientific_method_review(
        review,
        expected_method_ref=str(entry["formula_artifact_ref"]),
    )
    if not isinstance(formula_payload, Mapping):
        raise ValueError("pareto_formula_payload_required")
    return {
        "formula_artifact_ref": entry["formula_artifact_ref"],
        "formula_expression": formula_payload.get("formula_expression"),
        "input_variables": formula_payload.get("input_variables"),
        "expected_final_kpi_link": formula_payload.get("expected_final_kpi_link"),
        "expected_relation": formula_payload.get("expected_relation"),
        "trend_alignment_score": entry["trend_alignment_score"],
        "review_score": entry["review_score"],
        "review_reason": review_payload["reason"],
    }


def _render_leaderboard_markdown(
    runtime: Any,
    payload: Mapping[str, Any],
) -> str:
    first_materialization = runtime.read_artifact(
        str(payload["ranked_entries"][0]["materialization_artifact_ref"])
    )
    scope = materialization_dataset_scope(runtime, first_materialization)
    lines = [
        "# Proxy Formula Leaderboard",
        "",
        f"Dataset scope: `{scope}`." if scope else "Dataset scope: configured historical source.",
        "",
        "This version compares formulas on this exact scope and target only. "
        "Earlier versions retain their own evaluation scope.",
        "",
        (
            "Trend score is `25 * (direction-adjusted Spearman rho + "
            "direction-adjusted Kendall tau-b + 2)`, on a 0-100 scale. "
            "Public review is an independent scientific-method score. Pareto "
            "tiers maximize both axes; rank 1 is selected within tier 1."
        ),
        "",
        (
            "| Rank | Pareto tier | Formula | Expression | Inputs | "
            "Trend score | Review score |"
        ),
        "|---:|---:|---|---|---|---:|---:|",
    ]
    evidence_sections: list[str] = []
    for index, entry in enumerate(payload["ranked_entries"]):
        formula_ref = str(entry["formula_artifact_ref"])
        formula = dict(runtime.read_artifact(formula_ref))
        machine = formula.get("machine_payload")
        if not isinstance(machine, Mapping):
            raise ValueError(
                "proxy_formula_leaderboard_formula_payload_required:" + formula_ref
            )
        formula_label = (
            f"{machine.get('formula_id', 'proxy-formula')} "
            f"v{machine.get('version', '?')}"
        )
        expression = _markdown_cell(machine.get("formula_expression"))
        inputs = ", ".join(
            str(item.get("name") or "")
            for item in machine.get("input_variables") or []
            if isinstance(item, Mapping)
        )
        lines.append(
            "| "
            f"{entry['rank']} | {entry['pareto_tier']} | "
            f"{_markdown_cell(formula_label)} | `{expression}` | "
            f"{_markdown_cell(inputs)} | "
            f"{float(entry['trend_alignment_score']):.3f} | "
            f"{float(entry['review_score']):.3f} |"
        )
        materialization = (
            first_materialization if index == 0
            else runtime.read_artifact(str(entry["materialization_artifact_ref"]))
        )
        entry_scope = scope if index == 0 else materialization_dataset_scope(
            runtime, materialization, expected_formula_ref=formula_ref,
        )
        evidence_sections.extend(_render_scoring_evidence(
            runtime, entry, machine, materialization, entry_scope,
        ))
    lines.extend(evidence_sections)
    return "\n".join(lines) + "\n"


def _render_scoring_evidence(
    runtime: Any,
    entry: Mapping[str, Any],
    formula: Mapping[str, Any],
    materialization: Mapping[str, Any],
    scope: str | None,
) -> list[str]:
    observation = runtime.call_route("scientific_observation_inspect", {
        "observation_ref": entry["evaluation_observation_ref"],
        "selected_paths": ["result"],
    })
    aggregate = observation["observation"]["result"]
    _validate_private_evaluation_observation(
        observation, formula_ref=entry["formula_artifact_ref"],
        materialization_ref=entry["materialization_artifact_ref"], aggregate=aggregate,
    )
    implementation = materialization["machine_payload"]
    lines = [
        "", f"## Scoring evidence for rank {entry['rank']}", "",
        f"- Formula: `{entry['formula_artifact_ref']}`",
        f"- Declared target ID: `{formula.get('target_id', '')}`",
        f"- Declared proxy direction: `{formula.get('expected_relation', '')}`",
        "",
        "Public target definition and scientific link, as declared by the formula "
        "(not an independently verified scientific conclusion):",
        str(formula.get("expected_final_kpi_link") or "Not stated in this formula."),
        "",
        f"- Materialization: `{entry['materialization_artifact_ref']}`",
        f"- Implementation: `{implementation['implementation_ref']}`",
        "- Execution receipts: " + ", ".join(
            f"`{ref}`" for ref in implementation["execution_observation_refs"]
        ),
    ]
    if scope:
        prepared = runtime.read_artifact(scope)["machine_payload"]
        binding = validate_evaluation_binding(prepared["evaluation_binding"])
        lines.extend([
            f"- Execution-selected prepared data: `{scope}`",
            f"- Bound comparison target ID: `{binding['target_id']}`",
        ])
        # Free-text preparation notes can contain private measurements. Project
        # only exact output identities, not descriptions, reasons or data bodies.
        for key, label in (("record_output_name", "Calculation records"),
                           ("target_output_name", "Paired measured target")):
            output = next(item for item in prepared["prepared_outputs"] if item["name"] == binding[key])
            lines.append(f"- {label}: `{output['name']}`; exact body `{output['content_ref']}`")
    else:
        lines.append("- Comparison data: configured historical source used by the private evaluator.")
    lines.extend([
        f"- Scoring observation: `{entry['evaluation_observation_ref']}`",
        f"- Direction used by the evaluator: `{aggregate['expected_relation']}`",
    ])
    for key in ("sample_count", "spearman_rho", "kendall_tau_b",
                "direction_adjusted_spearman_rho", "direction_adjusted_kendall_tau_b"):
        if key in aggregate:
            lines.append(f"- `{key}`: {aggregate[key]}")
    lines.extend([
        "",
        "The trend score compares computed proxy values with the paired measured "
        "target on the stated dataset; it is not the proxy value itself, the public "
        "method-review score, or independent predictive validation. Raw target "
        "values are not reproduced here.",
    ])
    return lines


def _markdown_cell(value: Any) -> str:
    return str(value or "").replace("|", "\\|").replace("\n", " ").strip()
