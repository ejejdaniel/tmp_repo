from __future__ import annotations

from typing import Any

from ai_coscientist.common.artifacts import ArtifactStore
from ai_coscientist.common.code_artifacts import CodeArtifactStore
from ai_coscientist.common.development import DevelopmentProjectStore


def resolve_implementation(
    implementation_ref: str,
    *,
    artifacts: ArtifactStore,
    code_artifacts: CodeArtifactStore,
    development_projects: DevelopmentProjectStore | None,
) -> dict[str, Any]:
    """Resolve immutable implementation transport without interpreting science."""
    ref = str(implementation_ref).strip()
    if ref.startswith("code_artifact:"):
        stored = code_artifacts.read(ref)
        return {
            "implementation_ref": ref,
            "implementation_kind": "code_artifact",
            "dependency_refs": [
                str(value) for value in stored.get("depends_on") or ()
            ],
            "source_files": {
                "implementation.py": str(stored.get("code") or "").encode(
                    "utf-8"
                )
            },
        }
    if not ref.startswith("artifact:"):
        raise ValueError(f"implementation_ref_invalid:{ref}")
    stored = artifacts.read(ref)
    if stored.get("artifact_kind") != "development_project_snapshot":
        raise ValueError(f"implementation_artifact_kind_invalid:{ref}")
    payload = stored.get("machine_payload")
    if not isinstance(payload, dict):
        raise ValueError(f"implementation_payload_required:{ref}")
    if development_projects is None:
        raise ValueError("development_project_store_required")
    files = development_projects.snapshot_files(ref)
    return {
        "implementation_ref": ref,
        "implementation_kind": "development_project_snapshot",
        "dependency_refs": [
            str(value) for value in payload.get("dependency_refs") or ()
        ],
        "source_files": dict(files),
        "environment_ref": str(payload.get("environment_ref") or ""),
        "entry_command": [str(value) for value in payload.get("entry_command") or ()],
        "working_directory": str(payload.get("working_directory") or ""),
    }


def implementation_source_text(record: dict[str, Any]) -> str:
    """Return UTF-8 sources for bounded runner assertions; ignore binary files."""
    chunks: list[str] = []
    for path, body in sorted(dict(record.get("source_files") or {}).items()):
        try:
            source = bytes(body).decode("utf-8")
        except UnicodeDecodeError:
            continue
        chunks.append(f"\n# --- {path} ---\n{source}")
    return "".join(chunks)
