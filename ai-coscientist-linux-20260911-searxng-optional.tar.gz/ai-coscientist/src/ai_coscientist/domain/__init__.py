"""Project-local scientific workflow integrations."""
