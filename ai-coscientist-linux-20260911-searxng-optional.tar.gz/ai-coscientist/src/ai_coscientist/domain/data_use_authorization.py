from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from .prepared_sources import PreparedSourceData, resolve_prepared_source_data


class DataUseAuthorizationError(ValueError):
    """Raised when an explicit task data-use grant cannot be enforced."""


@dataclass(frozen=True)
class AuthorizedPreparedData:
    consumer_skill_id: str
    prepared_source: PreparedSourceData
    prepared_output_names: tuple[str, ...]
    allowed_use: str
    claim_limit: str

    @property
    def artifact_ref(self) -> str:
        return self.prepared_source.artifact_ref

    def prompt_projection(self) -> dict[str, Any]:
        return {
            "authority_class": "task_authorized_prepared_data",
            "consumer_skill_id": self.consumer_skill_id,
            "prepared_source_ref": self.prepared_source.artifact_ref,
            "prepared_output_names": list(self.prepared_output_names),
            "allowed_use": self.allowed_use,
            "claim_limit": self.claim_limit,
            "content": self.prepared_source.prompt_projection(),
        }


def resolve_task_authorized_prepared_data(
    runtime: Any,
    *,
    task: Mapping[str, Any],
    resolved_inputs: Sequence[Mapping[str, Any]],
    consumer_skill_id: str,
    require_grant: bool = True,
) -> AuthorizedPreparedData | None:
    """Resolve only prepared bodies explicitly granted to one consuming skill."""
    selection = _authorized_prepared_input_selection(
        task=task,
        resolved_inputs=resolved_inputs,
        consumer_skill_id=consumer_skill_id,
        require_grant=require_grant,
    )
    if selection is None:
        return None
    consumer, grant, selected_inputs = selection
    prepared_source = resolve_prepared_source_data(
        runtime,
        selected_inputs,
        consumer=consumer.replace("-", "_"),
        output_names=grant["prepared_output_names"],
    )
    if prepared_source is None:
        raise DataUseAuthorizationError("data_use_prepared_source_required")
    return AuthorizedPreparedData(
        consumer_skill_id=consumer,
        prepared_source=prepared_source,
        prepared_output_names=tuple(grant["prepared_output_names"]),
        allowed_use=str(grant["allowed_use"]),
        claim_limit=str(grant["claim_limit"]),
    )


def validate_task_prepared_data_authorization(
    *,
    task: Mapping[str, Any],
    resolved_inputs: Sequence[Mapping[str, Any]],
    consumer_skill_id: str,
) -> None:
    """Validate one Skill's prepared-data grant without reading data bodies."""
    _authorized_prepared_input_selection(
        task=task,
        resolved_inputs=resolved_inputs,
        consumer_skill_id=consumer_skill_id,
    )


def _authorized_prepared_input_selection(
    *,
    task: Mapping[str, Any],
    resolved_inputs: Sequence[Mapping[str, Any]],
    consumer_skill_id: str,
    require_grant: bool = True,
) -> tuple[str, dict[str, Any], list[dict[str, Any]]] | None:
    consumer = str(consumer_skill_id).strip()
    if not consumer:
        raise DataUseAuthorizationError("data_use_consumer_skill_id_required")

    prepared_inputs = [
        dict(item)
        for item in resolved_inputs
        if isinstance(item, Mapping)
        and item.get("artifact_kind") == "prepared_source_data"
    ]
    if not prepared_inputs:
        return None

    supplied_refs = {
        str(item.get("artifact_ref") or "").strip() for item in prepared_inputs
    }
    if any(not ref.startswith("artifact:") for ref in supplied_refs):
        raise DataUseAuthorizationError("data_use_prepared_source_ref_invalid")

    task_payload = task.get("machine_payload")
    if not isinstance(task_payload, Mapping):
        raise DataUseAuthorizationError("data_use_task_payload_required")
    grants = _validated_grants(task_payload.get("data_use_authorizations"))
    task_dependencies = {
        str(ref).strip()
        for ref in task.get("depends_on", [])
        if str(ref).strip()
    }
    matching = [
        grant
        for grant in grants
        if grant["consumer_skill_id"] == consumer
        and grant["prepared_source_ref"] in supplied_refs
    ]
    if not matching and not require_grant:
        return None
    authorized_refs = {grant["prepared_source_ref"] for grant in matching}
    unauthorized_refs = sorted(supplied_refs - authorized_refs)
    if unauthorized_refs:
        raise DataUseAuthorizationError(
            "data_use_prepared_source_not_authorized:"
            f"consumer={consumer};refs={unauthorized_refs}"
        )
    if len(matching) != 1:
        raise DataUseAuthorizationError(
            "data_use_authorization_ambiguous:"
            f"consumer={consumer};matches={len(matching)}"
        )

    grant = matching[0]
    source_ref = str(grant["prepared_source_ref"])
    if source_ref not in task_dependencies:
        raise DataUseAuthorizationError(
            "data_use_authorization_outside_task_lineage:"
            f"ref={source_ref}"
        )
    selected_inputs = [
        item
        for item in prepared_inputs
        if str(item.get("artifact_ref") or "").strip() == source_ref
    ]
    return consumer, dict(grant), selected_inputs


def _validated_grants(value: Any) -> list[dict[str, Any]]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise DataUseAuthorizationError("data_use_authorizations_must_be_array")
    grants: list[dict[str, Any]] = []
    for index, raw in enumerate(value):
        if not isinstance(raw, Mapping):
            raise DataUseAuthorizationError(
                f"data_use_authorization_must_be_object:index={index}"
            )
        expected = {
            "consumer_skill_id",
            "prepared_source_ref",
            "prepared_output_names",
            "allowed_use",
            "claim_limit",
        }
        if set(raw) != expected:
            raise DataUseAuthorizationError(
                "data_use_authorization_fields_invalid:"
                f"index={index};fields={sorted(raw)}"
            )
        consumer = str(raw.get("consumer_skill_id") or "").strip()
        source_ref = str(raw.get("prepared_source_ref") or "").strip()
        names = raw.get("prepared_output_names")
        allowed_use = str(raw.get("allowed_use") or "").strip()
        claim_limit = str(raw.get("claim_limit") or "").strip()
        if not consumer:
            raise DataUseAuthorizationError(
                f"data_use_authorization_consumer_required:index={index}"
            )
        if not source_ref.startswith("artifact:"):
            raise DataUseAuthorizationError(
                f"data_use_authorization_source_ref_invalid:index={index}"
            )
        if not isinstance(names, list):
            raise DataUseAuthorizationError(
                f"data_use_authorization_output_names_invalid:index={index}"
            )
        normalized_names = [str(item).strip() for item in names]
        if (
            not normalized_names
            or any(not item for item in normalized_names)
            or len(normalized_names) != len(set(normalized_names))
        ):
            raise DataUseAuthorizationError(
                f"data_use_authorization_output_names_invalid:index={index}"
            )
        if not allowed_use or not claim_limit:
            raise DataUseAuthorizationError(
                f"data_use_authorization_scope_required:index={index}"
            )
        grants.append(
            {
                "consumer_skill_id": consumer,
                "prepared_source_ref": source_ref,
                "prepared_output_names": normalized_names,
                "allowed_use": allowed_use,
                "claim_limit": claim_limit,
            }
        )
    identities = [
        (grant["consumer_skill_id"], grant["prepared_source_ref"])
        for grant in grants
    ]
    if len(identities) != len(set(identities)):
        raise DataUseAuthorizationError("data_use_authorization_duplicate_grant")
    return grants
