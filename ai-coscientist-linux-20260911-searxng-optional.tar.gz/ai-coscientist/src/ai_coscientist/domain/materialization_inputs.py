from __future__ import annotations

import json
from typing import Any, Mapping, Sequence


def record_path_present(record: Mapping[str, Any], path: str) -> bool:
    parts = path.split(".")
    if not parts or parts[0] != "record":
        return False
    current: Any = record
    for part in parts[1:]:
        if not isinstance(current, Mapping) or part not in current:
            return False
        current = current[part]
    return current is not None


def validate_execution_input_paths(
    value: Any, *, records: Sequence[Mapping[str, Any]] | None = None,
) -> list[str]:
    if not isinstance(value, list) or not value:
        raise ValueError(
            "materialization_execution_input_paths_required:"
            "declare_this_implementation_inputs_and_publish_a_new_execution;"
            "do_not_infer_paths_from_formula_research_sources"
        )
    for path in value:
        if (not isinstance(path, str) or not path.strip()
                or path != path.strip() or path.split(".")[0] != "record"
                or any(not part for part in path.split("."))):
            raise ValueError(f"materialization_execution_input_path_invalid:{path!r}")
    if records is not None:
        missing = [
            {"sample_id": str(record.get("id", "")), "missing_paths": paths}
            for record in records
            if (paths := [path for path in value if not record_path_present(record, path)])
        ]
        if missing:
            raise ValueError(
                "materialization_execution_input_path_mismatch:"
                f"affected_records={len(missing)}:"
                + json.dumps(missing[:5], ensure_ascii=False)
            )
    return list(value)


def materialization_input_paths(
    artifact: Mapping[str, Any], *, records: Sequence[Mapping[str, Any]] | None = None,
) -> list[str]:
    payload = artifact.get("machine_payload") or {}
    try:
        return validate_execution_input_paths(payload.get("execution_input_paths"), records=records)
    except ValueError as exc:
        raise ValueError(
            f"{exc}:materialization_ref={artifact.get('artifact_ref')}:"
            f"implementation_ref={payload.get('implementation_ref')}"
        ) from exc
