"""Exact dataset binding shared by preparation, execution and evaluation."""

from __future__ import annotations

import math
from typing import Any, Callable, Mapping, Sequence


def final_kpi_target_metric(
    formal_context: Sequence[Mapping[str, Any]],
    *,
    visible_historical: Mapping[str, Any],
) -> dict[str, Any]:
    """Use the same existing target identity for preparation and discovery."""
    explicit_target_id = str(visible_historical.get("kpi") or "").strip()
    if explicit_target_id:
        return {
            "target_kind": "final_kpi",
            "target_id": explicit_target_id,
            "name": visible_historical.get("kpi"),
            "scientific_meaning": visible_historical.get("kpi_description"),
        }
    task_matches = [
        item for item in formal_context if item.get("artifact_kind") == "task_spec"
    ]
    if len(task_matches) != 1:
        raise ValueError(
            "final_kpi_proxy_target_task_authority_required:"
            f"actual={len(task_matches)}"
        )
    task_payload = task_matches[0].get("machine_payload")
    if not isinstance(task_payload, Mapping):
        raise ValueError("final_kpi_proxy_target_task_payload_required")
    task_id = str(task_payload.get("id") or "").strip()
    scientific_meaning = str(task_payload.get("evaluation_priority") or "").strip()
    if not task_id or not scientific_meaning:
        raise ValueError("final_kpi_proxy_target_authority_incomplete")
    return {
        "target_kind": "final_kpi",
        "target_id": f"{task_id}:primary_measured_objective",
        "name": "Primary measured objective declared by the task specification",
        "scientific_meaning": scientific_meaning,
    }


def evaluation_binding_schema() -> dict[str, Any]:
    descriptions = {
        "record_output_name": "Name of the calculation input records body in prepared_outputs.",
        "target_output_name": "Different output name for the paired target records[{id,value}] body.",
        "target_id": "Exact target_id from the task and formula.",
        "selection_reason": "Evidence-based inclusion, exclusion and source-row selection rationale.",
    }
    return {
        "type": "object",
        "properties": {
            name: {"type": "string", "minLength": 1, "description": description}
            for name, description in descriptions.items()
        },
        "required": list(descriptions),
        "additionalProperties": False,
    }


def validate_evaluation_binding(value: Any) -> dict[str, str]:
    expected = set(evaluation_binding_schema()["required"])
    if not isinstance(value, Mapping) or set(value) != expected:
        raise ValueError("prepared_evaluation_binding_fields_invalid")
    if any(not isinstance(value[name], str) or not value[name].strip() for name in expected):
        raise ValueError("prepared_evaluation_binding_nonempty_strings_required")
    if value["record_output_name"] == value["target_output_name"]:
        raise ValueError("prepared_evaluation_binding_outputs_must_differ")
    return dict(value)


def formula_prepared_source(runtime: Any, formula: Mapping[str, Any]) -> dict[str, Any] | None:
    sources = {}
    for ref in formula.get("depends_on") or ():
        if not str(ref).startswith("artifact:"):
            continue
        artifact = runtime.read_artifact(str(ref))
        if artifact.get("artifact_kind") == "prepared_source_data":
            if artifact.get("artifact_ref") != ref:
                raise ValueError("formula_prepared_source_ref_mismatch")
            sources[str(ref)] = artifact
    if len(sources) > 1:
        raise ValueError(f"formula_prepared_source_ambiguous:refs={sorted(sources)}")
    return next(iter(sources.values()), None)


def validate_record_table(body: Any) -> tuple[dict[str, Any], ...]:
    rows = body.get("records") if isinstance(body, Mapping) else None
    if not isinstance(rows, list) or not rows:
        raise ValueError("prepared_records_required")
    records = []
    seen = set()
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            raise ValueError(f"prepared_record_invalid:index={index}")
        record_id = row.get("id")
        if not isinstance(record_id, str) or not record_id.strip() or record_id in seen:
            raise ValueError(f"prepared_record_id_invalid:index={index}")
        seen.add(record_id)
        records.append(dict(row))
    return tuple(records)


def records_from_prepared(prepared: Any, *, binding: Mapping[str, str] | None = None) -> tuple[dict[str, Any], ...]:
    binding = binding or prepared.evaluation_binding
    tables = [
        output.content for output in prepared.outputs
        if (output.name == binding["record_output_name"] if binding else
            isinstance(output.content, Mapping) and isinstance(output.content.get("records"), list))
    ]
    if len(tables) != 1:
        raise ValueError(f"prepared_record_table_required:ref={prepared.artifact_ref}:actual={len(tables)}")
    return validate_record_table(tables[0])


def prepared_historical_data(prepared: Any) -> dict[str, Any]:
    """Project the selected table while retaining its existing source metadata."""
    binding = prepared.evaluation_binding
    records = records_from_prepared(prepared, binding=binding)
    table = next(output.content for output in prepared.outputs
                 if (output.name == binding["record_output_name"] if binding else
                     isinstance(output.content, Mapping) and isinstance(output.content.get("records"), list)))
    result = dict(table, records=list(records))
    if binding:
        if result.get("kpi") and result["kpi"] != binding["target_id"]:
            raise ValueError("prepared_record_target_id_mismatch")
        result["kpi"] = binding["target_id"]
    return result


def prepared_background(prepared: Any) -> dict[str, Any]:
    """Keep readable context, including targets, separate from calculation rows."""
    projection = prepared.prompt_projection()
    binding = prepared.evaluation_binding
    projection["prepared_outputs"] = [
        output for output in projection["prepared_outputs"]
        if (output["name"] != binding["record_output_name"] if binding else
            not (isinstance(output["content"], Mapping) and isinstance(output["content"].get("records"), list)))
    ]
    return projection


def validate_paired_targets(records: Sequence[Mapping[str, Any]], body: Any) -> dict[str, float]:
    if not isinstance(body, Mapping) or set(body) != {"records"}:
        raise ValueError("prepared_target_body_shape_invalid")
    rows = validate_record_table(body)
    values = {}
    for row in rows:
        value = row.get("value")
        if (set(row) != {"id", "value"} or isinstance(value, bool)
                or not isinstance(value, (int, float)) or not math.isfinite(value)):
            raise ValueError("prepared_target_finite_value_required")
        values[row["id"]] = float(value)
    if set(values) != {row["id"] for row in records}:
        raise ValueError("prepared_evaluation_sample_ids_mismatch")
    return values


def prepared_source_ref_schema() -> dict[str, Any]:
    return {
        "type": "string", "minLength": 1,
        "description": (
            "Exact prepared_source_data selected for THIS Formula execution, not "
            "necessarily its research source. Required without legacy SourceSpec. "
            "For later scoring select paired calculation inputs and targets via "
            "evaluation_binding. This execution interface supplies calculation rows; "
            "other prepared bodies remain readable for research and inspection. It "
            "records this ref in execution metadata; later consumers cannot rebind it."
        ),
    }


def validate_prepared_source_ref(value: Any) -> str:
    if not isinstance(value, str) or not value.startswith("artifact:") or value != value.strip():
        raise ValueError("materializer_exact_prepared_source_ref_required")
    return value


def execution_prepared_source_ref(
    materialization: Mapping[str, Any],
    read_observation: Callable[[str], Mapping[str, Any]],
    *, expected_formula_ref: str | None = None,
) -> str | None:
    """Recover the execution's immutable choice, never a sibling input or latest ref."""
    payload = materialization["machine_payload"]
    refs = payload.get("execution_observation_refs")
    if not isinstance(refs, list) or not refs:
        raise ValueError("materialization_execution_observation_refs_required")
    scopes: set[str | None] = set()
    for ref in refs:
        observation = read_observation(str(ref))
        result, metadata = observation.get("result"), observation.get("metadata")
        if not isinstance(metadata, Mapping) or result != payload:
            raise ValueError(f"materialization_execution_authority_mismatch:ref={ref}")
        if (metadata.get("implementation_ref") != payload.get("implementation_ref")
                or metadata.get("formula_artifact_ref") not in materialization.get("depends_on", ())
                or (expected_formula_ref is not None
                    and metadata.get("formula_artifact_ref") != expected_formula_ref)):
            raise ValueError(f"materialization_execution_dependency_mismatch:ref={ref}")
        scopes.add(validate_prepared_source_ref(metadata["prepared_source_ref"])
                   if "prepared_source_ref" in metadata else None)
    if len(scopes) != 1:
        raise ValueError("materialization_execution_dataset_ambiguous")
    return scopes.pop()


def materialization_dataset_scope(
    runtime: Any, materialization: Mapping[str, Any], *, expected_formula_ref: str | None = None,
) -> str | None:
    def read(ref: str) -> Mapping[str, Any]:
        # Bookkeeping reads immutable evidence; it must not rerun the implementation.
        runtime.call_route("read_ref", {"ref": ref})
        return runtime.read_ref(ref)

    return execution_prepared_source_ref(materialization, read, expected_formula_ref=expected_formula_ref)


def _execution_source(runtime: Any, formula: Mapping[str, Any], materialization: Mapping[str, Any]) -> str | None:
    ref = materialization_dataset_scope(runtime, materialization, expected_formula_ref=formula.get("artifact_ref"))
    if ref is None and formula_prepared_source(runtime, formula) is not None:
        raise ValueError(
            "legacy_prepared_materialization_requires_explicit_execution:"
            f"materialization_ref={materialization.get('artifact_ref')}:"
            "execute_same_formula_with_prepared_source_ref_do_not_reauthor_formula"
        )
    return ref


def _prepared_artifact(runtime: Any, source_ref: str) -> dict[str, Any]:
    validate_prepared_source_ref(source_ref)
    artifact = runtime.read_artifact(source_ref)
    if artifact.get("artifact_kind") != "prepared_source_data" or artifact.get("artifact_ref") != source_ref:
        raise ValueError(f"execution_prepared_source_mismatch:ref={source_ref}")
    return artifact


def resolve_materialization_evaluation(
    runtime: Any, formula: Mapping[str, Any], materialization: Mapping[str, Any],
) -> dict[str, float] | None:
    # A bound but unusable source must never fall back to the startup dataset.
    from .prepared_sources import resolve_prepared_source_data

    source_ref = _execution_source(runtime, formula, materialization)
    if source_ref is None:
        return None
    artifact = _prepared_artifact(runtime, source_ref)
    if artifact.get("self_review", {}).get("preparation_status", "complete") != "complete":
        raise ValueError("prepared_evaluation_source_incomplete")
    payload = artifact["machine_payload"]
    if not isinstance(payload.get("evaluation_binding"), Mapping):
        raise ValueError(
            "execution_evaluation_source_not_scoring_ready:"
            f"prepared_source_ref={artifact.get('artifact_ref')}:"
            "requires_distinct_calculation_records_paired_targets_and_"
            "evaluation_binding:prepare_scoring_data_then_execute_same_formula_"
            "with_explicit_prepared_source_ref"
        )
    binding = validate_evaluation_binding(payload["evaluation_binding"])
    if formula["machine_payload"].get("target_id") != binding["target_id"]:
        raise ValueError(
            "prepared_evaluation_target_id_mismatch:"
            f"formula_ref={formula.get('artifact_ref')}:prepared_source_ref={source_ref}:"
            f"expected={formula['machine_payload'].get('target_id')}:actual={binding['target_id']}"
        )
    prepared = resolve_prepared_source_data(
        runtime, [artifact], consumer="private_evaluator",
        output_names=[binding["record_output_name"], binding["target_output_name"]],
    )
    records = records_from_prepared(prepared, binding=binding)
    target = next(output.content for output in prepared.outputs if output.name == binding["target_output_name"])
    return validate_paired_targets(records, target)


def resolve_prepared_records(runtime: Any, source_ref: str, *, consumer: str) -> tuple[Any, tuple[dict[str, Any], ...]]:
    from .prepared_sources import resolve_prepared_source_data

    artifact = _prepared_artifact(runtime, source_ref)
    payload = artifact["machine_payload"]
    binding = (validate_evaluation_binding(payload["evaluation_binding"])
               if "evaluation_binding" in payload else None)
    prepared = resolve_prepared_source_data(
        runtime, [artifact], consumer=consumer,
        output_names=[binding["record_output_name"]] if binding else None,
    )
    return prepared, records_from_prepared(prepared, binding=binding)


def resolve_materialization_records(
    runtime: Any, formula: Mapping[str, Any], materialization: Mapping[str, Any], *, consumer: str,
) -> tuple[Any, tuple[dict[str, Any], ...]] | None:
    source_ref = _execution_source(runtime, formula, materialization)
    if source_ref is None:
        return None
    return resolve_prepared_records(runtime, source_ref, consumer=consumer)
