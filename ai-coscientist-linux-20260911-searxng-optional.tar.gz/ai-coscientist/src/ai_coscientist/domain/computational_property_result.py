from __future__ import annotations

import json
import math
from typing import Any, Mapping, Sequence


_TOP_LEVEL_KEYS = frozenset(
    {
        "artifact_kind",
        "protocol_artifact_ref",
        "output_id",
        "value",
        "unit",
        "implementation_ref",
        "execution_observation_refs",
    }
)


class ComputationalPropertyResultError(ValueError):
    pass


def validate_computational_property_result(payload: Any) -> None:
    """Validate one execution-derived property result without judging science."""
    if not isinstance(payload, Mapping):
        raise ComputationalPropertyResultError(
            "computational_property_result_must_be_object"
        )
    actual_keys = set(payload)
    if actual_keys != _TOP_LEVEL_KEYS:
        raise ComputationalPropertyResultError(
            "computational_property_result_keys_invalid:"
            f"missing={sorted(_TOP_LEVEL_KEYS - actual_keys)}:"
            f"extra={sorted(actual_keys - _TOP_LEVEL_KEYS)}"
        )
    if payload.get("artifact_kind") != "computational_property_result":
        raise ComputationalPropertyResultError(
            "computational_property_result_kind_invalid"
        )
    _required_ref(
        payload.get("protocol_artifact_ref"),
        "protocol_artifact_ref",
        prefix="artifact:",
    )
    _required_text(payload.get("output_id"), "output_id")
    _required_json_value(payload.get("value"))
    _required_text(payload.get("unit"), "unit")
    _implementation_ref(payload.get("implementation_ref"))
    _single_ref_array(
        payload.get("execution_observation_refs"),
        "execution_observation_refs",
        prefix="execution_observation:",
    )


def _required_text(value: Any, label: str) -> str:
    text = str(value or "").strip()
    if not text:
        raise ComputationalPropertyResultError(
            f"computational_property_result_{label}_required"
        )
    return text


def _required_ref(value: Any, label: str, *, prefix: str) -> str:
    ref = _required_text(value, label)
    if not ref.startswith(prefix):
        raise ComputationalPropertyResultError(
            f"computational_property_result_{label}_invalid:{ref}"
        )
    return ref


def _implementation_ref(value: Any) -> str:
    ref = _required_text(value, "implementation_ref")
    if not ref.startswith(("code_artifact:", "artifact:")):
        raise ComputationalPropertyResultError(
            "computational_property_result_implementation_ref_invalid:"
            f"{ref}"
        )
    return ref


def _single_ref_array(
    value: Any,
    label: str,
    *,
    prefix: str,
) -> tuple[str, ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise ComputationalPropertyResultError(
            f"computational_property_result_{label}_must_be_array"
        )
    refs = tuple(str(item).strip() for item in value)
    if len(refs) != 1 or len(refs) != len(set(refs)):
        raise ComputationalPropertyResultError(
            f"computational_property_result_{label}_must_contain_one_unique_ref"
        )
    for ref in refs:
        if not ref.startswith(prefix):
            raise ComputationalPropertyResultError(
                f"computational_property_result_{label}_invalid:{ref}"
            )
    return refs


def _required_json_value(value: Any) -> None:
    if value is None:
        raise ComputationalPropertyResultError(
            "computational_property_result_value_required"
        )

    def reject_nonfinite(item: Any) -> None:
        if isinstance(item, float) and not math.isfinite(item):
            raise ComputationalPropertyResultError(
                "computational_property_result_value_nonfinite"
            )
        if isinstance(item, Mapping):
            for child in item.values():
                reject_nonfinite(child)
        elif isinstance(item, Sequence) and not isinstance(item, (str, bytes)):
            for child in item:
                reject_nonfinite(child)

    reject_nonfinite(value)
    try:
        json.dumps(value, ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise ComputationalPropertyResultError(
            "computational_property_result_value_not_json"
        ) from exc
