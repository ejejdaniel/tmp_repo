from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence


_TASK_SOURCES = ("autonomous", "commissioned")
_RESEARCH_STRATEGIES = ("deepen", "explore")

_MODE_SELECTION_PROMPT = """\
Classify the caller's research instruction; do not choose a scientifically
preferable mode and do not rewrite the task.

The two axes are independent:
- task_source=autonomous: the researcher chooses a useful question within the
  active node's requested outcome.
- task_source=commissioned: the caller assigns a specific question, claim, gap,
  comparison, or existing artifact to address.
- research_strategy=deepen: relevant shared research assets may guide the first
  scientific draft.
- research_strategy=explore: the first scientific draft must be independent of
  non-commissioned shared research assets; the skill will reintroduce them in a
  later reconciliation stage before publication.

Copy explicit mode labels in the step purpose exactly. When the task-source axis
is not labeled, use commissioned only when the purpose delegates a specific
target; otherwise use autonomous. When the strategy axis is not labeled, use
deepen. Exploration never hides the formal task, raw or prepared source data,
required structural inputs, or the exact object of a commission.

The active_work_unit is the authoritative Graph-node contract. The step purpose
is only a short operational summary and may be compacted. Use the work unit's
outcome, completion condition, and exact dependencies to distinguish artifacts
that define the assigned subject or gap from artifacts used only as background,
source authority, prior evidence, or a comparison baseline. The purpose cannot
turn the skill's future output into an existing commissioned input.

Select commissioned_input_refs only from the supplied exact artifact index and
only for artifacts that directly define the commissioned target. Do not include
general background, optional inspiration, transport dependencies, or all inputs
by default. Formal task authority, source data, and required structural inputs
may remain visible to the skill, but they are not commissioned targets unless
the purpose explicitly assigns that exact artifact for inspection. In
particular, do not include a task_spec merely because every invocation requires
it. An artifact-free commission may use an empty list.
"""


@dataclass(frozen=True)
class ResearchMode:
    task_source: str
    research_strategy: str
    commissioned_input_refs: tuple[str, ...]
    explicit_selection: bool = True

    def prompt_projection(self) -> dict[str, Any]:
        return {
            "task_source": self.task_source,
            "research_strategy": self.research_strategy,
            "commissioned_input_refs": list(self.commissioned_input_refs),
        }


def resolve_research_mode(
    payload: Mapping[str, Any],
    runtime: Any,
    resolved_inputs: Sequence[Mapping[str, Any]],
    *,
    skill_id: str,
) -> ResearchMode:
    """Copy the caller-owned mode card, with an old-checkpoint fallback."""
    raw_step = payload.get("active_loop_step")
    if raw_step is None:
        return ResearchMode(
            task_source="autonomous",
            research_strategy="deepen",
            commissioned_input_refs=(),
            explicit_selection=False,
        )
    if not isinstance(raw_step, Mapping):
        raise ValueError("research_mode_active_loop_step_invalid")
    if str(raw_step.get("skill_id") or "") != skill_id:
        raise ValueError(
            "research_mode_skill_mismatch:"
            f"expected={skill_id}:actual={raw_step.get('skill_id')}"
        )

    artifact_index = _artifact_index(resolved_inputs)
    exact_refs = [item["artifact_ref"] for item in artifact_index]
    raw_card = raw_step.get("research_mode")
    if raw_card is not None:
        return _research_mode_from_card(
            raw_card,
            exact_refs=frozenset(exact_refs),
            step_input_refs=frozenset(
                str(ref) for ref in raw_step.get("input_refs") or ()
            ),
        )

    # Compatibility path for checkpoints created before the structured C1 card.
    ref_schema: dict[str, Any] = {"type": "string"}
    if exact_refs:
        ref_schema["enum"] = exact_refs
    mode = runtime.generate_json(
        _MODE_SELECTION_PROMPT,
        _mode_context(
            raw_step,
            artifact_index,
            active_work_unit=payload.get("active_work_unit"),
        ),
        purpose="resolve-research-mode",
        schema={
            "type": "object",
            "properties": {
                "task_source": {
                    "type": "string",
                    "enum": list(_TASK_SOURCES),
                },
                "research_strategy": {
                    "type": "string",
                    "enum": list(_RESEARCH_STRATEGIES),
                },
                "commissioned_input_refs": {
                    "type": "array",
                    "items": ref_schema,
                    "maxItems": len(exact_refs),
                    "uniqueItems": True,
                },
            },
            "required": [
                "task_source",
                "research_strategy",
                "commissioned_input_refs",
            ],
            "additionalProperties": False,
        },
    )
    commissioned_refs = tuple(
        str(ref) for ref in mode.get("commissioned_input_refs") or ()
    )
    unknown_refs = sorted(set(commissioned_refs) - set(exact_refs))
    if unknown_refs:
        raise ValueError(
            f"research_mode_commissioned_refs_unknown:{unknown_refs}"
        )
    return ResearchMode(
        task_source=str(mode["task_source"]),
        research_strategy=str(mode["research_strategy"]),
        commissioned_input_refs=commissioned_refs,
    )


def _research_mode_from_card(
    raw: Any,
    *,
    exact_refs: frozenset[str],
    step_input_refs: frozenset[str],
) -> ResearchMode:
    if not isinstance(raw, Mapping) or set(raw) != {
        "task_source",
        "research_strategy",
        "commissioned_input_refs",
    }:
        raise ValueError("research_mode_card_invalid")
    task_source = str(raw.get("task_source") or "")
    strategy = str(raw.get("research_strategy") or "")
    raw_commissioned = raw.get("commissioned_input_refs")
    if task_source not in _TASK_SOURCES:
        raise ValueError("research_mode_task_source_invalid")
    if strategy not in _RESEARCH_STRATEGIES:
        raise ValueError("research_mode_strategy_invalid")
    if (
        not isinstance(raw_commissioned, Sequence)
        or isinstance(raw_commissioned, (str, bytes))
    ):
        raise ValueError("research_mode_commissioned_refs_invalid")
    commissioned_refs = tuple(str(ref).strip() for ref in raw_commissioned)
    if (
        any(not ref for ref in commissioned_refs)
        or len(commissioned_refs) != len(set(commissioned_refs))
        or not set(commissioned_refs).issubset(step_input_refs)
        or not set(commissioned_refs).issubset(exact_refs)
        or (task_source == "autonomous" and commissioned_refs)
    ):
        raise ValueError("research_mode_commissioned_refs_invalid")
    return ResearchMode(
        task_source=task_source,
        research_strategy=strategy,
        commissioned_input_refs=commissioned_refs,
    )


def initial_research_inputs(
    mode: ResearchMode,
    resolved_inputs: Sequence[Mapping[str, Any]],
    *,
    shared_artifact_kinds: Sequence[str],
    always_visible_artifact_kinds: Sequence[str] = (),
) -> list[dict[str, Any]]:
    """Project exact inputs for the first draft without changing storage."""
    copied = [dict(item) for item in resolved_inputs]
    if mode.research_strategy != "explore":
        return copied
    shared_kinds = {str(kind) for kind in shared_artifact_kinds}
    always_visible = {str(kind) for kind in always_visible_artifact_kinds}
    commissioned_refs = set(mode.commissioned_input_refs)
    return [
        item
        for item in copied
        if str(item.get("artifact_kind") or "") not in shared_kinds
        or str(item.get("artifact_kind") or "") in always_visible
        or str(item.get("artifact_ref") or "") in commissioned_refs
    ]


def reconciliation_projection(mode: ResearchMode) -> dict[str, Any]:
    """Describe the skill-owned transition without adding persisted state."""
    projection = mode.prompt_projection()
    projection["stage_policy"] = (
        "The independent first draft is complete. Reconcile it with the now-"
        "visible shared research assets, preserving useful novelty while "
        "correcting conflicts, duplication, and unsupported claims."
        if mode.research_strategy == "explore"
        else "Shared research assets may guide and deepen the draft from the start."
    )
    return projection


def _artifact_index(
    resolved_inputs: Sequence[Mapping[str, Any]],
) -> list[dict[str, str]]:
    result: list[dict[str, str]] = []
    seen: set[str] = set()
    for item in resolved_inputs:
        ref = str(item.get("artifact_ref") or "").strip()
        if not ref or ref in seen:
            continue
        seen.add(ref)
        result.append(
            {
                "artifact_ref": ref,
                "artifact_kind": str(item.get("artifact_kind") or ""),
                "title": str(item.get("title") or "")[:500],
                "summary": str(item.get("summary") or "")[:1_500],
            }
        )
    return result


def _mode_context(
    active_loop_step: Mapping[str, Any],
    artifact_index: Sequence[Mapping[str, str]],
    *,
    active_work_unit: Any = None,
) -> str:
    import json

    return json.dumps(
        {
            "active_work_unit": _work_unit_projection(active_work_unit),
            "active_loop_step": {
                "skill_id": str(active_loop_step.get("skill_id") or ""),
                "purpose": str(active_loop_step.get("purpose") or ""),
                "cost": active_loop_step.get("cost"),
                "input_refs": [
                    str(ref) for ref in active_loop_step.get("input_refs") or ()
                ],
            },
            "exact_resolved_artifact_index": [dict(item) for item in artifact_index],
        },
        ensure_ascii=False,
        indent=2,
    )


def _work_unit_projection(raw: Any) -> dict[str, Any] | None:
    if not isinstance(raw, Mapping):
        return None
    return {
        "node_id": str(raw.get("node_id") or ""),
        "outcome": str(raw.get("outcome") or ""),
        "completion_condition": str(raw.get("completion_condition") or ""),
        "depends_on": [str(ref) for ref in raw.get("depends_on") or ()],
    }
