from __future__ import annotations

import json
from typing import Any, Callable, Mapping, Sequence

from ai_coscientist.common.json_schema import json_schema_issues
from ai_coscientist.domain.source_inspection import SOURCE_CONTEXT_GUIDE


ContentValidator = Callable[[Mapping[str, Any]], Sequence[str] | None]


SCIENTIFIC_CLAIM_CALIBRATION_GUIDE = """\
Calibrate every scientific statement to its actual authority:
- Call a pattern observed only when it is directly present in the supplied
  records, explicitly authorized_task_data, or public research artifacts. Confounded record differences do not
  isolate one variable's effect.
- Task-scoped prepared measurements, including paired scoring targets, are
  readable research evidence. A scoring role is not a privacy restriction.
  When authorized_task_data is present, use its granted named bodies within
  allowed_use and claim_limit. Reading does not authorize answer substitution.
  Explain any supported fitting in existing prose; a chosen coefficient without
  a fitting calculation is a proposal, not a fitted result. Agreement on the
  supplied dataset is not independent validation. An absent grant section does
  not prohibit ordinary prepared data; explicit source restrictions still apply.
- Scope availability claims to the source and consumer actually inspected.
  Withheld from this input is not absent from the research, and no published
  execution yet is not proof that evaluation is impossible. An upstream gap
  is a fallible assessment at that stage; check supplied direct source and
  execution evidence before adopting it. Evidence already present can correct
  an earlier oversight; no new artifact or experiment is required merely to
  acknowledge that correction. Neither
  infer hidden values nor claim hidden data exists without source evidence.
- Describe a mechanism-derived direction as expected, hypothesized, or
  proposed for testing unless supplied evidence directly establishes it.
- Treat an author-chosen coefficient, cutoff, normalization, or comparison
  point as a prospective design choice, not a measured constant or derived
  physical threshold. State that status in the existing explanatory fields.
- Do not use an unsupported numeric reference to create an optimum, target
  match, or monotonic law. When direction is uncertain, propose a falsifiable
  regime-bounded relation or discriminating comparison instead of claiming the
  uncertainty has already been resolved.
These distinctions use the existing prose fields and do not create new output
fields.
"""


_MINDMAP_SKELETON_PROMPT = """\
Develop the supplied scientific research context into a stable mechanism-research
landscape. This is the upper-system pass. A family is a reusable method family,
not a single candidate hypothesis, formula, material, component, or variable.

Honor research_mode as a caller-owned context policy. In explore mode, shared
research assets absent from this pass are deliberately withheld so this
skeleton can provide an independent P0; do not reconstruct or assume them.

Use the mechanically separated evidence_authority sections in this order:

1. formal_task_contract defines the objective, constraints, explicitly stated
   meanings, and visibility boundary. It does not prove a scientific mechanism.
2. sanitized_record_evidence is direct evidence only for included visible
   fields and records. Check model summaries against it before using them.
3. model_source_extraction is a fallible navigation aid, not an independent
   source. model_scientific_interpretation contains idea seeds only.
4. unknown_or_withheld records limitations of the inspected input, not a global
   inventory of missing data or unavailable capabilities. Preserve its source,
   stage and consumer scope; recheck even against evidence already supplied,
   rather than requiring a new experiment to correct an oversight. Correct an extraction that turns intentional
   withholding into dataset absence or impossibility of downstream evaluation.
   Never promote a lower-authority section into a higher-authority claim.
5. Prior mind-map architecture summaries are continuity evidence to retain
   where still useful or reorganize where their abstraction is too narrow,
   redundant, or incomplete. Their omitted long-form detail is available only
   to the later deepening pass and must not dominate this architecture decision.
6. Occupied research directions summarize hypotheses, formulas, reviews, and
   rankings that already exist. They mark explored space and tensions only; they
   must not define the family taxonomy or pull the whole landscape toward the
   current best candidate.

A direct record comparison may be reported as a comparison. When records vary
multiple controls, it does not establish an isolated effect, monotonic or
nonmonotonic response, optimum, threshold, or causal direction. A visible failed
criterion can show that the combined success condition is not met, but it cannot
establish the status of a withheld criterion or that every criterion failed.
Named-component role assignments must remain unresolved unless an exact source
states the mapping; structure-based assignments are hypotheses to test.

Top-level families must be independently actionable intervention classes or
reusable system strategies at a comparable level of abstraction. Observed
columns, varying record fields, named components, current candidate variables,
intermediate physical quantities, process stages, constraints, and failure
modes are evidence or mechanisms within a family, not automatically peer
families. When several properties are consequences of the same controllable
subsystem or intervention class, group them in one family. Promote a causal
stage to a family only when the task exposes an independent way to intervene on
that stage and it can support multiple future hypotheses or quantitative
methods. A scientifically plausible intervention class named by the task may
remain a family even when the current records do not vary it; mark the missing
evidence as a bottleneck instead of collapsing the research landscape to the
observed columns. Together the families should span the main controllable route
to the target observable and state their meaningful interactions.

When family_identity_policy.required_family_ids is nonempty, preserve every
listed family_id exactly once and do not add, remove, merge, split, or rename
those ids. Otherwise create only the nonredundant families supported by the
context, normally three to five, and assign concise stable ids. Reuse a prior id
only when it still names the same system-level family; do not preserve a weak
taxonomy merely for textual continuity.

Organize the existing fields with these roles:

- landscape_summary: research goal and observables; controllable variables;
  major system-level mechanism relationships; directions already occupied by
  supplied hypotheses or formulas; unexplored research space; evidence gaps;
- title: the method-family name, not one candidate name;
- causal_role: which part of the scientific system the family controls;
- core_mechanism: a concise qualitative chain from controllable variable,
  through an intermediate physical quantity, to the target observable;
- mechanism_chain: a compact structural projection of core_mechanism with
  nonempty inputs_or_controls, intermediate_processes, and target_observables.
  It must not add a claim absent from core_mechanism. An observational family
  may name a comparison state or external condition instead of an intervention;
- interaction_motif: coupling, competition, or complementarity with other
  families;
- scope_mode, key_prerequisites, main_bottleneck, expected_failure_mode, and
  viability_band: the operating scope, requirements, gap, failure, and current
  research maturity;
- tension_ids and tension_strategy: cross-family tradeoffs and how to study them.

Write supported_relationships as explicit drawable edges. Each item must use
exactly one of these forms, with ids copied from the families in this result:

- source_family_id -> target_family_id: Traditional Chinese explanation
- source_family_id <-> target_family_id: Traditional Chinese explanation

Use -> only for a directional influence or dependency and <-> for mutual
coupling, competition, or confounding. Keep uncertainty in the explanation.
Do not emit a relationship sentence without both exact family ids, and do not
invent an edge merely to make the map look connected.

Write every human-readable narrative field in Traditional Chinese. Keep stable
ids, formulas, symbols, units, abbreviations, chemical or material names, and
scientific terms without an accurate Chinese equivalent in their precise
original form. Translate ordinary titles and prose; do not leave an English
sentence when a clear Traditional Chinese expression exists, and do not use
Simplified Chinese.

Treat causal and directional statements in prior research assets as claims to
audit, not facts that must be defended. Check whether a fixed quantity is also
used as the varied control, whether an entity-level quantity is promoted to a
bulk quantity without normalization, whether a necessary condition is treated
as proof, whether confounded variables receive separate effects, and whether
competing channels are compressed into an unsupported direction. Preserve the
useful family while making only the unsupported causal edge conditional and
naming the observation that would distinguish the alternatives.

Keep landscape_summary at or below 2000 characters and
evidence_boundary_summary at or below 1200 characters. Retain supported
mechanistic detail in families, relationships, and unresolved gaps. Do not
produce a formal hypothesis, formula, sample, artifact envelope, refs, ranking,
or next action. Return the current mind-map scientific-content shape exactly.
"""


_MINDMAP_DEEPENING_PROMPT = """\
Audit and deepen the supplied upper-system skeleton into the completed current
hypothesis mind-map shape. This is the final architecture-and-evidence pass.

Honor research_mode.stage_policy. In explore mode, shared assets are now visible
after the independent P0: compare them with the skeleton, preserve useful
novelty, and correct conflicts or duplication without treating prior work as
proof. In deepen mode they may guide this pass continuously.

The skeleton is provisional model interpretation, not source authority. Recheck
its scientific claims against evidence_authority: the formal task controls
objective and visibility, sanitized records control visible observations, model
extractions are fallible summaries, model interpretations are idea seeds, and
unknown_or_withheld retains its source, stage and consumer scope. Not visible to
this pass does not mean absent from the research or impossible to evaluate by
another authorized consumer. Existing source evidence can correct a mistaken
gap; it need not be newly produced. Exact source content wins over any draft.
In particular, audit named-component role assignments, isolated trends inferred
from confounded records, and pass/fail statements that include withheld values.
Do not claim that all criteria failed or passed when any criterion is withheld.

When family_identity_policy.required_family_ids is nonempty, preserve those ids
exactly. Otherwise the skeleton is a draft, not an identity authority. First
check that its families are independently actionable intervention classes or
reusable system strategies at a comparable abstraction level. Merge, split, or
rename draft families when one is merely an observed field, intermediate
quantity, process stage, constraint, failure mode, or property caused by another
family's controllable subsystem. Retain a draft family and its id when it passes
that audit. The completed set should cover task-authorized intervention classes
even when current records do not vary them, with missing evidence stated as a
bottleneck. Do not reorganize merely for novelty.

For each family, make the qualitative causal chain explicit as controllable
variable -> intermediate physical quantity -> target observable. Explain how
the interaction motif supports, competes with, or limits that chain. State the
scope, prerequisites, current bottleneck, realistic failure mode, and bounded
viability judgment. Fit the supplied task and research assets rather than using
generic textbook prose.

Also project that same chain into mechanism_chain. Use inputs_or_controls for
the intervention, input, external condition, or comparison state;
intermediate_processes for the mechanism steps or latent quantities; and
target_observables for quantities that can actually be observed or computed.
The structured chain is not a second scientific claim: every item must be
supported by core_mechanism, and uncertainty in the narrative must remain
uncertain in the projection.

Complete supported_relationships as explicit drawable edges. Every item must
be either `source_family_id -> target_family_id: Traditional Chinese
explanation` or `source_family_id <-> target_family_id: Traditional Chinese
explanation`, using exact ids from this result. Use the directional form only
for a directional influence or dependency, and the mutual form for coupling,
competition, or confounding. Preserve uncertainty and omit unsupported edges.

Write every human-readable narrative field in Traditional Chinese. Preserve
stable ids, formulas, symbols, units, abbreviations, chemical or material names,
and scientific terms without an accurate Chinese equivalent in their original
form. Translate ordinary titles and prose, and do not use Simplified Chinese.

Prior hypotheses and formulas are occupied directions and comparison evidence,
not causal proof. Do not inflate relative ordering into an unsupported absolute
number. If directionality is unknown, preserve that uncertainty and identify a
discriminating observation. Verify that the control can vary under the stated
fixed conditions; that per-entity, per-mass, per-volume, and system quantities
are not substituted without normalization; and that the direction survives
competing channels. Correct only the faulty link and retain supported detail.

Keep landscape_summary at or below 2000 characters and
evidence_boundary_summary at or below 1200 characters. Do not produce an
artifact envelope, refs, ranking, formula, sample, or next action. Return the
current mind-map scientific-content shape exactly.
"""


_HYPOTHESIS_CONSISTENCY_PROMPT = """\
Revise one existing provisional scientific hypothesis for internal scientific
consistency without replacing it with a different method. Preserve the exact
title and mind-map family id. Return the complete existing hypothesis-content
shape.

Preserving the candidate means preserving its identity and central research
question, not every source sentence or derivation. Treat the draft as a
provisional claim that may be wrong. Use this priority order: internal
scientific consistency, evidence boundaries, candidate identity, supported
detail, then source wording. Remove or replace an unsupported derivation rather
than repeating it and appending a caveat.

Audit and revise the actual fields, not a separate checklist:

1. Give each quantity one role within each proposed comparison. A quantity may
   describe the observed baseline and later become an intervention, but it
   cannot be both fixed and varied in the same comparison.
2. Keep per-molecule, per-chain, per-mass, per-area, per-volume, and system-level
   quantities distinct. At fixed bulk composition, a larger count per entity
   may be offset by fewer entities. Claim an intensive change only when an
   independent normalization is supplied and the factors do not cancel.
3. Call a quantity source-computable only when every factor and normalization is
   supplied or derivable. An assumed normalizer makes it a quantity to measure
   or estimate, not a completed computation.
4. Check the direction after all stated channels act together. If the sign is
   unresolved, propose a discriminating comparison instead of forcing a trend.
5. Separate a plausible mechanism, a necessary condition, and evidence that the
   mechanism controls the target. Do not promote the first two into proof.

Keep precise supported content and make uncertainty local to the unsupported
edge. Do not add artifact identity, refs, ranking, execution claims, private KPI
values, Markdown, or next action.
"""


_HYPOTHESIS_DEEPENING_PROMPT = """\
Deepen the supplied consistency-revised provisional hypothesis without changing
its title, mind-map family id, or scientific candidate identity. Make its
preference, causal mechanism, falsifiability, scope, and recommended verification
substantially clearer while preserving every supported scientific distinction.

Respect the existing field limits: title <= 240 characters; description <= 2000;
mechanism <= 3000; core_claim <= 1500; each risk <= 1200; each verification-plan
item <= 2500; and direction_card.lineage_role <= 500. Remove repeated context
instead of truncating a causal statement.

- description begins with the concrete preference: what to change or compare,
  fixed conditions, and the target observable. When direction is unresolved,
  state the discriminating comparison instead of guessing.
- mechanism gives the chain from controllable variable through intermediate
  physical quantities to the target, including competing channels and the
  assumptions connecting them.
- core_claim states one falsifiable relation with the control, comparison or
  direction, fixed conditions, expected observation, and explicit refutation.
- risks state confounders, scope limits, transitions, and adverse effects.
- each verification_plan string names a method, physical quantity or observable,
  supporting result, and refuting result. Prefer a suitable scientific
  calculation or simulation over an expensive experiment when it can genuinely
  discriminate the claim. This is advice only; do not write code or claim it ran.
- direction_card preserves the exact family_id and concisely explains how this
  same method develops that family.

Supporting research assets are context, not proof. A formula score or ranking is
not causal validation. Do not invent literature, measurements, execution,
private KPI values, or unsupported absolute numbers. Recheck control roles,
scale normalization, competing directions, evidence authority, and whether each
validation varies the control independently. Return only the complete existing
hypothesis scientific-content shape.
"""


_FORMULA_EXPLANATION_PROMPT = f"""\
Deepen the physical-property explanation of one existing frozen scientific proxy
formula. Scrutinize the formula rather than defending it. Formula identity,
expression, variable names, target identity, expected direction, source binding,
historical evidence, and materialization contract are immutable.

Rewrite only the supplied existing explanatory fields:

- input_variables[].meaning: physical quantity, unit or dimensionless status,
  and mechanistic role. Preserve every exact variable name and order.
- expected_final_kpi_link: explain every term and operator, the causal chain to
  the target, sign, direction, scaling, dimensional consistency, assumptions,
  public references, and uncalibrated coefficients.
- side_effect_notes: scope, competing mechanisms, saturation, regime changes,
  confounders, and conditions that remove ranking power without repetition.
- claim_boundary: exactly what trend or ranking may be supported and what cannot.
- validation_criteria: deepen text-valued explanations under the exact existing
  keys. Preserve every non-text threshold, flag, list, or object exactly; add,
  remove, or rename no key.

Shared research assets are context, not proof and not mandatory lineage. A
hypothesis may inspire an explanation, but the frozen formula need not serve it.
Do not alter the formula to agree with another method. Do not invent literature,
measurements, execution, fitted constants, private KPI values, or validation.

{SCIENTIFIC_CLAIM_CALIBRATION_GUIDE}

Audit these science-general boundaries before returning:

1. A structural count is not automatically a functional quencher, catalyst,
   charge carrier, active site, or reacted equivalent.
2. Nominal stoichiometry is not effective physical action. A 1:1 count does not
   prove neutralization, conversion, balance, or an optimum.
3. Dimensional consistency is necessary but does not establish calibration or a
   physical conversion coefficient.
4. Mathematical resemblance to a target shape does not prove the physical
   response has that center, sign, threshold, or symmetry.
5. If every visible record has the same formula input and output, the candidate
   has no demonstrated ranking power for those records.
6. Competing channels, saturation, normalization, or scale changes may reverse
   a claimed direction. Do not call a reference first-principles without the
   supplied derivation.

Use precise authority wording: "the formula encodes" describes mathematics;
"the physical system is expected to" requires supplied scientific support. The
claim boundary must be no stronger than the evidence. Preserve explanations
that pass the audit and expose failed premises in the existing fields. Return
only the requested existing explanation shape, never frozen fields, artifact
identity, refs, Markdown, score, ranking, or next action.
"""


def develop_mind_map_content(
    runtime: Any,
    *,
    research_context: Mapping[str, Any],
    deepening_research_context: Mapping[str, Any] | None = None,
    schema: Mapping[str, Any],
    validate_content: ContentValidator | None = None,
    required_family_ids: Sequence[str] = (),
    purpose_prefix: str = "mindmap",
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Build an upper system skeleton, then deepen it in the same shape."""

    required_ids = [str(value).strip() for value in required_family_ids]
    stage_context = {
        **dict(research_context),
        "family_identity_policy": {"required_family_ids": required_ids},
    }
    deepening_context = {
        **dict(deepening_research_context or research_context),
        "family_identity_policy": {"required_family_ids": required_ids},
    }
    skeleton_context = _mindmap_skeleton_context(stage_context)
    skeleton = _generate_with_local_repair(
        runtime,
        prompt=_MINDMAP_SKELETON_PROMPT,
        context=skeleton_context,
        repair_authority={"required_family_ids": required_ids},
        purpose=f"{purpose_prefix}-upper-system-skeleton",
        schema=schema,
        issues=lambda value: _mindmap_issues(
            value,
            required_family_ids=required_ids,
            validate_content=validate_content,
        ),
        scientific_call=True,
    )
    content = _generate_with_local_repair(
        runtime,
        prompt=_MINDMAP_DEEPENING_PROMPT,
        context={**deepening_context, "upper_system_skeleton": skeleton},
        repair_authority={"required_family_ids": required_ids},
        purpose=f"{purpose_prefix}-architecture-audit-and-evidence-deepening",
        schema=schema,
        issues=lambda value: _mindmap_issues(
            value,
            required_family_ids=required_ids,
            validate_content=validate_content,
        ),
    )
    return skeleton, content


def _mindmap_skeleton_context(
    research_context: Mapping[str, Any],
) -> dict[str, Any]:
    """Keep prior-map topology visible without replaying its long-form prose."""

    context = dict(research_context)
    prior_maps = context.pop("prior_terminal_mind_maps", [])
    if not isinstance(prior_maps, Sequence) or isinstance(
        prior_maps, (str, bytes)
    ):
        prior_maps = []
    context["prior_mind_map_architecture_summaries"] = [
        _prior_mind_map_architecture(item)
        for item in prior_maps
        if isinstance(item, Mapping)
    ]
    return context


def _prior_mind_map_architecture(
    artifact: Mapping[str, Any],
) -> dict[str, Any]:
    payload = artifact.get("machine_payload")
    if not isinstance(payload, Mapping):
        payload = artifact
    landscape = payload.get("mechanism_landscape")
    if not isinstance(landscape, Mapping):
        landscape = payload
    raw_families = landscape.get("families")
    if not isinstance(raw_families, list):
        raw_families = []
    family_fields = (
        "family_id",
        "title",
        "causal_role",
        "interaction_motif",
        "scope_mode",
        "main_bottleneck",
        "viability_band",
        "mechanism_chain",
    )
    families = [
        {
            key: family[key]
            for key in family_fields
            if key in family and family[key] not in (None, "", [], {})
        }
        for family in raw_families
        if isinstance(family, Mapping)
    ]
    return {
        "artifact_ref": artifact.get("artifact_ref"),
        "artifact_kind": artifact.get("artifact_kind"),
        "title": artifact.get("title"),
        "summary": artifact.get("summary"),
        "landscape_summary": landscape.get(
            "mechanism_landscape_summary",
            landscape.get("landscape_summary"),
        ),
        "families": families,
        "supported_relationships": landscape.get(
            "supported_relationships",
            [],
        ),
        "unresolved_gaps": landscape.get("unresolved_gaps", []),
        "evidence_boundary_summary": landscape.get(
            "evidence_boundary_summary"
        ),
    }


def deepen_hypothesis_content(
    runtime: Any,
    *,
    draft: Mapping[str, Any],
    shared_research_assets: Sequence[Mapping[str, Any]],
    schema: Mapping[str, Any],
    purpose_prefix: str = "hypothesis",
    consistency_prompt: str | None = None,
    deepening_prompt: str | None = None,
) -> dict[str, Any]:
    """Repair premise consistency, then deepen the same hypothesis."""

    exact_title = str(draft.get("title") or "")
    exact_family_id = _hypothesis_family_id(draft)
    identity_issues = lambda value: _hypothesis_issues(
        value,
        schema=schema,
        exact_title=exact_title,
        exact_family_id=exact_family_id,
    )
    context = {
        "source_hypothesis_draft": dict(draft),
        "shared_research_assets": [dict(item) for item in shared_research_assets],
    }
    consistent = _generate_with_local_repair(
        runtime,
        prompt=consistency_prompt or _HYPOTHESIS_CONSISTENCY_PROMPT,
        context=context,
        repair_authority={
            "exact_title": exact_title,
            "exact_family_id": exact_family_id,
        },
        purpose=f"{purpose_prefix}-premise-consistency",
        schema=schema,
        issues=identity_issues,
    )
    return _generate_with_local_repair(
        runtime,
        prompt=deepening_prompt or _HYPOTHESIS_DEEPENING_PROMPT,
        context={
            "consistency_revised_hypothesis": consistent,
            "shared_research_assets": context["shared_research_assets"],
        },
        repair_authority={
            "exact_title": exact_title,
            "exact_family_id": exact_family_id,
        },
        purpose=f"{purpose_prefix}-mechanism-verification-deepening",
        schema=schema,
        issues=identity_issues,
    )


def deepen_proxy_formula_explanation(
    runtime: Any,
    *,
    candidate: Mapping[str, Any],
    shared_research_assets: Sequence[Mapping[str, Any]],
    historical_grounding: Mapping[str, Any],
    source_background: Mapping[str, Any] | None = None,
    authorized_task_data: Mapping[str, Any] | None = None,
    materializer_capability: str | None = None,
    validate_candidate: ContentValidator,
    purpose_prefix: str = "proxy",
) -> dict[str, Any]:
    """Deepen only explanatory fields of one frozen proxy formula."""

    schema = _formula_explanation_schema(candidate)
    exact_names = _formula_variable_names(candidate)
    exact_criteria = [str(key) for key in candidate["validation_criteria"]]
    exact_criteria_values = dict(candidate["validation_criteria"])

    def issues(value: Mapping[str, Any]) -> list[str]:
        found = _formula_explanation_issues(
            value,
            schema=schema,
            exact_variable_names=exact_names,
            exact_criteria_keys=exact_criteria,
            exact_criteria_values=exact_criteria_values,
        )
        if found:
            return found
        merged = _merge_formula_explanation(candidate, value)
        found.extend(_call_validator(validate_candidate, merged))
        return found

    context = {
        "frozen_formula": _frozen_formula_projection(candidate),
        "source_explanation": _formula_explanation(candidate),
        "historical_grounding": dict(historical_grounding),
        "shared_research_assets": [dict(item) for item in shared_research_assets],
    }
    if source_background:
        context["direct_source_background"] = dict(source_background)
    if authorized_task_data:
        context["authorized_task_data"] = dict(authorized_task_data)
    if materializer_capability:
        context["materializer_capability"] = materializer_capability
    explanation = _generate_with_local_repair(
        runtime,
        prompt=_FORMULA_EXPLANATION_PROMPT + (
            "\n\n" + SOURCE_CONTEXT_GUIDE if source_background else ""
        ),
        context=context,
        repair_authority={
            "frozen_formula": _frozen_formula_projection(candidate),
            "source_explanation": _formula_explanation(candidate),
            "exact_variable_names": exact_names,
            "exact_validation_criteria": exact_criteria_values,
        },
        purpose=f"{purpose_prefix}-physical-explanation-deepening",
        schema=schema,
        issues=issues,
    )
    merged = _merge_formula_explanation(candidate, explanation)
    remaining = _call_validator(validate_candidate, merged)
    if remaining:
        raise ValueError(
            "proxy_formula_deepening_invalid:" + "; ".join(remaining)
        )
    return merged


def _generate_with_local_repair(
    runtime: Any,
    *,
    prompt: str,
    context: Mapping[str, Any],
    repair_authority: Mapping[str, Any] | None = None,
    purpose: str,
    schema: Mapping[str, Any],
    issues: Callable[[Mapping[str, Any]], Sequence[str]],
    scientific_call: bool = False,
) -> dict[str, Any]:
    result = runtime.generate_json(
        prompt,
        _json(context),
        purpose=purpose,
        schema=dict(schema),
        scientific_call=scientific_call,
    )
    found = list(dict.fromkeys(issues(result)))
    if not found:
        return dict(result)

    repaired = runtime.generate_json(
        prompt
        + "\n\nRepair only the listed structural, identity, or consistency "
        + "defects. Preserve the same authority and return the complete "
        + "requested existing shape.",
        _json(
            {
                "rejected_result": result,
                "validation_issues": found,
                "repair_authority": {
                    **{key: context[key] for key in (
                        "evidence_authority", "direct_source_background", "authorized_task_data",
                        "materializer_capability",
                    ) if key in context},
                    **dict(repair_authority or {}),
                },
            }
        ),
        purpose=f"{purpose}-local-repair",
        schema=dict(schema),
        repair_call=True,
    )
    remaining = list(dict.fromkeys(issues(repaired)))
    if remaining:
        raise ValueError(
            f"scientific_content_deepening_invalid:{purpose}:"
            + "; ".join(remaining)
        )
    return dict(repaired)


def _mindmap_issues(
    value: Mapping[str, Any],
    *,
    required_family_ids: Sequence[str],
    validate_content: ContentValidator | None,
) -> list[str]:
    issues: list[str] = []
    ids = _family_ids(value)
    if not ids or len(ids) != len(set(ids)):
        issues.append("mindmap_family_ids_must_be_nonempty_and_unique")
    required = [str(item) for item in required_family_ids]
    if required and (len(ids) != len(required) or set(ids) != set(required)):
        issues.append(
            "mindmap_family_ids_must_match:"
            f"expected={required}:actual={ids}"
        )
    if validate_content is not None:
        issues.extend(_call_validator(validate_content, value))
    return issues


def _family_ids(value: Mapping[str, Any]) -> list[str]:
    families = value.get("families")
    if not isinstance(families, list):
        return []
    return [
        str(item.get("family_id") or "").strip()
        for item in families
        if isinstance(item, Mapping)
    ]


def _hypothesis_issues(
    value: Mapping[str, Any],
    *,
    schema: Mapping[str, Any],
    exact_title: str,
    exact_family_id: str,
) -> list[str]:
    issues = list(json_schema_issues(value, schema))
    if issues:
        return issues
    if str(value.get("title") or "") != exact_title:
        issues.append("hypothesis_title_must_match_draft")
    if _hypothesis_family_id(value) != exact_family_id:
        issues.append(
            "hypothesis_family_must_match_draft:"
            f"expected={exact_family_id}:actual={_hypothesis_family_id(value)}"
        )
    return issues


def _hypothesis_family_id(value: Mapping[str, Any]) -> str:
    direction = value.get("direction_card")
    if not isinstance(direction, Mapping):
        return ""
    return str(direction.get("family_id") or "").strip()


def _formula_explanation_schema(
    candidate: Mapping[str, Any],
) -> dict[str, Any]:
    names = _formula_variable_names(candidate)
    criteria = candidate.get("validation_criteria")
    if not names:
        raise ValueError("proxy_formula_deepening_variables_required")
    if not isinstance(criteria, Mapping) or not criteria:
        raise ValueError("proxy_formula_deepening_criteria_required")
    short = {"type": "string", "minLength": 1, "maxLength": 2500}
    return {
        "type": "object",
        "properties": {
            "input_variables": {
                "type": "array",
                "minItems": len(names),
                "maxItems": len(names),
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "enum": names},
                        "meaning": short,
                    },
                    "required": ["name", "meaning"],
                    "additionalProperties": False,
                },
            },
            "expected_final_kpi_link": {
                "type": "string",
                "minLength": 1,
                "maxLength": 5000,
            },
            "side_effect_notes": {
                "type": "array",
                "minItems": 1,
                "maxItems": 10,
                "items": short,
            },
            "claim_boundary": {
                "type": "string",
                "minLength": 1,
                "maxLength": 5000,
            },
            "validation_criteria": {
                "type": "object",
                "properties": {
                    str(key): short if isinstance(value, str) else {}
                    for key, value in criteria.items()
                },
                "required": [str(key) for key in criteria],
                "additionalProperties": False,
            },
        },
        "required": [
            "input_variables",
            "expected_final_kpi_link",
            "side_effect_notes",
            "claim_boundary",
            "validation_criteria",
        ],
        "additionalProperties": False,
    }


def _formula_variable_names(candidate: Mapping[str, Any]) -> list[str]:
    variables = candidate.get("input_variables")
    if not isinstance(variables, list):
        return []
    return [
        str(item.get("name") or "").strip()
        for item in variables
        if isinstance(item, Mapping)
        and str(item.get("name") or "").strip()
    ]


def _formula_explanation_issues(
    value: Mapping[str, Any],
    *,
    schema: Mapping[str, Any],
    exact_variable_names: Sequence[str],
    exact_criteria_keys: Sequence[str],
    exact_criteria_values: Mapping[str, Any],
) -> list[str]:
    issues = list(json_schema_issues(value, schema))
    if issues:
        return issues
    actual_names = _formula_variable_names(value)
    if actual_names != list(exact_variable_names):
        issues.append(
            "proxy_formula_deepening_variable_order_must_match:"
            f"expected={list(exact_variable_names)}:actual={actual_names}"
        )
    criteria = value.get("validation_criteria")
    actual_keys = list(criteria) if isinstance(criteria, Mapping) else []
    if set(actual_keys) != set(exact_criteria_keys):
        issues.append(
            "proxy_formula_deepening_criteria_must_match:"
            f"expected={sorted(exact_criteria_keys)}:"
            f"actual={sorted(actual_keys)}"
        )
    if isinstance(criteria, Mapping):
        for key, expected in exact_criteria_values.items():
            if isinstance(expected, str):
                continue
            if criteria.get(key) != expected:
                issues.append(
                    "proxy_formula_deepening_nontext_criterion_must_match:"
                    f"key={key}:expected={expected!r}:actual={criteria.get(key)!r}"
                )
    return issues


def _formula_explanation(candidate: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "input_variables": candidate.get("input_variables"),
        "expected_final_kpi_link": candidate.get("expected_final_kpi_link"),
        "side_effect_notes": candidate.get("side_effect_notes"),
        "claim_boundary": candidate.get("claim_boundary"),
        "validation_criteria": candidate.get("validation_criteria"),
    }


def _frozen_formula_projection(candidate: Mapping[str, Any]) -> dict[str, Any]:
    editable = set(_formula_explanation(candidate))
    return {key: value for key, value in candidate.items() if key not in editable}


def _merge_formula_explanation(
    candidate: Mapping[str, Any],
    explanation: Mapping[str, Any],
) -> dict[str, Any]:
    merged = json.loads(json.dumps(candidate, ensure_ascii=False))
    for key in _formula_explanation(candidate):
        merged[key] = json.loads(json.dumps(explanation[key], ensure_ascii=False))
    return merged


def _call_validator(
    validator: ContentValidator,
    value: Mapping[str, Any],
) -> list[str]:
    try:
        result = validator(value)
    except ValueError as exc:
        return [str(exc)]
    return [str(item) for item in (result or [])]


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)
