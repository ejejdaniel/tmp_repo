from __future__ import annotations

import copy
import json
from typing import Any, Mapping, Sequence


def read_sample_parameters(
    runtime: Any, artifacts: Sequence[Mapping[str, Any]]
) -> list[dict[str, Any]]:
    """Join selected best samples to their immutable candidate records by ID."""
    parameters = []
    seen = set()
    for artifact in artifacts:
        if artifact.get("artifact_kind") != "sample_evolution_result":
            continue
        artifact_ref = str(artifact["artifact_ref"])
        if artifact_ref in seen:
            continue
        seen.add(artifact_ref)
        bundle_refs = list(dict.fromkeys(
            ref for ref in artifact.get("trace_refs", [])
            if isinstance(ref, str) and ref.startswith("workspace:sample-candidate-bundles/")
        ))
        # Inline representations remain in their original formal payload.
        if not bundle_refs:
            continue
        if len(bundle_refs) != 1:
            raise ValueError(f"sample_candidate_bundle_ambiguous:{artifact_ref}")
        best = artifact.get("machine_payload", {}).get("best_sample", {})
        sample_id = best.get("sample_id")
        if not isinstance(sample_id, str) or not sample_id:
            raise ValueError(f"sample_best_identity_missing:{artifact_ref}")
        bundle_ref = bundle_refs[0]
        bundle = runtime.call_route(
            "scientific_sample_candidate_bundle_read", {"candidate_bundle_ref": bundle_ref}
        )
        if bundle.get("candidate_bundle_ref") != bundle_ref:
            raise ValueError(f"sample_candidate_bundle_ref_mismatch:{bundle_ref}")
        records = bundle.get("records")
        if not isinstance(records, list):
            raise ValueError(f"sample_candidate_bundle_shape_invalid:{bundle_ref}")
        matches = [record for record in records
                   if isinstance(record, Mapping) and record.get("id") == sample_id]
        if len(matches) != 1:
            raise ValueError(f"sample_candidate_record_identity_mismatch:{bundle_ref}:{sample_id}")
        record = matches[0]
        # Keep native keys and values; prose is not a source of executable parameters.
        inputs = {key: copy.deepcopy(record[key]) for key in ("id", "metadata", "smiles")
                  if key in record}
        parameters.append({
            "artifact_ref": artifact_ref,
            "candidate_bundle_ref": bundle_ref,
            "record": inputs,
        })
    return parameters


def render_sample_parameters(parameters: Sequence[Mapping[str, Any]]) -> str:
    """Render exact inputs separately from generated scientific interpretation."""
    if not parameters:
        return ""
    lines = ["### 樣本原始參數", "",
             "以下內容由所屬成果連結的候選檔按樣本識別碼讀回，未由模型改寫。"
             "欄位與數值維持原樣，不推定未聲明的單位。", ""]
    for item in parameters:
        body = json.dumps(item["record"], ensure_ascii=False, indent=2, allow_nan=False)
        fence = "```"
        while fence in body:
            fence += "`"
        lines.extend([
            f"所屬正式樣本成果：[{item['artifact_ref']}]({item['artifact_ref']})",
            f"完整參數來源：`{item['candidate_bundle_ref']}`", "",
            fence + "json", body, fence, "",
        ])
    return "\n".join(lines)
