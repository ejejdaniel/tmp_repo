from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Callable

from ai_coscientist.common.artifacts import ArtifactStore
from ai_coscientist.common.code_artifacts import CodeArtifactStore
from ai_coscientist.common.development import DevelopmentProjectStore
from ai_coscientist.common.implementation_projection import implementation_projection_schema
from ai_coscientist.common.json_schema import json_schema_issues
from ai_coscientist.common.observations import ObservationStore
from ai_coscientist.common.reference_links import ReferenceResolver, SOURCE_CONTENT_PREFIXES
from ai_coscientist.common.routes import Route


def report_readers(root: Path, store: ArtifactStore, source_reader: Callable | None = None):
    """Use the caller's existing source mount, never infer another workspace."""
    codes, observations = CodeArtifactStore(root), ObservationStore(root)
    projects = DevelopmentProjectStore(root, artifacts=store)

    def read_exact(ref):
        if ref.startswith("code_artifact:"):
            return codes.read(ref)
        if ref.startswith("execution_observation:"):
            return observations.read(ref)
        return store.read(ref)

    def load(ref, path):
        if ref.startswith(SOURCE_CONTENT_PREFIXES):
            if source_reader is None:
                raise ValueError("scientific_report_source_root_required")
            if path is not None:
                raise ValueError("reference_path_requires_snapshot")
            return source_reader(ref)
        if ref.startswith("development_output:"):
            return projects.output_bytes(ref)
        if path is not None:
            return projects.snapshot_file_bytes(ref, path)
        return read_exact(ref)

    return read_exact, ReferenceResolver(load)


def report_renderer():
    path = (Path(__file__).resolve().parents[3] / "skills" /
            "scientific-report-writer" / "scripts" / "render_report.py")
    spec = importlib.util.spec_from_file_location("scientific_report_renderer", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"scientific_report_renderer_load_failed:{path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def scientific_report_route(
    *, run_root: Path, artifacts: ArtifactStore, reference_resolver: ReferenceResolver,
    browser_executable: Path | None = None,
) -> Route:
    schema = {
        "type": "object", "additionalProperties": False,
        "required": ["report_ref"],
        "properties": {
            "report_ref": {"type": "string", "minLength": 1},
            "implementation_projections": {
                "type": "array", "items": implementation_projection_schema(),
            },
        },
    }

    def validate(arguments):
        issues = json_schema_issues(arguments, schema)
        if issues:
            raise ValueError("scientific_report_render_arguments_invalid:" + ";".join(issues))
        report = artifacts.read(arguments["report_ref"])
        if report.get("artifact_kind") != "scientific_report":
            raise ValueError("scientific_report_render_requires_report")

    def render(arguments) -> dict[str, Any]:
        validate(arguments)
        ref = arguments["report_ref"]
        # Exact report identity determines the destination, not a model-authored path.
        destination = (run_root.resolve() / "reports" / hashlib.sha256(ref.encode()).hexdigest())
        destination.mkdir(parents=True, exist_ok=True)
        projection_path = destination / "implementation-projections.json"
        projections = arguments.get("implementation_projections")
        if projections:
            projection_path.write_text(json.dumps(projections, ensure_ascii=False, indent=2) + "\n",
                                       encoding="utf-8")
        elif projection_path.is_file():
            projections = json.loads(projection_path.read_text(encoding="utf-8"))
        # A failed browser must not replace a previously delivered file pair.
        with tempfile.TemporaryDirectory(prefix=".render-", dir=destination) as temporary:
            staging = Path(temporary)
            result = report_renderer().write_report_projection(
                artifact_root=run_root, report_ref=ref,
                html_output=staging / "scientific-report.html",
                pdf_output=staging / "scientific-report.pdf",
                implementation_projections=projections,
                reference_resolver=reference_resolver,
                browser_executable=browser_executable,
            )
            for key in ("html_path", "pdf_path"):
                source = Path(result[key])
                target = destination / source.name
                os.replace(source, target)
                result[key] = str(target)
        return result

    return Route(
        name="render_scientific_report",
        description=("Render one exact stored scientific_report as HTML and PDF without "
                     "rewriting it. Destinations are host-owned. Retry the same ref after "
                     "a presentation failure; do not regenerate research or report prose."),
        parameters=schema, handler=render, validator=validate,
        skill_ids=("scientific-report-writer",),
    )
