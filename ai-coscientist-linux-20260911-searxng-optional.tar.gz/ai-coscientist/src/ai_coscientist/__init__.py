"""Pure Python dynamic scientific workflow."""

