from __future__ import annotations

import argparse
import configparser
import hashlib
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from ai_coscientist.common.capabilities import (
    CapabilityRegistry,
    DockerPythonExecutor,
    DockerRouteExecutorPool,
    resolve_local_docker_image_id,
)
from ai_coscientist.common.children import MissionWorkspacePathPolicy
from ai_coscientist.common.dialogue import DialogueStore
from ai_coscientist.common.memory_lifecycle.events import EventLog
from ai_coscientist.common.memory_lifecycle.dialogue_memory import DialogueMemory
from ai_coscientist.common.memory_lifecycle.migration import (
    migrate_agent_v16_dialogue_memory,
)
from ai_coscientist.common.memory_lifecycle.state import AgentStateStore
from ai_coscientist.common.memory_lifecycle.work_store import WorkMemoryStore
from ai_coscientist.common.observations import ObservationStore
from ai_coscientist.common.openai_compatible import OpenAICompatibleModel
from ai_coscientist.common.pre_task_loop import (
    PRE_TASK_SKILL_ID,
    PreTaskLoop,
)
from ai_coscientist.common.routes import RouteRegistry
from ai_coscientist.common.source_exploration import SourceExplorer
from ai_coscientist.common.reference_links import ReferenceResolver
from ai_coscientist.domain.session import (
    ScientificSession,
    create_scientific_session,
)
from ai_coscientist.domain.dialogue_task_bootstrap import DialogueTaskLaunch
from ai_coscientist.domain.source_authority import (
    SourceAuthorityError,
    SourceSpec,
)


PROJECT_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_SOURCE_ROOT = PROJECT_ROOT
DEFAULT_CONFIG = PROJECT_ROOT / "config_deepseek_v4_flash.cfg"
DEFAULT_CAPABILITY_REGISTRY = PROJECT_ROOT / "managed_capabilities"
DEFAULT_DOCKER_IMAGE = "ai-coscientist-native-science"
DEFAULT_DOCKER_LOCAL_TAG = "ai-coscientist-native-science:py312-v2"
DEFAULT_DOCKER_DIGEST: str | None = None


@dataclass
class _ChatRuntime:
    arguments: argparse.Namespace
    output: Path
    config: Mapping[str, str]
    model: OpenAICompatibleModel
    registry: CapabilityRegistry
    executor: DockerPythonExecutor | DockerRouteExecutorPool
    pre_task: PreTaskLoop
    dialogue_memory: DialogueMemory | None = None
    session: ScientificSession | None = None

    def close(self) -> None:
        self.executor.close()

    def ensure_session(
        self,
        *,
        objective_override: str | None = None,
        task_authority_mode: str | None = None,
        dialogue_launch: DialogueTaskLaunch | None = None,
    ) -> ScientificSession:
        if self.session is not None:
            return self.session
        resolved_objective = (
            str(objective_override).strip()
            if objective_override is not None
            else ""
        )
        resolved_mode = (
            str(task_authority_mode).strip()
            if task_authority_mode is not None
            else ""
        )
        if self.has_formal_state():
            persisted_objective = str(
                AgentStateStore(self.output / "agent-state.json").read()["c0"][
                    "objective"
                ]
            ).strip()
            if resolved_objective and resolved_objective != persisted_objective:
                raise ValueError(
                    "chat_session_objective_conflicts_with_persisted_c0"
                )
            resolved_objective = persisted_objective
            if not resolved_mode:
                resolved_mode = "dialogue_launch"
        if not resolved_mode:
            resolved_mode = "configured_source"
        source_spec = _source_spec(self.arguments)
        requested_timeout = getattr(self.arguments, "timeout", None)
        materializer_timeout = (
            float(requested_timeout)
            if requested_timeout is not None
            else float(self.config.get("timeout", 60.0))
        )
        self.session = create_scientific_session(
            run_root=self.output,
            source_spec=source_spec,
            source_root=self.arguments.source_root.resolve(),
            model=self.model,
            project_root=PROJECT_ROOT,
            capability_registry=self.registry,
            max_rounds=int(self.arguments.max_rounds),
            human_in_loop_enabled=bool(self.arguments.human_in_loop),
            python_executable=sys.executable,
            materializer_timeout_seconds=materializer_timeout,
            objective_override=(resolved_objective or None),
            task_authority_mode=resolved_mode,
            dialogue_launch=dialogue_launch,
            dialogue_memory=self.dialogue_memory,
        )
        return self.session

    def has_formal_state(self) -> bool:
        return (self.output / "agent-state.json").is_file()

    def dialogue_message(self, message_id: str) -> dict[str, Any]:
        if self.dialogue_memory is not None:
            return self.dialogue_memory.dialogue.get(message_id)
        return DialogueStore(self.output / "dialogue").get(message_id)


def configure_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument(
        "--source-root",
        type=Path,
        default=DEFAULT_SOURCE_ROOT,
    )
    parser.add_argument(
        "--goal-relative-path",
        help=(
            "Optional pinned benchmark goal. Supply together with "
            "--historical-relative-path and --expected-record-count."
        ),
    )
    parser.add_argument(
        "--historical-relative-path",
        help=(
            "Optional pinned benchmark data source. General dialogue-launched "
            "research does not require it."
        ),
    )
    parser.add_argument("--goal-sha256")
    parser.add_argument("--historical-sha256")
    parser.add_argument("--expected-record-count", type=int)
    parser.add_argument("--max-rounds", type=int, default=120)
    parser.add_argument("--max-tokens", type=int)
    parser.add_argument("--timeout", type=float)
    parser.add_argument(
        "--human-in-loop",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Allow the scientific runtime to pause and ask the human. Use "
            "--no-human-in-loop for unattended research."
        ),
    )
    parser.add_argument(
        "--capability-registry",
        type=Path,
        default=DEFAULT_CAPABILITY_REGISTRY,
    )
    parser.add_argument(
        "--capability-docker-base-image",
        default=DEFAULT_DOCKER_IMAGE,
    )
    parser.add_argument(
        "--capability-docker-base-image-digest",
        default=DEFAULT_DOCKER_DIGEST,
        help=(
            "Immutable default-runtime digest. When omitted with the default "
            "repository, resolve the local native-science tag to its image ID."
        ),
    )
    parser.add_argument("--capability-docker-base-image-reference")
    parser.add_argument(
        "--capability-docker-additional-runtime",
        action="append",
        default=[],
        metavar="EXACT_IMAGE_REFERENCE",
    )
    parser.add_argument("--capability-docker-cache-root", type=Path)


def run_scientific_chat(arguments: argparse.Namespace) -> int:
    config = _llm_config(arguments.config.resolve())
    current_output = arguments.output.resolve()
    runtime = _create_runtime(
        arguments=arguments,
        output=current_output,
        config=config,
    )
    try:
        if runtime.has_formal_state():
            runtime.ensure_session()
        _print_banner(runtime, current_output)
        if runtime.session is not None:
            _resume_interrupted_turn(runtime.session)
        while True:
            try:
                raw = input("you> ").strip()
            except EOFError:
                print()
                return 0
            except KeyboardInterrupt:
                print("\n已離開聊天；已寫入的狀態可由相同 --output 繼續。")
                return 130
            if not raw:
                continue
            if raw.startswith("/"):
                command = raw.split(maxsplit=1)[0].lower()
                if command == "/exit":
                    return 0
                if command == "/help":
                    _print_help()
                    continue
                if command == "/reference":
                    _print_reference(runtime, raw[len("/reference"):].strip())
                    continue
                if command == "/status":
                    _print_status(runtime)
                    continue
                if command == "/details":
                    _print_details(runtime)
                    continue
                if command == "/artifacts":
                    _print_artifacts(runtime)
                    continue
                if command == "/graph":
                    _print_graph(runtime)
                    continue
                if command == "/new":
                    value = raw[len("/new") :].strip()
                    if not value:
                        value = input("new output> ").strip()
                    if not value:
                        print("未建立新工作階段：必須提供新的輸出目錄。")
                        continue
                    next_output = Path(value).resolve()
                    if next_output == current_output:
                        print("新工作階段必須使用不同的輸出目錄。")
                        continue
                    runtime.close()
                    current_output = next_output
                    runtime = _create_runtime(
                        arguments=arguments,
                        output=current_output,
                        config=config,
                    )
                    if runtime.has_formal_state():
                        runtime.ensure_session()
                    _print_banner(runtime, current_output)
                    if runtime.session is not None:
                        _resume_interrupted_turn(runtime.session)
                    continue
                print(f"未知命令：{command}。輸入 /help 查看可用命令。")
                continue
            try:
                result = _run_chat_turn(runtime, raw)
            except KeyboardInterrupt:
                print("\n研究已中斷；下次以相同 --output 啟動時會接續本輪。")
                return 130
            except Exception as exc:
                print(f"system error> {exc}")
                print("本輪狀態已保留；重新啟動相同 --output 會嘗試接續。")
                return 2
            _print_turn_result(result)
    finally:
        runtime.close()


def _print_reference(runtime: _ChatRuntime, link: str) -> None:
    try:
        if runtime.session is not None:
            resolver = runtime.session.agent._reference_resolver()
        else:
            def load(ref: str, path: str | None) -> Any:
                if path is not None:
                    raise ValueError("reference_path_requires_snapshot")
                return runtime.pre_task._routes.reference_source(ref)
            resolver = ReferenceResolver(load)
        selected = resolver.resolve(link)
        print(f"來源：{selected.label}\n版本：{selected.locator['content_sha256']}")
        if selected.pdf:
            # Opening the local original-page copy works even without extractable text.
            output = runtime.output / "reference-previews"
            output.mkdir(exist_ok=True)
            preview = output / f"{selected.locator['content_sha256']}.pdf"
            preview.write_bytes(selected.body)
            start = selected.locator.get("range", {}).get("start", 1)
            print(f"原頁：{preview.as_uri()}#page={start}")
        offset = 0
        while True:
            page = resolver.read(link, line_offset=offset)
            print(page["content"], end="\n")
            if page["next_line_offset"] is None:
                break
            print(f"已顯示 {offset + page['line_count']} / {page['total_lines']} 行。")
            if input("Enter 繼續；q 返回聊天> ").strip().lower() == "q":
                break
            offset = page["next_line_offset"]
    except (ValueError, KeyError, OSError, RuntimeError, PermissionError) as exc:
        print(f"引用無法讀取：{exc}")


def _create_runtime(
    *,
    arguments: argparse.Namespace,
    output: Path,
    config: Mapping[str, str],
) -> _ChatRuntime:
    output.mkdir(parents=True, exist_ok=True)
    executor = _capability_executor(arguments)
    registry = CapabilityRegistry(
        arguments.capability_registry.resolve(),
        python_executable=sys.executable,
        route_executor=executor,
    )
    model = OpenAICompatibleModel(
        base_url=config["api_base"],
        model=config["model_name"],
        api_key=config["api_key"],
        timeout_seconds=(
            float(arguments.timeout)
            if arguments.timeout is not None
            else float(config["timeout"])
        ),
        max_tokens=(
            int(arguments.max_tokens)
            if arguments.max_tokens is not None
            else int(config["max_tokens"])
        ),
        temperature=float(config["temperature"]),
        reasoning_effort=config["reasoning_effort"],
        scientific_reasoning_effort=config.get(
            "scientific_reasoning_effort", ""
        ),
        repair_reasoning_effort=config.get("repair_reasoning_effort", ""),
        planning_reasoning_effort=config.get("planning_reasoning_effort", ""),
        on_status=_print_model_status,
        debug_trace_path=output / "llm-reasoning-debug.jsonl",
    )
    try:
        source_root = arguments.source_root.resolve()
        explorer = SourceExplorer(
            source_root=source_root,
            workspace_root=output / "workspace" / "pre-task-inquiry",
            allowed_relative_paths=(".",),
            python_executable=sys.executable,
            path_policy=MissionWorkspacePathPolicy(),
        )
        events = EventLog(output / "events.jsonl")
        work_store = WorkMemoryStore(output / "work-memory.sqlite3")
        state_store = AgentStateStore(output / "agent-state.json")
        migrate_agent_v16_dialogue_memory(
            state_store=state_store,
            work_store=work_store,
            dialogue_id="scientific-coordinator",
        )
        dialogue_memory = DialogueMemory(
            dialogue_id="scientific-coordinator",
            dialogue=DialogueStore(output / "dialogue"),
            work_store=work_store,
            model=model,
            events=events,
        )
        routes = RouteRegistry(
            (
                *explorer.routes(
                    skill_ids=(PRE_TASK_SKILL_ID,),
                    include_workspace_terminal=True,
                ),
                *dialogue_memory.routes(skill_ids=(PRE_TASK_SKILL_ID,)),
            )
        )
        pre_task = PreTaskLoop(
            model=model,
            routes=routes,
            dialogue_memory=dialogue_memory,
            observations=ObservationStore(output),
            events=events,
            skill_path=(
                PROJECT_ROOT
                / "src"
                / "ai_coscientist"
                / "common"
                / "pre_task_inquiry"
                / "SKILL.md"
            ),
        )
    except Exception:
        executor.close()
        raise
    return _ChatRuntime(
        arguments=arguments,
        output=output,
        config=config,
        model=model,
        registry=registry,
        executor=executor,
        pre_task=pre_task,
        dialogue_memory=dialogue_memory,
    )


def _run_chat_turn(
    runtime: _ChatRuntime,
    user_text: str,
) -> Any:
    if runtime.session is not None:
        return runtime.session.agent.chat_turn(
            user_text=user_text,
            objective=runtime.session.objective,
            evaluation_summary=runtime.session.evaluation_summary,
        )
    pre_task_result = runtime.pre_task.run(user_text)
    if pre_task_result.status != "task_ready":
        return pre_task_result
    try:
        session = runtime.ensure_session(
            task_authority_mode="dialogue_launch",
            dialogue_launch=DialogueTaskLaunch(
                user_message_id=pre_task_result.user_message_id,
                context_message_ids=pre_task_result.context_message_ids,
                supporting_refs=pre_task_result.supporting_refs,
            ),
        )
    except (
        FileNotFoundError,
        OSError,
        SourceAuthorityError,
        ValueError,
    ) as exc:
        return runtime.pre_task.finish_deferred(
            pre_task_result,
            status="clarification_required",
            message=(
                "這項工作需要進入正式定題，但目前設定的資料來源介面尚不能建立："
                f"{exc}。請補齊或修正 source adapter 設定。"
            ),
        )
    return session.agent.begin_preformulated_task_from_dialogue_message(
        user_message_id=pre_task_result.user_message_id,
        objective=session.objective,
        evaluation_summary=session.evaluation_summary,
    )


def _resume_interrupted_turn(session: ScientificSession) -> None:
    state_path = session.agent._state.path
    if not state_path.exists():
        return
    active = session.agent._state.read()["c1"]["dialogue_turn_state"]
    if active["phase"] == "idle":
        return
    print(
        f"system> 接續未完成對話 {active['turn_id']}（{active['phase']}）。",
        flush=True,
    )
    result = session.agent.resume_dialogue_turn(
        objective=session.objective,
        evaluation_summary=session.evaluation_summary,
    )
    _print_turn_result(result)


def _print_banner(runtime: _ChatRuntime, output: Path) -> None:
    message_count = len(DialogueStore(output / "dialogue").read())
    print("AI Co-scientist Research Chat")
    print(f"工作階段：{output}")
    print(
        "模式："
        + (
            "正式研究"
            if runtime.session is not None
            else "前置對話（尚未建立正式任務）"
        )
    )
    print(f"已載入對話：{message_count} 則；輸入 /help 查看命令。")
    pending = (
        runtime.session.agent.pending_human_interaction()
        if runtime.session is not None
        else None
    )
    if pending is not None:
        print(f"system> {pending['question']}")


def _print_turn_result(result: Any) -> None:
    print(f"assistant> {result.message}")
    if result.evidence_refs:
        print("evidence> " + ", ".join(result.evidence_refs))


def _print_help() -> None:
    print(
        "/status 目前流程狀態\n"
        "/details 驗收與控制細節\n"
        "/artifacts 正式成果索引\n"
        "/graph 目前研究圖\n"
        "/new [output] 以同一工作區設定建立乾淨工作階段\n"
        "/reference <reference_link> 開啟精確來源與引用範圍（不呼叫模型）\n"
        "/exit 離開"
    )


def _print_status(runtime: _ChatRuntime) -> None:
    session = runtime.session
    if session is None:
        print("status> 前置對話中；尚未建立 C0、Global Evaluation 或 Graph。")
        return
    state_path = session.agent._state.path
    if not state_path.exists():
        print("status> 尚未開始研究。")
        return
    state = session.agent._state.read()
    global_state = state["c1"]["global_evaluation_state"]
    active_node = next(
        (
            node
            for node in state["c1"]["plan_graph"].get("nodes") or ()
            if node.get("status") == "active"
        ),
        None,
    )
    print(
        "status> "
        f"task_phase={state['c1']['task_contract_state']['phase']} "
        f"dialogue={state['c1']['dialogue_turn_state']['phase']} "
        f"active_node={active_node['node_id'] if active_node else '-'} "
        f"global_terminal={bool(global_state and global_state['terminal'])} "
        f"pending_human={session.agent.pending_human_interaction() is not None}"
    )


def _print_details(runtime: _ChatRuntime) -> None:
    session = runtime.session
    if session is None:
        details = {
            "phase": "pre_task",
            "formal_task_started": False,
            "source_root": str(runtime.arguments.source_root.resolve()),
        }
        print(json.dumps(details, ensure_ascii=False, indent=2))
        return
    if not session.agent._state.path.exists():
        print("details> 尚未建立狀態。")
        return
    state = session.agent._state.read()
    details = {
        "task_contract": state["c1"]["task_contract_state"],
        "global_evaluation": state["c1"]["global_evaluation_state"],
        "frame_evaluation": state["c1"]["frame_evaluation_state"],
        "current_issue": state["c1"]["current_issue"],
        "pending_human": session.agent.pending_human_interaction(),
    }
    print(json.dumps(details, ensure_ascii=False, indent=2))


def _print_artifacts(runtime: _ChatRuntime) -> None:
    session = runtime.session
    if session is None:
        print("artifacts> 正式任務尚未建立；目前只有對話與前置觀察。")
        return
    artifacts = session.workflow.artifacts.list()
    if not artifacts:
        print("artifacts> 尚無正式成果。")
        return
    for item in artifacts:
        print(
            f"{item['artifact_ref']} | {item['artifact_kind']} | "
            f"{item['status']} | {item.get('summary', '')}"
        )


def _print_graph(runtime: _ChatRuntime) -> None:
    session = runtime.session
    if session is None:
        print("graph> 正式任務尚未建立，因此沒有研究圖。")
        return
    if not session.agent._state.path.exists():
        print("graph> 尚未建立研究圖。")
        return
    summary = str(session.agent._state.read()["c1"]["plan_summary"]).strip()
    print(summary or "graph> 尚未建立研究圖。")


def _source_spec(arguments: argparse.Namespace) -> SourceSpec | None:
    root = arguments.source_root.resolve()
    goal_relative = str(arguments.goal_relative_path or "").strip()
    historical_relative = str(arguments.historical_relative_path or "").strip()
    goal_hash = str(arguments.goal_sha256 or "").strip().lower()
    historical_hash = str(arguments.historical_sha256 or "").strip().lower()
    raw_count = arguments.expected_record_count
    configured_values = (
        goal_relative,
        historical_relative,
        goal_hash,
        historical_hash,
        raw_count,
    )
    if not any(value not in (None, "") for value in configured_values):
        return None
    if not goal_relative or not historical_relative or raw_count is None:
        raise ValueError(
            "configured_source_requires_goal_historical_and_record_count"
        )
    goal_path = (root / goal_relative).resolve()
    historical_path = (root / historical_relative).resolve()
    if not goal_hash:
        goal_hash = _sha256(goal_path)
    if not historical_hash:
        historical_hash = _sha256(historical_path)
    count = int(raw_count)
    if count < 1:
        raise ValueError("expected_record_count_must_be_positive_integer")
    return SourceSpec(
        source_root=root,
        goal_relative_path=goal_relative,
        historical_relative_path=historical_relative,
        goal_sha256=goal_hash,
        historical_sha256=historical_hash,
        expected_record_count=count,
    )


def _sha256(path: Path) -> str:
    if not path.is_file():
        raise FileNotFoundError(f"source_file_missing:{path}")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _llm_config(path: Path) -> dict[str, str]:
    parser = configparser.ConfigParser()
    if not parser.read(path, encoding="utf-8"):
        raise FileNotFoundError(f"llm_config_missing:{path}")
    if not parser.has_section("LLM"):
        raise ValueError(f"llm_config_section_missing:{path}:LLM")
    section = parser["LLM"]
    required = ("model_name", "api_base", "api_key", "timeout", "max_tokens")
    missing = [key for key in required if not section.get(key, "").strip()]
    if missing:
        raise ValueError(f"llm_config_keys_missing:{missing}")
    return {
        "model_name": section["model_name"].strip(),
        "api_base": section["api_base"].strip(),
        "api_key": section["api_key"].strip(),
        "timeout": section["timeout"].strip(),
        "max_tokens": section["max_tokens"].strip(),
        "temperature": section.get("temperature", "0.0").strip(),
        "reasoning_effort": section.get("reasoning_effort", "").strip(),
        "scientific_reasoning_effort": section.get(
            "scientific_reasoning_effort", ""
        ).strip(),
        "repair_reasoning_effort": section.get(
            "repair_reasoning_effort", ""
        ).strip(),
        "planning_reasoning_effort": section.get(
            "planning_reasoning_effort", ""
        ).strip(),
    }


def _capability_executor(
    arguments: argparse.Namespace,
) -> DockerPythonExecutor | DockerRouteExecutorPool:
    cache_root = (
        arguments.capability_docker_cache_root.resolve()
        if arguments.capability_docker_cache_root is not None
        else PROJECT_ROOT / "managed_capabilities" / ".runtime" / "docker-cache"
    )
    base_digest, base_reference = _default_docker_runtime_identity(arguments)
    default = DockerPythonExecutor(
        cache_root=cache_root,
        base_image_repository=arguments.capability_docker_base_image,
        base_image_digest=base_digest,
        base_image_reference=base_reference,
    )
    additional = [
        _executor_from_exact_reference(value, cache_root=cache_root)
        for value in arguments.capability_docker_additional_runtime
    ]
    if not additional:
        return default
    return DockerRouteExecutorPool(default, additional)


def _default_docker_runtime_identity(
    arguments: argparse.Namespace,
) -> tuple[str, str | None]:
    digest = str(arguments.capability_docker_base_image_digest or "").strip()
    reference = str(arguments.capability_docker_base_image_reference or "").strip()
    if digest:
        return digest, reference or None
    if reference:
        if re.fullmatch(r"sha256:[0-9a-fA-F]{64}", reference):
            return reference.lower(), reference.lower()
        _repository, separator, candidate_digest = reference.rpartition("@")
        if separator and re.fullmatch(
            r"sha256:[0-9a-fA-F]{64}", candidate_digest
        ):
            return candidate_digest.lower(), reference
        raise ValueError("capability_docker_base_image_reference_not_exact")
    if arguments.capability_docker_base_image != DEFAULT_DOCKER_IMAGE:
        raise ValueError("custom_docker_base_image_digest_required")
    image_id = resolve_local_docker_image_id(DEFAULT_DOCKER_LOCAL_TAG)
    return image_id, image_id


def _executor_from_exact_reference(
    value: str,
    *,
    cache_root: Path,
) -> DockerPythonExecutor:
    reference = str(value).strip()
    if re.fullmatch(r"sha256:[0-9a-fA-F]{64}", reference):
        digest = reference.lower()
        repository = "local-image"
        exact_reference = digest
    else:
        repository, separator, digest = reference.rpartition("@")
        digest = digest.lower()
        if (
            not separator
            or not repository
            or re.fullmatch(r"sha256:[0-9a-f]{64}", digest) is None
        ):
            raise ValueError(
                f"capability_docker_runtime_reference_invalid:{reference}"
            )
        exact_reference = f"{repository}@{digest}"
    return DockerPythonExecutor(
        cache_root=cache_root,
        base_image_repository=repository,
        base_image_digest=digest,
        base_image_reference=exact_reference,
    )


def _print_model_status(event: Mapping[str, Any]) -> None:
    kind = str(event.get("event") or "status")
    if kind == "delta":
        return
    purpose = str(event.get("purpose") or "")
    details = " ".join(
        f"{key}={value}"
        for key, value in event.items()
        if key not in {"event", "purpose", "body"}
    )
    print(f"[llm:{kind}] purpose={purpose} {details}".rstrip(), flush=True)
