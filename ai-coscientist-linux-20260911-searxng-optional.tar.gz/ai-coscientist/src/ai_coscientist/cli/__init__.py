"""Interactive command-line hosts for the scientific common agent."""
