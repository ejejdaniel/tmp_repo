from __future__ import annotations

import argparse

from . import scientific_chat


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="python -m ai_coscientist.cli",
        description="Interactive hosts for the AI co-scientist.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    chat = subparsers.add_parser(
        "chat",
        help="Open one persistent multi-turn scientific research chat.",
    )
    scientific_chat.configure_arguments(chat)
    arguments = parser.parse_args()
    if arguments.command == "chat":
        return scientific_chat.run_scientific_chat(arguments)
    parser.error(f"unknown command: {arguments.command}")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
