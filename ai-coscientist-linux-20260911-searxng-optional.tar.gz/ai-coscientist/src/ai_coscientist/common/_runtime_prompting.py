from __future__ import annotations

import copy
import json
from typing import Any, Mapping, Sequence

from ._runtime_prompts import (
    ACTIVE_SKILL_PROMPT as _ACTIVE_SKILL_PROMPT,
    BASE_SYSTEM_PROMPT as _BASE_SYSTEM_PROMPT,
    CHILD_MISSION_PROMPT as _CHILD_MISSION_PROMPT,
    HUMAN_IN_LOOP_DISABLED_PROMPT as _HUMAN_IN_LOOP_DISABLED_PROMPT,
    HUMAN_IN_LOOP_ENABLED_PROMPT as _HUMAN_IN_LOOP_ENABLED_PROMPT,
    NODE_EXECUTION_PROMPT as _NODE_EXECUTION_PROMPT,
    SKILL_SELECTION_PROMPT as _SKILL_SELECTION_PROMPT,
)
from ._runtime_support import (
    observation_current_state_identity,
    stored_ref_strings as _stored_ref_strings,
    task_work_skill_cards as _task_work_skill_cards,
)
from .development import DevelopmentProjectError
from .memory_lifecycle.policy import (
    DEFAULT_ARTIFACT_CATALOG_BUDGET_BYTES,
    MINIMAL_ARTIFACT_CATALOG_BUDGET_BYTES,
    PromptSource,
    artifact_catalog_page as _build_artifact_catalog_page,
    artifact_prompt_catalog,
    current_observation_refs,
)
from .memory_lifecycle.prompt import (
    FOCUSED_C4_SOURCE_PREFIX,
    artifact_reference_prompt_projection,
    artifact_prompt_projection,
    bounded_text,
    code_artifact_prompt_projection,
    evaluation_state_prompt_projection,
    fit_resolved_input_projections,
    focused_code_source_prompt,
)
from .memory_lifecycle.project_revisions import current_project_snapshot_refs
from .planning import (
    GRAPH_REVISION_OUTCOME_KIND,
    active_work_unit as _active_work_unit,
    active_work_unit_context_refs as _active_work_unit_context_refs,
)
from .planning.node_loop import next_skill_id


class PromptRuntimeMixin:
    """Prompt assembly and exact stored-result projection."""

    def _active_artifact_index(self) -> list[dict[str, Any]]:
        state = self._state.read()
        receipts = list(
            self._artifacts.active_receipts(
                explicit_refs=state["c1"]["resolved_artifact_refs"],
            )
        )
        return [
            receipt for receipt in receipts
            if receipt.get("artifact_kind") != "agent_evaluation_gate"
        ]

    def _prompt_artifact_catalog(
        self,
        *,
        projection_tier: str = "normal",
    ) -> dict[str, Any]:
        if projection_tier not in {"normal", "minimal"}:
            raise ValueError(
                f"runtime_prompt_projection_tier_invalid:{projection_tier}"
            )
        state = self._state.read()
        return artifact_prompt_catalog(
            self._active_artifact_index(),
            priority_refs=self._prompt_priority_artifact_refs(state),
            budget_bytes=(
                DEFAULT_ARTIFACT_CATALOG_BUDGET_BYTES
                if projection_tier == "normal"
                else MINIMAL_ARTIFACT_CATALOG_BUDGET_BYTES
            ),
        )

    def _prompt_artifact_index(
        self,
        *,
        projection_tier: str = "normal",
    ) -> list[dict[str, Any]]:
        return [
            dict(item)
            for item in self._prompt_artifact_catalog(
                projection_tier=projection_tier
            )["items"]
        ]

    def _artifact_catalog_page(
        self,
        arguments: Mapping[str, Any],
    ) -> dict[str, Any]:
        return _build_artifact_catalog_page(
            self._active_artifact_index(),
            artifact_kind=str(arguments.get("artifact_kind") or ""),
            status=str(arguments.get("status") or ""),
            query=str(arguments.get("query") or ""),
            cursor=int(arguments.get("cursor") or 0),
            limit=int(arguments.get("limit") or 8),
        )

    def _prompt_priority_artifact_refs(
        self,
        state: Mapping[str, Any],
    ) -> tuple[str, ...]:
        c1 = state["c1"]
        refs: list[str] = []

        def add(raw_ref: Any) -> None:
            ref = str(raw_ref or "").strip()
            if ref.startswith("artifact:") and ref not in refs:
                refs.append(ref)

        for ref in c1["resolved_artifact_refs"]:
            add(ref)
        add(c1["task_contract_state"]["task_spec_ref"])
        for ref in _active_work_unit_context_refs(c1["plan_graph"]):
            add(ref)
        for ref in _stored_ref_strings(c1["node_loop_state"]):
            add(ref)
        for evaluation_state in (
            c1["global_evaluation_state"],
            c1["frame_evaluation_state"],
        ):
            if not isinstance(evaluation_state, Mapping):
                continue
            for result in evaluation_state.get("criterion_results") or ():
                if not isinstance(result, Mapping) or result.get("status") == "met":
                    continue
                for ref in result.get("evidence_refs") or ():
                    add(ref)
        for ref in _successful_receipt_refs(c1["recent_bounded_receipts"]):
            add(ref)
        return tuple(refs)

    def _runtime_prompt_sources(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
    ) -> tuple[PromptSource, ...]:
        focused_c4 = ""
        prompt_state_index = -1
        if len(messages) >= 2 and str(messages[-1].get("content", "")).startswith(
            FOCUSED_C4_SOURCE_PREFIX
        ):
            focused_c4 = str(messages[-1]["content"])
            prompt_state_index = -2
        prompt_state = json.loads(str(messages[prompt_state_index]["content"]))
        recent_messages = list(messages[1:prompt_state_index])
        sources = [
            PromptSource("instruction", "common_agent_instruction", messages[0]),
            PromptSource(
                "C0",
                "objective_and_evaluation",
                {
                    "objective": prompt_state.get("objective"),
                    "evaluation_summary": prompt_state.get("evaluation_summary"),
                },
            ),
            PromptSource(
                "C1",
                "active_plan_and_issue",
                {
                    "plan_summary": prompt_state.get("plan_summary"),
                    "task_contract_state": prompt_state.get(
                        "task_contract_state"
                    ),
                    "active_work_unit": prompt_state.get("active_work_unit"),
                    "active_loop_step": prompt_state.get("active_loop_step"),
                    "node_loop_state": prompt_state.get("node_loop_state"),
                    "global_evaluation_state": prompt_state.get(
                        "global_evaluation_state"
                    ),
                    "frame_evaluation_state": prompt_state.get(
                        "frame_evaluation_state"
                    ),
                    "current_issue": prompt_state.get("current_issue"),
                    "work_context": {
                        key: value for key, value in
                        (prompt_state.get("work_context") or {}).items()
                        if key != "summary"
                    },
                    "human_interaction": prompt_state.get("human_interaction"),
                },
            ),
            PromptSource(
                "C2",
                "active_artifact_index",
                prompt_state.get("formal_artifact_index", []),
            ),
            PromptSource(
                "C2",
                "formal_artifact_catalog",
                prompt_state.get("formal_artifact_catalog", {}),
            ),
            PromptSource(
                "C2",
                "resolved_formal_inputs",
                prompt_state.get("resolved_inputs_for_active_skill", []),
            ),
            PromptSource(
                "C3",
                "work_summary",
                (prompt_state.get("work_context") or {}).get("summary", ""),
            ),
            PromptSource(
                "C1",
                "completed_runtime_readbacks",
                prompt_state.get("completed_runtime_readbacks", []),
            ),
            PromptSource("C1", "recent_native_turns", recent_messages),
            PromptSource(
                "instruction",
                "available_or_selected_skill",
                prompt_state.get("active_skill")
                or prompt_state.get("planned_skill")
                or prompt_state.get("skill_menu")
                or [],
            ),
            PromptSource("tool_schema", "available_tools", list(tools)),
        ]
        if self._mission:
            sources.append(
                PromptSource(
                    "C0",
                    "child_mission_packet",
                    prompt_state.get("mission_packet", {}),
                )
            )
        if prompt_state.get("pending_child_artifact_for_review"):
            sources.append(
                PromptSource(
                    "C2",
                    "pending_child_artifact_for_review",
                    prompt_state["pending_child_artifact_for_review"],
                )
            )
        if prompt_state.get("pending_child_results"):
            sources.append(
                PromptSource(
                    "C2",
                    "pending_child_results",
                    prompt_state["pending_child_results"],
                )
            )
        if focused_c4:
            sources.append(PromptSource("C4", "focused_stored_source", focused_c4))
        return tuple(sources)

    def _purpose(self) -> str:
        state = self._state.read()
        active_skill_id = state["c1"]["active_skill_id"]
        if active_skill_id:
            return f"execute selected skill: {active_skill_id}"
        if state["c1"]["node_loop_state"]["awaiting_transition"]:
            return "choose one declared Graph transition"
        if self._pending_child_review_packets():
            return "review one returned child result for the active Graph node"
        active = _active_work_unit(state["c1"]["plan_graph"])
        if active is not None and next_skill_id(
            state["c1"]["node_loop_state"],
            node_id=str(active["node_id"]),
        ):
            return "mechanically load the next skill in the active node LOOP"
        return "choose execution mode for the active Graph node"

    def _selected_skill_disclosure_context(
        self,
        skill_id: str,
        *,
        resolved_artifacts: Sequence[Mapping[str, Any]] | None = None,
        artifact_index: Sequence[Mapping[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Build a transient, trusted context for optional skill disclosure."""
        state = self._state.read()
        if resolved_artifacts is None:
            resolved_artifacts = tuple(
                self._read_exact_ref(artifact_ref)
                for artifact_ref in state["c1"]["resolved_artifact_refs"]
            )
        resolved_by_ref = {
            _stored_ref(item): dict(item)
            for item in resolved_artifacts
            if _stored_ref(item)
        }
        for artifact_ref in _active_work_unit_context_refs(
            state["c1"]["plan_graph"]
        ):
            if artifact_ref in resolved_by_ref:
                continue
            try:
                resolved_by_ref[artifact_ref] = self._read_exact_ref(artifact_ref)
            except (KeyError, OSError, PermissionError, ValueError):
                continue
        for artifact_ref in _successful_receipt_refs(
            state["c1"]["recent_bounded_receipts"]
        ):
            if artifact_ref in resolved_by_ref:
                continue
            try:
                resolved_by_ref[artifact_ref] = self._read_exact_ref(artifact_ref)
            except (KeyError, OSError, PermissionError, ValueError):
                continue
        if artifact_index is None:
            artifact_index = self._active_artifact_index()
        work_context = self._current_work_projection(
            consumer=str(skill_id),
            explicit_refs=tuple(resolved_by_ref),
        )
        if work_context is not None:
            for ref in work_context.get("operational_refs") or ():
                if ref not in resolved_by_ref:
                    resolved_by_ref[ref] = self._read_exact_ref(ref)
            for snapshot_ref in work_context.get("snapshot_refs", ()):
                if snapshot_ref in resolved_by_ref:
                    continue
                try:
                    stored = self._read_exact_ref(snapshot_ref)
                except (KeyError, OSError, PermissionError, ValueError):
                    continue
                if stored.get("artifact_kind") != "development_project_snapshot":
                    continue
                resolved_by_ref[snapshot_ref] = stored
        # Historical executions retain their exact implementation identity even
        # when the selected input is a newer snapshot of that same project.
        for stored in tuple(resolved_by_ref.values()):
            if stored.get("artifact_kind") != "execution_observation":
                continue
            for ref in _stored_ref_strings(stored.get("metadata")):
                if not ref.startswith("artifact:") or ref in resolved_by_ref:
                    continue
                try:
                    resolved_by_ref[ref] = self._read_exact_ref(ref)
                except (KeyError, OSError, PermissionError, ValueError):
                    continue
        observation_refs = self._observations.ordered_refs(tuple(resolved_by_ref))
        current_refs = current_observation_refs(
            observation_refs, read=self._read_exact_ref,
            identity=observation_current_state_identity,
            creation_order=self._observations.ordered_refs,
        )
        resolved_artifacts = (
            *(item for ref, item in resolved_by_ref.items()
              if not ref.startswith("execution_observation:")),
            *(self._read_exact_ref(ref) for ref in current_refs),
        )
        recent_receipts: list[dict[str, Any]] = []
        if work_context is not None:
            raw_handoff_receipts = work_context.get("tool_receipts")
            if isinstance(raw_handoff_receipts, Sequence) and not isinstance(
                raw_handoff_receipts, (str, bytes, bytearray)
            ):
                recent_receipts.extend(
                    copy.deepcopy(dict(receipt))
                    for receipt in raw_handoff_receipts
                    if isinstance(receipt, Mapping)
                )
        recent_receipts.extend(
            copy.deepcopy(dict(receipt))
            for receipt in state["c1"]["recent_bounded_receipts"]
            if isinstance(receipt, Mapping)
        )
        context = {
            "skill_id": str(skill_id),
            "invocation_seed_refs": list(
                self._active_invocation_seed_refs(str(skill_id))
            ),
            "invocation_output_refs": list(
                self._active_invocation_artifact_refs(str(skill_id))
            ),
            "resolved_artifacts": [dict(item) for item in resolved_artifacts],
            "current_project_snapshot_refs": list(current_project_snapshot_refs(
                resolved_artifacts, read_stored=self._artifacts.store.read,
            )),
            "formal_artifact_index": [dict(item) for item in artifact_index],
            "current_issue": state["c1"]["current_issue"],
            "recent_receipts": recent_receipts,
            "pending_readback_ref": self._pending_readback_ref(),
            "latest_read_ref": self._active_invocation_read_ref(str(skill_id)),
        }
        if work_context is not None:
            context["work_context"] = work_context
        return context

    def _render_messages(
        self,
        *,
        projection_tier: str = "normal",
        recent_native_turn_budget_bytes: int | None = None,
    ) -> list[dict[str, Any]]:
        if projection_tier not in {"normal", "minimal"}:
            raise ValueError(
                f"runtime_prompt_projection_tier_invalid:{projection_tier}"
            )
        persisted = self._state.read()
        c0 = persisted["c0"]
        c1 = persisted["c1"]
        c3 = persisted["c3"]
        active_skill_id = c1["active_skill_id"]
        self._work.consumer = str(active_skill_id or "node-execution")
        awaiting_transition = bool(
            c1["node_loop_state"]["awaiting_transition"]
        )
        active_plan_unit = _active_work_unit(c1["plan_graph"])
        active_skill = None
        if active_skill_id:
            active_skill = {"skill_id": active_skill_id}
        active_node_input_refs: tuple[str, ...] = ()
        if not active_skill_id and active_plan_unit is not None:
            active_node_input_refs = self._active_node_input_refs(persisted)
        resolved_artifacts = [
            self._read_exact_ref(artifact_ref)
            for artifact_ref in c1["resolved_artifact_refs"]
        ]
        if not active_skill_id and active_plan_unit is not None:
            allowed_node_inputs = set(active_node_input_refs)
            resolved_artifacts = [
                artifact
                for artifact in resolved_artifacts
                if _stored_ref(artifact) in allowed_node_inputs
            ]
        resolved_by_ref = {
            _stored_ref(artifact): artifact
            for artifact in resolved_artifacts
            if _stored_ref(artifact)
        }
        if not active_skill_id and active_plan_unit is not None:
            for artifact_ref in active_node_input_refs:
                if artifact_ref in resolved_by_ref:
                    continue
                try:
                    stored = self._read_exact_ref(artifact_ref)
                except (KeyError, OSError, PermissionError, ValueError):
                    continue
                resolved_artifacts.append(stored)
                resolved_by_ref[artifact_ref] = stored
        if awaiting_transition:
            transition_evidence_refs = _active_transition_evidence_refs(
                active_plan_unit
            )
            for artifact_ref in transition_evidence_refs:
                if artifact_ref in resolved_by_ref:
                    continue
                try:
                    stored = self._read_exact_ref(artifact_ref)
                except (KeyError, OSError, PermissionError, ValueError):
                    continue
                resolved_artifacts.append(stored)
                resolved_by_ref[artifact_ref] = stored
        else:
            transition_evidence_refs = ()
        artifact_catalog = self._prompt_artifact_catalog(
            projection_tier=projection_tier
        )
        artifact_index = [dict(item) for item in artifact_catalog["items"]]
        if not active_skill_id and active_plan_unit is not None:
            artifact_index = [
                receipt
                for receipt in artifact_index
                if receipt.get("artifact_kind")
                != GRAPH_REVISION_OUTCOME_KIND
            ]
        if active_skill_id:
            disclosure_context = self._selected_skill_disclosure_context(
                active_skill_id,
                resolved_artifacts=resolved_artifacts,
                artifact_index=artifact_index,
            )
            active_skill["detail"] = self._skills.render_detail(
                active_skill_id,
                disclosure_context,
            )
            visible_refs = self._skills.disclosure_visible_refs(
                active_skill_id,
                disclosure_context,
            )
            resolved_artifacts = [
                dict(artifact)
                for artifact in disclosure_context["resolved_artifacts"]
            ]
            if visible_refs is not None:
                visible = set(visible_refs)
                resolved_artifacts = [
                    artifact
                    for artifact in disclosure_context["resolved_artifacts"]
                    if _stored_ref(artifact) in visible
                ]
                artifact_index = [
                    receipt
                    for receipt in artifact_index
                    if str(receipt.get("artifact_ref") or "") in visible
                ]
        node_read_refs = (
            self._memory.formal_read_refs() if not active_skill_id else ()
        )
        focused_artifact_ref = (
            self._active_invocation_read_ref(active_skill_id)
            if active_skill_id
            else next(iter(node_read_refs), "")
        )
        if focused_artifact_ref and not any(
            _stored_ref(artifact) == focused_artifact_ref
            for artifact in resolved_artifacts
        ):
            focused_artifact_ref = ""
        if focused_artifact_ref:
            read_order = {ref: index for index, ref in enumerate(node_read_refs)}
            resolved_artifacts.sort(
                key=lambda artifact: (
                    _stored_ref(artifact) != focused_artifact_ref,
                    read_order.get(_stored_ref(artifact), len(read_order)),
                )
            )
        focused_code_prompt = ""
        if focused_artifact_ref:
            focused_stored = next(
                (
                    artifact
                    for artifact in resolved_artifacts
                    if str(
                        artifact.get("artifact_ref")
                        or artifact.get("code_artifact_ref")
                        or ""
                    )
                    == focused_artifact_ref
                ),
                None,
            )
            if focused_stored is not None:
                focused_code_prompt = focused_code_source_prompt(focused_stored)
        if active_skill_id or awaiting_transition or focused_artifact_ref:
            detailed_resolved_inputs = [
                dict(
                    self._exact_ref_prompt_projection(
                        artifact,
                        include_markdown=(
                            artifact.get("artifact_kind")
                            == "human_interaction_response"
                            or _stored_ref(artifact) in node_read_refs
                            or (
                                str(
                                    artifact.get("artifact_ref")
                                    or artifact.get("code_artifact_ref")
                                    or ""
                                )
                                == focused_artifact_ref
                                and artifact.get("artifact_kind")
                                != "code_artifact"
                            )
                        ),
                        include_machine_payload=True,
                    )
                )
                if (
                    active_skill_id
                    or awaiting_transition
                    or _stored_ref(artifact) == focused_artifact_ref
                    or _stored_ref(artifact) in node_read_refs
                    or artifact.get("artifact_kind") == "human_interaction_response"
                )
                else dict(artifact_reference_prompt_projection(artifact))
                for artifact in resolved_artifacts
            ]
            mandatory_detail_refs = [
                _stored_ref(artifact)
                for artifact in resolved_artifacts
                if (
                    _stored_ref(artifact) == focused_artifact_ref
                    or artifact.get("artifact_kind")
                    == "human_interaction_response"
                    or _stored_ref(artifact) in transition_evidence_refs
                )
            ]
            resolved_inputs = fit_resolved_input_projections(
                stored_artifacts=resolved_artifacts,
                detailed_projections=detailed_resolved_inputs,
                mandatory_detail_refs=mandatory_detail_refs,
                detail_budget_bytes=(
                    48_000 if projection_tier == "normal" else 20_000
                ),
            )
        else:
            resolved_inputs = [
                (
                    dict(
                        self._exact_ref_prompt_projection(
                            artifact,
                            include_markdown=True,
                            include_machine_payload=True,
                        )
                    )
                    if artifact.get("artifact_kind")
                    == "human_interaction_response"
                    else dict(artifact_reference_prompt_projection(artifact))
                )
                for artifact in resolved_artifacts
            ]
        if not active_skill_id and active_plan_unit is not None:
            resolved_input_refs = {
                str(item.get("artifact_ref") or "").strip()
                for item in resolved_inputs
                if str(item.get("artifact_ref") or "").strip()
            }
            artifact_index = [
                receipt
                for receipt in artifact_index
                if str(receipt.get("artifact_ref") or "").strip()
                not in resolved_input_refs
            ]
        if focused_code_prompt:
            for projection in resolved_inputs:
                if projection.get("artifact_ref") == focused_artifact_ref:
                    projection["code"] = (
                        "[exact stored source rendered in the focused C4 message]"
                    )
                    break
        review_only_projection: dict[str, Any] | None = None
        if self._review_only_artifact is not None:
            review_only_projection = dict(
                self._exact_ref_prompt_projection(
                    self._review_only_artifact,
                    include_markdown=True,
                    include_machine_payload=True,
                )
            )
            review_only_projection["review_only"] = True
            review_only_projection["not_formal_parent_input"] = True
        loop_state = dict(c1["node_loop_state"])
        loop_steps = list(loop_state.get("steps") or [])
        loop_index = int(loop_state.get("next_step_index") or 0)
        active_loop_step = (
            dict(loop_steps[loop_index])
            if 0 <= loop_index < len(loop_steps)
            and (
                not active_skill_id
                or str(loop_steps[loop_index].get("skill_id") or "")
                == active_skill_id
            )
            else None
        )
        pending_child_results = self._pending_child_review_packets()
        next_node_attempt_index: int | None = None
        work_context = self._current_work_projection(
            consumer=str(active_skill_id or "node-execution"),
        )
        if not active_skill_id and not pending_child_results and active_plan_unit is not None and not awaiting_transition:
            next_node_attempt_index = self._next_node_execution_attempt_index()
        global_evaluation_projection = evaluation_state_prompt_projection(
            c1["global_evaluation_state"]
        )
        frame_evaluation_projection = evaluation_state_prompt_projection(
            c1["frame_evaluation_state"]
        )
        current_issue_projection = bounded_text(
            str(c1["current_issue"] or ""),
            4_000,
        )
        current_work_state: dict[str, Any] = {
            "evaluation_summary": c0["evaluation_summary"],
            "task_contract_state": copy.deepcopy(
                c1["task_contract_state"]
            ),
            "global_evaluation_state": global_evaluation_projection,
            "frame_evaluation_state": frame_evaluation_projection,
            "active_work_unit": dict(active_plan_unit) if active_plan_unit else None,
            "node_loop_state": loop_state,
            "formal_artifact_index": artifact_index,
            "formal_artifact_catalog": {
                key: value
                for key, value in artifact_catalog.items()
                if key != "items"
            },
            "current_issue": current_issue_projection,
        }
        if active_skill_id:
            prompt_state: dict[str, Any] = {
                "objective": c0["objective"],
                "evaluation_summary": c0["evaluation_summary"],
                "active_work_unit": (
                    _active_skill_work_unit_projection(active_plan_unit)
                    if active_plan_unit
                    else None
                ),
                "active_loop_step": active_loop_step,
                "task_contract_state": copy.deepcopy(
                    c1["task_contract_state"]
                ),
                "global_evaluation_state": global_evaluation_projection,
                "frame_evaluation_state": frame_evaluation_projection,
                "current_issue": current_issue_projection,
                "active_skill": active_skill,
                "resolved_inputs_for_active_skill": resolved_inputs,
            }
            system_prompt = _BASE_SYSTEM_PROMPT + "\n\n" + _ACTIVE_SKILL_PROMPT
        elif awaiting_transition:
            prompt_state = {
                "active_work_unit": (
                    dict(active_plan_unit) if active_plan_unit else None
                ),
                "current_issue": current_issue_projection,
                "resolved_inputs_for_active_skill": resolved_inputs,
            }
            system_prompt = _BASE_SYSTEM_PROMPT + "\n\n" + _SKILL_SELECTION_PROMPT
        elif active_loop_step is not None:
            raise RuntimeError(
                "planned_loop_step_must_be_loaded_mechanically_before_prompt"
            )
        else:
            node_input_refs = list(active_node_input_refs)
            prompt_state = {
                "objective": c0["objective"],
                **current_work_state,
                "resolved_inputs_for_active_skill": resolved_inputs,
                "allowed_mission_artifact_refs": node_input_refs,
                "node_execution_boundary": {
                    "next_attempt_index": (
                        None
                        if pending_child_results
                        else next_node_attempt_index
                    ),
                    "current_attempt_index": (
                        int(loop_state["attempt_index"])
                        if pending_child_results
                        else None
                    ),
                    "available_modes": (
                        ["review_child_result"]
                        if pending_child_results
                        else [
                            "local",
                            *(
                                ["child"]
                                if self._child_depth < self._max_child_depth
                                else []
                            ),
                        ]
                    ),
                },
                "skill_menu": [
                    {
                        "skill_id": card.skill_id,
                        "description": card.description,
                        "estimated_complexity": card.estimated_complexity,
                        "detail_available": True,
                    }
                    for card in _task_work_skill_cards(
                        self._skills,
                        getattr(self, "_task_formulation_skill_id", ""),
                    )
                ],
            }
            system_prompt = _BASE_SYSTEM_PROMPT + "\n\n" + _NODE_EXECUTION_PROMPT
        if work_context is not None:
            # Its covered turns no longer appear in recent history. Omitting
            # this summary would remove both representations of the work.
            prompt_state["work_context"] = work_context
        if not active_skill_id:
            prompt_state["available_work_contexts"] = self._work.list(limit=8)
        if review_only_projection is not None:
            prompt_state["pending_child_artifact_for_review"] = review_only_projection
        if pending_child_results:
            prompt_state["pending_child_results"] = pending_child_results
        if self._mission:
            mission_projection = self._mission_prompt_projection()
            if active_skill_id:
                prompt_state["mission_packet"] = {
                    key: mission_projection[key]
                    for key in ("mission_context", "mounted_refs", "workspace")
                }
            else:
                prompt_state["mission_packet"] = mission_projection
        if self._mission and not active_skill_id and not awaiting_transition:
            system_prompt += "\n\n" + _CHILD_MISSION_PROMPT
        if self._role_instructions and active_skill_id:
            system_prompt += (
                "\n\nAgent-local role instructions:\n" + self._role_instructions
            )
        system_prompt += "\n\n" + (
            _HUMAN_IN_LOOP_ENABLED_PROMPT
            if self._human_in_loop_enabled
            else _HUMAN_IN_LOOP_DISABLED_PROMPT
        )
        human_interaction = self._human_interaction_prompt_projection()
        if human_interaction is not None:
            prompt_state["human_interaction"] = human_interaction
        completed_runtime_readbacks = self._completed_runtime_readbacks()
        if completed_runtime_readbacks:
            prompt_state["completed_runtime_readbacks"] = (
                completed_runtime_readbacks
            )
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": system_prompt}
        ]
        messages.append(
            {
                "role": "user",
                "content": json.dumps(prompt_state, ensure_ascii=False, indent=2),
            }
        )
        if focused_code_prompt:
            messages.append({"role": "user", "content": focused_code_prompt})
        if recent_native_turn_budget_bytes is None:
            recent_native_turn_budget_bytes = self._memory.remaining_history_budget(
                messages=messages,
                tools=self._tool_specs(
                    projection_tier=projection_tier, prompt_messages=messages,
                ),
                budget_tier=(
                    "full" if active_skill_id or loop_state["node_id"] else "compact"
                ),
            )
        messages[1:1] = [
            dict(message) for message in self._memory.recent_messages(
                max_bytes=recent_native_turn_budget_bytes,
            )
        ]
        return messages

    def _completed_runtime_readbacks(self) -> list[dict[str, Any]]:
        """Project bounded automatic-read receipts persisted in C1."""
        receipts: list[dict[str, Any]] = []
        state_receipts = self._state.read()["c1"]["recent_bounded_receipts"]
        for receipt in state_receipts:
            call_id = str(receipt.get("call_id") or "")
            if not call_id.startswith("runtime-readback-"):
                continue
            result = receipt.get("result")
            if not isinstance(result, Mapping):
                continue
            receipts.append(
                {
                    "call_id": call_id,
                    "tool": str(receipt.get("tool") or ""),
                    "status": str(result.get("status") or "completed"),
                    "ref": str(
                        result.get("artifact_ref")
                        or result.get("code_artifact_ref")
                        or result.get("observation_ref")
                        or result.get("source_ref")
                        or ""
                    ),
                }
            )
        return receipts[-8:]

    @staticmethod
    def _exact_ref_prompt_projection(
        stored: Mapping[str, Any],
        *,
        include_markdown: bool = True,
        include_machine_payload: bool = True,
    ) -> Mapping[str, Any]:
        if stored.get("artifact_kind") == "code_artifact":
            return code_artifact_prompt_projection(
                stored,
                include_code=include_markdown,
            )
        if stored.get("artifact_kind") == "execution_observation":
            inspected = bool(stored.get("_inspected"))
            metadata_refs = _stored_ref_strings(stored.get("metadata"))
            return artifact_prompt_projection(
                {
                    "artifact_ref": stored.get("observation_ref"),
                    "artifact_kind": "execution_observation",
                    "status": (
                        "execution_observation_inspected"
                        if inspected
                        else stored.get("status")
                    ),
                    "title": (
                        f"{stored.get('namespace', 'runtime')} execution observation"
                    ),
                    "summary": (
                        "Inspected stored execution result."
                        if inspected
                        else "Stored execution result awaiting inspection."
                    ),
                    "depends_on": list(metadata_refs),
                    "markdown": (
                        "The complete execution body remains in the observation "
                        "store under this exact ref."
                    ),
                    "machine_payload": (
                        stored.get("result", {}) if inspected else {}
                    ),
                },
                include_markdown=include_markdown,
                include_machine_payload=include_machine_payload,
            )

        return artifact_prompt_projection(
            stored,
            include_markdown=include_markdown,
            include_machine_payload=include_machine_payload,
        )


def _successful_receipt_refs(
    receipts: Sequence[Mapping[str, Any]],
) -> tuple[str, ...]:
    refs: list[str] = []
    for receipt in receipts:
        result = receipt.get("result")
        if not isinstance(result, Mapping) or result.get("status") == "tool_error":
            continue
        for key in (
            "artifact_ref",
            "code_artifact_ref",
            "snapshot_ref",
            "observation_ref",
        ):
            ref = str(result.get(key) or "")
            if ref and ref not in refs:
                refs.append(ref)
    return tuple(refs)


def _active_skill_work_unit_projection(
    active: Mapping[str, Any],
) -> dict[str, Any]:
    """Expose the current node contract without future Graph structure."""
    return {
        "node_id": str(active.get("node_id") or ""),
        "outcome": str(active.get("outcome") or ""),
        "completion_condition": str(active.get("completion_condition") or ""),
    }


def _active_transition_evidence_refs(
    active: Mapping[str, Any] | None,
) -> tuple[str, ...]:
    """Return accepted refs that the main agent must classify against edges."""
    if not isinstance(active, Mapping) or not active.get("transitions"):
        return ()
    refs = active.get("completion_refs")
    if not isinstance(refs, Sequence) or isinstance(refs, (str, bytes)):
        return ()
    return tuple(
        dict.fromkeys(str(ref).strip() for ref in refs if str(ref).strip())
    )


def _stored_ref(stored: Mapping[str, Any]) -> str:
    return str(
        stored.get("artifact_ref")
        or stored.get("code_artifact_ref")
        or stored.get("observation_ref")
        or ""
    )
