from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence


class ObservationStore:
    """Immutable execution results that require inspection before publication."""

    def __init__(self, root: Path) -> None:
        self._root = root.resolve()
        self._observation_dir = self._root / "observations"
        self._index_path = self._root / "observation-index.json"
        self._observation_dir.mkdir(parents=True, exist_ok=True)
        if not self._index_path.exists():
            self._write_json(
                self._index_path,
                {"order": [], "entries": {}, "inspected": []},
            )

    def publish(
        self,
        *,
        namespace: str,
        result: Mapping[str, Any],
        status: str = "code_artifact_executed",
        metadata: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        canonical = {
            "status": status,
            "artifact_kind": "execution_observation",
            "namespace": namespace,
            "result": dict(result),
            "metadata": dict(metadata or {}),
        }
        digest = hashlib.sha256(
            json.dumps(canonical, ensure_ascii=False, sort_keys=True).encode(
                "utf-8"
            )
        ).hexdigest()[:16]
        observation_ref = (
            f"execution_observation:{_slug(namespace)}:{digest}"
        )
        index = self._read_index()
        if observation_ref not in index["entries"]:
            observation = {
                "observation_ref": observation_ref,
                **canonical,
            }
            path = self._observation_dir / f"{digest}.json"
            self._write_json(path, observation)
            index["order"].append(observation_ref)
            index["entries"][observation_ref] = {
                "observation_ref": observation_ref,
                "artifact_kind": "execution_observation",
                "status": status,
                "storage_path": str(path),
            }
            self._write_json(self._index_path, index)
        return _public_receipt(index["entries"][observation_ref])

    def publish_with_ref(
        self,
        *,
        namespace: str,
        result_factory: Callable[[str], Mapping[str, Any]],
        status: str = "code_artifact_executed",
        metadata: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Build and immutably store a result that must cite its own ref."""
        index = self._read_index()
        sequence = len(index["order"]) + 1
        observation_ref = (
            f"execution_observation:{_slug(namespace)}:{sequence:06d}"
        )
        while observation_ref in index["entries"]:
            sequence += 1
            observation_ref = (
                f"execution_observation:{_slug(namespace)}:{sequence:06d}"
            )
        result = result_factory(observation_ref)
        if not isinstance(result, Mapping):
            raise TypeError("observation_result_factory_must_return_mapping")
        observation = {
            "observation_ref": observation_ref,
            "status": status,
            "artifact_kind": "execution_observation",
            "namespace": namespace,
            "result": dict(result),
            "metadata": dict(metadata or {}),
        }
        path = self._observation_dir / (
            f"{_slug(namespace)}-{sequence:06d}.json"
        )
        self._write_json(path, observation)
        index["order"].append(observation_ref)
        index["entries"][observation_ref] = {
            "observation_ref": observation_ref,
            "artifact_kind": "execution_observation",
            "status": status,
            "storage_path": str(path),
        }
        self._write_json(self._index_path, index)
        return _public_receipt(index["entries"][observation_ref])
    def read(self, observation_ref: str) -> dict[str, Any]:
        entry = self._read_index()["entries"].get(observation_ref)
        if entry is None:
            raise KeyError(
                f"execution_observation_ref_not_found:{observation_ref}"
            )
        path = Path(entry["storage_path"]).resolve()
        if not path.is_relative_to(self._observation_dir):
            raise ValueError(
                f"observation_path_outside_store:{observation_ref}"
            )
        return json.loads(path.read_text(encoding="utf-8"))

    def ordered_refs(self, refs: Sequence[str] | None = None) -> tuple[str, ...]:
        """Return stored creation order, never the order in which refs were read."""
        order = self._read_index()["order"]
        selected = set(refs) if refs is not None else None
        return tuple(ref for ref in order if selected is None or ref in selected)

    def is_inspected(self, observation_ref: str) -> bool:
        index = self._read_index()
        if observation_ref not in index["entries"]:
            raise KeyError(
                f"execution_observation_ref_not_found:{observation_ref}"
            )
        return observation_ref in index["inspected"]

    def inspect(
        self, observation_ref: str, *, selected_paths: Sequence[str] = (),
        extra_sources: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        observation = self.read(observation_ref)
        sources = {"result": observation["result"], "metadata": observation["metadata"]}
        for root, value in (extra_sources or {}).items():
            if root in observation:
                raise ValueError(f"observation_inspection_source_collision:{root}")
            sources[root] = value
        selected: dict[str, Any] = {}
        for raw_path in selected_paths:
            path = raw_path.strip()
            if not path:
                continue
            if path.split(".", 1)[0] not in sources:
                raise ValueError(
                    f"observation_selected_path_root_invalid:{path}"
                )
            selected[path] = _resolve_path(sources, path)
        index = self._read_index()
        if observation_ref not in index["inspected"]:
            index["inspected"].append(observation_ref)
            self._write_json(self._index_path, index)
        return {
            "status": "execution_observation_inspected",
            "observation_ref": observation_ref,
            "selected_paths": selected,
            "observation": observation,
        }

    def result_for_artifact(self, observation_ref: str) -> dict[str, Any]:
        index = self._read_index()
        if observation_ref not in index["inspected"]:
            raise ValueError(
                f"execution_observation_inspection_required:{observation_ref}"
            )
        observation = self.read(observation_ref)
        result = observation.get("result")
        if observation.get("status") != "code_artifact_executed":
            raise ValueError(
                f"execution_observation_not_publishable:{observation_ref}"
            )
        if not isinstance(result, Mapping):
            raise ValueError(
                f"execution_observation_result_not_object:{observation_ref}"
            )
        return dict(result)

    def _read_index(self) -> dict[str, Any]:
        return json.loads(self._index_path.read_text(encoding="utf-8"))

    @staticmethod
    def _write_json(path: Path, value: Mapping[str, Any]) -> None:
        temporary = path.with_suffix(f"{path.suffix}.tmp")
        temporary.write_text(
            json.dumps(value, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, path)


def _public_receipt(entry: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "observation_ref": entry["observation_ref"],
        "artifact_kind": entry["artifact_kind"],
        "status": entry["status"],
    }

def _resolve_path(value: Mapping[str, Any], dot_path: str) -> Any:
    current: Any = value
    for segment in dot_path.split("."):
        if not isinstance(current, Mapping) or segment not in current:
            return None
        current = current[segment]
    return current


def _slug(value: str) -> str:
    normalized = re.sub(
        r"[^a-zA-Z0-9._-]+", "-", value.strip()
    ).strip("-")
    return normalized or "observation"
