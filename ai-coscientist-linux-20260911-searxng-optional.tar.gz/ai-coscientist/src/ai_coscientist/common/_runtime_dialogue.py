from __future__ import annotations

import json
import uuid
from typing import Any, Mapping, Sequence

from ._runtime_support import exact_string_refs, function_tool
from .capabilities import parse_task_authorization
from .dialogue import (
    DialogueTurnResult,
    publish_human_conversation_input,
    validate_human_conversation_input,
)
from .memory_lifecycle.policy import PromptSource
from .memory_lifecycle.dialogue_memory import RECENT_DIALOGUE_BUDGET_BYTES
from .memory_lifecycle.prompt import bounded_projection, bounded_text
from .model import complete_model_turn


_MAX_DIALOGUE_READS = 3
_CONTRACT_CHANGE_CONFIRMATIONS = frozenset({"confirm", "確認變更"})
_CONTRACT_CHANGE_REJECTIONS = frozenset({"reject", "拒絕變更"})
_CONTRACT_CHANGE_RESPONSE_INSTRUCTION = (
    "請精確回覆 `確認變更`（confirm）或 `拒絕變更`（reject）。"
)

_INTAKE_INSTRUCTION = """\
You are the same main agent that owns the scientific Graph, not a child and not
a separate chat assistant. At this boundary, decide what the user's latest
message means before research execution resumes.

Choose exactly one high-level action:
- reply_to_user: answer from the supplied conversation and accepted evidence.
- ask_user_clarification: ask one question only when no responsible action is
  possible without the missing answer.
- promote_user_input: turn this exact user message into a formal C2 input, then
  let the existing Graph/Node/LOOP runtime research it. Classify it as feedback,
  scientific_input, or task_contract_change. A task_contract_change alters the
  objective, success criteria, or stop criteria and requires confirmation.
- resume_research: continue the already defined task without changing it.
- read_dialogue_evidence: inspect one exact visible ref before deciding.

Do not execute scientific work in this intake call. Do not claim that research
was performed unless accepted evidence is supplied. Match the user's language.
Use exactly one tool call.
"""

_REPORT_INSTRUCTION = """\
You are the same main agent returning from a scientific research boundary.
Answer the user's initiating message in plain language. State what the run
actually proved, what remains unproved, and the current research status. Cite
only exact evidence refs supplied here or read through read_dialogue_evidence.
When the run produced user-facing files, return their exact available paths or
links alongside the result and limitations; internal artifact identifiers alone
are not file delivery. Do not invent a path or claim a file was produced without
a successful delivery receipt. Read available evidence when needed to locate it.
Do not turn internal run chronology into a long report. Match the user's
language and use exactly one tool call.
"""

class DialogueRuntimeMixin:
    """Run-scoped multi-turn chat owned by the parent main agent."""

    def dialogue_messages(self) -> tuple[dict[str, Any], ...]:
        return self._dialogue.read()

    def chat_turn(
        self,
        *,
        user_text: str,
        objective: str,
        evaluation_summary: str,
        attachment_refs: Sequence[str] = (),
    ) -> DialogueTurnResult:
        if self._mission is not None:
            raise RuntimeError("child_agent_dialogue_forbidden")
        normalized_text = str(user_text).strip()
        if not normalized_text:
            raise ValueError("dialogue_user_text_required")
        normalized_objective = self._prepare_dialogue_identity(
            objective=objective,
            evaluation_summary=evaluation_summary,
        )
        self._recover_interrupted_dialogue_completion()
        state = self._state.read()["c1"]["dialogue_turn_state"]
        if state["phase"] != "idle":
            raise RuntimeError(
                "dialogue_turn_already_active:" + str(state["turn_id"])
            )
        attachments = self._validate_dialogue_attachment_refs(
            attachment_refs
        )
        turn_id = f"turn-{uuid.uuid4().hex}"
        message_id = f"msg-{uuid.uuid4().hex}"
        self._dialogue.append_message(
            message_id=message_id,
            turn_id=turn_id,
            role="user",
            content=normalized_text,
            attachment_refs=attachments,
        )
        self._state.set_dialogue_turn_state(
            {
                "phase": "intake",
                "turn_id": turn_id,
                "user_message_id": message_id,
            }
        )
        self._events.append(
            "dialogue_turn_started",
            {
                "turn_id": turn_id,
                "user_message_id": message_id,
                "attachment_refs": list(attachments),
            },
        )
        return self._continue_dialogue_turn(
            objective=normalized_objective,
            evaluation_summary=evaluation_summary,
        )

    def begin_task_from_dialogue_message(
        self,
        *,
        user_message_id: str,
        objective: str,
        evaluation_summary: str,
        supporting_refs: Sequence[str] = (),
        context_message_ids: Sequence[str] = (),
    ) -> DialogueTurnResult:
        """Enter formal bootstrap after the host-owned pre-task LOOP."""
        if self._mission is not None:
            raise RuntimeError("child_agent_dialogue_forbidden")
        user_message = self._dialogue.get(str(user_message_id))
        if user_message["role"] != "user":
            raise ValueError("dialogue_task_start_requires_user_message")
        transcript = self._dialogue.read()
        message_positions = {
            str(message["message_id"]): index
            for index, message in enumerate(transcript)
        }
        latest_position = message_positions[str(user_message["message_id"])]
        selected_messages: list[dict[str, Any]] = []
        seen_message_ids = {str(user_message["message_id"])}
        for raw_message_id in context_message_ids:
            message_id = str(raw_message_id).strip()
            if not message_id:
                raise ValueError("dialogue_launch_context_message_id_required")
            if message_id in seen_message_ids:
                raise ValueError(
                    "dialogue_launch_context_message_id_duplicated:"
                    f"{message_id}"
                )
            if message_id not in message_positions:
                raise KeyError(f"dialogue_message_unknown:{message_id}")
            if message_positions[message_id] >= latest_position:
                raise ValueError(
                    "dialogue_launch_context_message_must_precede_latest:"
                    f"{message_id}"
                )
            selected_messages.append(self._dialogue.get(message_id))
            seen_message_ids.add(message_id)
        refs = tuple(
            dict.fromkeys(
                str(ref).strip()
                for ref in supporting_refs
                if str(ref).strip()
            )
        )
        for ref in refs:
            self._read_exact_ref(ref)
        normalized_objective = self._prepare_dialogue_identity(
            objective=objective,
            evaluation_summary=evaluation_summary,
        )
        active = self._state.read()["c1"]["dialogue_turn_state"]
        if active["phase"] != "idle":
            raise RuntimeError(
                "dialogue_turn_already_active:" + str(active["turn_id"])
            )
        self._state.set_dialogue_turn_state(
            {
                "phase": "research",
                "turn_id": str(user_message["turn_id"]),
                "user_message_id": str(user_message["message_id"]),
            }
        )
        promoted_context_refs: list[str] = []
        assistant_context: list[dict[str, Any]] = []
        for selected in selected_messages:
            if selected["role"] == "user":
                context_ref = self._publish_conversation_input(
                    user_message=selected,
                    declared_response_role="scientific_input",
                )
                self._register_conversation_input(
                    context_ref,
                    declared_response_role="scientific_input",
                )
                promoted_context_refs.append(context_ref)
                continue
            assistant_context.append(
                {
                    "message_id": str(selected["message_id"]),
                    "turn_id": str(selected["turn_id"]),
                    "role": "assistant",
                    "content": str(selected["content"]),
                    "attachment_refs": list(selected["attachment_refs"]),
                    "evidence_refs": list(selected["evidence_refs"]),
                }
            )
        context_observation_refs: list[str] = []
        if assistant_context:
            context_receipt = self._observations.publish(
                namespace="dialogue-launch-context",
                status="dialogue_launch_context_selected",
                result={"messages": assistant_context},
                metadata={
                    "turn_id": str(user_message["turn_id"]),
                    "selected_message_ids": [
                        str(item["message_id"]) for item in assistant_context
                    ],
                },
            )
            context_observation_refs.append(
                str(context_receipt["observation_ref"])
            )
        promoted_ref = self._publish_conversation_input(
            user_message=user_message,
            declared_response_role="scientific_input",
        )
        self._register_conversation_input(
            promoted_ref,
            declared_response_role="scientific_input",
        )
        task_supporting_refs = tuple((*refs, *context_observation_refs))
        if task_supporting_refs:
            self._register_task_supporting_refs(task_supporting_refs)
        self._events.append(
            "dialogue_pre_task_handoff",
            {
                "turn_id": user_message["turn_id"],
                "user_message_id": user_message["message_id"],
                "promoted_ref": promoted_ref,
                "context_message_ids": [
                    str(item["message_id"]) for item in selected_messages
                ],
                "promoted_context_refs": promoted_context_refs,
                "context_observation_refs": context_observation_refs,
                "supporting_refs": list(task_supporting_refs),
            },
        )
        return self._run_dialogue_research(
            user_message=user_message,
            objective=normalized_objective,
            evaluation_summary=evaluation_summary,
        )

    def begin_preformulated_task_from_dialogue_message(
        self,
        *,
        user_message_id: str,
        objective: str,
        evaluation_summary: str,
    ) -> DialogueTurnResult:
        """Create C0 from an already published TaskSpec, then begin research."""
        if self._mission is not None:
            raise RuntimeError("child_agent_dialogue_forbidden")
        if not self._preformulated_task_spec_ref:
            raise RuntimeError("preformulated_task_spec_required")
        user_message = self._dialogue.get(str(user_message_id))
        if user_message["role"] != "user":
            raise ValueError("dialogue_task_start_requires_user_message")
        normalized_objective = self._prepare_dialogue_identity(
            objective=objective,
            evaluation_summary=evaluation_summary,
        )
        active = self._state.read()["c1"]["dialogue_turn_state"]
        if active["phase"] != "idle":
            raise RuntimeError(
                "dialogue_turn_already_active:" + str(active["turn_id"])
            )
        self._state.set_dialogue_turn_state(
            {
                "phase": "research",
                "turn_id": str(user_message["turn_id"]),
                "user_message_id": str(user_message["message_id"]),
            }
        )
        self._events.append(
            "dialogue_preformulated_task_started",
            {
                "turn_id": user_message["turn_id"],
                "user_message_id": user_message["message_id"],
                "task_spec_ref": self._preformulated_task_spec_ref,
                "input_refs": list(self._preformulated_task_input_refs),
            },
        )
        return self._run_dialogue_research(
            user_message=user_message,
            objective=normalized_objective,
            evaluation_summary=evaluation_summary,
        )

    def resume_dialogue_turn(
        self,
        *,
        objective: str,
        evaluation_summary: str,
    ) -> DialogueTurnResult:
        if self._mission is not None:
            raise RuntimeError("child_agent_dialogue_forbidden")
        normalized_objective = self._prepare_dialogue_identity(
            objective=objective,
            evaluation_summary=evaluation_summary,
        )
        active = self._state.read()["c1"]["dialogue_turn_state"]
        if active["phase"] == "idle":
            raise RuntimeError("dialogue_turn_not_active")
        self._dialogue.get(str(active["user_message_id"]))
        return self._continue_dialogue_turn(
            objective=normalized_objective,
            evaluation_summary=evaluation_summary,
        )

    def _prepare_dialogue_identity(
        self,
        *,
        objective: str,
        evaluation_summary: str,
    ) -> str:
        parsed = parse_task_authorization(objective)
        normalized_objective = parsed.objective
        self._enabled_meta_capabilities = parsed.enabled_meta_capabilities
        self._configure_meta_skill_catalog(
            self._enabled_meta_capabilities,
            require_support=bool(self._enabled_meta_capabilities),
        )
        self._initialize_or_validate_agent_state(
            objective=normalized_objective,
            evaluation_request=evaluation_summary,
        )
        return normalized_objective

    def _continue_dialogue_turn(
        self,
        *,
        objective: str,
        evaluation_summary: str,
    ) -> DialogueTurnResult:
        active = self._state.read()["c1"]["dialogue_turn_state"]
        user_message = self._dialogue.get(str(active["user_message_id"]))
        if active["phase"] == "research":
            return self._run_dialogue_research(
                user_message=user_message,
                objective=objective,
                evaluation_summary=evaluation_summary,
            )

        pending = self.pending_human_interaction()
        if pending is not None:
            if self._pending_global_evaluation_confirmation():
                return self._resolve_contract_change_confirmation(
                    pending=pending,
                    user_message=user_message,
                    objective=objective,
                    evaluation_summary=evaluation_summary,
                )
            self.submit_human_response(
                str(pending["request_id"]),
                str(user_message["content"]),
                attachment_refs=user_message["attachment_refs"],
            )
            self._state.set_dialogue_turn_state(
                {
                    **active,
                    "phase": "research",
                }
            )
            return self._run_dialogue_research(
                user_message=user_message,
                objective=objective,
                evaluation_summary=evaluation_summary,
            )

        action = self._decide_dialogue_action(user_message=user_message)
        name = action["name"]
        arguments = action["arguments"]
        if name == "reply_to_user":
            return self._finish_dialogue_turn(
                status="replied",
                message=str(arguments["message"]),
                evidence_refs=arguments.get("evidence_refs") or (),
            )
        if name == "ask_user_clarification":
            return self._finish_dialogue_turn(
                status="clarification_required",
                message=str(arguments["question"]),
            )
        if name == "resume_research":
            self._state.set_dialogue_turn_state(
                {**active, "phase": "research"}
            )
            return self._run_dialogue_research(
                user_message=user_message,
                objective=objective,
                evaluation_summary=evaluation_summary,
            )
        if name != "promote_user_input":
            raise RuntimeError(f"dialogue_action_unhandled:{name}")

        role = str(arguments["declared_response_role"])
        promoted_ref = self._publish_conversation_input(
            user_message=user_message,
            declared_response_role=role,
        )
        if role == "task_contract_change":
            request = self._request_human_input(
                {
                    "scope": "frame",
                    "question": str(user_message["content"]),
                    "reason": (
                        "The chat request changes the authoritative task "
                        "contract and requires explicit confirmation."
                    ),
                    "expected_response_role": "task_contract_change",
                    "context_refs": [promoted_ref],
                },
                allowed_scopes=("frame",),
                extra_context_refs=(promoted_ref,),
            )
            return self._finish_dialogue_turn(
                status="confirmation_required",
                message=(
                    f"{request['question']}\n\n"
                    f"{_CONTRACT_CHANGE_RESPONSE_INSTRUCTION}"
                ),
                evidence_refs=(promoted_ref,),
            )

        self._register_conversation_input(
            promoted_ref,
            declared_response_role=role,
        )
        self._state.set_dialogue_turn_state(
            {**active, "phase": "research"}
        )
        return self._run_dialogue_research(
            user_message=user_message,
            objective=objective,
            evaluation_summary=evaluation_summary,
        )

    def _resolve_contract_change_confirmation(
        self,
        *,
        pending: Mapping[str, Any],
        user_message: Mapping[str, Any],
        objective: str,
        evaluation_summary: str,
    ) -> DialogueTurnResult:
        answer = str(user_message["content"]).strip().casefold()
        if answer in _CONTRACT_CHANGE_CONFIRMATIONS:
            self.submit_human_response(
                str(pending["request_id"]),
                str(user_message["content"]),
                declared_response_role="task_contract_change",
                attachment_refs=user_message["attachment_refs"],
            )
            for ref in self._pending_conversation_contract_refs(pending):
                self._state.add_resolved_artifact_ref(ref)
                self._register_conversation_input(
                    ref,
                    declared_response_role="task_contract_change",
                )
            active = self._state.read()["c1"]["dialogue_turn_state"]
            self._state.set_dialogue_turn_state(
                {**active, "phase": "research"}
            )
            return self._run_dialogue_research(
                user_message=user_message,
                objective=objective,
                evaluation_summary=evaluation_summary,
            )
        if answer in _CONTRACT_CHANGE_REJECTIONS:
            response = self.submit_human_response(
                str(pending["request_id"]),
                str(user_message["content"]),
                declared_response_role="feedback",
                attachment_refs=user_message["attachment_refs"],
            )
            retired_refs = [
                str(response["artifact_ref"]),
                *self._pending_conversation_contract_refs(pending),
            ]
            self._state.remove_resolved_artifact_refs(retired_refs)
            self._mark_human_answer_consumed(
                consumer="dialogue_contract_change_rejected"
            )
            self._events.append(
                "dialogue_contract_change_rejected",
                {
                    "request_id": pending["request_id"],
                    "proposed_refs": retired_refs[1:],
                    "response_ref": retired_refs[0],
                },
            )
            return self._finish_dialogue_turn(
                status="contract_change_rejected",
                message=(
                    "已拒絕這次任務契約變更；原任務與全域驗收條件"
                    "維持不變。"
                ),
            )
        return self._finish_dialogue_turn(
            status="confirmation_required",
            message=(
                "這是任務契約變更，不能從一般回答推測是否核准。\n\n"
                f"{_CONTRACT_CHANGE_RESPONSE_INSTRUCTION}"
            ),
        )

    def _pending_conversation_contract_refs(
        self,
        pending: Mapping[str, Any],
    ) -> tuple[str, ...]:
        refs: list[str] = []
        for raw_ref in pending.get("context_refs") or ():
            ref = str(raw_ref)
            if not ref.startswith("artifact:"):
                continue
            stored = self._read_exact_ref(ref)
            if stored.get("artifact_kind") != "human_conversation_input":
                continue
            payload = stored.get("machine_payload")
            if (
                isinstance(payload, Mapping)
                and payload.get("declared_response_role")
                == "task_contract_change"
            ):
                refs.append(ref)
        return tuple(dict.fromkeys(refs))

    def _decide_dialogue_action(
        self,
        *,
        user_message: Mapping[str, Any],
    ) -> dict[str, Any]:
        recent_dialogue = [
            item
            for item in self._dialogue_memory.recent(
                max_bytes=RECENT_DIALOGUE_BUDGET_BYTES
            )
            if item["message_id"] != user_message["message_id"]
        ]
        return self._run_dialogue_model_boundary(
            instruction=_INTAKE_INSTRUCTION,
            purpose="decide main-agent dialogue intake",
            payload={
                "run_state": self._dialogue_run_projection(),
                "dialogue_summary": self._dialogue_memory.summary(),
                "recent_dialogue": recent_dialogue,
                "latest_user_message": dict(user_message),
                "accepted_artifact_index": self._active_artifact_index(),
            },
            action_tools=_intake_tools(),
            visible_refs=self._dialogue_visible_refs(user_message),
            allowed_actions={
                "reply_to_user",
                "ask_user_clarification",
                "promote_user_input",
                "resume_research",
            },
        )

    def _run_dialogue_model_boundary(
        self,
        *,
        instruction: str,
        purpose: str,
        payload: Mapping[str, Any],
        action_tools: Sequence[Mapping[str, Any]],
        visible_refs: Sequence[str],
        allowed_actions: set[str],
        scientific_call: bool = False,
    ) -> dict[str, Any]:
        read_results: list[dict[str, Any]] = []
        read_refs: set[str] = set()
        issue = ""
        reads = 0
        for decision_index in range(1, 7):
            remaining_refs = [
                ref for ref in visible_refs if ref not in read_refs
            ]
            tools = list(action_tools)
            if reads < _MAX_DIALOGUE_READS and remaining_refs:
                tools.append(_read_tool(remaining_refs))
            call_payload = dict(payload)
            if read_results:
                call_payload["exact_read_results"] = read_results
            if issue:
                call_payload["format_repair"] = issue
            messages = [
                {
                    "role": "system",
                    "content": instruction
                    + ("\n\n" + self._role_instructions if self._role_instructions else ""),
                },
                {
                    "role": "user",
                    "content": json.dumps(
                        call_payload,
                        ensure_ascii=False,
                        separators=(",", ":"),
                        default=str,
                    ),
                },
            ]
            is_repair = bool(issue)
            call_purpose = purpose if not is_repair else f"repair {purpose}"
            self._memory.prepare_for_model_call(call_site=call_purpose)
            self._memory.record_prompt_projection(
                call_site=call_purpose,
                messages=messages,
                tools=tools,
                sources=(
                    PromptSource("instruction", "dialogue_instruction", instruction),
                    PromptSource("C0", "dialogue_run_state", payload.get("run_state")),
                    PromptSource("C3", "dialogue_summary", payload.get("dialogue_summary")),
                    PromptSource("C4", "recent_dialogue", payload.get("recent_dialogue")),
                    PromptSource("C4", "latest_user_message", payload.get("latest_user_message")),
                    PromptSource("C2", "accepted_artifact_index", payload.get("accepted_artifact_index")),
                    PromptSource("tool_schema", "dialogue_tools", tools),
                ),
                budget_tier="full",
            )
            turn = complete_model_turn(
                self._model,
                messages=messages,
                tools=tools,
                purpose=call_purpose,
                tool_choice="required",
                repair=is_repair,
                scientific=scientific_call and not is_repair,
            )
            self._events.append(
                "dialogue_model_turn",
                {
                    "purpose": call_purpose,
                    "decision_index": decision_index,
                    "content": turn.content,
                    "tool_calls": [
                        {
                            "call_id": call.call_id,
                            "name": call.name,
                            "arguments": dict(call.arguments),
                        }
                        for call in turn.tool_calls
                    ],
                    "usage": dict(turn.usage),
                },
            )
            if len(turn.tool_calls) != 1:
                issue = "Use exactly one available dialogue tool."
                continue
            call = turn.tool_calls[0]
            if call.name == "read_dialogue_evidence":
                ref = str(call.arguments.get("ref") or "").strip()
                if ref not in visible_refs:
                    issue = f"The requested ref is not visible: {ref}"
                    continue
                if ref in read_refs:
                    issue = (
                        "The requested ref was already read; use the exact "
                        "result already shown or choose a final action."
                    )
                    continue
                if reads >= _MAX_DIALOGUE_READS:
                    issue = "The exact-read limit is exhausted; choose a final action."
                    continue
                read_results.append(
                    {
                        "ref": ref,
                        "stored": self._read_exact_ref(ref),
                    }
                )
                read_refs.add(ref)
                reads += 1
                issue = ""
                continue
            if call.name not in allowed_actions:
                issue = f"Choose one allowed final action, not {call.name}."
                continue
            try:
                self._validate_dialogue_action(call.name, call.arguments)
            except (KeyError, TypeError, ValueError) as exc:
                issue = str(exc)
                continue
            if call.name == "reply_to_user":
                ungrounded = [
                    str(ref)
                    for ref in call.arguments["evidence_refs"]
                    if str(ref) not in visible_refs
                ]
                if ungrounded:
                    issue = (
                        "The reply cites refs outside the visible evidence "
                        f"set: {ungrounded}"
                    )
                    continue
            if (
                call.name == "promote_user_input"
                and call.arguments["declared_response_role"]
                == "task_contract_change"
                and self._state.read()["c1"]["global_evaluation_state"] is None
            ):
                issue = (
                    "No existing Global Evaluation can be amended. Treat an "
                    "initial task-defining message as scientific_input instead."
                )
                continue
            closure = self._current_evaluation_closure_or_bootstrap()
            if bool(closure.get("complete")) and (
                call.name == "resume_research"
                or (
                    call.name == "promote_user_input"
                    and call.arguments["declared_response_role"]
                    == "scientific_input"
                )
            ):
                issue = (
                    "The current Global Evaluation is terminal. Reply from "
                    "existing evidence, or use task_contract_change for new "
                    "research; do not silently continue the closed task."
                )
                continue
            if (
                call.name == "promote_user_input"
                and call.arguments["declared_response_role"]
                == "task_contract_change"
                and not self._human_in_loop_enabled
            ):
                issue = (
                    "Human-in-the-loop is disabled, so this run cannot open "
                    "the required contract-change confirmation. Explain that "
                    "the user must start a new session or enable HITL."
                )
                continue
            return {
                "name": call.name,
                "arguments": dict(call.arguments),
            }
        raise RuntimeError("dialogue_decision_exhausted:" + issue)

    def _run_dialogue_research(
        self,
        *,
        user_message: Mapping[str, Any],
        objective: str,
        evaluation_summary: str,
    ) -> DialogueTurnResult:
        before_refs = {
            str(item["artifact_ref"]) for item in self._artifacts.list()
        }
        result = self.run(
            objective=objective,
            evaluation_summary=evaluation_summary,
        )
        after_index = list(self._artifacts.list())
        new_refs = tuple(
            str(item["artifact_ref"])
            for item in after_index
            if str(item["artifact_ref"]) not in before_refs
        )
        if result.status == "paused_for_human":
            pending = self.pending_human_interaction()
            if pending is None:
                raise RuntimeError("dialogue_pause_without_human_request")
            return self._finish_dialogue_turn(
                status="research_paused_for_human",
                message=str(pending["question"]),
                research_status=result.status,
                rounds=result.rounds,
                closure=result.closure,
                evidence_refs=new_refs,
            )

        evidence_refs = list(new_refs)
        for ref in exact_string_refs(result.closure):
            if ref.startswith(
                ("artifact:", "code_artifact:", "execution_observation:")
            ) and ref not in evidence_refs:
                evidence_refs.append(ref)
        try:
            report_action = self._run_dialogue_model_boundary(
                instruction=_REPORT_INSTRUCTION,
                purpose="report scientific research to user",
                payload={
                    "run_state": self._dialogue_run_projection(),
                    "latest_user_message": dict(user_message),
                    "research_result": {
                        "status": result.status,
                        "rounds": result.rounds,
                        "final_text": result.final_text,
                        "closure": bounded_projection(
                            result.closure,
                            max_depth=5,
                            max_items=20,
                        ),
                        "new_artifact_refs": list(new_refs),
                    },
                    "accepted_artifact_index": self._active_artifact_index(),
                },
                action_tools=(_reply_tool(),),
                visible_refs=self._dialogue_visible_refs(
                    user_message,
                    extra_refs=evidence_refs,
                ),
                allowed_actions={"reply_to_user"},
                scientific_call=True,
            )
            report_message = str(report_action["arguments"]["message"])
            report_refs = (
                report_action["arguments"].get("evidence_refs")
                or evidence_refs
            )
        except Exception as exc:
            self._events.append(
                "dialogue_report_fallback_used",
                {
                    "turn_id": user_message["turn_id"],
                    "research_status": result.status,
                    "rounds": result.rounds,
                    "error": f"{type(exc).__name__}:{exc}",
                },
            )
            refs_text = "\n".join(f"- `{ref}`" for ref in evidence_refs)
            if not refs_text:
                refs_text = "- 無新增或結案證據引用"
            report_message = (
                "研究執行已結束，但回報模型未能產生合規回覆。"
                "以下僅列出系統可機械確認的狀態：\n"
                f"- 執行狀態：`{result.status}`\n"
                f"- 執行回合：`{result.rounds}`\n"
                "- 證據引用：\n"
                f"{refs_text}\n"
                "本訊息不額外宣稱科學結論或整體目標已達成；"
                "科學內容以引用的正式成果為準。"
            )
            report_refs = evidence_refs
        return self._finish_dialogue_turn(
            status=(
                "research_complete"
                if result.status == "complete"
                else "research_stopped"
            ),
            message=report_message,
            research_status=result.status,
            rounds=result.rounds,
            closure=result.closure,
            evidence_refs=report_refs,
        )

    def _publish_conversation_input(
        self,
        *,
        user_message: Mapping[str, Any],
        declared_response_role: str,
    ) -> str:
        ref = publish_human_conversation_input(
            artifacts=self._artifacts,
            events=self._events,
            user_message=user_message,
            declared_response_role=declared_response_role,
        )
        if declared_response_role != "task_contract_change":
            self._state.add_resolved_artifact_ref(ref)
        return ref

    def _register_conversation_input(
        self,
        artifact_ref: str,
        *,
        declared_response_role: str,
    ) -> None:
        state = self._state.read()
        contract = state["c1"]["task_contract_state"]
        if contract["phase"] in {"task_formulation", "evaluation_build"}:
            refs = list(contract["input_refs"])
            if artifact_ref not in refs:
                refs.append(artifact_ref)
            self._state.set_task_contract_state(
                {
                    **contract,
                    "input_refs": refs,
                }
            )
        self._state.set_issue(
            "Accepted human conversation input must be consumed by the "
            f"current task: {artifact_ref} ({declared_response_role})."
        )

    def _register_task_supporting_refs(
        self,
        refs: Sequence[str],
    ) -> None:
        state = self._state.read()
        contract = state["c1"]["task_contract_state"]
        input_refs = list(contract["input_refs"])
        for ref in refs:
            normalized = str(ref).strip()
            if not normalized:
                continue
            self._state.add_resolved_artifact_ref(normalized)
            if normalized not in input_refs:
                input_refs.append(normalized)
        if input_refs != list(contract["input_refs"]):
            self._state.set_task_contract_state(
                {**contract, "input_refs": input_refs}
            )

    def _finish_dialogue_turn(
        self,
        *,
        status: str,
        message: str,
        research_status: str = "",
        rounds: int = 0,
        closure: Mapping[str, Any] | None = None,
        evidence_refs: Sequence[str] = (),
    ) -> DialogueTurnResult:
        active = self._state.read()["c1"]["dialogue_turn_state"]
        normalized_message = str(message).strip()
        if not normalized_message:
            raise RuntimeError("dialogue_assistant_message_required")
        refs = self._validate_dialogue_evidence_refs(evidence_refs)
        turn_id = str(active["turn_id"])
        self._append_dialogue_assistant_once(
            turn_id=turn_id,
            content=normalized_message,
            evidence_refs=refs,
        )
        self._state.clear_dialogue_turn_state()
        self._events.append(
            "dialogue_turn_completed",
            {
                "turn_id": turn_id,
                "status": status,
                "research_status": research_status,
                "rounds": int(rounds),
                "evidence_refs": list(refs),
            },
        )
        try:
            self._dialogue_memory.maybe_compact(turn_id=turn_id)
        except Exception as exc:
            self._events.append(
                "dialogue_compaction_deferred",
                {
                    "turn_id": turn_id,
                    "reason": str(exc),
                },
            )
        return DialogueTurnResult(
            status=status,
            turn_id=turn_id,
            message=normalized_message,
            research_status=str(research_status),
            rounds=int(rounds),
            closure=dict(closure or {}),
            evidence_refs=refs,
        )

    def _append_dialogue_assistant_once(
        self,
        *,
        turn_id: str,
        content: str,
        evidence_refs: Sequence[str],
    ) -> None:
        message_id = f"msg-assistant-{turn_id}"
        try:
            existing = self._dialogue.get(message_id)
        except KeyError:
            self._dialogue.append_message(
                message_id=message_id,
                turn_id=turn_id,
                role="assistant",
                content=content,
                evidence_refs=evidence_refs,
            )
            return
        expected_refs = list(dict.fromkeys(str(ref) for ref in evidence_refs))
        if (
            existing["turn_id"] != turn_id
            or existing["role"] != "assistant"
            or existing["content"] != content
            or list(existing["evidence_refs"]) != expected_refs
        ):
            raise RuntimeError("dialogue_assistant_replay_conflict")

    def _recover_interrupted_dialogue_completion(self) -> None:
        active = self._state.read()["c1"]["dialogue_turn_state"]
        if active["phase"] == "idle":
            return
        turn_id = str(active["turn_id"])
        try:
            existing = self._dialogue.get(f"msg-assistant-{turn_id}")
        except KeyError:
            return
        if existing["turn_id"] != turn_id or existing["role"] != "assistant":
            raise RuntimeError("dialogue_recovery_message_conflict")
        self._state.clear_dialogue_turn_state()
        self._events.append(
            "dialogue_turn_completion_recovered",
            {"turn_id": turn_id},
        )

    def _dialogue_run_projection(self) -> dict[str, Any]:
        state = self._state.read()
        return {
            "objective": state["c0"]["objective"],
            "task_contract": bounded_projection(
                state["c1"]["task_contract_state"],
                max_depth=3,
                max_items=20,
            ),
            "global_evaluation": self._current_evaluation_closure_or_bootstrap(),
            "current_issue": bounded_text(
                str(state["c1"]["current_issue"]),
                2_000,
            ),
            "human_in_loop_enabled": self._human_in_loop_enabled,
        }

    def _dialogue_visible_refs(
        self,
        user_message: Mapping[str, Any],
        *,
        extra_refs: Sequence[str] = (),
    ) -> tuple[str, ...]:
        refs: list[str] = []
        for item in self._active_artifact_index():
            ref = str(item.get("artifact_ref") or "")
            if ref and ref not in refs:
                refs.append(ref)
        for ref in [*user_message.get("attachment_refs", ()), *extra_refs]:
            normalized = str(ref).strip()
            if normalized and normalized not in refs:
                try:
                    self._read_exact_ref(normalized)
                except (KeyError, OSError, PermissionError, ValueError):
                    continue
                refs.append(normalized)
        return tuple(refs)

    def _validate_dialogue_attachment_refs(
        self,
        refs: Sequence[str],
    ) -> tuple[str, ...]:
        normalized = tuple(
            dict.fromkeys(str(ref).strip() for ref in refs if str(ref).strip())
        )
        for ref in normalized:
            self._read_exact_ref(ref)
        return normalized

    def _validate_dialogue_evidence_refs(
        self,
        refs: Sequence[str],
    ) -> tuple[str, ...]:
        normalized = tuple(
            dict.fromkeys(str(ref).strip() for ref in refs if str(ref).strip())
        )
        for ref in normalized:
            self._read_exact_ref(ref)
        return normalized

    @staticmethod
    def _validate_dialogue_action(
        name: str,
        arguments: Mapping[str, Any],
    ) -> None:
        if name == "reply_to_user":
            if set(arguments) != {"message", "evidence_refs"}:
                raise ValueError("reply_to_user_fields_invalid")
            if not str(arguments["message"]).strip():
                raise ValueError("reply_to_user_message_required")
            refs = arguments["evidence_refs"]
            if not isinstance(refs, list) or not all(
                isinstance(ref, str) and ref for ref in refs
            ):
                raise ValueError("reply_to_user_evidence_refs_invalid")
            return
        if name == "ask_user_clarification":
            if set(arguments) != {"question"} or not str(
                arguments["question"]
            ).strip():
                raise ValueError("dialogue_clarification_invalid")
            return
        if name == "promote_user_input":
            if set(arguments) != {"declared_response_role", "reason"}:
                raise ValueError("promote_user_input_fields_invalid")
            validate_human_conversation_input(
                {
                    "artifact_kind": "human_conversation_input",
                    "message_id": "validation-message",
                    "turn_id": "validation-turn",
                    "declared_response_role": arguments[
                        "declared_response_role"
                    ],
                    "attachment_refs": [],
                }
            )
            if not str(arguments["reason"]).strip():
                raise ValueError("promote_user_input_reason_required")
            return
        if name == "resume_research":
            if set(arguments) != {"reason"} or not str(
                arguments["reason"]
            ).strip():
                raise ValueError("resume_research_reason_required")
            return
        raise ValueError(f"dialogue_action_unknown:{name}")


def _intake_tools() -> tuple[dict[str, Any], ...]:
    return (
        _reply_tool(),
        function_tool(
            "ask_user_clarification",
            "Ask one necessary clarification and return control to the user.",
            {
                "type": "object",
                "properties": {
                    "question": {"type": "string", "minLength": 1},
                },
                "required": ["question"],
                "additionalProperties": False,
            },
        ),
        function_tool(
            "promote_user_input",
            "Promote the exact latest user message into formal C2 task input.",
            {
                "type": "object",
                "properties": {
                    "declared_response_role": {
                        "type": "string",
                        "enum": [
                            "feedback",
                            "scientific_input",
                            "task_contract_change",
                        ],
                    },
                    "reason": {"type": "string", "minLength": 1},
                },
                "required": ["declared_response_role", "reason"],
                "additionalProperties": False,
            },
        ),
        function_tool(
            "resume_research",
            "Resume the existing authoritative task without changing it.",
            {
                "type": "object",
                "properties": {
                    "reason": {"type": "string", "minLength": 1},
                },
                "required": ["reason"],
                "additionalProperties": False,
            },
        ),
    )


def _reply_tool() -> dict[str, Any]:
    return function_tool(
        "reply_to_user",
        "Return one evidence-grounded message to the human chat.",
        {
            "type": "object",
            "properties": {
                "message": {"type": "string", "minLength": 1},
                "evidence_refs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "uniqueItems": True,
                },
            },
            "required": ["message", "evidence_refs"],
            "additionalProperties": False,
        },
    )


def _read_tool(visible_refs: Sequence[str]) -> dict[str, Any]:
    ref_schema: dict[str, Any] = {"type": "string", "minLength": 1}
    if visible_refs:
        ref_schema["enum"] = list(visible_refs)
    return function_tool(
        "read_dialogue_evidence",
        "Read one exact visible stored ref before choosing the final action.",
        {
            "type": "object",
            "properties": {"ref": ref_schema},
            "required": ["ref"],
            "additionalProperties": False,
        },
    )
