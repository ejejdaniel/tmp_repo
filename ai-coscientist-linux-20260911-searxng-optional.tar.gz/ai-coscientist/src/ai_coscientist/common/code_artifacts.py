from __future__ import annotations

import ast
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Mapping, Sequence


class CodeArtifactStore:
    """Immutable source files with bounded receipts and verified reads."""

    def __init__(self, root: Path) -> None:
        self._root = root.resolve()
        self._code_dir = self._root / "code"
        self._index_path = self._root / "code-artifact-index.json"
        self._code_dir.mkdir(parents=True, exist_ok=True)
        if not self._index_path.exists():
            self._write_json(self._index_path, {"order": [], "entries": {}})

    def publish(
        self,
        *,
        code: str,
        purpose: str,
        depends_on: Sequence[str] = (),
    ) -> dict[str, Any]:
        if not code.strip():
            raise ValueError("python_code_required")
        if len(code) > 120_000:
            raise ValueError("python_code_too_large")
        try:
            ast.parse(code, filename="<code-artifact>")
        except SyntaxError as exc:
            raise ValueError(
                "python_syntax_error:"
                f"{exc.msg}:line={int(exc.lineno or 0)}:"
                f"offset={int(exc.offset or 0)}"
            ) from exc
        digest = hashlib.sha256(
            json.dumps(
                {
                    "language": "python",
                    "purpose": purpose,
                    "depends_on": list(depends_on),
                    "code": code,
                },
                ensure_ascii=False,
                sort_keys=True,
            ).encode("utf-8")
        ).hexdigest()
        code_ref = f"code_artifact:{_slug(purpose)}:{digest[:16]}"
        index = self._read_index()
        if code_ref not in index["entries"]:
            path = self._code_dir / f"{digest[:16]}.py"
            self._write_text(path, code)
            entry = {
                "code_artifact_ref": code_ref,
                "artifact_kind": "code_artifact",
                "language": "python",
                "purpose": purpose,
                "depends_on": list(depends_on),
                "sha256": digest,
                "storage_path": str(path),
            }
            index["order"].append(code_ref)
            index["entries"][code_ref] = entry
            self._write_json(self._index_path, index)
        entry = index["entries"][code_ref]
        return {
            "code_artifact_ref": entry["code_artifact_ref"],
            "artifact_kind": entry["artifact_kind"],
            "language": entry["language"],
            "purpose": entry["purpose"],
            "sha256": entry["sha256"],
        }

    def read(self, code_artifact_ref: str) -> dict[str, Any]:
        entry = self._read_index()["entries"].get(code_artifact_ref)
        if entry is None:
            raise KeyError(f"code_artifact_ref_not_found:{code_artifact_ref}")
        path = Path(entry["storage_path"]).resolve()
        if not path.is_relative_to(self._code_dir):
            raise ValueError(f"code_artifact_path_outside_store:{code_artifact_ref}")
        code = path.read_text(encoding="utf-8")
        digest = hashlib.sha256(
            json.dumps(
                {
                    "language": entry["language"],
                    "purpose": entry["purpose"],
                    "depends_on": entry["depends_on"],
                    "code": code,
                },
                ensure_ascii=False,
                sort_keys=True,
            ).encode("utf-8")
        ).hexdigest()
        if digest != entry["sha256"]:
            raise ValueError(f"code_artifact_hash_mismatch:{code_artifact_ref}")
        return {**entry, "code": code, "path": str(path)}

    def ancestor_refs(self, code_artifact_ref: str) -> tuple[str, ...]:
        """Return the exact transitive code ancestors of one immutable revision."""
        pending = [
            str(ref)
            for ref in self.read(code_artifact_ref).get("depends_on", ())
            if str(ref).startswith("code_artifact:")
        ]
        ancestors: list[str] = []
        while pending:
            ref = pending.pop()
            if ref in ancestors:
                continue
            ancestors.append(ref)
            pending.extend(
                str(dependency)
                for dependency in self.read(ref).get("depends_on", ())
                if str(dependency).startswith("code_artifact:")
                and str(dependency) not in ancestors
            )
        return tuple(ancestors)

    def edit(
        self,
        *,
        code_artifact_ref: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> dict[str, Any]:
        """Create one immutable revision by replacing exact stored source text."""
        if not old_string:
            raise ValueError("code_edit_old_string_required")
        if old_string == new_string:
            raise ValueError("code_edit_requires_changed_text")

        previous = self.read(code_artifact_ref)
        source = str(previous["code"])
        occurrence_count = source.count(old_string)
        if occurrence_count == 0:
            raise ValueError("code_edit_old_string_not_found")
        if occurrence_count > 1 and not replace_all:
            raise ValueError(
                f"code_edit_old_string_not_unique:occurrences={occurrence_count}"
            )

        replacement_count = occurrence_count if replace_all else 1
        revised = source.replace(
            old_string,
            new_string,
            -1 if replace_all else 1,
        )
        dependencies = list(previous.get("depends_on") or ())
        if code_artifact_ref not in dependencies:
            dependencies.append(code_artifact_ref)
        receipt = self.publish(
            code=revised,
            purpose=str(previous["purpose"]),
            depends_on=dependencies,
        )
        return {
            **receipt,
            "previous_code_artifact_ref": code_artifact_ref,
            "replacement_count": replacement_count,
        }

    def _read_index(self) -> dict[str, Any]:
        return json.loads(self._index_path.read_text(encoding="utf-8"))

    @staticmethod
    def _write_json(path: Path, value: Mapping[str, Any]) -> None:
        temporary = path.with_suffix(f"{path.suffix}.tmp")
        temporary.write_text(
            json.dumps(value, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, path)

    @staticmethod
    def _write_text(path: Path, value: str) -> None:
        temporary = path.with_suffix(f"{path.suffix}.tmp")
        temporary.write_text(value, encoding="utf-8")
        os.replace(temporary, path)


def _slug(value: str) -> str:
    normalized = re.sub(r"[^a-zA-Z0-9._-]+", "-", value.strip()).strip("-")
    return normalized or "code"
