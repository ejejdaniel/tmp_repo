from __future__ import annotations

import ast

from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from .code_artifacts import CodeArtifactStore
from .routes import Route


@dataclass(frozen=True)
class CommonCodingTools:
    """Science-neutral immutable code authoring and exact-text revision tools."""

    code_artifacts: CodeArtifactStore
    environment_inspector: Callable[..., Mapping[str, Any]] | None = None

    def routes(self, *, skill_ids: Sequence[str]) -> tuple[Route, ...]:
        owners = tuple(str(skill_id) for skill_id in skill_ids)
        if not owners:
            raise ValueError("common_coding_skill_ids_required")
        routes = [
            Route(
                name="write_code_artifact",
                description=(
                    "Store one complete syntactically valid Python source version "
                    "without executing it. python_code is decoded tool data and must "
                    "itself be raw Python source, without Markdown fences or literal "
                    "backslashes before Python docstring quotes. An omitted python_code "
                    "body is rejected and is never reconstructed by payload repair. "
                    "The returned exact ref is the only identity for later edits or "
                    "execution."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "purpose": {"type": "string"},
                        "python_code": {"type": "string"},
                        "depends_on": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                    },
                    "required": ["purpose", "python_code", "depends_on"],
                    "additionalProperties": False,
                },
                handler=self.write,
                skill_ids=owners,
            ),
            Route(
                name="edit_code_artifact",
                description=(
                    "Create one immutable revision by replacing exact text in one "
                    "stored code artifact. old_string and new_string are fragments, "
                    "must differ, and never contain complete source files. Editing "
                    "does not mean overwrite. Read the exact source first and "
                    "copy the smallest unique old_string verbatim. replace_all means "
                    "replace every exact occurrence. For a complete corrected source, "
                    "call write_code_artifact with the previous code ref in "
                    "depends_on instead of calling this route."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "code_artifact_ref": {"type": "string"},
                        "old_string": {"type": "string"},
                        "new_string": {"type": "string"},
                        "replace_all": {"type": "boolean"},
                    },
                    "required": [
                        "code_artifact_ref",
                        "old_string",
                        "new_string",
                    ],
                    "additionalProperties": False,
                },
                handler=self.edit,
                skill_ids=owners,
            ),
        ]
        if self.environment_inspector is not None:
            routes.append(
                Route(
                    name="inspect_python_environment",
                    description=(
                        "Run one exact stored Python code artifact as a read-only "
                        "diagnostic inside one exact visible Python environment. "
                        "environment_ref must be an exact visible approved_route: "
                        "or workspace:capability_registry/pending/ ref; a "
                        "code_artifact: ref is not an environment. "
                        "Use it to inspect installed package APIs, import paths, "
                        "signatures, versions, or candidate source behavior before "
                        "editing implementation code. It cannot modify or approve "
                        "the environment and its output is diagnostic evidence, not "
                        "a scientific result."
                    ),
                    parameters={
                        "type": "object",
                        "properties": {
                            "environment_ref": {"type": "string"},
                            "code_artifact_ref": {"type": "string"},
                            "timeout_seconds": {
                                "type": "integer",
                                "minimum": 1,
                                "maximum": 120,
                            },
                        },
                        "required": [
                            "environment_ref",
                            "code_artifact_ref",
                            "timeout_seconds",
                        ],
                        "additionalProperties": False,
                    },
                    handler=lambda arguments: arguments,
                    contextual_handler=self.inspect_environment,
                    skill_ids=owners,
                )
            )
        return tuple(routes)

    def write(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        purpose = str(arguments.get("purpose") or "").strip()
        if not purpose:
            raise ValueError("code_artifact_purpose_required")
        python_code = _validated_python_code(
            str(arguments.get("python_code") or "")
        )
        dependencies = _string_refs(arguments.get("depends_on"))
        return self.code_artifacts.publish(
            code=python_code,
            purpose=purpose,
            depends_on=dependencies,
        )

    def edit(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        code_ref = str(arguments.get("code_artifact_ref") or "")
        old_string = str(arguments.get("old_string") or "")
        new_string = str(arguments.get("new_string") or "")
        if _looks_like_complete_python_source(
            new_string,
            replacement_target=old_string,
        ):
            previous = self.code_artifacts.read(code_ref)
            dependencies = list(previous.get("depends_on") or ())
            if code_ref not in dependencies:
                dependencies.append(code_ref)
            raise ValueError(
                "complete_python_source_detected_in_new_string:"
                "do_not_retry_edit:"
                "call_write_code_artifact_with_"
                f"purpose={previous['purpose']!r}:"
                f"depends_on={dependencies!r}"
            )
        try:
            return self.code_artifacts.edit(
                code_artifact_ref=code_ref,
                old_string=old_string,
                new_string=new_string,
                replace_all=bool(arguments.get("replace_all", False)),
            )
        except ValueError as exc:
            if str(exc) != "code_edit_old_string_not_found":
                raise
            raise ValueError(
                "code_edit_old_string_not_found:"
                "reread_exact_source_and_use_smallest_exact_fragment"
            ) from exc

    def inspect_environment(
        self,
        arguments: Mapping[str, Any],
        skill_id: str | None,
    ) -> dict[str, Any]:
        if self.environment_inspector is None:
            raise RuntimeError("python_environment_inspector_unavailable")
        caller = str(skill_id or "").strip()
        if not caller:
            raise PermissionError("python_environment_inspection_requires_skill")
        environment_ref = str(arguments.get("environment_ref") or "").strip()
        code_ref = str(arguments.get("code_artifact_ref") or "").strip()
        timeout = arguments.get("timeout_seconds")
        if not environment_ref:
            raise ValueError("python_environment_ref_required")
        if not code_ref.startswith("code_artifact:"):
            raise ValueError("python_environment_code_artifact_ref_required")
        if (
            isinstance(timeout, bool)
            or not isinstance(timeout, int)
            or not 1 <= timeout <= 120
        ):
            raise ValueError("python_environment_timeout_invalid")
        stored = self.code_artifacts.read(code_ref)
        raw = self.environment_inspector(
            environment_ref=environment_ref,
            python_code=str(stored["code"]),
            caller_skill_id=caller,
            timeout_seconds=float(timeout),
        )
        status = str(raw.get("status") or "")
        returncode = raw.get("returncode")
        if status not in {"passed", "failed", "timed_out"}:
            raise ValueError("python_environment_inspection_status_invalid")
        if returncode is not None and (
            isinstance(returncode, bool) or not isinstance(returncode, int)
        ):
            raise ValueError("python_environment_inspection_returncode_invalid")
        return {
            "status": status,
            "returncode": returncode,
            "stdout": str(raw.get("stdout") or "")[-12_000:],
            "stderr": str(raw.get("stderr") or "")[-12_000:],
        }


def _string_refs(value: Any) -> tuple[str, ...]:
    if not isinstance(value, list):
        raise TypeError("code_artifact_depends_on_must_be_array")
    refs = tuple(str(item).strip() for item in value)
    if any(not ref for ref in refs):
        raise ValueError("code_artifact_dependency_ref_required")
    return refs

def _validated_python_code(python_code: str) -> str:
    try:
        ast.parse(python_code, filename="<code-artifact>")
        return python_code
    except SyntaxError as original_error:
        recovered = _recover_escaped_docstring_delimiters(python_code)
        if recovered != python_code:
            try:
                ast.parse(recovered, filename="<code-artifact>")
                return recovered
            except SyntaxError:
                pass
        line = int(original_error.lineno or 0)
        offset = int(original_error.offset or 0)
        raise ValueError(
            "python_syntax_error:"
            f"{original_error.msg}:line={line}:offset={offset}"
        ) from original_error


def _looks_like_complete_python_source(
    value: str,
    *,
    replacement_target: str,
) -> bool:
    try:
        tree = ast.parse(value, filename="<code-replacement>")
    except SyntaxError:
        return False
    definition_nodes = (
        ast.FunctionDef,
        ast.AsyncFunctionDef,
        ast.ClassDef,
    )
    if not any(isinstance(node, definition_nodes) for node in tree.body):
        return False
    try:
        target_tree = ast.parse(
            replacement_target,
            filename="<code-replacement-target>",
        )
    except SyntaxError:
        return True
    return not any(
        isinstance(node, definition_nodes) for node in target_tree.body
    )



def _recover_escaped_docstring_delimiters(python_code: str) -> str:
    """Remove one redundant JSON-escape layer from docstring delimiters only."""
    recovered: list[str] = []
    for line in python_code.splitlines(keepends=True):
        stripped = line.strip()
        if stripped.startswith('\\"\\"\\"') or stripped.endswith('\\"\\"\\"'):
            line = line.replace('\\"\\"\\"', '"""')
        if stripped.startswith("\\'\\'\\'") or stripped.endswith("\\'\\'\\'"):
            line = line.replace("\\'\\'\\'", "'''")
        recovered.append(line)
    return "".join(recovered)
