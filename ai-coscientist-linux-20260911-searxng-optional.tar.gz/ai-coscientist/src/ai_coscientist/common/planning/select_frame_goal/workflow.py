from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ..._runtime_support import function_tool
from ...memory_lifecycle.policy import PromptSource
from ...model import ChatModel, complete_model_turn
from ...openai_compatible import ModelProtocolError
from ..graph import FRAME_GOAL_NODE_ID


_ROOT = Path(__file__).resolve().parent
_SKILL = (_ROOT / "SKILL.md").read_text(encoding="utf-8")
_SYSTEM_PROMPT = """\
You are the main agent's private Frame-goal authoring stage.

Select one bounded goal for the next Frame. Global criteria describe the full
mission horizon; they are not a request to place all remaining work in this
Frame. Find why a new Frame is opening, choose the nearest judgeable formal
outcome that advances that reason, and stop before the first unknown result or
human/evaluator decision that could change the later route.

When priority criterion ids are supplied, the goal must advance at least one
of them. Another criterion may be linked only when the same single accepted
outcome supports it without adding another work route. Never widen a Frame just
to cover more criterion ids; criterion count is not a measure of Frame size.

Do not build a graph, list work nodes, choose skills, execute work, or describe
later Frames. Use the required tool exactly once. The goal must be judgeable
from accepted evidence available by the end of this Frame.
"""


class FrameGoalSelectionError(RuntimeError):
    """The model did not author one valid bounded Frame goal."""


def select_frame_goal(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    objective: str,
    global_evaluation_gate: Mapping[str, Any],
    global_evaluation_state: Mapping[str, Any],
    trigger: str,
    trigger_reason: str,
    completed_node_anchors: Sequence[Mapping[str, Any]],
    accepted_artifacts: Sequence[Mapping[str, Any]],
    skill_summaries: Sequence[Mapping[str, Any]],
    previous_frame_goal: Mapping[str, Any] | None = None,
    priority_criterion_ids: Sequence[str] = (),
    mission_packet: Mapping[str, Any] | None = None,
    human_input_tool: Mapping[str, Any] | None = None,
    request_human_input: Callable[[Mapping[str, Any]], None] | None = None,
) -> dict[str, Any]:
    """Author the immutable goal for one new Frame before graph construction."""
    criteria = _unmet_criteria(
        global_evaluation_gate,
        global_evaluation_state,
    )
    allowed_ids = [str(item["criterion_id"]) for item in criteria]
    priority_ids = [str(item).strip() for item in priority_criterion_ids]
    if any(not item for item in priority_ids) or len(priority_ids) != len(
        set(priority_ids)
    ):
        raise FrameGoalSelectionError("frame_goal_priority_criteria_invalid")
    unknown_priority = sorted(set(priority_ids) - set(allowed_ids))
    if unknown_priority:
        raise FrameGoalSelectionError(
            "frame_goal_priority_criteria_not_unmet:" + str(unknown_priority)
        )
    payload: dict[str, Any] = {
        "new_frame_trigger": {
            "kind": str(trigger).strip(),
            "reason": str(trigger_reason).strip(),
            "priority_criterion_ids": priority_ids,
        },
        "global_horizon": {
            "objective": str(objective),
            "unmet_criteria": criteria,
        },
        "accepted_completed_outcomes": [
            _node_projection(item) for item in completed_node_anchors
        ],
        "accepted_artifact_index": [dict(item) for item in accepted_artifacts],
    }
    output_contracts = "\n\n".join(
        str(item.get("description") or "").strip() for item in skill_summaries
    )
    if previous_frame_goal:
        payload["previous_frame_goal"] = _node_projection(previous_frame_goal)
    if mission_packet:
        payload["mission_packet"] = dict(mission_packet)

    tool = _frame_goal_tool(allowed_ids)
    tools = [tool]
    if human_input_tool is not None:
        tools.append(dict(human_input_tool))

    issue = ""
    for attempt in range(1, 3):
        call_payload = dict(payload)
        if issue:
            call_payload["format_repair"] = {
                "issue": issue,
                "instruction": (
                    "Correct only the rejected Frame-goal tool payload. Keep "
                    "the same bounded intent and use submit_frame_goal once."
                ),
            }
        purpose = (
            "select next common-agent Frame goal"
            if not issue
            else "repair next common-agent Frame goal format"
        )
        messages = [
            {"role": "system", "content": _SYSTEM_PROMPT + "\n\n" + _SKILL},
            {
                "role": "user",
                "content": json.dumps(
                    call_payload,
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            },
        ]
        if output_contracts:
            messages.append({
                "role": "user",
                "content": (
                    "Existing capability result definitions. Use these to "
                    "interpret what accepted outputs establish, not to choose "
                    "skills, prescribe a route, or add task obligations.\n\n"
                    + output_contracts
                ),
            })
        memory.prepare_for_model_call(call_site=purpose)
        memory.record_prompt_projection(
            call_site=purpose,
            messages=messages,
            tools=tools,
            sources=(*_prompt_sources(call_payload), PromptSource(
                "instruction", "frame_goal_output_contracts", output_contracts,
            )),
            budget_tier="full",
        )
        events.append(
            "frame_goal_prompt_snapshot",
            {
                "purpose": purpose,
                "attempt": attempt,
                "messages": messages,
                "tool_names": [item["function"]["name"] for item in tools],
            },
        )
        try:
            turn = complete_model_turn(
                model,
                messages=messages,
                tools=tools,
                purpose=purpose,
                tool_choice="required",
                planning=True,
            )
        except ModelProtocolError as exc:
            issue = f"model_protocol_error:{exc}"
            if attempt == 2:
                raise FrameGoalSelectionError(issue) from exc
            continue

        events.append(
            "frame_goal_model_turn",
            {
                "purpose": purpose,
                "attempt": attempt,
                "content": turn.content,
                "tool_calls": [
                    {
                        "call_id": call.call_id,
                        "name": call.name,
                        "arguments": dict(call.arguments),
                    }
                    for call in turn.tool_calls
                ],
                "usage": dict(turn.usage),
            },
        )
        if (
            len(turn.tool_calls) == 1
            and turn.tool_calls[0].name == "request_human_input"
        ):
            if request_human_input is None:
                raise FrameGoalSelectionError(
                    "frame_goal_human_input_callback_missing"
                )
            try:
                request_human_input(turn.tool_calls[0].arguments)
            except (RuntimeError, ValueError) as exc:
                issue = f"frame_goal_human_input_rejected:{exc}"
                if attempt == 2:
                    raise FrameGoalSelectionError(issue) from exc
                continue
            from ...sub_loop_toolkit import HumanInteractionPause

            raise HumanInteractionPause()

        try:
            arguments = _single_goal_submission(turn.tool_calls)
            goal = _normalize_goal(
                arguments,
                allowed_ids=allowed_ids,
                priority_ids=priority_ids,
            )
        except FrameGoalSelectionError as exc:
            issue = str(exc)
            if attempt == 2:
                raise
            continue

        events.append(
            "frame_goal_selected",
            {
                "trigger": str(trigger),
                "priority_criterion_ids": priority_ids,
                "frame_goal": goal,
            },
        )
        return goal

    raise FrameGoalSelectionError("frame_goal_selection_exhausted")


def _unmet_criteria(
    gate: Mapping[str, Any],
    state: Mapping[str, Any],
) -> list[dict[str, Any]]:
    raw_payload = gate.get("machine_payload")
    payload = (
        dict(raw_payload)
        if isinstance(raw_payload, Mapping)
        else dict(gate)
    )
    raw_criteria = payload.get("success_criteria")
    if isinstance(raw_criteria, (str, bytes)) or not isinstance(
        raw_criteria, Sequence
    ):
        raise FrameGoalSelectionError("frame_goal_global_criteria_invalid")
    raw_results = state.get("criterion_results")
    if isinstance(raw_results, (str, bytes)) or not isinstance(
        raw_results, Sequence
    ):
        raise FrameGoalSelectionError("frame_goal_global_state_invalid")
    result_by_id = {
        str(item.get("criterion_id") or "").strip(): item
        for item in raw_results
        if isinstance(item, Mapping)
        and str(item.get("criterion_id") or "").strip()
    }
    criteria: list[dict[str, Any]] = []
    for raw in raw_criteria:
        if not isinstance(raw, Mapping):
            raise FrameGoalSelectionError("frame_goal_global_criterion_invalid")
        criterion_id = str(raw.get("criterion_id") or "").strip()
        requirement = str(raw.get("requirement") or "").strip()
        expectation = str(raw.get("evidence_expectation") or "").strip()
        if not criterion_id or not requirement or not expectation:
            raise FrameGoalSelectionError("frame_goal_global_criterion_invalid")
        result = result_by_id.get(criterion_id, {})
        status = str(result.get("status") or "indeterminate").strip()
        if status == "met":
            continue
        if status not in {"unmet", "indeterminate"}:
            raise FrameGoalSelectionError("frame_goal_global_status_invalid")
        criteria.append(
            {
                "criterion_id": criterion_id,
                "requirement": requirement,
                "evidence_expectation": expectation,
                "status": status,
                "reason": str(result.get("reason") or "Not evaluated yet."),
                "evidence_refs": [
                    str(ref)
                    for ref in result.get("evidence_refs") or ()
                    if str(ref)
                ],
            }
        )
    if not criteria:
        raise FrameGoalSelectionError("frame_goal_not_required_global_complete")
    return criteria


def _single_goal_submission(calls: Sequence[Any]) -> Mapping[str, Any]:
    if len(calls) != 1 or calls[0].name != "submit_frame_goal":
        raise FrameGoalSelectionError(
            "frame_goal_requires_exactly_one_submit_frame_goal_call"
        )
    return dict(calls[0].arguments)


def _normalize_goal(
    arguments: Mapping[str, Any],
    *,
    allowed_ids: Sequence[str],
    priority_ids: Sequence[str],
) -> dict[str, Any]:
    if set(arguments) != {
        "outcome",
        "completion_condition",
        "addresses_criteria",
    }:
        raise FrameGoalSelectionError("frame_goal_fields_invalid")
    outcome = str(arguments.get("outcome") or "").strip()
    completion = str(arguments.get("completion_condition") or "").strip()
    raw_ids = arguments.get("addresses_criteria")
    if not outcome or len(outcome) > 1_000:
        raise FrameGoalSelectionError("frame_goal_outcome_invalid")
    if not completion or len(completion) > 1_000:
        raise FrameGoalSelectionError("frame_goal_completion_invalid")
    if isinstance(raw_ids, (str, bytes)) or not isinstance(raw_ids, Sequence):
        raise FrameGoalSelectionError("frame_goal_criteria_invalid")
    criterion_ids = [str(item).strip() for item in raw_ids]
    if (
        not criterion_ids
        or any(not item for item in criterion_ids)
        or len(criterion_ids) != len(set(criterion_ids))
        or not set(criterion_ids) <= set(allowed_ids)
    ):
        raise FrameGoalSelectionError("frame_goal_criteria_invalid")
    if priority_ids and not set(criterion_ids) & set(priority_ids):
        raise FrameGoalSelectionError(
            "frame_goal_must_address_priority_criterion"
        )
    return {
        "node_id": FRAME_GOAL_NODE_ID,
        "outcome": outcome,
        "completion_condition": completion,
        "addresses_criteria": criterion_ids,
        "decision_boundary": False,
        "depends_on": [],
        "transitions": [],
        "selected_transition_id": "",
        "status": "pending",
        "attempt_refs": [],
        "completion_refs": [],
    }


def _frame_goal_tool(criterion_ids: Sequence[str]) -> dict[str, Any]:
    return function_tool(
        "submit_frame_goal",
        "Submit exactly one bounded current-Frame goal, not a work graph.",
        {
            "type": "object",
            "properties": {
                "outcome": {"type": "string", "minLength": 1, "maxLength": 1000},
                "completion_condition": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 1000,
                },
                "addresses_criteria": {
                    "type": "array",
                    "minItems": 1,
                    "uniqueItems": True,
                    "items": {"type": "string", "enum": list(criterion_ids)},
                },
            },
            "required": [
                "outcome",
                "completion_condition",
                "addresses_criteria",
            ],
            "additionalProperties": False,
        },
    )


def _node_projection(node: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "node_id": str(node.get("node_id") or ""),
        "outcome": str(node.get("outcome") or ""),
        "completion_condition": str(node.get("completion_condition") or ""),
        "addresses_criteria": [
            str(item) for item in node.get("addresses_criteria") or ()
        ],
        "completion_refs": [str(item) for item in node.get("completion_refs") or ()],
    }


def _prompt_sources(payload: Mapping[str, Any]) -> tuple[PromptSource, ...]:
    return (
        PromptSource("instruction", "frame_goal_instruction", _SYSTEM_PROMPT),
        PromptSource(
            "C0",
            "frame_goal_global_horizon",
            payload.get("global_horizon"),
        ),
        PromptSource(
            "C1",
            "frame_goal_trigger_and_history",
            {
                "new_frame_trigger": payload.get("new_frame_trigger"),
                "previous_frame_goal": payload.get("previous_frame_goal"),
                "accepted_completed_outcomes": payload.get(
                    "accepted_completed_outcomes"
                ),
            },
        ),
        PromptSource(
            "C2",
            "frame_goal_accepted_artifacts",
            payload.get("accepted_artifact_index"),
        ),
        PromptSource(
            "C5",
            "frame_goal_format_repair",
            payload.get("format_repair"),
        ),
    )
