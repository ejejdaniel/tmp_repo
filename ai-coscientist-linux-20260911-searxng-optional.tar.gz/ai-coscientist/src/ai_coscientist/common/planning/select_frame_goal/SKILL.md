---
name: select-frame-goal
description: Selects one bounded Frame goal from the Global horizon before a new Frame graph is built. It does not build the graph or execute task work.
estimated_complexity: low
---

# Select Frame Goal

This is private common planning infrastructure. It is not a selectable domain
skill and does not execute scientific work.

## Responsibility

Choose exactly one locally judgeable outcome for the next Frame. Global
Evaluation is a long-horizon authority, not the current Frame's work list. The
selected goal may advance one or several Global criteria, but it never needs to
cover every unmet criterion.

## Scale rule

Start from the event that requires a new Frame and choose the nearest formal
outcome that resolves or advances that event. Stop at the first boundary after
which the route depends on information that does not exist yet, including:

- a human answer or choice;
- an evaluator, reviewer, or Final-LCA result;
- newly retrieved or computed evidence;
- an experiment or scientific result whose value determines the next route;
- discovery that a required source or capability is unavailable.

Work after that boundary belongs to a later Frame. Do not use "continue the
mission", "finish all remaining work", or an inventory of Global deliverables
as a Frame goal.

When a human-confirmed requirement triggered the new Frame, normally select the
nearest accepted result that answers that requirement. Do not also plan how the
answer will be used after it exists. When the trigger supplies explicit
`priority_criterion_ids`, the Frame goal must advance at least one of them.
It may also cite another criterion only when the same single accepted outcome
naturally supplies evidence for that criterion without adding another work
route. Criterion count is not a Frame-size measure. When the prior Frame completed normally,
select the next causally available outcome from accepted evidence and remaining
Global requirements.

## Formal outcome identity

The Global horizon and task contract own the requested scientific meaning.
Narrow the scope of work, not the meaning of the requested result. Preserve the
required operation or relationship, its comparison basis, and any task-defined
quantity or criterion when writing `outcome` and `completion_condition`.
Available evidence describes the starting point; it does not redefine success.
When the previous evaluation identifies a missing result, state what evidence
would establish that result, not merely how to rename or republish its inputs.
Input values and intermediate results are not expected answers to a different
operation. Reuse accepted evidence when it already establishes the same result;
do not require another calculation or publication just because a new Frame opens.

The supplied capability descriptions explain existing results and their limits,
not a mandatory workflow. Distinguish the evidence already produced from the
operation or comparison still required by the task. Carry that meaning into
the existing `outcome` and `completion_condition`, so downstream planning can
work on this Frame without reconstructing the Global mission. Mapping the
selected outcome to skills, routes and executable prerequisites still belongs
to the downstream Graph planner.

Do not infer a canonical artifact kind from generic prose nouns such as
`document`, `report`, `result`, or `analysis`. Bind the Frame goal to a canonical
kind only when the task explicitly names it or the capability definitions
establish that it represents the requested scientific result. Otherwise describe
the outcome in the task's own language and leave its implementation identity
unspecified. Do not turn an upstream
scientific result into a presentation derivative merely because the task asks
for a written document.

## Output

Return only the existing Frame-goal semantics:

- `outcome`: the one result this Frame should establish;
- `completion_condition`: exact accepted evidence that lets the Frame evaluator
  judge that result at Frame end;
- `addresses_criteria`: one or more applicable unmet Global criterion ids used
  only for traceability.

The runtime owns the reserved goal id, dependencies, status, attempts, and
completion evidence. This stage does not build work nodes or graph edges.
