from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ..._runtime_support import function_tool
from ...evaluation.evaluator import (
    _evaluation_read_request,
    _evidence_projection,
    _read_evidence_tool,
    evidence_completeness_instruction,
)
from ...reference_links import SOURCE_CONTENT_PREFIXES, evidence_ref_strings, source_ref
from ...memory_lifecycle.prompt import bounded_text
from ...memory_lifecycle.policy import PromptSource
from ...model import ChatModel, ModelTurn, complete_model_turn, retry_model_turn_without_reasoning
from ...openai_compatible import ModelProtocolError
from ..graph import (
    FRAME_GOAL_NODE_ID,
    MAX_PLAN_GRAPH_NODES,
    TASK_START_NODE_ID,
    build_plan_graph,
    validate_plan_graph,
)


_ROOT = Path(__file__).resolve().parent
_SKILL_ROOT = (_ROOT / "SKILL.md").read_text(encoding="utf-8")
_CAUSAL_GRAPH_BATCH_SIZE = 1
_CONDITIONAL_GRAPH_BATCH_SIZE = 3
_WORK_UNIT_REASON_LIMIT = 500
_DETAIL_ONLY_STAGE_PAGES = frozenset({"progress.md"})


class _ConditionalCausalConflict(ValueError):
    def __init__(self, changes: Sequence[Mapping[str, Any]]) -> None:
        self.changes = tuple(dict(item) for item in changes)
        super().__init__(
            "conditional_stage_proposed_causal_dependency_changes:"
            + json.dumps(self.changes, ensure_ascii=False)
        )


def create_initial_plan(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    objective: str,
    evaluation_gate: Mapping[str, Any],
    evaluation_state: Mapping[str, Any],
    mission_packet: Mapping[str, Any] | None,
    resolved_artifacts: Sequence[Mapping[str, Any]],
    current_issue: str,
    skill_summaries: Sequence[Mapping[str, str]],
    revision: int,
    causal_skill_summaries: Sequence[Mapping[str, str]] | None = None,
    frame_goal: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build one Frame graph after its goal has been selected."""
    if frame_goal is None:
        criteria, stop_criteria = _evaluation_contract(
            evaluation_gate,
            evaluation_state,
        )
    else:
        criteria, stop_criteria = _frame_goal_contract(frame_goal)
    remaining_ids = [
        item["criterion_id"] for item in criteria if item["status"] != "met"
    ]
    if not remaining_ids:
        raise RuntimeError("planning_not_required_all_success_criteria_met")
    causal_capabilities = (
        [dict(item) for item in causal_skill_summaries]
        if causal_skill_summaries is not None
        else [dict(item) for item in skill_summaries]
    )

    state_card = _current_state_card(
        criteria=criteria,
        stop_criteria=stop_criteria,
        resolved_artifacts=resolved_artifacts,
        current_issue=current_issue,
    )
    p0_payload: dict[str, Any] = {
        "objective": objective,
        "current_state": state_card,
        "available_skill_summaries": [
            dict(item) for item in skill_summaries
        ],
    }
    if frame_goal is not None:
        p0_payload["frame_goal"] = {
            "node_id": FRAME_GOAL_NODE_ID,
            "outcome": str(frame_goal["outcome"]),
            "completion_condition": str(frame_goal["completion_condition"]),
            "addresses_criteria": list(frame_goal["addresses_criteria"]),
        }
    if mission_packet:
        p0_payload["mission_packet"] = dict(mission_packet)

    p0_arguments = _call_validated_outcome_stage(
        model=model,
        memory=memory,
        events=events,
        purpose="initial common-agent plan: coarse outcome inventory",
        page="p0.md",
        payload=p0_payload,
        tool_name="submit_p0_graph",
        remaining_criterion_ids=remaining_ids,
        forbidden_node_ids=(FRAME_GOAL_NODE_ID,),
    )
    outcome_nodes = [
        {
            key: item[key]
            for key in (
                "node_id",
                "outcome",
                "completion_condition",
                "addresses_criteria",
            )
        }
        for item in p0_arguments["nodes"]
    ]
    causal_nodes = [
        {
            **dict(item),
            "decision_boundary": False,
            "depends_on": [],
            "transitions": [],
        }
        for item in outcome_nodes
    ]
    pending_causal_ids = [str(item["node_id"]) for item in causal_nodes]
    reviewed_causal_ids: set[str] = set()
    while pending_causal_ids:
        focus_node_ids = pending_causal_ids[:_CAUSAL_GRAPH_BATCH_SIZE]
        del pending_causal_ids[:_CAUSAL_GRAPH_BATCH_SIZE]
        focus_criterion_ids = {
            str(criterion_id)
            for item in causal_nodes
            if str(item["node_id"]) in focus_node_ids
            for criterion_id in item["addresses_criteria"]
        }
        causal_payload: dict[str, Any] = {
            "objective": objective,
            "current_state": {
                **state_card,
                "remaining_criteria": [
                    dict(item)
                    for item in state_card["remaining_criteria"]
                    if str(item["criterion_id"]) in focus_criterion_ids
                ],
            },
            "focus_node_ids": focus_node_ids,
            "causal_graph": [dict(item) for item in causal_nodes],
            "available_skill_summaries": [
                dict(item) for item in causal_capabilities
            ],
        }
        if mission_packet:
            causal_payload["mission_packet"] = dict(mission_packet)
        causal_arguments = _call_validated_causal_stage(
            model=model,
            memory=memory,
            events=events,
            purpose=(
                "initial common-agent plan: causal dependencies for "
                + ", ".join(focus_node_ids)
            ),
            payload=causal_payload,
            remaining_criterion_ids=remaining_ids,
            previous_nodes=causal_nodes,
            focus_node_ids=focus_node_ids,
        )
        previous_ids = {str(item["node_id"]) for item in causal_nodes}
        causal_nodes = [dict(item) for item in causal_arguments["nodes"]]
        reviewed_causal_ids.update(focus_node_ids)
        for item in causal_nodes:
            node_id = str(item["node_id"])
            if (
                node_id not in previous_ids
                and node_id not in reviewed_causal_ids
                and node_id not in pending_causal_ids
            ):
                pending_causal_ids.append(node_id)

    conditional_nodes = _construct_conditional_graph(
        model=model,
        memory=memory,
        events=events,
        state_card=state_card,
        causal_nodes=causal_nodes,
        skill_summaries=causal_capabilities,
        remaining_criterion_ids=remaining_ids,
        objective=objective,
        mission_packet=mission_packet,
    )
    graph = build_plan_graph(
        conditional_nodes,
        revision=revision,
        goal_node_id=FRAME_GOAL_NODE_ID,
        goal_criteria=[item["criterion_id"] for item in criteria],
    )
    if frame_goal is not None:
        goal = next(
            node
            for node in graph["nodes"]
            if str(node["node_id"]) == FRAME_GOAL_NODE_ID
        )
        goal["outcome"] = str(frame_goal["outcome"])
        goal["completion_condition"] = str(
            frame_goal["completion_condition"]
        )
        goal["addresses_criteria"] = list(
            frame_goal["addresses_criteria"]
        )
        validate_plan_graph(graph)
    return graph


def _call_validated_outcome_stage(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    purpose: str,
    page: str,
    payload: Mapping[str, Any],
    tool_name: str,
    remaining_criterion_ids: Sequence[str],
    forbidden_node_ids: Sequence[str] = (),
) -> Mapping[str, Any]:
    tool = _outcome_inventory_tool(tool_name, remaining_criterion_ids)
    arguments = _call_stage(
        model=model,
        memory=memory,
        events=events,
        purpose=purpose,
        page=page,
        payload=payload,
        tool=tool,
        allow_protocol_repair=False,
        planning_call=True,
    )
    arguments = _defer_unaddressed_outcomes(
        arguments,
        events=events,
        purpose=purpose,
    )
    try:
        _validate_outcome_stage_result(
            arguments,
            remaining_criterion_ids=remaining_criterion_ids,
            forbidden_node_ids=forbidden_node_ids,
        )
        return arguments
    except ValueError as exc:
        issue = str(exc)

    events.append(
        "plan_stage_structural_repair_requested",
        {
            "purpose": purpose,
            "page": page,
            "issue": issue,
        },
    )
    repaired = _call_stage(
        model=model,
        memory=memory,
        events=events,
        purpose=f"{purpose}: structural repair",
        page=page,
        payload=_outcome_repair_payload(
            payload=payload,
            previous_nodes=arguments.get("nodes", ()),
            issue=issue,
        ),
        tool=tool,
        allow_protocol_repair=False,
        include_structural_repair_instruction=True,
        repair_call=True,
    )
    repaired = _defer_unaddressed_outcomes(
        repaired,
        events=events,
        purpose=f"{purpose}: structural repair",
    )
    _validate_outcome_stage_result(
        repaired,
        remaining_criterion_ids=remaining_criterion_ids,
        forbidden_node_ids=forbidden_node_ids,
    )
    return repaired


def _defer_unaddressed_outcomes(
    arguments: Mapping[str, Any],
    *,
    events: Any,
    purpose: str,
) -> Mapping[str, Any]:
    """Defer structurally identifiable prerequisites to causal construction."""
    raw_nodes = arguments.get("nodes")
    if not isinstance(raw_nodes, Sequence) or isinstance(
        raw_nodes, (str, bytes, bytearray)
    ):
        return arguments
    kept: list[Any] = []
    deferred_ids: list[str] = []
    for raw_node in raw_nodes:
        addresses = raw_node.get("addresses_criteria") if isinstance(
            raw_node, Mapping
        ) else None
        if (
            isinstance(addresses, Sequence)
            and not isinstance(addresses, (str, bytes, bytearray))
            and not addresses
        ):
            deferred_ids.append(str(raw_node.get("node_id") or "<missing>"))
            continue
        kept.append(raw_node)
    if not deferred_ids:
        return arguments
    events.append(
        "plan_stage_unaddressed_outcomes_deferred",
        {
            "purpose": purpose,
            "node_ids": deferred_ids,
            "reason": "causal_stage_owns_external_prerequisites",
        },
    )
    return {**dict(arguments), "nodes": kept}


def _outcome_repair_payload(
    *,
    payload: Mapping[str, Any],
    previous_nodes: Any,
    issue: str,
) -> dict[str, Any]:
    nodes = (
        previous_nodes
        if isinstance(previous_nodes, Sequence)
        and not isinstance(previous_nodes, (str, bytes, bytearray))
        else ()
    )
    return {
        **dict(payload),
        "previous_nodes": [
            dict(item) for item in nodes if isinstance(item, Mapping)
        ],
        "structural_validation_issue": issue,
    }


def _call_validated_causal_stage(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    purpose: str,
    payload: Mapping[str, Any],
    remaining_criterion_ids: Sequence[str],
    previous_nodes: Sequence[Mapping[str, Any]],
    focus_node_ids: Sequence[str],
) -> Mapping[str, Any]:
    tool = _plan_graph_tool(
        "submit_causal_graph",
        remaining_criterion_ids,
        description=(
            "Submit only the requested focus nodes and any new formal "
            "prerequisite nodes. Non-focus nodes are merged mechanically."
        ),
    )
    arguments = _call_stage(
        model=model,
        memory=memory,
        events=events,
        purpose=purpose,
        page="causal-graph.md",
        payload=payload,
        tool=tool,
        allow_protocol_repair=False,
        budget_tier="full",
        planning_call=True,
    )
    try:
        return _merge_validated_causal_focus_result(
            arguments,
            remaining_criterion_ids=remaining_criterion_ids,
            previous_nodes=previous_nodes,
            focus_node_ids=focus_node_ids,
        )
    except ValueError as exc:
        issue = str(exc)

    events.append(
        "plan_stage_structural_repair_requested",
        {
            "purpose": purpose,
            "page": "causal-graph.md",
            "issue": issue,
        },
    )
    repaired = _call_stage(
        model=model,
        memory=memory,
        events=events,
        purpose=f"{purpose}: structural repair",
        page="causal-graph.md",
        payload={
            **dict(payload),
            "previous_nodes": [dict(item) for item in arguments.get("nodes", ())],
            "structural_validation_issue": issue,
        },
        tool=tool,
        allow_protocol_repair=False,
        include_structural_repair_instruction=False,
        budget_tier="full",
        repair_call=True,
    )
    return _merge_validated_causal_focus_result(
        repaired,
        remaining_criterion_ids=remaining_criterion_ids,
        previous_nodes=previous_nodes,
        focus_node_ids=focus_node_ids,
    )


def _merge_validated_causal_focus_result(
    arguments: Mapping[str, Any],
    *,
    remaining_criterion_ids: Sequence[str],
    previous_nodes: Sequence[Mapping[str, Any]],
    focus_node_ids: Sequence[str],
) -> dict[str, Any]:
    raw_nodes = arguments.get("nodes")
    if not isinstance(raw_nodes, Sequence) or isinstance(
        raw_nodes, (str, bytes, bytearray)
    ):
        raise ValueError("causal_focus_nodes_must_be_sequence")
    expected_fields = {
        "node_id",
        "outcome",
        "completion_condition",
        "addresses_criteria",
        "decision_boundary",
        "depends_on",
        "transitions",
    }
    invalid_shapes = [
        index
        for index, item in enumerate(raw_nodes, start=1)
        if not isinstance(item, Mapping) or set(item) != expected_fields
    ]
    if invalid_shapes:
        raise ValueError(
            "causal_focus_node_fields_invalid:"
            f"{invalid_shapes}"
        )
    before = {str(item["node_id"]): dict(item) for item in previous_nodes}
    submitted = {str(item["node_id"]): dict(item) for item in raw_nodes}
    if len(submitted) != len(raw_nodes):
        raise ValueError("causal_focus_submitted_node_ids_must_be_unique")
    focus = set(str(node_id) for node_id in focus_node_ids)
    if not focus or not focus <= set(before):
        raise ValueError("causal_focus_node_ids_invalid")
    missing_focus = sorted(focus - set(submitted))
    if missing_focus:
        raise ValueError(f"causal_focus_nodes_missing:{missing_focus}")
    submitted_focus = {node_id: submitted[node_id] for node_id in focus}
    candidate_new_nodes = {
        node_id: item
        for node_id, item in submitted.items()
        if node_id not in before
    }
    reachable_new_ids: set[str] = set()
    pending_dependencies = [
        str(dependency_id)
        for node in submitted_focus.values()
        for dependency_id in node["depends_on"]
    ]
    while pending_dependencies:
        dependency_id = pending_dependencies.pop()
        if dependency_id in reachable_new_ids:
            continue
        candidate = candidate_new_nodes.get(dependency_id)
        if candidate is None:
            continue
        reachable_new_ids.add(dependency_id)
        pending_dependencies.extend(
            str(item) for item in candidate["depends_on"]
        )
    new_nodes = {
        node_id: candidate_new_nodes[node_id]
        for node_id in reachable_new_ids
    }
    focus_criteria = {
        str(criterion_id)
        for node_id in focus
        for criterion_id in before[node_id]["addresses_criteria"]
    }
    invalid_new_addresses: list[str] = []
    for node_id, item in new_nodes.items():
        raw_addresses = item["addresses_criteria"]
        if (
            not isinstance(raw_addresses, Sequence)
            or isinstance(raw_addresses, (str, bytes, bytearray))
            or not raw_addresses
            or not set(str(value) for value in raw_addresses) <= focus_criteria
        ):
            if len(focus_criteria) == 1:
                normalized = dict(item)
                normalized["addresses_criteria"] = sorted(focus_criteria)
                new_nodes[node_id] = normalized
            else:
                invalid_new_addresses.append(node_id)
    if invalid_new_addresses:
        raise ValueError(
            "causal_focus_new_prerequisite_addresses_criteria_invalid:"
            f"nodes={sorted(invalid_new_addresses)}:"
            f"allowed={sorted(focus_criteria)}"
        )
    after = {
        **before,
        **submitted_focus,
        **new_nodes,
    }
    immutable_fields = (
        "node_id",
        "outcome",
        "completion_condition",
        "addresses_criteria",
        "decision_boundary",
        "transitions",
    )
    changed_focus_semantics = sorted(
        node_id
        for node_id in focus
        if any(
            after[node_id][field] != before[node_id][field]
            for field in immutable_fields
        )
    )
    if changed_focus_semantics:
        raise ValueError(
            "causal_focus_changed_formal_outcome:"
            f"{changed_focus_semantics}"
        )

    new_ids = set(new_nodes)
    merged_nodes = [
        dict(after[str(item["node_id"])]) for item in previous_nodes
    ]
    merged_nodes.extend(dict(item) for item in new_nodes.values())
    merged = {"nodes": merged_nodes}
    _validate_graph_stage_result(
        merged,
        remaining_criterion_ids=remaining_criterion_ids,
        require_plain_dag=True,
    )
    if not new_ids:
        return merged
    invalid_new_criteria = sorted(
        node_id
        for node_id in new_ids
        if not set(after[node_id]["addresses_criteria"]) <= focus_criteria
    )
    if invalid_new_criteria:
        raise ValueError(
            "causal_focus_new_prerequisite_criteria_invalid:"
            f"{invalid_new_criteria}"
        )

    by_id = {str(item["node_id"]): item for item in merged_nodes}

    def ancestors(node_id: str) -> set[str]:
        found: set[str] = set()
        pending = [str(item) for item in by_id[node_id]["depends_on"]]
        while pending:
            dependency_id = pending.pop()
            if dependency_id in found:
                continue
            found.add(dependency_id)
            pending.extend(
                str(item) for item in by_id[dependency_id]["depends_on"]
            )
        return found

    used_new_ids = {
        node_id
        for focus_id in focus
        for node_id in ancestors(focus_id)
        if node_id in new_ids
    }
    unused_new_ids = sorted(new_ids - used_new_ids)
    if unused_new_ids:
        raise ValueError(
            "causal_focus_new_node_must_be_focus_prerequisite:"
            f"{unused_new_ids}"
        )
    return merged


def _construct_conditional_graph(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    state_card: Mapping[str, Any],
    causal_nodes: Sequence[Mapping[str, Any]],
    skill_summaries: Sequence[Mapping[str, str]],
    remaining_criterion_ids: Sequence[str],
    objective: str,
    mission_packet: Mapping[str, Any] | None,
) -> list[dict[str, Any]]:
    """Build conditional edges, returning dependency disputes to causal review."""
    authoritative_nodes = [dict(item) for item in causal_nodes]
    reviewed_proposals: set[tuple[str, tuple[str, ...]]] = set()
    rejected_causal_claims: set[tuple[str, str]] = set()
    conditional_issue = ""

    while True:
        conditional_nodes = [dict(item) for item in authoritative_nodes]
        ordered_node_ids = [str(item["node_id"]) for item in conditional_nodes]
        try:
            for offset in range(
                0,
                len(ordered_node_ids),
                _CONDITIONAL_GRAPH_BATCH_SIZE,
            ):
                focus_node_ids = ordered_node_ids[
                    offset : offset + _CONDITIONAL_GRAPH_BATCH_SIZE
                ]
                # Conditional construction classifies task-defined result
                # branches. Formal evidence and capability descriptions were
                # already consumed while inventorying outcomes and causal
                # prerequisites; repeating them here obscures the graph that
                # this stage must review.
                branch_state = {
                    "remaining_criteria": [
                        dict(item)
                        for item in state_card["remaining_criteria"]
                    ],
                    "legal_stop_criteria": [
                        dict(item)
                        for item in state_card["legal_stop_criteria"]
                    ],
                    "current_issue": str(
                        state_card.get("current_issue") or ""
                    ),
                }
                if conditional_issue:
                    branch_state["current_issue"] = bounded_text(
                        "\n\n".join(
                            part
                            for part in (
                                str(state_card.get("current_issue") or "").strip(),
                                conditional_issue,
                            )
                            if part
                        ),
                        2_000,
                    )
                branch_payload: dict[str, Any] = {
                    "objective": objective,
                    "current_state": branch_state,
                    "focus_node_ids": focus_node_ids,
                    "causal_graph": [dict(item) for item in conditional_nodes],
                }
                if mission_packet:
                    branch_payload["mission_packet"] = dict(mission_packet)
                branch_arguments = _call_validated_conditional_stage(
                    model=model,
                    memory=memory,
                    events=events,
                    purpose=(
                        "initial common-agent plan: conditional transitions for "
                        + ", ".join(focus_node_ids)
                    ),
                    payload=branch_payload,
                    remaining_criterion_ids=remaining_criterion_ids,
                    previous_nodes=conditional_nodes,
                    focus_node_ids=focus_node_ids,
                    rejected_causal_claims=sorted(rejected_causal_claims),
                )
                conditional_nodes = [
                    dict(item) for item in branch_arguments["nodes"]
                ]
            return conditional_nodes
        except _ConditionalCausalConflict as conflict:
            proposal_keys = {
                (
                    str(item["node_id"]),
                    tuple(str(dep) for dep in item["proposed_depends_on"]),
                )
                for item in conflict.changes
            }
            repeated = sorted(proposal_keys & reviewed_proposals)
            if repeated:
                raise ValueError(
                    "conditional_causal_conflict_persisted_after_review:"
                    f"{repeated}"
                ) from conflict
            reviewed_proposals.update(proposal_keys)

            events.append(
                "plan_stage_causal_reconsideration_started",
                {
                    "changes": [dict(item) for item in conflict.changes],
                },
            )
            rejected_now: set[tuple[str, str]] = set()
            for change in conflict.changes:
                node_id = str(change["node_id"])
                focus_node = next(
                    item
                    for item in authoritative_nodes
                    if str(item["node_id"]) == node_id
                )
                focus_criteria = {
                    str(item) for item in focus_node["addresses_criteria"]
                }
                if change.get("mutually_exclusive_targets"):
                    review_issue = bounded_text(
                        "Conditional branch construction claimed that "
                        f"{change['mutually_exclusive_targets']} are mutually "
                        f"exclusive outcomes, while {node_id} currently consumes "
                        "both lineages. Re-evaluate only the direct formal inputs "
                        "consumed by this outcome from the capability descriptions. "
                        "Do not remove an input merely to make the conditional "
                        "claim valid.",
                        2_000,
                    )
                else:
                    review_issue = bounded_text(
                        "Conditional branch construction proposed changing causal "
                        f"dependencies for {node_id} from "
                        f"{change['authoritative_depends_on']} to "
                        f"{change['proposed_depends_on']}. Re-evaluate only the "
                        "direct formal inputs consumed by this outcome from the "
                        "capability descriptions. Do not accept the proposal merely "
                        "because the conditional stage proposed it.",
                        2_000,
                    )
                review_state = {
                    **dict(state_card),
                    "remaining_criteria": [
                        dict(item)
                        for item in state_card["remaining_criteria"]
                        if str(item["criterion_id"]) in focus_criteria
                    ],
                    "current_issue": review_issue,
                }
                causal_payload = {
                    "objective": objective,
                    "current_state": review_state,
                    "focus_node_ids": [node_id],
                    "causal_graph": [dict(item) for item in authoritative_nodes],
                    "available_skill_summaries": [
                        dict(item) for item in skill_summaries
                    ],
                }
                if mission_packet:
                    causal_payload["mission_packet"] = dict(mission_packet)
                reviewed = _call_validated_causal_stage(
                    model=model,
                    memory=memory,
                    events=events,
                    purpose=(
                        "initial common-agent plan: causal reconsideration for "
                        f"{node_id}"
                    ),
                    payload=causal_payload,
                    remaining_criterion_ids=remaining_criterion_ids,
                    previous_nodes=authoritative_nodes,
                    focus_node_ids=[node_id],
                )
                authoritative_nodes = [
                    dict(item) for item in reviewed["nodes"]
                ]
                reviewed_node = next(
                    item
                    for item in authoritative_nodes
                    if str(item["node_id"]) == node_id
                )
                if list(reviewed_node["depends_on"]) == list(
                    change["authoritative_depends_on"]
                ):
                    for edge in change.get("rejected_transition_edges", ()):
                        if (
                            isinstance(edge, Sequence)
                            and not isinstance(edge, (str, bytes, bytearray))
                            and len(edge) == 2
                        ):
                            rejected_now.add((str(edge[0]), str(edge[1])))

            if rejected_now:
                rejected_causal_claims.update(rejected_now)
                events.append(
                    "plan_stage_rejected_causal_claims_recorded",
                    {
                        "rejected_edges": [list(item) for item in sorted(rejected_now)],
                    },
                )

            conditional_issue = bounded_text(
                "Causal dependency reconsideration completed. The causal graph "
                "now shown in this prompt is authoritative. "
                + (
                    "Rejected conditional edges are removed mechanically: "
                    f"{sorted(rejected_now)}. "
                    if rejected_now
                    else ""
                )
                + "Construct conditions against the reviewed graph; do not "
                "rewrite depends_on fields.",
                2_000,
            )
            events.append(
                "plan_stage_causal_reconsideration_completed",
                {
                    "changes": [dict(item) for item in conflict.changes],
                    "causal_graph": [dict(item) for item in authoritative_nodes],
                },
            )


def _call_validated_conditional_stage(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    purpose: str,
    payload: Mapping[str, Any],
    remaining_criterion_ids: Sequence[str],
    previous_nodes: Sequence[Mapping[str, Any]],
    focus_node_ids: Sequence[str],
    rejected_causal_claims: Sequence[tuple[str, str]] = (),
) -> Mapping[str, Any]:
    """Review a bounded node batch without reconstructing the whole graph."""
    tool = _plan_graph_tool(
        "submit_conditional_graph",
        remaining_criterion_ids,
        description=(
            "Submit only the requested focus nodes. Non-focus nodes are "
            "preserved and merged mechanically."
        ),
    )
    arguments = _call_stage(
        model=model,
        memory=memory,
        events=events,
        purpose=purpose,
        page="conditional-graph.md",
        payload=payload,
        tool=tool,
        allow_protocol_repair=False,
        budget_tier="full",
        planning_call=True,
    )
    arguments, collapsed = _collapse_control_equivalent_decisions(arguments)
    if collapsed:
        events.append(
            "plan_stage_control_equivalent_decisions_collapsed",
            {
                "purpose": purpose,
                "page": "conditional-graph.md",
                "collapsed": collapsed,
            },
        )
    arguments, sanitized = _sanitize_rejected_causal_claims(
        arguments,
        previous_nodes=previous_nodes,
        rejected_causal_claims=rejected_causal_claims,
    )
    if sanitized:
        events.append(
            "plan_stage_rejected_causal_claims_sanitized",
            {
                "purpose": purpose,
                "page": "conditional-graph.md",
                "sanitized": sanitized,
            },
        )
    dependency_changes = _conditional_dependency_changes(
        arguments,
        previous_nodes=previous_nodes,
        focus_node_ids=focus_node_ids,
    )
    if dependency_changes:
        events.append(
            "plan_stage_conditional_causal_conflict",
            {
                "purpose": purpose,
                "page": "conditional-graph.md",
                "changes": dependency_changes,
            },
        )
        raise _ConditionalCausalConflict(dependency_changes)
    try:
        return _merge_validated_conditional_focus_result(
            arguments,
            remaining_criterion_ids=remaining_criterion_ids,
            previous_nodes=previous_nodes,
            focus_node_ids=focus_node_ids,
        )
    except ValueError as exc:
        issue = str(exc)

    events.append(
        "plan_stage_structural_repair_requested",
        {
            "purpose": purpose,
            "page": "conditional-graph.md",
            "issue": issue,
        },
    )
    repaired = _call_stage(
        model=model,
        memory=memory,
        events=events,
        purpose=f"{purpose}: structural repair",
        page="conditional-graph.md",
        payload={
            **dict(payload),
            "previous_nodes": [
                dict(item) for item in arguments.get("nodes", ())
            ],
            "structural_validation_issue": issue,
        },
        tool=tool,
        allow_protocol_repair=False,
        include_structural_repair_instruction=False,
        budget_tier="full",
        repair_call=True,
    )
    repaired, collapsed = _collapse_control_equivalent_decisions(repaired)
    if collapsed:
        events.append(
            "plan_stage_control_equivalent_decisions_collapsed",
            {
                "purpose": f"{purpose}: structural repair",
                "page": "conditional-graph.md",
                "collapsed": collapsed,
            },
        )
    repaired, sanitized = _sanitize_rejected_causal_claims(
        repaired,
        previous_nodes=previous_nodes,
        rejected_causal_claims=rejected_causal_claims,
    )
    if sanitized:
        events.append(
            "plan_stage_rejected_causal_claims_sanitized",
            {
                "purpose": f"{purpose}: structural repair",
                "page": "conditional-graph.md",
                "sanitized": sanitized,
            },
        )
    dependency_changes = _conditional_dependency_changes(
        repaired,
        previous_nodes=previous_nodes,
        focus_node_ids=focus_node_ids,
    )
    if dependency_changes:
        events.append(
            "plan_stage_conditional_causal_conflict",
            {
                "purpose": f"{purpose}: structural repair",
                "page": "conditional-graph.md",
                "changes": dependency_changes,
            },
        )
        raise _ConditionalCausalConflict(dependency_changes)
    try:
        return _merge_validated_conditional_focus_result(
            repaired,
            remaining_criterion_ids=remaining_criterion_ids,
            previous_nodes=previous_nodes,
            focus_node_ids=focus_node_ids,
        )
    except ValueError as exc:
        dependency_changes = _forward_edge_causal_conflict(
            str(exc),
            previous_nodes=previous_nodes,
        )
        if not dependency_changes:
            dependency_changes = _exclusive_join_causal_conflict(
                str(exc),
                previous_nodes=previous_nodes,
            )
        if not dependency_changes:
            raise
        events.append(
            "plan_stage_conditional_causal_conflict",
            {
                "purpose": f"{purpose}: structural repair exhausted",
                "page": "conditional-graph.md",
                "changes": dependency_changes,
                "reason": str(exc),
            },
        )
        raise _ConditionalCausalConflict(dependency_changes) from exc


def _collapse_control_equivalent_decisions(
    arguments: Mapping[str, Any],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Remove branches whose conditions cannot change graph control flow."""
    normalized = dict(arguments)
    raw_nodes = arguments.get("nodes")
    if not isinstance(raw_nodes, Sequence) or isinstance(
        raw_nodes, (str, bytes, bytearray)
    ):
        return normalized, []

    nodes: list[Any] = []
    collapsed: list[dict[str, Any]] = []
    for raw_node in raw_nodes:
        if not isinstance(raw_node, Mapping):
            nodes.append(raw_node)
            continue
        node = dict(raw_node)
        transitions = node.get("transitions")
        if (
            node.get("decision_boundary") is True
            and isinstance(transitions, Sequence)
            and not isinstance(transitions, (str, bytes, bytearray))
            and len(transitions) >= 2
            and all(isinstance(item, Mapping) for item in transitions)
        ):
            target_ids = [
                str(item.get("target_node_id") or "").strip()
                for item in transitions
            ]
            if target_ids and all(target_ids) and len(set(target_ids)) == 1:
                collapsed.append(
                    {
                        "node_id": str(node.get("node_id") or ""),
                        "target_node_id": target_ids[0],
                        "transition_ids": [
                            str(item.get("transition_id") or "")
                            for item in transitions
                        ],
                        "reason": "all declared results have identical control flow",
                    }
                )
                node["decision_boundary"] = False
                node["transitions"] = []
        nodes.append(node)
    normalized["nodes"] = nodes
    return normalized, collapsed


def _conditional_dependency_changes(
    arguments: Mapping[str, Any],
    *,
    previous_nodes: Sequence[Mapping[str, Any]],
    focus_node_ids: Sequence[str],
) -> list[dict[str, Any]]:
    """Describe dependency disputes without accepting either semantic claim."""
    raw_nodes = arguments.get("nodes")
    if not isinstance(raw_nodes, Sequence) or isinstance(
        raw_nodes, (str, bytes, bytearray)
    ):
        return []
    before = {str(item.get("node_id") or ""): item for item in previous_nodes}
    focus = {str(item) for item in focus_node_ids}
    changes: list[dict[str, Any]] = []
    for raw_node in raw_nodes:
        if not isinstance(raw_node, Mapping):
            continue
        node_id = str(raw_node.get("node_id") or "")
        if node_id not in focus:
            continue
        prior = before.get(node_id)
        if prior is not None and raw_node.get("depends_on") != prior.get("depends_on"):
            originating_edges = [
                [
                    str(candidate.get("node_id") or ""),
                    node_id,
                ]
                for candidate in raw_nodes
                if isinstance(candidate, Mapping)
                for transition in candidate.get("transitions", ())
                if isinstance(transition, Mapping)
                and str(transition.get("target_node_id") or "") == node_id
            ]
            changes.append(
                {
                    "node_id": node_id,
                    "proposed_depends_on": list(raw_node.get("depends_on") or ()),
                    "authoritative_depends_on": list(prior.get("depends_on") or ()),
                    "rejected_transition_edges": originating_edges,
                }
            )
    return changes


def _forward_edge_causal_conflict(
    issue: str,
    *,
    previous_nodes: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Project one repeatedly invalid forward edge back to causal review."""
    prefix = "plan_graph_forward_transition_requires_causal_dependency:"
    if not issue.startswith(prefix):
        return []
    parts = issue[len(prefix) :].split(":", 2)
    if len(parts) < 2:
        return []
    source_id, target_id = (part.strip() for part in parts[:2])
    by_id = {str(item.get("node_id") or ""): item for item in previous_nodes}
    target = by_id.get(target_id)
    if not source_id or target is None:
        return []
    authoritative = [str(item) for item in target.get("depends_on", ())]
    proposed = list(authoritative)
    if source_id not in proposed:
        proposed.append(source_id)
    return [
        {
            "node_id": target_id,
            "proposed_depends_on": proposed,
            "authoritative_depends_on": authoritative,
            "originating_transition_source": source_id,
            "rejected_transition_edges": [[source_id, target_id]],
        }
    ]


def _exclusive_join_causal_conflict(
    issue: str,
    *,
    previous_nodes: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Return an impossible exclusive-branch join to causal review."""
    prefix = "plan_graph_mutually_exclusive_branch_join:"
    if not issue.startswith(prefix):
        return []
    parts = issue[len(prefix) :].split(":", 2)
    if len(parts) != 3:
        return []
    source_id, join_id, raw_targets = (part.strip() for part in parts)
    try:
        targets = [str(item) for item in ast.literal_eval(raw_targets)]
    except (SyntaxError, ValueError, TypeError):
        return []
    by_id = {str(item.get("node_id") or ""): item for item in previous_nodes}
    join = by_id.get(join_id)
    if not source_id or join is None or len(targets) < 2:
        return []
    authoritative = [str(item) for item in join.get("depends_on", ())]
    return [
        {
            "node_id": join_id,
            "proposed_depends_on": authoritative,
            "authoritative_depends_on": authoritative,
            "mutually_exclusive_targets": targets,
            "rejected_transition_edges": [
                [source_id, target_id] for target_id in targets
            ],
        }
    ]


def _sanitize_rejected_causal_claims(
    arguments: Mapping[str, Any],
    *,
    previous_nodes: Sequence[Mapping[str, Any]],
    rejected_causal_claims: Sequence[tuple[str, str]],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Apply a completed causal review without interpreting scientific text."""
    rejected = {
        (str(source_id), str(target_id))
        for source_id, target_id in rejected_causal_claims
        if str(source_id) and str(target_id)
    }
    normalized = dict(arguments)
    raw_nodes = arguments.get("nodes")
    if not rejected or not isinstance(raw_nodes, Sequence) or isinstance(
        raw_nodes, (str, bytes, bytearray)
    ):
        return normalized, []

    before = {str(item.get("node_id") or ""): item for item in previous_nodes}
    nodes: list[Any] = []
    sanitized: list[dict[str, Any]] = []
    for raw_node in raw_nodes:
        if not isinstance(raw_node, Mapping):
            nodes.append(raw_node)
            continue
        node = dict(raw_node)
        node_id = str(node.get("node_id") or "")
        prior = before.get(node_id)
        rejected_sources = {
            source_id
            for source_id, target_id in rejected
            if target_id == node_id
        }
        if prior is not None and rejected_sources:
            proposed_dependencies = [
                str(item) for item in node.get("depends_on", ())
            ]
            if any(source_id in proposed_dependencies for source_id in rejected_sources):
                node["depends_on"] = list(prior.get("depends_on") or ())
                sanitized.append(
                    {
                        "node_id": node_id,
                        "restored_depends_on": list(node["depends_on"]),
                        "rejected_sources": sorted(rejected_sources),
                    }
                )

        transitions = node.get("transitions")
        if isinstance(transitions, Sequence) and not isinstance(
            transitions, (str, bytes, bytearray)
        ):
            kept = [
                dict(item) if isinstance(item, Mapping) else item
                for item in transitions
                if not (
                    isinstance(item, Mapping)
                    and (node_id, str(item.get("target_node_id") or ""))
                    in rejected
                )
            ]
            if len(kept) != len(transitions):
                removed_ids = [
                    str(item.get("transition_id") or "")
                    for item in transitions
                    if isinstance(item, Mapping)
                    and (node_id, str(item.get("target_node_id") or ""))
                    in rejected
                ]
                node["transitions"] = kept
                sanitized.append(
                    {
                        "node_id": node_id,
                        "removed_transition_ids": removed_ids,
                    }
                )
                remaining_targets = {
                    str(item.get("target_node_id") or "")
                    for item in kept
                    if isinstance(item, Mapping)
                }
                if len(kept) < 2 or len(remaining_targets) < 2:
                    node["decision_boundary"] = False
                    node["transitions"] = []
        nodes.append(node)
    normalized["nodes"] = nodes
    return normalized, sanitized


def _validate_graph_stage_result(
    arguments: Mapping[str, Any],
    *,
    remaining_criterion_ids: Sequence[str],
    require_plain_dag: bool = False,
) -> None:
    raw_nodes = arguments.get("nodes")
    if any(
        isinstance(node, Mapping)
        and str(node.get("node_id") or "").strip() == FRAME_GOAL_NODE_ID
        for node in raw_nodes or ()
    ):
        raise ValueError("plan_graph_reserved_goal_node_id_used_as_work")
    if any(
        isinstance(node, Mapping)
        and str(node.get("node_id") or "").strip() == TASK_START_NODE_ID
        for node in raw_nodes or ()
    ):
        raise ValueError("plan_graph_reserved_start_node_id_used_as_work")
    build_plan_graph(raw_nodes, revision=1)
    if require_plain_dag and any(
        bool(node["decision_boundary"]) or bool(node["transitions"])
        for node in raw_nodes
    ):
        raise ValueError(
            "causal_dependency_stage_must_leave_decisions_for_branch_review"
        )
    expected = set(remaining_criterion_ids)
    covered = {
        str(criterion_id)
        for node in raw_nodes
        for criterion_id in node["addresses_criteria"]
    }
    unknown = sorted(covered - expected)
    if unknown:
        raise ValueError(f"plan_graph_unknown_remaining_criteria:{unknown}")
    missing = sorted(expected - covered)
    if missing:
        raise ValueError(f"plan_graph_missing_remaining_criteria:{missing}")


def _merge_validated_conditional_focus_result(
    arguments: Mapping[str, Any],
    *,
    remaining_criterion_ids: Sequence[str],
    previous_nodes: Sequence[Mapping[str, Any]],
    focus_node_ids: Sequence[str],
) -> dict[str, Any]:
    raw_nodes = arguments.get("nodes")
    if not isinstance(raw_nodes, Sequence) or isinstance(
        raw_nodes, (str, bytes, bytearray)
    ):
        raise ValueError("conditional_focus_nodes_must_be_sequence")
    expected_fields = {
        "node_id",
        "outcome",
        "completion_condition",
        "addresses_criteria",
        "decision_boundary",
        "depends_on",
        "transitions",
    }
    invalid_shapes = [
        index
        for index, item in enumerate(raw_nodes, start=1)
        if not isinstance(item, Mapping) or set(item) != expected_fields
    ]
    if invalid_shapes:
        raise ValueError(
            "conditional_focus_node_fields_invalid:"
            f"{invalid_shapes}"
        )
    before = {str(item["node_id"]): dict(item) for item in previous_nodes}
    submitted = {str(item["node_id"]): dict(item) for item in raw_nodes}
    if len(submitted) != len(raw_nodes):
        raise ValueError("conditional_focus_submitted_node_ids_must_be_unique")
    focus = set(str(node_id) for node_id in focus_node_ids)
    if not focus or not focus <= set(before):
        raise ValueError("conditional_focus_node_ids_invalid")
    missing_focus = sorted(focus - set(submitted))
    if missing_focus:
        raise ValueError(f"conditional_focus_nodes_missing:{missing_focus}")
    unexpected_ids = sorted(set(submitted) - set(before))
    if unexpected_ids:
        raise ValueError(
            "conditional_focus_added_nodes_forbidden:"
            f"{unexpected_ids}"
        )
    after = {**before, **{node_id: submitted[node_id] for node_id in focus}}
    changed_criterion_addresses = sorted(
        node_id
        for node_id in focus
        if after[node_id]["addresses_criteria"]
        != before[node_id]["addresses_criteria"]
    )
    if changed_criterion_addresses:
        raise ValueError(
            "conditional_focus_changed_criterion_addresses:"
            f"{changed_criterion_addresses}"
        )
    changed_dependencies = sorted(
        node_id
        for node_id in focus
        if after[node_id]["depends_on"] != before[node_id]["depends_on"]
    )
    if changed_dependencies:
        raise ValueError(
            "conditional_focus_changed_causal_dependencies:"
            f"{changed_dependencies}"
        )
    merged = {
        "nodes": [dict(after[str(item["node_id"])]) for item in previous_nodes]
    }
    _validate_graph_stage_result(
        merged,
        remaining_criterion_ids=remaining_criterion_ids,
    )
    return merged


def _validate_outcome_stage_result(
    arguments: Mapping[str, Any],
    *,
    remaining_criterion_ids: Sequence[str],
    forbidden_node_ids: Sequence[str] = (),
) -> None:
    raw_nodes = arguments.get("nodes")
    if not isinstance(raw_nodes, Sequence) or isinstance(
        raw_nodes, (str, bytes, bytearray)
    ):
        raise ValueError("plan_outcome_stage_nodes_must_be_sequence")
    projected_nodes: list[dict[str, Any]] = []
    for raw_node in raw_nodes:
        if not isinstance(raw_node, Mapping):
            raise ValueError("plan_outcome_stage_node_must_be_mapping")
        node_id = str(raw_node.get("node_id") or "").strip()
        addresses = raw_node.get("addresses_criteria")
        if (
            not isinstance(addresses, Sequence)
            or isinstance(addresses, (str, bytes, bytearray))
            or not addresses
        ):
            raise ValueError(
                "plan_outcome_stage_node_without_criterion:"
                f"node={node_id or '<missing>'}:P0 contains only task outcomes "
                "that address remaining criteria; remove an external "
                "prerequisite from P0 and let the causal stage add it"
            )
        try:
            projected_nodes.append(
                {
                    "node_id": raw_node["node_id"],
                    "outcome": raw_node["outcome"],
                    "completion_condition": raw_node["completion_condition"],
                    "addresses_criteria": raw_node["addresses_criteria"],
                    "decision_boundary": False,
                    "depends_on": [],
                    "transitions": [],
                }
            )
        except KeyError as exc:
            raise ValueError(
                f"plan_outcome_stage_missing_field:{exc.args[0]}"
            ) from exc
    forbidden_ids = set(forbidden_node_ids)
    collisions = sorted(
        {
            str(item["node_id"])
            for item in projected_nodes
            if str(item["node_id"]) in forbidden_ids
        }
    )
    if collisions:
        raise ValueError(
            f"plan_outcome_stage_node_ids_already_constructed:{collisions}"
        )
    _validate_graph_stage_result(
        {"nodes": projected_nodes},
        remaining_criterion_ids=remaining_criterion_ids,
        require_plain_dag=True,
    )

def assess_work_unit(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    active_node: Mapping[str, Any],
    newly_verified_artifacts: Sequence[Mapping[str, Any]],
    resolved_artifacts: Sequence[Mapping[str, Any]],
    completion_candidate_refs: Sequence[str],
    observed_result: Mapping[str, Any] | None = None,
    purpose: str = "assess active common-agent work unit",
    read_ref: Callable[..., Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Let the model judge semantic fulfillment from exact stored evidence."""
    payload = {
        "active_work_unit": dict(active_node),
        "newly_verified_artifacts": [
            dict(item) for item in newly_verified_artifacts
        ],
        "resolved_formal_artifacts": [dict(item) for item in resolved_artifacts],
        "completion_candidate_refs": list(completion_candidate_refs),
    }
    if observed_result is not None:
        payload["attempt_result"] = dict(observed_result)
    # Reads extend only this invocation's visible evidence closure. They do not
    # authorize new completion roots or change the accepted artifact board.
    allowed_refs = set(evidence_ref_strings([newly_verified_artifacts, resolved_artifacts]))
    allowed_refs.update(completion_candidate_refs)
    def read_evidence(arguments: Mapping[str, Any]) -> Mapping[str, Any]:
        ref, path, offset, limit = _evaluation_read_request(arguments)
        if source_ref(ref) not in allowed_refs:
            raise ValueError(f"work_unit_evidence_ref_not_visible:{ref}")
        paged = path is not None or ref.startswith(("reference:", *SOURCE_CONTENT_PREFIXES))
        stored = dict(read_ref(ref, path=path, line_offset=offset, line_limit=limit)
                      if paged else read_ref(ref))
        linked = [] if paged else list(evidence_ref_strings(stored))
        allowed_refs.update(linked)
        return {"ref": ref, "content": stored if paged else _evidence_projection(stored),
                "linked_refs": linked}
    readbacks: list[dict[str, Any]] = []
    tool = _progress_tool(str(active_node["node_id"]))
    arguments = _call_stage(
        model=model,
        memory=memory,
        events=events,
        purpose=purpose,
        page="progress.md",
        payload=payload,
        tool=tool,
        budget_tier="full",
        scientific_call=True,
        read_evidence=read_evidence if read_ref is not None else None,
        evidence_readbacks=readbacks,
    )
    try:
        return _validated_progress(
            arguments,
            active_node_id=str(active_node["node_id"]),
            visible_refs=set(completion_candidate_refs),
        )
    except ValueError as exc:
        repaired = _call_stage(
            model=model,
            memory=memory,
            events=events,
            purpose="repair common-agent work-unit assessment",
            page="progress.md",
            payload={
                **payload,
                "previous_attempt": dict(arguments),
                "validation_issue": str(exc),
            },
            tool=tool,
            budget_tier="full",
            repair_call=True,
            read_evidence=read_evidence if read_ref is not None else None,
            evidence_readbacks=readbacks,
        )
        return _validated_progress(
            repaired,
            active_node_id=str(active_node["node_id"]),
            visible_refs=set(completion_candidate_refs),
        )


def _current_state_card(
    *,
    criteria: Sequence[Mapping[str, Any]],
    stop_criteria: Sequence[Mapping[str, Any]],
    resolved_artifacts: Sequence[Mapping[str, Any]],
    current_issue: str,
) -> dict[str, Any]:
    return {
        "remaining_criteria": [
            dict(item) for item in criteria if item["status"] != "met"
        ],
        "already_satisfied_criteria": [
            dict(item) for item in criteria if item["status"] == "met"
        ],
        "legal_stop_criteria": [dict(item) for item in stop_criteria],
        "accepted_evidence": [dict(item) for item in resolved_artifacts],
        "current_issue": str(current_issue),
    }


def _evaluation_contract(
    gate: Mapping[str, Any],
    state: Mapping[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    payload = gate.get("machine_payload")
    if not isinstance(payload, Mapping):
        payload = gate
    raw_criteria = payload.get("success_criteria")
    raw_stops = payload.get("stop_criteria")
    raw_results = state.get("criterion_results")
    if (
        not isinstance(raw_criteria, Sequence)
        or isinstance(raw_criteria, (str, bytes))
        or not raw_criteria
    ):
        raise ValueError("planning_evaluation_gate_criteria_invalid")
    if not isinstance(raw_stops, Sequence) or isinstance(raw_stops, (str, bytes)):
        raise ValueError("planning_evaluation_gate_stops_invalid")
    if not isinstance(raw_results, Sequence) or isinstance(
        raw_results, (str, bytes)
    ):
        raise ValueError("planning_evaluation_state_results_invalid")

    results_by_id: dict[str, Mapping[str, Any]] = {}
    for result in raw_results:
        if not isinstance(result, Mapping):
            raise ValueError("planning_evaluation_result_invalid")
        criterion_id = str(result.get("criterion_id") or "")
        if not criterion_id or criterion_id in results_by_id:
            raise ValueError("planning_evaluation_result_ids_invalid")
        results_by_id[criterion_id] = result

    criteria: list[dict[str, Any]] = []
    criterion_ids: list[str] = []
    for raw in raw_criteria:
        if not isinstance(raw, Mapping):
            raise ValueError("planning_evaluation_criterion_invalid")
        criterion_id = str(raw.get("criterion_id") or "")
        if not criterion_id or criterion_id in criterion_ids:
            raise ValueError("planning_evaluation_criterion_ids_invalid")
        result = results_by_id.get(criterion_id)
        if result is None:
            raise ValueError(
                f"planning_evaluation_state_missing_criterion:{criterion_id}"
            )
        criterion_ids.append(criterion_id)
        criteria.append(
            {
                "criterion_id": criterion_id,
                "requirement": str(raw.get("requirement") or ""),
                "evidence_expectation": str(
                    raw.get("evidence_expectation") or ""
                ),
                "status": str(result.get("status") or ""),
                "evidence_refs": list(result.get("evidence_refs") or ()),
                "reason": str(result.get("reason") or ""),
            }
        )
    if set(results_by_id) != set(criterion_ids):
        raise ValueError("planning_evaluation_state_has_unknown_criteria")
    stops = [dict(item) for item in raw_stops if isinstance(item, Mapping)]
    if len(stops) != len(raw_stops):
        raise ValueError("planning_evaluation_stop_invalid")
    return criteria, stops


def _frame_goal_contract(
    frame_goal: Mapping[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    outcome = str(frame_goal.get("outcome") or "").strip()
    completion = str(frame_goal.get("completion_condition") or "").strip()
    raw_ids = frame_goal.get("addresses_criteria")
    if (
        not outcome
        or not completion
        or isinstance(raw_ids, (str, bytes))
        or not isinstance(raw_ids, Sequence)
    ):
        raise ValueError("planning_frame_goal_invalid")
    criterion_ids = [str(item).strip() for item in raw_ids]
    if (
        not criterion_ids
        or any(not item for item in criterion_ids)
        or len(criterion_ids) != len(set(criterion_ids))
    ):
        raise ValueError("planning_frame_goal_criteria_invalid")
    return (
        [
            {
                "criterion_id": criterion_id,
                "requirement": outcome,
                "evidence_expectation": completion,
                "status": "indeterminate",
                "evidence_refs": [],
                "reason": "Selected as part of the current Frame goal.",
            }
            for criterion_id in criterion_ids
        ],
        [],
    )


def _call_stage(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    purpose: str,
    page: str,
    payload: Mapping[str, Any],
    tool: Mapping[str, Any],
    allow_protocol_repair: bool = True,
    include_structural_repair_instruction: bool = False,
    budget_tier: str = "compact",
    planning_call: bool = False,
    scientific_call: bool = False,
    repair_call: bool = False,
    read_evidence: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None,
    evidence_readbacks: list[dict[str, Any]] | None = None,
) -> Mapping[str, Any]:
    if sum((planning_call, scientific_call, repair_call)) > 1:
        raise ValueError("plan_stage_reasoning_profile_ambiguous")
    instruction = _stage_instruction(
        page,
        include_structural_repair_instruction=(
            include_structural_repair_instruction
        ),
    )
    base_messages = [
        {"role": "system", "content": instruction},
        {
            "role": "user",
            "content": json.dumps(payload, ensure_ascii=False, indent=2),
        },
    ]
    tools = [dict(tool)]
    readbacks = evidence_readbacks if evidence_readbacks is not None else []
    read_limit = 8 if read_evidence is not None else 0
    if read_evidence is not None:
        read_tool = _read_evidence_tool()
        read_tool["function"]["description"] = (
            "Read an exact visible candidate or linked evidence ref needed to judge this node. "
            "This does not accept the evidence or make it a completion root."
        )
        tools.append(read_tool)
    tool_name = str(tool["function"]["name"])
    issue = ""
    previous_attempt: Mapping[str, Any] | None = None
    failures = 0
    failure_limit = 2 if allow_protocol_repair else 1

    for attempt in range(failure_limit + read_limit):
        if failures >= failure_limit:
            break
        messages = list(base_messages)
        if readbacks:
            messages.append({"role": "user", "content": "Evidence readbacks (not new completion roots):\n"
                             + json.dumps(readbacks, ensure_ascii=False, indent=2)})
        if read_evidence is not None and len(readbacks) >= read_limit:
            tools = [dict(tool)]
            messages.append({"role": "user", "content":
                "Evidence read allowance used. Submit the assessment from the evidence shown. "
                "If a required fact remains unavailable, report that gap; do not claim verification."})
        if previous_attempt is not None:
            required_fields = list(
                tool.get("function", {})
                .get("parameters", {})
                .get("required", ())
            )
            messages.extend(
                [
                    {
                        "role": "assistant",
                        "content": "Previous invalid structured attempt:\n"
                        + json.dumps(previous_attempt, ensure_ascii=False),
                    },
                    {
                        "role": "user",
                        "content": (
                            "Repair only the stated tool-protocol error. "
                            f"Issue: {issue}. The tool argument is one JSON "
                            f"object and must contain these top-level fields: "
                            f"{required_fields}. Call {tool_name} exactly once "
                            "with the complete corrected result; do not submit "
                            "an empty object or a prose explanation."
                        ),
                    },
                ]
            )
        attempt_purpose = purpose if failures == 0 else f"{purpose}: local repair"
        memory.prepare_for_model_call(call_site=attempt_purpose)
        memory.record_prompt_projection(
            call_site=attempt_purpose,
            messages=messages,
            tools=tools,
            sources=(*_prompt_sources(instruction, payload, tools),
                     PromptSource("C4", "work_unit_evidence_readbacks", readbacks)),
            budget_tier=budget_tier,
        )
        events.append(
            "plan_stage_prompt_snapshot",
            {
                "purpose": attempt_purpose,
                "page": page,
                "attempt": attempt + 1,
                "messages": messages,
                "tool_names": [item["function"]["name"] for item in tools],
            },
        )
        turn: ModelTurn | None = None
        try:
            is_repair = repair_call or failures > 0
            call_kwargs = dict(
                messages=messages, tools=tools, purpose=attempt_purpose,
                tool_choice="required", planning=planning_call and not is_repair,
                scientific=scientific_call and not is_repair, repair=is_repair,
            )
            try:
                turn = complete_model_turn(model, **call_kwargs)
            except ModelProtocolError as exc:
                turn = retry_model_turn_without_reasoning(
                    model, error=exc,
                    before_retry=lambda: events.append("model_output_limit_retry", {
                        "purpose": attempt_purpose, "reason": str(exc),
                        "reasoning_effort": "none",
                    }),
                    **call_kwargs,
                )
        except ModelProtocolError as exc:
            issue = f"model_protocol_error:{exc}"
            if str(exc) == "model_output_limit_without_answer":
                # There is no candidate for protocol repair. Do not start another
                # medium/none pair through the structural-repair allowance.
                raise RuntimeError(f"planning_stage_local_repair_failed:{purpose}:{issue}") from exc
        if turn is not None:
            events.append(
                "plan_stage_model_turn",
                {
                    "purpose": attempt_purpose,
                    "page": page,
                    "attempt": attempt + 1,
                    "content": turn.content,
                    "tool_calls": [
                        {
                            "call_id": call.call_id,
                            "name": call.name,
                            "arguments": dict(call.arguments),
                        }
                        for call in turn.tool_calls
                    ],
                    "usage": dict(turn.usage),
                },
            )
            if (read_evidence is not None and len(readbacks) < read_limit
                    and len(turn.tool_calls) == 1
                    and turn.tool_calls[0].name == "read_evaluation_evidence"):
                call = turn.tool_calls[0]
                ref = str(call.arguments.get("ref") or "").strip()
                try:
                    readback = dict(read_evidence(call.arguments))
                except Exception as exc:
                    readback = {"ref": ref, "read_error": f"{type(exc).__name__}:{exc}"}
                readbacks.append(readback)
                events.append("plan_stage_evidence_read", {"purpose": purpose, **readback})
                previous_attempt = None
                continue
            try:
                arguments = _single_tool_arguments(turn, tool_name)
                _validate_top_level_tool_shape(arguments, tool)
                return arguments
            except RuntimeError as exc:
                issue = str(exc)
            previous_attempt = {
                "content": bounded_text(turn.content, 1_000),
                "tool_calls": [
                    {"name": call.name, "arguments": dict(call.arguments)}
                    for call in turn.tool_calls
                ],
            }
        else:
            previous_attempt = {"content": "", "tool_calls": []}
        failures += 1
        events.append(
            "plan_stage_repair_requested",
            {
                "purpose": purpose,
                "page": page,
                "attempt": attempt + 1,
                "issue": issue,
            },
        )
    raise RuntimeError(f"planning_stage_local_repair_failed:{purpose}:{issue}")


def _prompt_sources(
    instruction: str,
    payload: Mapping[str, Any],
    tools: Sequence[Mapping[str, Any]],
) -> tuple[PromptSource, ...]:
    current_state = payload.get("current_state")
    control_state = (
        {
            key: value
            for key, value in current_state.items()
            if key != "accepted_evidence"
        }
        if isinstance(current_state, Mapping)
        else current_state
    )
    formal_evidence = (
        {
            "accepted_evidence": current_state.get("accepted_evidence") or [],
        }
        if isinstance(current_state, Mapping)
        else {
            "newly_verified_artifacts": (
                payload.get("newly_verified_artifacts") or []
            ),
            "resolved_formal_artifacts": (
                payload.get("resolved_formal_artifacts") or []
            ),
        }
    )
    return (
        PromptSource("instruction", "planning_stage_instruction", instruction),
        PromptSource(
            "C0",
            "planning_task_anchor",
            {
                "objective": payload.get("objective"),
                "mission_packet": payload.get("mission_packet") or {},
            },
        ),
        PromptSource(
            "C1",
            "planning_control_state",
            {
                "current_state": control_state,
                "active_work_unit": payload.get("active_work_unit"),
                "evaluation_state": payload.get("evaluation_state"),
            },
        ),
        PromptSource(
            "C2",
            "planning_formal_evidence",
            formal_evidence,
        ),
        PromptSource(
            "instruction",
            "planning_skill_summaries",
            payload.get("available_skill_summaries") or [],
        ),
        PromptSource(
            "C5",
            "planning_stage_working_context",
            {
                key: value
                for key, value in payload.items()
                if key
                not in {
                    "objective",
                    "mission_packet",
                    "current_state",
                    "active_work_unit",
                    "evaluation_state",
                    "resolved_formal_artifacts",
                    "newly_verified_artifacts",
                    "available_skill_summaries",
                }
            },
        ),
        PromptSource("tool_schema", "planning_stage_result", list(tools)),
    )


def _stage_instruction(
    page: str,
    *,
    include_structural_repair_instruction: bool = False,
) -> str:
    detail = (_ROOT / "references" / page).read_text(encoding="utf-8")
    stage_instruction = (
        detail
        if page in _DETAIL_ONLY_STAGE_PAGES
        else _SKILL_ROOT + "\n\nSelected workflow stage:\n\n" + detail
    )
    if page == "progress.md":
        stage_instruction = evidence_completeness_instruction() + "\n\n" + stage_instruction
    if include_structural_repair_instruction:
        return (
            stage_instruction
            + "\n\nStructural repair addendum:\n\n"
            + (_ROOT / "references" / "repair.md").read_text(
                encoding="utf-8"
            )
        )
    return stage_instruction


def _single_tool_arguments(turn: ModelTurn, tool_name: str) -> Mapping[str, Any]:
    if len(turn.tool_calls) != 1:
        raise RuntimeError(
            f"planning_stage_requires_one_tool_call:{len(turn.tool_calls)}"
        )
    call = turn.tool_calls[0]
    if call.name != tool_name:
        raise RuntimeError(f"planning_stage_tool_mismatch:{tool_name}:{call.name}")
    return dict(call.arguments)


def _validate_top_level_tool_shape(
    arguments: Mapping[str, Any],
    tool: Mapping[str, Any],
) -> None:
    parameters = tool.get("function", {}).get("parameters", {})
    required = set(parameters.get("required", ()))
    properties = set(parameters.get("properties", {}))
    actual = set(arguments)
    missing = sorted(required - actual)
    unexpected = sorted(actual - properties) if properties else []
    if missing or unexpected:
        raise RuntimeError(
            "planning_stage_tool_arguments_shape_invalid:"
            f"missing={missing}:unexpected={unexpected}"
        )


def _validated_progress(
    arguments: Mapping[str, Any],
    *,
    active_node_id: str,
    visible_refs: set[str],
) -> dict[str, Any]:
    expected = {"node_id", "fulfilled", "evidence_refs", "reason"}
    if set(arguments) != expected:
        raise ValueError("work_unit_assessment_fields_invalid")
    if arguments["node_id"] != active_node_id:
        raise ValueError("work_unit_assessment_node_mismatch")
    if not isinstance(arguments["fulfilled"], bool):
        raise ValueError("work_unit_assessment_fulfilled_must_be_boolean")
    raw_refs = arguments["evidence_refs"]
    if isinstance(raw_refs, (str, bytes)) or not isinstance(raw_refs, Sequence):
        raise ValueError("work_unit_assessment_evidence_refs_must_be_array")
    refs = [str(ref).strip() for ref in raw_refs if str(ref).strip()]
    if len(refs) != len(raw_refs) or len(refs) != len(set(refs)):
        raise ValueError("work_unit_assessment_evidence_refs_invalid")
    non_citable_refs = sorted(set(refs) - visible_refs)
    if non_citable_refs:
        raise ValueError(
            "work_unit_assessment_evidence_ref_not_visible:"
            f"non_citable_refs={non_citable_refs}:"
            "cite_only_top_level_refs_from_newly_verified_or_resolved_artifacts"
        )
    reason = str(arguments["reason"]).strip()
    if not reason:
        raise ValueError("work_unit_assessment_reason_invalid")
    reason = _compact_work_unit_reason(reason)
    if arguments["fulfilled"] and not refs:
        raise ValueError("fulfilled_work_unit_requires_evidence_refs")
    return {
        "node_id": active_node_id,
        "fulfilled": arguments["fulfilled"],
        "evidence_refs": refs,
        "reason": reason,
    }


def _compact_work_unit_reason(value: str) -> str:
    """Project the raw C6 verdict into a bounded C1 diagnostic."""
    normalized = " ".join(str(value).split())
    if len(normalized) <= _WORK_UNIT_REASON_LIMIT:
        return normalized
    return normalized[: _WORK_UNIT_REASON_LIMIT - 3].rstrip() + "..."


def _node_schema(criterion_ids: Sequence[str]) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "node_id": {"type": "string", "minLength": 1, "maxLength": 80},
            "outcome": {"type": "string", "minLength": 1, "maxLength": 1_000},
            "completion_condition": {
                "type": "string",
                "minLength": 1,
                "maxLength": 1_000,
            },
            "addresses_criteria": {
                "type": "array",
                "minItems": 1,
                "uniqueItems": True,
                "items": {"type": "string", "enum": list(criterion_ids)},
            },
            "decision_boundary": {
                "description": (
                    "True only when this work unit produces evidence used to "
                    "choose among two or more explicit transitions."
                ),
                "type": "boolean",
            },
            "depends_on": {
                "description": (
                    "Predecessor node_id values from this submitted graph only. "
                    "Accepted artifact or observation refs are context inputs and "
                    "must not appear here; use [] when there is no predecessor node."
                ),
                "type": "array",
                "uniqueItems": True,
                "items": {"type": "string", "minLength": 1, "maxLength": 80},
            },
            "transitions": {
                "description": (
                    "Observable conditional edges. Use [] for a non-decision "
                    "node and at least two entries for a decision node."
                ),
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "transition_id": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 80,
                        },
                        "condition": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 500,
                        },
                        "target_node_id": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 80,
                        },
                    },
                    "required": [
                        "transition_id",
                        "condition",
                        "target_node_id",
                    ],
                    "additionalProperties": False,
                },
            },
        },
        "required": [
            "node_id",
            "outcome",
            "completion_condition",
            "addresses_criteria",
            "decision_boundary",
            "depends_on",
            "transitions",
        ],
        "additionalProperties": False,
    }


def _plan_graph_tool(
    name: str,
    criterion_ids: Sequence[str],
    *,
    description: str = "Submit one complete remaining-outcome graph.",
) -> dict[str, Any]:
    return function_tool(
        name,
        description,
        {
            "type": "object",
            "properties": {
                "nodes": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": MAX_PLAN_GRAPH_NODES,
                    "items": _node_schema(criterion_ids),
                }
            },
            "required": ["nodes"],
            "additionalProperties": False,
        },
    )


def _progress_tool(node_id: str) -> dict[str, Any]:
    return function_tool(
        "assess_work_unit",
        "Assess only the active work unit against exact visible evidence.",
        {
            "type": "object",
            "properties": {
                "node_id": {"type": "string", "enum": [node_id]},
                "fulfilled": {"type": "boolean"},
                "evidence_refs": {
                    "type": "array",
                    "uniqueItems": True,
                    "items": {"type": "string", "minLength": 1},
                },
                "reason": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": _WORK_UNIT_REASON_LIMIT,
                },
            },
            "required": ["node_id", "fulfilled", "evidence_refs", "reason"],
            "additionalProperties": False,
        },
    )


def _outcome_inventory_tool(
    name: str,
    criterion_ids: Sequence[str],
) -> dict[str, Any]:
    return function_tool(
        name,
        "Submit candidate outcomes for later causal graph construction.",
        {
            "type": "object",
            "properties": {
                "nodes": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": MAX_PLAN_GRAPH_NODES,
                    "items": {
                        "type": "object",
                        "properties": {
                            "node_id": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": 80,
                            },
                            "outcome": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": 1_000,
                            },
                            "completion_condition": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": 1_000,
                            },
                            "addresses_criteria": {
                                "type": "array",
                                "minItems": 1,
                                "uniqueItems": True,
                                "items": {
                                    "type": "string",
                                    "enum": list(criterion_ids),
                                },
                            },
                        },
                        "required": [
                            "node_id",
                            "outcome",
                            "completion_condition",
                            "addresses_criteria",
                        ],
                        "additionalProperties": False,
                    },
                }
            },
            "required": ["nodes"],
            "additionalProperties": False,
        },
    )
