# Connect Formal Causal Results

Review ordinary causal dependencies for only the supplied `focus_node_ids` in
the complete `causal_graph`. Python preserves and merges non-focus nodes.

P0 owns work-unit boundaries. Preserve each focus node's identity, outcome,
completion condition, criterion addresses, and empty decision fields. This
stage may change only `depends_on` and may add a genuinely missing formal
prerequisite result.

Use these authorities in order:

1. The objective and mission packet define declared result boundaries.
2. Remaining criteria judge outcomes; they are not an input or node checklist.
3. `current_state.accepted_evidence` lists formal results that already exist.
4. Existing graph nodes list formal results the graph already intends to make.
5. Skill planning projections state each capability's compact summary,
   responsibility boundary, entry conditions, and approximate cost. They do not
   expose the Skill's internal workflow.

For each focus node, identify only independently stored formal results that its
producer must consume. Apply this decision in order:

1. If the result is accepted evidence, no graph node is needed for it.
2. If an existing graph node produces it, add that node to `depends_on`.
3. If the task or matching skill summary explicitly requires a separate formal
   result that neither exists nor has a producer node, add one prerequisite
   node and connect it.
4. Otherwise add nothing and leave execution-time discovery to the node LOOP.

When a capability offers alternative input modes, choose the mode whose formal
lineage can satisfy the focus node's outcome and completion condition. The mere
availability of an accepted input does not authorize a cheaper mode whose
output omits lineage required by that node. Add any missing formal prerequisites
explicitly required by the matching mode under rule 3; do not combine inputs
from mutually exclusive modes.

A C3-only working observation is never a missing formal prerequisite. When a
capability summary says it publishes no formal C2 artifact, do not add it as a
node or dependency; the formal producer performs any required inspection inside
its own bounded workflow.

Do not mistake runtime inputs for missing formal results. Task text, mounted
source files, workspace data, and fields read internally by the focus skill are
inputs to that skill, not predecessor outcomes merely because they are absent
from `accepted_evidence`. If an input is actually unavailable, execution may
return evidence of that gap and trigger graph rebuilding; planning must not
invent a source-preparation result in advance.

Likewise, values or fields that the focus result must calculate, populate,
validate, rank, or report belong inside that focus node. Writing, executing,
inspecting, repairing, and publishing one program are normally one node-local
LOOP, not predecessor nodes. Node scale was decided in P0.

`depends_on` means the focus consumes the predecessor's accepted formal result;
it never means order, convenience, shared context, or an internal operation.
Every dependency is conjunctive. Do not duplicate outcomes, invent producers,
infer scientific facts, or add conditional branches in this stage. A new
prerequisite must be an ancestor of the focus node and must use criterion ids
already addressed by the focus node, as required by the existing graph format.

Return every focus node exactly once. Every returned node contains `node_id`,
`outcome`, `completion_condition`, `addresses_criteria`, `decision_boundary`,
`depends_on`, and `transitions`. Use `decision_boundary=false` and
`transitions=[]`. Call `submit_causal_graph` exactly once.

If the payload contains `previous_nodes` and `structural_validation_issue`, fix
only that structural defect while preserving the same focus and formal input
boundaries. When the issue supplies allowed criterion ids, use only those ids.
