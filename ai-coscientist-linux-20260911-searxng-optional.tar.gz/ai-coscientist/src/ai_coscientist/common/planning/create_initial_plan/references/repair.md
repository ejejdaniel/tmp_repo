# Repair Initial Graph Construction

Return one complete corrected graph, not a patch.

Honor every length bound in the supplied tool schema. When the structural issue
names an invalid `outcome` or `completion_condition`, shorten that field while
preserving its formal result identity and evidence boundary. Rewrite both text
fields on every affected node to at most 300 characters rather than aiming at
the 1000-character hard limit. Do not repeat the full criterion text:
`addresses_criteria` retains the exact checklist.

P0 cannot retain a node with no applicable remaining criterion. When such a
node is an external prerequisite for another outcome, remove it from the P0
repair rather than assigning a guessed criterion; the causal stage receives the
same capability summaries and will add and connect that prerequisite under its
own contract.

Use the same objective, mission packet, current state, accepted evidence,
capability summaries, original stage instructions, and tool schema supplied to
the rejected call. The previous nodes and reported issue identify what to
repair; they do not replace those authorities. This is structural repair, not
replanning. Preserve every valid field and scientific meaning while correcting
the reported shape. Cover every remaining criterion using exact criterion ids.
Keep nodes as judgeable outcomes rather than tools, skills, or action lists. Do
not invent future artifact refs.

Only ids under `current_state.remaining_criteria` are legal in
`addresses_criteria`. Never preserve or reintroduce an id from
`current_state.already_satisfied_criteria`. When the reported issue names such an
id, remove work that serves only that completed criterion. Do not assign a
remaining criterion to a prerequisite that does not itself own that criterion's
evidence. The later causal stage adds required prerequisite outcomes.

Repair false criterion coverage rather than restating it. A node's outcome and
completion condition must together provide the expected evidence for every cited
criterion. If different allowed outcomes prove different criteria, split them at
the causal boundary or narrow each node's criterion ids. Preserve any explicit
task boundary that authorizes an explicitly declared fallback.

Repair temporal leakage as a structural meaning defect. Every work node must be
judgeable when it ends. Remove any requirement that a future successor, parent,
later human interaction, review, report, or other not-yet-produced artifact
must cite, accept, or use the current result. Preserve that relation only on the
later consumer node. Do not invent a generic evidence node merely to carry a
future relationship that belongs to an existing successor.

Do not add skills, tools, execution order, dependencies, branches, or new task
interpretations. Call the supplied tool exactly once with the complete corrected
payload.
