# Active Work-Unit Fulfillment

Judge only whether exact stored evidence fulfills the active work unit. A
candidate may be a result just produced by this node-local LOOP or formal
evidence that was already explicitly visible when the node became active.
Neither is automatic completion. Its publication status may still be `proposed`
because this assessment is the boundary that decides whether the exact ref
becomes completion evidence. Do not reject it merely because it has not already
been accepted; judge its stored content against this node now.

Apply the shared Evidence Completeness instruction to the node outcome and
completion condition. There are two distinct reference roles:

- `completion_candidate_refs` limits which root results may be returned in
  `evidence_refs` to complete this node. It does not limit where their evidence
  may be stored.
- Exact dependencies of a candidate are readable supporting evidence. After
  reading and checking their relation to the candidate, use their facts to judge
  the candidate and return that candidate's root ref, not the dependency ref.

If a required fact is not in the supplied candidate content, inspect its linked
evidence using `read_evaluation_evidence` before concluding that fact is missing.
Do not equate the result's "resolved content" with just its inline machine
payload. Apply any explicit self-contained presentation requirement separately.
Neither a reference alone nor a producer's completion claim proves fulfillment.

Check the work actually required by the outcome and completion condition against
the candidate and its exact linked evidence. A candidate's top-level kind need
not match the kind of supporting evidence requested by the node: a stored result
can establish that an execution occurred through its linked execution record.
Read that record and verify the requested subject, implementation version, inputs
and actual outcome. A link by itself is not proof.

Do not relabel artifacts or substitute an unrelated subject or version. If the
node explicitly requires delivery of a particular artifact, verify that exact
artifact exists in the candidate's evidence chain and meets the requirement;
a description of it is insufficient. Respect explicit standalone or
self-contained delivery requirements. During compact screening, keep a candidate
whose lineage plausibly contains the requested evidence for focused reading;
do not reject it solely because its outer artifact kind differs.

Every artifact produced during the node-local LOOP remains stored attempt
evidence. Some of it may be an intermediate result whose kind or scientific
subject also appears in another Graph node. Do not complete, score, or otherwise
update that other node here. Cite as completion evidence only the subset that
actually fulfills this active node's outcome and completion condition. Uncited
artifacts remain traceable attempt evidence and confer no Graph completion by
themselves.

The runtime has already checked visibility, provenance, and node ownership for
the completion candidates. They may be current-attempt results, explicit task
inputs, this node's preserved results, or partial results promoted during graph
rebuilding. Do not demand a duplicate of an already available candidate.
The `graph_revision_outcome` audit artifact itself is never a completion
candidate. Preserve the subject, route, version, and other identity stated by
the work unit. Matching only a label or one branch of an `or` is insufficient.
A plan, catalog, or method description does not prove an implemented or observed
result; inspect the actual evidence rather than treating a description as proof.

There are two explicit pre-execution review statuses. When `attempt_result.status`
is `existing_formal_evidence_screening`, the candidate items are compact stored
indexes, not full content. This call never completes the node. Use
`evidence_refs` only as the shortlist of smallest roots that plausibly warrant
focused verification, and set `fulfilled=true` exactly when that shortlist is
non-empty. If the reason says full content is needed to decide, return true with
the refs that need expansion. Return false with an empty list only when the
compact identity, shape, lineage, or summary already shows that no candidate can
fulfill the work unit. When the status is
`existing_formal_evidence_verification`, only the selected roots are expanded;
then apply the normal exact-content rule and return true only if they actually
fulfill the node.

The node's addresses_criteria explains why the work matters, but this call does
not decide global task success. The agent-local evaluator separately judges each
criterion. A scientifically unfavorable or bounded-gap result may still fulfill
an investigative work unit when its completion condition asks for a finding. The
attempt_result reports what the just-finished skill invocation observed; it may
explain a gap, but fulfilled=true still requires exact visible formal evidence.
When exact stored self-review, residual issues, or the attempt result
affirmatively contradicts the completion condition, return fulfilled=false
unless the node explicitly asks for a formal record of that gap. Do not accept
a result merely because its top-level status or summary sounds complete.
When attempt_result reports a precise missing prerequisite or terminal gap,
preserve that cause in the reason instead of replacing it with the generic fact
that no completion artifact exists.

Do not rewrite the plan, decide the next skill, or require evidence not stated by
the work unit. Keep the reason concise and name the exact stored result that
supports the decision.

For a node with conditional transitions, this call judges only whether the
announced work-unit outcome exists. The main agent, not this judge, later
chooses one declared edge.
