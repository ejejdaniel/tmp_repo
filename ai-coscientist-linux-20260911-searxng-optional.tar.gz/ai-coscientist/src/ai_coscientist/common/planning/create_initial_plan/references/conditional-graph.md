# Construct Conditional Transitions

Add observable conditional transitions to the supplied causal dependency graph.
The graph already contains formal outcomes and ordinary prerequisites. This call
reviews only `focus_node_ids`. Return only those focus nodes, every one exactly
once. Do not copy non-focus nodes into the answer; Python preserves and merges
them mechanically. Do not add, remove, or rename nodes. A focus node may change
only its decision flag and transitions. Its outcome, completion condition,
criterion addresses, and ordinary `depends_on` relations are already
authoritative and must remain unchanged.

Find only branches that are explicit in the objective or remaining success
criteria. A branch exists when one accepted observed result determines which of
two or more different later formal outcomes is applicable. A graph with no
decision nodes is valid when the task does not state such a conditional
relationship.

Capability availability and approximate cost were already considered while
constructing the supplied causal graph. Do not reconstruct that work here or
create Graph branches from a skill's ordinary success, bounded gap, blocked
result, repair result, or other internal return classes. Those classes belong
to the node-local LOOP unless the task itself requires different later formal
outcomes for them.

Perform the task-defined branch check separately for every focus node. Finding
a decision for one focus node does not finish the other focus nodes.

For each outcome:

- A node is a decision boundary only when its work can formally produce two or
  more accepted, classifiable result types and those results require materially
  different later work.
- Preserve each node's outcome and completion condition. This stage connects
  already inventoried formal outcomes; it does not broaden a node to include a
  skill's gap, blocked, or repair results.
- Transition conditions describe observable result states. They do not guess a
  future scientific answer or select a skill.
- Conditional transitions represent mutually exclusive result classes, not the
  ordinary fan-out that follows one successful result. The existing causal
  `depends_on` relations already make every dependent outcome eligible after its
  prerequisites complete. Do not copy one success condition into one transition
  per dependent node.
- A capability is not a decision boundary merely because its scientific result
  or execution status is unknown before execution. Add a branch only when the
  task-defined condition and its distinct later outcomes are both present in
  the supplied graph.
- Write each observable result condition exactly once. When one result enables
  several ordinary downstream outcomes, keep those causal dependencies intact
  and select only one immediate forward control target for that condition. The
  other dependents remain reachable through the causal graph.
- Merge accepted result descriptions that lead to the same downstream work into
  one condition. For example, two accepted variants that both continue to the
  same construction outcome are one branch, not two branches.
- Every entry in `depends_on` is conjunctive. Never require results from two
  mutually exclusive branches.
- Do not repair a missing route by changing `depends_on`. Choose only causally
  valid existing targets. Declare a decision node only when at least two
  mutually exclusive, observable result classes each have a truthful existing
  target. Otherwise keep the node non-decision; an accepted result not covered
  by the ordinary causal graph can trigger later graph reconstruction.
- A forward target causally depends on the decision result. It may also wait for
  independent ordinary prerequisites. A transition must not target the same
  node or any causal ancestor because the stored Graph is acyclic. Retrying the
  same outcome with a different capability, new evidence, or corrected
  construction belongs inside that node's bounded LOOP. If accepted evidence
  requires returning to an earlier outcome, leave the result outside the
  existing branch so runtime can request a Graph rebuild.
- Use only existing forward node ids as transition targets. Never emit a partial
  decision table with only one valid branch or an invented target.
- Do not mark terminal closure as a decision when every judgment ends the task.

Nodes with no material result branch remain `decision_boundary=false` with
`transitions=[]`. Return only the complete focus batch and call
`submit_conditional_graph` exactly once.

If the payload contains `previous_nodes` and `structural_validation_issue`, fix
only that issue while still preserving node identity, non-focus nodes, and focus
node criterion addresses. When the issue names `allowed_target_node_ids`, never
repeat the rejected target. Choose a scientifically truthful target from that
list, remove the unsupported transition, or make the node non-decision when no
listed target represents materially different later work.
