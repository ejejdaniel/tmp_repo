---
name: create-initial-plan
description: Produces one bounded current-Frame graph from an already selected Frame goal, accepted evidence, issue state, and available capabilities.
estimated_complexity: medium
---

# Create Initial Plan

This is private common infrastructure. It is not a selectable domain skill.

The workflow uses three model-driven construction stages, surrounded by one
mechanical input projection and one mechanical compilation step:

1. The main agent first selects one bounded Frame goal from the Global
   Evaluation. That selection is a separate planning stage; this workflow does
   not choose or expand the global mission horizon.
2. Python projects the selected Frame goal, accepted evidence summaries, and
   current issue. The Frame goal is the sole planning authority for what this
   graph must reach.
3. One model call inventories bounded outcomes needed to reach that Frame goal
   from current evidence and compact capability summaries. The goal's linked
   criteria are a checklist rather than a node list: one node may
   address several criteria when one formal result and one bounded LOOP attempt
   satisfy them. A formal envelope and the named bodies it exposes are one node
   unless the task requires a body as a separately published formal result. It
   does not select capabilities or define graph edges.
4. Focused causal calls receive planning projections from the same Skill source
   of truth: each compact summary plus its responsibility boundary and entry
   conditions. They build only ordinary causal dependencies and missing formal
   prerequisite results. Node scale is already frozen; Skill workflow internals
   remain hidden and cannot become graph nodes or new task requirements. This
   stage emits no decisions or transitions.
5. Focused conditional calls construct only observable result branches. They may rewrite
   a success-only work outcome as one classifiable result and add explicit
   recovery routes, but do not redo ordinary planning.
6. Python strictly validates and mechanically compiles only the reviewed work
   nodes, prepends one completed non-executable task start anchor, appends one
   non-executable Frame goal node selected before this workflow,
   connects every work root to the start and every work sink to the goal, then
   adds runtime status fields. The model never invents or executes either
   structural node.

Global Evaluation owns the whole mission horizon and remembers what remains
unmet. The selected Frame goal owns this graph's local endpoint. Accepted
artifacts and observations own facts about what has happened. The plan owns
only the current bounded route to that endpoint.

Skill summaries are P0 node-scale, causal, and execution hints, not task
requirements or graph nodes. Their ids must not appear in plan nodes. One graph
node may need several skill invocations at execution time. A capability boundary
may expose a missing prerequisite during causal construction, but alternative
capabilities never become simultaneous required outcomes merely because they
are available.
No planning stage reviews scientific correctness or scores a proposed method.
The causal stage only builds graph structure. If a stage does not return the
declared tool shape, the skill performs only its bounded structural repair and
preserves the raw call log.

The outcome inventory nodes contain:

- node_id
- outcome
- completion_condition
- addresses_criteria

Each work node is temporally local: its completion must be judgeable from its
predecessors and its own newly stored result at the moment that node ends. A
future successor's citation, acceptance, review, or use of that result belongs
to the successor node, even when both nodes address the same final criterion.

The causally reviewed graph nodes contain:

- node_id
- outcome
- completion_condition
- addresses_criteria
- decision_boundary
- depends_on
- transitions

selected_transition_id, attempt_refs, completion_refs, and execution statuses
are runtime-owned and are not model outputs.

The stored Graph has one reserved `task-start` node and exactly one
`goal_node_id`. The start node is a completed structural anchor with no incoming
edge, artifact, evaluator, skill, or node-local LOOP; every work root depends on
it. The goal node represents current-Frame closure, has no outgoing edge, never
owns a skill or node-local LOOP, and is completed only when the Frame evaluator
reports that selected endpoint satisfied. Every pending or active work node must have
a causal path from start and to goal. Completed historical work may remain as a
leaf after a later replan.

The stored Graph is acyclic. Ordinary dependencies and conditional transitions
move only forward; neither may point to the same node or to an ancestor. Retry
and repeated work belong inside the bounded node-local LOOP. If the topology
must change, runtime requests a Graph rebuild instead of adding a cycle.

The model call input is C0/C1/C2 context plus the dynamically discovered compact
skill summaries. Its transient prompt and raw response remain C5/C6 according to
the existing memory policy. Only the mechanically assembled plan is stored in
C1.

### LLM call contracts

| Stage purpose | Authoritative inputs | Allowed work | Output and validator | Local repair | Consumer |
|---|---|---|---|---|---|
| Coarse outcome inventory | Selected Frame goal, read-only objective context, accepted-evidence summaries, current issue, mission packet, and compact capability summaries | List bounded formal-result outcomes needed only to reach the Frame goal; linked criteria are a checklist, not one-node-per-criterion instructions; keep every completion condition judgeable at that node boundary | Existing P0 node shape with ids, outcomes, completion conditions, and criterion links | One structural repair with the rejected result and exact issue | Causal construction |
| Causal dependencies for one focus node | Same planning authority, complete current candidate graph, one focus node, and planning projections containing Skill summary, responsibility boundary, entry conditions, and complexity | Add missing prerequisite result nodes and ordinary `depends_on` edges; do not expose skill workflow internals or create conditional branches | Existing causal graph node shape; validates identity, criterion support, node scale, and legal dependencies | One structural repair for that focus result | Conditional construction |
| Conditional branches for a bounded node batch | Frozen causal graph, same task/evaluation authority, and a bounded focus set | Mark genuine observation-dependent decisions and add result-class transitions without rewriting ordinary causal structure | Existing complete graph shape; validates branch coverage and forbids unrequested causal changes | One structural repair; causal conflicts return to their owning construction logic | Mechanical graph compilation |
| Active work-unit assessment | Exact current node, completion condition, visible accepted evidence, and attempt result | Judge whether this node is complete, should continue within quota, or has produced a graph-level gap | Existing progress tool shape and exact visible-ref validation | One narrow shape repair | Runtime node state transition |

The common structured-output repair may correct only malformed tool protocol. It
does not change scientific content, add missing graph semantics, or overrule a
valid stage rejection.
