from __future__ import annotations

import json
from typing import Any, Mapping, Sequence

from .graph import render_plan_summary, validate_plan_graph
from .node_loop import NODE_LOOP_PURPOSE_LIMIT, compact_node_loop_purpose


GRAPH_REVISION_OUTCOME_KIND = "graph_revision_outcome"
_PAYLOAD_KEYS = frozenset(
    {
        "artifact_kind",
        "source_revision",
        "revision_scope",
        "trigger",
        "failed_node",
        "attempts",
        "unmet_criteria",
        "still_usable_refs",
    }
)
_FAILED_NODE_KEYS = frozenset(
    {
        "node_id",
        "outcome",
        "completion_condition",
        "addresses_criteria",
    }
)
_ATTEMPT_KEYS = frozenset(
    {
        "attempt_index",
        "planned_steps",
        "result_refs",
        "observation_refs",
        "evaluator_accepted",
        "evaluator_reason",
    }
)
_STEP_KEYS = frozenset({"skill_id", "purpose", "input_refs", "cost"})
_UNMET_CRITERION_KEYS = frozenset(
    {"criterion_id", "status", "evidence_refs", "reason"}
)
_DEFAULT_ATTEMPT_REASON = "No accepted completion evidence."
_REASON_LIMIT = 2_000


def build_graph_revision_outcome(
    *,
    source_graph: Mapping[str, Any],
    failed_node_id: str | None = None,
    revision_scope: str = "node",
    trigger: str,
    reason: str,
    events: Sequence[Mapping[str, Any]],
    unmet_criteria: Sequence[Mapping[str, Any]] = (),
    still_usable_refs: Sequence[str],
    skill_costs: Mapping[str, int] | None = None,
) -> dict[str, Any]:
    """Project one failed node or exhausted Graph into a formal C2 result."""
    validate_plan_graph(source_graph)
    scope = str(revision_scope).strip()
    node_id = str(failed_node_id or "").strip()
    trigger_text = str(trigger).strip()
    reason_text = str(reason).strip()
    if scope not in {"node", "graph"}:
        raise ValueError("graph_revision_scope_invalid")
    if scope == "node" and not node_id:
        raise ValueError("graph_revision_failed_node_id_required")
    if scope == "graph" and node_id:
        raise ValueError("graph_revision_graph_scope_forbids_failed_node")
    if not trigger_text:
        raise ValueError("graph_revision_trigger_required")
    if not reason_text:
        raise ValueError("graph_revision_reason_required")

    failed: Mapping[str, Any] | None = None
    attempts: list[dict[str, Any]] = []
    if scope == "node":
        failed = next(
            (
                node
                for node in source_graph["nodes"]
                if str(node["node_id"]) == node_id
            ),
            None,
        )
        if failed is None:
            raise ValueError(f"graph_revision_failed_node_unknown:{node_id}")
        scoped_events = _events_for_revision(
            events,
            revision=int(source_graph["revision"]),
        )
        attempts = _attempt_records(
            scoped_events,
            node_id=node_id,
            fallback_refs=failed["attempt_refs"],
            final_reason=reason_text,
            evaluator_accepted=(trigger_text == "no_matching_transition"),
            skill_costs=skill_costs or {},
        )
    payload = {
        "artifact_kind": GRAPH_REVISION_OUTCOME_KIND,
        "source_revision": int(source_graph["revision"]),
        "revision_scope": scope,
        "trigger": trigger_text,
        "failed_node": (
            {
                "node_id": node_id,
                "outcome": str(failed["outcome"]),
                "completion_condition": str(failed["completion_condition"]),
                "addresses_criteria": list(failed["addresses_criteria"]),
            }
            if failed is not None
            else None
        ),
        "attempts": attempts,
        "unmet_criteria": [dict(item) for item in unmet_criteria],
        "still_usable_refs": _unique_refs(still_usable_refs),
    }
    validate_graph_revision_outcome(payload)
    return payload


def validate_graph_revision_outcome(payload: Any) -> None:
    if not isinstance(payload, Mapping) or set(payload) != _PAYLOAD_KEYS:
        raise ValueError("graph_revision_outcome_fields_invalid")
    if payload.get("artifact_kind") != GRAPH_REVISION_OUTCOME_KIND:
        raise ValueError("graph_revision_outcome_kind_invalid")
    revision = payload.get("source_revision")
    if not isinstance(revision, int) or revision < 1:
        raise ValueError("graph_revision_outcome_source_revision_invalid")
    _bounded_text(
        payload.get("trigger"),
        issue="graph_revision_outcome_trigger_invalid",
        limit=120,
    )
    scope = payload.get("revision_scope")
    if scope not in {"node", "graph"}:
        raise ValueError("graph_revision_outcome_scope_invalid")

    failed = payload.get("failed_node")
    if scope == "node":
        if not isinstance(failed, Mapping) or set(failed) != _FAILED_NODE_KEYS:
            raise ValueError("graph_revision_outcome_failed_node_invalid")
        _bounded_text(
            failed.get("node_id"),
            issue="graph_revision_outcome_failed_node_id_invalid",
            limit=80,
        )
        _bounded_text(
            failed.get("outcome"),
            issue="graph_revision_outcome_failed_node_outcome_invalid",
            limit=1_000,
        )
        _bounded_text(
            failed.get("completion_condition"),
            issue="graph_revision_outcome_failed_node_condition_invalid",
            limit=1_000,
        )
        _validate_refs(
            failed.get("addresses_criteria"),
            issue="graph_revision_outcome_failed_node_criteria_invalid",
            allow_empty=False,
        )
    elif failed is not None:
        raise ValueError("graph_revision_outcome_graph_failed_node_forbidden")

    attempts = payload.get("attempts")
    if (
        isinstance(attempts, (str, bytes))
        or not isinstance(attempts, Sequence)
        or (scope == "node" and not 1 <= len(attempts) <= 2)
        or (scope == "graph" and len(attempts) != 0)
    ):
        raise ValueError("graph_revision_outcome_attempts_invalid")
    seen_attempts: set[int] = set()
    for index, attempt in enumerate(attempts, start=1):
        if not isinstance(attempt, Mapping) or set(attempt) != _ATTEMPT_KEYS:
            raise ValueError(f"graph_revision_outcome_attempt_{index}_invalid")
        attempt_index = attempt.get("attempt_index")
        if (
            not isinstance(attempt_index, int)
            or attempt_index < 1
            or attempt_index in seen_attempts
        ):
            raise ValueError(
                f"graph_revision_outcome_attempt_{index}_index_invalid"
            )
        seen_attempts.add(attempt_index)
        steps = attempt.get("planned_steps")
        if isinstance(steps, (str, bytes)) or not isinstance(steps, Sequence):
            raise ValueError(
                f"graph_revision_outcome_attempt_{index}_steps_invalid"
            )
        for step_index, step in enumerate(steps, start=1):
            if not isinstance(step, Mapping) or set(step) != _STEP_KEYS:
                raise ValueError(
                    "graph_revision_outcome_attempt_"
                    f"{index}_step_{step_index}_invalid"
                )
            _bounded_text(
                step.get("skill_id"),
                issue=(
                    "graph_revision_outcome_attempt_"
                    f"{index}_step_{step_index}_skill_invalid"
                ),
                limit=120,
            )
            _bounded_text(
                step.get("purpose"),
                issue=(
                    "graph_revision_outcome_attempt_"
                    f"{index}_step_{step_index}_purpose_invalid"
                ),
                limit=NODE_LOOP_PURPOSE_LIMIT,
            )
            cost = step.get("cost")
            if not isinstance(cost, int) or cost < 1:
                raise ValueError(
                    "graph_revision_outcome_attempt_"
                    f"{index}_step_{step_index}_cost_invalid"
                )
            _validate_refs(
                step.get("input_refs"),
                issue=(
                    "graph_revision_outcome_attempt_"
                    f"{index}_step_{step_index}_input_refs_invalid"
                ),
                allow_empty=True,
            )
        _validate_refs(
            attempt.get("result_refs"),
            issue=f"graph_revision_outcome_attempt_{index}_result_refs_invalid",
            allow_empty=True,
        )
        _validate_refs(
            attempt.get("observation_refs"),
            issue=(
                f"graph_revision_outcome_attempt_{index}_observation_refs_invalid"
            ),
            allow_empty=True,
        )
        if set(attempt["observation_refs"]) - set(attempt["result_refs"]):
            raise ValueError(
                f"graph_revision_outcome_attempt_{index}_observation_not_result"
            )
        if not isinstance(attempt.get("evaluator_accepted"), bool):
            raise ValueError(
                f"graph_revision_outcome_attempt_{index}_accepted_invalid"
            )
        _bounded_text(
            attempt.get("evaluator_reason"),
            issue=f"graph_revision_outcome_attempt_{index}_reason_invalid",
            limit=2_000,
        )

    unmet = payload.get("unmet_criteria")
    if isinstance(unmet, (str, bytes)) or not isinstance(unmet, Sequence):
        raise ValueError("graph_revision_outcome_unmet_criteria_invalid")
    if scope == "graph" and not unmet:
        raise ValueError("graph_revision_outcome_graph_unmet_criteria_required")
    seen_criteria: set[str] = set()
    for index, criterion in enumerate(unmet, start=1):
        if (
            not isinstance(criterion, Mapping)
            or set(criterion) != _UNMET_CRITERION_KEYS
        ):
            raise ValueError(
                f"graph_revision_outcome_unmet_criterion_{index}_invalid"
            )
        criterion_id = _bounded_text(
            criterion.get("criterion_id"),
            issue=f"graph_revision_outcome_unmet_criterion_{index}_id_invalid",
            limit=120,
        )
        if criterion_id in seen_criteria:
            raise ValueError("graph_revision_outcome_unmet_criterion_duplicate")
        seen_criteria.add(criterion_id)
        if criterion.get("status") not in {"unmet", "indeterminate"}:
            raise ValueError(
                f"graph_revision_outcome_unmet_criterion_{index}_status_invalid"
            )
        _validate_refs(
            criterion.get("evidence_refs"),
            issue=(
                f"graph_revision_outcome_unmet_criterion_{index}_refs_invalid"
            ),
            allow_empty=True,
        )
        _bounded_text(
            criterion.get("reason"),
            issue=(
                f"graph_revision_outcome_unmet_criterion_{index}_reason_invalid"
            ),
            limit=2_000,
        )

    _validate_refs(
        payload.get("still_usable_refs"),
        issue="graph_revision_outcome_still_usable_refs_invalid",
        allow_empty=True,
    )


def render_graph_revision_outcome(
    payload: Mapping[str, Any],
    *,
    source_graph: Mapping[str, Any],
) -> str:
    validate_graph_revision_outcome(payload)
    validate_plan_graph(source_graph)
    failed = payload["failed_node"]
    lines = [
        "# Graph Revision Outcome",
        "",
        f"- Source revision: {payload['source_revision']}",
        f"- Revision scope: {payload['revision_scope']}",
        f"- Trigger: {payload['trigger']}",
    ]
    if isinstance(failed, Mapping):
        lines.extend(
            [
                f"- Failed node: {failed['node_id']}",
                f"- Intended outcome: {failed['outcome']}",
                f"- Completion condition: {failed['completion_condition']}",
                "",
                "## Structured Attempts",
                "",
                "```json",
                json.dumps(payload["attempts"], ensure_ascii=False, indent=2),
                "```",
            ]
        )
    lines.extend(
        [
            "",
            "## Unmet Evaluation Criteria",
            "",
            "```json",
            json.dumps(payload["unmet_criteria"], ensure_ascii=False, indent=2),
            "```",
            "",
            "## Backed-up Source Graph",
            "",
            "```text",
            render_plan_summary(source_graph),
            "```",
        ]
    )
    return "\n".join(lines)


def _events_for_revision(
    events: Sequence[Mapping[str, Any]],
    *,
    revision: int,
) -> list[Mapping[str, Any]]:
    start = 0
    for index, event in enumerate(events):
        if event.get("event_type") not in {
            "initial_plan_created",
            "graph_rebuilt",
        }:
            continue
        graph = event.get("plan_graph")
        if isinstance(graph, Mapping) and graph.get("revision") == revision:
            start = index
    return [event for event in events[start:] if isinstance(event, Mapping)]


def _attempt_records(
    events: Sequence[Mapping[str, Any]],
    *,
    node_id: str,
    fallback_refs: Sequence[str],
    final_reason: str,
    evaluator_accepted: bool,
    skill_costs: Mapping[str, int],
) -> list[dict[str, Any]]:
    by_index: dict[int, dict[str, Any]] = {}

    def ensure(attempt_index: int) -> dict[str, Any]:
        return by_index.setdefault(
            attempt_index,
            {
                "attempt_index": attempt_index,
                "planned_steps": [],
                "result_refs": [],
                "observation_refs": [],
                "evaluator_accepted": False,
                "evaluator_reason": _DEFAULT_ATTEMPT_REASON,
            },
        )

    current_index = 0
    attempt_open = False
    for event in events:
        event_type = str(event.get("event_type") or "")
        event_node_id = str(event.get("node_id") or "")
        raw_index = event.get("attempt_index")
        if (
            event_type == "node_loop_plan_model_turn"
            and event_node_id == node_id
            and isinstance(raw_index, int)
            and raw_index >= 1
        ):
            rejected_steps = _model_turn_planned_steps(
                event,
                skill_costs=skill_costs,
            )
            if rejected_steps:
                ensure(raw_index)["planned_steps"] = rejected_steps
            continue
        if event_type == "node_loop_attempt_started":
            if event_node_id != node_id:
                continue
            if isinstance(raw_index, int) and raw_index >= 1:
                current_index = raw_index
            if not current_index:
                continue
            attempt_open = True
            attempt = ensure(current_index)
            raw_steps = event.get("steps")
            if isinstance(raw_steps, Sequence) and not isinstance(
                raw_steps, (str, bytes)
            ):
                attempt["planned_steps"] = [
                    {
                        "skill_id": str(step.get("skill_id") or ""),
                        "purpose": str(step.get("purpose") or ""),
                        "input_refs": _step_input_refs(step),
                        "cost": int(step.get("cost") or 0),
                    }
                    for step in raw_steps
                    if isinstance(step, Mapping)
                ]
            continue

        if event_type in {
            "skill_workflow_completed",
            "skill_workflow_failed",
        }:
            if not current_index or not attempt_open:
                continue
            attempt = ensure(current_index)
            planned_skill_ids = {
                str(step.get("skill_id") or "")
                for step in attempt["planned_steps"]
                if isinstance(step, Mapping)
            }
            skill_id = str(event.get("skill_id") or "")
            if planned_skill_ids and skill_id not in planned_skill_ids:
                continue
            refs = event.get("artifact_refs")
            if isinstance(refs, Sequence) and not isinstance(refs, (str, bytes)):
                attempt["result_refs"] = _unique_refs(
                    [*attempt["result_refs"], *refs]
                )
            if event_type == "skill_workflow_failed":
                _append_reason(
                    attempt,
                    label=f"skill_failure[{skill_id or 'unknown'}]",
                    reason=event.get("reason"),
                    fragment_limit=1_000,
                )
            else:
                result = event.get("result")
                if isinstance(result, Mapping):
                    status = str(result.get("status") or "unknown")
                    _append_reason(
                        attempt,
                        label=(
                            f"skill_result[{skill_id or 'unknown'}:{status}]"
                        ),
                        reason=result.get("reason"),
                        fragment_limit=1_000,
                    )
            continue

        if event_type == "node_child_attempt_failed":
            if event_node_id != node_id:
                continue
            if isinstance(raw_index, int) and raw_index >= 1:
                current_index = raw_index
            attempt = ensure(current_index or 1)
            _append_reason(
                attempt,
                label="child_failure",
                reason=event.get("reason"),
                fragment_limit=1_500,
            )
            attempt_open = False
            continue

        if event_type == "node_attempt_handoff":
            if event_node_id != node_id:
                continue
            if isinstance(raw_index, int) and raw_index >= 1:
                current_index = raw_index
            attempt = ensure(current_index or 1)
            handoff_refs: list[str] = []
            handoff_refs.extend(
                ref for ref in _unique_refs(event.get("operational_refs") or ())
                if ref.startswith("execution_observation:")
            )
            raw_formal_refs = event.get("formal_result_refs")
            if isinstance(raw_formal_refs, Sequence) and not isinstance(
                raw_formal_refs, (str, bytes)
            ):
                handoff_refs.extend(
                    str(ref).strip()
                    for ref in raw_formal_refs
                    if str(ref).strip()
                )
            raw_project_receipts = event.get("project_receipts")
            if isinstance(raw_project_receipts, Sequence) and not isinstance(
                raw_project_receipts, (str, bytes)
            ):
                for receipt in raw_project_receipts:
                    if not isinstance(receipt, Mapping):
                        continue
                    snapshot_ref = str(
                        receipt.get("latest_snapshot_ref") or ""
                    ).strip()
                    if snapshot_ref:
                        handoff_refs.append(snapshot_ref)
            attempt["result_refs"] = _unique_refs(
                [*attempt["result_refs"], *handoff_refs]
            )
            continue

        if event_node_id != node_id:
            continue
        if isinstance(raw_index, int) and raw_index >= 1:
            current_index = raw_index
        if event_type == "node_loop_step_completed" and current_index:
            attempt = ensure(current_index)
            refs = event.get("artifact_refs")
            if isinstance(refs, Sequence) and not isinstance(refs, (str, bytes)):
                attempt["result_refs"] = _unique_refs(
                    [*attempt["result_refs"], *refs]
                )
            _append_reason(
                attempt,
                label="node_evaluator",
                reason=event.get("reason"),
                fragment_limit=500,
            )
            if bool(event.get("attempt_finished")):
                attempt_open = False
            continue
        if event_type in {
            "plan_work_unit_not_fulfilled",
            "node_loop_attempt_restarted",
            "node_loop_plan_failed",
        }:
            attempt = ensure(current_index or 1)
            _append_reason(
                attempt,
                label=(
                    "node_loop_planner"
                    if event_type == "node_loop_plan_failed"
                    else "node_evaluator"
                ),
                reason=event.get("reason"),
                fragment_limit=500,
            )

    if not by_index:
        ensure(1)
    selected_indexes = sorted(by_index)[-2:]
    records = [by_index[index] for index in selected_indexes]
    last = records[-1]
    recorded_refs = {
        ref
        for attempt in records
        for ref in attempt["result_refs"]
    }
    unassigned_fallback_refs = [
        ref
        for ref in _unique_refs(fallback_refs)
        if ref not in recorded_refs
    ]
    last["result_refs"] = _unique_refs(
        [*last["result_refs"], *unassigned_fallback_refs]
    )
    last["evaluator_accepted"] = evaluator_accepted
    _append_reason(
        last,
        label="graph_rebuild_trigger",
        reason=final_reason,
        fragment_limit=300,
    )
    for attempt in records:
        attempt["observation_refs"] = [
            ref
            for ref in attempt["result_refs"]
            if ref.startswith("execution_observation:")
        ]
    return records


def _model_turn_planned_steps(
    event: Mapping[str, Any],
    *,
    skill_costs: Mapping[str, int],
) -> list[dict[str, Any]]:
    """Recover a rejected pre-execution plan from its authoritative C6 turn."""
    raw_calls = event.get("tool_calls")
    if (
        isinstance(raw_calls, (str, bytes))
        or not isinstance(raw_calls, Sequence)
        or len(raw_calls) != 1
    ):
        return []
    call = raw_calls[0]
    if not isinstance(call, Mapping) or call.get("name") != "submit_node_loop":
        return []
    arguments = call.get("arguments")
    raw_steps = arguments.get("steps") if isinstance(arguments, Mapping) else None
    if (
        isinstance(raw_steps, (str, bytes))
        or not isinstance(raw_steps, Sequence)
        or not raw_steps
    ):
        return []
    projected: list[dict[str, Any]] = []
    for raw_step in raw_steps:
        if not isinstance(raw_step, Mapping):
            return []
        skill_id = str(raw_step.get("skill_id") or "").strip()
        purpose = str(raw_step.get("purpose") or "").strip()
        input_refs = _step_input_refs(raw_step)
        cost = skill_costs.get(skill_id)
        if not skill_id or not purpose or not isinstance(cost, int) or cost < 1:
            return []
        projected.append(
            {
                "skill_id": skill_id,
                "purpose": compact_node_loop_purpose(purpose),
                "input_refs": input_refs,
                "cost": cost,
            }
        )
    return projected


def operational_step_fingerprint(
    steps: Sequence[Mapping[str, Any]],
) -> tuple[tuple[str, tuple[str, ...]], ...]:
    """Return a science-neutral identity for one executable skill sequence."""
    fingerprint: list[tuple[str, tuple[str, ...]]] = []
    for index, step in enumerate(steps, start=1):
        if not isinstance(step, Mapping):
            raise ValueError(f"operational_step_{index}_invalid")
        skill_id = str(step.get("skill_id") or "").strip()
        if not skill_id:
            raise ValueError(f"operational_step_{index}_skill_invalid")
        input_refs = _step_input_refs(step)
        fingerprint.append((skill_id, tuple(sorted(input_refs))))
    if not fingerprint:
        raise ValueError("operational_steps_empty")
    return tuple(fingerprint)


def operational_attempt_fingerprint(
    *,
    node: Mapping[str, Any],
    steps: Sequence[Mapping[str, Any]],
) -> tuple[str, str, tuple[tuple[str, tuple[str, ...]], ...]]:
    """Identify an attempt by its exact node contract and executable inputs."""
    outcome = str(node.get("outcome") or "").strip()
    completion_condition = str(node.get("completion_condition") or "").strip()
    if not outcome:
        raise ValueError("operational_attempt_outcome_invalid")
    if not completion_condition:
        raise ValueError("operational_attempt_completion_condition_invalid")
    return (
        outcome,
        completion_condition,
        operational_step_fingerprint(steps),
    )


def graph_revision_attempt_fingerprints(
    payload: Mapping[str, Any],
) -> tuple[
    tuple[
        int,
        tuple[str, str, tuple[tuple[str, tuple[str, ...]], ...]],
    ],
    ...,
]:
    """Read executable attempt identities from one formal revision outcome."""
    validate_graph_revision_outcome(payload)
    failed_node = payload["failed_node"]
    if not isinstance(failed_node, Mapping):
        return ()
    fingerprints = []
    for attempt in payload["attempts"]:
        steps = attempt["planned_steps"]
        if not steps:
            continue
        fingerprints.append(
            (
                int(attempt["attempt_index"]),
                operational_attempt_fingerprint(
                    node=failed_node,
                    steps=steps,
                ),
            )
        )
    return tuple(fingerprints)


def _append_reason(
    attempt: dict[str, Any],
    *,
    label: str,
    reason: Any,
    fragment_limit: int,
) -> None:
    reason_text = str(reason or "").strip()
    if not reason_text:
        return
    existing = str(attempt.get("evaluator_reason") or "").strip()
    if reason_text in existing:
        return
    if existing == _DEFAULT_ATTEMPT_REASON:
        existing = ""
    fragment = f"{label}: {reason_text[:fragment_limit]}"
    combined = f"{existing}\n{fragment}".strip() if existing else fragment
    attempt["evaluator_reason"] = combined[:_REASON_LIMIT]


def _unique_refs(values: Sequence[Any]) -> list[str]:
    return list(
        dict.fromkeys(str(value).strip() for value in values if str(value).strip())
    )


def _step_input_refs(step: Mapping[str, Any]) -> list[str]:
    raw_refs = step.get("input_refs", [])
    if isinstance(raw_refs, (str, bytes)) or not isinstance(raw_refs, Sequence):
        return []
    return _unique_refs(raw_refs)


def _validate_refs(value: Any, *, issue: str, allow_empty: bool) -> None:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValueError(issue)
    refs = [item for item in value if isinstance(item, str) and item.strip()]
    if len(refs) != len(value) or len(refs) != len(set(refs)):
        raise ValueError(issue)
    if not allow_empty and not refs:
        raise ValueError(issue)


def _bounded_text(value: Any, *, issue: str, limit: int) -> str:
    if not isinstance(value, str) or not value.strip() or len(value.strip()) > limit:
        raise ValueError(issue)
    return value.strip()
