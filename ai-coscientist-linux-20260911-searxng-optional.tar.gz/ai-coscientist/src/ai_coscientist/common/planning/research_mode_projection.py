from __future__ import annotations

import json
from typing import Any, Mapping, Sequence

from .._runtime_support import function_tool
from ..memory_lifecycle.policy import PromptSource
from ..model import ChatModel, ModelTurn, complete_model_turn


_TASK_SOURCES = ("autonomous", "commissioned")
_RESEARCH_STRATEGIES = ("deepen", "explore")
RESEARCH_INPUT_ROLES = (
    "commission_authority",
    "required_authority",
    "shared_context",
    "comparison_baseline",
    "irrelevant",
)
RESEARCH_MODE_DECISION_NOTE_LIMIT = 2_000

_SYSTEM_PROMPT = """\
Finish the optional context binding for research-capable steps in an accepted
node-local LOOP draft. The skill sequence, purposes, order, and Stage A direct
input refs are already finalized and immutable. For every research step,
classify every supplied candidate ref exactly once, then choose the caller-owned
research mode.

Judge the two axes independently.

`task_source=autonomous` means the researcher may choose a useful question
inside the active Graph-node outcome. `task_source=commissioned` means the node
assigns a specific question, claim, gap, comparison, or existing result. A
commission may be defined entirely by the node text and therefore need not have
an artifact ref.

Classify refs by their role in this exact invocation, not merely by artifact
kind:
- `commission_authority`: the exact object the researcher must answer, check,
  improve, or transform.
- `required_authority`: a formal task, source, or structural prerequisite needed
  to perform the work, but not itself the commissioned object.
- `shared_context`: accepted research knowledge that may inform or later
  reconcile the work.
- `comparison_baseline`: a prior candidate or result that the new work must
  compare against or remain distinct from.
- `irrelevant`: not needed for this invocation.

Only `commission_authority` becomes `commissioned_input_refs`. Autonomous work
cannot use that role. Every Stage A `provisional_input_ref` is a finalized direct
input: retain it and classify it as an authority, shared context, or comparison
baseline as appropriate. Candidate refs added after Stage A are optional context
only and may be `shared_context`, `comparison_baseline`, or `irrelevant`; never
promote one to `commission_authority` or `required_authority`. All roles except
`irrelevant` become final `input_refs`.

Optional context is limited to artifact kinds not already bound by Stage A.
Another artifact of an already-bound kind is an alternative version or
authority, not harmless context, and is excluded mechanically. When a Skill
genuinely needs several same-kind inputs for comparison, Stage A must select
each one explicitly.

The selected Skill contract and Stage A planner own required direct inputs. This
projection must not repair an omitted prerequisite, add another task authority,
or replace the accepted input lineage. In particular, an ancestor `task_spec`
that Stage A did not select is provenance, not an additional task authority.

Read the selected Skill's detailed input contract and the current issue/work
context before adding optional context. An earlier failure is diagnostic evidence,
not a permanent blacklist. Do not restore an optional input that caused rejection
unless new accepted evidence resolves the reported conflict with the current
contract. A relevant artifact is not automatically a compatible input. Explain
any such resolved conflict in the existing decision_note; do not undo Stage A's
deliberate input selection merely because an artifact is available.

Choose research strategy solely from the first scientific draft. Use
`research_strategy=deepen` when non-commissioned shared research assets may
shape that first draft. Use `research_strategy=explore` when the first draft
must be formed without non-commissioned shared research assets. Explore mode may
and normally will restore, compare, cite, or reconcile those shared assets before
publication; that later reconciliation never turns explore into deepen.
Commissioned refs remain visible because they define the assigned work.

Return exactly one projection for every supplied research step and classify its
entire candidate set with no omissions or duplicates. Include one short
`decision_note` for C5 diagnosis. Do not add a reviewer, change a skill or
purpose, infer Graph transitions, or answer in prose. Call
submit_research_mode_projection exactly once.
"""

_REPAIR_SYSTEM_PROMPT = _SYSTEM_PROMPT + """\

This is one narrow repair of a mechanically rejected research-mode projection.
The Graph node, accepted Node LOOP steps, Skill identities, purposes, Stage A
direct inputs, candidate refs, and tool schema are frozen. Reclassify candidate
refs so the complete projection satisfies `validation_issue`. Return the
complete projection, not a patch, and do not repeat the rejected projection
unchanged.
"""


class ResearchModeProjectionError(RuntimeError):
    pass


def project_research_modes(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    active_node: Mapping[str, Any],
    attempt_index: int,
    research_steps: Sequence[Mapping[str, Any]],
    selected_skill_summaries: Sequence[Mapping[str, Any]],
    candidate_artifacts: Sequence[Mapping[str, Any]],
    current_issue: str = "",
    work_context: Mapping[str, Any] | None = None,
    previous_projection: Mapping[str, Any] | None = None,
    validation_issue: str = "",
) -> Mapping[str, Any]:
    """Bind candidate refs and project modes in one model call."""
    if not research_steps:
        raise ResearchModeProjectionError(
            "research_mode_projection_steps_required"
        )
    step_indices = [int(step["step_index"]) for step in research_steps]
    candidate_refs = tuple(
        dict.fromkeys(
            str(ref)
            for step in research_steps
            for ref in step.get("candidate_input_refs") or ()
            if str(ref)
        )
    )
    tool = _projection_tool(step_indices, candidate_refs)
    payload = {
        "active_graph_node": dict(active_node),
        "attempt_index": int(attempt_index),
        "immutable_research_steps": [dict(step) for step in research_steps],
        "selected_skill_summaries": [
            dict(item) for item in selected_skill_summaries
        ],
        "candidate_artifact_index": [dict(item) for item in candidate_artifacts],
        "current_issue": str(current_issue),
    }
    if work_context is not None:
        payload["work_context"] = dict(work_context)
    repairing = previous_projection is not None
    if repairing:
        issue = str(validation_issue).strip()
        if not issue:
            raise ResearchModeProjectionError(
                "research_mode_projection_repair_issue_required"
            )
        payload["previous_projection"] = dict(previous_projection)
        payload["validation_issue"] = issue
        purpose = (
            "repair research modes for node LOOP attempt "
            f"{attempt_index} on {active_node.get('node_id') or ''}"
        )
        system_prompt = _REPAIR_SYSTEM_PROMPT
    else:
        purpose = (
            "project research modes for node LOOP attempt "
            f"{attempt_index} on {active_node.get('node_id') or ''}"
        )
        system_prompt = _SYSTEM_PROMPT
    messages = [
        {"role": "system", "content": system_prompt},
        {
            "role": "user",
            "content": json.dumps(payload, ensure_ascii=False, indent=2),
        },
    ]
    tools = [tool]
    memory.prepare_for_model_call(call_site=purpose)
    memory.record_prompt_projection(
        call_site=purpose,
        messages=messages,
        tools=tools,
        sources=(
            PromptSource(
                "instruction",
                "research_mode_projection_instruction",
                messages[0],
            ),
            PromptSource(
                "C1",
                "research_mode_active_node_and_steps",
                {
                    "active_graph_node": payload["active_graph_node"],
                    "attempt_index": payload["attempt_index"],
                    "immutable_research_steps": payload[
                        "immutable_research_steps"
                    ],
                    "current_issue": payload["current_issue"],
                    **({"work_context": payload["work_context"]} if work_context is not None else {}),
                },
            ),
            PromptSource(
                "instruction",
                "research_skill_summaries",
                payload["selected_skill_summaries"],
            ),
            PromptSource(
                "C2",
                "research_candidate_artifact_index",
                payload["candidate_artifact_index"],
            ),
            *(
                (
                    PromptSource(
                        "C1",
                        "research_mode_projection_repair",
                        {
                            "previous_projection": payload[
                                "previous_projection"
                            ],
                            "validation_issue": payload["validation_issue"],
                        },
                    ),
                )
                if repairing
                else ()
            ),
            PromptSource(
                "tool_schema",
                "research_mode_projection_submission",
                tool,
            ),
        ),
        budget_tier="compact",
    )
    events.append(
        "research_mode_projection_prompt_snapshot",
        {
            "node_id": str(active_node.get("node_id") or ""),
            "attempt_index": int(attempt_index),
            "purpose": purpose,
            "messages": messages,
            "tool_names": ["submit_research_mode_projection"],
        },
    )
    turn = complete_model_turn(
        model,
        messages=messages,
        tools=tools,
        purpose=purpose,
        tool_choice="required",
        repair=repairing,
        planning=not repairing,
    )
    events.append(
        "research_mode_projection_model_turn",
        {
            "node_id": str(active_node.get("node_id") or ""),
            "attempt_index": int(attempt_index),
            "content": turn.content,
            "tool_calls": [
                {
                    "call_id": call.call_id,
                    "name": call.name,
                    "arguments": dict(call.arguments),
                }
                for call in turn.tool_calls
            ],
            "usage": dict(turn.usage),
        },
    )
    return _single_projection(turn)


def _projection_tool(
    step_indices: Sequence[int], candidate_refs: Sequence[str]
) -> dict[str, Any]:
    ref_schema: dict[str, Any] = {"type": "string"}
    if candidate_refs:
        ref_schema["enum"] = list(candidate_refs)
    return function_tool(
        "submit_research_mode_projection",
        "Bind candidate refs and assign one research mode per research step.",
        {
            "type": "object",
            "properties": {
                "step_modes": {
                    "type": "array",
                    "minItems": len(step_indices),
                    "maxItems": len(step_indices),
                    "items": {
                        "type": "object",
                        "properties": {
                            "step_index": {
                                "type": "integer",
                                "enum": list(step_indices),
                            },
                            "task_source": {
                                "type": "string",
                                "enum": list(_TASK_SOURCES),
                            },
                            "research_strategy": {
                                "type": "string",
                                "enum": list(_RESEARCH_STRATEGIES),
                            },
                            "input_roles": {
                                "type": "array",
                                "maxItems": len(candidate_refs),
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "artifact_ref": ref_schema,
                                        "role": {
                                            "type": "string",
                                            "enum": list(RESEARCH_INPUT_ROLES),
                                        },
                                    },
                                    "required": ["artifact_ref", "role"],
                                    "additionalProperties": False,
                                },
                            },
                            "decision_note": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": RESEARCH_MODE_DECISION_NOTE_LIMIT,
                            },
                        },
                        "required": [
                            "step_index",
                            "task_source",
                            "research_strategy",
                            "input_roles",
                            "decision_note",
                        ],
                        "additionalProperties": False,
                    },
                }
            },
            "required": ["step_modes"],
            "additionalProperties": False,
        },
    )


def _single_projection(turn: ModelTurn) -> Mapping[str, Any]:
    if len(turn.tool_calls) != 1:
        raise ResearchModeProjectionError(
            "research_mode_projection_requires_one_tool_call:"
            f"{len(turn.tool_calls)}"
        )
    call = turn.tool_calls[0]
    if call.name != "submit_research_mode_projection":
        raise ResearchModeProjectionError(
            "research_mode_projection_tool_mismatch:"
            f"submit_research_mode_projection:{call.name}"
        )
    return dict(call.arguments)
