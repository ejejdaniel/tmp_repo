from __future__ import annotations

import copy
from typing import Any, Mapping, Sequence


PLAN_STATUSES = frozenset({"pending", "in_progress", "completed", "cancelled"})
MAX_PLAN_GRAPH_NODES = 32
TASK_START_NODE_ID = "task-start"
FRAME_GOAL_NODE_ID = "frame-goal"
# Import compatibility for callers that predate the Frame/Global split. The
# persisted reserved id is FRAME_GOAL_NODE_ID.
TASK_GOAL_NODE_ID = FRAME_GOAL_NODE_ID
_MAX_RAW_PLAN_GRAPH_NODES = MAX_PLAN_GRAPH_NODES + 1
_MAX_STORED_PLAN_GRAPH_NODES = MAX_PLAN_GRAPH_NODES + 2
_GRAPH_KEYS = frozenset({"revision", "goal_node_id", "nodes"})
_NODE_KEYS = frozenset(
    {
        "node_id",
        "outcome",
        "completion_condition",
        "addresses_criteria",
        "decision_boundary",
        "depends_on",
        "transitions",
        "selected_transition_id",
        "status",
        "attempt_refs",
        "completion_refs",
    }
)
_RAW_NODE_KEYS = frozenset(
    {
        "node_id",
        "outcome",
        "completion_condition",
        "addresses_criteria",
        "decision_boundary",
        "depends_on",
        "transitions",
    }
)
_TRANSITION_KEYS = frozenset(
    {"transition_id", "condition", "target_node_id"}
)


def empty_plan_graph() -> dict[str, Any]:
    return {"revision": 0, "goal_node_id": "", "nodes": []}


def build_plan_graph(
    raw_nodes: Sequence[Mapping[str, Any]],
    *,
    revision: int,
    goal_node_id: str = FRAME_GOAL_NODE_ID,
    goal_criteria: Sequence[str] | None = None,
) -> dict[str, Any]:
    """Compile semantic work units into one structurally valid active graph."""
    if not isinstance(revision, int) or revision < 1:
        raise ValueError("plan_graph_revision_must_be_positive")
    goal_id = _bounded_text_field(
        goal_node_id,
        issue="plan_graph_goal_node_id_invalid",
        limit=80,
    )
    raw_node_ids = _preflight_raw_node_ids(raw_nodes)
    if TASK_START_NODE_ID in raw_node_ids:
        raise ValueError("plan_graph_reserved_start_node_id_used_as_work")
    work_node_count = len(
        [node_id for node_id in raw_node_ids if node_id != goal_id]
    )
    if work_node_count > MAX_PLAN_GRAPH_NODES:
        raise ValueError(
            f"plan_graph_nodes_length_must_be_1_to_{MAX_PLAN_GRAPH_NODES}"
        )
    normalized = _normalize_raw_nodes(raw_nodes)
    matching_goals = [
        node for node in normalized if str(node["node_id"]) == goal_id
    ]
    if len(matching_goals) > 1:
        raise ValueError("plan_graph_requires_exactly_one_goal_node")
    if not matching_goals:
        work_node_ids = {str(node["node_id"]) for node in normalized}
        depended_on = {
            str(dependency)
            for node in normalized
            for dependency in node["depends_on"]
            if str(dependency) in work_node_ids
        }
        sink_ids = [
            str(node["node_id"])
            for node in normalized
            if str(node["node_id"]) not in depended_on
        ]
        if not sink_ids:
            raise ValueError("plan_graph_goal_requires_predecessor")
        criteria = (
            [str(item).strip() for item in goal_criteria]
            if goal_criteria is not None
            else list(
                dict.fromkeys(
                    str(criterion_id)
                    for node in normalized
                    for criterion_id in node["addresses_criteria"]
                )
            )
        )
        if not criteria or any(not item for item in criteria):
            raise ValueError("plan_graph_goal_criteria_invalid")
        normalized.append(
            {
                "node_id": goal_id,
                "outcome": (
                    "Conclude the current Frame after evaluating the accepted "
                    "evidence produced by its enabled work route."
                ),
                "completion_condition": (
                    "The frame-level evaluator has issued a current judgment "
                    "after the enabled terminal predecessors complete, or has "
                    "already established the Frame success condition."
                ),
                "addresses_criteria": criteria,
                "decision_boundary": False,
                "depends_on": sink_ids,
                "transitions": [],
            }
        )
    normalized = _attach_structural_start_node(
        normalized,
        goal_node_id=goal_id,
    )
    ordered = _stable_topological_order(normalized)
    nodes = [
        {
            **node,
            "selected_transition_id": "",
            "status": (
                "completed"
                if str(node["node_id"]) == TASK_START_NODE_ID
                else "pending"
            ),
            "attempt_refs": [],
            "completion_refs": [],
        }
        for node in ordered
    ]
    entry = _next_ready_node(nodes, goal_node_id=goal_id)
    if entry is None:
        raise ValueError("plan_graph_requires_unconditional_entry_node")
    entry["status"] = "in_progress"
    graph = {
        "revision": revision,
        "goal_node_id": goal_id,
        "nodes": nodes,
    }
    validate_plan_graph(graph)
    return graph


def build_replacement_plan_graph(
    raw_nodes: Sequence[Mapping[str, Any]],
    *,
    revision: int,
    completed_nodes: Sequence[Mapping[str, Any]],
    goal_node_id: str = FRAME_GOAL_NODE_ID,
) -> dict[str, Any]:
    """Compile a replacement graph while preserving accepted node evidence."""
    if not isinstance(revision, int) or revision < 1:
        raise ValueError("plan_graph_revision_must_be_positive")
    goal_id = _bounded_text_field(
        goal_node_id,
        issue="plan_graph_goal_node_id_invalid",
        limit=80,
    )
    raw_node_ids = _preflight_raw_node_ids(raw_nodes)
    if TASK_START_NODE_ID in raw_node_ids:
        raise ValueError("plan_graph_reserved_start_node_id_used_as_work")
    if raw_node_ids.count(goal_id) != 1:
        raise ValueError("plan_graph_requires_exactly_one_goal_node")
    work_node_count = len(
        [node_id for node_id in raw_node_ids if node_id != goal_id]
    )
    if work_node_count > MAX_PLAN_GRAPH_NODES:
        raise ValueError(
            f"plan_graph_nodes_length_must_be_1_to_{MAX_PLAN_GRAPH_NODES}"
        )
    normalized = _normalize_raw_nodes(raw_nodes)
    normalized = _attach_structural_start_node(
        normalized,
        goal_node_id=goal_id,
    )
    ordered = _stable_topological_order(normalized)
    nodes = [
        {
            **node,
            "selected_transition_id": "",
            "status": "pending",
            "attempt_refs": [],
            "completion_refs": [],
        }
        for node in ordered
    ]
    graph = {
        "revision": revision,
        "goal_node_id": goal_id,
        "nodes": nodes,
    }
    by_id = {str(node["node_id"]): node for node in nodes}

    completed_by_id: dict[str, Mapping[str, Any]] = {}
    for index, raw in enumerate(completed_nodes, start=1):
        if not isinstance(raw, Mapping):
            raise ValueError(
                f"replacement_completed_node_{index}_must_be_object"
            )
        node_id = str(raw.get("node_id") or "").strip()
        if node_id == TASK_START_NODE_ID:
            continue
        if not node_id or node_id in completed_by_id:
            raise ValueError(
                f"replacement_completed_node_{index}_id_invalid"
            )
        if raw.get("status") != "completed":
            raise ValueError(
                f"replacement_completed_node_{node_id}_status_invalid"
            )
        if node_id not in by_id:
            raise ValueError(
                f"replacement_completed_node_missing_from_graph:{node_id}"
            )
        completed_by_id[node_id] = raw

    for node in nodes:
        node["status"] = (
            "completed"
            if str(node["node_id"]) == TASK_START_NODE_ID
            else "pending"
        )
        node["attempt_refs"] = []
        node["completion_refs"] = []
        node["selected_transition_id"] = ""

    for node_id, preserved in completed_by_id.items():
        target = by_id[node_id]
        preserved_attempts = list(preserved.get("attempt_refs") or ())
        preserved_completions = list(preserved.get("completion_refs") or ())
        if not preserved_completions:
            raise ValueError(
                f"replacement_completed_node_evidence_required:{node_id}"
            )
        if set(preserved_completions) - set(preserved_attempts):
            raise ValueError(
                f"replacement_completed_node_evidence_not_attempted:{node_id}"
            )
        target["status"] = "completed"
        target["attempt_refs"] = preserved_attempts
        target["completion_refs"] = preserved_completions

    # A selected conditional edge between two accepted completed nodes is a
    # historical causal fact. Restore that one traversed edge mechanically;
    # edges into retired or unfinished nodes stay only in the revision record.
    for node_id, preserved in completed_by_id.items():
        selected = str(preserved.get("selected_transition_id") or "").strip()
        if not selected:
            continue
        selected_edge = next(
            (
                dict(edge)
                for edge in preserved.get("transitions") or ()
                if isinstance(edge, Mapping)
                and str(edge.get("transition_id") or "").strip() == selected
            ),
            None,
        )
        if selected_edge is None:
            raise ValueError(
                f"replacement_completed_node_selected_edge_missing:{node_id}"
            )
        target_id = str(selected_edge.get("target_node_id") or "").strip()
        if target_id not in completed_by_id:
            continue
        target = by_id[node_id]
        target["decision_boundary"] = True
        target["transitions"] = [selected_edge]
        target["selected_transition_id"] = selected

    active = _next_ready_node(nodes, goal_node_id=graph["goal_node_id"])
    if active is not None:
        active["status"] = "in_progress"
    elif any(node["status"] == "pending" for node in nodes):
        raise ValueError("replacement_graph_has_no_reachable_pending_node")

    validate_plan_graph(graph)
    return graph


def apply_capability_refinements(
    p0_nodes: Sequence[Mapping[str, Any]],
    refinements: Sequence[Mapping[str, Any]],
    *,
    revision: int,
) -> dict[str, Any]:
    """Replace each P0 node exactly once and splice local subgraphs mechanically."""
    origins = _stable_topological_order(_normalize_raw_nodes(p0_nodes))
    origin_ids = [node["node_id"] for node in origins]
    origin_by_id = {node["node_id"]: node for node in origins}
    if isinstance(refinements, (str, bytes)) or not isinstance(
        refinements, Sequence
    ):
        raise ValueError("plan_refinements_must_be_array")

    raw_by_origin: dict[str, list[Mapping[str, Any]]] = {}
    replacement_ids_by_origin: dict[str, list[str]] = {}
    for index, raw in enumerate(refinements, start=1):
        if not isinstance(raw, Mapping) or set(raw) != {
            "origin_node_id",
            "replacement_nodes",
        }:
            raise ValueError(f"plan_refinement_{index}_fields_invalid")
        origin_id = _bounded_text_field(
            raw.get("origin_node_id"),
            issue=f"plan_refinement_{index}_origin_invalid",
            limit=80,
        )
        if origin_id in raw_by_origin:
            raise ValueError(f"plan_refinement_duplicate_origin:{origin_id}")
        replacement_source = raw.get("replacement_nodes")
        replacement_ids_by_origin[origin_id] = _preflight_raw_node_ids(
            replacement_source
        )
        raw_by_origin[origin_id] = list(replacement_source)

    if set(raw_by_origin) != set(origin_ids):
        raise ValueError(
            "plan_refinements_must_cover_every_p0_node:"
            f"missing={sorted(set(origin_ids) - set(raw_by_origin))}:"
            f"unexpected={sorted(set(raw_by_origin) - set(origin_ids))}"
        )

    all_replacement_ids = [
        node_id
        for origin_id in origin_ids
        for node_id in replacement_ids_by_origin[origin_id]
    ]
    if len(all_replacement_ids) != len(set(all_replacement_ids)):
        raise ValueError("plan_refinement_node_ids_must_be_globally_unique")
    if len(all_replacement_ids) > MAX_PLAN_GRAPH_NODES:
        raise ValueError(
            f"plan_graph_nodes_length_must_be_1_to_{MAX_PLAN_GRAPH_NODES}"
        )

    all_replacement_id_set = set(all_replacement_ids)
    origin_id_set = set(origin_ids)
    by_origin: dict[str, list[dict[str, Any]]] = {}
    for origin_id in origin_ids:
        local_ids = set(replacement_ids_by_origin[origin_id])
        predecessor_origins = set(origin_by_id[origin_id]["depends_on"])
        predecessor_replacements = {
            node_id
            for predecessor in predecessor_origins
            for node_id in replacement_ids_by_origin[predecessor]
        }
        inherited_refs = predecessor_origins | predecessor_replacements
        redundant_refs = inherited_refs - local_ids
        cleaned_source: list[Mapping[str, Any]] = []
        for node in raw_by_origin[origin_id]:
            dependencies = node.get("depends_on")
            if (
                isinstance(dependencies, (str, bytes))
                or not isinstance(dependencies, Sequence)
            ):
                cleaned_source.append(node)
                continue
            dependency_set = set(dependencies)
            forbidden_cross_origin = (
                dependency_set
                & (all_replacement_id_set | origin_id_set)
                - local_ids
                - inherited_refs
            )
            if forbidden_cross_origin:
                raise ValueError(
                    "plan_refinement_cross_origin_dependency_invalid:"
                    f"{origin_id}:{sorted(forbidden_cross_origin)}"
                )
            cleaned_source.append(
                {
                    **dict(node),
                    "depends_on": [
                        dependency
                        for dependency in dependencies
                        if dependency not in redundant_refs
                    ],
                }
            )
        replacements = _normalize_raw_nodes(cleaned_source)
        by_origin[origin_id] = _stable_topological_order(replacements)

    sinks_by_origin: dict[str, list[str]] = {}
    for origin_id in origin_ids:
        replacements = by_origin[origin_id]
        depended_on = {
            dependency
            for node in replacements
            for dependency in node["depends_on"]
        }
        sinks_by_origin[origin_id] = [
            node["node_id"]
            for node in replacements
            if node["node_id"] not in depended_on
        ]

    compiled: list[dict[str, Any]] = []
    for origin_id in origin_ids:
        replacements = by_origin[origin_id]
        replacement_ids = {node["node_id"] for node in replacements}
        incoming = [
            sink
            for predecessor in origin_by_id[origin_id]["depends_on"]
            for sink in sinks_by_origin[predecessor]
        ]
        for node in replacements:
            dependencies = list(node["depends_on"])
            if not set(dependencies) & replacement_ids:
                for predecessor in incoming:
                    if predecessor not in dependencies:
                        dependencies.append(predecessor)
            compiled.append({**node, "depends_on": dependencies})
    return build_plan_graph(compiled, revision=revision)


def validate_plan_graph(graph: Any, *, allow_empty: bool = False) -> None:
    if not isinstance(graph, Mapping) or set(graph) != _GRAPH_KEYS:
        raise ValueError("plan_graph_fields_invalid")
    revision = graph.get("revision")
    if not isinstance(revision, int) or revision < 0:
        raise ValueError("plan_graph_revision_invalid")
    raw_nodes = graph.get("nodes")
    goal_node_id = graph.get("goal_node_id")
    if not isinstance(goal_node_id, str):
        raise ValueError("plan_graph_goal_node_id_invalid")
    if isinstance(raw_nodes, (str, bytes)) or not isinstance(raw_nodes, Sequence):
        raise ValueError("plan_graph_nodes_invalid")
    if not raw_nodes:
        if allow_empty and revision == 0 and not goal_node_id:
            return
        raise ValueError("plan_graph_nodes_required")
    if len(raw_nodes) > _MAX_STORED_PLAN_GRAPH_NODES:
        raise ValueError(
            "plan_graph_nodes_length_must_be_1_to_"
            f"{_MAX_STORED_PLAN_GRAPH_NODES}"
        )
    goal_id = _bounded_text_field(
        goal_node_id,
        issue="plan_graph_goal_node_id_invalid",
        limit=80,
    )

    nodes: list[Mapping[str, Any]] = []
    node_ids: list[str] = []
    for index, node in enumerate(raw_nodes, start=1):
        if not isinstance(node, Mapping) or set(node) != _NODE_KEYS:
            raise ValueError(f"plan_graph_node_{index}_fields_invalid")
        node_id = _bounded_text_field(
            node.get("node_id"),
            issue=f"plan_graph_node_{index}_id_invalid",
            limit=80,
        )
        _bounded_text_field(
            node.get("outcome"),
            issue=f"plan_graph_node_{index}_outcome_invalid",
            limit=1_000,
        )
        _bounded_text_field(
            node.get("completion_condition"),
            issue=f"plan_graph_node_{index}_completion_condition_invalid",
            limit=1_000,
        )
        if not isinstance(node.get("decision_boundary"), bool):
            raise ValueError(
                f"plan_graph_node_{index}_decision_boundary_invalid"
            )
        dependencies = node.get("depends_on")
        transitions = node.get("transitions")
        selected_transition_id = node.get("selected_transition_id")
        addresses_criteria = node.get("addresses_criteria")
        attempt_refs = node.get("attempt_refs")
        completion_refs = node.get("completion_refs")
        if not _unique_nonempty_strings(dependencies):
            raise ValueError(f"plan_graph_node_{index}_dependencies_invalid")
        _validate_transitions(
            transitions,
            decision_boundary=bool(node["decision_boundary"]),
            issue_prefix=f"plan_graph_node_{index}",
            allow_single_selected=(
                node.get("status") == "completed"
                and bool(selected_transition_id)
            ),
        )
        if not isinstance(selected_transition_id, str):
            raise ValueError(
                f"plan_graph_node_{index}_selected_transition_id_invalid"
            )
        transition_ids = {
            str(item["transition_id"])
            for item in transitions
            if isinstance(item, Mapping)
        }
        if selected_transition_id and selected_transition_id not in transition_ids:
            raise ValueError(
                f"plan_graph_node_{index}_selected_transition_id_unknown"
            )
        if not _unique_nonempty_strings(addresses_criteria) or (
            not addresses_criteria and node_id != TASK_START_NODE_ID
        ):
            raise ValueError(
                f"plan_graph_node_{index}_addresses_criteria_invalid"
            )
        if not _unique_nonempty_strings(attempt_refs):
            raise ValueError(f"plan_graph_node_{index}_attempt_refs_invalid")
        if not _unique_nonempty_strings(completion_refs):
            raise ValueError(f"plan_graph_node_{index}_completion_refs_invalid")
        if set(completion_refs) - set(attempt_refs):
            raise ValueError(
                f"plan_graph_node_{index}_completion_refs_not_attempted"
            )
        if node.get("status") not in PLAN_STATUSES:
            raise ValueError(f"plan_graph_node_{index}_status_invalid")
        node_ids.append(node_id)
        nodes.append(node)
    if len(node_ids) != len(set(node_ids)):
        raise ValueError("plan_graph_node_ids_must_be_unique")
    known = set(node_ids)
    if TASK_START_NODE_ID not in known:
        raise ValueError("plan_graph_start_node_missing")
    if goal_id not in known:
        raise ValueError(f"plan_graph_goal_node_missing:{goal_id}")
    start = next(
        node for node in nodes if str(node["node_id"]) == TASK_START_NODE_ID
    )
    if (
        start["addresses_criteria"]
        or bool(start["decision_boundary"])
        or start["depends_on"]
        or start["transitions"]
        or start["selected_transition_id"]
        or start["attempt_refs"]
        or start["completion_refs"]
        or start["status"] != "completed"
    ):
        raise ValueError("plan_graph_start_node_shape_invalid")
    goal = next(node for node in nodes if str(node["node_id"]) == goal_id)
    if (
        bool(goal["decision_boundary"])
        or goal["transitions"]
        or goal["selected_transition_id"]
        or goal["attempt_refs"]
        or goal["completion_refs"]
        or not goal["depends_on"]
        or goal["status"] == "in_progress"
    ):
        raise ValueError("plan_graph_goal_node_shape_invalid")
    for node in nodes:
        unknown = set(node["depends_on"]) - known
        if unknown:
            raise ValueError(
                f"plan_graph_unknown_dependency:{node['node_id']}:{sorted(unknown)}"
            )
        if node["node_id"] in node["depends_on"]:
            raise ValueError(f"plan_graph_self_dependency:{node['node_id']}")
        if node["node_id"] != TASK_START_NODE_ID and not node["depends_on"]:
            raise ValueError(
                f"plan_graph_nonstart_node_requires_predecessor:{node['node_id']}"
            )
        if node["node_id"] != goal_id and goal_id in node["depends_on"]:
            raise ValueError(
                f"plan_graph_goal_node_outgoing_dependency:{node['node_id']}"
            )
        for transition in node["transitions"]:
            target = str(transition["target_node_id"])
            if target not in known:
                raise ValueError(
                    "plan_graph_unknown_transition_target:"
                    f"{node['node_id']}:{target}"
                )
            if target == TASK_START_NODE_ID:
                raise ValueError(
                    "plan_graph_start_node_incoming_transition_forbidden:"
                    f"{node['node_id']}"
                )
            if target == goal_id:
                raise ValueError(
                    "plan_graph_goal_conditional_incoming_forbidden:"
                    f"{node['node_id']}"
                )
    _stable_topological_order(
        [
            {
                "node_id": node["node_id"],
                "outcome": node["outcome"],
                "completion_condition": node["completion_condition"],
                "addresses_criteria": list(node["addresses_criteria"]),
                "decision_boundary": node["decision_boundary"],
                "depends_on": list(node["depends_on"]),
                "transitions": [dict(item) for item in node["transitions"]],
            }
            for node in nodes
        ]
    )
    _validate_transition_target_dependencies(nodes, goal_node_id=goal_id)
    _validate_exclusive_branch_reconvergence(
        nodes,
        goal_node_id=goal_id,
    )
    ancestors = _ancestor_map(nodes)
    disconnected_from_start = sorted(
        str(node["node_id"])
        for node in nodes
        if str(node["node_id"]) != TASK_START_NODE_ID
        and TASK_START_NODE_ID not in ancestors[str(node["node_id"])]
    )
    if disconnected_from_start:
        raise ValueError(
            "plan_graph_nodes_have_no_start_path:"
            f"{disconnected_from_start}"
        )
    start_successors = [
        str(node["node_id"])
        for node in nodes
        if TASK_START_NODE_ID in node["depends_on"]
        and str(node["node_id"]) != goal_id
    ]
    if not start_successors:
        raise ValueError("plan_graph_start_node_requires_work_successor")
    goal_ancestors = ancestors[goal_id]
    stranded_active_work = sorted(
        str(node["node_id"])
        for node in nodes
        if str(node["node_id"]) != goal_id
        and node["status"] in {"pending", "in_progress"}
        and str(node["node_id"]) not in goal_ancestors
    )
    if stranded_active_work:
        raise ValueError(
            "plan_graph_active_work_has_no_goal_path:"
            f"{stranded_active_work}"
        )

    active = [node for node in nodes if node["status"] == "in_progress"]
    if len(active) > 1:
        raise ValueError(f"plan_graph_requires_at_most_one_active_node:{len(active)}")
    status_by_id = {node["node_id"]: node["status"] for node in nodes}
    if active and any(
        status_by_id[dependency] != "completed"
        for dependency in active[0]["depends_on"]
    ):
        raise ValueError("plan_graph_active_node_dependencies_incomplete")
    if active and not _transition_target_is_enabled(active[0], nodes):
        raise ValueError("plan_graph_active_node_transition_not_selected")
    ready_pending = _ready_pending_nodes(nodes, goal_node_id=goal_id)
    if not active and ready_pending:
        raise ValueError("plan_graph_ready_node_requires_activation")


def active_work_unit(graph: Mapping[str, Any]) -> Mapping[str, Any] | None:
    validate_plan_graph(graph, allow_empty=True)
    for node in graph["nodes"]:
        if (
            node["status"] == "in_progress"
            and str(node["node_id"]) != str(graph["goal_node_id"])
        ):
            return copy.deepcopy(dict(node))
    return None


def frame_goal_node(graph: Mapping[str, Any]) -> Mapping[str, Any] | None:
    """Return the current Frame's unique non-executable closure node."""
    validate_plan_graph(graph, allow_empty=True)
    goal_id = str(graph.get("goal_node_id") or "")
    if not goal_id:
        return None
    return copy.deepcopy(
        next(
            dict(node)
            for node in graph["nodes"]
            if str(node["node_id"]) == goal_id
        )
    )


def frame_goal_is_ready(graph: Mapping[str, Any]) -> bool:
    """Return whether all enabled Frame-goal predecessors are complete."""
    validate_plan_graph(graph, allow_empty=True)
    goal_id = str(graph.get("goal_node_id") or "")
    if not goal_id:
        return False
    nodes = graph["nodes"]
    goal = next(node for node in nodes if str(node["node_id"]) == goal_id)
    if goal["status"] == "completed":
        return True
    enabled_dependencies = [
        str(node_id)
        for node_id in goal["depends_on"]
        if _route_is_enabled(str(node_id), nodes)
    ]
    if not enabled_dependencies:
        return False
    status_by_id = {
        str(node["node_id"]): str(node["status"]) for node in nodes
    }
    return all(
        status_by_id[node_id] == "completed"
        for node_id in enabled_dependencies
    )


def settle_frame_graph(graph: Mapping[str, Any]) -> dict[str, Any]:
    """Close one evaluated Frame without treating it as global success."""
    validate_plan_graph(graph, allow_empty=True)
    updated = copy.deepcopy(dict(graph))
    goal_id = str(updated.get("goal_node_id") or "")
    if not goal_id:
        raise ValueError("frame_settlement_goal_required")
    for node in updated["nodes"]:
        node_id = str(node["node_id"])
        if node_id == goal_id:
            node["status"] = "completed"
        elif node["status"] in {"pending", "in_progress"}:
            node["status"] = "cancelled"
    validate_plan_graph(updated)
    return updated


# Compatibility aliases for older callers. Their semantics are Frame-local.
task_goal_node = frame_goal_node
task_goal_is_ready = frame_goal_is_ready


def active_work_unit_context_refs(
    graph: Mapping[str, Any],
) -> tuple[str, ...]:
    """Return exact evidence refs available to the active node."""
    validate_plan_graph(graph, allow_empty=True)
    active = next(
        (node for node in graph["nodes"] if node["status"] == "in_progress"),
        None,
    )
    if active is None:
        return ()

    by_id = {str(node["node_id"]): node for node in graph["nodes"]}
    refs: list[str] = []

    def append_refs(values: Any) -> None:
        if not isinstance(values, Sequence) or isinstance(values, (str, bytes)):
            return
        for value in values:
            ref = str(value).strip()
            if ref and ref not in refs:
                refs.append(ref)

    append_refs(active["attempt_refs"])
    pending = [str(node_id) for node_id in active["depends_on"]]
    visited: set[str] = set()
    while pending:
        node_id = pending.pop()
        if node_id in visited:
            continue
        visited.add(node_id)
        node = by_id.get(node_id)
        if node is None:
            continue
        # Attempt refs are diagnostic history, not accepted predecessor
        # authority. A useful partial result must first be accepted as
        # completion evidence or promoted into its own preserved node before a
        # downstream node may consume it.
        append_refs(node["completion_refs"])
        pending.extend(str(item) for item in node["depends_on"])
    return tuple(refs)


def ready_pending_work_units(
    graph: Mapping[str, Any],
) -> tuple[Mapping[str, Any], ...]:
    """Return pending nodes whose declared graph prerequisites are satisfied."""
    validate_plan_graph(graph, allow_empty=True)
    return tuple(
        copy.deepcopy(dict(node))
        for node in _ready_pending_nodes(
            graph["nodes"],
            goal_node_id=str(graph["goal_node_id"]),
        )
    )


def complete_ready_plan_node(
    graph: Mapping[str, Any],
    *,
    node_id: str,
    evidence_refs: Sequence[str],
) -> dict[str, Any]:
    """Complete one ready non-active result without disturbing current focus."""
    validate_plan_graph(graph)
    updated = copy.deepcopy(dict(graph))
    nodes = updated["nodes"]
    target = next(
        (node for node in nodes if str(node["node_id"]) == str(node_id)),
        None,
    )
    if target is None:
        raise ValueError(f"plan_graph_unknown_ready_node:{node_id}")
    if str(target["node_id"]) == str(graph["goal_node_id"]):
        raise ValueError("plan_graph_goal_node_is_not_executable")
    if target["status"] != "pending":
        raise ValueError(f"plan_graph_ready_node_not_pending:{node_id}")
    ready_ids = {
        str(node["node_id"])
        for node in _ready_pending_nodes(
            nodes,
            goal_node_id=str(graph["goal_node_id"]),
        )
    }
    if str(node_id) not in ready_ids:
        raise ValueError(f"plan_graph_node_not_ready:{node_id}")
    if target["transitions"]:
        raise ValueError(
            f"plan_graph_ready_conditional_node_requires_active_focus:{node_id}"
        )
    refs = [str(ref).strip() for ref in evidence_refs if str(ref).strip()]
    if not refs or len(refs) != len(set(refs)):
        raise ValueError(f"plan_graph_ready_node_evidence_invalid:{node_id}")
    for ref in refs:
        if ref not in target["attempt_refs"]:
            target["attempt_refs"].append(ref)
        if ref not in target["completion_refs"]:
            target["completion_refs"].append(ref)
    target["status"] = "completed"
    validate_plan_graph(updated)
    return updated


def record_plan_attempt(
    graph: Mapping[str, Any],
    *,
    node_id: str,
    artifact_ref: str,
) -> dict[str, Any]:
    """Attach one real produced artifact to the active work unit."""
    validate_plan_graph(graph)
    ref = str(artifact_ref).strip()
    if not ref:
        raise ValueError("plan_graph_attempt_ref_required")
    updated = copy.deepcopy(dict(graph))
    active = next(
        (
            node
            for node in updated["nodes"]
            if node["status"] == "in_progress"
        ),
        None,
    )
    if active is None or active["node_id"] != node_id:
        raise ValueError(f"plan_graph_active_node_mismatch:{node_id}")
    if str(active["node_id"]) == str(graph["goal_node_id"]):
        raise ValueError("plan_graph_goal_node_is_not_executable")
    if ref not in active["attempt_refs"]:
        active["attempt_refs"].append(ref)
    validate_plan_graph(updated)
    return updated


def record_plan_completion(
    graph: Mapping[str, Any],
    *,
    node_id: str,
    evidence_refs: Sequence[str],
) -> dict[str, Any]:
    """Record judge-approved completion evidence without selecting an edge."""
    validate_plan_graph(graph)
    updated = copy.deepcopy(dict(graph))
    active = next(
        (node for node in updated["nodes"] if node["status"] == "in_progress"),
        None,
    )
    if active is None or active["node_id"] != node_id:
        raise ValueError(f"plan_graph_active_node_mismatch:{node_id}")
    if str(active["node_id"]) == str(graph["goal_node_id"]):
        raise ValueError("plan_graph_goal_node_is_not_executable")
    refs = [str(ref).strip() for ref in evidence_refs if str(ref).strip()]
    if not refs or len(refs) != len(set(refs)):
        raise ValueError("plan_graph_completion_refs_invalid")
    for ref in refs:
        if ref not in active["attempt_refs"]:
            active["attempt_refs"].append(ref)
        if ref not in active["completion_refs"]:
            active["completion_refs"].append(ref)
    validate_plan_graph(updated)
    return updated


def advance_plan_graph(
    graph: Mapping[str, Any],
    *,
    node_id: str,
    evidence_refs: Sequence[str],
    task_complete: bool,
    selected_transition_id: str = "",
) -> dict[str, Any]:
    validate_plan_graph(graph)
    updated = copy.deepcopy(dict(graph))
    nodes = updated["nodes"]
    active = next(
        (node for node in nodes if node["status"] == "in_progress"),
        None,
    )
    if active is None or active["node_id"] != node_id:
        raise ValueError(f"plan_graph_active_node_mismatch:{node_id}")
    if str(active["node_id"]) == str(graph["goal_node_id"]):
        raise ValueError("plan_graph_goal_node_is_not_executable")
    refs = [str(ref).strip() for ref in evidence_refs if str(ref).strip()]
    if len(refs) != len(set(refs)):
        raise ValueError("plan_graph_completion_refs_must_be_unique")
    for ref in refs:
        if ref not in active["attempt_refs"]:
            active["attempt_refs"].append(ref)
        if ref not in active["completion_refs"]:
            active["completion_refs"].append(ref)
    selected = str(selected_transition_id).strip()
    has_conditional_transitions = bool(active["transitions"])
    if has_conditional_transitions:
        transition_ids = {
            str(item["transition_id"]): str(item["target_node_id"])
            for item in active["transitions"]
        }
        if selected not in transition_ids:
            raise ValueError("plan_graph_selected_transition_required")
        active["selected_transition_id"] = selected
    elif selected:
        raise ValueError("plan_graph_unconditional_transition_forbidden")
    active["status"] = "completed"

    if task_complete:
        for node in nodes:
            if node["status"] == "pending":
                node["status"] = "cancelled"
        validate_plan_graph(updated)
        return updated

    if has_conditional_transitions:
        target_id = transition_ids[selected]
        next_node = next(node for node in nodes if node["node_id"] == target_id)
        if next_node["status"] == "pending":
            ready = _next_ready_node(
                nodes,
                goal_node_id=str(updated["goal_node_id"]),
            )
            if ready is not None:
                ready["status"] = "in_progress"
        validate_plan_graph(updated)
        return updated

    next_node = _next_ready_node(
        nodes,
        goal_node_id=str(updated["goal_node_id"]),
    )
    if next_node is None:
        validate_plan_graph(updated)
        return updated
    next_node["status"] = "in_progress"
    validate_plan_graph(updated)
    return updated


def reconcile_plan_with_evaluation(
    graph: Mapping[str, Any],
    *,
    closure: Mapping[str, Any],
) -> dict[str, Any]:
    """Cancel unresolved work only after evaluator-backed overall success."""
    validate_plan_graph(graph, allow_empty=True)
    updated = copy.deepcopy(dict(graph))
    if not bool(closure.get("complete")) or not bool(closure.get("success")):
        return updated

    raw_results = closure.get("criterion_results")
    if isinstance(raw_results, (str, bytes)) or not isinstance(
        raw_results, Sequence
    ):
        raise ValueError("plan_reconciliation_criteria_must_be_array")

    results_by_id: dict[str, list[str]] = {}
    for index, raw in enumerate(raw_results, start=1):
        if not isinstance(raw, Mapping):
            raise ValueError(
                f"plan_reconciliation_criterion_{index}_must_be_object"
            )
        criterion_id = str(raw.get("criterion_id") or "").strip()
        if not criterion_id or criterion_id in results_by_id:
            raise ValueError(
                f"plan_reconciliation_criterion_{index}_id_invalid"
            )
        if str(raw.get("status") or "") != "met":
            raise ValueError(
                f"plan_reconciliation_criterion_{criterion_id}_not_met"
            )
        raw_refs = raw.get("evidence_refs")
        if isinstance(raw_refs, (str, bytes)) or not isinstance(
            raw_refs, Sequence
        ):
            raise ValueError(
                f"plan_reconciliation_criterion_{criterion_id}_refs_invalid"
            )
        refs = [str(ref).strip() for ref in raw_refs if str(ref).strip()]
        if not refs or len(refs) != len(set(refs)):
            raise ValueError(
                f"plan_reconciliation_criterion_{criterion_id}_refs_invalid"
            )
        results_by_id[criterion_id] = refs

    for node in updated["nodes"]:
        if str(node["node_id"]) == str(updated["goal_node_id"]):
            node["status"] = "completed"
            continue
        if node["status"] not in {"pending", "in_progress"}:
            continue
        missing = set(node["addresses_criteria"]) - set(results_by_id)
        if missing:
            raise ValueError(
                f"plan_reconciliation_missing_criteria:{node['node_id']}:"
                f"{sorted(missing)}"
            )
        node["status"] = "cancelled"

    validate_plan_graph(updated, allow_empty=True)
    return updated


def render_plan_summary(graph: Mapping[str, Any]) -> str:
    validate_plan_graph(graph, allow_empty=True)
    if not graph["nodes"]:
        return ""
    lines = [f"# Plan (revision {graph['revision']})"]
    for index, node in enumerate(graph["nodes"], start=1):
        role = (
            "start"
            if str(node["node_id"]) == TASK_START_NODE_ID
            else (
                "goal"
                if str(node["node_id"]) == str(graph["goal_node_id"])
                else "work"
            )
        )
        dependencies = ", ".join(node["depends_on"]) or "none"
        criteria = ", ".join(node["addresses_criteria"])
        attempts = ", ".join(node["attempt_refs"]) or "none"
        refs = ", ".join(node["completion_refs"]) or "none"
        selected = node["selected_transition_id"] or "none"
        transitions = "; ".join(
            f"{item['transition_id']} when {item['condition']} -> "
            f"{item['target_node_id']}"
            for item in node["transitions"]
        ) or "none"
        lines.append(
            f"{index}. [{node['status']} | {role}] {node['node_id']}: "
            f"{node['outcome']} | Done when: {node['completion_condition']} | "
            f"Conditional transitions: {transitions} | Selected: {selected} | "
            f"Addresses: {criteria} | Depends on: {dependencies} | "
            f"Attempt refs: {attempts} | Completion refs: {refs}"
        )
    return "\n".join(lines)


def _normalize_raw_nodes(raw_nodes: Any) -> list[dict[str, Any]]:
    if isinstance(raw_nodes, (str, bytes)) or not isinstance(raw_nodes, Sequence):
        raise ValueError("plan_graph_nodes_must_be_array")
    if not 1 <= len(raw_nodes) <= _MAX_RAW_PLAN_GRAPH_NODES:
        raise ValueError(
            "plan_graph_nodes_length_must_be_1_to_"
            f"{_MAX_RAW_PLAN_GRAPH_NODES}"
        )
    normalized: list[dict[str, Any]] = []
    for index, raw in enumerate(raw_nodes, start=1):
        if not isinstance(raw, Mapping):
            raise ValueError(
                f"plan_graph_raw_node_{index}_fields_invalid:"
                f"actual_type={type(raw).__name__}:"
                f"required={sorted(_RAW_NODE_KEYS)!r}"
            )
        actual_keys = set(raw)
        if actual_keys != _RAW_NODE_KEYS:
            raise ValueError(
                f"plan_graph_raw_node_{index}_fields_invalid:"
                f"missing={sorted(_RAW_NODE_KEYS - actual_keys)!r}:"
                f"extra={sorted(actual_keys - _RAW_NODE_KEYS)!r}"
            )
        node_id = _bounded_text_field(
            raw.get("node_id"),
            issue=f"plan_graph_raw_node_{index}_id_invalid",
            limit=80,
        )
        outcome = _bounded_text_field(
            raw.get("outcome"),
            issue=f"plan_graph_raw_node_{index}_outcome_invalid",
            limit=1_000,
        )
        completion = _bounded_text_field(
            raw.get("completion_condition"),
            issue=f"plan_graph_raw_node_{index}_completion_condition_invalid",
            limit=1_000,
        )
        decision_boundary = raw.get("decision_boundary")
        if not isinstance(decision_boundary, bool):
            raise ValueError(
                f"plan_graph_raw_node_{index}_decision_boundary_invalid"
            )
        addresses_criteria = raw.get("addresses_criteria")
        if (
            not _unique_nonempty_strings(addresses_criteria)
            or not addresses_criteria
        ):
            raise ValueError(
                f"plan_graph_raw_node_{index}_addresses_criteria_invalid"
            )
        dependencies = raw.get("depends_on")
        if not _unique_nonempty_strings(dependencies):
            raise ValueError(f"plan_graph_raw_node_{index}_dependencies_invalid")
        transitions = raw.get("transitions")
        _validate_transitions(
            transitions,
            decision_boundary=decision_boundary,
            issue_prefix=f"plan_graph_raw_node_{index}",
        )
        normalized.append(
            {
                "node_id": node_id,
                "outcome": outcome,
                "completion_condition": completion,
                "addresses_criteria": list(addresses_criteria),
                "decision_boundary": decision_boundary,
                "depends_on": list(dependencies),
                "transitions": [dict(item) for item in transitions],
            }
        )
    ids = [node["node_id"] for node in normalized]
    if len(ids) != len(set(ids)):
        raise ValueError("plan_graph_node_ids_must_be_unique")
    known = set(ids)
    for node in normalized:
        unknown = set(node["depends_on"]) - known
        if unknown:
            raise ValueError(
                f"plan_graph_unknown_dependency:{node['node_id']}:{sorted(unknown)}"
            )
        if node["node_id"] in node["depends_on"]:
            raise ValueError(f"plan_graph_self_dependency:{node['node_id']}")
        for transition in node["transitions"]:
            target = str(transition["target_node_id"])
            if target not in known:
                raise ValueError(
                    "plan_graph_unknown_transition_target:"
                    f"{node['node_id']}:{target}"
                )
    return normalized


def _preflight_raw_node_ids(raw_nodes: Any) -> list[str]:
    if isinstance(raw_nodes, (str, bytes)) or not isinstance(raw_nodes, Sequence):
        raise ValueError("plan_graph_nodes_must_be_array")
    if not 1 <= len(raw_nodes) <= _MAX_RAW_PLAN_GRAPH_NODES:
        raise ValueError(
            "plan_graph_nodes_length_must_be_1_to_"
            f"{_MAX_RAW_PLAN_GRAPH_NODES}"
        )
    node_ids: list[str] = []
    for index, raw in enumerate(raw_nodes, start=1):
        if not isinstance(raw, Mapping):
            raise ValueError(
                f"plan_graph_raw_node_{index}_fields_invalid:"
                f"actual_type={type(raw).__name__}:"
                f"required={sorted(_RAW_NODE_KEYS)!r}"
            )
        actual_keys = set(raw)
        if actual_keys != _RAW_NODE_KEYS:
            raise ValueError(
                f"plan_graph_raw_node_{index}_fields_invalid:"
                f"missing={sorted(_RAW_NODE_KEYS - actual_keys)!r}:"
                f"extra={sorted(actual_keys - _RAW_NODE_KEYS)!r}"
            )
        node_ids.append(
            _bounded_text_field(
                raw.get("node_id"),
                issue=f"plan_graph_raw_node_{index}_id_invalid",
                limit=80,
            )
        )
    if len(node_ids) != len(set(node_ids)):
        raise ValueError("plan_graph_node_ids_must_be_unique")
    return node_ids


def _stable_topological_order(
    nodes: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    ordered_input = [dict(node) for node in nodes]
    by_id = {node["node_id"]: node for node in ordered_input}
    remaining = set(by_id)
    emitted: list[str] = []
    while remaining:
        ready = [
            node["node_id"]
            for node in ordered_input
            if node["node_id"] in remaining
            and all(dependency in emitted for dependency in node["depends_on"])
        ]
        if not ready:
            raise ValueError(f"plan_graph_cycle_detected:{sorted(remaining)}")
        for node_id in ready:
            emitted.append(node_id)
            remaining.remove(node_id)
    return [copy.deepcopy(by_id[node_id]) for node_id in emitted]


def _attach_structural_start_node(
    nodes: Sequence[Mapping[str, Any]],
    *,
    goal_node_id: str,
) -> list[dict[str, Any]]:
    """Add the non-executable start anchor and connect every work root."""
    copied = [copy.deepcopy(dict(node)) for node in nodes]
    if any(str(node["node_id"]) == TASK_START_NODE_ID for node in copied):
        raise ValueError("plan_graph_reserved_start_node_id_used_as_work")
    roots = [
        node
        for node in copied
        if str(node["node_id"]) != str(goal_node_id)
        and not node["depends_on"]
    ]
    if not roots:
        raise ValueError("plan_graph_start_requires_work_successor")
    for node in roots:
        node["depends_on"] = [TASK_START_NODE_ID]
    return [
        {
            "node_id": TASK_START_NODE_ID,
            "outcome": "Anchor the beginning of the task graph.",
            "completion_condition": (
                "This structural node is complete when the graph is created."
            ),
            "addresses_criteria": [],
            "decision_boundary": False,
            "depends_on": [],
            "transitions": [],
        },
        *copied,
    ]


def ensure_plan_graph_start_node(graph: Mapping[str, Any]) -> dict[str, Any]:
    """Mechanically migrate one stored pre-start graph without changing work."""
    migrated = copy.deepcopy(dict(graph))
    raw_nodes = migrated.get("nodes")
    if not raw_nodes:
        return migrated
    if not isinstance(raw_nodes, Sequence) or isinstance(raw_nodes, (str, bytes)):
        raise ValueError("plan_graph_nodes_invalid")
    if any(
        isinstance(node, Mapping)
        and str(node.get("node_id") or "") == TASK_START_NODE_ID
        for node in raw_nodes
    ):
        validate_plan_graph(migrated)
        return migrated
    goal_id = str(migrated.get("goal_node_id") or "").strip()
    stored_nodes = [copy.deepcopy(dict(node)) for node in raw_nodes]
    roots = [
        node
        for node in stored_nodes
        if str(node.get("node_id") or "") != goal_id
        and not node.get("depends_on")
    ]
    if not roots:
        raise ValueError("plan_graph_start_requires_work_successor")
    for node in roots:
        node["depends_on"] = [TASK_START_NODE_ID]
    start = {
        "node_id": TASK_START_NODE_ID,
        "outcome": "Anchor the beginning of the task graph.",
        "completion_condition": (
            "This structural node is complete when the graph is created."
        ),
        "addresses_criteria": [],
        "decision_boundary": False,
        "depends_on": [],
        "transitions": [],
        "selected_transition_id": "",
        "status": "completed",
        "attempt_refs": [],
        "completion_refs": [],
    }
    migrated["nodes"] = _stable_topological_order([start, *stored_nodes])
    validate_plan_graph(migrated)
    return migrated


def _validate_transitions(
    value: Any,
    *,
    decision_boundary: bool,
    issue_prefix: str,
    allow_single_selected: bool = False,
) -> None:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValueError(f"{issue_prefix}_transitions_invalid")
    minimum_transition_count = 1 if allow_single_selected else 2
    if decision_boundary and len(value) < minimum_transition_count:
        raise ValueError(f"{issue_prefix}_decision_transitions_required")
    if not decision_boundary and value:
        raise ValueError(f"{issue_prefix}_nondecision_transitions_forbidden")
    transition_ids: list[str] = []
    conditions: list[str] = []
    target_node_ids: list[str] = []
    for index, transition in enumerate(value, start=1):
        if not isinstance(transition, Mapping) or set(transition) != _TRANSITION_KEYS:
            raise ValueError(
                f"{issue_prefix}_transition_{index}_fields_invalid"
            )
        transition_ids.append(
            _bounded_text_field(
                transition.get("transition_id"),
                issue=f"{issue_prefix}_transition_{index}_id_invalid",
                limit=80,
            )
        )
        conditions.append(
            _bounded_text_field(
                transition.get("condition"),
                issue=f"{issue_prefix}_transition_{index}_condition_invalid",
                limit=500,
            )
        )
        target_node_ids.append(
            _bounded_text_field(
                transition.get("target_node_id"),
                issue=f"{issue_prefix}_transition_{index}_target_invalid",
                limit=80,
            )
        )
    if len(transition_ids) != len(set(transition_ids)):
        raise ValueError(f"{issue_prefix}_transition_ids_must_be_unique")
    if len(conditions) != len(set(conditions)):
        duplicates = sorted(
            {
                condition
                for condition in conditions
                if conditions.count(condition) > 1
            }
        )
        duplicate_edges = [
            {
                "transition_id": str(transition["transition_id"]),
                "condition": str(transition["condition"]),
                "target_node_id": str(transition["target_node_id"]),
            }
            for transition in value
            if str(transition["condition"]) in duplicates
        ]
        raise ValueError(
            f"{issue_prefix}_transition_conditions_must_be_distinct:"
            f"duplicate_edges={duplicate_edges}"
        )
    minimum_target_count = 1 if allow_single_selected else 2
    if decision_boundary and len(set(target_node_ids)) < minimum_target_count:
        raise ValueError(
            f"{issue_prefix}_decision_transitions_require_distinct_targets:"
            f"target_node_ids={target_node_ids}"
        )


def _validate_transition_target_dependencies(
    nodes: Sequence[Mapping[str, Any]],
    *,
    goal_node_id: str,
) -> None:
    """Keep every conditional transition forward in the causal DAG."""
    ancestors = _ancestor_map(nodes)
    for source in nodes:
        source_id = str(source["node_id"])
        for transition in source["transitions"]:
            target_id = str(transition["target_node_id"])
            is_back_or_self = (
                target_id == source_id or target_id in ancestors[source_id]
            )
            if is_back_or_self:
                raise ValueError(
                    "plan_graph_conditional_cycle_forbidden:"
                    f"{source_id}:{target_id}"
                )
            if source_id not in ancestors[target_id]:
                allowed_target_ids = sorted(
                    str(candidate["node_id"])
                    for candidate in nodes
                    if str(candidate["node_id"])
                    not in {str(goal_node_id), TASK_START_NODE_ID}
                    and (
                        str(candidate["node_id"]) == source_id
                        or str(candidate["node_id"]) in ancestors[source_id]
                        or source_id in ancestors[str(candidate["node_id"])]
                    )
                )
                raise ValueError(
                    "plan_graph_forward_transition_requires_causal_dependency:"
                    f"{source_id}:{target_id}:"
                    f"allowed_target_node_ids={allowed_target_ids}"
                )


def _validate_exclusive_branch_reconvergence(
    nodes: Sequence[Mapping[str, Any]],
    *,
    goal_node_id: str,
) -> None:
    """Reject AND dependencies that require mutually exclusive branch results."""
    ancestors = _ancestor_map(nodes)
    for source in nodes:
        source_id = str(source["node_id"])
        forward_targets = {
            str(transition["target_node_id"])
            for transition in source["transitions"]
            if str(transition["target_node_id"]) != source_id
            and str(transition["target_node_id"]) not in ancestors[source_id]
        }
        if len(forward_targets) < 2:
            continue
        for node in nodes:
            node_id = str(node["node_id"])
            if node_id == goal_node_id:
                continue
            lineage = ancestors[node_id] | {node_id}
            required_branches = sorted(forward_targets & lineage)
            if len(required_branches) > 1:
                raise ValueError(
                    "plan_graph_mutually_exclusive_branch_join:"
                    f"{source_id}:{node_id}:{required_branches}"
                )


def _incoming_transition_sources(
    nodes: Sequence[Mapping[str, Any]],
) -> dict[str, list[Mapping[str, Any]]]:
    incoming: dict[str, list[Mapping[str, Any]]] = {
        str(node["node_id"]): [] for node in nodes
    }
    for source in nodes:
        for transition in source["transitions"]:
            incoming[str(transition["target_node_id"])].append(source)
    return incoming


def _route_is_enabled(
    node_id: str,
    nodes: Sequence[Mapping[str, Any]],
) -> bool:
    """Resolve whether a node remains on a selected or still-open branch."""
    by_id = {str(node["node_id"]): node for node in nodes}
    incoming = _incoming_transition_sources(nodes)
    memo: dict[str, bool] = {}

    def resolve(current_id: str) -> bool:
        if current_id in memo:
            return memo[current_id]
        node = by_id[current_id]
        if node["status"] == "completed":
            memo[current_id] = True
            return True
        sources = incoming[current_id]
        if sources:
            enabled_by_transition = False
            for source in sources:
                selected = str(source.get("selected_transition_id") or "")
                if not selected:
                    enabled_by_transition = True
                    break
                if any(
                    str(edge["transition_id"]) == selected
                    and str(edge["target_node_id"]) == current_id
                    for edge in source["transitions"]
                ):
                    enabled_by_transition = True
                    break
            if not enabled_by_transition:
                memo[current_id] = False
                return False
        enabled = all(resolve(str(dep)) for dep in node["depends_on"])
        memo[current_id] = enabled
        return enabled

    return resolve(node_id)


def _transition_target_is_enabled(
    node: Mapping[str, Any],
    nodes: Sequence[Mapping[str, Any]],
) -> bool:
    target_id = str(node["node_id"])
    ancestors = _ancestor_map(nodes)
    forward_incoming = [
        source
        for source in _incoming_transition_sources(nodes)[target_id]
        if str(source["node_id"]) in ancestors[target_id]
    ]
    if not forward_incoming:
        return True
    return any(
        any(
            str(transition["transition_id"])
            == str(source["selected_transition_id"])
            and str(transition["target_node_id"]) == target_id
            for transition in source["transitions"]
        )
        for source in forward_incoming
    )


def _ancestor_map(
    nodes: Sequence[Mapping[str, Any]],
) -> dict[str, set[str]]:
    by_id = {str(node["node_id"]): node for node in nodes}
    ancestors: dict[str, set[str]] = {}

    def collect(node_id: str) -> set[str]:
        if node_id in ancestors:
            return ancestors[node_id]
        result: set[str] = set()
        for dependency in by_id[node_id]["depends_on"]:
            dependency_id = str(dependency)
            result.add(dependency_id)
            result.update(collect(dependency_id))
        ancestors[node_id] = result
        return result

    for node_id in by_id:
        collect(node_id)
    return ancestors


def _ready_pending_nodes(
    nodes: Sequence[Mapping[str, Any]],
    *,
    goal_node_id: str,
) -> list[Mapping[str, Any]]:
    status_by_id = {str(node["node_id"]): str(node["status"]) for node in nodes}
    return [
        node
        for node in nodes
        if str(node["node_id"])
        not in {str(goal_node_id), TASK_START_NODE_ID}
        and node["status"] == "pending"
        and all(status_by_id[str(dep)] == "completed" for dep in node["depends_on"])
        and _transition_target_is_enabled(node, nodes)
    ]


def _next_ready_node(
    nodes: Sequence[Mapping[str, Any]],
    *,
    goal_node_id: str,
) -> Mapping[str, Any] | None:
    ready = _ready_pending_nodes(nodes, goal_node_id=goal_node_id)
    return ready[0] if ready else None


def _bounded_text_field(value: Any, *, issue: str, limit: int) -> str:
    if not isinstance(value, str):
        raise ValueError(
            f"{issue}:expected_type=str:actual_type={type(value).__name__}"
        )
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{issue}:nonempty_text_required")
    if len(normalized) > limit:
        raise ValueError(
            f"{issue}:actual_length={len(normalized)}:max_length={limit}"
        )
    if "\n" in value or "\r" in value:
        raise ValueError(f"{issue}:single_line_text_required")
    return normalized


def _unique_nonempty_strings(value: Any) -> bool:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        return False
    normalized = [item for item in value if isinstance(item, str) and item]
    return len(normalized) == len(value) and len(normalized) == len(set(normalized))
