---
name: rebuild-graph
description: Rebuilds remaining common-agent work after the current Graph cannot carry observed evidence, while preserving accepted completed outcomes and the current Frame goal.
estimated_complexity: medium
---

# Rebuild Graph

This is private common infrastructure. It is not a selectable domain skill and
does not share the initial-plan workflow.

## Responsibility and boundary

Rebuild only the work needed to reach the already selected current Frame goal
after runtime has formally recorded why the prior route cannot continue.
Preserve accepted completed outcomes and the supplied Frame-goal semantics. Do
not select a different Frame goal, inspect or cover the Global Evaluation,
reinterpret scientific evidence, or repair a skill payload.

## Entry conditions and authority

The workflow requires:

- optional mission context from C0;
- the current graph's completed anchors and one frozen Frame-goal anchor from C1;
- one stored `graph_revision_outcome` plus compact accepted artifact projections
  from C2;
- bounded processed execution observations resolved from that record's exact
  `observation_refs`. These are operational evidence, not accepted science.

Every artifact in `accepted_artifact_index` already exists and is available as
an input to node-local execution. Do not create a pending node to reproduce,
recover, or re-accept that output. A later version is new work only when the
frozen Frame goal or recorded revision evidence explicitly requires it.

Raw C6 events are never model input. Runtime first projects the relevant attempt
history into the formal C2 revision outcome. The main rebuild call also receives
a compact C2 execution projection containing the current failed node contract,
ordered skill calls, exact input refs, per-step cost, total cost, fixed node
limit, and recorded failure reason. Distinct earlier exhausted operations are
projected in the same block with their exact node contracts, skill order, input
refs, costs, and bounded failure reasons. This avoids asking the model to
rediscover decisive failure shapes inside a large evidence payload. Accepted
science artifacts are limited to the current graph's explicit evidence roots
and their dependency closure; older revision records remain stored but are not
duplicated in that science index. Recent non-cost failures are grouped by exact
node contract in `prior_semantic_failure_groups`; each group retains exact skill
inputs, result refs, and bounded evaluator reasons. Older full records remain
available to runtime replay checks and audit. A structural repair receives only
the rejected graph, exact validation issue, completed anchors, Frame-goal anchor,
retired ids, and allowed criterion ids; scientific evidence and capability
summaries are intentionally omitted because the repair may not reinterpret them.

## Prompt and memory projection

One main model call receives only the authorities above and compact capability
summaries. It returns the complete route from available accepted outcomes to the
current Frame goal in the existing raw Graph node shape, excluding the
runtime-owned `task-start` anchor. It must not add work after that goal or try to
cover unrelated Global requirements. The model may also
omit the current `frame-goal` anchor; in that case Python restores it and
connects every terminal pending work node. If the model explicitly submits the
goal, its incoming dependencies are preserved while all goal semantics remain
runtime-owned. Python restores the start anchor and connects every remaining
work root after model output. The submitted `outcome` and
`completion_condition` become the node's sole persisted semantic authority;
runtime does not send each node through a second LLM rewrite. One
bounded protocol repair may correct a malformed main tool call. One separate
bounded structural repair may receive the rejected graph and exact
graph-validation issue in C5. A protocol defect therefore cannot consume the
only opportunity to repair graph content.

## Cost-overflow rebuild contract

Use this narrow contract only when every recorded current attempt failed before
execution because its total skill cost exceeded `node_loop_cost_limit`. This is
a scheduling failure, not scientific evidence against the selected route.

The prompt supplies the failed node contract, the rejected ordered steps with
exact costs and inputs, completed anchors, accepted artifacts, the frozen Frame
goal, and the complete capability-summary vocabulary available to rebuild the
remaining route. The rejected sequence identifies mandatory work to partition;
it does not define the entire remaining route to the Frame goal.

- Preserve every skill in the rejected ordered sequence unless its promised
  formal output already exists in a completed anchor or accepted artifact.
- Preserve the causal order required by the supplied capability contracts.
- Partition the sequence into at least two causally linked work nodes so every
  node-local LOOP costs at most `node_loop_cost_limit`.
- After partitioning that sequence, add only the formal prerequisites or
  downstream work needed to connect its stored results to the frozen Frame goal.
  Select that remaining work from the complete capability summaries; do not
  treat omitted work from the rejected node-local attempt as already complete.
- Place a boundary only where the preceding work leaves a formal, independently
  stored result that the successor can consume. A node may contain more than one
  skill when their combined cost fits the limit and they jointly produce its
  locally judgeable outcome.
- Name outcomes after the formal results promised by the capability summaries.
  Never replace a producer, materializer, or reviewer with a generic analysis,
  evidence, preparation, or report node.
- Existing accepted artifacts are inputs, not new work. Do not reproduce them.
- `depends_on` contains node ids only. Connect new work to its true completed or
  newly proposed causal predecessor, and connect terminal work to the frozen
  Frame goal.
- Return exactly one `submit_replacement_graph` tool call and no prose. Omit the
  runtime-owned `task-start` node. The immutable Frame-goal node may be omitted;
  runtime will restore it and attach terminal work.

## Step-call exhaustion

A sealed LOOP's estimated skill cost and a running step's LLM-call allowance
are different limits. A step exhausting its calls does not imply that its skill
combination exceeded the cost limit, or that its scientific specification must
be split into new formulas or quantities. Read `execution_observations` together
with the exact retained project checkpoints before choosing remaining work.

Distinguish source repair already checkpointed, calculations actually completed,
restart files retained, and the still-missing formal result. An accepted project
snapshot is usable implementation state, not proof of scientific completion.
Historical runtime data may be inspected and explicitly reused by the producing
skill; its compatibility and computational strategy remain that skill's decision.

Plan from this changed starting point. A fresh node may retain the same scientific
target while continuing from repaired code and retained runtime data, or use a
different defensible execution strategy. Describe the remaining outcome and the
change supported by evidence; do not ask a skill to repeat completed upstream
work. This is not permission to replay an unchanged exhausted attempt or to reset
its counters. New nodes receive their own bounded LOOP after the graph changes.

Nodes are judgeable work outcomes, not one node per skill and not one node per
internal calculation. Split only where the available capabilities genuinely
produce independently usable evidence. Never invent intermediate scientific
artifact kinds to make a split possible. Keep this Frame's unmet goal unchanged.

## Workflow

1. Runtime freezes completed nodes with resolvable completion evidence.
2. For an in-Frame repair, runtime preserves that Frame's goal. For a new Frame,
   the main agent's preceding Frame-goal stage supplies a newly selected goal.
   In both cases rebuild receives one frozen goal and clears only its incoming
   edges. The old graph and old goal remain archived in the revision outcome.
3. The model compares local completion verdicts with the stored content of the
   exact result and criterion-evidence refs. A local verdict states whether a
   threshold was met; the cited result content explains why evidence remained
   unfavorable. If exhausted attempts only reassessed unchanged evidence, the
   new route must first create or change upstream evidence.
   The same rule applies to distinct prior exhausted attempts retained in the
   compact execution history. If a recorded attempt exceeded the node LOOP cost
   limit, the model preserves every capability in that rejected ordered
   sequence unless its canonical output already exists in a completed-node
   anchor, and separates their judgeable outcomes into causally linked nodes.
   A cost-only failure does not authorize changing the scientific route. Each
   replacement node names the formal output promised by its corresponding
   skill summary; it must not turn a producer, materializer, or reviewer into
   generic analysis, evidence, or report work. The mechanically deduplicated
   `over_limit_skill_combinations` block makes these combinations explicit.
   When a capability has alternative input modes, choose the mode whose formal
   lineage satisfies the frozen node contract. Existing evidence does not make
   an incompatible cheaper mode valid; add the matching mode's missing formal
   prerequisites and never combine mutually exclusive modes in one call.
   Do not add an umbrella preparation node whose completion would require the
   same complete combination; each node must stop at one independently
   publishable result within the fixed cost limit. The record does not ban those skills or refs. An exact exhausted
   replay requires the same node outcome, completion condition, ordered skills,
   and exact per-step input refs; purpose wording is not part of identity.
4. The model creates only the middle work needed to reach the supplied Frame
   goal and may reconnect it. If
   it omits that immutable anchor, Python connects every terminal pending work
   node to the goal mechanically. When one
   failed attempt already produced a formal result that independently satisfies
   a narrower useful outcome, the model may represent that outcome as a fresh
   node rather than rerunning its producer. The node must state only what the
   exact stored result proves and depend on its true completed causal
   predecessor. Runtime then verifies that exact result through the ordinary
   existing-evidence boundary before completing the node.
5. Python restores canonical completed-node and goal semantics, completes any
   omitted terminal-work-to-goal structure, compiles the
   graph, and validates acyclicity, reachability, references, and at least one
   pending work path to the goal.
6. Only a fully valid graph replaces C1 atomically. Node-local evaluators later
   judge actual evidence against the persisted completion condition; an
   execution failure becomes evidence for a later Graph rebuild rather than a
   pre-execution semantic rewrite.

The replacement Graph is acyclic. Ordinary dependencies and conditional
transitions move only forward; neither may point to the same node or to an
ancestor. Retry belongs inside the bounded node-local LOOP. A required topology
change is represented by another Graph rebuild, never by a cycle.

Do not resubmit completed nodes as `nodes` entries. Whenever new work consumes
those completed outcomes, it must copy their exact node ids into `depends_on`.
New work may depend on any causally appropriate completed anchor, not only the
latest completed node. Consequently a later completed node may remain in the
replacement graph as an immutable historical leaf while a new branch grows
from an earlier completed node.
Completion of a Graph work node means its local result is valid; it does not
imply that the overall evaluation criterion is met. The Frame goal is not a work
node and is never duplicated. After graph exhaustion it stays pending while its
incoming active edges are rebuilt toward what the evaluator still requires.
Old failed or incomplete node ids are retired. If the model reuses one while
describing a replacement route, runtime assigns a fresh revision-local id and
rewrites its graph edges mechanically; this identity bookkeeping does not alter
the proposed work. Graph nodes remain judgeable outcomes, not skill names or
tool calls. Every new node must fit one bounded node LOOP.
Every work node must also terminate in formal stored evidence. A capability
whose summary explicitly limits its result to C3 working memory or says it
publishes no formal C2 artifact cannot own a Graph node or become a predecessor
outcome. Its observation is not a cross-skill handoff; a formal producer must
perform any inspection required by its own bounded workflow.
Every work node is temporally local and must be judgeable when it ends. A future
successor, parent, later human interaction, review, report, or other
not-yet-produced artifact cannot be part of the current node's completion
condition merely because it will later cite, accept, or use the current result.
That relationship belongs to the later consumer node. Never invent a generic
evidence node to carry a downstream obligation already owned by a successor.
Every node names at least one final criterion it causally supports; this linkage
does not assert that the intermediate node itself fulfills the final criterion.
It also does not make the work node a gate that guarantees the criterion's
threshold. The rebuild model must keep current thresholds in the Frame goal and
author each work node as a locally judgeable evidence outcome. Runtime preserves
that authored meaning rather than asking another model to reinterpret it. At Graph level,
`depends_on` is the sole input-identity authority. Natural-language qualifiers
in `outcome` or `completion_condition` do not identify inputs.
Ordinary sequencing uses `depends_on`. Only a true observation-dependent choice
uses `transitions`; non-decision nodes have no transitions.

Nodes that produce an independent review, evaluator verdict, or final judgment
must ask for that evidence to be produced from their declared predecessor
outcomes. They must not preordain a favorable score, pass state, or release
outcome in their outcome or completion condition, and must not use any result
property to choose an input. Desired thresholds belong only to the authoritative
Frame goal. An unfavorable but valid review or judgment completes its local node;
if the overall criterion remains unmet, the runtime may later rebuild the graph
from that new evidence.

`depends_on` is Graph topology, not dataflow storage. Every value must be the
exact `node_id` of another node in the replacement submission or a frozen
completed-node anchor. Never place an artifact, observation, workspace, code,
or other evidence ref in `depends_on`. Items in `accepted_artifact_index` are
already available facts. A node may describe work that consumes those facts;
its node-local LOOP later selects the exact refs as action inputs.

Attempt result refs may define a narrower replacement node even when they did
not fulfill the failed node that produced them. This applies only to formal
stored work results. A `graph_revision_outcome`, event log, receipt, plan, or
prose description cannot itself complete that node. Do not regenerate an
already stored result merely to move it across the Graph boundary.

When a new node consumes an accepted completed outcome, its `depends_on` must
name that completed node id. Compact artifact projections explain available
evidence but do not replace causal graph edges. The replacement route must answer
the recorded failure mechanism in `graph_revision_outcome`; do not merely rename the failed nodes
and present them as a new route. If a missing prerequisite caused the failure,
represent that prerequisite as bounded work and connect the later retry through
it. An evaluator reason that only reports a missed score or verdict is not by
itself the scientific cause. Read the stored summaries for its exact cited refs.
Repeating an assessment over unchanged predecessor evidence is not a replacement
route; first add bounded work that changes the evidence available to it.

If a new node explicitly claims to strengthen, repair, or reassess an accepted
method because a prior review, evaluator verdict, or final judgment identified
a gap, its `depends_on` must include the completed node whose `completion_refs`
carry that exact gap evidence. Otherwise the new node has no Graph-level input
authority for that finding. A genuinely independent replacement route may omit
the old assessment dependency, but then its outcome must describe independent
new work rather than remediation of the accepted method.

## Formal output and handoff

The workflow returns a validated replacement graph using the existing plan
schema. The `graph_revision_outcome` remains the formal C2 record of the route
that failed. Each recorded planned step includes its exact `input_refs`, so the
runtime can compare a later validated node-local plan to exhausted operations
without reading C6. The replacement graph becomes the sole current C1 plan.

## Failure and repair

Protocol failure and structural failure each receive at most one narrow repair.
If either repair budget is exhausted, leave the old graph active and fail closed.
Do not silently fall back to the initial planner.

## C0-C6 mapping

- C0: optional mission context; read-only.
- C1: source graph, completed anchors, frozen Frame-goal anchor, and the
  atomically installed replacement graph.
- C2: `graph_revision_outcome` and compact accepted artifact projections.
- C3: unused.
- C4: no large body is loaded; only existing refs remain visible.
- C5: rejected graph candidate, exact structural issue, and repair kind; cleared
  on return.
- C6: complete prompt, model turn, and rebuild event audit; never model input.

### LLM call contracts

| Stage purpose | Authoritative inputs | Allowed work | Output and validator | Local repair | Consumer |
|---|---|---|---|---|---|
| Rebuild current Frame graph | One frozen Frame-goal anchor, completed anchors, one formal C2 `graph_revision_outcome`, accepted-evidence projections, optional mission context, and compact capability summaries | Replace failed or retired middle work only as needed to reach the supplied Frame goal | Existing replacement-graph tool shape; validates ids, dependencies, acyclicity, goal reachability, Frame criterion linkage, and bounded node scale | One protocol repair for malformed tool use | Canonical-anchor restoration and structural validation |
| Repair replacement graph structure | Rejected C5 candidate graph, exact structural issue, and the unchanged rebuild authority | Correct only the reported graph defect; do not reinterpret evidence or weaken the gate | Complete existing replacement-graph shape under the same validator | One structural repair; failure leaves old graph active | Atomic C1 plan replacement |
