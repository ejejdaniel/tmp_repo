from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ..._runtime_support import function_tool
from ...memory_lifecycle.policy import PromptSource
from ...memory_lifecycle.prompt import bounded_projection
from ...model import ChatModel, ModelTurn, complete_model_turn
from ...openai_compatible import ModelProtocolError
from ...sub_loop_toolkit import HumanInteractionPause
from ..graph import (
    MAX_PLAN_GRAPH_NODES,
    TASK_START_NODE_ID,
    build_replacement_plan_graph,
    validate_plan_graph,
)
from ..graph_revision import validate_graph_revision_outcome
from ..node_loop import NODE_LOOP_COST_LIMIT


_ROOT = Path(__file__).resolve().parent
_SKILL = (_ROOT / "SKILL.md").read_text(encoding="utf-8")


def _skill_section(name: str) -> str:
    """Load one exact SKILL.md section as the prompt authority."""
    heading = f"## {name}"
    lines = _SKILL.splitlines()
    try:
        start = lines.index(heading)
    except ValueError as exc:
        raise RuntimeError(f"rebuild_graph_skill_section_missing:{name}") from exc
    end = len(lines)
    for index in range(start + 1, len(lines)):
        if lines[index].startswith("## "):
            end = index
            break
    return "\n".join(lines[start:end]).strip()

_SYSTEM_PROMPT = """\
Execute the attached `rebuild-graph` skill using the authority blocks in the
user message. Return exactly one `submit_replacement_graph` call whose `nodes`
argument contains only the work required to reach the frozen current Frame
goal. Never extend the graph beyond that goal, return prose, or return an empty
argument object.

The replacement Graph must be acyclic. Neither an ordinary dependency nor a
conditional transition may point to the same node or to an ancestor. Retries
belong inside the bounded node-local LOOP, not in Graph topology.

Do not return the reserved `task-start` node. Python mechanically restores that
non-executable structural anchor and connects every remaining work root to it.

`frame_goal_node_anchor` is also runtime-owned. You may return it
exactly once when you want to declare its incoming `depends_on` edges
explicitly. If you omit it, Python restores it and connects every terminal
pending work node to that single goal. Never alter its outcome, completion
condition, criteria, or topology role.

`depends_on` represents Graph topology only. Every entry must exactly equal a
`node_id` declared in this submission or an id listed in
`completed_node_anchors`. Never put an artifact, observation, workspace, or
other evidence ref in `depends_on`. Existing refs in `accepted_artifact_index`
are already available facts; the node-local LOOP selects them as action inputs
when executing the node.

An accepted artifact is an existing input, not remaining work. Never add a node
whose outcome is to create, recreate, recover, or merely re-accept an output
already present in `accepted_artifact_index`. A new node for the same formal
output is valid only when the frozen Frame goal or revision evidence explicitly
requires a changed or newer version. Capability availability does not make an
already completed bootstrap or upstream result pending again.

Every work node must end in formal stored evidence that the node evaluator can
cite after the producing skill is released. A capability summary that explicitly
offers only C3 working memory or says it publishes no formal C2 artifact cannot
own a Graph node or appear as a predecessor outcome. Such exploration may occur
only inside a formal producer's own bounded workflow; it is not a cross-skill
handoff and must not be inserted as a prerequisite node.

Exact task terms and formal outputs explicitly declared by
`available_skill_summaries` are the complete output vocabulary. Never invent a
new artifact kind, snake_case output identity, or generic umbrella result that
neither authority declares. Describe a judgeable outcome in ordinary language
or connect declared outputs causally instead of minting a fictitious stored type.

Every work node must also be judgeable at the moment it ends, using completed
predecessor outcomes and its own newly stored evidence. Never require a future
successor, parent, later human interaction, review, report, or other
not-yet-produced artifact to cite, accept, or use the current node's result.
Place that downstream relationship on the later consumer node. Multiple nodes
may address the same final criterion; this linkage does not make an intermediate
node responsible for future consumer behavior.

Completed anchors and the causal edges already established between them are
immutable history. Do not resubmit or reinterpret them. Python preserves their
ordinary dependencies and any selected conditional edge whose source and target
both remain completed; only edges into retired work are removed.

New work may branch from any completed anchor whose outcome is the true causal
predecessor; it need not continue from the most recently completed node. Later
completed nodes remain immutable historical branches even when no new node
depends on them.

A failed node may contain a formal result that did not fulfill that node's broad
completion condition but does independently fulfill a narrower, causally useful
outcome. Attempt `result_refs` remain diagnostic history, not accepted facts. A
partial result may seed a fresh replacement node only when its exact ref was
explicitly promoted into `still_usable_refs` and therefore appears in
`accepted_artifact_index`. State only what that stored result actually
establishes, and attach the replacement node to its true completed causal
predecessor. Do not place the artifact ref in `depends_on`, reuse the retired
failed-node id, or ask a skill to reproduce the result. Logs, receipts, plans,
unpromoted failed results, and the graph-revision record itself are not
recoverable scientific outcomes.

Treat an attempt's `evaluator_reason` as the local completion verdict, not
automatically as the causal explanation for an unfavorable scientific result.
Use the stored summaries for the exact result and criterion-evidence refs named
by `graph_revision_outcome` to identify the evidence gap that the replacement
route must address. If the exhausted attempts merely reassessed unchanged
predecessor evidence, the replacement graph must first create or change
upstream evidence before another assessment. Repeating that assessment as the
first replacement work node is not a new route.

`failed_execution_constraints` is a compact mechanical projection of the
current node contract, its attempted skill sequences, and distinct prior
exhausted attempts. When an attempt's
`total_cost` exceeds `node_loop_cost_limit`, do not place that complete skill
combination back into one replacement node. Keep any genuinely required work,
but split it into causally linked, locally judgeable result nodes. This record
does not ban a skill, an input ref, or a scientific route. A later attempt is an
exact replay only when the node outcome, node completion condition, ordered
skill ids, and each step's exact input-ref set all match the exhausted record;
changing purpose wording alone does not make it new.

A cost-only failure is not evidence that the selected scientific route or any
of its capabilities failed. Preserve every skill in the rejected ordered
sequence unless its canonical output already exists in a completed-node anchor.
Split the sequence at result boundaries, and name each replacement node by the
formal output promised by the corresponding skill summary. Do not replace a
producer, materializer, or reviewer with a generic analysis, evidence, or
report node merely to fit the cost limit.

When a capability summary offers alternative input modes, select the mode whose
formal lineage can satisfy the failed node's frozen outcome and completion
condition. An already accepted artifact does not justify a cheaper alternative
whose output omits required lineage. Missing formal results required by the
matching mode become bounded prerequisite nodes. Never combine exact inputs
from mutually exclusive modes into one invocation.

`over_limit_skill_combinations` is the mechanically deduplicated high-signal
summary of those cost failures. Do not insert an umbrella analysis or
preparation node whose completion would require one of those complete
combinations again. Each replacement node must end at one independently
publishable result that can be produced by a proper subset within the fixed
limit; connect the next producer, materializer, or reviewer as a successor.
`prior_semantic_failure_groups` retains recent non-cost failures grouped by
their exact node contracts, with exact skill inputs, result refs, and bounded
evaluator reasons. Use them to avoid reassessing unchanged evidence. Full older
records remain stored for runtime replay checks and audit but are not duplicated
into this planning prompt.

When `previous_invalid_candidate` and `validation_issue` are present, this is a
narrow repair. Preserve every unmentioned node and field, but correct every
reported defect in `validation_issue`, including all issues separated by `|`.
The repair payload is intentionally limited to Graph structure. The node
described by `frame_goal_node_anchor` is fixed within this Graph revision. If it
is present, preserve it
exactly once and connect it to valid candidate or completed predecessor nodes.
If it is omitted, Python restores it mechanically after this call.
"""

_COST_OVERFLOW_SYSTEM_PROMPT = """\
Execute the attached cost-overflow contract for `rebuild-graph`. The current
node-local plan was rejected before execution solely because its total cost
exceeded the fixed limit. Submit the causally equivalent bounded replacement
route with exactly one `submit_replacement_graph` tool call and no prose.

The supplied completed anchors and Frame goal are immutable. Existing artifacts
are inputs, `depends_on` contains node ids only, the Graph must remain acyclic,
and every proposed work node must end in locally judgeable stored evidence.
""" + "\n\n" + _skill_section("Cost-overflow rebuild contract")

class GraphRebuildError(RuntimeError):
    pass


class GraphRebuildProtocolError(GraphRebuildError):
    """The model did not satisfy the tool-call transport contract."""


class GraphRebuildStructureError(GraphRebuildError):
    """The submitted graph did not satisfy the graph contract."""


def rebuild_graph(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    source_graph: Mapping[str, Any],
    revision_outcome: Mapping[str, Any],
    resolved_artifacts: Sequence[Mapping[str, Any]],
    skill_summaries: Sequence[Mapping[str, Any]],
    revision: int,
    revision_history: Sequence[Mapping[str, Any]] = (),
    mission_packet: Mapping[str, Any] | None = None,
    human_input_tool: Mapping[str, Any] | None = None,
    request_human_input: Callable[[Mapping[str, Any]], None] | None = None,
    frame_goal: Mapping[str, Any] | None = None,
    resolved_observations: Sequence[Mapping[str, Any]] = (),
) -> dict[str, Any]:
    """Build one replacement route toward an already selected Frame goal."""
    validate_plan_graph(source_graph)
    validate_graph_revision_outcome(revision_outcome)
    if revision != int(source_graph["revision"]) + 1:
        raise GraphRebuildError("graph_rebuild_revision_must_increment_once")

    completed_anchors = _completed_anchors(source_graph)
    goal_anchor = _frame_goal_anchor(source_graph, frame_goal=frame_goal)
    all_criterion_ids = [
        str(item).strip() for item in goal_anchor["addresses_criteria"]
    ]
    if (
        not all_criterion_ids
        or any(not item for item in all_criterion_ids)
        or len(all_criterion_ids) != len(set(all_criterion_ids))
    ):
        raise GraphRebuildError("graph_rebuild_frame_goal_criteria_invalid")
    remaining_criterion_ids = list(all_criterion_ids)

    old_node_ids = {str(node["node_id"]) for node in source_graph["nodes"]}
    completed_ids = {str(node["node_id"]) for node in completed_anchors}
    goal_id = str(goal_anchor["node_id"])
    retired_ids = sorted(old_node_ids - completed_ids - {goal_id})
    failed_execution_constraints = _failed_execution_history_projection(
        revision_outcome,
        revision_history=revision_history,
    )
    cost_overflow_skill_ids = _current_cost_overflow_skill_ids(
        failed_execution_constraints
    )
    payload: dict[str, Any] = {
        "completed_node_anchors": [
            _anchor_projection(node) for node in completed_anchors
        ],
        "frame_goal_node_anchor": _anchor_projection(goal_anchor),
        "retired_node_ids": retired_ids,
        "graph_revision_outcome": _revision_outcome_prompt_projection(
            revision_outcome
        ),
        "failed_execution_constraints": failed_execution_constraints,
        "accepted_artifact_index": [dict(item) for item in resolved_artifacts],
        "execution_observations": [
            bounded_projection(item, max_depth=5, max_items=8, max_text_chars=1500)
            for item in resolved_observations
            if item.get("observation_ref") in {
                ref for attempt in revision_outcome.get("attempts", ())
                for ref in attempt.get("observation_refs", ())
            }
        ],
        "available_skill_summaries": [dict(item) for item in skill_summaries],
    }
    if mission_packet:
        payload["mission_packet"] = dict(mission_packet)
    tool = _replacement_tool(
        all_criterion_ids,
        max_items=(MAX_PLAN_GRAPH_NODES + 1) - len(completed_anchors),
    )
    previous_candidate: Mapping[str, Any] | None = None
    issue = ""
    repair_kind = ""
    protocol_repairs_remaining = 1
    structure_repairs_remaining = 1
    attempt = 0

    while True:
        attempt += 1
        if repair_kind == "structure" and previous_candidate is not None:
            call_payload = _structure_repair_payload(
                payload,
                previous_candidate=previous_candidate,
                validation_issue=issue,
                criterion_ids=all_criterion_ids,
            )
        else:
            call_payload = dict(payload)
            if previous_candidate is not None:
                call_payload["previous_invalid_candidate"] = dict(
                    previous_candidate
                )
                call_payload["validation_issue"] = issue
                call_payload["repair_kind"] = repair_kind
        if not repair_kind:
            purpose = "rebuild common-agent remaining-work graph"
        elif repair_kind == "protocol":
            purpose = "repair common-agent replacement graph protocol"
        else:
            purpose = "repair common-agent replacement graph structure"
        human_instruction = (
            "\n\nA human-interruption tool is available. Use it only when "
            "the recorded evidence cannot support a responsible replacement "
            "Graph without information or judgment from a person. A required "
            "formal outcome with no owning capability in the supplied skill "
            "summaries is such a case: do not recreate it with the nearest "
            "ineligible skill or delegate the same capability gap. Otherwise "
            "submit the replacement Graph directly."
            if human_input_tool is not None
            else ""
        )
        system_instruction = (
            _COST_OVERFLOW_SYSTEM_PROMPT
            if cost_overflow_skill_ids
            else _SYSTEM_PROMPT + "\n\n" + _SKILL
        )
        if "model_output_limit_without_answer" in issue:
            system_instruction += (
                "\nThe previous call exhausted its output budget without a graph. "
                "Do not repeat an exhaustive search of alternative decompositions. "
                "Use the exact failure and retained evidence to choose the smallest "
                "defensible remaining-work graph and submit it. Step-call exhaustion "
                "is not by itself evidence that a scientific result must be split."
            )
        messages = [
            {
                "role": "system",
                "content": system_instruction + human_instruction,
            },
            {
                "role": "user",
                "content": json.dumps(
                    call_payload,
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            },
        ]
        tools = [tool]
        if human_input_tool is not None:
            tools.append(dict(human_input_tool))
        memory.prepare_for_model_call(call_site=purpose)
        memory.record_prompt_projection(
            call_site=purpose,
            messages=messages,
            tools=tools,
            sources=_prompt_sources(
                call_payload,
                instruction=system_instruction + human_instruction,
            ),
            budget_tier="full",
        )
        events.append(
            "graph_rebuild_prompt_snapshot",
            {
                "purpose": purpose,
                "attempt": attempt,
                "repair_kind": repair_kind or "initial",
                "messages": messages,
                "tool_names": [
                    item["function"]["name"] for item in tools
                ],
            },
        )
        try:
            turn = complete_model_turn(
                model,
                messages=messages,
                tools=tools,
                purpose=purpose,
                tool_choice="required",
                planning=not repair_kind,
                repair=bool(repair_kind),
            )
        except ModelProtocolError as exc:
            issue = f"model_protocol_error:{exc}"
            previous_candidate = {}
            if protocol_repairs_remaining < 1:
                raise GraphRebuildError(
                    f"graph_rebuild_protocol_repair_exhausted:{issue}"
                ) from exc
            protocol_repairs_remaining -= 1
            repair_kind = "protocol"
            events.append(
                "graph_rebuild_repair_requested",
                {
                    "attempt": attempt,
                    "repair_kind": repair_kind,
                    "issue": issue,
                },
            )
            continue

        events.append(
            "graph_rebuild_model_turn",
            {
                "purpose": purpose,
                "attempt": attempt,
                "repair_kind": repair_kind or "initial",
                "content": turn.content,
                "tool_calls": [
                    {
                        "call_id": call.call_id,
                        "name": call.name,
                        "arguments": dict(call.arguments),
                    }
                    for call in turn.tool_calls
                ],
                "usage": dict(turn.usage),
            },
        )

        if (
            len(turn.tool_calls) == 1
            and turn.tool_calls[0].name == "request_human_input"
        ):
            if request_human_input is None:
                raise GraphRebuildProtocolError(
                    "graph_rebuild_human_input_callback_missing"
                )
            request_human_input(turn.tool_calls[0].arguments)
            raise HumanInteractionPause()

        try:
            arguments = _single_submission(turn)
            previous_candidate = dict(arguments)
            submitted_nodes = _submission_nodes(arguments)
        except GraphRebuildProtocolError as exc:
            issue = str(exc)
            if protocol_repairs_remaining < 1:
                raise GraphRebuildError(
                    f"graph_rebuild_protocol_repair_exhausted:{issue}"
                ) from exc
            protocol_repairs_remaining -= 1
            repair_kind = "protocol"
            events.append(
                "graph_rebuild_repair_requested",
                {
                    "attempt": attempt,
                    "repair_kind": repair_kind,
                    "issue": issue,
                },
            )
            continue

        try:
            candidate_nodes = _canonical_replacement_nodes(
                submitted_nodes,
                completed_anchors=completed_anchors,
                goal_anchor=goal_anchor,
                retired_ids=retired_ids,
                criterion_ids=all_criterion_ids,
                remaining_criterion_ids=remaining_criterion_ids,
                revision=revision,
            )
            return build_replacement_plan_graph(
                candidate_nodes,
                revision=revision,
                completed_nodes=completed_anchors,
                goal_node_id=str(source_graph["goal_node_id"]),
            )
        except (GraphRebuildError, ValueError) as exc:
            issue = str(exc)
            if structure_repairs_remaining < 1:
                raise GraphRebuildError(
                    f"graph_rebuild_structure_repair_exhausted:{issue}"
                ) from exc
            structure_repairs_remaining -= 1
            repair_kind = "structure"
        events.append(
            "graph_rebuild_repair_requested",
            {
                "attempt": attempt,
                "repair_kind": repair_kind,
                "issue": issue,
            },
        )


def _completed_anchors(
    graph: Mapping[str, Any],
) -> list[dict[str, Any]]:
    goal_node_id = str(graph["goal_node_id"])
    completed = [
        dict(node)
        for node in graph["nodes"]
        if str(node["node_id"])
        not in {goal_node_id, TASK_START_NODE_ID}
        and node["status"] == "completed"
        and node["completion_refs"]
    ]
    completed_ids = {str(node["node_id"]) for node in completed}
    for node in completed:
        missing = (
            set(node["depends_on"])
            - completed_ids
            - {TASK_START_NODE_ID}
        )
        if missing:
            raise GraphRebuildError(
                "graph_rebuild_completed_anchor_dependency_not_completed:"
                f"{node['node_id']}:{sorted(missing)}"
            )
        node["depends_on"] = [
            dependency
            for dependency in node["depends_on"]
            if dependency != TASK_START_NODE_ID
        ]
    return completed


def _frame_goal_anchor(
    graph: Mapping[str, Any],
    *,
    frame_goal: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Return the supplied Frame goal with every old active edge removed."""
    goal_node_id = str(graph.get("goal_node_id") or "").strip()
    stored_goal = next(
        (
            dict(node)
            for node in graph["nodes"]
            if str(node["node_id"]) == goal_node_id
        ),
        None,
    )
    if stored_goal is None:
        raise GraphRebuildError("graph_rebuild_goal_anchor_required")
    goal = dict(frame_goal) if frame_goal is not None else stored_goal
    if str(goal.get("node_id") or "").strip() != goal_node_id:
        raise GraphRebuildError("graph_rebuild_frame_goal_id_mismatch")
    for field in ("outcome", "completion_condition"):
        value = str(goal.get(field) or "").strip()
        if not value or len(value) > 1_000:
            raise GraphRebuildError(
                f"graph_rebuild_frame_goal_{field}_invalid"
            )
        goal[field] = value
    raw_criteria = goal.get("addresses_criteria")
    if isinstance(raw_criteria, (str, bytes)) or not isinstance(
        raw_criteria, Sequence
    ):
        raise GraphRebuildError("graph_rebuild_frame_goal_criteria_invalid")
    goal["addresses_criteria"] = [
        str(item).strip() for item in raw_criteria
    ]
    goal["decision_boundary"] = False
    goal["transitions"] = []
    goal["depends_on"] = []
    goal["completion_refs"] = []
    goal["attempt_refs"] = []
    goal["selected_transition_id"] = ""
    goal["status"] = "pending"
    return goal


def _anchor_projection(node: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "node_id": str(node["node_id"]),
        "outcome": str(node["outcome"]),
        "completion_condition": str(node["completion_condition"]),
        "addresses_criteria": list(node["addresses_criteria"]),
        "depends_on": list(node["depends_on"]),
        "selected_transition_id": str(
            node.get("selected_transition_id") or ""
        ),
        "transitions": [dict(item) for item in node.get("transitions") or ()],
        "completion_refs": list(node["completion_refs"]),
    }


def _canonical_replacement_nodes(
    raw_nodes: Sequence[Mapping[str, Any]],
    *,
    completed_anchors: Sequence[Mapping[str, Any]],
    goal_anchor: Mapping[str, Any],
    retired_ids: Sequence[str],
    criterion_ids: Sequence[str],
    remaining_criterion_ids: Sequence[str],
    revision: int,
) -> list[dict[str, Any]]:
    candidate = [dict(node) for node in raw_nodes]

    candidate_ids = [str(node.get("node_id") or "").strip() for node in candidate]
    issues: list[str] = []
    if any(not node_id for node_id in candidate_ids):
        issues.append("graph_rebuild_node_id_required")
    if len(candidate_ids) != len(set(candidate_ids)):
        issues.append("graph_rebuild_node_ids_must_be_unique")
    if TASK_START_NODE_ID in candidate_ids:
        issues.append("graph_rebuild_reserved_start_node_id_used_as_work")
    completed_ids = {str(node["node_id"]) for node in completed_anchors}
    if not issues:
        candidate = _normalize_retired_node_ids(
            candidate,
            retired_ids=retired_ids,
            reserved_ids=completed_ids,
            revision=revision,
        )
        candidate_ids = [str(node["node_id"]) for node in candidate]
        candidate = _restore_missing_goal_candidate(
            candidate,
            goal_anchor=goal_anchor,
        )
        candidate_ids = [str(node["node_id"]) for node in candidate]
    known_node_ids = completed_ids | {
        node_id for node_id in candidate_ids if node_id
    }
    repeated_completed = completed_ids & set(candidate_ids)
    if repeated_completed:
        issues.append(
            "graph_rebuild_must_not_restate_completed_anchors:"
            f"{sorted(repeated_completed)}"
        )
    retired_reuse = set(retired_ids) & set(candidate_ids)
    if retired_reuse:
        issues.append(
            f"graph_rebuild_retired_node_ids_reused:{sorted(retired_reuse)}"
        )
    for node in candidate:
        node_id = str(node.get("node_id") or "").strip() or "<missing>"
        raw_dependencies = node.get("depends_on")
        if (
            isinstance(raw_dependencies, (str, bytes))
            or not isinstance(raw_dependencies, Sequence)
            or any(
                not isinstance(item, str) or not item.strip()
                for item in raw_dependencies
            )
            or len(raw_dependencies) != len(set(raw_dependencies))
        ):
            issues.append(
                "graph_rebuild_node_dependencies_invalid:"
                f"node={node_id}:actual={raw_dependencies!r}"
            )
        else:
            dependencies = [str(item).strip() for item in raw_dependencies]
            unknown_dependencies = set(dependencies) - known_node_ids
            if unknown_dependencies:
                issues.append(
                    "graph_rebuild_unknown_dependencies:"
                    f"node={node_id}:actual={sorted(unknown_dependencies)!r}:"
                    f"allowed_node_ids={sorted(known_node_ids)!r}"
                )
            if node_id in dependencies:
                issues.append(
                    f"graph_rebuild_self_dependency:node={node_id}"
                )

        raw_transitions = node.get("transitions")
        if isinstance(raw_transitions, (str, bytes)) or not isinstance(
            raw_transitions, Sequence
        ):
            continue
        unknown_targets = {
            str(transition.get("target_node_id") or "").strip()
            for transition in raw_transitions
            if isinstance(transition, Mapping)
            and str(transition.get("target_node_id") or "").strip()
        } - known_node_ids
        if unknown_targets:
            issues.append(
                "graph_rebuild_unknown_transition_targets:"
                f"node={node_id}:actual={sorted(unknown_targets)!r}:"
                f"allowed_node_ids={sorted(known_node_ids)!r}"
            )
    known_criteria = set(criterion_ids)
    remaining_criteria = set(remaining_criterion_ids)
    goal_id = str(goal_anchor["node_id"])
    for node in candidate:
        raw_criteria = node.get("addresses_criteria")
        if (
            isinstance(raw_criteria, (str, bytes))
            or not isinstance(raw_criteria, Sequence)
            or not raw_criteria
            or any(
                not isinstance(item, str) or not item.strip()
                for item in raw_criteria
            )
            or len(raw_criteria) != len(set(raw_criteria))
        ):
            issues.append(
                "graph_rebuild_node_criteria_invalid:"
                f"node={node.get('node_id')}:actual={raw_criteria!r}:"
                f"allowed={sorted(known_criteria)!r}"
            )
            continue
        unknown_criteria = set(raw_criteria) - known_criteria
        if unknown_criteria:
            issues.append(
                "graph_rebuild_node_criteria_invalid:"
                f"node={node.get('node_id')}:actual={list(raw_criteria)!r}:"
                f"unknown={sorted(unknown_criteria)!r}:"
                f"allowed={sorted(known_criteria)!r}"
            )
        if (
            str(node.get("node_id") or "") != goal_id
            and not set(raw_criteria) & remaining_criteria
        ):
            issues.append(
                "graph_rebuild_work_node_addresses_no_remaining_criterion:"
                f"node={node.get('node_id')}:"
                f"actual={list(raw_criteria)!r}:"
                f"remaining={sorted(remaining_criteria)!r}"
            )

    submitted_work_ids = set(candidate_ids) - {goal_id}
    if not submitted_work_ids:
        issues.append("graph_rebuild_requires_pending_work_toward_goal")
    if goal_id in set(candidate_ids):
        goal_candidate = next(
            node for node in candidate if str(node.get("node_id")) == goal_id
        )
        dependencies = goal_candidate.get("depends_on")
        if not isinstance(dependencies, Sequence) or isinstance(
            dependencies, (str, bytes)
        ) or not dependencies:
            issues.append(
                f"graph_rebuild_goal_requires_incoming_edge:{goal_id}"
            )
    if issues:
        raise GraphRebuildError(
            "graph_rebuild_candidate_structure_invalid:"
            + " | ".join(issues)
        )

    canonical: list[dict[str, Any]] = []
    for node in candidate:
        node_id = str(node["node_id"])
        if node_id != goal_id:
            canonical.append(node)
            continue
        canonical.append(
            {
                "node_id": node_id,
                "outcome": str(goal_anchor["outcome"]),
                "completion_condition": str(goal_anchor["completion_condition"]),
                "addresses_criteria": list(goal_anchor["addresses_criteria"]),
                "decision_boundary": False,
                "depends_on": list(node.get("depends_on") or ()),
                "transitions": [],
            }
        )

    for node in completed_anchors:
        # Conditional history is restored from completed_anchors only after the
        # replacement graph compiles; the model never owns or restates it.
        canonical.append(
            {
                "node_id": str(node["node_id"]),
                "outcome": str(node["outcome"]),
                "completion_condition": str(node["completion_condition"]),
                "addresses_criteria": list(node["addresses_criteria"]),
                "decision_boundary": False,
                "depends_on": list(node["depends_on"]),
                "transitions": [],
            }
        )
    return canonical


def _restore_missing_goal_candidate(
    nodes: Sequence[Mapping[str, Any]],
    *,
    goal_anchor: Mapping[str, Any],
) -> list[dict[str, Any]]:
    """Restore the immutable goal and attach every terminal pending work node."""
    candidate = [dict(node) for node in nodes]
    goal_id = str(goal_anchor["node_id"])
    if any(str(node.get("node_id") or "") == goal_id for node in candidate):
        return candidate

    work_ids = {
        str(node.get("node_id") or "").strip()
        for node in candidate
        if str(node.get("node_id") or "").strip()
    }
    terminal_ids = set(work_ids)
    for node in candidate:
        node_id = str(node.get("node_id") or "").strip()
        dependencies = node.get("depends_on")
        if isinstance(dependencies, Sequence) and not isinstance(
            dependencies, (str, bytes)
        ):
            for dependency in dependencies:
                dependency_id = str(dependency or "").strip()
                if dependency_id in work_ids:
                    terminal_ids.discard(dependency_id)

        transitions = node.get("transitions")
        if isinstance(transitions, Sequence) and not isinstance(
            transitions, (str, bytes)
        ):
            for transition in transitions:
                if not isinstance(transition, Mapping):
                    continue
                target_id = str(
                    transition.get("target_node_id") or ""
                ).strip()
                if node_id in work_ids and target_id in work_ids:
                    terminal_ids.discard(node_id)

    candidate.append(
        {
            "node_id": goal_id,
            "outcome": str(goal_anchor["outcome"]),
            "completion_condition": str(goal_anchor["completion_condition"]),
            "addresses_criteria": list(goal_anchor["addresses_criteria"]),
            "decision_boundary": False,
            "depends_on": sorted(terminal_ids),
            "transitions": [],
        }
    )
    return candidate


def _normalize_retired_node_ids(
    nodes: Sequence[Mapping[str, Any]],
    *,
    retired_ids: Sequence[str],
    reserved_ids: set[str],
    revision: int,
) -> list[dict[str, Any]]:
    """Give reused route-local ids fresh identities and rewrite graph edges."""
    retired = set(retired_ids)
    occupied = set(reserved_ids) | {
        str(node.get("node_id") or "").strip()
        for node in nodes
        if str(node.get("node_id") or "").strip() not in retired
    }
    replacements: dict[str, str] = {}
    for node in nodes:
        node_id = str(node.get("node_id") or "").strip()
        if node_id not in retired or node_id in replacements:
            continue
        suffix_index = 0
        while True:
            suffix = (
                f"-r{revision}"
                if suffix_index == 0
                else f"-r{revision}-{suffix_index}"
            )
            replacement = node_id[: 80 - len(suffix)] + suffix
            if replacement not in occupied and replacement not in retired:
                break
            suffix_index += 1
        replacements[node_id] = replacement
        occupied.add(replacement)

    if not replacements:
        return [dict(node) for node in nodes]

    normalized: list[dict[str, Any]] = []
    for raw in nodes:
        node = dict(raw)
        node_id = str(node.get("node_id") or "").strip()
        node["node_id"] = replacements.get(node_id, node_id)
        dependencies = node.get("depends_on")
        if isinstance(dependencies, Sequence) and not isinstance(
            dependencies, (str, bytes)
        ):
            node["depends_on"] = [
                replacements.get(str(item).strip(), str(item).strip())
                for item in dependencies
            ]
        transitions = node.get("transitions")
        if isinstance(transitions, Sequence) and not isinstance(
            transitions, (str, bytes)
        ):
            node["transitions"] = [
                {
                    **dict(item),
                    "target_node_id": replacements.get(
                        str(item.get("target_node_id") or "").strip(),
                        str(item.get("target_node_id") or "").strip(),
                    ),
                }
                if isinstance(item, Mapping)
                else item
                for item in transitions
            ]
        normalized.append(node)
    return normalized


def _single_submission(turn: ModelTurn) -> Mapping[str, Any]:
    if len(turn.tool_calls) != 1:
        raise GraphRebuildProtocolError(
            f"graph_rebuild_requires_one_tool_call:{len(turn.tool_calls)}"
        )
    call = turn.tool_calls[0]
    if call.name != "submit_replacement_graph":
        raise GraphRebuildProtocolError(
            "graph_rebuild_tool_mismatch:"
            f"submit_replacement_graph:{call.name}"
        )
    return dict(call.arguments)


def _submission_nodes(
    arguments: Mapping[str, Any],
) -> list[dict[str, Any]]:
    if set(arguments) != {"nodes"}:
        raise GraphRebuildProtocolError(
            "graph_rebuild_submission_fields_invalid:"
            f"actual={sorted(arguments)}:required=['nodes']"
        )
    raw_nodes = arguments.get("nodes")
    if (
        isinstance(raw_nodes, (str, bytes))
        or not isinstance(raw_nodes, Sequence)
        or not raw_nodes
    ):
        raise GraphRebuildProtocolError("graph_rebuild_nodes_required")
    candidate = [dict(node) for node in raw_nodes if isinstance(node, Mapping)]
    if len(candidate) != len(raw_nodes):
        raise GraphRebuildProtocolError(
            "graph_rebuild_nodes_must_be_objects"
        )
    return candidate


def _replacement_tool(
    criterion_ids: Sequence[str],
    *,
    max_items: int,
) -> dict[str, Any]:
    if max_items < 1:
        raise GraphRebuildError("graph_rebuild_has_no_remaining_node_capacity")
    return function_tool(
        "submit_replacement_graph",
        (
            "Submit one complete replacement graph for remaining work. Put the "
            "entire graph in nodes; never submit an empty argument object."
        ),
        {
            "type": "object",
            "properties": {
                "nodes": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": max_items,
                    "items": _node_schema(criterion_ids),
                }
            },
            "required": ["nodes"],
            "additionalProperties": False,
        },
    )


def _node_schema(criterion_ids: Sequence[str]) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "node_id": {"type": "string", "minLength": 1, "maxLength": 80},
            "outcome": {"type": "string", "minLength": 1, "maxLength": 500},
            "completion_condition": {
                "type": "string",
                "minLength": 1,
                "maxLength": 500,
            },
            "addresses_criteria": {
                "type": "array",
                "minItems": 1,
                "uniqueItems": True,
                "items": {"type": "string", "enum": list(criterion_ids)},
                "description": (
                    "Final criteria this node causally supports. This does not "
                    "claim the node alone fulfills those criteria."
                ),
            },
            "decision_boundary": {
                "type": "boolean",
                "description": (
                    "True only when this node's observed result selects among "
                    "two or more explicit branches."
                ),
            },
            "depends_on": {
                "type": "array",
                "uniqueItems": True,
                "items": {"type": "string", "minLength": 1, "maxLength": 80},
                "description": (
                    "Graph topology only: exact node_id values declared in "
                    "this submission or completed_node_anchors. Never include "
                    "artifact, observation, workspace, or other evidence refs; "
                    "the node-local LOOP selects those refs as action inputs."
                ),
            },
            "transitions": {
                "type": "array",
                "description": (
                    "Conditional branches only. Must be empty for a non-decision "
                    "node; a decision node requires at least two branches."
                ),
                "items": {
                    "type": "object",
                    "properties": {
                        "transition_id": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 80,
                        },
                        "condition": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 500,
                        },
                        "target_node_id": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 80,
                        },
                    },
                    "required": [
                        "transition_id",
                        "condition",
                        "target_node_id",
                    ],
                    "additionalProperties": False,
                },
            },
        },
        "required": [
            "node_id",
            "outcome",
            "completion_condition",
            "addresses_criteria",
            "decision_boundary",
            "depends_on",
            "transitions",
        ],
        "additionalProperties": False,
    }


def _prompt_sources(
    payload: Mapping[str, Any],
    *,
    instruction: str = _SYSTEM_PROMPT,
) -> tuple[PromptSource, ...]:
    return (
        PromptSource("instruction", "graph_rebuild_instruction", instruction),
        PromptSource(
            "C0",
            "graph_rebuild_task_context",
            {
                "mission_packet": payload.get("mission_packet") or {},
            },
        ),
        PromptSource(
            "C1",
            "graph_rebuild_control_anchors",
            {
                "completed_node_anchors": payload.get("completed_node_anchors"),
                "frame_goal_node_anchor": payload.get("frame_goal_node_anchor"),
                "retired_node_ids": payload.get("retired_node_ids"),
            },
        ),
        PromptSource(
            "C2",
            "graph_rebuild_formal_evidence",
            {
                "graph_revision_outcome": payload.get("graph_revision_outcome"),
                "accepted_artifact_index": payload.get("accepted_artifact_index"),
            },
        ),
        PromptSource(
            "C2",
            "graph_rebuild_failed_execution_constraints",
            payload.get("failed_execution_constraints"),
        ),
        PromptSource(
            "C3", "graph_rebuild_execution_observations",
            payload.get("execution_observations"),
        ),
        PromptSource(
            "instruction",
            "graph_rebuild_capability_summaries",
            payload.get("available_skill_summaries"),
        ),
        PromptSource(
            "C5",
            "graph_rebuild_local_repair",
            {
                "previous_invalid_candidate": payload.get(
                    "previous_invalid_candidate"
                ),
                "validation_issue": payload.get("validation_issue"),
                "repair_kind": payload.get("repair_kind"),
            },
        ),
    )


def _failed_execution_projection(
    revision_outcome: Mapping[str, Any],
) -> dict[str, Any]:
    """Expose failed execution shape without asking the model to mine C2."""
    failed_node = revision_outcome.get("failed_node")
    if not isinstance(failed_node, Mapping):
        return {
            "source_revision": int(
                revision_outcome.get("source_revision") or 0
            ),
            "trigger": str(revision_outcome.get("trigger") or ""),
            "failed_node_contract": None,
            "node_loop_cost_limit": NODE_LOOP_COST_LIMIT,
            "attempts": [],
        }

    projected_attempts: list[dict[str, Any]] = []
    for attempt in revision_outcome.get("attempts") or ():
        if not isinstance(attempt, Mapping):
            continue
        steps: list[dict[str, Any]] = []
        total_cost = 0
        for raw_step in attempt.get("planned_steps") or ():
            if not isinstance(raw_step, Mapping):
                continue
            cost = int(raw_step.get("cost") or 0)
            total_cost += cost
            steps.append(
                {
                    "skill_id": str(raw_step.get("skill_id") or ""),
                    "purpose": str(raw_step.get("purpose") or ""),
                    "input_refs": list(raw_step.get("input_refs") or ()),
                    "cost": cost,
                }
            )
        projected_attempts.append(
            {
                "attempt_index": int(attempt.get("attempt_index") or 0),
                "steps": steps,
                "total_cost": total_cost,
                "cost_exceeds_limit": total_cost > NODE_LOOP_COST_LIMIT,
                "result_refs": [
                    str(ref)
                    for ref in attempt.get("result_refs") or ()
                    if str(ref)
                ],
                "evaluator_reason": str(
                    attempt.get("evaluator_reason") or ""
                ),
            }
        )

    return {
        "source_revision": int(revision_outcome.get("source_revision") or 0),
        "trigger": str(revision_outcome.get("trigger") or ""),
        "failed_node_contract": {
            "outcome": str(failed_node.get("outcome") or ""),
            "completion_condition": str(
                failed_node.get("completion_condition") or ""
            ),
        },
        "node_loop_cost_limit": NODE_LOOP_COST_LIMIT,
        "attempts": projected_attempts,
    }


def _failed_execution_history_projection(
    revision_outcome: Mapping[str, Any],
    *,
    revision_history: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Project current detail plus metabolized historical failure memory."""
    current = _failed_execution_projection(revision_outcome)
    semantic_groups: dict[tuple[str, str], dict[str, Any]] = {}
    over_limit_combinations: dict[tuple[str, ...], dict[str, Any]] = {}
    seen: set[
        tuple[str, str, tuple[tuple[str, tuple[str, ...]], ...]]
    ] = set()
    current_revision = int(revision_outcome.get("source_revision") or 0)
    ordered_history = sorted(
        (
            item
            for item in revision_history
            if isinstance(item, Mapping)
            and int(item.get("source_revision") or 0) < current_revision
        ),
        key=lambda item: int(item.get("source_revision") or 0),
    )
    for historical in ordered_history:
        failed_node = historical.get("failed_node")
        if not isinstance(failed_node, Mapping):
            continue
        node_outcome = str(failed_node.get("outcome") or "").strip()
        completion_condition = str(
            failed_node.get("completion_condition") or ""
        ).strip()
        if not node_outcome or not completion_condition:
            continue
        for attempt in historical.get("attempts") or ():
            if not isinstance(attempt, Mapping):
                continue
            compact_steps: list[dict[str, Any]] = []
            fingerprint_steps: list[tuple[str, tuple[str, ...]]] = []
            total_cost = 0
            for raw_step in attempt.get("planned_steps") or ():
                if not isinstance(raw_step, Mapping):
                    continue
                skill_id = str(raw_step.get("skill_id") or "").strip()
                if not skill_id:
                    continue
                input_refs = sorted(
                    {
                        str(ref).strip()
                        for ref in raw_step.get("input_refs") or ()
                        if str(ref).strip()
                    }
                )
                cost = int(raw_step.get("cost") or 0)
                total_cost += cost
                compact_steps.append(
                    {
                        "skill_id": skill_id,
                        "input_refs": input_refs,
                        "cost": cost,
                    }
                )
                fingerprint_steps.append((skill_id, tuple(input_refs)))
            if not compact_steps:
                continue
            fingerprint = (
                node_outcome,
                completion_condition,
                tuple(fingerprint_steps),
            )
            if fingerprint in seen:
                continue
            seen.add(fingerprint)
            source_revision = int(historical.get("source_revision") or 0)
            if total_cost > NODE_LOOP_COST_LIMIT:
                ordered_skill_ids = tuple(
                    step["skill_id"] for step in compact_steps
                )
                record = over_limit_combinations.setdefault(
                    ordered_skill_ids,
                    {
                        "ordered_skill_ids": list(ordered_skill_ids),
                        "total_cost": total_cost,
                        "seen_in_source_revisions": [],
                        "failed_node_outcomes": [],
                    },
                )
                if source_revision not in record["seen_in_source_revisions"]:
                    record["seen_in_source_revisions"].append(source_revision)
                if node_outcome not in record["failed_node_outcomes"]:
                    record["failed_node_outcomes"].append(node_outcome)
                continue

            group = semantic_groups.setdefault(
                (node_outcome, completion_condition),
                {
                    "failed_node_contract": {
                        "outcome": node_outcome,
                        "completion_condition": completion_condition,
                    },
                    "source_revisions": [],
                    "attempts": [],
                },
            )
            if source_revision not in group["source_revisions"]:
                group["source_revisions"].append(source_revision)
            group["attempts"].append(
                {
                    "source_revision": source_revision,
                    "trigger": str(historical.get("trigger") or ""),
                    "attempt_index": int(attempt.get("attempt_index") or 0),
                    "steps": compact_steps,
                    "result_refs": [
                        str(ref)
                        for ref in attempt.get("result_refs") or ()
                        if str(ref)
                    ],
                    "evaluator_reason": str(
                        attempt.get("evaluator_reason") or ""
                    )[:500],
                }
            )

    grouped_semantic_failures = list(semantic_groups.values())
    for group in grouped_semantic_failures:
        group["attempts"] = group["attempts"][-2:]
    current["prior_semantic_failure_groups"] = grouped_semantic_failures[-4:]

    current_attempts = [
        {
            "source_revision": current["source_revision"],
            **attempt,
        }
        for attempt in current["attempts"]
    ]
    for attempt in current_attempts:
        if not bool(attempt.get("cost_exceeds_limit")):
            continue
        ordered_skill_ids = tuple(
            str(step.get("skill_id") or "")
            for step in attempt.get("steps") or ()
            if isinstance(step, Mapping) and str(step.get("skill_id") or "")
        )
        if not ordered_skill_ids:
            continue
        record = over_limit_combinations.setdefault(
            ordered_skill_ids,
            {
                "ordered_skill_ids": list(ordered_skill_ids),
                "total_cost": int(attempt.get("total_cost") or 0),
                "seen_in_source_revisions": [],
                "failed_node_outcomes": [],
            },
        )
        source_revision = int(attempt.get("source_revision") or 0)
        if source_revision not in record["seen_in_source_revisions"]:
            record["seen_in_source_revisions"].append(source_revision)
        failed_contract = current.get("failed_node_contract")
        failed_outcome = (
            str(failed_contract.get("outcome") or "")
            if isinstance(failed_contract, Mapping)
            else ""
        )
        if failed_outcome and failed_outcome not in record["failed_node_outcomes"]:
            record["failed_node_outcomes"].append(failed_outcome)
    current["over_limit_skill_combinations"] = list(
        over_limit_combinations.values()
    )
    return current


def _current_cost_overflow_skill_ids(
    failed_execution_constraints: Mapping[str, Any],
) -> tuple[str, ...]:
    """Return the rejected sequence only for a pure current cost failure."""
    attempts = [
        item
        for item in failed_execution_constraints.get("attempts") or ()
        if isinstance(item, Mapping)
    ]
    if not attempts or not all(
        bool(item.get("cost_exceeds_limit")) for item in attempts
    ):
        return ()
    ordered: list[str] = []
    for attempt in attempts:
        for step in attempt.get("steps") or ():
            if not isinstance(step, Mapping):
                continue
            skill_id = str(step.get("skill_id") or "").strip()
            if skill_id and skill_id not in ordered:
                ordered.append(skill_id)
    return tuple(ordered)


def _revision_outcome_prompt_projection(
    revision_outcome: Mapping[str, Any],
) -> dict[str, Any]:
    """Keep revision authority without duplicating attempt detail."""
    return {
        "artifact_kind": revision_outcome.get("artifact_kind"),
        "source_revision": revision_outcome.get("source_revision"),
        "revision_scope": revision_outcome.get("revision_scope"),
        "trigger": revision_outcome.get("trigger"),
        "failed_node": revision_outcome.get("failed_node"),
        "still_usable_refs": revision_outcome.get("still_usable_refs"),
    }


def _structure_repair_payload(
    authority: Mapping[str, Any],
    *,
    previous_candidate: Mapping[str, Any],
    validation_issue: str,
    criterion_ids: Sequence[str],
) -> dict[str, Any]:
    """Project only the immutable authorities needed to repair Graph shape."""
    return {
        "completed_node_anchors": [
            dict(item)
            for item in authority.get("completed_node_anchors") or ()
            if isinstance(item, Mapping)
        ],
        "frame_goal_node_anchor": dict(
            authority.get("frame_goal_node_anchor") or {}
        ),
        "retired_node_ids": [
            str(item) for item in authority.get("retired_node_ids") or ()
        ],
        "allowed_criterion_ids": [str(item) for item in criterion_ids],
        "previous_invalid_candidate": dict(previous_candidate),
        "validation_issue": str(validation_issue),
        "repair_kind": "structure",
    }
