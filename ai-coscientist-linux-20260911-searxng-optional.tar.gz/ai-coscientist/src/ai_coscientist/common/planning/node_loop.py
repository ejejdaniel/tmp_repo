from __future__ import annotations

import json
import textwrap
from typing import Any, Callable, Mapping, Sequence

from .._runtime_support import function_tool
from ..memory_lifecycle.policy import PromptSource
from ..model import (
    ChatModel,
    ModelTurn,
    complete_model_turn,
    retry_model_turn_without_reasoning,
)
from ..openai_compatible import ModelProtocolError
from .research_mode_projection import (
    RESEARCH_INPUT_ROLES,
    RESEARCH_MODE_DECISION_NOTE_LIMIT,
    ResearchModeProjectionError,
    project_research_modes,
)


NODE_LOOP_COST_BY_COMPLEXITY = {
    "low": 1,
    "medium": 3,
    "high": 6,
}
NODE_LOOP_COST_LIMIT = 10
NODE_LOOP_MAX_ATTEMPTS = 2
NODE_LOOP_LLM_CALLS_PER_COST = 4
NODE_LOOP_PURPOSE_LIMIT = 300
_RESEARCH_TASK_SOURCES = ("autonomous", "commissioned")
_RESEARCH_STRATEGIES = ("deepen", "explore")
SkillDetailLoader = Callable[[str], str]
_DETAIL_DISCLOSURE_ISSUE = (
    "Selected Skill contracts are now disclosed. Finalize the complete sequence "
    "required by those exact responsibility and input boundaries. Preserve the "
    "Graph node outcome, but correct Skill choice, order, and existing input refs "
    "where the detailed contracts prove the draft incomplete or ambiguous. Do "
    "not omit required work or switch to an incompatible input mode to fit an "
    "attempt budget; runtime evaluates cost only after this complete submission."
)
_LOCAL_PAYLOAD_REPAIR_SYSTEM_PROMPT = """\
Repair one rejected `submit_node_loop` payload. Return exactly one call to the
same tool with complete corrected arguments. The active Graph-node outcome and
scientific objective are frozen. Use only the exact validation issue, rejected
payload, disclosed Skill contracts, compact exact-ref catalog, and tool schema.

The rejected payload is failure evidence, not a template. Reconstruct the
arguments independently from the selected Skill contracts. A Graph outcome may
name causal ancestors or scientific context that must not become direct
`input_refs`; the selected Skill contract alone defines its direct input modes.
Never combine mutually exclusive input modes merely to preserve lineage.

Before calling the tool, check the reconstructed arguments against every exact
validation issue. If any reported condition remains true, the repair is not
finished. An identical payload is guaranteed to remain rejected. Preserve only
values that survive this contract check. Do not invent refs, add prose, inspect
new data, change the Graph, or perform the planned work.
"""

_SYSTEM_PROMPT = """\
Plan one complete, bounded, immutable LOOP attempt for exactly one active Graph
node. The active node defines the result to produce. Its `depends_on` entries are
completed predecessor outcomes. The formal artifact index contains the exact
stored inputs already accepted or explicitly mounted for this attempt.

Return only the project-local skills still needed to transform those inputs into
judgeable evidence for the node completion condition. Each skill description is
its capability boundary: do not assign it a different role. In particular, do
not relabel a producer as a validator or schedule it merely to recreate or
re-verify an existing prerequisite. A consuming skill can inspect exact refs
inside its own invocation.

Graph-node completion must cite formal stored evidence. Do not select a skill
whose summary explicitly limits its output to C3 working memory or says it
publishes no formal C2 artifact: that working memory disappears at the skill
boundary and cannot complete this node or feed a later step. Select the formal
producer that owns the active node outcome; it may perform its required source
inspection inside its own workflow.

The step purpose cannot assign a skill a different canonical output from the
one promised in its description. A report or presentation skill cannot derive,
measure, implement, validate, or create new scientific evidence. Select the
actual producer for that evidence, even when a different skill could summarize
the same predecessor artifacts.

For every step, propose `input_refs` only from the formal artifact index. These
are existing stored inputs for that exact skill invocation. Use the smallest
coherent set that establishes its required authority and scientific context.
For ordinary skills this set is final. A separate binding stage may refine it
only for a skill that explicitly declares research-mode support. Never invent a
future ref. Outputs published by an earlier step in this same attempt are
supplied mechanically to later steps and therefore are not named in advance.
A Skill's entry conditions apply when that step starts, using its actual inputs.
Plan the work needed to obtain prerequisites; do not treat an earlier step's
not-yet-produced result as an existing missing-input error during planning.

A step is one bounded skill invocation, not a raw tool call or a skill's internal
action. One node may need several skills and one skill may use several tools. A
skill may produce an intermediate result whose kind or scientific subject also
appears in another Graph node when that work genuinely helps produce the active
node outcome. That intermediate remains evidence for this attempt; it does not
complete or advance any other Graph node. Only the active-node evaluator may
select completion evidence, and it judges only the active completion condition.

Each step `purpose` is only a concise C1 operational note explaining that
invocation's contribution. Use one short sentence. Do not restate the active
node outcome, completion condition, acceptance checklist, or a full provenance
inventory. Keep it within 300 characters; the active node remains the complete
source of those requirements.

After this draft, separate stages disclose the selected Skill contracts, finalize
the complete Skill sequence, and then bind research mode for declared
research-capable skills. The detailed-contract stage may correct Skill choice,
purpose, order, and existing input refs before runtime accepts the plan. The
sequence becomes immutable only after that acceptance. Do not include, discuss,
or infer a research-mode card in this submission.

Do not choose Graph transitions, add branches, invent future refs, or add hidden
fallback work. Always submit every Skill invocation genuinely required to satisfy
the active node. Never omit required work or switch to an input mode whose
lineage cannot satisfy the node merely to fit the attempt budget. Runtime derives
the total cost after submission. An over-limit complete plan is valid planning
evidence that the Graph must be split or rebuilt; do not turn it into a cheaper
incomplete plan. The sequence cannot change after execution starts. A later
attempt may use formal evidence and the exact prior gap. When
`work_context` is present, it is an operational continuity receipt:
continue from its verified tool and project state instead of repeating those
probes, but never cite it as formal evidence that completes the Graph node. If
that context contains a mutable development project, the formal artifact index
also restores the exact specifications already bound to that project. A step
that continues the project must include those exact refs; do not replace them
with a newly authored specification merely because the Graph node or attempt
changed. Only an explicit incompatibility in the current issue permits a new
project/specification lineage.
Call submit_node_loop exactly once and do not answer in prose.

Planning uses progressive disclosure. The first call sees compact summaries and
drafts likely Skill ownership. When selected Skill contracts are then disclosed,
reconstruct the complete sequence from the active node and those contracts; do
not copy or minimally edit the undisclosed draft. Internal Skill workflow actions
remain inside that Skill and never become LOOP steps. `previous_attempt` is
present only when this finalized submission itself failed validation; that is a
narrow repair call. Change the rejected sequence enough to satisfy that exact
issue. Never include a `cost` field in a submitted step; runtime derives cost
mechanically from each selected Skill's declared complexity. Never repeat an
identical sequence after a cost, schema, or capability-boundary rejection.

A completed predecessor is reusable only while its exact stored result remains
compatible with the selected consumer. If the prior attempt reports a precise
consumer error proving that the predecessor lacks required content, do not pass
the same incompatible ref to the same consumer again. First invoke the capability
that owns the missing directly consumable intermediate, then invoke the active
outcome producer; same-attempt outputs are forwarded mechanically. Submit that
complete causal sequence even when runtime may reject it as too costly and ask
Graph to split it. This repairs the active node only and does not mark a different
Graph node complete.
"""


class NodeLoopPlanError(RuntimeError):
    pass


class NodeLoopCostLimitError(NodeLoopPlanError):
    """The proposed node cannot fit one bounded LOOP attempt."""

    def __init__(
        self,
        message: str,
        *,
        candidate_plan: Mapping[str, Any],
    ) -> None:
        super().__init__(message)
        self.candidate_plan = dict(candidate_plan)


class NodeLoopStepCallLimitError(RuntimeError):
    """One immutable LOOP step exhausted its model-call allowance."""

    def __init__(
        self,
        *,
        node_id: str,
        attempt_index: int,
        step_index: int,
        skill_id: str,
        used: int,
        limit: int,
    ) -> None:
        self.node_id = str(node_id)
        self.attempt_index = int(attempt_index)
        self.step_index = int(step_index)
        self.skill_id = str(skill_id)
        self.used = int(used)
        self.limit = int(limit)
        super().__init__(
            "node_loop_step_llm_call_limit_exhausted:"
            f"node={self.node_id}:attempt={self.attempt_index}:"
            f"step={self.step_index}:skill={self.skill_id}:"
            f"used={self.used}:limit={self.limit}"
        )


def _complete_node_loop_plan_turn(
    *,
    model: ChatModel,
    events: Any,
    messages: Sequence[Mapping[str, Any]],
    tools: Sequence[Mapping[str, Any]],
    purpose: str,
    node_id: str,
    attempt_index: int,
    repair_pass: int,
    phase: str,
    repairing: bool,
) -> ModelTurn:
    """Retry only answerless output exhaustion without semantic repair."""
    call_kwargs = {
        "messages": messages,
        "tools": tools,
        "purpose": purpose,
        "tool_choice": "required",
        "repair": repairing,
        "planning": not repairing,
    }
    try:
        return complete_model_turn(model, **call_kwargs)
    except ModelProtocolError as exc:
        return retry_model_turn_without_reasoning(
            model,
            error=exc,
            before_retry=lambda: events.append(
                "model_output_limit_retry",
                {
                    "node_id": node_id,
                    "attempt_index": attempt_index,
                    "repair_pass": repair_pass,
                    "phase": phase,
                    "purpose": purpose,
                    "reason": str(exc),
                    "reasoning_effort": "none",
                },
            ),
            **call_kwargs,
        )


def node_loop_step_llm_call_limit(step: Mapping[str, Any]) -> int:
    """Derive a fixed execution-call allowance from immutable step cost."""
    cost = step.get("cost")
    if (
        isinstance(cost, bool)
        or not isinstance(cost, int)
        or cost not in NODE_LOOP_COST_BY_COMPLEXITY.values()
    ):
        raise NodeLoopPlanError("node_loop_step_cost_invalid_for_call_limit")
    return cost * NODE_LOOP_LLM_CALLS_PER_COST


def create_node_loop_plan(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    active_node: Mapping[str, Any],
    attempt_index: int,
    skill_summaries: Sequence[Mapping[str, Any]],
    formal_artifacts: Sequence[Mapping[str, Any]],
    current_issue: str,
    work_context: Mapping[str, Any] | None = None,
    node_context_refs: Sequence[str] | None = None,
    skill_detail: SkillDetailLoader | None = None,
) -> dict[str, Any]:
    """Draft, disclose selected Skills, and freeze one bounded Node LOOP."""
    node_id = str(active_node.get("node_id") or "").strip()
    if not node_id:
        raise NodeLoopPlanError("node_loop_active_node_id_required")
    if not 1 <= attempt_index <= NODE_LOOP_MAX_ATTEMPTS:
        raise NodeLoopPlanError("node_loop_attempt_index_invalid")

    summaries = [dict(item) for item in skill_summaries]
    skill_ids = [str(item.get("skill_id") or "") for item in summaries]
    complexity_by_id = {
        str(item.get("skill_id") or ""): str(
            item.get("estimated_complexity") or ""
        )
        for item in summaries
    }
    if not skill_ids or any(not skill_id for skill_id in skill_ids):
        raise NodeLoopPlanError("node_loop_skill_catalog_empty_or_invalid")
    accepts_research_mode_by_id: dict[str, bool] = {}
    for item in summaries:
        raw_capability = item.get("accepts_research_mode", False)
        if not isinstance(raw_capability, bool):
            raise NodeLoopPlanError(
                "node_loop_skill_research_mode_capability_invalid:"
                f"{item.get('skill_id') or ''}"
            )
        accepts_research_mode_by_id[
            str(item.get("skill_id") or "")
        ] = raw_capability
    planner_summaries = [
        {
            "skill_id": str(item.get("skill_id") or ""),
            "description": str(item.get("description") or ""),
            "estimated_complexity": str(
                item.get("estimated_complexity") or ""
            ),
        }
        for item in summaries
    ]
    formal_refs = tuple(
        dict.fromkeys(
            str(item.get("artifact_ref") or "").strip()
            for item in formal_artifacts
            if str(item.get("artifact_ref") or "").strip()
        )
    )
    normalized_node_context_refs = _normalized_node_context_refs(
        node_context_refs,
        formal_refs=formal_refs,
    )
    tool = _submission_tool(skill_ids, formal_refs)
    base_payload = {
        "active_graph_node": _node_loop_scope(active_node),
        "attempt_index": attempt_index,
        "available_skill_summaries": planner_summaries,
        "formal_artifact_index": [dict(item) for item in formal_artifacts],
        "current_issue": str(current_issue),
    }
    if work_context is not None:
        base_payload["work_context"] = dict(work_context)
    previous_attempt: Mapping[str, Any] | None = None
    validation_issue = ""
    draft_plan: dict[str, Any] | None = None

    for repair_pass in range(2):
        payload = dict(base_payload)
        if previous_attempt is not None:
            payload["previous_attempt"] = dict(previous_attempt)
            payload["validation_issue"] = validation_issue
        purpose = (
            f"plan node LOOP attempt {attempt_index} for {node_id}"
            if repair_pass == 0
            else f"repair node LOOP attempt {attempt_index} for {node_id}"
        )
        messages = [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {
                "role": "user",
                "content": json.dumps(payload, ensure_ascii=False, indent=2),
            },
        ]
        tools = [tool]
        memory.prepare_for_model_call(call_site=purpose, consumer="node-loop-plan")
        memory.record_prompt_projection(
            call_site=purpose,
            messages=messages,
            tools=tools,
            sources=(
                PromptSource(
                    "instruction", "node_loop_planning_instruction", messages[0]
                ),
                PromptSource(
                    "C1",
                    "active_node_and_attempt",
                    {
                        "active_graph_node": payload["active_graph_node"],
                        "attempt_index": attempt_index,
                        "current_issue": payload["current_issue"],
                        "work_context": payload.get(
                            "work_context"
                        ),
                    },
                ),
                PromptSource(
                    "C2",
                    "node_loop_formal_artifact_index",
                    payload["formal_artifact_index"],
                ),
                PromptSource(
                    "instruction",
                    "node_loop_skill_summaries",
                    payload["available_skill_summaries"],
                ),
                PromptSource("tool_schema", "node_loop_submission", tool),
            ),
            budget_tier="full",
        )
        events.append(
            "node_loop_plan_prompt_snapshot",
            {
                "node_id": node_id,
                "attempt_index": attempt_index,
                "repair_pass": repair_pass,
                "purpose": purpose,
                "messages": messages,
                "tool_names": ["submit_node_loop"],
            },
        )
        turn = _complete_node_loop_plan_turn(
            model=model,
            events=events,
            messages=messages,
            tools=tools,
            purpose=purpose,
            node_id=node_id,
            attempt_index=attempt_index,
            repair_pass=repair_pass,
            phase="draft",
            repairing=repair_pass > 0,
        )
        events.append(
            "node_loop_plan_model_turn",
            {
                "node_id": node_id,
                "attempt_index": attempt_index,
                "repair_pass": repair_pass,
                "content": turn.content,
                "tool_calls": [
                    {
                        "call_id": call.call_id,
                        "name": call.name,
                        "arguments": dict(call.arguments),
                    }
                    for call in turn.tool_calls
                ],
                "usage": dict(turn.usage),
            },
        )
        try:
            arguments = _single_submission(turn)
            draft_plan = _validated_plan(
                arguments,
                node_id=node_id,
                attempt_index=attempt_index,
                complexity_by_id=complexity_by_id,
                allowed_input_refs=frozenset(formal_refs),
            )
            break
        except (NodeLoopPlanError, ValueError) as exc:
            previous_attempt = (
                dict(turn.tool_calls[0].arguments)
                if len(turn.tool_calls) == 1
                else {}
            )
            validation_issue = str(exc)
            events.append(
                "node_loop_plan_rejected",
                {
                    "node_id": node_id,
                    "attempt_index": attempt_index,
                    "repair_pass": repair_pass,
                    "reason": validation_issue,
                },
            )
            # Cost is the Graph node boundary, not a transport defect. Once a
            # complete proposed sequence exceeds the fixed attempt budget, the
            # remaining graph must be split instead of asking the model to omit
            # work that the node completion condition still requires.
            if isinstance(exc, NodeLoopCostLimitError):
                raise

    if draft_plan is None:
        raise NodeLoopPlanError(
            f"node_loop_plan_invalid_after_local_repair:{validation_issue}"
        )
    if skill_detail is not None:
        draft_plan = _finalize_with_selected_skill_details(
            model=model,
            memory=memory,
            events=events,
            node_id=node_id,
            attempt_index=attempt_index,
            base_payload=base_payload,
            tool=tool,
            draft_plan=draft_plan,
            planner_summaries=planner_summaries,
            skill_detail=skill_detail,
            complexity_by_id=complexity_by_id,
            formal_refs=formal_refs,
        )
    else:
        try:
            _enforce_cost_limit(draft_plan)
        except NodeLoopCostLimitError as exc:
            events.append(
                "node_loop_plan_rejected",
                {
                    "node_id": node_id,
                    "attempt_index": attempt_index,
                    "repair_pass": 0,
                    "reason": str(exc),
                },
            )
            raise
    try:
        return _apply_research_mode_projection(
            model=model,
            memory=memory,
            events=events,
            active_node=_node_loop_scope(active_node),
            draft_plan=draft_plan,
            accepts_research_mode_by_id=accepts_research_mode_by_id,
            skill_summaries=summaries,
            formal_artifacts=formal_artifacts,
            node_context_refs=normalized_node_context_refs,
            current_issue=current_issue,
            work_context=work_context,
            skill_detail=skill_detail,
        )
    except ResearchModeProjectionError as exc:
        raise NodeLoopPlanError(
            f"node_loop_research_mode_projection_failed:{exc}"
        ) from exc


def next_skill_id(loop_state: Mapping[str, Any], *, node_id: str) -> str:
    if str(loop_state.get("node_id") or "") != str(node_id):
        return ""
    if bool(loop_state.get("awaiting_transition")):
        return ""
    steps = loop_state.get("steps")
    index = loop_state.get("next_step_index")
    if not isinstance(steps, Sequence) or isinstance(steps, (str, bytes)):
        return ""
    if not isinstance(index, int) or not 0 <= index < len(steps):
        return ""
    step = steps[index]
    return str(step.get("skill_id") or "") if isinstance(step, Mapping) else ""


def current_step_input_refs(
    loop_state: Mapping[str, Any], *, node_id: str
) -> tuple[str, ...]:
    if str(loop_state.get("node_id") or "") != str(node_id):
        return ()
    steps = loop_state.get("steps")
    index = loop_state.get("next_step_index")
    if not isinstance(steps, Sequence) or isinstance(steps, (str, bytes)):
        return ()
    if not isinstance(index, int) or not 0 <= index < len(steps):
        return ()
    step = steps[index]
    if not isinstance(step, Mapping):
        return ()
    refs = step.get("input_refs")
    if not isinstance(refs, Sequence) or isinstance(refs, (str, bytes)):
        return ()
    return tuple(str(ref) for ref in refs if str(ref))


def _node_loop_scope(active_node: Mapping[str, Any]) -> dict[str, Any]:
    """Hide successor structure from one node-local attempt planner."""
    return {
        "node_id": str(active_node.get("node_id") or ""),
        "outcome": str(active_node.get("outcome") or ""),
        "completion_condition": str(
            active_node.get("completion_condition") or ""
        ),
        "depends_on": [str(item) for item in active_node.get("depends_on") or ()],
    }


def complete_current_step(
    loop_state: Mapping[str, Any],
    *,
    terminate_attempt: bool,
    produced_refs: Sequence[str] = (),
) -> tuple[dict[str, Any], bool]:
    accumulated_refs = list(
        dict.fromkeys(
            [
                *(str(ref) for ref in loop_state.get("produced_refs") or ()),
                *(str(ref) for ref in produced_refs),
            ]
        )
    )
    updated = {
        "node_id": str(loop_state.get("node_id") or ""),
        "attempt_index": int(loop_state.get("attempt_index") or 0),
        "steps": [dict(item) for item in loop_state.get("steps") or ()],
        "produced_refs": accumulated_refs,
        "next_step_index": int(loop_state.get("next_step_index") or 0),
        "awaiting_transition": bool(loop_state.get("awaiting_transition")),
    }
    if not updated["steps"] or updated["next_step_index"] >= len(
        updated["steps"]
    ):
        raise NodeLoopPlanError("node_loop_current_step_missing")
    updated["next_step_index"] += 1
    attempt_finished = terminate_attempt or updated["next_step_index"] >= len(
        updated["steps"]
    )
    if attempt_finished:
        updated["steps"] = []
        updated["produced_refs"] = []
        updated["next_step_index"] = 0
    return updated, attempt_finished


def mark_awaiting_transition(loop_state: Mapping[str, Any]) -> dict[str, Any]:
    updated = {
        "node_id": str(loop_state.get("node_id") or ""),
        "attempt_index": int(loop_state.get("attempt_index") or 0),
        "steps": [dict(item) for item in loop_state.get("steps") or ()],
        "produced_refs": [
            str(ref) for ref in loop_state.get("produced_refs") or ()
        ],
        "next_step_index": len(loop_state.get("steps") or ()),
        "awaiting_transition": True,
    }
    if not updated["node_id"] or updated["attempt_index"] < 1:
        raise NodeLoopPlanError("node_loop_transition_without_attempt")
    return updated


def _submission_tool(
    skill_ids: Sequence[str], formal_refs: Sequence[str]
) -> dict[str, Any]:
    input_ref_items: dict[str, Any] = {"type": "string"}
    if formal_refs:
        input_ref_items["enum"] = list(formal_refs)
    return function_tool(
        "submit_node_loop",
        "Submit one immutable skill sequence for the active Graph node.",
        {
            "type": "object",
            "properties": {
                "steps": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 10,
                    "description": (
                        "Ordered Skill invocations only. Do not include cost; "
                        "runtime derives it from declared Skill complexity."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "skill_id": {
                                "type": "string",
                                "enum": list(skill_ids),
                            },
                            "purpose": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": NODE_LOOP_PURPOSE_LIMIT,
                            },
                            "input_refs": {
                                "type": "array",
                                "items": input_ref_items,
                                "maxItems": len(formal_refs),
                                "uniqueItems": True,
                                "description": (
                                    "Existing exact refs from formal_artifact_index "
                                    "needed by this skill. Use [] when none are needed."
                                ),
                            },
                        },
                        "required": [
                            "skill_id",
                            "purpose",
                            "input_refs",
                        ],
                        "additionalProperties": False,
                    },
                }
            },
            "required": ["steps"],
            "additionalProperties": False,
        },
    )


def _single_submission(turn: ModelTurn) -> Mapping[str, Any]:
    if len(turn.tool_calls) != 1:
        raise NodeLoopPlanError(
            f"node_loop_requires_one_tool_call:{len(turn.tool_calls)}"
        )
    call = turn.tool_calls[0]
    if call.name != "submit_node_loop":
        raise NodeLoopPlanError(
            f"node_loop_tool_mismatch:submit_node_loop:{call.name}"
        )
    return dict(call.arguments)


def _validated_plan(
    arguments: Mapping[str, Any],
    *,
    node_id: str,
    attempt_index: int,
    complexity_by_id: Mapping[str, str],
    allowed_input_refs: frozenset[str],
) -> dict[str, Any]:
    if set(arguments) != {"steps"}:
        raise NodeLoopPlanError("node_loop_submission_fields_invalid")
    raw_steps = arguments.get("steps")
    if (
        isinstance(raw_steps, (str, bytes))
        or not isinstance(raw_steps, Sequence)
        or not raw_steps
    ):
        raise NodeLoopPlanError("node_loop_steps_required")
    steps: list[dict[str, Any]] = []
    for index, raw in enumerate(raw_steps, start=1):
        if not isinstance(raw, Mapping) or set(raw) != {
            "skill_id",
            "purpose",
            "input_refs",
        }:
            raise NodeLoopPlanError(f"node_loop_step_{index}_fields_invalid")
        skill_id = str(raw.get("skill_id") or "").strip()
        raw_purpose = str(raw.get("purpose") or "").strip()
        if skill_id not in complexity_by_id:
            raise NodeLoopPlanError(f"node_loop_step_{index}_skill_unknown")
        if not raw_purpose:
            raise NodeLoopPlanError(f"node_loop_step_{index}_purpose_invalid")
        purpose = compact_node_loop_purpose(raw_purpose)
        raw_input_refs = raw.get("input_refs")
        if (
            not isinstance(raw_input_refs, Sequence)
            or isinstance(raw_input_refs, (str, bytes))
        ):
            raise NodeLoopPlanError(
                f"node_loop_step_{index}_input_refs_invalid"
            )
        input_refs = [str(ref).strip() for ref in raw_input_refs]
        if (
            any(not ref for ref in input_refs)
            or len(input_refs) != len(set(input_refs))
        ):
            raise NodeLoopPlanError(
                f"node_loop_step_{index}_input_refs_invalid"
            )
        unknown_refs = sorted(set(input_refs) - allowed_input_refs)
        if unknown_refs:
            raise NodeLoopPlanError(
                f"node_loop_step_{index}_input_refs_unknown:{unknown_refs}"
            )
        complexity = complexity_by_id[skill_id]
        if complexity not in NODE_LOOP_COST_BY_COMPLEXITY:
            raise NodeLoopPlanError(
                f"node_loop_step_{index}_complexity_invalid:{complexity}"
            )
        step = {
            "skill_id": skill_id,
            "purpose": purpose,
            "input_refs": input_refs,
            "cost": NODE_LOOP_COST_BY_COMPLEXITY[complexity],
        }
        steps.append(step)
    candidate_plan = {
        "node_id": node_id,
        "attempt_index": attempt_index,
        "steps": steps,
        "produced_refs": [],
        "next_step_index": 0,
        "awaiting_transition": False,
    }
    return candidate_plan


def _enforce_cost_limit(candidate_plan: Mapping[str, Any]) -> None:
    steps = [dict(step) for step in candidate_plan.get("steps") or ()]
    total_cost = sum(int(step["cost"]) for step in steps)
    if total_cost > NODE_LOOP_COST_LIMIT:
        raise NodeLoopCostLimitError(
            f"node_loop_cost_exceeds_limit:{total_cost}>{NODE_LOOP_COST_LIMIT}",
            candidate_plan=candidate_plan,
        )


def _finalize_with_selected_skill_details(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    node_id: str,
    attempt_index: int,
    base_payload: Mapping[str, Any],
    tool: Mapping[str, Any],
    draft_plan: Mapping[str, Any],
    planner_summaries: Sequence[Mapping[str, Any]],
    skill_detail: SkillDetailLoader,
    complexity_by_id: Mapping[str, str],
    formal_refs: Sequence[str],
) -> dict[str, Any]:
    """Finalize a draft after revealing only the selected Skill contracts."""
    selected_skill_ids = tuple(
        dict.fromkeys(
            str(step.get("skill_id") or "")
            for step in draft_plan.get("steps") or ()
            if str(step.get("skill_id") or "")
        )
    )
    detailed_summaries: list[dict[str, Any]] = []
    detail_sizes: dict[str, int] = {}
    for summary in planner_summaries:
        item = dict(summary)
        skill_id = str(item.get("skill_id") or "")
        if skill_id in selected_skill_ids:
            detail = _load_selected_skill_detail(skill_id, skill_detail)
            item["description"] = (
                f"{item['description']}\n\n"
                "Planning-time progressive disclosure for this selected Skill:\n"
                f"{detail}"
            )
            detail_sizes[skill_id] = len(detail)
        detailed_summaries.append(item)

    selected_detailed_summaries = [
        dict(item)
        for item in detailed_summaries
        if str(item.get("skill_id") or "") in selected_skill_ids
    ]

    events.append(
        "node_loop_selected_skill_details_disclosed",
        {
            "node_id": node_id,
            "attempt_index": attempt_index,
            "selected_skill_ids": list(selected_skill_ids),
            "detail_chars_by_skill": detail_sizes,
        },
    )
    previous_attempt: Mapping[str, Any] | None = None
    validation_issue = _DETAIL_DISCLOSURE_ISSUE
    for repair_pass in range(2):
        repairing = previous_attempt is not None
        if repairing:
            payload = _local_payload_repair_packet(
                base_payload=base_payload,
                detailed_summaries=selected_detailed_summaries,
                previous_attempt=previous_attempt,
                validation_issue=validation_issue,
            )
            system_prompt = _LOCAL_PAYLOAD_REPAIR_SYSTEM_PROMPT
            budget_tier = "compact"
            purpose = (
                f"repair finalized node LOOP attempt {attempt_index} for {node_id}"
            )
        else:
            payload = dict(base_payload)
            payload["available_skill_summaries"] = [
                dict(item) for item in detailed_summaries
            ]
            payload["validation_issue"] = validation_issue
            system_prompt = _SYSTEM_PROMPT
            budget_tier = "full"
            purpose = f"finalize node LOOP attempt {attempt_index} for {node_id}"
        messages = [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": json.dumps(payload, ensure_ascii=False, indent=2),
            },
        ]
        tools = [tool]
        memory.prepare_for_model_call(call_site=purpose, consumer="node-loop-plan")
        memory.record_prompt_projection(
            call_site=purpose,
            messages=messages,
            tools=tools,
            sources=(
                PromptSource(
                    "instruction", "node_loop_planning_instruction", messages[0]
                ),
                PromptSource(
                    "C1",
                    "active_node_and_attempt",
                    {
                        "active_graph_node": payload["active_graph_node"],
                        "attempt_index": attempt_index,
                        "current_issue": payload.get("current_issue", ""),
                        "work_context": payload.get(
                            "work_context"
                        ),
                    },
                ),
                PromptSource(
                    "C2",
                    "node_loop_formal_artifact_index",
                    payload["formal_artifact_index"],
                ),
                PromptSource(
                    "instruction",
                    "node_loop_selected_skill_details",
                    payload["available_skill_summaries"],
                ),
                PromptSource("tool_schema", "node_loop_submission", tool),
            ),
                budget_tier=budget_tier,
        )
        events.append(
            "node_loop_plan_prompt_snapshot",
            {
                "node_id": node_id,
                "attempt_index": attempt_index,
                "repair_pass": repair_pass,
                "phase": "selected_skill_detail_finalization",
                "purpose": purpose,
                "messages": messages,
                "tool_names": ["submit_node_loop"],
            },
        )
        turn = _complete_node_loop_plan_turn(
            model=model,
            events=events,
            messages=messages,
            tools=tools,
            purpose=purpose,
            node_id=node_id,
            attempt_index=attempt_index,
            repair_pass=repair_pass,
            phase="selected_skill_detail_finalization",
            repairing=repairing,
        )
        events.append(
            "node_loop_plan_model_turn",
            {
                "node_id": node_id,
                "attempt_index": attempt_index,
                "repair_pass": repair_pass,
                "phase": "selected_skill_detail_finalization",
                "content": turn.content,
                "tool_calls": [
                    {
                        "call_id": call.call_id,
                        "name": call.name,
                        "arguments": dict(call.arguments),
                    }
                    for call in turn.tool_calls
                ],
                "usage": dict(turn.usage),
            },
        )
        try:
            arguments = _single_submission(turn)
            if previous_attempt is not None and dict(arguments) == dict(
                previous_attempt
            ):
                raise NodeLoopPlanError(
                    "structured_payload_repair_repeated_identical_payload:"
                    f"{validation_issue}"
                )
            finalized_plan = _validated_plan(
                arguments,
                node_id=node_id,
                attempt_index=attempt_index,
                complexity_by_id=complexity_by_id,
                allowed_input_refs=frozenset(formal_refs),
            )
            _enforce_cost_limit(finalized_plan)
            return finalized_plan
        except (NodeLoopPlanError, ValueError) as exc:
            previous_attempt = (
                dict(turn.tool_calls[0].arguments)
                if len(turn.tool_calls) == 1
                else {}
            )
            validation_issue = str(exc)
            events.append(
                "node_loop_plan_rejected",
                {
                    "node_id": node_id,
                    "attempt_index": attempt_index,
                    "repair_pass": repair_pass,
                    "phase": "selected_skill_detail_finalization",
                    "reason": validation_issue,
                },
            )
            if isinstance(exc, NodeLoopCostLimitError):
                raise

    raise NodeLoopPlanError(
        "node_loop_plan_invalid_after_detail_finalization:"
        f"{validation_issue}"
    )


def _local_payload_repair_packet(
    *,
    base_payload: Mapping[str, Any],
    detailed_summaries: Sequence[Mapping[str, Any]],
    previous_attempt: Mapping[str, Any],
    validation_issue: str,
) -> dict[str, Any]:
    """Build a compact repair packet without replaying scientific bodies."""
    packet = {
        "active_graph_node": dict(base_payload["active_graph_node"]),
        "attempt_index": int(base_payload["attempt_index"]),
        "available_skill_summaries": [
            dict(item) for item in detailed_summaries
        ],
        "formal_artifact_index": [
            _compact_artifact_identity(item)
            for item in base_payload["formal_artifact_index"]
        ],
        "previous_attempt": dict(previous_attempt),
        "validation_issue": str(validation_issue),
    }
    if base_payload.get("work_context") is not None:
        packet["work_context"] = dict(
            base_payload["work_context"]
        )
    return packet


def _compact_artifact_identity(item: Mapping[str, Any]) -> dict[str, Any]:
    """Retain transport identity and lineage, never full stored content."""
    keys = (
        "artifact_ref",
        "artifact_kind",
        "title",
        "depends_on",
        "target_kind",
        "target_id",
    )
    return {key: item[key] for key in keys if key in item}


def _normalized_node_context_refs(
    raw: Sequence[str] | None,
    *,
    formal_refs: Sequence[str],
) -> tuple[str, ...]:
    if raw is None:
        return tuple(formal_refs)
    if not isinstance(raw, Sequence) or isinstance(raw, (str, bytes)):
        raise NodeLoopPlanError("node_loop_node_context_refs_invalid")
    refs = tuple(dict.fromkeys(str(ref).strip() for ref in raw))
    if any(not ref for ref in refs):
        raise NodeLoopPlanError("node_loop_node_context_refs_invalid")
    unknown = sorted(set(refs) - set(formal_refs))
    if unknown:
        raise NodeLoopPlanError(
            f"node_loop_node_context_refs_unknown:{unknown}"
        )
    return refs


def _load_selected_skill_detail(skill_id: str, loader: SkillDetailLoader) -> str:
    try:
        detail = str(loader(skill_id)).strip()
    except Exception as exc:
        raise NodeLoopPlanError(
            f"node_loop_skill_detail_load_failed:{skill_id}:{exc}"
        ) from exc
    if not detail:
        raise NodeLoopPlanError(f"node_loop_skill_detail_empty:{skill_id}")
    return detail


def _apply_research_mode_projection(
    *,
    model: ChatModel,
    memory: Any,
    events: Any,
    active_node: Mapping[str, Any],
    draft_plan: Mapping[str, Any],
    accepts_research_mode_by_id: Mapping[str, bool],
    skill_summaries: Sequence[Mapping[str, Any]],
    formal_artifacts: Sequence[Mapping[str, Any]],
    node_context_refs: Sequence[str],
    current_issue: str = "",
    work_context: Mapping[str, Any] | None = None,
    skill_detail: SkillDetailLoader | None = None,
) -> dict[str, Any]:
    final_plan = {
        **dict(draft_plan),
        "steps": [dict(step) for step in draft_plan.get("steps") or ()],
    }
    for step in final_plan["steps"]:
        step["research_mode"] = None

    artifact_kind_by_ref = {
        str(item.get("artifact_ref") or ""): str(
            item.get("artifact_kind") or ""
        )
        for item in formal_artifacts
        if str(item.get("artifact_ref") or "")
    }
    research_steps: list[dict[str, Any]] = []
    for index, step in enumerate(final_plan["steps"]):
        skill_id = str(step.get("skill_id") or "")
        if not accepts_research_mode_by_id.get(skill_id, False):
            continue
        provisional_refs = [
            str(ref) for ref in step.get("input_refs") or () if str(ref)
        ]
        provisional_kinds = {
            artifact_kind_by_ref.get(ref, "") for ref in provisional_refs
        }
        provisional_kinds.discard("")
        # The finalized Skill plan owns direct authority inputs. Research-mode
        # binding may add cross-kind context. Another artifact of a kind that
        # Stage A already bound is an alternative authority/version, not an
        # optional context addition. A real same-kind comparison must therefore
        # be selected explicitly by Stage A.
        optional_context_refs = [
            str(ref)
            for ref in node_context_refs
            if str(ref) not in provisional_refs
            and artifact_kind_by_ref.get(str(ref)) != "task_spec"
            and artifact_kind_by_ref.get(str(ref)) not in provisional_kinds
        ]
        candidate_refs = list(
            dict.fromkeys([*provisional_refs, *optional_context_refs])
        )
        research_steps.append(
            {
                "step_index": index,
                "skill_id": skill_id,
                "purpose": str(step.get("purpose") or ""),
                "provisional_input_refs": provisional_refs,
                "candidate_input_refs": candidate_refs,
            }
        )
    if not research_steps:
        return final_plan

    selected_skill_ids = list(
        dict.fromkeys(str(step["skill_id"]) for step in research_steps)
    )
    summary_by_id = {
        str(item.get("skill_id") or ""): item for item in skill_summaries
    }
    selected_skill_summaries = [
        {
            "skill_id": skill_id,
            "description": str(
                summary_by_id.get(skill_id, {}).get("description") or ""
            ),
        }
        for skill_id in selected_skill_ids
    ]
    if skill_detail is not None:
        for item in selected_skill_summaries:
            detail = _load_selected_skill_detail(item["skill_id"], skill_detail)
            item["description"] += (
                "\n\nPlanning-time progressive disclosure for this selected Skill:\n"
                + detail
            )
    candidate_refs = {
        str(ref)
        for step in research_steps
        for ref in step.get("candidate_input_refs") or ()
    }
    candidate_artifacts = [
        dict(item)
        for item in formal_artifacts
        if str(item.get("artifact_ref") or "") in candidate_refs
    ]
    arguments = project_research_modes(
        model=model,
        memory=memory,
        events=events,
        active_node=active_node,
        attempt_index=int(draft_plan.get("attempt_index") or 0),
        research_steps=research_steps,
        selected_skill_summaries=selected_skill_summaries,
        candidate_artifacts=candidate_artifacts,
        current_issue=current_issue,
        work_context=work_context,
    )
    for projection_pass in range(2):
        try:
            final_plan, accepted_modes = _validated_research_mode_projection(
                arguments=arguments,
                draft_plan=draft_plan,
                research_steps=research_steps,
            )
        except NodeLoopPlanError as exc:
            events.append(
                "research_mode_projection_rejected",
                {
                    "node_id": str(draft_plan.get("node_id") or ""),
                    "attempt_index": int(
                        draft_plan.get("attempt_index") or 0
                    ),
                    "projection_pass": projection_pass,
                    "reason": str(exc),
                },
            )
            if projection_pass > 0:
                raise NodeLoopPlanError(
                    "node_loop_research_mode_projection_invalid_after_"
                    f"local_repair:{exc}"
                ) from exc
            arguments = project_research_modes(
                model=model,
                memory=memory,
                events=events,
                active_node=active_node,
                attempt_index=int(draft_plan.get("attempt_index") or 0),
                research_steps=research_steps,
                selected_skill_summaries=selected_skill_summaries,
                candidate_artifacts=candidate_artifacts,
                current_issue=current_issue,
                work_context=work_context,
                previous_projection=arguments,
                validation_issue=str(exc),
            )
            continue
        events.append(
            "research_mode_projection_accepted",
            {
                "node_id": str(draft_plan.get("node_id") or ""),
                "attempt_index": int(draft_plan.get("attempt_index") or 0),
                "step_modes": accepted_modes,
            },
        )
        return final_plan

    raise NodeLoopPlanError("node_loop_research_mode_projection_unreachable")


def _validated_research_mode_projection(
    *,
    arguments: Mapping[str, Any],
    draft_plan: Mapping[str, Any],
    research_steps: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    final_plan = {
        **dict(draft_plan),
        "steps": [dict(step) for step in draft_plan.get("steps") or ()],
    }
    for step in final_plan["steps"]:
        step["research_mode"] = None
    if set(arguments) != {"step_modes"}:
        raise NodeLoopPlanError(
            "node_loop_research_mode_projection_fields_invalid"
        )
    raw_modes = arguments.get("step_modes")
    if (
        isinstance(raw_modes, (str, bytes))
        or not isinstance(raw_modes, Sequence)
        or len(raw_modes) != len(research_steps)
    ):
        raise NodeLoopPlanError(
            "node_loop_research_mode_projection_count_invalid"
        )

    research_step_by_index = {
        int(step["step_index"]): step for step in research_steps
    }
    expected_indices = set(research_step_by_index)
    seen_indices: set[int] = set()
    accepted_modes: list[dict[str, Any]] = []
    for raw in raw_modes:
        if not isinstance(raw, Mapping) or set(raw) != {
            "step_index",
            "task_source",
            "research_strategy",
            "input_roles",
            "decision_note",
        }:
            raise NodeLoopPlanError(
                "node_loop_research_mode_projection_item_invalid"
            )
        raw_index = raw.get("step_index")
        if isinstance(raw_index, bool) or not isinstance(raw_index, int):
            raise NodeLoopPlanError(
                "node_loop_research_mode_projection_index_invalid"
            )
        if raw_index not in expected_indices or raw_index in seen_indices:
            raise NodeLoopPlanError(
                "node_loop_research_mode_projection_index_invalid"
            )
        decision_note = " ".join(
            str(raw.get("decision_note") or "").split()
        )
        if (
            not decision_note
            or len(decision_note) > RESEARCH_MODE_DECISION_NOTE_LIMIT
        ):
            raise NodeLoopPlanError(
                "node_loop_research_mode_projection_note_invalid"
            )
        research_step = research_step_by_index[raw_index]
        candidate_input_refs = tuple(
            str(ref)
            for ref in research_step.get("candidate_input_refs") or ()
        )
        role_by_ref = _validated_research_input_roles(
            raw.get("input_roles"),
            step_index=raw_index + 1,
            candidate_refs=candidate_input_refs,
        )
        provisional_input_refs = frozenset(
            str(ref)
            for ref in research_step.get("provisional_input_refs") or ()
        )
        for ref, role in role_by_ref.items():
            if ref in provisional_input_refs and role == "irrelevant":
                raise NodeLoopPlanError(
                    f"node_loop_step_{raw_index + 1}_finalized_input_removed"
                )
            if ref not in provisional_input_refs and role in {
                "commission_authority",
                "required_authority",
            }:
                raise NodeLoopPlanError(
                    f"node_loop_step_{raw_index + 1}_optional_context_"
                    "promoted_to_authority"
                )
        final_input_refs = [
            ref
            for ref in candidate_input_refs
            if role_by_ref[ref] != "irrelevant"
        ]
        commissioned_refs = [
            ref
            for ref in candidate_input_refs
            if role_by_ref[ref] == "commission_authority"
        ]
        step = final_plan["steps"][raw_index]
        step["input_refs"] = final_input_refs
        research_mode = _validated_research_mode_card(
            {
                "task_source": raw.get("task_source"),
                "research_strategy": raw.get("research_strategy"),
                "commissioned_input_refs": commissioned_refs,
            },
            step_index=raw_index + 1,
            input_refs=frozenset(final_input_refs),
        )
        if research_mode is None:
            raise NodeLoopPlanError(
                "node_loop_research_mode_projection_card_required"
            )
        step["research_mode"] = research_mode
        seen_indices.add(raw_index)
        accepted_modes.append(
            {
                "step_index": raw_index,
                "research_mode": research_mode,
                "provisional_input_refs": list(
                    research_step.get("provisional_input_refs") or ()
                ),
                "candidate_input_refs": list(candidate_input_refs),
                "input_roles": [
                    {"artifact_ref": ref, "role": role_by_ref[ref]}
                    for ref in candidate_input_refs
                ],
                "final_input_refs": final_input_refs,
                "decision_note": decision_note,
            }
        )
    if seen_indices != expected_indices:
        raise NodeLoopPlanError(
            "node_loop_research_mode_projection_coverage_invalid"
        )
    return final_plan, accepted_modes


def _validated_research_input_roles(
    raw: Any,
    *,
    step_index: int,
    candidate_refs: Sequence[str],
) -> dict[str, str]:
    if not isinstance(raw, Sequence) or isinstance(raw, (str, bytes)):
        raise NodeLoopPlanError(
            f"node_loop_step_{step_index}_input_roles_invalid"
        )
    expected_refs = tuple(str(ref) for ref in candidate_refs)
    role_by_ref: dict[str, str] = {}
    for item in raw:
        if not isinstance(item, Mapping) or set(item) != {
            "artifact_ref",
            "role",
        }:
            raise NodeLoopPlanError(
                f"node_loop_step_{step_index}_input_roles_invalid"
            )
        artifact_ref = str(item.get("artifact_ref") or "").strip()
        role = str(item.get("role") or "").strip()
        if (
            not artifact_ref
            or artifact_ref not in expected_refs
            or artifact_ref in role_by_ref
        ):
            raise NodeLoopPlanError(
                f"node_loop_step_{step_index}_input_role_ref_invalid"
            )
        if role not in RESEARCH_INPUT_ROLES:
            raise NodeLoopPlanError(
                f"node_loop_step_{step_index}_input_role_invalid"
            )
        role_by_ref[artifact_ref] = role
    if set(role_by_ref) != set(expected_refs) or len(role_by_ref) != len(
        expected_refs
    ):
        raise NodeLoopPlanError(
            f"node_loop_step_{step_index}_input_role_coverage_invalid"
        )
    return role_by_ref


def _validated_research_mode_card(
    raw: Any,
    *,
    step_index: int,
    input_refs: frozenset[str],
) -> dict[str, Any] | None:
    if raw is None:
        return None
    if not isinstance(raw, Mapping) or set(raw) != {
        "task_source",
        "research_strategy",
        "commissioned_input_refs",
    }:
        raise NodeLoopPlanError(
            f"node_loop_step_{step_index}_research_mode_invalid"
        )
    task_source = str(raw.get("task_source") or "")
    strategy = str(raw.get("research_strategy") or "")
    raw_commissioned = raw.get("commissioned_input_refs")
    if task_source not in _RESEARCH_TASK_SOURCES:
        raise NodeLoopPlanError(
            f"node_loop_step_{step_index}_task_source_invalid"
        )
    if strategy not in _RESEARCH_STRATEGIES:
        raise NodeLoopPlanError(
            f"node_loop_step_{step_index}_research_strategy_invalid"
        )
    if (
        not isinstance(raw_commissioned, Sequence)
        or isinstance(raw_commissioned, (str, bytes))
    ):
        raise NodeLoopPlanError(
            f"node_loop_step_{step_index}_commissioned_refs_invalid"
        )
    commissioned_refs = [str(ref).strip() for ref in raw_commissioned]
    if (
        any(not ref for ref in commissioned_refs)
        or len(commissioned_refs) != len(set(commissioned_refs))
        or not set(commissioned_refs).issubset(input_refs)
        or (task_source == "autonomous" and commissioned_refs)
    ):
        raise NodeLoopPlanError(
            f"node_loop_step_{step_index}_commissioned_refs_invalid"
        )
    return {
        "task_source": task_source,
        "research_strategy": strategy,
        "commissioned_input_refs": commissioned_refs,
    }


def compact_node_loop_purpose(value: str) -> str:
    """Project a raw C6 purpose into the bounded C1 operational summary."""
    normalized = " ".join(str(value).split())
    if len(normalized) <= NODE_LOOP_PURPOSE_LIMIT:
        return normalized
    return textwrap.shorten(
        normalized,
        width=NODE_LOOP_PURPOSE_LIMIT,
        placeholder="...",
    )
