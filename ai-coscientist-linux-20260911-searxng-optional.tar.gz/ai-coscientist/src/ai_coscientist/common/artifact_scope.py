from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Sequence

from .artifacts import ArtifactStore
from .memory_lifecycle.policy import active_artifact_receipts


class ArtifactScope:
    """A runtime visibility view over one shared immutable artifact board."""

    def __init__(
        self,
        store: ArtifactStore,
        *,
        agent_id: str,
        isolated: bool = False,
        mounted_refs: Sequence[str] = (),
        quarantined_refs: Sequence[str] = (),
    ) -> None:
        self._store = store
        self._agent_id = str(agent_id)
        self._isolated = bool(isolated)
        self._mounted_refs = {str(ref) for ref in mounted_refs if str(ref)}
        self._owned_refs: set[str] = set()
        self._quarantined_refs = {
            str(ref) for ref in quarantined_refs if str(ref)
        }

    @property
    def root(self) -> Path:
        return self._store.root

    @property
    def store(self) -> ArtifactStore:
        return self._store

    def list(self) -> tuple[dict[str, Any], ...]:
        receipts = tuple(
            receipt
            for receipt in self._store.list()
            if str(receipt.get("artifact_ref") or "")
            not in self._quarantined_refs
        )
        if not self._isolated:
            return receipts
        visible = self._visible_refs(receipts)
        return tuple(
            receipt
            for receipt in receipts
            if str(receipt.get("artifact_ref") or "") in visible
        )

    def active_receipts(
        self,
        *,
        explicit_refs: Sequence[str] = (),
    ) -> tuple[dict[str, Any], ...]:
        if not self._isolated and not self._quarantined_refs:
            return self._store.active_receipts(explicit_refs=explicit_refs)
        return active_artifact_receipts(
            self.list(),
            read_artifact=self.read,
            explicit_refs=explicit_refs,
        )

    def read(self, artifact_ref: str) -> dict[str, Any]:
        ref = str(artifact_ref).strip()
        if ref in self._quarantined_refs:
            raise PermissionError(f"artifact_pending_child_review:{ref}")
        artifact = self._store.read(ref)
        if self._isolated and not self._can_read(ref, artifact):
            raise PermissionError(f"artifact_not_visible_to_agent:{ref}")
        return artifact

    def read_for_review(self, artifact_ref: str) -> dict[str, Any]:
        ref = str(artifact_ref).strip()
        if ref not in self._quarantined_refs:
            raise PermissionError(f"artifact_not_pending_child_review:{ref}")
        return self._store.read(ref)

    def quarantine_refs(self, refs: Sequence[str]) -> tuple[str, ...]:
        quarantined: list[str] = []
        for raw_ref in refs:
            ref = str(raw_ref).strip()
            if not ref:
                continue
            self._store.read(ref)
            self._quarantined_refs.add(ref)
            quarantined.append(ref)
        return tuple(quarantined)

    def unquarantine_refs(self, refs: Sequence[str]) -> tuple[str, ...]:
        released: list[str] = []
        for raw_ref in refs:
            ref = str(raw_ref).strip()
            if ref in self._quarantined_refs:
                self._quarantined_refs.remove(ref)
                released.append(ref)
        return tuple(released)

    def is_quarantined(self, artifact_ref: str) -> bool:
        return str(artifact_ref).strip() in self._quarantined_refs

    def publish(self, **kwargs: Any) -> dict[str, Any]:
        receipt = self._store.publish(**kwargs)
        ref = str(receipt.get("artifact_ref") or "")
        if ref:
            self._owned_refs.add(ref)
        return receipt

    def register_produced_refs(self, refs: Sequence[str]) -> tuple[str, ...]:
        """Make artifacts produced on this agent's behalf visible to it."""
        registered: list[str] = []
        for raw_ref in refs:
            ref = str(raw_ref).strip()
            if not ref:
                continue
            self._store.read(ref)
            self._owned_refs.add(ref)
            registered.append(ref)
        return tuple(registered)

    def mount_refs(self, refs: Sequence[str]) -> tuple[str, ...]:
        mounted: list[str] = []
        for raw_ref in refs:
            ref = str(raw_ref).strip()
            if not ref:
                continue
            self._store.read(ref)
            self._mounted_refs.add(ref)
            mounted.append(ref)
        return tuple(mounted)

    def owned_refs(self) -> tuple[str, ...]:
        refs: list[str] = []
        for receipt in self._store.list():
            ref = str(receipt.get("artifact_ref") or "")
            if not ref:
                continue
            try:
                artifact = self._store.read(ref)
            except (KeyError, OSError, ValueError):
                continue
            if (
                ref in self._owned_refs
                or artifact.get("producer_agent_id") == self._agent_id
            ):
                refs.append(ref)
        return tuple(refs)

    def mounted_refs(self) -> tuple[str, ...]:
        return tuple(sorted(self._mounted_refs))

    def _can_read(self, ref: str, artifact: Mapping[str, Any]) -> bool:
        return (
            ref not in self._quarantined_refs
            and (
                ref in self._mounted_refs
                or ref in self._owned_refs
                or artifact.get("producer_agent_id") == self._agent_id
            )
        )

    def _visible_refs(self, receipts: Sequence[Mapping[str, Any]]) -> set[str]:
        visible = set(self._mounted_refs) | set(self._owned_refs)
        for receipt in receipts:
            ref = str(receipt.get("artifact_ref") or "")
            if not ref:
                continue
            try:
                artifact = self._store.read(ref)
            except (KeyError, OSError, ValueError):
                continue
            if artifact.get("producer_agent_id") == self._agent_id:
                visible.add(ref)

        return visible

