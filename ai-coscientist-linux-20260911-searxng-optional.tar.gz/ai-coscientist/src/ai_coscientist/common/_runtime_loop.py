from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from .capabilities import parse_task_authorization
from ._runtime_support import (
    merge_current_issue as _merge_current_issue,
    return_control_issue as _return_control_issue,
)
from .attempt_handoffs import node_attempt_handoff_issue
from .memory_lifecycle.policy import PromptBudgetExceeded, PromptSource
from .memory_lifecycle.prompt import bounded_text
from .model import ModelTurn, ToolCall, complete_model_turn, retry_model_turn_without_reasoning
from .openai_compatible import ModelProtocolError, visible_tool_protocol_issue
from .planning import active_work_unit
from .planning.node_loop import (
    NodeLoopStepCallLimitError,
    current_step_input_refs,
    next_skill_id,
)
from .sub_loop_toolkit import HumanInteractionPause

_TERMINAL_SKILL_WORKFLOW_STATUSES = frozenset(
    {"complete", "completed", "blocked", "bounded_gap"}
)


@dataclass(frozen=True)
class AgentResult:
    status: str
    final_text: str
    rounds: int
    closure: Mapping[str, Any]


class ExecutionLoopMixin:
    """Run the common-agent round loop and enforce transition discipline."""

    def _repair_invalid_tool_arguments(
        self,
        *,
        error: ModelProtocolError,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
        purpose: str,
        round_number: int,
    ) -> ModelTurn | None:
        if getattr(error, "code", "") != "tool_call_invalid_arguments":
            return None
        tool_name = str(getattr(error, "tool_name", "") or "").strip()
        matching_tools = [
            tool
            for tool in tools
            if str((tool.get("function") or {}).get("name") or "") == tool_name
        ]
        if not tool_name or len(matching_tools) != 1:
            return None

        file_payload_instruction = ""
        if tool_name == "development_project_write":
            file_payload_instruction = (
                " The intended file operation may be regenerated, but keep this "
                "single payload reliably bounded. Write one coherent file only; "
                "if the implementation is large, split it by responsibility and "
                "leave later modules for later tool steps."
            )
        elif tool_name == "development_project_edit":
            file_payload_instruction = (
                " The intended file operation may be regenerated, but keep this "
                "single payload reliably bounded. Prefer the smallest coherent "
                "edit instead of replacing a large whole-project body."
            )
        instruction = (
            "Native tool-call encoding repair only. The preceding call selected "
            f"`{tool_name}`, but its arguments ended as malformed or incomplete "
            "JSON, so nothing executed. Reissue exactly one call to the supplied "
            "same tool with complete valid JSON arguments. Reconstruct the intended "
            "action from the original request and current authoritative state; do "
            "not treat the malformed prefix as an observation, change the scientific "
            "objective, inspect new data, or explain the answer in prose."
            + file_payload_instruction
        )
        repair_purpose = f"repair malformed native arguments: {tool_name}"
        repair_messages = [*messages, {"role": "user", "content": instruction}]
        self._reserve_active_loop_step_model_call(purpose=repair_purpose)
        self._memory.prepare_for_model_call(
            call_site=repair_purpose,
            consumer=self._work.consumer,
        )
        self._memory.record_prompt_projection(
            call_site=repair_purpose,
            messages=repair_messages,
            tools=matching_tools,
            sources=(
                PromptSource("C5", "original_request", list(messages)),
                PromptSource("C5", "malformed_tool_arguments", str(error)),
                PromptSource("instruction", "protocol_repair", instruction),
                PromptSource("tool_schema", "selected_tool", matching_tools[0]),
            ),
            budget_tier="full",
        )
        self._events.append(
            "tool_payload_repair_prompt_snapshot",
            {
                "round": round_number,
                "purpose": repair_purpose,
                "reason": str(error),
                "messages": repair_messages,
                "tool_names": [tool_name],
            },
        )
        repaired = complete_model_turn(
            self._model,
            messages=repair_messages,
            tools=matching_tools,
            purpose=repair_purpose,
            tool_choice="required",
            repair=True,
        )
        if len(repaired.tool_calls) != 1 or repaired.tool_calls[0].name != tool_name:
            raise ModelProtocolError(
                "tool_argument_protocol_repair_changed_action:"
                f"expected={tool_name}:actual="
                f"{','.join(call.name for call in repaired.tool_calls)}"
            )
        return repaired

    def _record_execution_turn(
        self, turn: ModelTurn, *, messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]], purpose: str,
        tool_choice: str | None, round_number: int,
    ) -> tuple[ModelTurn, int]:
        def record(event_type: str, candidate: ModelTurn) -> int:
            return self._events.append(event_type, {
                "round": round_number, "content": candidate.content,
                "tool_calls": [{"call_id": call.call_id, "name": call.name,
                                "arguments": dict(call.arguments)} for call in candidate.tool_calls],
                "usage": dict(candidate.usage),
            })

        sequence = record("model_turn", turn)
        issue = visible_tool_protocol_issue(turn.content)
        if not issue:
            return turn, sequence
        if turn.tool_calls:
            # Native calls already have an exact identity. Discard only the
            # malformed prose; normal payload validation still owns the calls.
            return ModelTurn(content="", tool_calls=turn.tool_calls,
                             usage=turn.usage, finish_reason=turn.finish_reason), sequence
        repair_purpose = "repair malformed visible tool protocol"
        instruction = (
            "Response encoding repair only. The preceding response contained bare "
            "tool-protocol markup in its ordinary content. No calls from that response "
            "have executed. Use native tool_calls, never DSML/Harmony markup in text. "
            "Do not invent observations or interpret the leaked markup as actions. "
            "Ordinary text is optional and must not contain wire-format tool blocks. "
            "Answer the original request using its declared tools and constraints."
        )
        repair_messages = [*messages, {"role": "user", "content": instruction}]
        self._reserve_active_loop_step_model_call(purpose=repair_purpose)
        self._memory.prepare_for_model_call(
            call_site=repair_purpose, consumer=self._work.consumer,
        )
        self._memory.record_prompt_projection(
            call_site=repair_purpose, messages=repair_messages, tools=tools,
            sources=(PromptSource("C5", "original_request", list(messages)),
                     PromptSource("instruction", "protocol_repair", instruction),
                     PromptSource("tool_schema", "available_tools", list(tools))),
            budget_tier="full",
        )
        self._events.append("tool_payload_repair_prompt_snapshot", {
            "round": round_number, "purpose": repair_purpose,
            "messages": repair_messages,
            "tool_names": [tool["function"]["name"] for tool in tools],
        })
        repaired = complete_model_turn(
            self._model, messages=repair_messages, tools=tools,
            purpose=repair_purpose, tool_choice=tool_choice, repair=True,
        )
        sequence = record("tool_payload_repair_model_turn", repaired)
        if visible_tool_protocol_issue(repaired.content):
            raise ModelProtocolError("visible_tool_protocol_invalid_after_repair")
        # Private repair prose is audit-only; only its native calls can proceed.
        return ModelTurn(content="", tool_calls=repaired.tool_calls,
                         usage=repaired.usage, finish_reason=repaired.finish_reason), sequence

    def _complete_execution_turn(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
        purpose: str,
        tool_choice: str | None,
        scientific: bool,
        round_number: int,
        planning: bool = False,
    ) -> ModelTurn:
        try:
            return complete_model_turn(
                self._model, messages=messages, tools=tools, purpose=purpose,
                tool_choice=tool_choice, scientific=scientific, planning=planning,
            )
        except ModelProtocolError as exc:
            repaired = self._repair_invalid_tool_arguments(
                error=exc,
                messages=messages,
                tools=tools,
                purpose=purpose,
                round_number=round_number,
            )
            if repaired is not None:
                return repaired
            def before_retry() -> None:
                self._reserve_active_loop_step_model_call(purpose=purpose)
                self._events.append("model_output_limit_retry", {
                    "round": round_number, "purpose": purpose,
                    "reason": str(exc), "reasoning_effort": "none",
                })

            return retry_model_turn_without_reasoning(
                self._model, error=exc, before_retry=before_retry,
                messages=messages, tools=tools, purpose=purpose,
                tool_choice=tool_choice, scientific=scientific, planning=planning,
            )

    def run(
        self,
        *,
        objective: str,
        evaluation_summary: str,
    ) -> AgentResult:
        if self._mission is None:
            parsed = parse_task_authorization(objective)
            objective = parsed.objective
            self._enabled_meta_capabilities = (
                parsed.enabled_meta_capabilities
            )
            self._configure_meta_skill_catalog(
                self._enabled_meta_capabilities,
                require_support=bool(self._enabled_meta_capabilities),
            )
        else:
            parsed = parse_task_authorization(objective)
            if parsed.enabled_meta_capabilities:
                raise RuntimeError(
                    "child_objective_meta_capability_commands_forbidden"
                )
            objective = parsed.objective
        self._human_run_rounds_used = 0
        try:
            return self._run_until_boundary(
                objective=objective,
                evaluation_summary=evaluation_summary,
            )
        except HumanInteractionPause:
            pending = self.pending_human_interaction()
            if pending is None:
                raise RuntimeError(
                    "human_interaction_pause_without_pending_request"
                )
            closure = self._current_evaluation_closure_or_bootstrap()
            return AgentResult(
                status="paused_for_human",
                final_text=str(pending["question"]),
                rounds=int(self._human_run_rounds_used),
                closure=closure,
            )

    def _run_until_boundary(
        self,
        *,
        objective: str,
        evaluation_summary: str,
    ) -> AgentResult:
        self._bootstrap_or_load_evaluation(
            objective=objective,
            evaluation_request=evaluation_summary,
        )
        if self.pending_human_interaction() is not None:
            raise HumanInteractionPause()
        self._resume_paused_child_if_ready()
        if self._human_response_requires_new_frame():
            self._apply_confirmed_global_evaluation_amendment(
                round_number=0
            )
        if not self._human_resume_anchor_is_current():
            raise RuntimeError("human_interaction_resume_anchor_stale")
        self._mount_run_inputs()
        self._resume_pending_contract_graph_rebuild(round_number=0)
        self._ensure_initial_plan()
        self._reconcile_active_skill_context_on_resume()

        final_text = ""
        last_closure: Mapping[str, Any] = self._current_evaluation_closure()
        if bool(last_closure.get("complete")):
            self._events.append(
                "evaluation_terminal_resumed",
                {"result": dict(last_closure)},
            )
            return AgentResult(
                status="complete",
                final_text=final_text,
                rounds=0,
                closure=last_closure,
            )
        self._ensure_frame_evaluation()
        if active_work_unit(self._state.read()["c1"]["plan_graph"]) is None:
            last_closure = self._evaluate_runtime_progress(round_number=0)
            if bool(last_closure.get("complete")):
                return AgentResult(
                    status="complete",
                    final_text=final_text,
                    rounds=0,
                    closure=last_closure,
                )
            self._reconcile_active_skill_context_on_resume()
        start_round = self._next_round_number()
        rounds_used = 0
        last_round_number = start_round

        for rounds_used, round_number in enumerate(
            range(start_round, start_round + self._max_rounds), start=1
        ):
            self._human_run_rounds_used = rounds_used
            if self.pending_human_interaction() is not None:
                raise HumanInteractionPause()
            last_round_number = round_number
            self._recover_pending_readback(round_number=round_number)
            active_skill_id = str(self._state.read()["c1"]["active_skill_id"] or "")
            if not active_skill_id:
                activation_state = self._state.read()
                activation_node = active_work_unit(
                    activation_state["c1"]["plan_graph"]
                )
                if activation_node is not None and next_skill_id(
                    activation_state["c1"]["node_loop_state"],
                    node_id=str(activation_node["node_id"]),
                ):
                    self._activate_planned_skill(round_number=round_number)
                    active_skill_id = str(
                        self._state.read()["c1"]["active_skill_id"] or ""
                    )
            if active_skill_id and self._skills.has_workflow(active_skill_id):
                try:
                    (
                        final_text,
                        invocation_artifact_refs,
                        workflow_completion_ref,
                        workflow_status,
                        workflow_error,
                        workflow_result,
                    ) = self._run_active_skill_workflow(
                        active_skill_id,
                        round_number=round_number,
                    )
                except NodeLoopStepCallLimitError as exc:
                    self._exhaust_active_loop_step_model_calls(
                        exc,
                        round_number=round_number,
                    )
                    continue
                completion_refs = list(invocation_artifact_refs)
                if workflow_completion_ref and workflow_completion_ref not in completion_refs:
                    completion_refs.append(workflow_completion_ref)
                completion_ref_tuple = self._node_completion_candidate_refs(completion_refs)
                observed_workflow_result = dict(workflow_result or {})
                if workflow_error:
                    observed_workflow_result.update(
                        {"status": "failed", "reason": workflow_error}
                    )
                elif (
                    workflow_status in _TERMINAL_SKILL_WORKFLOW_STATUSES
                    and not completion_ref_tuple
                ):
                    observed_workflow_result.update(
                        {
                            "status": "failed",
                            "reason": (
                                "skill-local workflow returned terminal status "
                                "without formal result evidence"
                            ),
                        }
                    )
                terminal_workflow_status = (
                    workflow_status in _TERMINAL_SKILL_WORKFLOW_STATUSES
                )

                plan_refresh_issue = ""
                plan_assessment_issue = ""
                try:
                    plan_assessment_issue = self._refresh_plan(
                        completion_ref_tuple,
                        producer_skill_id=active_skill_id,
                        observed_result=observed_workflow_result,
                        round_number=round_number,
                    )
                except Exception as exc:
                    plan_refresh_issue = f"plan_refresh_failed:{exc}"
                    self._events.append(
                        "plan_refresh_error",
                        {
                            "round": round_number,
                            "artifact_refs": list(completion_ref_tuple),
                            "reason": str(exc),
                        },
                    )
                    self._release_skill_context()
                    self._state.set_issue(plan_refresh_issue)
                    self._events.append(
                        "skill_context_released",
                        {
                            "round": round_number,
                            "skill_id": active_skill_id,
                            "reason": "plan_refresh_failed",
                        },
                    )
                    raise
                if completion_ref_tuple or terminal_workflow_status or workflow_error:
                    last_closure = self._evaluate_runtime_progress(
                        round_number=round_number
                    )
                else:
                    last_closure = self._current_evaluation_closure()

                if workflow_error:
                    handoff_issue = self._skill_workflow_failure_issue(
                        active_skill_id,
                        workflow_error,
                    )
                elif (
                    workflow_status in {"complete", "completed"}
                    and completion_ref_tuple
                ):
                    handoff_issue = bounded_text(
                        "Completed skill-local workflow published formal "
                        "artifacts: " + ", ".join(completion_ref_tuple),
                        1_200,
                    )
                elif workflow_status in {"bounded_gap", "blocked"}:
                    base_issue = _return_control_issue(
                        final_text,
                        last_closure,
                        source="completed skill-local workflow",
                        artifact_refs=completion_ref_tuple,
                    )
                    handoff_issue = self._skill_workflow_terminal_gap_issue(
                        active_skill_id,
                        workflow_status=workflow_status,
                        reason=final_text,
                        artifact_refs=completion_ref_tuple,
                        base_issue=base_issue,
                    )
                else:
                    handoff_issue = _return_control_issue(
                        final_text,
                        last_closure,
                        source=(
                            "completed skill-local workflow"
                            if terminal_workflow_status
                            else "unfinished skill-local workflow"
                        ),
                        artifact_refs=completion_ref_tuple,
                    )
                if plan_refresh_issue:
                    handoff_issue = _merge_current_issue(
                        handoff_issue,
                        plan_refresh_issue,
                    )
                if plan_assessment_issue:
                    handoff_issue = bounded_text(
                        plan_assessment_issue
                        + "\nInvocation receipt: "
                        + handoff_issue,
                        2_000,
                    )
                self._state.set_issue(handoff_issue)

                if bool(last_closure.get("complete")):
                    self._release_skill_context()
                    self._events.append(
                        "skill_context_released",
                        {
                            "round": round_number,
                            "skill_id": active_skill_id,
                            "reason": "agent_local_evaluation_terminal",
                        },
                    )
                    return AgentResult(
                        status="complete",
                        final_text=final_text,
                        rounds=rounds_used,
                        closure=last_closure,
                    )

                if (
                    not workflow_error
                    and not completion_ref_tuple
                    and not terminal_workflow_status
                ):
                    self._events.append(
                        "skill_context_retained",
                        {
                            "round": round_number,
                            "skill_id": active_skill_id,
                            "reason": "workflow_return_without_formal_result",
                        },
                    )
                    continue

                self._release_skill_context()
                self._events.append(
                    "skill_context_released",
                    {
                        "round": round_number,
                        "skill_id": active_skill_id,
                        "reason": (
                            "workflow_failed"
                            if workflow_error
                            else "skill_local_workflow_returned_control"
                        ),
                    },
                )
                self._state.set_issue(handoff_issue)
                continue

            if not active_skill_id:
                state = self._state.read()
                active_node = active_work_unit(state["c1"]["plan_graph"])
                pending_child_review = bool(
                    self._pending_child_review_packets()
                )
                if active_node is not None and not pending_child_review:
                    loop_state = state["c1"]["node_loop_state"]
                    planned_skill_id = next_skill_id(
                        loop_state,
                        node_id=str(active_node["node_id"]),
                    )
                    if planned_skill_id:
                        raise RuntimeError(
                            "planned_skill_activation_did_not_enter_active_skill"
                        )
                    previous_attempt = (
                        int(loop_state["attempt_index"])
                        if str(loop_state["node_id"])
                        == str(active_node["node_id"])
                        else 0
                    )
                    if (
                        previous_attempt == 0
                        and not bool(loop_state["awaiting_transition"])
                        and self._accept_existing_work_unit_evidence(
                            round_number=round_number,
                        )
                    ):
                        continue
                    if (
                        previous_attempt >= 2
                        and not bool(loop_state["awaiting_transition"])
                    ):
                        self._ensure_node_loop_plan(
                            round_number=round_number
                        )
                        continue
                if active_node is None and not pending_child_review:
                    last_closure = self._evaluate_runtime_progress(
                        round_number=round_number
                    )
                    if bool(last_closure.get("complete")):
                        return AgentResult(
                            status="complete",
                            final_text=final_text,
                            rounds=rounds_used,
                            closure=last_closure,
                        )
                    continue

            purpose = self._purpose()
            if active_skill_id:
                try:
                    self._reserve_active_loop_step_model_call(purpose=purpose)
                except NodeLoopStepCallLimitError as exc:
                    self._exhaust_active_loop_step_model_calls(
                        exc,
                        round_number=round_number,
                    )
                    continue
            self._memory.prepare_for_model_call(
                call_site=purpose, consumer=str(active_skill_id or "node-execution"),
            )
            state = self._state.read()
            node_loop_state = state["c1"].get("node_loop_state")
            active_node = active_work_unit(state["c1"]["plan_graph"])
            planned_skill_id = (
                next_skill_id(
                    node_loop_state,
                    node_id=str(active_node["node_id"]),
                )
                if isinstance(node_loop_state, Mapping)
                and active_node is not None
                else ""
            )
            pending_child_review = bool(self._pending_child_review_packets())
            node_execution_decision = bool(
                not state["c1"]["active_skill_id"]
                and active_node is not None
                and not bool(node_loop_state.get("awaiting_transition"))
                and not planned_skill_id
            )
            has_active_node_loop = bool(
                isinstance(node_loop_state, Mapping)
                and str(node_loop_state.get("node_id") or "").strip()
            )
            budget_tier = (
                "full"
                if state["c1"]["active_skill_id"] or has_active_node_loop
                else "compact"
            )
            projection_tier = "normal"
            recent_native_turn_budget_bytes = None
            pressure_compaction_attempted = False
            while True:
                messages = self._render_messages(
                    projection_tier=projection_tier,
                    recent_native_turn_budget_bytes=(
                        recent_native_turn_budget_bytes
                    ),
                )
                tools = self._tool_specs(
                    projection_tier=projection_tier,
                    prompt_messages=messages,
                )
                try:
                    self._memory.record_prompt_projection(
                        call_site=purpose,
                        messages=messages,
                        tools=tools,
                        sources=self._runtime_prompt_sources(
                            messages=messages,
                            tools=tools,
                        ),
                        budget_tier=budget_tier,
                    )
                    break
                except PromptBudgetExceeded as exc:
                    if projection_tier != "minimal":
                        self._events.append(
                            "prompt_projection_degraded",
                            {
                                "round": round_number,
                                "purpose": purpose,
                                "from_tier": "normal",
                                "to_tier": "minimal",
                                "reason": str(exc),
                            },
                        )
                        projection_tier = "minimal"
                        continue
                    receipt = exc.receipt
                    recent_source = next(
                        (
                            source
                            for source in receipt.get("sources") or ()
                            if source.get("name") == "recent_native_turns"
                        ),
                        None,
                    )
                    current_recent_bytes = (
                        int(recent_source.get("bytes") or 0)
                        if isinstance(recent_source, Mapping)
                        else 0
                    )
                    overflow = max(
                        0,
                        int(receipt.get("total_bytes") or 0)
                        - int(receipt.get("budget_bytes") or 0),
                    )
                    reduced_budget = max(
                        0,
                        current_recent_bytes - overflow - 4_096,
                    )
                    if (
                        current_recent_bytes <= 0
                        or (
                            recent_native_turn_budget_bytes is not None
                            and reduced_budget >= recent_native_turn_budget_bytes
                        )
                    ):
                        if current_recent_bytes > 0 and not pressure_compaction_attempted:
                            pressure_compaction_attempted = True
                            if self._memory.maintain(recent_budget_bytes=reduced_budget):
                                # Rebuild with the new summary and its uncovered
                                # exact receipts; do not reuse a stale byte count.
                                recent_native_turn_budget_bytes = None
                                continue
                        raise
                    self._events.append(
                        "prompt_projection_recent_native_turns_reduced",
                        {
                            "round": round_number,
                            "purpose": purpose,
                            "from_bytes": recent_native_turn_budget_bytes,
                            "to_bytes": reduced_budget,
                            "overflow_bytes": overflow,
                        },
                    )
                    recent_native_turn_budget_bytes = reduced_budget
            self._events.append(
                "prompt_snapshot",
                {
                    "round": round_number,
                    "purpose": purpose,
                    "active_skill_id": state["c1"]["active_skill_id"],
                    "projection_tier": projection_tier,
                    "messages": messages,
                    "tool_names": [tool["function"]["name"] for tool in tools],
                },
            )
            try:
                turn = self._complete_execution_turn(
                    messages=messages,
                    tools=tools,
                    purpose=purpose,
                    # Required-tool decoding can suppress the ordinary work note.
                    # Existing result/readback rules, not this API mode, own closure.
                    tool_choice=(
                        "required"
                        if pending_child_review or node_execution_decision
                        else "auto" if state["c1"]["active_skill_id"] else None
                    ),
                    scientific=bool(state["c1"]["active_skill_id"]),
                    planning=node_execution_decision and not pending_child_review,
                    round_number=round_number,
                )
                turn, model_event_sequence = self._record_execution_turn(
                    turn, messages=messages, tools=tools, purpose=purpose,
                    tool_choice=("required" if pending_child_review or node_execution_decision
                                 else "auto" if state["c1"]["active_skill_id"] else None),
                    round_number=round_number,
                )
            except NodeLoopStepCallLimitError as exc:
                self._exhaust_active_loop_step_model_calls(
                    exc, round_number=round_number,
                )
                continue
            self._work.record_note(
                turn.content, event_id=f"{self.agent_id}:{model_event_sequence}:note",
                source_refs=tuple(ref for ref in dict.fromkeys([
                    *state["c1"]["resolved_artifact_refs"],
                    *self._work.checkpoint()["source_refs"],
                    *(ref for _, entry in self._work.entries(
                        after_sequence=self._work.checkpoint()["through_sequence"]
                    ) for ref in entry["source_refs"]),
                ]) if not ref.startswith("work_entry:")),
            )

            if turn.tool_calls:
                child_completion_refs: list[str] = []
                step_call_limit_exhausted = False
                for call in turn.tool_calls:
                    try:
                        (
                            prepared_call,
                            repair_failure,
                        ) = self._repair_tool_payload_if_needed(
                            call,
                            round_number=round_number,
                        )
                    except NodeLoopStepCallLimitError as exc:
                        self._exhaust_active_loop_step_model_calls(
                            exc,
                            round_number=round_number,
                        )
                        step_call_limit_exhausted = True
                        break
                    tool_result = self._execute_tool_call(
                        prepared_call,
                        round_number=round_number,
                        repair_failure=repair_failure,
                    )
                    if self.pending_human_interaction() is not None:
                        raise HumanInteractionPause()
                    if (
                        pending_child_review
                        and prepared_call.name == "review_child_result"
                        and isinstance(tool_result, Mapping)
                    ):
                        review = tool_result.get("review")
                        if isinstance(review, Mapping):
                            if review.get("decision") == "accept":
                                accepted = review.get("accepted_artifact_refs")
                                if isinstance(accepted, (list, tuple)):
                                    child_completion_refs.extend(
                                        str(ref) for ref in accepted if str(ref)
                                    )
                            elif review.get("decision") == "reject":
                                child_id = str(
                                    prepared_call.arguments.get("child_id") or ""
                                )
                                handoff = self._child_operational_handoff(child_id)
                                issue = (
                                    node_attempt_handoff_issue(handoff)
                                    if isinstance(handoff, Mapping)
                                    else (
                                        "child_node_attempt_rejected:"
                                        f"child_id={child_id}:the returned result "
                                        "did not satisfy the delegated Graph node"
                                    )
                                )
                                self._state.set_issue(issue)
                                if isinstance(handoff, Mapping):
                                    self._events.append(
                                        "node_child_attempt_failed",
                                        {
                                            "round": round_number,
                                            "node_id": str(
                                                handoff.get("node_id") or ""
                                            ),
                                            "attempt_index": int(
                                                handoff.get("attempt_index") or 0
                                            ),
                                            "reason": issue,
                                        },
                                    )
                    self._recover_pending_readback(round_number=round_number)
                if step_call_limit_exhausted:
                    continue
                if child_completion_refs:
                    unique_refs = tuple(dict.fromkeys(child_completion_refs))
                    try:
                        plan_assessment_issue = self._refresh_plan(
                            unique_refs,
                            producer_skill_id="",
                            observed_result={
                                "status": "reviewed_child_result_accepted",
                                "artifact_refs": list(unique_refs),
                            },
                            round_number=round_number,
                        )
                    except Exception as exc:
                        issue = f"plan_refresh_failed:{exc}"
                        self._state.set_issue(issue)
                        self._events.append(
                            "plan_refresh_error",
                            {
                                "round": round_number,
                                "artifact_refs": list(unique_refs),
                                "reason": str(exc),
                                "source": "reviewed_child_result",
                            },
                        )
                        raise
                    last_closure = self._evaluate_runtime_progress(
                        round_number=round_number
                    )
                    if plan_assessment_issue:
                        self._state.set_issue(plan_assessment_issue)
                    if bool(last_closure.get("complete")):
                        return AgentResult(
                            status="complete",
                            final_text=final_text,
                            rounds=rounds_used,
                            closure=last_closure,
                        )
                continue

            final_text = turn.content.strip()
            active_skill_id = str(self._state.read()["c1"]["active_skill_id"] or "")
            invocation_artifact_refs = (
                self._active_invocation_artifact_refs(active_skill_id)
                if active_skill_id
                else ()
            )
            completion_candidate_refs = (
                self._node_completion_candidate_refs(invocation_artifact_refs)
                if active_skill_id else ()
            )
            plan_refresh_issue = ""
            plan_assessment_issue = ""
            if completion_candidate_refs:
                try:
                    observed_result = {
                        "summary": final_text,
                        "artifact_refs": list(completion_candidate_refs),
                    }
                    if invocation_artifact_refs:
                        observed_result["status"] = "formal_result_published"
                    plan_assessment_issue = self._refresh_plan(
                        completion_candidate_refs,
                        producer_skill_id=active_skill_id,
                        observed_result=observed_result,
                        round_number=round_number,
                    )
                except Exception as exc:
                    plan_refresh_issue = f"plan_refresh_failed:{exc}"
                    self._events.append(
                        "plan_refresh_error",
                        {
                            "round": round_number,
                            "artifact_refs": list(completion_candidate_refs),
                            "reason": str(exc),
                        },
                    )
                    self._release_skill_context()
                    self._state.set_issue(plan_refresh_issue)
                    self._events.append(
                        "skill_context_released",
                        {
                            "round": round_number,
                            "skill_id": active_skill_id,
                            "reason": "plan_refresh_failed",
                        },
                    )
                    raise
            last_closure = self._evaluate_runtime_progress(
                round_number=round_number
            )
            if bool(last_closure.get("complete")):
                if active_skill_id:
                    self._release_skill_context()
                    self._events.append(
                        "skill_context_released",
                        {
                            "round": round_number,
                            "skill_id": active_skill_id,
                            "reason": "agent_local_evaluation_terminal",
                        },
                    )
                return AgentResult(
                    status="complete",
                    final_text=final_text,
                    rounds=rounds_used,
                    closure=last_closure,
                )

            if active_skill_id and not completion_candidate_refs:
                self._state.set_issue(
                    "selected_skill_result_required: the active "
                    "skill returned prose without a formal result. Continue "
                    "the skill or call restart_node_attempt with the precise "
                    "proven gap. Plain text cannot end an active attempt."
                )
                self._events.append(
                    "skill_context_retained",
                    {
                        "round": round_number,
                        "skill_id": active_skill_id,
                        "reason": "text_return_without_formal_result",
                    },
                )
                continue

            if active_skill_id:
                self._release_skill_context()
                self._events.append(
                    "skill_context_released",
                    {
                        "round": round_number,
                        "skill_id": active_skill_id,
                        "reason": "model_returned_control_before_terminal",
                    },
                )
            handoff_issue = _return_control_issue(
                final_text,
                last_closure,
                source=(
                    "released skill invocation"
                    if active_skill_id
                    else "skill-selection boundary"
                ),
                artifact_refs=completion_candidate_refs,
            )
            if plan_refresh_issue:
                handoff_issue = _merge_current_issue(
                    handoff_issue,
                    plan_refresh_issue,
                )
            if plan_assessment_issue:
                handoff_issue = bounded_text(
                    plan_assessment_issue + "\nInvocation receipt: " + handoff_issue,
                    2_000,
                )
            self._state.set_issue(handoff_issue)
        last_closure = self._current_evaluation_closure(scope="global")
        self._events.append(
            "runtime_execution_window_exhausted",
            {
                "round": last_round_number,
                "rounds_used": rounds_used,
                "active_skill_id": str(
                    self._state.read()["c1"]["active_skill_id"] or ""
                ),
                "reason": (
                    "host execution window ended without changing Node, Frame, "
                    "or Graph state"
                ),
            },
        )
        return AgentResult(
            status="round_limit",
            final_text=final_text,
            rounds=rounds_used,
            closure=last_closure,
        )

    def _evaluate_runtime_progress(
        self,
        *,
        round_number: int,
    ) -> Mapping[str, Any]:
        """Evaluate Frame progress and consult Global only at a boundary."""
        frame_closure = self._evaluate_agent_closure(
            round_number=round_number,
            scope="frame",
        )
        global_terminal = self._advance_frame_boundary(
            frame_closure=frame_closure,
            round_number=round_number,
            current_issue=str(self._state.read()["c1"]["current_issue"]),
        )
        if global_terminal is not None:
            return global_terminal
        return self._current_evaluation_closure(scope="global")

    def _mount_run_inputs(self) -> None:
        """Mount run inputs without broadening a resumed skill invocation."""
        state = self._state.read()
        active_skill_id = str(state["c1"]["active_skill_id"] or "")
        refs = [
            *self._initial_artifact_refs,
            *getattr(self, "_preformulated_task_input_refs", ()),
        ]
        if self._mission:
            refs.extend(
                ref
                for ref in self._mission.artifact_refs
                if ref.startswith("artifact:")
            )
        for ref in dict.fromkeys(refs):
            if ref.startswith("artifact:"):
                self._artifacts.mount_refs((ref,))
            self._read_exact_ref(ref)
            if not active_skill_id:
                self._state.add_resolved_artifact_ref(ref)
        if active_skill_id:
            self._events.append(
                "active_skill_inputs_preserved_on_resume",
                {
                    "skill_id": active_skill_id,
                    "resolved_artifact_refs": list(
                        state["c1"]["resolved_artifact_refs"]
                    ),
                },
            )

    def _reconcile_active_skill_context_on_resume(self) -> bool:
        """Drop invocation state that no longer belongs to the active node LOOP."""
        state = self._state.read()
        active_skill_id = str(state["c1"]["active_skill_id"] or "")
        if not active_skill_id:
            return False

        active_node = active_work_unit(state["c1"]["plan_graph"])
        active_node_id = (
            str(active_node["node_id"]) if active_node is not None else ""
        )
        loop_state = state["c1"]["node_loop_state"]
        expected_skill_id = (
            next_skill_id(loop_state, node_id=active_node_id)
            if active_node_id
            else ""
        )
        expected_refs = tuple(
            dict.fromkeys(
                [
                    *current_step_input_refs(
                        loop_state,
                        node_id=active_node_id,
                    ),
                    *(
                        str(ref)
                        for ref in loop_state.get("produced_refs", ())
                    ),
                    *self._answered_human_response_refs(),
                ]
            )
        )
        active_refs = tuple(
            str(ref) for ref in state["c1"]["resolved_artifact_refs"]
        )
        load_event = self._active_invocation_load_event(active_skill_id)
        load_result = load_event.get("raw_result") if load_event else None
        invocation_inputs = (
            self._active_invocation_seed_refs(active_skill_id)
            if isinstance(load_result, Mapping) and "input_refs" in load_result
            else active_refs
        )
        # Resolved refs grow as the skill reads its own outputs. Only the
        # original invocation inputs determine whether the commission changed.
        if (
            expected_skill_id == active_skill_id
            and expected_refs == invocation_inputs
        ):
            return False

        stale_loop_node_id = str(loop_state.get("node_id") or "")
        self._release_skill_context()
        self._events.append(
            "stale_skill_context_released_on_resume",
            {
                "stale_skill_id": active_skill_id,
                "active_node_id": active_node_id or None,
                "node_loop_node_id": stale_loop_node_id or None,
                "expected_skill_id": expected_skill_id or None,
                "stale_input_refs": list(active_refs),
                "expected_input_refs": list(expected_refs),
            },
        )
        return True

    def _activate_planned_skill(self, *, round_number: int) -> bool:
        """Mechanically enter the next skill already fixed by the node LOOP."""
        state = self._state.read()
        active = active_work_unit(state["c1"]["plan_graph"])
        if active is None:
            return False
        skill_id = next_skill_id(
            state["c1"]["node_loop_state"],
            node_id=str(active["node_id"]),
        )
        if not skill_id:
            return False
        self._execute_tool_call(
            ToolCall(
                call_id=f"runtime-load-skill-{round_number}",
                name="load_skill",
                arguments={"skill_id": skill_id},
            ),
            round_number=round_number,
        )
        loaded_skill_id = str(
            self._state.read()["c1"]["active_skill_id"] or ""
        )
        if loaded_skill_id == skill_id:
            self._events.append(
                "planned_skill_loaded",
                {
                    "round": round_number,
                    "node_id": str(active["node_id"]),
                    "skill_id": skill_id,
                },
            )
            return True

        issue = str(self._state.read()["c1"]["current_issue"] or "")
        self._restart_node_attempt(
            "planned_skill_load_failed:"
            + (issue or f"skill={skill_id}"),
            round_number=round_number,
        )
        return True

    def _next_round_number(self) -> int:
        rounds = [
            int(event["round"])
            for event in self._events.read()
            if event.get("round") is not None
        ]
        return max(rounds, default=0) + 1

    def _recover_pending_readback(self, *, round_number: int) -> bool:
        """Read immutable tool outputs without spending another model round."""
        recovery_offset = sum(
            event.get("event_type") == "artifact_readback_recovered"
            and int(event.get("round", -1)) == round_number
            for event in self._events.read()
        )
        recovered_any = False
        for local_index in range(1, 9):
            pending_ref = self._pending_readback_ref()
            if not pending_ref:
                return recovered_any
            recovery_index = recovery_offset + local_index
            readback_call = ToolCall(
                call_id=f"runtime-readback-{round_number}-{recovery_index}",
                name="read_ref",
                arguments={"ref": pending_ref},
            )
            readback_result = self._execute_tool_call(
                readback_call,
                round_number=round_number,
                internal_readback=True,
            )
            if self._pending_readback_ref() == pending_ref:
                self._events.append(
                    "artifact_readback_recovery_failed",
                    {
                        "round": round_number,
                        "artifact_ref": pending_ref,
                        "reason": "mandatory_exact_readback_remains_pending",
                    },
                )
                return False
            self._events.append(
                "artifact_readback_recovered",
                {
                    "round": round_number,
                    "call_id": readback_call.call_id,
                    "tool": readback_call.name,
                    "status": str(
                        readback_result.get("status") or "completed"
                    ),
                    "artifact_ref": pending_ref,
                    "reason": "mandatory_exact_readback_is_mechanical",
                },
            )
            recovered_any = True
        pending_ref = self._pending_readback_ref()
        self._events.append(
            "artifact_readback_recovery_failed",
            {
                "round": round_number,
                "artifact_ref": pending_ref,
                "reason": "mandatory_exact_readback_budget_exhausted",
            },
        )
        return False
