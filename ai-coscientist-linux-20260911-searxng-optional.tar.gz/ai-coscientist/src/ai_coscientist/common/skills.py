from __future__ import annotations

import hashlib
import importlib.util
import inspect
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Mapping, Sequence

from .reference_links import reference_source_read

if TYPE_CHECKING:
    from .artifacts import ArtifactStore
    from .capabilities import CapabilityRegistry
    from .routes import Route


SkillWorkflow = Callable[[dict[str, Any], Any], Any]
_PENDING_DECLARATIVE_REFERENCE_SUFFIXES = frozenset(
    {".csv", ".json", ".md", ".txt", ".tsv", ".yaml", ".yml"}
)
_MARKDOWN_LINK_TARGET = re.compile(r"\[[^\]]+\]\(([^)\s]+)\)")


class SkillWorkflowLoadError(RuntimeError):
    """Raised before execution when an optional trusted workflow is invalid."""


class SkillDisclosureLoadError(RuntimeError):
    """Raised when an optional selected-skill disclosure module is invalid."""


def _pending_skill_package_is_declarative(root: Path) -> bool:
    files = [path for path in root.rglob("*") if path.is_file()]
    if root / "SKILL.md" not in files:
        return False
    for path in files:
        relative = path.relative_to(root)
        if relative.as_posix() == "SKILL.md":
            continue
        if (
            len(relative.parts) < 2
            or relative.parts[0] != "references"
            or path.suffix.lower()
            not in _PENDING_DECLARATIVE_REFERENCE_SUFFIXES
        ):
            return False
    return True


def _select_pending_skill_candidate(
    candidates: Sequence[
        tuple[str, Mapping[str, Any], Path, tuple[str, ...]]
    ],
    *,
    preferred_candidate_refs: Sequence[str] = (),
) -> tuple[str, Mapping[str, Any], Path, tuple[str, ...]] | None:
    """Select exact task authority or the unique revision-chain leaf."""
    if not candidates:
        return None
    preferred_refs = {
        str(ref).strip()
        for ref in preferred_candidate_refs
        if str(ref).strip()
    }
    preferred = [
        candidate for candidate in candidates if candidate[0] in preferred_refs
    ]
    if preferred:
        return preferred[0] if len(preferred) == 1 else None
    if len(candidates) == 1:
        return candidates[0]
    revisions = [
        candidate
        for candidate in candidates
        if str(candidate[1].get("candidate_kind") or "") == "revision"
    ]
    if not revisions:
        return candidates[-1]
    superseded_hashes = {
        str(candidate[1].get("base_package_hash") or "")
        for candidate in revisions
        if str(candidate[1].get("base_package_hash") or "")
    }
    leaves = [
        candidate
        for candidate in candidates
        if str(candidate[1].get("package_hash") or "")
        not in superseded_hashes
    ]
    return leaves[0] if len(leaves) == 1 else None


@dataclass(frozen=True)
class SkillCard:
    skill_id: str
    description: str
    estimated_complexity: str
    detail_ref: str
    accepts_research_mode: bool = False


class SkillCatalog:
    """Discovers skills and reveals either their full or opted-in focused detail."""

    def __init__(
        self,
        root: Path,
        *,
        include_ids: Sequence[str] | None = None,
        overlay_roots: Mapping[str, Path] | None = None,
        capability_registry: "CapabilityRegistry | None" = None,
    ) -> None:
        self._root = root.resolve()
        self._fixed_overlay_roots = {
            str(skill_id): Path(path).resolve()
            for skill_id, path in (overlay_roots or {}).items()
        }
        self._overlay_roots = dict(self._fixed_overlay_roots)
        self._capability_registry = capability_registry
        self._allowed_roots = (
            self._root,
            *(path for path in self._overlay_roots.values()),
        )
        self._include_ids = (
            None
            if include_ids is None
            else tuple(str(skill_id) for skill_id in include_ids)
        )
        discovered = self._discover()
        requested = tuple(str(skill_id) for skill_id in (include_ids or ()))
        missing = [skill_id for skill_id in requested if skill_id not in discovered]
        if missing:
            raise KeyError(f"included_skills_missing:{missing}")
        self._cards = (
            {skill_id: discovered[skill_id] for skill_id in requested}
            if include_ids is not None
            else discovered
        )
        self._workflow_cache: dict[str, SkillWorkflow] = {}
        self._workflow_module_cache: dict[str, Any] = {}
        self._disclosure_cache: dict[str, Any] = {}
        self._pending_skill_lineage_refs: dict[str, tuple[str, ...]] = {}
        self._pending_skill_route_contracts: dict[
            str, tuple[dict[str, Any], ...]
        ] = {}
        self._pending_route_descriptors: list[dict[str, Any]] = []

    @property
    def root(self) -> Path:
        return self._root

    def pending_candidate_snapshot(
        self,
        package_ref: str,
        *,
        max_text_chars: int = 32_000,
    ) -> dict[str, Any]:
        """Read one exact pending package for an evaluator-only linked ref."""
        if self._capability_registry is None:
            raise KeyError("capability_registry_unavailable")
        return self._capability_registry.pending_candidate_snapshot(
            str(package_ref),
            max_text_chars=max_text_chars,
        )

    def clone_for_child(self) -> "SkillCatalog":
        """Re-scan SKILL.md; do not copy live detail or workflow cache."""
        return SkillCatalog(
            self._root,
            include_ids=self._include_ids,
            overlay_roots=self._fixed_overlay_roots,
            capability_registry=self._capability_registry,
        )

    def refresh_pending_candidates(
        self,
        artifacts: "ArtifactStore",
        *,
        preferred_candidate_refs: Sequence[str] = (),
    ) -> None:
        """Mount exact task-visible pending candidates without activating them."""
        self._overlay_roots = dict(self._fixed_overlay_roots)
        self._pending_skill_lineage_refs = {}
        self._pending_skill_route_contracts = {}
        self._pending_route_descriptors = []
        if self._capability_registry is None:
            return

        base_cards = self._discover()
        candidates: list[
            tuple[str, Mapping[str, Any], tuple[str, ...]]
        ] = []
        for receipt in artifacts.list():
            if receipt.get("artifact_kind") != "capability_candidate":
                continue
            ref = str(receipt.get("artifact_ref") or "")
            if not ref:
                continue
            try:
                stored = artifacts.read(ref)
            except (KeyError, OSError, PermissionError, ValueError):
                continue
            payload = stored.get("machine_payload")
            if isinstance(payload, Mapping):
                candidates.append(
                    (
                        ref,
                        payload,
                        tuple(str(item) for item in stored.get("depends_on") or ()),
                    )
                )

        skill_candidates: dict[
            str,
            list[tuple[str, Mapping[str, Any], Path, tuple[str, ...]]],
        ] = {}
        latest_skills: dict[
            str,
            tuple[str, Mapping[str, Any], Path, tuple[str, ...]],
        ] = {}
        for candidate_ref, payload, candidate_dependencies in candidates:
            package_ref = str(payload.get("package_ref") or "")
            try:
                expected = self._capability_registry.candidate_payload_for_package_ref(
                    package_ref
                )
            except Exception:
                continue
            if dict(payload) != expected:
                continue
            asset_type = str(payload.get("asset_type") or "")
            if asset_type == "route_package":
                snapshot = self._capability_registry.pending_candidate_snapshot(
                    package_ref,
                    max_text_chars=0,
                )
                manifest = snapshot["manifest"]
                for route in manifest["routes"]:
                    route_ref = self._capability_registry.pending_route_ref(
                        package_ref,
                        str(route["route_name"]),
                    )
                    descriptor = self._capability_registry.resolve_managed_route_ref(
                        route_ref
                    )
                    self._pending_route_descriptors.append(
                        {
                            **descriptor,
                            "candidate_artifact_ref": candidate_ref,
                        }
                    )
                continue
            if asset_type != "skill":
                continue
            skill_id = str(payload.get("asset_id") or "")
            if not skill_id or skill_id in base_cards:
                continue
            try:
                skill_root = self._capability_registry.pending_skill_root(
                    package_ref,
                    candidate_payload=payload,
                )
            except Exception:
                continue
            if not _pending_skill_package_is_declarative(skill_root):
                continue
            skill_candidates.setdefault(skill_id, []).append(
                (
                    candidate_ref,
                    payload,
                    skill_root,
                    candidate_dependencies,
                )
            )

        for skill_id, options in skill_candidates.items():
            selected = _select_pending_skill_candidate(
                options,
                preferred_candidate_refs=preferred_candidate_refs,
            )
            if selected is not None:
                latest_skills[skill_id] = selected

        for skill_id, (
            candidate_ref,
            payload,
            skill_root,
            candidate_dependencies,
        ) in sorted(
            latest_skills.items()
        ):
            route_contracts = self._pending_skill_route_contracts_for(
                payload=payload,
                candidate_dependencies=candidate_dependencies,
            )
            if route_contracts is None:
                continue
            self._overlay_roots[skill_id] = skill_root
            self._pending_skill_route_contracts[skill_id] = route_contracts
            self._pending_skill_lineage_refs[skill_id] = tuple(
                dict.fromkeys(
                    (
                        candidate_ref,
                        *self._pending_skill_route_lineage_refs(
                            payload=payload,
                            candidate_dependencies=candidate_dependencies,
                        ),
                    )
                )
            )

        self._allowed_roots = (
            self._root,
            *(path for path in self._overlay_roots.values()),
        )
        discovered = self._discover()
        requested = tuple(str(skill_id) for skill_id in (self._include_ids or ()))
        base = (
            {skill_id: discovered[skill_id] for skill_id in requested}
            if self._include_ids is not None
            else {
                skill_id: card
                for skill_id, card in discovered.items()
                if skill_id not in self._pending_skill_lineage_refs
            }
        )
        for skill_id in self._pending_skill_lineage_refs:
            base[skill_id] = discovered[skill_id]
        self._cards = base
        self._workflow_cache.clear()
        self._workflow_module_cache.clear()
        self._disclosure_cache.clear()

    def _pending_skill_route_contracts_for(
        self,
        *,
        payload: Mapping[str, Any],
        candidate_dependencies: Sequence[str],
    ) -> tuple[dict[str, Any], ...] | None:
        """Resolve declared Route contracts without granting execution access."""
        assert self._capability_registry is not None
        dependency_refs = set(candidate_dependencies)
        contracts: list[dict[str, Any]] = []
        for dependency in payload.get("route_dependencies") or ():
            if not isinstance(dependency, Mapping):
                return None
            route_name = str(dependency.get("route_name") or "")
            package_hash = str(dependency.get("package_hash") or "")
            approved_ref = f"approved_route:{route_name}:{package_hash}"
            candidate_artifact_ref = ""
            try:
                descriptor = self._capability_registry.resolve_route_ref(
                    approved_ref
                )
            except (KeyError, RuntimeError, ValueError):
                pending_ref = f"pending_route:{route_name}:{package_hash}"
                matches = [
                    item
                    for item in self._pending_route_descriptors
                    if item.get("route_ref") == pending_ref
                    and item.get("candidate_artifact_ref") in dependency_refs
                ]
                if len(matches) != 1:
                    return None
                descriptor = matches[0]
                candidate_artifact_ref = str(
                    descriptor.get("candidate_artifact_ref") or ""
                )
            contract = {
                "route_ref": str(descriptor["route_ref"]),
                "description": str(descriptor["description"]),
                "input_schema": dict(descriptor["input_schema"]),
                "output_schema": dict(descriptor["output_schema"]),
                "agent_callable": bool(descriptor["agent_callable"]),
                "code_callable": bool(descriptor["code_callable"]),
                "estimated_complexity": str(descriptor["estimated_complexity"]),
            }
            if candidate_artifact_ref:
                contract["candidate_artifact_ref"] = candidate_artifact_ref
            contracts.append(contract)
        return tuple(contracts)

    def _pending_skill_route_lineage_refs(
        self,
        *,
        payload: Mapping[str, Any],
        candidate_dependencies: Sequence[str],
    ) -> tuple[str, ...]:
        dependency_refs = set(candidate_dependencies)
        exact_route_refs = {
            f"pending_route:{item.get('route_name')}:{item.get('package_hash')}"
            for item in payload.get("route_dependencies") or ()
            if isinstance(item, Mapping)
        }
        refs = [
            str(item["candidate_artifact_ref"])
            for item in self._pending_route_descriptors
            if item.get("route_ref") in exact_route_refs
            and item.get("candidate_artifact_ref") in dependency_refs
        ]
        return tuple(dict.fromkeys(refs))

    def lineage_refs(self, skill_id: str) -> tuple[str, ...]:
        return self._pending_skill_lineage_refs.get(str(skill_id), ())

    def managed_route_summaries(
        self,
        *,
        skill_id: str,
        require_agent_callable: bool = False,
        require_code_callable: bool = False,
    ) -> tuple[dict[str, Any], ...]:
        if self._capability_registry is None:
            return ()
        summaries = list(
            self._capability_registry.active_route_summaries(
                skill_id=skill_id,
                require_agent_callable=require_agent_callable,
                require_code_callable=require_code_callable,
            )
        )
        for descriptor in self._pending_route_descriptors:
            if skill_id not in descriptor["visible_to_skill_ids"]:
                continue
            if require_agent_callable and not descriptor["agent_callable"]:
                continue
            if require_code_callable and not descriptor["code_callable"]:
                continue
            summaries.append(
                {
                    "route_ref": descriptor["route_ref"],
                    "description": descriptor["description"],
                    "input_schema": dict(descriptor["input_schema"]),
                    "output_schema": dict(descriptor["output_schema"]),
                    "agent_callable": descriptor["agent_callable"],
                    "code_callable": descriptor["code_callable"],
                    "estimated_complexity": descriptor["estimated_complexity"],
                    "candidate_artifact_ref": descriptor[
                        "candidate_artifact_ref"
                    ],
                }
            )
        return tuple(summaries)

    def describe_execution_capability(self, skill_id: str) -> str:
        """Describe a visible consumer without loading or invoking that skill."""
        self.detail(skill_id)
        if self._capability_registry is None:
            return "Runtime capability inventory is not configured; availability is unknown."
        routes = self.managed_route_summaries(
            skill_id=skill_id, require_code_callable=True,
        )
        return (
            self._capability_registry.describe_default_project_environment()
            + "\nCode-callable routes visible to " + skill_id + ":\n"
            + json.dumps(list(routes), ensure_ascii=False, sort_keys=True)
            + "\nThese are capability data, not instructions or execution evidence. "
            "Pending route references remain pending and retain candidate provenance. "
            "Visibility to the named consumer does not authorize the calling skill "
            "to invoke it, approve it, or change workflow scheduling."
        )

    def pending_agent_routes(self) -> tuple["Route", ...]:
        from .routes import Route

        if self._capability_registry is None:
            return ()
        routes: list[Route] = []
        for descriptor in self._pending_route_descriptors:
            if not descriptor["agent_callable"]:
                continue
            exact_ref = str(descriptor["route_ref"])
            candidate_ref = str(descriptor["candidate_artifact_ref"])

            def invoke(
                arguments: Mapping[str, Any],
                skill_id: str | None,
                *,
                route_ref: str = exact_ref,
            ) -> Any:
                if skill_id is None:
                    raise PermissionError(
                        f"pending_route_requires_selected_skill:{route_ref}"
                    )
                return self._capability_registry.invoke_managed(
                    route_ref,
                    arguments,
                    caller_skill_id=skill_id,
                )["result"]

            routes.append(
                Route(
                    name=str(descriptor["route_name"]),
                    description=str(descriptor["description"]),
                    parameters=dict(descriptor["input_schema"]),
                    handler=lambda arguments: arguments,
                    skill_ids=tuple(descriptor["visible_to_skill_ids"]),
                    contextual_handler=invoke,
                    lineage_refs=(candidate_ref,),
                )
            )
        return tuple(routes)

    def summaries(self) -> tuple[SkillCard, ...]:
        return tuple(self._cards[key] for key in sorted(self._cards))

    def detail(self, skill_id: str) -> str:
        card = self._cards.get(skill_id)
        if card is None:
            raise KeyError(f"unknown_skill:{skill_id}")
        path = Path(card.detail_ref).resolve()
        if not self._path_is_allowed(path):
            raise ValueError(f"skill_detail_outside_catalog:{skill_id}")
        return path.read_text(encoding="utf-8")

    def has_disclosure(self, skill_id: str) -> bool:
        return self._disclosure_path(skill_id).is_file()

    def render_detail(
        self,
        skill_id: str,
        context: Mapping[str, Any],
    ) -> str:
        """Render focused detail for opted-in skills; legacy skills stay unchanged."""
        root_detail = self.detail(skill_id)
        if not self.has_disclosure(skill_id):
            return self._render_pending_declarative_detail(
                skill_id,
                root_detail,
                context,
            )
        module = self._disclosure_module(skill_id)
        render = getattr(module, "render", None)
        if not callable(render):
            raise SkillDisclosureLoadError(
                f"skill_disclosure_render_missing:{skill_id}"
            )
        _require_callable_arity(
            render,
            2,
            f"skill_disclosure_render_signature_invalid:{skill_id}",
        )
        disclosed_context = dict(context)
        if self._capability_registry is not None:
            disclosed_context["approved_route_summaries"] = list(
                self._capability_registry.active_route_summaries(
                    skill_id=skill_id,
                )
            )
            disclosed_context["managed_route_summaries"] = list(
                self.managed_route_summaries(skill_id=skill_id)
            )
        rendered = render(root_detail, disclosed_context)
        if not isinstance(rendered, str) or not rendered.strip():
            raise SkillDisclosureLoadError(
                f"skill_disclosure_render_result_invalid:{skill_id}"
            )
        return rendered

    def _render_pending_declarative_detail(
        self,
        skill_id: str,
        root_detail: str,
        context: Mapping[str, Any],
    ) -> str:
        """Reveal linked Markdown pages after selecting a pending text-only Skill."""
        if skill_id not in self._pending_skill_lineage_refs:
            return root_detail
        card = self._cards[skill_id]
        skill_root = Path(card.detail_ref).resolve().parent
        linked_pages: list[tuple[str, str]] = []
        seen: set[str] = set()
        for raw_target in _MARKDOWN_LINK_TARGET.findall(root_detail):
            target = raw_target.partition("#")[0].replace("\\", "/").strip()
            if (
                not target.startswith("references/")
                or not target.lower().endswith(".md")
                or target in seen
            ):
                continue
            path = (skill_root / Path(target)).resolve()
            if not path.is_relative_to(skill_root) or not path.is_file():
                raise SkillDisclosureLoadError(
                    f"pending_skill_linked_reference_unreadable:{skill_id}:{target}"
                )
            seen.add(target)
            linked_pages.append((target, path.read_text(encoding="utf-8")))
        route_contracts = list(
            self._pending_skill_route_contracts.get(skill_id, ())
        )
        if not linked_pages and not route_contracts:
            return root_detail
        sections = [root_detail.rstrip()]
        for target, content in linked_pages:
            sections.extend(
                (
                    "",
                    f"## Progressively disclosed reference: {target}",
                    "",
                    content.strip(),
                )
            )
        if route_contracts:
            sections.extend(
                (
                    "",
                    "## Exact declared Route contracts (read-only)",
                    "",
                    (
                        "These exact input/output contracts come from this pending "
                        "Skill's validated dependencies. Use them to make compatible "
                        "recommendations or protocols. They do not expose a Route "
                        "tool and do not authorize Route execution."
                    ),
                    "",
                    "```json",
                    json.dumps(route_contracts, ensure_ascii=False, indent=2),
                    "```",
                )
            )
        return "\n".join(sections).rstrip() + "\n"

    def disclosure_visible_refs(
        self,
        skill_id: str,
        context: Mapping[str, Any],
    ) -> tuple[str, ...] | None:
        """Return an optional focused ref projection for an opted-in skill."""
        if not self.has_disclosure(skill_id):
            return None
        module = self._disclosure_module(skill_id)
        visible_refs = getattr(module, "visible_refs", None)
        if visible_refs is None:
            return None
        if not callable(visible_refs):
            raise SkillDisclosureLoadError(
                f"skill_disclosure_visible_refs_invalid:{skill_id}"
            )
        _require_callable_arity(
            visible_refs,
            1,
            f"skill_disclosure_visible_refs_signature_invalid:{skill_id}",
        )
        disclosed_context = dict(context)
        if self._capability_registry is not None:
            disclosed_context["approved_route_summaries"] = list(
                self._capability_registry.active_route_summaries(
                    skill_id=skill_id,
                )
            )
            disclosed_context["managed_route_summaries"] = list(
                self.managed_route_summaries(skill_id=skill_id)
            )
        raw_refs = visible_refs(disclosed_context)
        if isinstance(raw_refs, (str, bytes)) or not isinstance(raw_refs, Sequence):
            raise SkillDisclosureLoadError(
                f"skill_disclosure_visible_refs_result_invalid:{skill_id}"
            )
        normalized: list[str] = []
        for raw_ref in raw_refs:
            ref = str(raw_ref).strip()
            if ref and ref not in normalized:
                normalized.append(ref)
        return tuple(normalized)

    def disclosure_visible_route_names(
        self,
        skill_id: str,
        route_names: Sequence[str],
        context: Mapping[str, Any],
    ) -> tuple[str, ...]:
        """Let an opted-in Skill narrow its currently registered Route tools."""
        normalized = tuple(
            dict.fromkeys(str(name).strip() for name in route_names if str(name).strip())
        )
        if not self.has_disclosure(skill_id):
            return normalized
        module = self._disclosure_module(skill_id)
        visible_route_names = getattr(module, "visible_route_names", None)
        if visible_route_names is None:
            return normalized
        if not callable(visible_route_names):
            raise SkillDisclosureLoadError(
                f"skill_disclosure_visible_route_names_invalid:{skill_id}"
            )
        _require_callable_arity(
            visible_route_names,
            2,
            f"skill_disclosure_visible_route_names_signature_invalid:{skill_id}",
        )
        disclosed_context = dict(context)
        if self._capability_registry is not None:
            disclosed_context["approved_route_summaries"] = list(
                self._capability_registry.active_route_summaries(
                    skill_id=skill_id,
                )
            )
            disclosed_context["managed_route_summaries"] = list(
                self.managed_route_summaries(skill_id=skill_id)
            )
        raw_names = visible_route_names(normalized, disclosed_context)
        if isinstance(raw_names, (str, bytes)) or not isinstance(raw_names, Sequence):
            raise SkillDisclosureLoadError(
                f"skill_disclosure_visible_route_names_result_invalid:{skill_id}"
            )
        allowed = set(normalized)
        result: list[str] = []
        for raw_name in raw_names:
            name = str(raw_name).strip()
            if name not in allowed:
                raise SkillDisclosureLoadError(
                    "skill_disclosure_visible_route_names_unknown:"
                    f"{skill_id}:{name or 'empty'}"
                )
            if name not in result:
                result.append(name)
        return tuple(result)

    def validate_disclosed_tool_call(
        self,
        skill_id: str,
        tool_name: str,
        arguments: Mapping[str, Any],
        context: Mapping[str, Any],
    ) -> None:
        """Run an opted-in skill's science-neutral invocation-lineage checks."""
        source_arguments = reference_source_read(tool_name, arguments)
        if source_arguments is not None:
            tool_name, arguments = "read_ref", source_arguments
        if not self.has_disclosure(skill_id):
            return
        module = self._disclosure_module(skill_id)
        validate = getattr(module, "validate_tool_call", None)
        if validate is None:
            return
        if not callable(validate):
            raise SkillDisclosureLoadError(
                f"skill_disclosure_validate_tool_call_invalid:{skill_id}"
            )
        _require_callable_arity(
            validate,
            3,
            f"skill_disclosure_validate_tool_call_signature_invalid:{skill_id}",
        )
        disclosed_context = dict(context)
        if self._capability_registry is not None:
            disclosed_context["approved_route_summaries"] = list(
                self._capability_registry.active_route_summaries(
                    skill_id=skill_id,
                )
            )
            disclosed_context["managed_route_summaries"] = list(
                self.managed_route_summaries(skill_id=skill_id)
            )
        validate(str(tool_name), dict(arguments), disclosed_context)

    def has_workflow(self, skill_id: str) -> bool:
        return self._workflow_path(skill_id).is_file()

    def workflow(self, skill_id: str) -> SkillWorkflow:
        cached = self._workflow_cache.get(skill_id)
        if cached is not None:
            return cached
        module = self._workflow_module(skill_id)
        run = getattr(module, "run", None)
        if not callable(run):
            raise SkillWorkflowLoadError(f"skill_workflow_run_missing:{skill_id}")
        _require_callable_arity(
            run,
            2,
            f"skill_workflow_run_signature_invalid:{skill_id}",
            error_type=SkillWorkflowLoadError,
        )
        self._workflow_cache[skill_id] = run
        return run

    def _workflow_module(self, skill_id: str) -> Any:
        cached = self._workflow_module_cache.get(skill_id)
        if cached is not None:
            return cached
        path = self._workflow_path(skill_id)
        if not path.is_file():
            raise KeyError(f"skill_workflow_missing:{skill_id}")
        digest = hashlib.sha256(str(path).encode("utf-8")).hexdigest()[:16]
        module_name = f"ai_coscientist_skill_{skill_id}_{digest}"
        spec = importlib.util.spec_from_file_location(module_name, path)
        if spec is None or spec.loader is None:
            raise SkillWorkflowLoadError(
                f"skill_workflow_module_unloadable:{skill_id}"
            )
        module = importlib.util.module_from_spec(spec)
        package_path = str(path.parent)
        sys.path.insert(0, package_path)
        try:
            spec.loader.exec_module(module)
        except Exception as exc:
            raise SkillWorkflowLoadError(
                f"skill_workflow_import_failed:{skill_id}:{exc}"
            ) from exc
        finally:
            if sys.path and sys.path[0] == package_path:
                sys.path.pop(0)
            elif package_path in sys.path:
                sys.path.remove(package_path)
        self._workflow_module_cache[skill_id] = module
        return module

    def _workflow_path(self, skill_id: str) -> Path:
        card = self._cards.get(skill_id)
        if card is None:
            raise KeyError(f"unknown_skill:{skill_id}")
        path = (Path(card.detail_ref).parent / "workflow.py").resolve()
        if not self._path_is_allowed(path):
            raise ValueError(f"skill_workflow_outside_catalog:{skill_id}")
        return path

    def _disclosure_path(self, skill_id: str) -> Path:
        card = self._cards.get(skill_id)
        if card is None:
            raise KeyError(f"unknown_skill:{skill_id}")
        path = (Path(card.detail_ref).parent / "disclosure.py").resolve()
        if not self._path_is_allowed(path):
            raise ValueError(f"skill_disclosure_outside_catalog:{skill_id}")
        return path

    def _disclosure_module(self, skill_id: str) -> Any:
        cached = self._disclosure_cache.get(skill_id)
        if cached is not None:
            return cached
        path = self._disclosure_path(skill_id)
        if not path.is_file():
            raise KeyError(f"skill_disclosure_missing:{skill_id}")
        digest = hashlib.sha256(str(path).encode("utf-8")).hexdigest()[:16]
        module_name = f"ai_coscientist_skill_disclosure_{skill_id}_{digest}"
        spec = importlib.util.spec_from_file_location(module_name, path)
        if spec is None or spec.loader is None:
            raise SkillDisclosureLoadError(
                f"skill_disclosure_module_unloadable:{skill_id}"
            )
        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)
        except Exception as exc:
            raise SkillDisclosureLoadError(
                f"skill_disclosure_import_failed:{skill_id}:{exc}"
            ) from exc
        self._disclosure_cache[skill_id] = module
        return module

    def _discover(self) -> dict[str, SkillCard]:
        cards = self._discover_root(self._root)
        for expected_skill_id, overlay_root in sorted(
            self._overlay_roots.items()
        ):
            path = overlay_root / "SKILL.md"
            if not path.is_file():
                raise ValueError(
                    f"approved_skill_overlay_missing:{expected_skill_id}"
                )
            overlay = self._card_from_path(path)
            if overlay.skill_id != expected_skill_id:
                raise ValueError(
                    "approved_skill_overlay_id_mismatch:"
                    f"expected={expected_skill_id}:actual={overlay.skill_id}"
                )
            cards[expected_skill_id] = overlay
        return cards

    def _discover_root(self, root: Path) -> dict[str, SkillCard]:
        cards: dict[str, SkillCard] = {}
        if not root.exists():
            return cards
        for path in sorted(root.glob("*/SKILL.md")):
            card = self._card_from_path(path)
            if card.skill_id in cards:
                raise ValueError(f"duplicate_skill:{card.skill_id}")
            cards[card.skill_id] = card
        return cards

    @staticmethod
    def _card_from_path(path: Path) -> SkillCard:
        metadata = _frontmatter(path.read_text(encoding="utf-8"))
        skill_id = metadata.get("name", path.parent.name).strip()
        description = metadata.get("description", "").strip()
        estimated_complexity = metadata.get(
            "estimated_complexity", ""
        ).strip()
        raw_accepts_research_mode = metadata.get(
            "accepts_research_mode", "false"
        ).strip().lower()
        if not skill_id or not description or estimated_complexity not in {
            "low",
            "medium",
            "high",
        } or raw_accepts_research_mode not in {"true", "false"}:
            raise ValueError(f"invalid_skill_frontmatter:{path}")
        return SkillCard(
            skill_id=skill_id,
            description=description,
            estimated_complexity=estimated_complexity,
            detail_ref=str(path.resolve()),
            accepts_research_mode=(raw_accepts_research_mode == "true"),
        )

    def _path_is_allowed(self, path: Path) -> bool:
        return any(path.is_relative_to(root) for root in self._allowed_roots)


def _frontmatter(markdown: str) -> dict[str, str]:
    lines = markdown.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}
    metadata: dict[str, str] = {}
    for line in lines[1:]:
        if line.strip() == "---":
            return metadata
        key, separator, value = line.partition(":")
        if separator:
            metadata[key.strip()] = _frontmatter_scalar(value.strip())
    return {}


def _frontmatter_scalar(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        return value[1:-1]
    return value


def _require_callable_arity(
    function: Callable[..., Any],
    count: int,
    issue: str,
    *,
    error_type: type[RuntimeError] = SkillDisclosureLoadError,
) -> None:
    parameters = list(inspect.signature(function).parameters.values())
    if len(parameters) != count or any(
        parameter.kind
        not in {
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        }
        or parameter.default is not inspect.Parameter.empty
        for parameter in parameters
    ):
        raise error_type(issue)
