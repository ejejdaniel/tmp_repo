from __future__ import annotations

from typing import Any, Mapping

from .evaluation import (
    amend_global_evaluation_gate,
    build_evaluation_gate,
    build_frame_evaluation_gate,
    evaluate_agent_gate,
    initial_evaluation_state,
    reconcile_task_contract,
)
from .evaluation.evaluator import evaluation_state_from_closure
from .memory_lifecycle.policy import artifact_dependency_closure_refs
from .memory_lifecycle.prompt import bounded_projection, bounded_text
from .planning import settle_frame_graph
from .reference_links import SOURCE_CONTENT_PREFIXES
from .evaluation.scorer import execute_evaluation_scorers
from ._runtime_support import task_work_skill_cards as _task_work_skill_cards
from .sub_loop_toolkit import human_input_tool


_PENDING_CONTRACT_GRAPH_REBUILD = "contract_graph_rebuild_pending:"


class EvaluationRuntimeMixin:
    """Agent-local evaluation bootstrap, evidence review, and closure."""

    def _bootstrap_or_load_evaluation(
        self,
        *,
        objective: str,
        evaluation_request: str,
    ) -> Mapping[str, Any]:
        self._initialize_or_validate_agent_state(
            objective=objective,
            evaluation_request=evaluation_request,
        )

        self._mount_run_inputs()
        state = self._state.read()
        contract = state["c1"]["task_contract_state"]
        phase = str(contract["phase"])

        if not self._task_formulation_skill_id:
            current_evaluation = state["c1"]["global_evaluation_state"]
            if current_evaluation is not None:
                return self._resume_global_gate(state)
            return self._build_legacy_global_gate(
                objective=objective,
                evaluation_request=evaluation_request,
            )

        if phase == "ready":
            return self._resume_global_gate(state)
        if phase == "contract_reconciliation":
            if str(contract["task_spec_ref"]):
                decision = self._reconcile_task_contract_at_frame_boundary(
                    global_closure=self._current_evaluation_closure(
                        scope="global"
                    )
                )
                if decision["decision"] == "keep_current_contract":
                    current = self._current_evaluation_closure(scope="global")
                    if not bool(current.get("complete")):
                        self._schedule_contract_graph_rebuild(
                            "frame contract was retained while Global "
                            "Evaluation remains incomplete"
                        )
                    return self._resume_global_gate(self._state.read())
                phase = "task_formulation"
            else:
                contract = {
                    "phase": "task_formulation",
                    "task_spec_ref": "",
                    "input_refs": list(contract["input_refs"]),
                }
                self._state.set_task_contract_state(contract)
                phase = "task_formulation"
        if phase == "task_formulation":
            task_spec_ref, input_refs = self._run_task_formulation_skill()
            contract = {
                "phase": "evaluation_build",
                "task_spec_ref": task_spec_ref,
                "input_refs": list(input_refs),
            }
            self._state.set_task_contract_state(contract)
            self._state.add_resolved_artifact_ref(task_spec_ref)
            phase = "evaluation_build"
        if phase != "evaluation_build":
            raise RuntimeError(f"task_contract_phase_unhandled:{phase}")
        return self._build_global_gate_for_task_spec(
            objective=objective,
            evaluation_request=evaluation_request,
        )

    def _initialize_or_validate_agent_state(
        self,
        *,
        objective: str,
        evaluation_request: str,
    ) -> None:
        """Establish immutable run identity without starting bootstrap work."""
        fresh = not self._state.path.exists()
        if fresh:
            preformulated_ref = str(
                getattr(self, "_preformulated_task_spec_ref", "") or ""
            )
            preformulated_inputs = list(
                getattr(self, "_preformulated_task_input_refs", ())
            )
            if preformulated_ref:
                preformulated = self._read_exact_ref(preformulated_ref)
                payload = preformulated.get("machine_payload")
                if (
                    preformulated.get("artifact_kind") != "task_spec"
                    or not isinstance(payload, Mapping)
                ):
                    raise RuntimeError(
                        "preformulated_task_spec_artifact_invalid"
                    )
                if str(payload.get("goal") or "").strip() != objective:
                    raise RuntimeError(
                        "preformulated_task_spec_goal_conflicts_with_c0"
                    )
            self._state.initialize(
                objective=objective,
                evaluation_summary=evaluation_request,
                plan_summary="",
                global_evaluation_state=None,
                frame_evaluation_state=None,
                task_contract_state={
                    "phase": (
                        "evaluation_build"
                        if preformulated_ref
                        else (
                            "task_formulation"
                            if self._task_formulation_skill_id
                            else "ready"
                        )
                    ),
                    "task_spec_ref": preformulated_ref,
                    "input_refs": preformulated_inputs,
                },
                enabled_meta_capabilities=(
                    self._enabled_meta_capabilities
                ),
            )
            self._work.ensure(title=objective, input_refs=self._mission.artifact_refs if self._mission else ())
            if self._mission and self._mission.work_entry_refs:
                self._work.store.import_entries(
                    self._work.ensure(), agent_id=self.agent_id,
                    entry_refs=self._mission.work_entry_refs,
                    authorized_refs=self._mission.work_entry_refs,
                )
        state = self._state.read()
        if state["c0"]["objective"] != objective:
            raise RuntimeError("objective_conflicts_with_persisted_c0")
        if state["c0"]["evaluation_summary"] != evaluation_request:
            raise RuntimeError("evaluation_conflicts_with_persisted_c0")
        if tuple(state["c0"]["enabled_meta_capabilities"]) != tuple(
            self._enabled_meta_capabilities
        ):
            raise RuntimeError(
                "meta_capabilities_conflict_with_persisted_c0"
            )

    def _resume_global_gate(
        self,
        state: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        evaluation_state = state["c1"]["global_evaluation_state"]
        if not isinstance(evaluation_state, Mapping):
            raise RuntimeError("ready_task_contract_requires_global_evaluation")
        gate = self._load_evaluation_gate(
            str(evaluation_state["gate_ref"]),
            expected_scope="global",
        )
        self._events.append(
            "evaluation_gate_resumed",
            {
                "gate_ref": gate["artifact_ref"],
                "evaluation_summary": state["c0"]["evaluation_summary"],
                "task_spec_ref": str(
                    state["c1"]["task_contract_state"]["task_spec_ref"]
                ),
            },
        )
        return gate

    def _build_legacy_global_gate(
        self,
        *,
        objective: str,
        evaluation_request: str,
    ) -> Mapping[str, Any]:
        built = build_evaluation_gate(
            model=self._model,
            events=self._events,
            artifacts=self._artifacts,
            code_artifacts=self._code_artifacts,
            agent_runtime_root=self._event_log_path.parent,
            agent_id=self.agent_id,
            objective=objective,
            evaluation_request=evaluation_request,
            max_rounds=self._max_rounds,
            scope="global",
            mission_packet=(
                self._mission_prompt_projection() if self._mission else None
            ),
            skill_summaries=[
                {
                    "skill_id": card.skill_id,
                    "description": card.description,
                    "estimated_complexity": card.estimated_complexity,
                }
                for card in _task_work_skill_cards(
                    self._skills,
                    getattr(self, "_task_formulation_skill_id", ""),
                )
            ],
        )
        gate = dict(built["gate"])
        global_evaluation_state = initial_evaluation_state(
            str(built["gate_ref"]),
            dict(gate["machine_payload"]),
        )
        self._state.set_global_evaluation_state(global_evaluation_state)
        self._state.set_task_contract_state(
            {"phase": "ready", "task_spec_ref": "", "input_refs": []}
        )
        return gate

    def _run_task_formulation_skill(self) -> tuple[str, tuple[str, ...]]:
        skill_id = self._task_formulation_skill_id
        state = self._state.read()
        contract = state["c1"]["task_contract_state"]
        explicit_inputs = tuple(str(ref) for ref in contract["input_refs"])
        resolved_inputs = tuple(
            dict.fromkeys(
                [
                    *(explicit_inputs or state["c1"]["resolved_artifact_refs"]),
                    *self._answered_human_response_refs(),
                ]
            )
        )
        active_skill = str(state["c1"]["active_skill_id"] or "")
        if active_skill and active_skill != skill_id:
            raise RuntimeError(
                "task_formulation_conflicts_with_active_skill:"
                f"{active_skill}"
            )
        if not active_skill:
            self._state.start_skill(
                skill_id,
                resolved_artifact_refs=resolved_inputs,
            )
        (
            _final_text,
            published_refs,
            completion_ref,
            workflow_status,
            workflow_error,
            _workflow_result,
        ) = self._run_active_skill_workflow(skill_id, round_number=0)
        if workflow_error or workflow_status not in {"complete", "completed"}:
            raise RuntimeError(
                "task_formulation_failed:"
                f"{workflow_error or workflow_status or 'unknown'}"
            )
        candidates = list(
            dict.fromkeys([*published_refs, completion_ref])
        )
        task_spec_refs = [
            ref
            for ref in candidates
            if ref
            and self._read_exact_ref(ref).get("artifact_kind") == "task_spec"
        ]
        if len(task_spec_refs) != 1:
            raise RuntimeError(
                "task_formulation_requires_one_task_spec:"
                f"actual={len(task_spec_refs)}"
            )
        task_spec_ref = task_spec_refs[0]
        self._release_skill_context()
        self._events.append(
            "task_formulation_completed",
            {
                "skill_id": skill_id,
                "task_spec_ref": task_spec_ref,
                "input_refs": list(resolved_inputs),
            },
        )
        return task_spec_ref, resolved_inputs

    def _build_global_gate_for_task_spec(
        self,
        *,
        objective: str,
        evaluation_request: str,
    ) -> Mapping[str, Any]:
        state = self._state.read()
        contract = state["c1"]["task_contract_state"]
        task_spec_ref = str(contract["task_spec_ref"])
        task_spec_artifact = self._read_exact_ref(task_spec_ref)
        task_spec = task_spec_artifact.get("machine_payload")
        if not isinstance(task_spec, Mapping):
            raise RuntimeError("task_spec_machine_payload_invalid")
        previous_evaluation = state["c1"]["global_evaluation_state"]
        previous_gate_ref = (
            str(previous_evaluation["gate_ref"])
            if isinstance(previous_evaluation, Mapping)
            else ""
        )
        human_scopes = (
            ("evaluation_build",) if self._human_in_loop_enabled else ()
        )
        build_human_tool = (
            human_input_tool(
                scopes=human_scopes,
                visible_context_refs=tuple(
                    dict.fromkeys(
                        [
                            *self._visible_human_context_refs(),
                            task_spec_ref,
                        ]
                    )
                ),
            )
            if human_scopes
            else None
        )
        built = build_evaluation_gate(
            model=self._model,
            events=self._events,
            artifacts=self._artifacts,
            code_artifacts=self._code_artifacts,
            agent_runtime_root=self._event_log_path.parent,
            agent_id=self.agent_id,
            objective=objective,
            evaluation_request=evaluation_request,
            max_rounds=self._max_rounds,
            scope="global",
            mission_packet=(
                self._mission_prompt_projection() if self._mission else None
            ),
            skill_summaries=[
                {
                    "skill_id": card.skill_id,
                    "description": card.description,
                    "estimated_complexity": card.estimated_complexity,
                }
                for card in _task_work_skill_cards(
                    self._skills,
                    getattr(self, "_task_formulation_skill_id", ""),
                )
            ],
            task_spec=task_spec,
            task_spec_ref=task_spec_ref,
            previous_gate_ref=previous_gate_ref,
            human_input_tool=build_human_tool,
            request_human_input=(
                lambda arguments: self._request_human_input(
                    arguments,
                    allowed_scopes=human_scopes,
                    extra_context_refs=(task_spec_ref,),
                )
                if build_human_tool is not None
                else None
            ),
        )
        gate = dict(built["gate"])
        evaluation_state = initial_evaluation_state(
            str(built["gate_ref"]),
            dict(gate["machine_payload"]),
        )
        self._state.set_frame_evaluation_state(None)
        self._state.activate_task_contract(
            task_spec_ref=task_spec_ref,
            input_refs=contract["input_refs"],
            global_evaluation_state=evaluation_state,
        )
        self._mark_human_answer_consumed(consumer="evaluation_build")
        return gate

    def _reconcile_task_contract_at_frame_boundary(
        self,
        *,
        global_closure: Mapping[str, Any],
    ) -> dict[str, Any]:
        state = self._state.read()
        contract = state["c1"]["task_contract_state"]
        task_spec_ref = str(contract["task_spec_ref"])
        if not self._task_formulation_skill_id or not task_spec_ref:
            return {
                "decision": "keep_current_contract",
                "source_refs": [],
                "reason": "No task-formulation profile is active.",
            }
        if contract["phase"] != "contract_reconciliation":
            self._state.set_task_contract_state(
                {
                    "phase": "contract_reconciliation",
                    "task_spec_ref": task_spec_ref,
                    "input_refs": list(contract["input_refs"]),
                }
            )
            state = self._state.read()
        task_spec_artifact = self._read_exact_ref(task_spec_ref)
        task_spec = task_spec_artifact.get("machine_payload")
        if not isinstance(task_spec, Mapping):
            raise RuntimeError("task_spec_machine_payload_invalid")
        source_refs = list(self._frame_contract_source_refs(state))
        for response_ref in self._answered_human_response_refs():
            if response_ref not in source_refs:
                source_refs.append(response_ref)
        source_artifacts = [
            self._task_contract_source_projection(
                self._read_exact_ref(ref)
            )
            for ref in source_refs
        ]
        human_scopes = (
            ("task_formulation",)
            if self._human_in_loop_enabled
            else ()
        )
        reconciliation_human_tool = (
            human_input_tool(
                scopes=human_scopes,
                visible_context_refs=tuple(
                    dict.fromkeys(
                        [
                            *self._visible_human_context_refs(),
                            task_spec_ref,
                            *source_refs,
                        ]
                    )
                ),
            )
            if human_scopes
            else None
        )
        self._memory.prepare_for_model_call(
            call_site="reconcile task contract at frame boundary"
        )
        decision = reconcile_task_contract(
            model=self._model,
            events=self._events,
            task_spec_ref=task_spec_ref,
            task_spec=task_spec,
            global_evaluation=global_closure,
            accepted_sources=source_artifacts,
            allowed_source_refs=source_refs,
            human_input_tool=reconciliation_human_tool,
            request_human_input=(
                lambda arguments: self._request_human_input(
                    arguments,
                    allowed_scopes=human_scopes,
                    extra_context_refs=(task_spec_ref,),
                )
                if reconciliation_human_tool is not None
                else None
            ),
        )
        if decision["decision"] == "keep_current_contract":
            self._state.set_task_contract_state(
                {
                    "phase": "ready",
                    "task_spec_ref": task_spec_ref,
                    "input_refs": list(contract["input_refs"]),
                }
            )
        else:
            selected_refs = list(decision["source_refs"])
            self._state.set_task_contract_state(
                {
                    "phase": "task_formulation",
                    "task_spec_ref": task_spec_ref,
                    "input_refs": selected_refs,
                }
            )
            self._schedule_contract_graph_rebuild(
                "task contract was reformulated from newly accepted exact "
                "sources: " + str(decision["reason"])
            )
        self._mark_human_answer_consumed(
            consumer="task_contract_reconciliation"
        )
        return dict(decision)

    def _frame_contract_source_refs(
        self,
        state: Mapping[str, Any],
    ) -> tuple[str, ...]:
        graph = state["c1"]["plan_graph"]
        roots = [
            str(ref)
            for node in graph.get("nodes") or ()
            if isinstance(node, Mapping) and node.get("status") == "completed"
            for ref in node.get("completion_refs") or ()
            if str(ref).startswith("artifact:")
        ]
        closure = artifact_dependency_closure_refs(
            self._artifacts.list(),
            read_artifact=self._artifacts.read,
            explicit_refs=roots,
        )
        return tuple(
            ref for ref in closure if str(ref).startswith("artifact:")
        )

    @staticmethod
    def _task_contract_source_projection(
        artifact: Mapping[str, Any],
    ) -> dict[str, Any]:
        return {
            "artifact_ref": str(artifact.get("artifact_ref") or ""),
            "artifact_kind": str(artifact.get("artifact_kind") or ""),
            "title": str(artifact.get("title") or ""),
            "summary": bounded_text(str(artifact.get("summary") or ""), 2_000),
            "markdown": bounded_text(str(artifact.get("markdown") or ""), 6_000),
            "machine_payload": bounded_projection(
                artifact.get("machine_payload"), max_depth=6, max_items=64
            ),
        }

    def _schedule_contract_graph_rebuild(self, reason: str) -> None:
        self._state.set_issue(
            _PENDING_CONTRACT_GRAPH_REBUILD + bounded_text(reason, 1_600)
        )

    def _resume_pending_contract_graph_rebuild(
        self,
        *,
        round_number: int,
    ) -> bool:
        state = self._state.read()
        issue = str(state["c1"]["current_issue"])
        if not issue.startswith(_PENDING_CONTRACT_GRAPH_REBUILD):
            return False
        if state["c1"]["task_contract_state"]["phase"] != "ready":
            return False
        reason = issue[len(_PENDING_CONTRACT_GRAPH_REBUILD) :].strip()
        graph = state["c1"]["plan_graph"]
        if graph["nodes"]:
            self._rebuild_current_graph(
                trigger="task_contract_frame_boundary",
                reason=reason,
                round_number=round_number,
                revision_scope="graph",
            )
        self._state.set_issue("")
        return True

    def _load_evaluation_gate(
        self,
        gate_ref: str,
        *,
        expected_scope: str | None = None,
    ) -> dict[str, Any]:
        gate = self._artifacts.read(str(gate_ref))
        if gate.get("artifact_kind") != "agent_evaluation_gate":
            raise RuntimeError(
                f"agent_evaluation_gate_kind_invalid:{gate_ref}:"
                f"{gate.get('artifact_kind')}"
            )
        payload = gate.get("machine_payload")
        if not isinstance(payload, Mapping):
            raise RuntimeError("agent_evaluation_gate_payload_invalid")
        scope = str(payload.get("scope") or "").strip()
        if not scope:
            # Persisted v10 gates predate the explicit scope field and migrate
            # only as Global authorities. New Frame gates never use this path.
            scope = "global"
        if scope not in {"global", "frame"}:
            raise RuntimeError("agent_evaluation_gate_scope_invalid")
        if expected_scope is not None and scope != expected_scope:
            raise RuntimeError(
                "agent_evaluation_gate_scope_mismatch:"
                f"expected={expected_scope}:actual={scope}"
            )
        return gate

    def _replace_frame_evaluation_for_graph(self) -> Mapping[str, Any]:
        state = self._state.read()
        graph = state["c1"]["plan_graph"]
        if not graph["nodes"]:
            self._state.set_frame_evaluation_state(None)
            raise RuntimeError("frame_evaluation_requires_plan_graph")
        global_state = state["c1"]["global_evaluation_state"]
        built = build_frame_evaluation_gate(
            events=self._events,
            artifacts=self._artifacts,
            agent_runtime_root=self._event_log_path.parent,
            agent_id=self.agent_id,
            plan_graph=graph,
            max_rounds=self._max_rounds,
            global_gate_ref=str(global_state["gate_ref"]),
        )
        frame_state = initial_evaluation_state(
            str(built["gate_ref"]),
            dict(built["gate"]["machine_payload"]),
        )
        self._state.set_frame_evaluation_state(frame_state)
        return dict(built["gate"])

    def _ensure_frame_evaluation(self) -> Mapping[str, Any]:
        state = self._state.read()
        frame_state = state["c1"]["frame_evaluation_state"]
        if frame_state is None:
            return self._replace_frame_evaluation_for_graph()
        return self._load_evaluation_gate(
            str(frame_state["gate_ref"]),
            expected_scope="frame",
        )

    def _apply_confirmed_global_evaluation_amendment(
        self,
        *,
        round_number: int,
    ) -> Mapping[str, Any]:
        requirement = self._confirmed_global_evaluation_requirement()
        if requirement is None:
            raise RuntimeError(
                "confirmed_global_evaluation_amendment_required"
            )
        interaction = self._sub_loop_toolkit.current()
        if interaction is None or interaction["status"] != "answered":
            raise RuntimeError("global_evaluation_confirmation_missing")
        response_ref = str(interaction["response_ref"])
        self._read_exact_ref(response_ref)
        state = self._state.read()
        previous_state = state["c1"]["global_evaluation_state"]
        if bool(previous_state["terminal"]):
            raise RuntimeError(
                "global_evaluation_amendment_after_terminal_forbidden"
            )
        previous_gate = self._load_evaluation_gate(
            str(previous_state["gate_ref"]),
            expected_scope="global",
        )
        previous_criterion_ids = {
            str(item.get("criterion_id") or "").strip()
            for item in previous_gate["machine_payload"]["success_criteria"]
        }
        built = amend_global_evaluation_gate(
            events=self._events,
            artifacts=self._artifacts,
            agent_runtime_root=self._event_log_path.parent,
            agent_id=self.agent_id,
            current_gate=previous_gate,
            confirmed_requirement=requirement,
            confirmation_response_ref=response_ref,
        )
        next_gate = dict(built["gate"])
        next_criterion_ids = {
            str(item.get("criterion_id") or "").strip()
            for item in next_gate["machine_payload"]["success_criteria"]
        }
        added_criterion_ids = sorted(
            next_criterion_ids - previous_criterion_ids
        )
        next_state = _carry_evaluation_state_to_revised_gate(
            previous_state=previous_state,
            gate_ref=str(built["gate_ref"]),
            gate_payload=dict(next_gate["machine_payload"]),
        )
        self._state.set_global_evaluation_state(next_state)

        current = self._state.read()
        active_skill_id = str(current["c1"]["active_skill_id"] or "")
        if active_skill_id:
            self._release_skill_context()
            current = self._state.read()
        graph = current["c1"]["plan_graph"]
        if graph["nodes"]:
            self._state.set_plan_graph(settle_frame_graph(graph))
            self._rebuild_current_graph(
                trigger="human_confirmed_global_evaluation_amendment",
                reason=(
                    "Human confirmed a new Global Evaluation requirement; "
                    "preserve accepted outcomes and build a new Frame that "
                    "addresses the amended authority."
                ),
                round_number=round_number,
                revision_scope="graph",
                priority_criterion_ids=added_criterion_ids,
            )
        else:
            self._mark_human_answer_consumed(
                consumer="global_evaluation_amendment"
            )
        return next_gate

    def _evaluate_agent_closure(
        self,
        *,
        round_number: int,
        scope: str = "global",
    ) -> dict[str, Any]:
        if scope not in {"global", "frame"}:
            raise ValueError("evaluation_scope_invalid")
        self._memory.prepare_for_model_call(
            call_site=f"evaluate agent-local {scope} closure"
        )
        state = self._state.read()
        state_key = f"{scope}_evaluation_state"
        evaluation_state = state["c1"][state_key]
        if evaluation_state is None:
            raise RuntimeError(f"{scope}_evaluation_state_unavailable")
        gate = self._load_evaluation_gate(
            str(evaluation_state["gate_ref"]),
            expected_scope=scope,
        )
        evaluator_skill = self._read_agent_local_evaluator(gate)
        evidence_index = self._evaluation_evidence_index(scope=scope)
        evidence_index.extend(
            execute_evaluation_scorers(
                gate=gate,
                evidence_index=evidence_index,
                read_ref=self._read_exact_ref,
                code_artifacts=self._code_artifacts,
                observations=self._observations,
                run_root=self._event_log_path.parent,
                events=self._events,
            )
        )
        fresh_evidence_by_criterion = (
            _fresh_graph_evidence_by_criterion(
                evaluation_state=evaluation_state,
                plan_graph=state["c1"]["plan_graph"],
            )
            if scope == "global"
            else {}
        )
        human_scopes = (
            ("evaluation_judgment",)
            if self._human_in_loop_enabled
            else ()
        )
        evaluation_human_tool = (
            human_input_tool(
                scopes=human_scopes,
                visible_context_refs=tuple(
                    dict.fromkeys(
                        [
                            *self._visible_human_context_refs(),
                            str(gate["artifact_ref"]),
                        ]
                    )
                ),
            )
            if human_scopes
            else None
        )
        closure = evaluate_agent_gate(
            model=self._model,
            events=self._events,
            gate=gate,
            evaluator_skill=evaluator_skill,
            evidence_index=evidence_index,
            read_ref=self._read_evaluation_ref,
            previous_state=evaluation_state,
            round_number=round_number,
            fresh_evidence_by_criterion=fresh_evidence_by_criterion,
            human_input_tool=evaluation_human_tool,
            request_human_input=(
                lambda arguments: self._request_human_input(
                    arguments,
                    allowed_scopes=human_scopes,
                    extra_context_refs=(str(gate["artifact_ref"]),),
                )
                if evaluation_human_tool is not None
                else None
            ),
        )
        next_state = evaluation_state_from_closure(closure)
        if scope == "global":
            self._state.set_global_evaluation_state(next_state)
        else:
            self._state.set_frame_evaluation_state(next_state)
        self._mark_human_answer_consumed(
            consumer=f"{scope}_evaluation_judgment"
        )
        if scope == "frame" and bool(closure.get("complete")):
            previous_plan = self._state.read()["c1"]["plan_graph"]
            settled_plan = settle_frame_graph(previous_plan)
            if settled_plan != previous_plan:
                self._state.set_plan_graph(settled_plan)
                self._events.append(
                    "frame_plan_settled",
                    {
                        "round": round_number,
                        "gate_ref": closure["gate_ref"],
                        "success": bool(closure.get("success")),
                        "triggered_stop_id": str(
                            closure.get("triggered_stop_id") or ""
                        ),
                        "previous_plan_graph": previous_plan,
                        "settled_plan_graph": settled_plan,
                    },
                )
        self._events.append(
            "closure_evaluation",
            {
                "round": round_number,
                "scope": scope,
                "result": closure,
            },
        )
        return dict(closure)

    def _read_evaluation_ref(
        self, ref: str, *, path: str | None = None,
        line_offset: int = 0, line_limit: int = 200,
    ) -> dict[str, Any]:
        """Resolve authorized records, scoped source content and immutable snapshot pages."""
        normalized = str(ref).strip()
        if normalized.startswith("reference:"):
            if path is not None:
                raise ValueError("reference_path_override_not_allowed")
            return self._reference_resolver().read(
                normalized, line_offset=line_offset, line_limit=line_limit,
            )
        if normalized.startswith(SOURCE_CONTENT_PREFIXES):
            if path is not None:
                raise ValueError("reference_path_requires_snapshot")
            resolver = self._reference_resolver()
            link = resolver.create({"ref": normalized})["reference_link"]
            return resolver.read(link, line_offset=line_offset, line_limit=line_limit)
        if path is not None:
            self._read_exact_ref(normalized)
            if self._development_projects is None:
                raise RuntimeError("development_project_store_unavailable")
            return self._development_projects.read_snapshot_file(
                normalized, path, line_offset=line_offset, line_limit=line_limit,
            )
        if normalized.startswith("workspace:capability_registry/pending/"):
            return self._skills.pending_candidate_snapshot(normalized)
        return self._read_exact_ref(normalized)

    def _current_evaluation_closure(
        self,
        *,
        scope: str = "global",
    ) -> dict[str, Any]:
        if scope not in {"global", "frame"}:
            raise ValueError("evaluation_scope_invalid")
        state = self._state.read()["c1"][f"{scope}_evaluation_state"]
        if state is None:
            raise RuntimeError(f"{scope}_evaluation_state_unavailable")
        issues = [
            f"{item['criterion_id']}:{item['status']}:{item['reason']}"
            for item in state["criterion_results"]
            if item["status"] != "met"
        ]
        return {
            "complete": bool(state["terminal"]),
            "success": bool(state["success"]),
            "gate_ref": str(state["gate_ref"]),
            "criterion_results": [
                dict(item) for item in state["criterion_results"]
            ],
            "triggered_stop_id": str(state["triggered_stop_id"]),
            "issues": issues,
            "scope": scope,
        }

    def _current_evaluation_closure_or_bootstrap(self) -> dict[str, Any]:
        if not self._state.path.exists():
            phase = "task_formulation"
            evaluation_state = None
        else:
            state = self._state.read()
            phase = str(state["c1"]["task_contract_state"]["phase"])
            evaluation_state = state["c1"]["global_evaluation_state"]
        if isinstance(evaluation_state, Mapping):
            return self._current_evaluation_closure(scope="global")
        return {
            "complete": False,
            "success": False,
            "gate_ref": "",
            "criterion_results": [],
            "triggered_stop_id": "",
            "issues": [f"task_contract_phase:{phase}"],
            "scope": "global",
        }

    def _read_agent_local_evaluator(
        self,
        gate: Mapping[str, Any],
    ) -> str:
        payload = gate.get("machine_payload")
        if not isinstance(payload, Mapping):
            raise RuntimeError("agent_evaluation_gate_payload_invalid")
        evaluator_ref = str(payload.get("evaluator_skill_ref") or "")
        prefix = "workspace:"
        if not evaluator_ref.startswith(prefix):
            raise RuntimeError("agent_evaluator_skill_ref_invalid")
        runtime_root = self._event_log_path.parent.resolve()
        path = (runtime_root / evaluator_ref[len(prefix) :]).resolve()
        if not path.is_relative_to(runtime_root) or not path.is_file():
            raise RuntimeError(
                f"agent_evaluator_skill_unavailable:{evaluator_ref}"
            )
        return path.read_text(encoding="utf-8")

    def _evaluation_evidence_index(
        self,
        *,
        scope: str = "global",
    ) -> list[dict[str, Any]]:
        state = self._state.read()
        evaluation_state = state["c1"][f"{scope}_evaluation_state"]
        if evaluation_state is None:
            raise RuntimeError(f"{scope}_evaluation_state_unavailable")
        gate_ref = str(evaluation_state["gate_ref"])
        graph = state["c1"]["plan_graph"]
        completion_refs = [
            str(ref)
            for node in graph["nodes"]
            for ref in node["completion_refs"]
            if str(ref)
        ]

        # Mounted inputs and node-local intermediates stay readable for work, but
        # global closure starts only from node-approved completion evidence.
        authorized_refs = list(completion_refs)

        index: list[dict[str, Any]] = []
        seen: set[str] = set()
        pending = list(dict.fromkeys(authorized_refs))
        while pending:
            ref = str(pending.pop(0))
            if not ref or ref == gate_ref or ref in seen:
                continue
            try:
                stored = self._read_exact_ref(ref)
            except (KeyError, OSError, PermissionError, ValueError):
                continue
            index.append(_formal_evidence_receipt(stored))
            seen.add(ref)
            for dependency_ref in stored.get("depends_on") or ():
                dependency_ref = str(dependency_ref).strip()
                if dependency_ref and dependency_ref not in seen:
                    pending.append(dependency_ref)
        return index


def _fresh_graph_evidence_by_criterion(
    *,
    evaluation_state: Mapping[str, Any],
    plan_graph: Mapping[str, Any],
) -> dict[str, list[str]]:
    """Find new completion refs that directly address unresolved criteria."""
    unresolved_results = {
        str(item.get("criterion_id") or ""): item
        for item in evaluation_state.get("criterion_results") or ()
        if isinstance(item, Mapping) and str(item.get("status") or "") != "met"
    }
    fresh: dict[str, list[str]] = {}
    for node in plan_graph.get("nodes") or ():
        if not isinstance(node, Mapping) or str(node.get("status") or "") != "completed":
            continue
        completion_refs = [
            str(ref).strip()
            for ref in node.get("completion_refs") or ()
            if str(ref).strip()
        ]
        if not completion_refs:
            continue
        for raw_criterion_id in node.get("addresses_criteria") or ():
            criterion_id = str(raw_criterion_id).strip()
            previous = unresolved_results.get(criterion_id)
            if previous is None:
                continue
            previous_refs = {
                str(ref).strip()
                for ref in previous.get("evidence_refs") or ()
                if str(ref).strip()
            }
            new_refs = [ref for ref in completion_refs if ref not in previous_refs]
            if new_refs:
                fresh.setdefault(criterion_id, []).extend(new_refs)
    return {
        criterion_id: list(dict.fromkeys(refs))
        for criterion_id, refs in fresh.items()
    }


def _carry_evaluation_state_to_revised_gate(
    *,
    previous_state: Mapping[str, Any],
    gate_ref: str,
    gate_payload: Mapping[str, Any],
) -> dict[str, Any]:
    carried = initial_evaluation_state(gate_ref, gate_payload)
    previous_by_id = {
        str(item.get("criterion_id") or ""): dict(item)
        for item in previous_state.get("criterion_results") or ()
        if isinstance(item, Mapping)
    }
    for item in carried["criterion_results"]:
        previous = previous_by_id.get(str(item["criterion_id"]))
        if previous is not None:
            item.update(previous)
    carried["success"] = all(
        item["status"] == "met" for item in carried["criterion_results"]
    )
    carried["terminal"] = bool(carried["success"])
    carried["triggered_stop_id"] = ""
    return carried


def _formal_evidence_receipt(stored: Mapping[str, Any]) -> dict[str, Any]:
    ref = str(
        stored.get("artifact_ref")
        or stored.get("code_artifact_ref")
        or stored.get("observation_ref")
        or ""
    )
    return {
        "artifact_ref": ref,
        "artifact_kind": str(stored.get("artifact_kind") or ""),
        "title": str(stored.get("title") or stored.get("purpose") or ""),
        "summary": str(stored.get("summary") or ""),
        "depends_on": list(stored.get("depends_on") or ()),
    }
