from __future__ import annotations

import copy
from typing import Any, Mapping, Sequence

from .memory_lifecycle.policy import (
    PromptSource,
    artifact_dependency_closure_refs,
)
from .memory_lifecycle.prompt import (
    bounded_projection,
    bounded_text,
    tool_result_prompt_projection,
)
from .planning import active_work_unit
from .planning.node_loop import NodeLoopStepCallLimitError
from .skill_workflows import SkillWorkflowRuntime
from .sub_loop_toolkit import HumanInteractionPause


def _active_loop_step_projection(
    raw_loop_state: Any,
    *,
    skill_id: str,
) -> dict[str, Any] | None:
    """Project the current persisted C1 step into one private skill payload."""
    if not isinstance(raw_loop_state, Mapping):
        return None
    steps = raw_loop_state.get("steps")
    index = raw_loop_state.get("next_step_index")
    if (
        not isinstance(steps, Sequence)
        or isinstance(steps, (str, bytes))
        or not isinstance(index, int)
        or not 0 <= index < len(steps)
    ):
        return None
    step = steps[index]
    if not isinstance(step, Mapping):
        return None
    projected = {
        "skill_id": str(step.get("skill_id") or ""),
        "purpose": str(step.get("purpose") or ""),
        "cost": step.get("cost"),
        "input_refs": [str(ref) for ref in step.get("input_refs") or ()],
        "research_mode": copy.deepcopy(step.get("research_mode")),
    }
    if projected["skill_id"] != skill_id:
        raise RuntimeError(
            "skill_workflow_active_loop_step_mismatch:"
            f"expected={skill_id}:actual={projected['skill_id']}"
        )
    return projected


class SkillWorkflowRuntimeMixin:
    """Host project-local fixed workflows inside one selected skill."""

    def _run_active_skill_workflow(
        self,
        skill_id: str,
        *,
        round_number: int,
    ) -> tuple[
        str,
        tuple[str, ...],
        str,
        str,
        str,
        Mapping[str, Any],
    ]:
        state = self._state.read()
        resolved_refs = tuple(state["c1"]["resolved_artifact_refs"])
        active_node = active_work_unit(state["c1"]["plan_graph"])
        attempt_refs = tuple(
            str(ref)
            for ref in (
                active_node.get("attempt_refs") if active_node is not None else ()
            )
            if str(ref).startswith("artifact:")
        )
        allowed_artifact_refs = artifact_dependency_closure_refs(
            self._artifacts.list(),
            read_artifact=self._artifacts.read,
            explicit_refs=tuple(dict.fromkeys((*resolved_refs, *attempt_refs))),
        )
        resolved_inputs = [
            copy.deepcopy(self._read_exact_ref(ref)) for ref in resolved_refs
        ]
        payload = {
            "skill_id": skill_id,
            "objective": state["c0"]["objective"],
            "task_request": state["c0"]["objective"],
            "evaluation_summary": state["c0"]["evaluation_summary"],
            "plan_summary": state["c1"]["plan_summary"],
            "current_issue": state["c1"]["current_issue"],
            "task_contract_state": copy.deepcopy(
                state["c1"]["task_contract_state"]
            ),
            "is_child_agent": self._mission is not None,
            "task_authority_mode": self._task_authority_mode,
            "active_work_unit": copy.deepcopy(active_node),
            "resolved_inputs": resolved_inputs,
        }
        active_loop_step = _active_loop_step_projection(
            state["c1"].get("node_loop_state"),
            skill_id=skill_id,
        )
        if active_loop_step is not None:
            payload["active_loop_step"] = active_loop_step
        payload["work_context"] = self._current_work_projection(consumer=skill_id)
        self._events.append(
            "skill_workflow_started",
            {
                "round": round_number,
                "skill_id": skill_id,
                "payload": payload,
            },
        )
        call_index = 0
        knowledge_summary = self._work.latest_skill_note(skill_id)

        def write_knowledge_summary(summary: str) -> None:
            nonlocal knowledge_summary
            knowledge_summary = summary
            sequence = self._events.append("skill_work_note", {
                "skill_id": skill_id, "round": round_number, "markdown": summary,
            })
            self._work.record_note(summary, event_id=f"{self.agent_id}:{sequence}:workflow-note:{skill_id}",
                                   source_refs=resolved_refs)

        def call_tool(name: str, arguments: Mapping[str, Any]) -> Any:
            nonlocal call_index
            call_index += 1
            call_id = f"workflow-{skill_id}-{round_number}-{call_index}"
            return self._execute_workflow_tool(
                name,
                arguments,
                call_id=call_id,
                round_number=round_number,
            )

        def before_model_call(purpose: str) -> None:
            self._reserve_active_loop_step_model_call(purpose=purpose)
            self._memory.prepare_for_model_call(call_site=purpose)

        runtime = SkillWorkflowRuntime(
            skill_id=skill_id,
            model=self._model,
            events=self._events,
            round_number=round_number,
            allowed_artifact_refs=allowed_artifact_refs,
            call_tool=call_tool,
            available_routes=self._routes.visible(skill_id),
            describe_execution_capability=self._skills.describe_execution_capability,
            read_stored_artifact=self._read_exact_ref,
            read_knowledge_summary=lambda: knowledge_summary,
            write_knowledge_summary=write_knowledge_summary,
            before_model_call=before_model_call,
            prepare_inspection_prompt=self._memory.prepare_inspection_prompt,
            record_model_prompt=lambda purpose, messages, tools: (
                self._memory.record_prompt_projection(
                    call_site=purpose,
                    messages=messages,
                    tools=tools,
                    sources=(
                        PromptSource(
                            "instruction",
                            "skill_stage_instruction",
                            messages[0] if messages else {},
                        ),
                        PromptSource(
                            "C5",
                            "skill_stage_working_context",
                            list(messages[1:]),
                        ),
                        PromptSource(
                            "tool_schema",
                            "skill_stage_result_contract",
                            list(tools),
                        ),
                    ),
                    budget_tier="full",
                )
            ),
        )
        try:
            result = self._skills.workflow(skill_id)(
                copy.deepcopy(payload),
                runtime,
            )
            if not isinstance(result, Mapping):
                raise TypeError("skill_workflow_result_must_be_object")
            runtime.ensure_complete()
            normalized = copy.deepcopy(dict(result))
            final_text = str(
                normalized.get("summary")
                or normalized.get("reason")
                or normalized.get("status")
                or "skill-local workflow completed"
            ).strip()
            workflow_status = str(normalized.get("status") or "").strip()
            completion_ref = str(normalized.get("artifact_ref") or "").strip()
            if completion_ref:
                allowed_completion_refs = {
                    *resolved_refs,
                    *runtime.published_refs,
                }
                if completion_ref not in allowed_completion_refs:
                    raise ValueError(
                        "skill_workflow_completion_ref_not_visible:"
                        f"{completion_ref}"
                    )
                self._read_exact_ref(completion_ref)
            self._events.append(
                "skill_workflow_completed",
                {
                    "round": round_number,
                    "skill_id": skill_id,
                    "result": normalized,
                    "artifact_refs": list(runtime.published_refs),
                },
            )
            self._mark_human_answer_consumed(
                consumer=f"skill_workflow:{skill_id}"
            )
            return (
                final_text,
                runtime.published_refs,
                completion_ref,
                workflow_status,
                "",
                normalized,
            )
        except (HumanInteractionPause, NodeLoopStepCallLimitError):
            raise
        except Exception as exc:
            reason = f"{type(exc).__name__}: {exc}"
            self._events.append(
                "skill_workflow_failed",
                {
                    "round": round_number,
                    "skill_id": skill_id,
                    "reason": reason,
                    "artifact_refs": list(runtime.published_refs),
                },
            )
            return (
                reason,
                runtime.published_refs,
                "",
                "failed",
                reason,
                {"status": "failed", "reason": reason},
            )

    def _skill_workflow_failure_issue(self, skill_id: str, reason: str) -> str:
        """Render recent same-route failure evidence for the next decision."""
        failure_count = 0
        for event in reversed(self._events.read()):
            event_type = str(event.get("event_type") or "")
            if event_type == "plan_progress_applied":
                break
            if event_type == "skill_workflow_completed":
                break
            if event_type != "skill_workflow_failed":
                continue
            failed_skill_id = str(event.get("skill_id") or "")
            if failed_skill_id != skill_id:
                break
            failure_count += 1
        return bounded_text(
            f"skill_workflow_failed:{skill_id}:"
            f"consecutive_failed_attempts={max(1, failure_count)}:"
            f"latest_reason={reason}",
            2_000,
        )

    def _skill_workflow_terminal_gap_issue(
        self,
        skill_id: str,
        *,
        workflow_status: str,
        reason: str,
        artifact_refs: tuple[str, ...],
        base_issue: str,
    ) -> str:
        """Expose repeated terminal gaps without choosing a scientific route."""
        gap_count = 0
        for event in reversed(self._events.read()):
            event_type = str(event.get("event_type") or "")
            if event_type != "skill_workflow_completed":
                continue
            if str(event.get("skill_id") or "") != skill_id:
                continue
            result = event.get("result")
            if not isinstance(result, Mapping):
                continue
            status = str(result.get("status") or "").strip().lower()
            if status in {"bounded_gap", "blocked"}:
                gap_count += 1

        parts = [
            f"skill_workflow_terminal_gap:{skill_id}",
            f"status={workflow_status}",
            f"gap_attempts_in_current_plan={max(1, gap_count)}",
            "published_artifact_refs="
            + (", ".join(artifact_refs) if artifact_refs else "none"),
            f"latest_reason={reason}",
        ]
        if gap_count >= 1 and not artifact_refs:
            parts.append(
                "The selected skill has returned a terminal gap without "
                "publishing new evidence. Another unchanged invocation is no "
                "progress. Compare other currently "
                "eligible graph work. If no existing path applies, execution "
                "must stop because graph replacement is unavailable."
            )
        parts.append(base_issue)
        return bounded_text("\n".join(parts), 2_000)

    def _repeated_terminal_gap_load_issue(
        self,
        skill_id: str,
        *,
        invocation_refs: Sequence[str] = (),
    ) -> str:
        """Reject the next unchanged route attempt until new evidence exists."""
        events = self._events.read()
        current_revision_events = list(events)

        matching_gaps: list[Mapping[str, Any]] = []
        for event in current_revision_events:
            if str(event.get("event_type") or "") != "skill_workflow_completed":
                continue
            if str(event.get("skill_id") or "") != skill_id:
                continue
            result = event.get("result")
            if not isinstance(result, Mapping):
                continue
            status = str(result.get("status") or "").strip().lower()
            if status in {"bounded_gap", "blocked"}:
                matching_gaps.append(event)
        if not matching_gaps:
            return ""

        latest_sequence = int(matching_gaps[-1].get("event_sequence") or 0)
        previous_refs = _latest_skill_workflow_input_refs(
            current_revision_events,
            skill_id=skill_id,
            before_sequence=latest_sequence,
        )
        current_refs = frozenset(
            str(ref).strip() for ref in invocation_refs if str(ref).strip()
        )
        if previous_refs is not None and current_refs != frozenset(previous_refs):
            return ""
        for event in current_revision_events:
            if int(event.get("event_sequence") or 0) <= latest_sequence:
                continue
            if _event_adds_formal_evidence(event):
                return ""

        latest_result = matching_gaps[-1].get("result")
        latest_reason = ""
        if isinstance(latest_result, Mapping):
            latest_reason = str(
                latest_result.get("reason")
                or latest_result.get("summary")
                or latest_result.get("status")
                or ""
            ).strip()
        return bounded_text(
            f"repeated_terminal_gap_without_new_evidence:{skill_id}:"
            f"gap_attempts_in_current_plan={len(matching_gaps)}:"
            "the same skill cannot be loaded again until accepted formal "
            "evidence changes its inputs, another eligible graph path produces "
            "new accepted evidence. Otherwise graph execution must stop. "
            f"latest_reason={latest_reason}",
            2_000,
        )

    def _execute_workflow_tool(
        self,
        name: str,
        arguments: Mapping[str, Any],
        *,
        call_id: str,
        round_number: int,
    ) -> Any:
        work_before = self._work.ensure()
        inputs = tuple(self._state.read()["c1"]["resolved_artifact_refs"])
        try:
            raw_result = self._dispatch(
                name,
                arguments,
                round_number=round_number,
            )
            error = ""
        except HumanInteractionPause:
            raise
        except Exception as exc:
            raw_result = {"status": "tool_error", "reason": str(exc)}
            error = str(exc)
        receipt_projection = bounded_projection(raw_result)
        prompt_projection = tool_result_prompt_projection(raw_result)
        sequence = self._events.append(
            "tool_result",
            {"round": round_number, "call_id": call_id, "tool": name,
             "executed_arguments": dict(arguments), "raw_result": raw_result,
             "prompt_projection": prompt_projection, "source": "skill_workflow"},
        )
        self._record_work_tool(
            call_id=call_id, name=name, arguments=arguments, result=raw_result,
            event_sequence=sequence, context_ref=work_before, input_refs=inputs,
        )
        if not error:
            self._activate_tool_result_refs(name, raw_result)
        self._state.record_receipt(
            {
                "tool": name,
                "call_id": call_id,
                "result": receipt_projection,
            }
        )
        if error:
            raise RuntimeError(error)
        return raw_result


def _event_adds_formal_evidence(event: Mapping[str, Any]) -> bool:
    event_type = str(event.get("event_type") or "")
    if event_type in {
        "plan_progress_applied",
        "plan_ready_work_unit_completed",
    }:
        return True
    if event_type == "skill_workflow_completed":
        return bool(event.get("artifact_refs"))
    if event_type != "tool_result":
        return False
    tool = str(event.get("tool") or "")
    if tool not in {
        "artifact_publish",
        "write_code_artifact",
        "edit_code_artifact",
        "execute_code_artifact",
        "review_child_result",
    }:
        return False
    result = event.get("raw_result")
    if not isinstance(result, Mapping):
        return False
    if str(result.get("status") or "") == "tool_error":
        return False
    if (
        result.get("artifact_ref")
        or result.get("code_artifact_ref")
        or result.get("execution_observation_ref")
        or result.get("observation_ref")
    ):
        return True
    review = result.get("review")
    return isinstance(review, Mapping) and bool(
        review.get("accepted_artifact_refs")
    )


def _latest_skill_workflow_input_refs(
    events: Sequence[Mapping[str, Any]],
    *,
    skill_id: str,
    before_sequence: int,
) -> tuple[str, ...] | None:
    for event in reversed(events):
        if int(event.get("event_sequence") or 0) >= before_sequence:
            continue
        if str(event.get("event_type") or "") != "skill_workflow_started":
            continue
        if str(event.get("skill_id") or "") != skill_id:
            continue
        payload = event.get("payload")
        if not isinstance(payload, Mapping):
            return None
        resolved_inputs = payload.get("resolved_inputs")
        if not isinstance(resolved_inputs, Sequence) or isinstance(
            resolved_inputs, (str, bytes)
        ):
            return None
        refs = [
            str(item.get("artifact_ref") or "").strip()
            for item in resolved_inputs
            if isinstance(item, Mapping)
            and str(item.get("artifact_ref") or "").strip()
        ]
        return tuple(dict.fromkeys(refs))
    return None

