from __future__ import annotations

import json
import os
import subprocess
import sys
import time

from pathlib import Path
from typing import Any


def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit("terminal_worker_requires_one_spec_path")
    spec_path = Path(sys.argv[1]).resolve()
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    argv = spec.get("argv")
    cwd = str(spec.get("cwd") or "").strip()
    if (
        not isinstance(argv, list)
        or not argv
        or any(not isinstance(item, str) or not item for item in argv)
        or not cwd
    ):
        raise SystemExit("terminal_worker_spec_invalid")

    return_code = 127
    launch_error = ""
    try:
        completed = subprocess.run(argv, cwd=cwd, check=False)
        return_code = int(completed.returncode)
    except Exception as exc:
        launch_error = f"{type(exc).__name__}:{exc}"
        print(launch_error, file=sys.stderr, flush=True)
    finally:
        completion = {
            "return_code": return_code,
            "timed_out": False,
            "finished_at_unix": time.time(),
        }
        if launch_error:
            completion["launch_error"] = launch_error
        _write_json_atomic(spec_path.parent / "completion.json", completion)
    return return_code if 0 <= return_code <= 255 else 1


def _write_json_atomic(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


if __name__ == "__main__":
    raise SystemExit(main())
