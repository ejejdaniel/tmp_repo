from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ..capabilities.managed_broker import ManagedRouteBrokerSessions
from ..routes import Route
from ..memory_lifecycle.prompt import preserve_tool_result
from .inspection import CodeInspector
from .projects import DevelopmentProjectStore
from .terminal import DevelopmentTerminalManager


@dataclass(frozen=True)
class DevelopmentProjectRoutes:
    """Low-level coding routes mounted only inside authoring Skills."""

    projects: DevelopmentProjectStore
    inspector: CodeInspector
    terminals: DevelopmentTerminalManager
    managed_route_brokers: ManagedRouteBrokerSessions | None = None
    execution_workspace_resolver: Callable[[str, str], Path] | None = None
    execution_inventory: Callable[[Mapping[str, Any]], dict[str, Any]] | None = None
    execution_read: Callable[[Mapping[str, Any]], dict[str, Any]] | None = None

    def routes(self, *, skill_ids: Sequence[str]) -> tuple[Route, ...]:
        owners = tuple(dict.fromkeys(str(item) for item in skill_ids if str(item)))
        if not owners:
            raise ValueError("development_project_skill_ids_required")
        routes = [
            Route(
                name="development_project_open",
                description=(
                    "Open or resume one mission-local multi-file development "
                    "worktree. When exactly one non-empty mutable project "
                    "has the same exact top-level formal specifications, this "
                    "returns that project instead of creating a blank duplicate; "
                    "new supporting dependencies are merged into that project; "
                    "revision greater than zero identifies such progress. A "
                    "checkpoint is a recovery point and does not close the "
                    "mutable project. "
                    "Runtime assigns one fixed project environment; the caller "
                    "provides only the entry command and cannot change packages "
                    "or execution environments. Opening does not execute code. "
                    "Every file path and working "
                    "directory used by development_project tools is relative to "
                    "the worktree root. Prefer working_directory='.' for a new "
                    "project unless its source tree requires a subdirectory. The "
                    "new worktree is empty, so write the entry file next instead "
                    "of searching for generated files."
                ),
                parameters=_OPEN_SCHEMA,
                handler=self._open,
                skill_ids=owners,
            ),
            Route(
                name="development_project_configure",
                description=(
                    "Change one development project's entry command or working "
                    "directory without changing source files or its Runtime-owned "
                    "environment."
                ),
                parameters=_CONFIGURE_SCHEMA,
                handler=self._configure,
                skill_ids=owners,
            ),
            Route(
                name="development_project_tree",
                description=(
                    "List exact current files and directories relative to one "
                    "worktree root. A newly opened project is intentionally empty. "
                    "Optional path selects a root-relative subtree or file; "
                    "max_entries bounds the listing. With execution_workspace_ref, "
                    "list that same project's retained execution read-only instead. "
                    "Worktree results contain project_id and entries; execution "
                    "results contain execution_workspace_ref, observation_ref, "
                    "execution_observation_ref, entries with runtime_state, and "
                    "truncated/total_file_count. These are operational evidence, "
                    "not new code or scientific results."
                ),
                parameters=_TREE_SCHEMA,
                handler=self._tree,
                skill_ids=owners,
            ),
            Route(
                name="development_project_read",
                description=(
                    "Read one bounded page from one exact UTF-8 project file. "
                    "With execution_workspace_ref, read path inside that same "
                    "project's retained execution, never the mutable worktree. "
                    "Worktree pages identify project_id/path; execution pages "
                    "identify execution_workspace_ref/relative_path/runtime_state. "
                    "Execution binary files return metadata only. Both are read-only. "
                    "When next_line_offset is present, continue from that exact "
                    "offset; null means the displayed page reached the real file end."
                ),
                parameters=_READ_SCHEMA,
                handler=self._read,
                skill_ids=owners,
            ),
            Route(
                name="development_project_search",
                description=(
                    "Search exact project files by literal text or regular expression. "
                    "With execution_workspace_ref, search only that exact retained "
                    "execution directory instead of the development worktree. "
                    "Matches use paths relative to the selected directory. "
                    "This is source search, not scientific semantic inference."
                ),
                parameters=_SEARCH_SCHEMA,
                handler=self._search,
                skill_ids=owners,
            ),
            Route(
                name="development_project_write",
                description=(
                    "Create one new UTF-8 file at a path relative to the development "
                    "worktree root. Include the configured working-directory prefix "
                    "in path only when that working directory is not '.'. This tool "
                    "never replaces an existing file; use development_project_edit "
                    "for both local edits and intentional whole-file replacement."
                ),
                parameters=_WRITE_SCHEMA,
                handler=lambda arguments: self.projects.write_file(
                    str(arguments["project_id"]),
                    str(arguments["path"]),
                    str(arguments["content"]),
                ),
                skill_ids=owners,
            ),
            Route(
                name="development_project_edit",
                description=(
                    "Edit one existing file by exact text replacement. Read the file "
                    "first and normally use the smallest unique old_string. For one "
                    "coherent whole-file rewrite, old_string may be the complete exact "
                    "file body from a completed read and new_string the complete revised "
                    "body. Never use development_project_write on an existing path."
                ),
                parameters=_EDIT_SCHEMA,
                handler=self._edit,
                skill_ids=owners,
            ),
            Route(
                name="development_project_move",
                description="Move or rename one exact path inside the same worktree.",
                parameters=_MOVE_SCHEMA,
                handler=lambda arguments: self.projects.move_path(
                    str(arguments["project_id"]),
                    str(arguments["source"]),
                    str(arguments["destination"]),
                ),
                skill_ids=owners,
            ),
            Route(
                name="development_project_delete",
                description="Delete one exact file or directory inside the worktree.",
                parameters=_PATH_SCHEMA,
                handler=lambda arguments: self.projects.delete_path(
                    str(arguments["project_id"]), str(arguments["path"])
                ),
                skill_ids=owners,
            ),
            Route(
                name="development_project_validate_syntax",
                description=(
                    "Parse or compiler-check selected project files with the native "
                    "language adapter. Unsupported languages are reported explicitly."
                ),
                parameters=_SYNTAX_SCHEMA,
                handler=self._validate_syntax,
                skill_ids=owners,
            ),
            Route(
                name="development_project_query_code",
                description=(
                    "Query bounded AST/code structure such as symbols, imports, calls, "
                    "or exact references. It never returns a full AST."
                ),
                parameters=_QUERY_SCHEMA,
                handler=self._query_code,
                skill_ids=owners,
            ),
            Route(
                name="development_project_terminal_start",
                description=(
                    "Start one shell command in the Runtime-owned project environment "
                    "and a project-relative directory. Package installation and "
                    "environment mutation are not supported. "
                    "The runtime shell may be minimal; optional shell utilities "
                    "are not guaranteed, so use language-native timing or "
                    "profiling when needed. "
                    "With execution_workspace_ref, mount that retained execution "
                    "read-only at AI_COSCIENTIST_EXECUTION_DIR. The command still "
                    "runs in the writable development project; diagnostic scripts "
                    "can analyze the mounted files without copying them into source. "
                    "Long commands return a terminal id for later polling or stopping."
                ),
                parameters=_TERMINAL_START_SCHEMA,
                handler=self._terminal_start,
                skill_ids=owners,
            ),
            Route(
                name="development_project_terminal_poll",
                description=(
                    "Poll one exact project terminal and read bounded output tails. "
                    "Use read_ref with stdout_ref or stderr_ref to page through full output."
                ),
                parameters=_TERMINAL_POLL_SCHEMA,
                handler=self._terminal_poll,
                skill_ids=owners,
            ),
            Route(
                name="development_project_terminal_stop",
                description="Stop one running terminal owned by the current runtime.",
                parameters=_TERMINAL_STOP_SCHEMA,
                handler=lambda arguments: self.terminals.stop(
                    str(arguments["project_id"]), str(arguments["terminal_id"])
                ),
                skill_ids=owners,
            ),
            Route(
                name="development_project_checkpoint",
                description=(
                    "Seal all current files plus the exact entry command and "
                    "Runtime-owned environment provenance as an immutable "
                    "development_project_snapshot artifact."
                ),
                parameters=_CHECKPOINT_SCHEMA,
                handler=self._checkpoint,
                skill_ids=owners,
            ),
            Route(
                name="development_project_diff",
                description=(
                    "Compare the current worktree with one exact immutable checkpoint. "
                    "When truncated, use read_ref with diff_ref to page through the full diff."
                ),
                parameters=_DIFF_SCHEMA,
                handler=self._diff,
                skill_ids=owners,
            ),
            Route(
                name="development_project_restore",
                description=(
                    "Restore one project to one exact checkpoint from the same project. "
                    "This changes only mission-local development files."
                ),
                parameters=_RESTORE_SCHEMA,
                handler=lambda arguments: self.projects.restore(
                    str(arguments["project_id"]), str(arguments["snapshot_ref"])
                ),
                skill_ids=owners,
            ),
        ]
        if self.managed_route_brokers is not None:
            routes.append(
                Route(
                    name="development_project_bind_managed_routes",
                    description=(
                        "Bind exact approved or pending code-callable Routes to one "
                        "development project for later formal execution. "
                        "Each Route keeps its own managed execution environment. "
                        "The exact Route refs become project dependencies; create a "
                        "new checkpoint after binding before formal execution. "
                        "The returned receipt is complete: do not inspect broker "
                        "files or environment variables while authoring. The formal "
                        "project executor injects a JSON stdin/stdout command prefix "
                        "only when the immutable checkpoint runs."
                    ),
                    parameters=_BIND_ROUTES_SCHEMA,
                    handler=lambda arguments: arguments,
                    contextual_handler=self._bind_managed_routes,
                    skill_ids=owners,
                )
            )
        return tuple(replace(route, result_projector=preserve_tool_result) for route in routes)

    def _open(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        resumed = self.projects.resume_compatible_project(
            depends_on=list(arguments["depends_on"]),
        )
        if resumed is not None:
            return self.projects.bind_dependencies(
                resumed["project_id"],
                list(arguments["depends_on"]),
            )
        return self.projects.open_project(
            purpose=str(arguments["purpose"]),
            entry_command=list(arguments["entry_command"]),
            working_directory=str(arguments["working_directory"]),
            depends_on=list(arguments["depends_on"]),
        )

    def _configure(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        return self.projects.configure_project(
            str(arguments["project_id"]),
            entry_command=list(arguments["entry_command"]),
            working_directory=str(arguments["working_directory"]),
        )

    def _tree(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        execution_ref, _ = self._execution_input(arguments)
        if execution_ref:
            if self.execution_inventory is None:
                raise ValueError("development_execution_inventory_unavailable")
            return self.execution_inventory({
                "execution_workspace_ref": execution_ref,
                "relative_path": str(arguments.get("path") or ""),
                **({"max_entries": arguments["max_entries"]}
                   if "max_entries" in arguments else {}),
            })
        return self.projects.tree(
            str(arguments["project_id"]),
            path=str(arguments.get("path") or "."),
            max_entries=arguments.get("max_entries"),
        )

    def _read(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        execution_ref, _ = self._execution_input(arguments)
        if execution_ref:
            if self.execution_read is None:
                raise ValueError("development_execution_read_unavailable")
            return self.execution_read({
                "execution_workspace_ref": execution_ref,
                "relative_path": str(arguments["path"]),
                "line_offset": int(arguments["line_offset"]),
                "line_limit": int(arguments["line_limit"]),
            })
        return self.projects.read_file(
            str(arguments["project_id"]),
            str(arguments["path"]),
            line_offset=int(arguments["line_offset"]),
            line_limit=int(arguments["line_limit"]),
        )

    def _search(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        execution_ref, execution_root = self._execution_input(arguments)
        result = self.projects.search(
            str(arguments["project_id"]),
            query=str(arguments["query"]),
            path_glob=str(arguments["path_glob"]),
            regex=bool(arguments["regex"]),
            max_results=int(arguments["max_results"]),
            search_root=execution_root,
        )
        if execution_ref:
            result["execution_workspace_ref"] = execution_ref
        return result

    def _execution_input(self, arguments: Mapping[str, Any]) -> tuple[str, Path | None]:
        if "execution_workspace_ref" not in arguments:
            return "", None
        ref = str(arguments["execution_workspace_ref"]).strip()
        if not ref or self.execution_workspace_resolver is None:
            raise ValueError("development_execution_workspace_unavailable")
        project_id = str(arguments["project_id"])
        self.projects.project_receipt(project_id)
        return ref, self.execution_workspace_resolver(project_id, ref)

    def _edit(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        return self.projects.edit_file(
            str(arguments["project_id"]),
            str(arguments["path"]),
            old_string=str(arguments["old_string"]),
            new_string=str(arguments["new_string"]),
            replace_all=bool(arguments["replace_all"]),
        )

    def _validate_syntax(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        return self.inspector.validate_syntax(
            str(arguments["project_id"]),
            paths=list(arguments["paths"]),
            timeout_seconds=int(arguments["timeout_seconds"]),
        )

    def _query_code(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        return self.inspector.query_structure(
            str(arguments["project_id"]),
            path=str(arguments["path"]),
            query_kind=str(arguments["query_kind"]),
            symbol=str(arguments["symbol"]),
            max_results=int(arguments["max_results"]),
        )

    def _terminal_start(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        execution_ref, execution_root = self._execution_input(arguments)
        return self.terminals.start(
            str(arguments["project_id"]),
            purpose=str(arguments["purpose"]),
            command=str(arguments["command"]),
            working_directory=str(arguments["working_directory"]),
            timeout_seconds=int(arguments["timeout_seconds"]),
            wait_seconds=int(arguments["wait_seconds"]),
            execution_workspace_ref=execution_ref,
            readonly_execution_root=execution_root,
        )

    def _terminal_poll(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        return self.terminals.poll(
            str(arguments["project_id"]),
            str(arguments["terminal_id"]),
            wait_seconds=int(arguments["wait_seconds"]),
            tail_chars=int(arguments["tail_chars"]),
        )

    def _checkpoint(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        return self.projects.checkpoint(
            str(arguments["project_id"]),
            title=str(arguments["title"]),
            summary=str(arguments["summary"]),
            additional_depends_on=list(arguments["additional_depends_on"]),
        )

    def _diff(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        return self.projects.diff(
            str(arguments["project_id"]),
            str(arguments["snapshot_ref"]),
            max_chars=int(arguments["max_chars"]),
        )

    def _bind_managed_routes(
        self,
        arguments: Mapping[str, Any],
        skill_id: str | None,
    ) -> dict[str, Any]:
        if self.managed_route_brokers is None:
            raise RuntimeError("managed_route_broker_unavailable")
        project_id = str(arguments["project_id"])
        self.projects.project_receipt(project_id)
        binding = self.managed_route_brokers.create(
            route_refs=list(arguments["route_refs"]),
            caller_skill_id=str(skill_id or ""),
            require_code_callable=True,
            max_route_calls=int(arguments["max_route_calls"]),
            timeout_seconds=float(arguments["timeout_seconds"]),
        )
        self.projects.bind_dependencies(
            project_id,
            list(arguments["route_refs"]),
        )
        request_contract = binding.get("request_contract")
        if not isinstance(request_contract, Mapping):
            request_contract = {
                "route_ref": "one exact bound route ref",
                "payload": "one JSON object matching that Route input schema",
            }
        return {
            "status": str(binding.get("status") or "managed_route_broker_ready"),
            "broker_id": str(binding.get("broker_id") or ""),
            "route_refs": [
                str(ref)
                for ref in binding.get("route_refs", arguments["route_refs"])
            ],
            "mode": str(binding.get("mode") or "record"),
            "max_route_calls": int(
                binding.get("max_route_calls", arguments["max_route_calls"])
            ),
            "request_contract": dict(request_contract),
        }


_STRING_ARRAY = {"type": "array", "items": {"type": "string"}}
_PROJECT_SCHEMA = {
    "type": "object",
    "properties": {"project_id": {"type": "string"}},
    "required": ["project_id"],
    "additionalProperties": False,
}
_TREE_SCHEMA = {
    **_PROJECT_SCHEMA,
    "properties": {
        **_PROJECT_SCHEMA["properties"],
        "execution_workspace_ref": {"type": "string", "minLength": 1},
        "path": {"type": "string"},
        "max_entries": {"type": "integer", "minimum": 1, "maximum": 500},
    },
}
_OPEN_SCHEMA = {
    "type": "object",
    "properties": {
        "purpose": {"type": "string"},
        "entry_command": _STRING_ARRAY,
        "working_directory": {"type": "string"},
        "depends_on": _STRING_ARRAY,
    },
    "required": [
        "purpose",
        "entry_command",
        "working_directory",
        "depends_on",
    ],
    "additionalProperties": False,
}
_CONFIGURE_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "entry_command": _STRING_ARRAY,
        "working_directory": {"type": "string"},
    },
    "required": [
        "project_id",
        "entry_command",
        "working_directory",
    ],
    "additionalProperties": False,
}
_PATH_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "path": {"type": "string"},
    },
    "required": ["project_id", "path"],
    "additionalProperties": False,
}
_READ_SCHEMA = {
    "type": "object",
    "properties": {
        **_PATH_SCHEMA["properties"],
        "execution_workspace_ref": {"type": "string", "minLength": 1},
        "line_offset": {"type": "integer", "minimum": 0},
        "line_limit": {"type": "integer", "minimum": 1, "maximum": 2000},
    },
    "required": ["project_id", "path", "line_offset", "line_limit"],
    "additionalProperties": False,
}
_SEARCH_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "execution_workspace_ref": {"type": "string", "minLength": 1},
        "query": {"type": "string"},
        "path_glob": {"type": "string"},
        "regex": {"type": "boolean"},
        "max_results": {"type": "integer", "minimum": 1, "maximum": 500},
    },
    "required": ["project_id", "query", "path_glob", "regex", "max_results"],
    "additionalProperties": False,
}
_WRITE_SCHEMA = {
    "type": "object",
    "properties": {
        **_PATH_SCHEMA["properties"],
        "content": {"type": "string"},
    },
    "required": ["project_id", "path", "content"],
    "additionalProperties": False,
}
_EDIT_SCHEMA = {
    "type": "object",
    "properties": {
        **_PATH_SCHEMA["properties"],
        "old_string": {"type": "string"},
        "new_string": {"type": "string"},
        "replace_all": {"type": "boolean"},
    },
    "required": [
        "project_id",
        "path",
        "old_string",
        "new_string",
        "replace_all",
    ],
    "additionalProperties": False,
}
_MOVE_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "source": {"type": "string"},
        "destination": {"type": "string"},
    },
    "required": ["project_id", "source", "destination"],
    "additionalProperties": False,
}
_SYNTAX_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "paths": _STRING_ARRAY,
        "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 300},
    },
    "required": ["project_id", "paths", "timeout_seconds"],
    "additionalProperties": False,
}
_QUERY_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "path": {"type": "string"},
        "query_kind": {
            "type": "string",
            "enum": ["symbols", "imports", "calls", "references"],
        },
        "symbol": {"type": "string"},
        "max_results": {"type": "integer", "minimum": 1, "maximum": 500},
    },
    "required": ["project_id", "path", "query_kind", "symbol", "max_results"],
    "additionalProperties": False,
}
_TERMINAL_START_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "execution_workspace_ref": {"type": "string", "minLength": 1},
        "purpose": {"type": "string"},
        "command": {"type": "string"},
        "working_directory": {"type": "string"},
        "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 86400},
        "wait_seconds": {"type": "integer", "minimum": 0, "maximum": 30},
    },
    "required": [
        "project_id",
        "purpose",
        "command",
        "working_directory",
        "timeout_seconds",
        "wait_seconds",
    ],
    "additionalProperties": False,
}
_TERMINAL_POLL_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "terminal_id": {"type": "string"},
        "wait_seconds": {"type": "integer", "minimum": 0, "maximum": 30},
        "tail_chars": {"type": "integer", "minimum": 1000, "maximum": 40000},
    },
    "required": ["project_id", "terminal_id", "wait_seconds", "tail_chars"],
    "additionalProperties": False,
}
_TERMINAL_STOP_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "terminal_id": {"type": "string"},
    },
    "required": ["project_id", "terminal_id"],
    "additionalProperties": False,
}
_CHECKPOINT_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "title": {"type": "string"},
        "summary": {"type": "string"},
        "additional_depends_on": _STRING_ARRAY,
    },
    "required": ["project_id", "title", "summary", "additional_depends_on"],
    "additionalProperties": False,
}
_DIFF_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "snapshot_ref": {"type": "string"},
        "max_chars": {"type": "integer", "minimum": 1000, "maximum": 120000},
    },
    "required": ["project_id", "snapshot_ref", "max_chars"],
    "additionalProperties": False,
}
_RESTORE_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "snapshot_ref": {"type": "string"},
    },
    "required": ["project_id", "snapshot_ref"],
    "additionalProperties": False,
}
_BIND_ROUTES_SCHEMA = {
    "type": "object",
    "properties": {
        "project_id": {"type": "string"},
        "route_refs": _STRING_ARRAY,
        "max_route_calls": {
            "type": "integer",
            "minimum": 1,
            "maximum": 10000,
        },
        "timeout_seconds": {
            "type": "integer",
            "minimum": 1,
            "maximum": 86400,
        },
    },
    "required": [
        "project_id",
        "route_refs",
        "max_route_calls",
        "timeout_seconds",
    ],
    "additionalProperties": False,
}
