from __future__ import annotations

import copy
import difflib
import hashlib
import json
import os
import re
import shutil
import uuid

from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Sequence

from ..artifacts import ArtifactStore
from ..text_pages import read_text_page


_PROJECT_ID = re.compile(r"^[a-zA-Z0-9._-]{1,96}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_MAX_FILE_BYTES = 2_000_000
_MAX_PROJECT_FILES = 2_000


class DevelopmentProjectError(RuntimeError):
    pass


class DevelopmentProjectStore:
    """Mutable mission-local worktrees with immutable formal checkpoints."""

    def __init__(
        self,
        root: Path,
        *,
        artifacts: ArtifactStore,
        environment_ref: str = "host:python",
    ) -> None:
        self.root = (root.resolve() / "development-projects").resolve()
        self.projects_root = self.root / "projects"
        self.snapshots_root = self.root / "snapshots"
        self.projects_root.mkdir(parents=True, exist_ok=True)
        self.snapshots_root.mkdir(parents=True, exist_ok=True)
        self.artifacts = artifacts
        self.environment_ref = str(environment_ref).strip()
        if not self.environment_ref:
            raise DevelopmentProjectError(
                "development_project_runtime_environment_required"
            )

    def open_project(
        self,
        *,
        purpose: str,
        entry_command: Sequence[str],
        working_directory: str,
        depends_on: Sequence[str],
    ) -> dict[str, Any]:
        normalized_purpose = str(purpose).strip()
        if not normalized_purpose:
            raise DevelopmentProjectError("development_project_purpose_required")
        command = _command_argv(entry_command)
        workdir = _normalize_relative_directory(working_directory)
        dependencies = list(_dependency_refs(depends_on))
        # Purpose remains in metadata. Keep the filesystem identifier short so
        # nested project paths remain usable on Windows hosts with MAX_PATH.
        project_id = f"project-{uuid.uuid4().hex[:12]}"
        project_dir = self.projects_root / project_id
        worktree = project_dir / "worktree"
        worktree.mkdir(parents=True, exist_ok=False)
        if workdir != ".":
            (worktree / Path(workdir)).mkdir(parents=True, exist_ok=True)
        metadata = {
            "project_id": project_id,
            "purpose": normalized_purpose,
            "environment_ref": self.environment_ref,
            "entry_command": command,
            "working_directory": workdir,
            "depends_on": dependencies,
            "revision": 0,
            "latest_snapshot_ref": None,
        }
        _write_json(project_dir / "project.json", metadata)
        return self.project_receipt(project_id)

    def resume_compatible_project(
        self,
        *,
        depends_on: Sequence[str],
    ) -> dict[str, Any] | None:
        """Return one non-empty mutable project for the same formal heads.

        Free-form purpose text is not project identity. The Runtime-owned
        environment is adopted mechanically when a run resumes. Supporting
        evidence can change between attempts, so project
        identity is the exact set of top-level formal refs: requested refs that
        are not provenance dependencies of another requested ref. Retrying the
        same implementation must continue its mutable worktree instead of
        silently creating a blank duplicate. A checkpoint records an immutable
        recovery point; it does not close or replace the mutable worktree.
        """
        requested_heads = self._project_lineage_heads(depends_on)
        if not requested_heads:
            return None

        candidates: list[str] = []
        for project_dir in sorted(self.projects_root.iterdir()):
            metadata_path = project_dir / "project.json"
            worktree = project_dir / "worktree"
            if not metadata_path.is_file() or not worktree.is_dir():
                continue
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            existing_heads = self._project_lineage_heads(
                metadata.get("depends_on", ())
            )
            if existing_heads != requested_heads:
                continue
            if not any(path.is_file() for path in worktree.rglob("*")):
                continue
            candidates.append(str(metadata.get("project_id") or ""))

        candidates = [project_id for project_id in candidates if project_id]
        if len(candidates) > 1:
            raise DevelopmentProjectError(
                "development_project_resume_ambiguous:"
                + ",".join(candidates)
            )
        if not candidates:
            return None
        project_id = candidates[0]
        metadata = self._metadata(project_id)
        if metadata.get("environment_ref") != self.environment_ref:
            metadata["environment_ref"] = self.environment_ref
            metadata["revision"] = int(metadata["revision"]) + 1
            self._write_metadata(project_id, metadata)
        return self.project_receipt(project_id)

    def _project_lineage_heads(
        self,
        depends_on: Sequence[str],
    ) -> frozenset[str]:
        formal_refs = {
            ref
            for ref in _dependency_refs(depends_on)
            if ref.startswith(("artifact:", "code_artifact:"))
        }
        if not formal_refs:
            return frozenset()

        ancestors: set[str] = set()
        visited: set[str] = set()

        def visit(artifact_ref: str) -> None:
            if artifact_ref in visited or not artifact_ref.startswith("artifact:"):
                return
            visited.add(artifact_ref)
            try:
                artifact = self.artifacts.read(artifact_ref)
            except KeyError:
                return
            for raw_dependency in artifact.get("depends_on", ()):
                dependency = str(raw_dependency).strip()
                if not dependency:
                    continue
                if dependency in formal_refs:
                    ancestors.add(dependency)
                visit(dependency)

        for artifact_ref in formal_refs:
            visit(artifact_ref)

        heads = formal_refs - ancestors
        # A mission-wide task contract alone cannot identify one development
        # project among multiple implementations in the same task.
        identifying: set[str] = set()
        for ref in heads:
            if not ref.startswith("artifact:"):
                identifying.add(ref)
                continue
            try:
                kind = str(self.artifacts.read(ref).get("artifact_kind") or "")
            except KeyError:
                identifying.add(ref)
                continue
            if kind != "task_spec":
                identifying.add(ref)
        return frozenset(identifying)

    def project_receipt(self, project_id: str) -> dict[str, Any]:
        metadata = self._metadata(project_id)
        return {
            "status": "development_project_ready",
            "project_id": metadata["project_id"],
            "purpose": metadata["purpose"],
            "environment_ref": metadata["environment_ref"],
            "entry_command": list(metadata["entry_command"]),
            "working_directory": metadata["working_directory"],
            "revision": metadata["revision"],
            "latest_snapshot_ref": metadata.get("latest_snapshot_ref"),
        }

    def dependency_refs(self, project_id: str) -> tuple[str, ...]:
        """Return the exact formal inputs already bound to a mutable project."""
        metadata = self._metadata(project_id)
        return tuple(_dependency_refs(metadata.get("depends_on", ())))

    def configure_project(
        self,
        project_id: str,
        *,
        entry_command: Sequence[str],
        working_directory: str,
    ) -> dict[str, Any]:
        metadata = self._metadata(project_id)
        command = _command_argv(entry_command)
        workdir = _normalize_relative_directory(working_directory)
        self.resolve_working_directory(project_id, workdir)
        metadata.update(
            {
                "environment_ref": self.environment_ref,
                "entry_command": command,
                "working_directory": workdir,
                "revision": int(metadata["revision"]) + 1,
            }
        )
        self._write_metadata(project_id, metadata)
        return self.project_receipt(project_id)

    def bind_dependencies(
        self,
        project_id: str,
        dependency_refs: Sequence[str],
    ) -> dict[str, Any]:
        """Persist exact dependencies on the mutable project before checkpointing."""
        metadata = self._metadata(project_id)
        additions = _dependency_refs(dependency_refs)
        dependencies = list(
            dict.fromkeys([*metadata.get("depends_on", ()), *additions])
        )
        if dependencies != list(metadata.get("depends_on", ())):
            metadata["depends_on"] = dependencies
            metadata["revision"] = int(metadata["revision"]) + 1
            self._write_metadata(project_id, metadata)
        return self.project_receipt(project_id)

    def tree(
        self, project_id: str, *, path: str = ".", max_entries: int | None = None,
    ) -> dict[str, Any]:
        worktree = self._worktree(project_id)
        root = worktree if path in {"", "."} else self._target(project_id, path)
        if not root.exists():
            raise DevelopmentProjectError(f"development_project_path_missing:{path}")
        if max_entries is not None and not 1 <= max_entries <= 500:
            raise DevelopmentProjectError("development_project_max_entries_invalid")
        entries: list[dict[str, Any]] = []
        for path in sorted(root.rglob("*")) if root.is_dir() else (root,):
            if path.is_symlink():
                raise DevelopmentProjectError(
                    f"development_project_symlink_forbidden:{path.relative_to(worktree)}"
                )
            relative = path.relative_to(worktree).as_posix()
            entries.append(
                {
                    "path": relative,
                    "kind": "directory" if path.is_dir() else "file",
                    "size_bytes": path.stat().st_size if path.is_file() else None,
                }
            )
            if len(entries) > _MAX_PROJECT_FILES * 2:
                raise DevelopmentProjectError("development_project_tree_too_large")
            if max_entries is not None and len(entries) >= max_entries:
                break
        return {
            "status": "development_project_tree_ready",
            "project_id": project_id,
            "entries": entries,
        }

    def read_file(
        self,
        project_id: str,
        path: str,
        *,
        line_offset: int,
        line_limit: int,
    ) -> dict[str, Any]:
        target = self._existing_file(project_id, path)
        if line_offset < 0:
            raise DevelopmentProjectError("development_read_line_offset_invalid")
        if not 1 <= line_limit <= 2_000:
            raise DevelopmentProjectError("development_read_line_limit_invalid")
        try:
            page = read_text_page(target, offset=line_offset, limit=line_limit)
        except UnicodeDecodeError as exc:
            raise DevelopmentProjectError(
                f"development_read_not_utf8:{_normalize_relative_path(path)}"
            ) from exc
        return {
            "status": "development_project_file_ready",
            "project_id": project_id,
            "path": _normalize_relative_path(path),
            **page,
        }

    def search(
        self,
        project_id: str,
        *,
        query: str,
        path_glob: str,
        regex: bool,
        max_results: int,
        search_root: Path | None = None,
    ) -> dict[str, Any]:
        needle = str(query)
        if not needle:
            raise DevelopmentProjectError("development_search_query_required")
        if len(needle) > 2_000:
            raise DevelopmentProjectError("development_search_query_too_large")
        if not 1 <= max_results <= 500:
            raise DevelopmentProjectError("development_search_limit_invalid")
        try:
            pattern = re.compile(needle) if regex else None
        except re.error as exc:
            raise DevelopmentProjectError(
                f"development_search_regex_invalid:{exc}"
            ) from exc
        worktree = self._worktree(project_id)
        if search_root is not None:
            worktree = Path(search_root).resolve(strict=True)
        glob = str(path_glob or "**/*").strip() or "**/*"
        glob_path = Path(glob.replace("\\", "/"))
        if glob_path.is_absolute() or glob_path.drive or ".." in glob_path.parts:
            raise DevelopmentProjectError("development_search_glob_outside_root")
        matches: list[dict[str, Any]] = []
        truncated = False
        for path in sorted(worktree.glob(glob)):
            if (
                not path.is_file()
                or any(item.is_symlink() for item in (path, *path.parents) if item != worktree)
                or not path.resolve().is_relative_to(worktree)
            ):
                continue
            try:
                text = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            for line_number, line in enumerate(text.splitlines(), start=1):
                matched = bool(pattern.search(line)) if pattern else needle in line
                if not matched:
                    continue
                if len(matches) >= max_results:
                    truncated = True
                    break
                matches.append(
                    {
                        "path": path.relative_to(worktree).as_posix(),
                        "line": line_number,
                        "text": line[:2_000],
                    }
                )
            if truncated:
                break
        return {
            "status": "development_project_search_ready",
            "project_id": project_id,
            "matches": matches,
            "truncated": truncated,
        }

    def write_file(self, project_id: str, path: str, content: str) -> dict[str, Any]:
        if not isinstance(content, str):
            raise DevelopmentProjectError("development_write_content_must_be_text")
        if len(content.encode("utf-8")) > _MAX_FILE_BYTES:
            raise DevelopmentProjectError("development_write_content_too_large")
        target = self._target(project_id, path)
        if target.exists():
            raise DevelopmentProjectError(
                f"development_write_file_exists:{_normalize_relative_path(path)}"
            )
        target.parent.mkdir(parents=True, exist_ok=True)
        _write_text(target, content)
        revision = self._bump_revision(project_id)
        return {
            "status": "development_project_file_written",
            "project_id": project_id,
            "path": _normalize_relative_path(path),
            "size_bytes": len(content.encode("utf-8")),
            "revision": revision,
        }

    def import_files(
        self,
        project_id: str,
        files: Mapping[str, bytes],
    ) -> dict[str, Any]:
        if not files:
            raise DevelopmentProjectError("development_import_files_required")
        if len(files) > _MAX_PROJECT_FILES:
            raise DevelopmentProjectError("development_project_file_limit")
        normalized: dict[str, bytes] = {}
        for raw_path, raw_body in files.items():
            path = _normalize_relative_path(raw_path)
            if not isinstance(raw_body, bytes):
                raise DevelopmentProjectError(
                    f"development_import_file_body_invalid:{path}"
                )
            if len(raw_body) > _MAX_FILE_BYTES:
                raise DevelopmentProjectError(
                    f"development_project_file_too_large:{path}"
                )
            if path in normalized:
                raise DevelopmentProjectError(
                    f"development_import_file_duplicate:{path}"
                )
            normalized[path] = raw_body
        written: list[str] = []
        for relative, body in normalized.items():
            target = self._target(project_id, relative)
            if target.exists():
                raise DevelopmentProjectError(
                    f"development_write_file_exists:{relative}"
                )
            target.parent.mkdir(parents=True, exist_ok=True)
            temporary = target.with_suffix(f"{target.suffix}.tmp")
            temporary.write_bytes(body)
            os.replace(temporary, target)
            written.append(relative)
        revision = self._bump_revision(project_id)
        return {
            "status": "development_project_files_imported",
            "project_id": project_id,
            "paths": sorted(written),
            "revision": revision,
        }

    def edit_file(
        self,
        project_id: str,
        path: str,
        *,
        old_string: str,
        new_string: str,
        replace_all: bool,
    ) -> dict[str, Any]:
        if not old_string:
            raise DevelopmentProjectError("development_edit_old_string_required")
        if old_string == new_string:
            raise DevelopmentProjectError("development_edit_requires_changed_text")
        target = self._existing_file(project_id, path)
        source = target.read_text(encoding="utf-8")
        occurrences = source.count(old_string)
        if not occurrences:
            raise DevelopmentProjectError("development_edit_old_string_not_found")
        if occurrences > 1 and not replace_all:
            raise DevelopmentProjectError(
                f"development_edit_old_string_not_unique:occurrences={occurrences}"
            )
        revised = source.replace(old_string, new_string, -1 if replace_all else 1)
        if len(revised.encode("utf-8")) > _MAX_FILE_BYTES:
            raise DevelopmentProjectError("development_edit_result_too_large")
        _write_text(target, revised)
        revision = self._bump_revision(project_id)
        return {
            "status": "development_project_file_edited",
            "project_id": project_id,
            "path": _normalize_relative_path(path),
            "replacement_count": occurrences if replace_all else 1,
            "revision": revision,
        }

    def move_path(self, project_id: str, source: str, destination: str) -> dict[str, Any]:
        source_path = self._target(project_id, source)
        destination_path = self._target(project_id, destination)
        if not source_path.exists():
            raise DevelopmentProjectError(
                f"development_move_source_missing:{_normalize_relative_path(source)}"
            )
        if source_path.is_symlink():
            raise DevelopmentProjectError("development_project_symlink_forbidden")
        if destination_path.exists():
            raise DevelopmentProjectError(
                f"development_move_destination_exists:{_normalize_relative_path(destination)}"
            )
        destination_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(source_path), str(destination_path))
        revision = self._bump_revision(project_id)
        return {
            "status": "development_project_path_moved",
            "project_id": project_id,
            "source": _normalize_relative_path(source),
            "destination": _normalize_relative_path(destination),
            "revision": revision,
        }

    def delete_path(self, project_id: str, path: str) -> dict[str, Any]:
        target = self._target(project_id, path)
        if not target.exists():
            raise DevelopmentProjectError(
                f"development_delete_path_missing:{_normalize_relative_path(path)}"
            )
        if target.is_symlink():
            raise DevelopmentProjectError("development_project_symlink_forbidden")
        if target.is_dir():
            shutil.rmtree(target)
        else:
            target.unlink()
        revision = self._bump_revision(project_id)
        return {
            "status": "development_project_path_deleted",
            "project_id": project_id,
            "path": _normalize_relative_path(path),
            "revision": revision,
        }

    def checkpoint(
        self,
        project_id: str,
        *,
        title: str,
        summary: str,
        additional_depends_on: Sequence[str] = (),
    ) -> dict[str, Any]:
        metadata = self._metadata(project_id)
        previous_snapshot_ref = str(
            metadata.get("latest_snapshot_ref") or ""
        ).strip()
        dependencies = tuple(
            dict.fromkeys(
                [
                    *metadata.get("depends_on", ()),
                    *(
                        (previous_snapshot_ref,)
                        if previous_snapshot_ref
                        else ()
                    ),
                    *_dependency_refs(additional_depends_on),
                ]
            )
        )
        files, bodies = self._file_manifest(project_id)
        canonical = {
            "project_id": project_id,
            "files": files,
            "entry_command": list(metadata["entry_command"]),
            "working_directory": metadata["working_directory"],
            "environment_ref": metadata["environment_ref"],
            "dependency_refs": list(dependencies),
        }
        snapshot_hash = hashlib.sha256(
            json.dumps(canonical, ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()
        snapshot_dir = self.snapshots_root / snapshot_hash
        if not snapshot_dir.exists():
            files_root = snapshot_dir / "files"
            files_root.mkdir(parents=True, exist_ok=False)
            for relative, body in bodies.items():
                destination = files_root / Path(relative)
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(body)
            _write_json(snapshot_dir / "snapshot.json", canonical)
        payload = {
            "artifact_kind": "development_project_snapshot",
            "project_id": project_id,
            "snapshot_hash": snapshot_hash,
            "files": files,
            "entry_command": list(metadata["entry_command"]),
            "working_directory": metadata["working_directory"],
            "environment_ref": metadata["environment_ref"],
            "dependency_refs": list(dependencies),
        }
        validate_development_project_snapshot(payload)
        receipt = self.artifacts.publish(
            artifact_kind="development_project_snapshot",
            artifact_id=f"development-project-{project_id}-{snapshot_hash[:12]}",
            title=str(title).strip() or f"Development project {project_id}",
            markdown=(
                "Immutable multi-file development checkpoint. Source bodies remain "
                "in mission-local runtime storage and are accessed through the "
                "development project tools."
            ),
            machine_payload=payload,
            status="accepted",
            summary=str(summary).strip(),
            depends_on=_artifact_refs_only(dependencies),
        )
        metadata["latest_snapshot_ref"] = receipt["artifact_ref"]
        self._write_metadata(project_id, metadata)
        return {
            "status": "development_project_checkpoint_created",
            "project_id": project_id,
            "snapshot_ref": receipt["artifact_ref"],
            "snapshot_hash": snapshot_hash,
            "file_count": len(files),
            "revision": metadata["revision"],
        }

    def diff(self, project_id: str, snapshot_ref: str, *, max_chars: int) -> dict[str, Any]:
        if not 1_000 <= max_chars <= 120_000:
            raise DevelopmentProjectError("development_diff_max_chars_invalid")
        snapshot = self._snapshot_payload(snapshot_ref)
        baseline_root = self._snapshot_files_root(str(snapshot["snapshot_hash"]))
        current_root = self._worktree(project_id)
        baseline_paths = {
            path.relative_to(baseline_root).as_posix()
            for path in baseline_root.rglob("*")
            if path.is_file()
        }
        current_paths = {
            path.relative_to(current_root).as_posix()
            for path in current_root.rglob("*")
            if path.is_file() and not path.is_symlink()
        }
        chunks: list[str] = []
        changed: list[str] = []
        for relative in sorted(baseline_paths | current_paths):
            before = _read_diff_lines(baseline_root / relative)
            after = _read_diff_lines(current_root / relative)
            if before == after:
                continue
            changed.append(relative)
            chunks.extend(
                difflib.unified_diff(
                    before,
                    after,
                    fromfile=f"snapshot/{relative}",
                    tofile=f"worktree/{relative}",
                )
            )
        rendered = "".join(chunks)
        digest = hashlib.sha256(rendered.encode("utf-8")).hexdigest()
        output_path = self._project_dir(project_id) / "diffs" / f"{digest}.txt"
        if not output_path.exists():
            output_path.parent.mkdir(parents=True, exist_ok=True)
            _write_text(output_path, rendered)
        truncated = len(rendered) > max_chars
        return {
            "status": "development_project_diff_ready",
            "project_id": project_id,
            "snapshot_ref": snapshot_ref,
            "changed_paths": changed,
            "diff": rendered[:max_chars],
            "truncated": truncated,
            "diff_ref": f"development_output:{project_id}:diff:{digest}",
        }

    def terminal_output_ref(self, project_id: str, terminal_id: str, stream: str) -> str:
        ref = f"development_output:{project_id}:terminal:{terminal_id}:{stream}"
        self._output_path(ref)
        return ref

    def read_output(
        self, ref: str, *, line_offset: int = 0, line_limit: int = 200
    ) -> dict[str, Any]:
        if line_offset < 0 or not 1 <= line_limit <= 2_000:
            raise DevelopmentProjectError("development_output_read_range_invalid")
        page = read_text_page(
            self._output_path(ref), offset=line_offset, limit=line_limit, errors="replace"
        )
        page.pop("total_lines")
        return {
            "status": "source_page_ready",
            "source_ref": ref,
            **page,
            "truncated": page["next_line_offset"] is not None,
        }

    def _output_path(self, ref: str) -> Path:
        parts = str(ref).split(":")
        if len(parts) not in {4, 5} or parts[0] != "development_output":
            raise DevelopmentProjectError("development_output_ref_invalid")
        root = self._project_dir(parts[1])
        if len(parts) == 4 and parts[2] == "diff" and _SHA256.fullmatch(parts[3]):
            target = root / "diffs" / f"{parts[3]}.txt"
        elif (
            len(parts) == 5 and parts[2] == "terminal"
            and re.fullmatch(r"[a-f0-9]{16}", parts[3])
            and parts[4] in {"stdout", "stderr"}
        ):
            target = root / "terminals" / parts[3] / f"{parts[4]}.txt"
        else:
            raise DevelopmentProjectError("development_output_ref_invalid")
        if target.is_symlink() or not target.resolve().is_relative_to(root):
            raise DevelopmentProjectError("development_output_path_escaped")
        if not target.is_file():
            raise DevelopmentProjectError(f"development_output_missing:{ref}")
        return target

    def restore(self, project_id: str, snapshot_ref: str) -> dict[str, Any]:
        snapshot = self._snapshot_payload(snapshot_ref)
        if str(snapshot["project_id"]) != project_id:
            raise DevelopmentProjectError("development_snapshot_project_mismatch")
        source = self._snapshot_files_root(str(snapshot["snapshot_hash"]))
        worktree = self._worktree(project_id)
        temporary = worktree.parent / f"restore-{uuid.uuid4().hex[:12]}"
        shutil.copytree(source, temporary)
        backup = worktree.parent / f"pre-restore-{uuid.uuid4().hex[:12]}"
        os.replace(worktree, backup)
        os.replace(temporary, worktree)
        shutil.rmtree(backup)
        metadata = self._metadata(project_id)
        metadata["environment_ref"] = self.environment_ref
        metadata["entry_command"] = list(snapshot["entry_command"])
        metadata["working_directory"] = snapshot["working_directory"]
        metadata["latest_snapshot_ref"] = snapshot_ref
        metadata["revision"] = int(metadata["revision"]) + 1
        self._write_metadata(project_id, metadata)
        return {
            "status": "development_project_snapshot_restored",
            "project_id": project_id,
            "snapshot_ref": snapshot_ref,
            "revision": metadata["revision"],
        }

    def worktree(self, project_id: str) -> Path:
        return self._worktree(project_id)

    def snapshot_files(self, snapshot_ref: str) -> dict[str, bytes]:
        payload = self._snapshot_payload(snapshot_ref)
        root = self._snapshot_files_root(str(payload["snapshot_hash"]))
        bodies: dict[str, bytes] = {}
        for item in payload["files"]:
            relative = _normalize_relative_path(item["path"])
            path = (root / relative).resolve()
            if not path.is_relative_to(root) or not path.is_file():
                raise DevelopmentProjectError(
                    f"development_snapshot_file_missing:{relative}"
                )
            body = path.read_bytes()
            digest = hashlib.sha256(body).hexdigest()
            if digest != item["sha256"] or len(body) != item["size_bytes"]:
                raise DevelopmentProjectError(
                    f"development_snapshot_file_integrity_error:{relative}"
                )
            bodies[relative] = body
        return bodies

    def read_snapshot_file(
        self,
        snapshot_ref: str,
        path: str,
        *,
        line_offset: int = 0,
        line_limit: int = 200,
    ) -> dict[str, Any]:
        """Read a verified immutable file, never the project's mutable worktree."""
        if type(line_offset) is not int or line_offset < 0:
            raise DevelopmentProjectError("development_read_line_offset_invalid")
        if type(line_limit) is not int or not 1 <= line_limit <= 2_000:
            raise DevelopmentProjectError("development_read_line_limit_invalid")
        relative = _normalize_relative_path(path)
        body = self.snapshot_file_bytes(snapshot_ref, relative)
        payload = self._snapshot_payload(snapshot_ref)
        target = self._snapshot_files_root(str(payload["snapshot_hash"])) / relative
        try:
            page = read_text_page(target, offset=line_offset, limit=line_limit)
        except UnicodeDecodeError as exc:
            raise DevelopmentProjectError(f"development_read_not_utf8:{relative}") from exc
        return {"snapshot_ref": snapshot_ref, "path": relative,
                "sha256": hashlib.sha256(body).hexdigest(), **page}

    def snapshot_file_bytes(self, snapshot_ref: str, path: str) -> bytes:
        """Read one manifest-authorized file, including binary PDF sources."""
        relative = _normalize_relative_path(path)
        payload = self._snapshot_payload(snapshot_ref)
        item = next((item for item in payload["files"] if item["path"] == relative), None)
        if item is None:
            raise DevelopmentProjectError(f"development_snapshot_file_not_listed:{relative}")
        root = self._snapshot_files_root(str(payload["snapshot_hash"]))
        target = (root / relative).resolve()
        if not target.is_relative_to(root) or not target.is_file():
            raise DevelopmentProjectError(f"development_snapshot_file_missing:{relative}")
        body = target.read_bytes()
        if (hashlib.sha256(body).hexdigest() != item["sha256"]
                or len(body) != item["size_bytes"]):
            raise DevelopmentProjectError(f"development_snapshot_file_integrity_error:{relative}")
        return body

    def output_bytes(self, ref: str) -> bytes:
        return self._output_path(ref).read_bytes()

    def snapshot_payload(self, snapshot_ref: str) -> dict[str, Any]:
        return copy.deepcopy(dict(self._snapshot_payload(snapshot_ref)))

    def resolve_working_directory(self, project_id: str, relative: str = ".") -> Path:
        normalized = _normalize_relative_directory(relative)
        root = self._worktree(project_id)
        target = root if normalized == "." else (root / Path(normalized)).resolve()
        if not target.is_relative_to(root) or not target.is_dir():
            raise DevelopmentProjectError(
                f"development_working_directory_invalid:{relative}"
            )
        return target

    def resolve_file(self, project_id: str, path: str) -> Path:
        return self._existing_file(project_id, path)

    def _project_dir(self, project_id: str) -> Path:
        normalized = str(project_id).strip()
        if _PROJECT_ID.fullmatch(normalized) is None:
            raise DevelopmentProjectError("development_project_id_invalid")
        project_dir = (self.projects_root / normalized).resolve()
        if not project_dir.is_relative_to(self.projects_root) or not project_dir.is_dir():
            raise DevelopmentProjectError(
                f"development_project_not_found:{normalized}"
            )
        return project_dir

    def _worktree(self, project_id: str) -> Path:
        return (self._project_dir(project_id) / "worktree").resolve()

    def _metadata(self, project_id: str) -> dict[str, Any]:
        return json.loads(
            (self._project_dir(project_id) / "project.json").read_text(
                encoding="utf-8"
            )
        )

    def _write_metadata(self, project_id: str, metadata: Mapping[str, Any]) -> None:
        _write_json(self._project_dir(project_id) / "project.json", metadata)

    def _bump_revision(self, project_id: str) -> int:
        metadata = self._metadata(project_id)
        metadata["revision"] = int(metadata["revision"]) + 1
        self._write_metadata(project_id, metadata)
        return int(metadata["revision"])

    def _target(self, project_id: str, path: str) -> Path:
        relative = _normalize_relative_path(path)
        worktree = self._worktree(project_id)
        target = (worktree / Path(relative)).resolve()
        if not target.is_relative_to(worktree) or target == worktree:
            raise DevelopmentProjectError(
                f"development_project_path_escaped:{relative}"
            )
        return target

    def _existing_file(self, project_id: str, path: str) -> Path:
        target = self._target(project_id, path)
        if not target.is_file() or target.is_symlink():
            raise DevelopmentProjectError(
                f"development_project_file_not_found:{_normalize_relative_path(path)}"
            )
        return target

    def _file_manifest(
        self, project_id: str
    ) -> tuple[list[dict[str, Any]], dict[str, bytes]]:
        worktree = self._worktree(project_id)
        files: list[dict[str, Any]] = []
        bodies: dict[str, bytes] = {}
        for path in sorted(worktree.rglob("*")):
            if path.is_symlink():
                raise DevelopmentProjectError("development_project_symlink_forbidden")
            if not path.is_file():
                continue
            if len(files) >= _MAX_PROJECT_FILES:
                raise DevelopmentProjectError("development_project_file_limit")
            body = path.read_bytes()
            if len(body) > _MAX_FILE_BYTES:
                raise DevelopmentProjectError(
                    f"development_project_file_too_large:{path.relative_to(worktree)}"
                )
            relative = path.relative_to(worktree).as_posix()
            digest = hashlib.sha256(body).hexdigest()
            files.append(
                {"path": relative, "sha256": digest, "size_bytes": len(body)}
            )
            bodies[relative] = body
        return files, bodies

    def _snapshot_payload(self, snapshot_ref: str) -> Mapping[str, Any]:
        artifact = self.artifacts.read(snapshot_ref)
        if artifact.get("artifact_kind") != "development_project_snapshot":
            raise DevelopmentProjectError(
                f"development_snapshot_kind_invalid:{snapshot_ref}"
            )
        payload = artifact.get("machine_payload")
        validate_development_project_snapshot(payload)
        assert isinstance(payload, Mapping)
        return payload

    def _snapshot_files_root(self, snapshot_hash: str) -> Path:
        if _SHA256.fullmatch(snapshot_hash) is None:
            raise DevelopmentProjectError("development_snapshot_hash_invalid")
        root = (self.snapshots_root / snapshot_hash / "files").resolve()
        if not root.is_relative_to(self.snapshots_root) or not root.is_dir():
            raise DevelopmentProjectError(
                f"development_snapshot_storage_missing:{snapshot_hash}"
            )
        return root


def validate_development_project_snapshot(payload: Any) -> None:
    if not isinstance(payload, Mapping):
        raise ValueError("development_project_snapshot_must_be_object")
    expected = {
        "artifact_kind",
        "project_id",
        "snapshot_hash",
        "files",
        "entry_command",
        "working_directory",
        "environment_ref",
        "dependency_refs",
    }
    if set(payload) != expected:
        raise ValueError(
            "development_project_snapshot_keys_invalid:"
            f"expected={sorted(expected)}:actual={sorted(payload)}"
        )
    if payload.get("artifact_kind") != "development_project_snapshot":
        raise ValueError("development_project_snapshot_kind_invalid")
    if _PROJECT_ID.fullmatch(str(payload.get("project_id") or "")) is None:
        raise ValueError("development_project_snapshot_project_id_invalid")
    if _SHA256.fullmatch(str(payload.get("snapshot_hash") or "")) is None:
        raise ValueError("development_project_snapshot_hash_invalid")
    files = payload.get("files")
    if not isinstance(files, list) or len(files) > _MAX_PROJECT_FILES:
        raise ValueError("development_project_snapshot_files_invalid")
    seen: set[str] = set()
    for index, raw in enumerate(files):
        if not isinstance(raw, Mapping) or set(raw) != {
            "path",
            "sha256",
            "size_bytes",
        }:
            raise ValueError(f"development_project_snapshot_file_invalid:{index}")
        path = _normalize_relative_path(raw.get("path"))
        if path in seen:
            raise ValueError(f"development_project_snapshot_file_duplicate:{path}")
        seen.add(path)
        if _SHA256.fullmatch(str(raw.get("sha256") or "")) is None:
            raise ValueError(
                f"development_project_snapshot_file_hash_invalid:{index}"
            )
        size = raw.get("size_bytes")
        if isinstance(size, bool) or not isinstance(size, int) or not 0 <= size <= _MAX_FILE_BYTES:
            raise ValueError(
                f"development_project_snapshot_file_size_invalid:{index}"
            )
    _command_argv(payload.get("entry_command"))
    _normalize_relative_directory(payload.get("working_directory"))
    if not str(payload.get("environment_ref") or "").strip():
        raise ValueError("development_project_snapshot_environment_ref_required")
    _dependency_refs(payload.get("dependency_refs"))


def _normalize_relative_path(value: Any) -> str:
    raw = str(value or "").strip().replace("\\", "/")
    path = PurePosixPath(raw)
    if (
        not raw
        or path.is_absolute()
        or raw.startswith("/")
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise DevelopmentProjectError(
            f"development_project_path_invalid:{raw or 'empty'}"
        )
    return path.as_posix()


def _normalize_relative_directory(value: Any) -> str:
    raw = str(value or ".").strip().replace("\\", "/") or "."
    if raw == ".":
        return raw
    return _normalize_relative_path(raw)


def _command_argv(value: Any) -> list[str]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise DevelopmentProjectError("development_entry_command_must_be_array")
    argv = [str(item) for item in value]
    if not argv or not argv[0].strip() or any("\x00" in item for item in argv):
        raise DevelopmentProjectError("development_entry_command_invalid")
    if len(argv) > 128 or sum(len(item) for item in argv) > 16_000:
        raise DevelopmentProjectError("development_entry_command_too_large")
    return argv


def _dependency_refs(value: Any) -> list[str]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise DevelopmentProjectError("development_project_depends_on_must_be_array")
    refs = [str(item).strip() for item in value]
    allowed_prefixes = (
        "artifact:",
        "code_artifact:",
        "approved_route:",
        "pending_route:",
    )
    if any(not ref.startswith(allowed_prefixes) for ref in refs):
        raise DevelopmentProjectError(
            "development_project_dependency_ref_invalid"
        )
    return list(dict.fromkeys(refs))


def _artifact_refs_only(value: Sequence[str]) -> list[str]:
    return [str(ref) for ref in value if str(ref).startswith("artifact:")]


def _read_diff_lines(path: Path) -> list[str]:
    if not path.is_file():
        return []
    try:
        return path.read_text(encoding="utf-8").splitlines(keepends=True)
    except UnicodeDecodeError:
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        return [f"<binary sha256={digest}>\n"]


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _write_text(path: Path, value: str) -> None:
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(value, encoding="utf-8", newline="")
    os.replace(temporary, path)
