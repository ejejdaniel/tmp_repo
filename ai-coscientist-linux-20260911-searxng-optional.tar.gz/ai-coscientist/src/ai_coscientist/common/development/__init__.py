"""Shared multi-file development workspace for authoring skills."""

from .inspection import CodeInspector
from .projects import (
    DevelopmentProjectError,
    DevelopmentProjectStore,
    validate_development_project_snapshot,
)
from .routes import DevelopmentProjectRoutes
from .terminal import DevelopmentTerminalManager

__all__ = [
    "CodeInspector",
    "DevelopmentProjectError",
    "DevelopmentProjectRoutes",
    "DevelopmentProjectStore",
    "DevelopmentTerminalManager",
    "validate_development_project_snapshot",
]
