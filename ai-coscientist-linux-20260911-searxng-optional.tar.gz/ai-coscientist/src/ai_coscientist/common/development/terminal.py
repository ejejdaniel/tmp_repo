from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import threading
import time
import uuid

from pathlib import Path
from typing import Any, Callable, Mapping

from .projects import DevelopmentProjectError, DevelopmentProjectStore


class DevelopmentTerminalManager:
    """Shell sessions rooted in one fixed development-project environment."""

    def __init__(
        self,
        projects: DevelopmentProjectStore,
        *,
        shell_launch: Callable[
            ...,
            tuple[list[str], Path, dict[str, str]],
        ]
        | None = None,
    ) -> None:
        self.projects = projects
        self.shell_launch = shell_launch
        self._lock = threading.RLock()
        self._processes: dict[
            str, tuple[subprocess.Popen[bytes], Any, Any]
        ] = {}
        self._requested_stops: set[str] = set()

    def start(
        self,
        project_id: str,
        *,
        purpose: str,
        command: str,
        working_directory: str,
        timeout_seconds: int,
        wait_seconds: int,
        execution_workspace_ref: str = "",
        readonly_execution_root: Path | None = None,
    ) -> dict[str, Any]:
        normalized_purpose = str(purpose).strip()
        if not normalized_purpose:
            raise DevelopmentProjectError("development_terminal_purpose_required")
        raw_command = str(command)
        if not raw_command.strip():
            raise DevelopmentProjectError("development_terminal_command_required")
        if len(raw_command) > 32_000:
            raise DevelopmentProjectError("development_terminal_command_too_large")
        if not 1 <= timeout_seconds <= 86_400:
            raise DevelopmentProjectError("development_terminal_timeout_invalid")
        if not 0 <= wait_seconds <= 30:
            raise DevelopmentProjectError("development_terminal_wait_invalid")
        cwd = self.projects.resolve_working_directory(
            project_id, working_directory
        )
        if bool(execution_workspace_ref) != (readonly_execution_root is not None):
            raise DevelopmentProjectError("development_execution_workspace_binding_invalid")
        if readonly_execution_root is not None and self.shell_launch is None:
            raise DevelopmentProjectError("development_terminal_readonly_mount_unsupported")
        terminal_id = uuid.uuid4().hex[:16]
        terminal_dir = self._terminal_root(project_id) / terminal_id
        terminal_dir.mkdir(parents=True, exist_ok=False)
        command_path = terminal_dir / "command.txt"
        stdout_path = terminal_dir / "stdout.txt"
        stderr_path = terminal_dir / "stderr.txt"
        command_path.write_text(raw_command.rstrip() + "\n", encoding="utf-8")
        runtime_environment: Mapping[str, str] = {
            "PYTHONIOENCODING": "utf-8",
            "PYTHONUTF8": "1",
        }
        if self.shell_launch is None:
            argv = _host_shell_argv(raw_command)
            launch_cwd = cwd
            env = {**os.environ, **runtime_environment}
        else:
            mount = (
                {"readonly_execution_root": readonly_execution_root}
                if readonly_execution_root is not None else {}
            )
            argv, launch_cwd, env = self.shell_launch(
                project_root=self.projects.worktree(project_id),
                working_directory=str(working_directory),
                command=raw_command,
                environment=runtime_environment,
                **mount,
            )
        stdout_handle = stdout_path.open("wb")
        stderr_handle = stderr_path.open("wb")
        worker_spec_path = terminal_dir / "worker.json"
        worker_spec_path.write_text(
            json.dumps(
                {
                    "argv": list(argv),
                    "cwd": str(launch_cwd),
                },
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        argv = [
            sys.executable,
            str(Path(__file__).with_name("_terminal_worker.py").resolve()),
            str(worker_spec_path),
        ]
        creationflags = (
            subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
        )
        process = subprocess.Popen(
            argv,
            cwd=str(launch_cwd),
            env=env,
            stdout=stdout_handle,
            stderr=stderr_handle,
            creationflags=creationflags,
            start_new_session=os.name != "nt",
        )
        manifest = {
            "terminal_id": terminal_id,
            "project_id": project_id,
            "purpose": normalized_purpose,
            "status": "running",
            "pid": process.pid,
            "return_code": None,
            "timed_out": False,
            "timeout_seconds": timeout_seconds,
            "working_directory": str(cwd),
            "started_at_unix": time.time(),
            "finished_at_unix": None,
        }
        if execution_workspace_ref:
            manifest["execution_workspace_ref"] = execution_workspace_ref
        self._write_manifest(project_id, terminal_id, manifest)
        with self._lock:
            self._processes[terminal_id] = (
                process,
                stdout_handle,
                stderr_handle,
            )
        watcher = threading.Thread(
            target=self._watch,
            args=(project_id, terminal_id, timeout_seconds),
            daemon=True,
            name=f"development-terminal-{terminal_id}",
        )
        watcher.start()
        return self.poll(
            project_id,
            terminal_id,
            wait_seconds=wait_seconds,
            tail_chars=12_000,
        )

    def poll(
        self,
        project_id: str,
        terminal_id: str,
        *,
        wait_seconds: int,
        tail_chars: int,
    ) -> dict[str, Any]:
        if not 0 <= wait_seconds <= 30:
            raise DevelopmentProjectError("development_terminal_wait_invalid")
        if not 1_000 <= tail_chars <= 40_000:
            raise DevelopmentProjectError("development_terminal_tail_invalid")
        process = self._process(terminal_id)
        if process is not None and wait_seconds:
            try:
                process.wait(timeout=wait_seconds)
            except subprocess.TimeoutExpired:
                pass
        self._refresh(project_id, terminal_id)
        manifest = self._manifest(project_id, terminal_id)
        terminal_dir = self._terminal_dir(project_id, terminal_id)
        return {
            "status": f"development_terminal_{manifest['status']}",
            **({"execution_workspace_ref": manifest["execution_workspace_ref"]}
               if manifest.get("execution_workspace_ref") else {}),
            "project_id": project_id,
            "terminal_id": terminal_id,
            "purpose": manifest["purpose"],
            "pid": manifest["pid"],
            "return_code": manifest["return_code"],
            "timed_out": manifest["timed_out"],
            "stdout_tail": _tail_text(terminal_dir / "stdout.txt", tail_chars),
            "stderr_tail": _tail_text(terminal_dir / "stderr.txt", tail_chars),
            "stdout_ref": self.projects.terminal_output_ref(project_id, terminal_id, "stdout"),
            "stderr_ref": self.projects.terminal_output_ref(project_id, terminal_id, "stderr"),
        }

    def stop(self, project_id: str, terminal_id: str) -> dict[str, Any]:
        process = self._process(terminal_id)
        manifest = self._manifest(project_id, terminal_id)
        if manifest["status"] != "running":
            return self.poll(
                project_id, terminal_id, wait_seconds=0, tail_chars=12_000
            )
        if process is None:
            raise DevelopmentProjectError(
                "development_terminal_detached_after_runtime_restart:"
                "inspect_pid_manually_before_stopping"
            )
        with self._lock:
            self._requested_stops.add(terminal_id)
        _terminate_process(process)
        self._finish(project_id, terminal_id, status="stopped", timed_out=False)
        return self.poll(
            project_id, terminal_id, wait_seconds=0, tail_chars=12_000
        )

    def _watch(self, project_id: str, terminal_id: str, timeout_seconds: int) -> None:
        process = self._process(terminal_id)
        if process is None:
            return
        try:
            process.wait(timeout=timeout_seconds)
        except subprocess.TimeoutExpired:
            _terminate_process(process)
            self._finish(project_id, terminal_id, status="timed_out", timed_out=True)
            return
        self._finish(
            project_id,
            terminal_id,
            status="succeeded" if process.returncode == 0 else "failed",
            timed_out=False,
        )

    def _refresh(self, project_id: str, terminal_id: str) -> None:
        process = self._process(terminal_id)
        if process is not None and process.poll() is None:
            return
        manifest = self._manifest(project_id, terminal_id)
        if manifest["status"] != "running":
            return
        completion = self._completion(project_id, terminal_id)
        if process is None and completion is None:
            return
        return_code = (
            int(completion["return_code"])
            if completion is not None
            else int(process.returncode)
        )
        self._finish(
            project_id,
            terminal_id,
            status="succeeded" if return_code == 0 else "failed",
            timed_out=bool(completion.get("timed_out")) if completion else False,
        )

    def _finish(
        self,
        project_id: str,
        terminal_id: str,
        *,
        status: str,
        timed_out: bool,
    ) -> None:
        with self._lock:
            item = self._processes.pop(terminal_id, None)
            manifest = self._manifest(project_id, terminal_id)
            if manifest["status"] != "running":
                if item is not None:
                    item[1].close()
                    item[2].close()
                return
            if terminal_id in self._requested_stops:
                status = "stopped"
                timed_out = False
                self._requested_stops.discard(terminal_id)
            completion = self._completion(project_id, terminal_id)
            return_code = (
                item[0].poll()
                if item is not None
                else (
                    int(completion["return_code"])
                    if completion is not None
                    else None
                )
            )
            if completion is not None and status != "stopped":
                timed_out = bool(completion.get("timed_out"))
                status = (
                    "timed_out"
                    if timed_out
                    else "succeeded"
                    if int(completion["return_code"]) == 0
                    else "failed"
                )
            if item is not None:
                item[1].close()
                item[2].close()
            manifest.update(
                {
                    "status": status,
                    "return_code": return_code,
                    "timed_out": timed_out,
                    "finished_at_unix": (
                        float(completion["finished_at_unix"])
                        if completion is not None
                        else time.time()
                    ),
                }
            )
            self._write_manifest(project_id, terminal_id, manifest)

    def _process(self, terminal_id: str) -> subprocess.Popen[bytes] | None:
        with self._lock:
            item = self._processes.get(str(terminal_id))
            return item[0] if item is not None else None

    def _terminal_root(self, project_id: str) -> Path:
        root = self.projects.worktree(project_id).parent / "terminals"
        root.mkdir(parents=True, exist_ok=True)
        return root.resolve()

    def _terminal_dir(self, project_id: str, terminal_id: str) -> Path:
        raw = str(terminal_id).strip()
        if len(raw) != 16 or any(char not in "0123456789abcdef" for char in raw):
            raise DevelopmentProjectError("development_terminal_id_invalid")
        root = self._terminal_root(project_id)
        target = (root / raw).resolve()
        if not target.is_relative_to(root) or not target.is_dir():
            raise DevelopmentProjectError(
                f"development_terminal_not_found:{raw}"
            )
        return target

    def _manifest(self, project_id: str, terminal_id: str) -> dict[str, Any]:
        return json.loads(
            (self._terminal_dir(project_id, terminal_id) / "manifest.json").read_text(
                encoding="utf-8"
            )
        )

    def _completion(
        self, project_id: str, terminal_id: str
    ) -> dict[str, Any] | None:
        path = self._terminal_dir(project_id, terminal_id) / "completion.json"
        if not path.is_file():
            return None
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value.get("return_code"), int):
            raise DevelopmentProjectError("development_terminal_completion_invalid")
        return value

    def _write_manifest(
        self, project_id: str, terminal_id: str, value: dict[str, Any]
    ) -> None:
        terminal_dir = self._terminal_root(project_id) / terminal_id
        terminal_dir.mkdir(parents=True, exist_ok=True)
        path = terminal_dir / "manifest.json"
        temporary = path.with_suffix(".json.tmp")
        temporary.write_text(
            json.dumps(value, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, path)


def _host_shell_argv(command: str) -> list[str]:
    if os.name == "nt":
        executable = os.environ.get(
            "COMSPEC", r"C:\Windows\System32\cmd.exe"
        )
        powershell = Path(
            r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
        )
        if powershell.is_file():
            return [
                str(powershell),
                "-NoLogo",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                command,
            ]
        return [executable, "/d", "/s", "/c", command]
    return ["/bin/sh", "-lc", command]


def _terminate_process(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    try:
        if os.name == "nt":
            completed = subprocess.run(
                ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if completed.returncode != 0:
                process.terminate()
        else:
            os.killpg(process.pid, signal.SIGTERM)
        process.wait(timeout=5)
    except (OSError, subprocess.TimeoutExpired):
        try:
            if os.name == "nt":
                process.kill()
            else:
                os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=5)
        except (OSError, subprocess.TimeoutExpired):
            pass


def _tail_text(path: Path, max_chars: int) -> str:
    if not path.is_file():
        return ""
    body = path.read_text(encoding="utf-8", errors="replace")
    tail = body[-max_chars:]
    if len(body) > max_chars:
        return "[Earlier output omitted; use read_ref with the stream ref.]\n" + tail
    return tail
