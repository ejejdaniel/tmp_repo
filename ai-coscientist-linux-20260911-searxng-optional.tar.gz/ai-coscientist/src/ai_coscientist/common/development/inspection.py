from __future__ import annotations

import ast
import json
import shutil
import subprocess
import tomllib

from pathlib import Path
from typing import Any, Sequence

from .projects import DevelopmentProjectError, DevelopmentProjectStore


_PYTHON_SUFFIXES = frozenset({".py", ".pyw"})
_JAVASCRIPT_SUFFIXES = frozenset({".js", ".mjs", ".cjs"})
_TYPESCRIPT_SUFFIXES = frozenset({".ts", ".tsx", ".mts", ".cts"})
_C_SUFFIXES = frozenset({".c"})
_CPP_SUFFIXES = frozenset({".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp"})


class CodeInspector:
    """Language-adapter syntax checks and bounded source-structure queries."""

    def __init__(self, projects: DevelopmentProjectStore) -> None:
        self.projects = projects

    def validate_syntax(
        self,
        project_id: str,
        *,
        paths: Sequence[str],
        timeout_seconds: int,
    ) -> dict[str, Any]:
        if not 1 <= timeout_seconds <= 300:
            raise DevelopmentProjectError("development_syntax_timeout_invalid")
        selected = self._selected_files(project_id, paths)
        checks = [
            self._validate_file(path, timeout_seconds=timeout_seconds)
            for path in selected
        ]
        supported = [check for check in checks if check["status"] != "unsupported"]
        status = (
            "failed"
            if any(check["status"] == "failed" for check in supported)
            else "passed"
            if supported
            else "unsupported"
        )
        return {
            "status": f"development_syntax_{status}",
            "project_id": project_id,
            "checks": checks,
        }

    def query_structure(
        self,
        project_id: str,
        *,
        path: str,
        query_kind: str,
        symbol: str,
        max_results: int,
    ) -> dict[str, Any]:
        if query_kind not in {"symbols", "imports", "calls", "references"}:
            raise DevelopmentProjectError("development_code_query_kind_invalid")
        if query_kind == "references" and not symbol.strip():
            raise DevelopmentProjectError(
                "development_code_query_symbol_required"
            )
        if not 1 <= max_results <= 500:
            raise DevelopmentProjectError("development_code_query_limit_invalid")
        source_path = self.projects.resolve_file(project_id, path)
        relative = source_path.relative_to(
            self.projects.worktree(project_id)
        ).as_posix()
        if source_path.suffix.lower() in _PYTHON_SUFFIXES:
            results = _query_python(
                source_path,
                query_kind=query_kind,
                symbol=symbol.strip(),
            )
            return {
                "status": "development_code_query_ready",
                "project_id": project_id,
                "path": relative,
                "language": "python",
                "query_kind": query_kind,
                "results": results[:max_results],
                "truncated": len(results) > max_results,
            }
        if query_kind == "symbols":
            ctags = shutil.which("ctags")
            if ctags:
                results = _query_ctags(ctags, source_path)
                return {
                    "status": "development_code_query_ready",
                    "project_id": project_id,
                    "path": relative,
                    "language": _language_name(source_path),
                    "query_kind": query_kind,
                    "results": results[:max_results],
                    "truncated": len(results) > max_results,
                }
        return {
            "status": "development_code_query_unsupported",
            "project_id": project_id,
            "path": relative,
            "language": _language_name(source_path),
            "query_kind": query_kind,
            "results": [],
            "truncated": False,
            "reason": (
                "No parser adapter is available for this language/query. "
                "Use exact text search or install a parser through the owning "
                "dependency-management skill."
            ),
        }

    def _selected_files(
        self, project_id: str, paths: Sequence[str]
    ) -> list[Path]:
        if paths:
            return [self.projects.resolve_file(project_id, path) for path in paths]
        root = self.projects.worktree(project_id)
        selected = [
            path
            for path in sorted(root.rglob("*"))
            if path.is_file() and not path.is_symlink()
        ]
        if len(selected) > 2_000:
            raise DevelopmentProjectError("development_syntax_file_limit")
        return selected

    def _validate_file(self, path: Path, *, timeout_seconds: int) -> dict[str, Any]:
        suffix = path.suffix.lower()
        language = _language_name(path)
        try:
            if suffix in _PYTHON_SUFFIXES:
                ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
                return _syntax_result(path, language, "passed")
            if suffix == ".json":
                json.loads(path.read_text(encoding="utf-8"))
                return _syntax_result(path, language, "passed")
            if suffix == ".toml":
                tomllib.loads(path.read_text(encoding="utf-8"))
                return _syntax_result(path, language, "passed")
            command = _syntax_command(path)
            if command is None:
                return _syntax_result(
                    path,
                    language,
                    "unsupported",
                    "No syntax adapter is installed for this file type.",
                )
            completed = subprocess.run(
                command,
                cwd=str(path.parent),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout_seconds,
                check=False,
            )
            status = "passed" if completed.returncode == 0 else "failed"
            detail = (completed.stderr or completed.stdout)[-8_000:]
            return _syntax_result(path, language, status, detail)
        except (SyntaxError, json.JSONDecodeError, tomllib.TOMLDecodeError) as exc:
            return _syntax_result(path, language, "failed", str(exc))
        except UnicodeDecodeError as exc:
            return _syntax_result(path, language, "failed", f"not_utf8:{exc}")
        except subprocess.TimeoutExpired:
            return _syntax_result(path, language, "failed", "syntax_check_timed_out")


def _syntax_command(path: Path) -> list[str] | None:
    suffix = path.suffix.lower()
    if suffix in _JAVASCRIPT_SUFFIXES:
        executable = shutil.which("node")
        return [executable, "--check", str(path)] if executable else None
    if suffix in _TYPESCRIPT_SUFFIXES:
        executable = shutil.which("tsc")
        return (
            [executable, "--noEmit", "--pretty", "false", str(path)]
            if executable
            else None
        )
    if suffix == ".sh":
        executable = shutil.which("bash")
        return [executable, "-n", str(path)] if executable else None
    if suffix == ".ps1":
        executable = shutil.which("pwsh") or shutil.which("powershell")
        if not executable:
            return None
        escaped = str(path).replace("'", "''")
        expression = (
            "$errors=$null;"
            f"[System.Management.Automation.Language.Parser]::ParseFile('{escaped}',"
            "[ref]$null,[ref]$errors)>$null;"
            "if($errors.Count){$errors|ForEach-Object{$_.Message};exit 1}"
        )
        return [executable, "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", expression]
    if suffix in _C_SUFFIXES:
        executable = shutil.which("cc") or shutil.which("gcc") or shutil.which("clang")
        return [executable, "-fsyntax-only", str(path)] if executable else None
    if suffix in _CPP_SUFFIXES:
        executable = shutil.which("c++") or shutil.which("g++") or shutil.which("clang++")
        return [executable, "-fsyntax-only", str(path)] if executable else None
    if suffix == ".go":
        executable = shutil.which("gofmt")
        return [executable, "-e", str(path)] if executable else None
    return None


def _query_python(
    path: Path,
    *,
    query_kind: str,
    symbol: str,
) -> list[dict[str, Any]]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    parents: dict[ast.AST, ast.AST] = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parents[child] = parent
    results: list[dict[str, Any]] = []
    for node in ast.walk(tree):
        if query_kind == "symbols":
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                results.append(
                    _node_result(
                        node,
                        kind=(
                            "class"
                            if isinstance(node, ast.ClassDef)
                            else "async_function"
                            if isinstance(node, ast.AsyncFunctionDef)
                            else "function"
                        ),
                        name=node.name,
                    )
                )
            elif isinstance(node, (ast.Assign, ast.AnnAssign)):
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                for target in targets:
                    for name in _target_names(target):
                        results.append(_node_result(node, kind="binding", name=name))
        elif query_kind == "imports":
            if isinstance(node, ast.Import):
                for item in node.names:
                    results.append(
                        _node_result(node, kind="import", name=item.name)
                    )
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for item in node.names:
                    results.append(
                        _node_result(
                            node,
                            kind="import_from",
                            name=f"{module}:{item.name}",
                        )
                    )
        elif query_kind == "calls" and isinstance(node, ast.Call):
            results.append(
                _node_result(node, kind="call", name=_expression_name(node.func))
            )
        elif query_kind == "references" and isinstance(node, ast.Name):
            if node.id == symbol:
                parent = parents.get(node)
                context = (
                    "call"
                    if isinstance(parent, ast.Call) and parent.func is node
                    else type(node.ctx).__name__.lower()
                )
                results.append(_node_result(node, kind=context, name=node.id))
    return sorted(results, key=lambda item: (item["line"], item["column"], item["name"]))


def _query_ctags(executable: str, path: Path) -> list[dict[str, Any]]:
    completed = subprocess.run(
        [executable, "--output-format=json", "--fields=+n", "-f", "-", str(path)],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=30,
        check=False,
    )
    if completed.returncode != 0:
        return []
    results: list[dict[str, Any]] = []
    for line in completed.stdout.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if item.get("_type") != "tag":
            continue
        results.append(
            {
                "kind": str(item.get("kind") or "symbol"),
                "name": str(item.get("name") or ""),
                "line": int(item.get("line") or 0),
                "column": 0,
            }
        )
    return results


def _target_names(node: ast.AST) -> list[str]:
    if isinstance(node, ast.Name):
        return [node.id]
    if isinstance(node, (ast.Tuple, ast.List)):
        return [name for child in node.elts for name in _target_names(child)]
    return []


def _expression_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = _expression_name(node.value)
        return f"{prefix}.{node.attr}" if prefix else node.attr
    return type(node).__name__


def _node_result(node: ast.AST, *, kind: str, name: str) -> dict[str, Any]:
    return {
        "kind": kind,
        "name": name,
        "line": int(getattr(node, "lineno", 0)),
        "column": int(getattr(node, "col_offset", 0)),
    }


def _syntax_result(
    path: Path,
    language: str,
    status: str,
    detail: str = "",
) -> dict[str, Any]:
    return {
        "path": path.name,
        "language": language,
        "status": status,
        "detail": str(detail)[-8_000:],
    }


def _language_name(path: Path) -> str:
    suffix = path.suffix.lower()
    return {
        ".py": "python",
        ".pyw": "python",
        ".json": "json",
        ".toml": "toml",
        ".js": "javascript",
        ".mjs": "javascript",
        ".cjs": "javascript",
        ".ts": "typescript",
        ".tsx": "typescript",
        ".mts": "typescript",
        ".cts": "typescript",
        ".sh": "shell",
        ".ps1": "powershell",
        ".c": "c",
        ".cc": "cpp",
        ".cpp": "cpp",
        ".cxx": "cpp",
        ".h": "c_or_cpp_header",
        ".hh": "cpp_header",
        ".hpp": "cpp_header",
        ".go": "go",
    }.get(suffix, suffix.lstrip(".") or "unknown")
