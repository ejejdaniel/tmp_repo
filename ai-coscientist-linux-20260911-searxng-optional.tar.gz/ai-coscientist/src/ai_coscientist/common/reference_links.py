from __future__ import annotations

import base64
import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Any, Callable, Mapping

from ._runtime_support import exact_string_refs, function_tool
from .text_pages import TEXT_PAGE_BYTES


PREFIX = "reference:v1:"
SOURCE_CONTENT_PREFIXES = ("source_file:", "source_probe:", "workspace_terminal:")
_SOURCE_PREFIXES = ("artifact:", "code_artifact:", "execution_observation:",
                    *SOURCE_CONTENT_PREFIXES, "development_output:")


def evidence_ref_strings(value: Any) -> tuple[str, ...]:
    """Discover exact content identities, not acceptance or workspace authority."""
    return tuple(ref for ref in exact_string_refs(value)
                 if ref.startswith((*_SOURCE_PREFIXES, "workspace:")))


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def _locator(value: Mapping[str, Any], *, hashed: bool) -> dict[str, Any]:
    allowed = {"ref", "path", "field_path", "range"} | ({"content_sha256"} if hashed else set())
    if set(value) - allowed:
        raise ValueError("reference_unknown_field")
    ref = value.get("ref")
    if not isinstance(ref, str) or not ref.startswith(_SOURCE_PREFIXES):
        raise ValueError("reference_source_namespace_invalid")
    result: dict[str, Any] = {"ref": ref}
    if "path" in value:
        path = value["path"]
        if not isinstance(path, str) or not path or "\\" in path or ":" in path:
            raise ValueError("reference_relative_path_invalid:use_snapshot_posix_path")
        parsed = PurePosixPath(path)
        if parsed.is_absolute() or ".." in parsed.parts or str(parsed) != path or path == ".":
            raise ValueError("reference_relative_path_invalid")
        result["path"] = path
    if "field_path" in value:
        pointer = value["field_path"]
        if not isinstance(pointer, str) or (pointer and not pointer.startswith("/")):
            raise ValueError("reference_json_pointer_invalid")
        if re.search(r"~(?![01])", pointer):
            raise ValueError("reference_json_pointer_escape_invalid")
        result["field_path"] = pointer
    if "range" in value:
        span = value["range"]
        if not isinstance(span, Mapping) or set(span) != {"unit", "start", "end"}:
            raise ValueError("reference_range_fields_invalid")
        if span["unit"] not in {"line", "page"} or any(
            type(span[key]) is not int for key in ("start", "end")
        ) or not 1 <= span["start"] <= span["end"]:
            raise ValueError("reference_range_invalid:one_based_inclusive")
        result["range"] = dict(span)
    if hashed:
        digest = value.get("content_sha256")
        if not isinstance(digest, str) or re.fullmatch(r"[0-9a-f]{64}", digest) is None:
            raise ValueError("reference_content_sha256_invalid")
        result["content_sha256"] = digest
    return result


def decode_reference(link: str) -> dict[str, Any]:
    if not isinstance(link, str) or not link.startswith(PREFIX):
        raise ValueError("reference_version_invalid")
    token = link[len(PREFIX):]
    if not re.fullmatch(r"[A-Za-z0-9_-]+", token):
        raise ValueError("reference_encoding_invalid")
    try:
        body = base64.urlsafe_b64decode(token + "=" * (-len(token) % 4))
        value = json.loads(body)
        if not isinstance(value, dict):
            raise ValueError("reference_locator_object_required")
        locator = _locator(value, hashed=True)
        if _encode(locator) != link:
            raise ValueError("reference_encoding_not_canonical")
        return locator
    except (UnicodeError, ValueError) as exc:
        raise ValueError(f"reference_decode_failed:{exc}") from exc


def _encode(locator: Mapping[str, Any]) -> str:
    return PREFIX + base64.urlsafe_b64encode(_json_bytes(locator)).decode("ascii").rstrip("=")


def source_ref(ref: str) -> str:
    return str(decode_reference(ref)["ref"]) if ref.startswith("reference:") else ref


def reference_source_read(tool_name: str, arguments: Mapping[str, Any]) -> dict[str, str] | None:
    """Check a locator against the same read authority as its canonical source."""
    if tool_name == "create_reference_link":
        return {"ref": _locator(arguments, hashed=False)["ref"]}
    ref = arguments.get("ref")
    if tool_name == "read_ref" and isinstance(ref, str) and ref.startswith("reference:"):
        return {"ref": source_ref(ref)}
    return None


def _select_field(value: Any, pointer: str) -> Any:
    if isinstance(value, bytes):
        value = json.loads(value.decode("utf-8"))
    for raw in pointer.split("/")[1:] if pointer else ():
        part = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(value, dict) and part in value:
            value = value[part]
        elif isinstance(value, list) and re.fullmatch(r"0|[1-9][0-9]*", part):
            try:
                value = value[int(part)]
            except IndexError as exc:
                raise ValueError(f"reference_field_missing:{pointer}") from exc
        else:
            raise ValueError(f"reference_field_missing:{pointer}")
    return value


@dataclass(frozen=True)
class ReferenceContent:
    locator: Mapping[str, Any]
    body: bytes
    pdf: bool

    @property
    def label(self) -> str:
        label = str(self.locator.get("path") or self.locator["ref"])
        if self.locator.get("field_path"):
            label += " " + str(self.locator["field_path"])
        if "range" in self.locator:
            span = self.locator["range"]
            label += f" {span['unit']} {span['start']}-{span['end']}"
        return label

    def page_indices(self, count: int) -> range:
        span = self.locator.get("range")
        if span is None:
            return range(count)
        if span["unit"] != "page" or span["end"] > count:
            raise ValueError(f"reference_page_range_invalid:total_pages={count}")
        return range(span["start"] - 1, span["end"])

    def text(self) -> str:
        if self.pdf:
            import pymupdf
            with pymupdf.open(stream=self.body, filetype="pdf") as document:
                text = "\n".join(document[index].get_text() for index in self.page_indices(len(document)))
            if not text.strip():
                raise ValueError("reference_pdf_text_unavailable:original_pages_remain_readable")
            return text
        text = self.body.decode("utf-8")
        span = self.locator.get("range")
        if span is not None:
            lines = text.splitlines(keepends=True)
            if span["unit"] != "line" or span["end"] > len(lines):
                raise ValueError(f"reference_line_range_invalid:total_lines={len(lines)}")
            text = "".join(lines[span["start"] - 1:span["end"]])
        return text


class ReferenceResolver:
    """Locators have no authority. The supplied loader enforces source visibility."""

    def __init__(self, load: Callable[[str, str | None], Any]):
        self._load = load

    def load_source(self, ref: str, path: str | None = None) -> Any:
        return self._load(ref, path)

    def _content(self, locator: Mapping[str, Any], *, verify: bool) -> ReferenceContent:
        value = self.load_source(str(locator["ref"]), locator.get("path"))
        if "field_path" in locator:
            value = _select_field(value, str(locator["field_path"]))
        body = value if isinstance(value, bytes) else (
            value.encode("utf-8") if isinstance(value, str) else _json_bytes(value)
        )
        pdf = body.startswith(b"%PDF-")
        if not pdf:
            body.decode("utf-8")
        digest = hashlib.sha256(body).hexdigest()
        if verify and digest != locator["content_sha256"]:
            raise ValueError(f"reference_content_changed:source={locator['ref']}:actual_sha256={digest}")
        resolved = ReferenceContent({**locator, "content_sha256": digest}, body, pdf)
        if pdf:
            import pymupdf
            with pymupdf.open(stream=body, filetype="pdf") as document:
                resolved.page_indices(len(document))
        else:
            resolved.text()
        return resolved

    def create(self, arguments: Mapping[str, Any]) -> dict[str, str]:
        content = self._content(_locator(arguments, hashed=False), verify=False)
        return {"source_ref": str(content.locator["ref"]),
                "reference_link": _encode(content.locator), "label": content.label}

    def resolve(self, link: str) -> ReferenceContent:
        return self._content(decode_reference(link), verify=True)

    def read(self, link: str, *, line_offset: int = 0, line_limit: int = 200) -> dict[str, Any]:
        if type(line_offset) is not int or line_offset < 0:
            raise ValueError("reference_line_offset_invalid")
        if type(line_limit) is not int or not 1 <= line_limit <= 2000:
            raise ValueError("reference_line_limit_invalid")
        selected = self.resolve(link)
        lines = selected.text().splitlines(keepends=True)
        page: list[str] = []
        size = 0
        for line in lines[line_offset:line_offset + line_limit]:
            length = len(line.encode("utf-8"))
            if page and size + length > TEXT_PAGE_BYTES:
                break
            page.append(line)
            size += length
        next_offset = line_offset + len(page)
        return {"source_ref": selected.locator["ref"], "reference_link": link,
                "content_sha256": selected.locator["content_sha256"],
                "line_offset": line_offset, "line_count": len(page),
                "next_line_offset": next_offset if next_offset < len(lines) else None,
                "total_lines": len(lines), "content": "".join(page)}


def create_reference_link_tool() -> dict[str, Any]:
    return function_tool("create_reference_link",
        "Locate an authorized exact source, optional immutable snapshot path, JSON Pointer "
        "field_path, and 1-based inclusive line/page range. Omit range for the whole selected "
        "content. Runtime generates the hash and reference_link; never construct them yourself. "
        "Use the link in Markdown, but keep source_ref in depends_on/trace_refs/evidence_refs. "
        "A valid link is a locator, not proof of a scientific claim. No nested links.",
        {"type": "object", "properties": {
            "ref": {"type": "string"},
            "path": {"type": "string", "description": "Exact snapshot-relative POSIX file path."},
            "field_path": {"type": "string", "description": "JSON Pointer, e.g. /markdown or /result/stdout."},
            "range": {"type": "object", "properties": {
                "unit": {"type": "string", "enum": ["line", "page"]},
                "start": {"type": "integer", "minimum": 1},
                "end": {"type": "integer", "minimum": 1},
            }, "required": ["unit", "start", "end"], "additionalProperties": False},
        }, "required": ["ref"], "additionalProperties": False})
