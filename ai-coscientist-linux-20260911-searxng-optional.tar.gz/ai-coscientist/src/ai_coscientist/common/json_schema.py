from __future__ import annotations

import copy
import json
import re
from typing import Any, Mapping


def json_schema_issues(
    value: Any,
    schema: Mapping[str, Any],
    *,
    path: str = "$",
) -> list[str]:
    """Return bounded, science-neutral issues for the supported tool-schema subset."""
    issues: list[str] = []
    expected_type = schema.get("type")
    if expected_type and not _matches_json_type(value, str(expected_type)):
        return [f"{path}:expected_{expected_type}"]
    if "enum" in schema and value not in schema["enum"]:
        issues.append(f"{path}:value_not_in_enum")
    alternatives = schema.get("anyOf")
    if isinstance(alternatives, list) and not any(
        not json_schema_issues(value, alternative, path=path)
        for alternative in alternatives
        if isinstance(alternative, Mapping)
    ):
        issues.append(f"{path}:no_matching_any_of")
    if isinstance(value, Mapping):
        properties = schema.get("properties")
        properties = properties if isinstance(properties, Mapping) else {}
        required = schema.get("required")
        required = required if isinstance(required, list) else []
        for key in required:
            if key not in value:
                issues.append(f"{path}.{key}:required")
        additional = schema.get("additionalProperties", True)
        for key, item in value.items():
            child_schema = properties.get(key)
            if isinstance(child_schema, Mapping):
                issues.extend(
                    json_schema_issues(
                        item,
                        child_schema,
                        path=f"{path}.{key}",
                    )
                )
            elif additional is False:
                issues.append(f"{path}.{key}:additional_property_not_allowed")
            elif isinstance(additional, Mapping):
                issues.extend(
                    json_schema_issues(
                        item,
                        additional,
                        path=f"{path}.{key}",
                    )
                )
    elif isinstance(value, list):
        minimum = schema.get("minItems")
        maximum = schema.get("maxItems")
        if isinstance(minimum, int) and len(value) < minimum:
            issues.append(f"{path}:min_items_{minimum}")
        if isinstance(maximum, int) and len(value) > maximum:
            issues.append(f"{path}:max_items_{maximum}")
        item_schema = schema.get("items")
        if isinstance(item_schema, Mapping):
            for index, item in enumerate(value):
                issues.extend(
                    json_schema_issues(
                        item,
                        item_schema,
                        path=f"{path}[{index}]",
                    )
                )
    elif isinstance(value, str):
        minimum = schema.get("minLength")
        maximum = schema.get("maxLength")
        if isinstance(minimum, int) and len(value) < minimum:
            issues.append(f"{path}:min_length_{minimum}")
        if isinstance(maximum, int) and len(value) > maximum:
            issues.append(f"{path}:max_length_{maximum}")
        pattern = schema.get("pattern")
        if isinstance(pattern, str) and re.search(pattern, value) is None:
            issues.append(f"{path}:pattern_mismatch")
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        minimum = schema.get("minimum")
        maximum = schema.get("maximum")
        if isinstance(minimum, (int, float)) and value < minimum:
            issues.append(f"{path}:minimum_{minimum}")
        if isinstance(maximum, (int, float)) and value > maximum:
            issues.append(f"{path}:maximum_{maximum}")
    return issues


def _matches_json_type(value: Any, expected_type: str) -> bool:
    if expected_type == "object":
        return isinstance(value, Mapping)
    if expected_type == "array":
        return isinstance(value, list)
    if expected_type == "string":
        return isinstance(value, str)
    if expected_type == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected_type == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected_type == "boolean":
        return isinstance(value, bool)
    if expected_type == "null":
        return value is None
    return True


def normalize_json_encoded_containers(
    value: Any,
    schema: Mapping[str, Any],
) -> Any:
    """Decode only schema-valid JSON strings standing in for containers."""
    expected_type = str(schema.get("type") or "")
    if isinstance(value, str) and expected_type in {"object", "array"}:
        try:
            decoded = json.loads(value)
        except (TypeError, ValueError):
            return value
        if not _matches_json_type(decoded, expected_type):
            return value
        normalized = normalize_json_encoded_containers(decoded, schema)
        if json_schema_issues(normalized, schema):
            return value
        return normalized

    if isinstance(value, Mapping) and expected_type == "object":
        properties = schema.get("properties")
        properties = properties if isinstance(properties, Mapping) else {}
        additional = schema.get("additionalProperties")
        normalized_object: dict[Any, Any] = {}
        for key, item in value.items():
            child_schema = properties.get(key)
            if not isinstance(child_schema, Mapping) and isinstance(
                additional, Mapping
            ):
                child_schema = additional
            normalized_object[key] = (
                normalize_json_encoded_containers(item, child_schema)
                if isinstance(child_schema, Mapping)
                else copy.deepcopy(item)
            )
        return normalized_object

    if isinstance(value, list) and expected_type == "array":
        item_schema = schema.get("items")
        if isinstance(item_schema, Mapping):
            return [
                normalize_json_encoded_containers(item, item_schema)
                for item in value
            ]
        return copy.deepcopy(value)

    return copy.deepcopy(value)
