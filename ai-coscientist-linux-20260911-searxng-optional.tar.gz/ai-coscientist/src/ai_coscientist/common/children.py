from __future__ import annotations

import copy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Sequence

from .capabilities import normalize_meta_capabilities


class ChildMissionError(ValueError):
    """Raised when a parent mission would leak parent runtime state."""


_FORBIDDEN_MISSION_KEYS = {
    "parent_goal",
    "parent_prompt",
    "parent_memory",
    "parent_wiki",
    "parent_plan",
    "parent_attempts",
    "parent_reasoning",
    "full_parent_workspace",
    "active_plan",
    "attempts",
    "memory",
    "wiki",
    "reasoning",
    "conversation",
    "prompt_history",
}

_WORKSPACE_PRIVATE_DIRECTORY_NAMES = frozenset(
    {
        ".git",
        ".codex",
        ".agents",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        ".venv",
        "agent-local-skills",
        "venv",
        "node_modules",
        "__pycache__",
        "backups",
        "children",
        "observations",
        "raw-inputs",
        "source-probes",
        "tmp",
    }
)
_WORKSPACE_PRIVATE_FILE_NAMES = frozenset(
    {
        "agent-state.json",
        "work-memory.sqlite3",
        "work-memory.sqlite3-journal",
        "work-memory.sqlite3-wal",
        "work-memory.sqlite3-shm",
        "events.jsonl",
        "llm-reasoning-debug.jsonl",
        "observation-index.json",
        "parent-events.jsonl",
        "parent-private-note.txt",
        "parent-state.json",
    }
)


@dataclass(frozen=True)
class MissionWorkspacePathPolicy:
    """One mechanical visibility policy shared by prompt and source routes."""

    excluded_relative_paths: tuple[str, ...] = ()

    def allows_relative(self, relative_path: str | Path) -> bool:
        value = str(relative_path).strip().replace("\\", "/").strip("/")
        parts = tuple(part for part in value.split("/") if part and part != ".")
        lowered_parts = {part.casefold() for part in parts}
        if lowered_parts & _WORKSPACE_PRIVATE_DIRECTORY_NAMES:
            return False
        lowered_name = parts[-1].casefold() if parts else ""
        if lowered_name in _WORKSPACE_PRIVATE_FILE_NAMES:
            return False
        if lowered_name.endswith((".log", ".tmp", ".pyc")):
            return False
        lowered_value = "/".join(parts).casefold()
        for raw_excluded in self.excluded_relative_paths:
            excluded = (
                str(raw_excluded)
                .strip()
                .replace("\\", "/")
                .strip("/")
                .casefold()
            )
            if excluded and (
                lowered_value == excluded
                or lowered_value.startswith(f"{excluded}/")
            ):
                return False
        return True

    def ripgrep_exclusion_globs(self) -> tuple[str, ...]:
        """Project the same policy into ripgrep's mechanical path filters."""
        globs: list[str] = []
        for name in sorted(_WORKSPACE_PRIVATE_DIRECTORY_NAMES):
            globs.extend((f"!{name}/**", f"!**/{name}/**"))
        for name in sorted(_WORKSPACE_PRIVATE_FILE_NAMES):
            globs.extend((f"!{name}", f"!**/{name}"))
        for suffix in ("*.log", "*.tmp", "*.pyc"):
            globs.extend((f"!{suffix}", f"!**/{suffix}"))
        for raw_excluded in self.excluded_relative_paths:
            value = str(raw_excluded).strip().replace("\\", "/").strip("/")
            if value:
                globs.extend((f"!{value}", f"!{value}/**"))
        return tuple(dict.fromkeys(globs))

    def allows(self, path: Path, *, root: Path) -> bool:
        resolved_root = root.resolve()
        try:
            resolved = path.resolve()
        except OSError:
            return False
        if not resolved.is_relative_to(resolved_root):
            return False
        relative = resolved.relative_to(resolved_root)
        return self.allows_relative(relative)


@dataclass(frozen=True)
class MissionWorkspace:
    """Resolve one mission-scoped workspace authority for prompts and routes."""

    root: Path | None = None
    refs: tuple[str, ...] = ()
    discover: bool = False
    max_entries: int = 256
    excluded_relative_paths: tuple[str, ...] = ()

    def resolve(self) -> "ResolvedMissionWorkspace":
        root = self.root.resolve() if self.root is not None else None
        path_policy = MissionWorkspacePathPolicy(
            excluded_relative_paths=tuple(self.excluded_relative_paths)
        )
        if root is None:
            return ResolvedMissionWorkspace(
                root=None,
                mode="unconfigured",
                entries=(),
                path_policy=path_policy,
                reason="parent_did_not_supply_a_workspace_root",
            )
        if not root.is_dir():
            raise ChildMissionError(f"child_workspace_root_not_directory:{root}")

        if self.refs and not self.discover:
            entries = tuple(
                self._ref_projection(root, ref, path_policy=path_policy)
                for ref in self.refs
            )
            return ResolvedMissionWorkspace(
                root=root,
                mode="allowlist",
                entries=entries,
                path_policy=path_policy,
            )

        if not self.discover:
            return ResolvedMissionWorkspace(
                root=root,
                mode="allowlist",
                entries=(),
                path_policy=path_policy,
            )

        entries: list[dict[str, Any]] = []
        truncated = False
        seen_paths: set[str] = set()
        for ref in self.refs:
            item = self._ref_projection(root, ref, path_policy=path_policy)
            relative_path = str(item.get("relative_path") or "")
            if relative_path:
                seen_paths.add(relative_path)
            entries.append(item)
        for path in sorted(root.iterdir(), key=lambda item: str(item).lower()):
            if len(entries) >= self.max_entries:
                truncated = True
                break
            if not path_policy.allows(path, root=root):
                continue
            relative_path = path.relative_to(root).as_posix()
            if relative_path in seen_paths:
                continue
            if path.is_dir():
                entries.append(
                    {
                        "ref": f"workspace:{relative_path}/",
                        "relative_path": f"{relative_path}/",
                    }
                )
                continue
            if not path.is_file():
                continue
            try:
                stat = path.stat()
            except OSError:
                continue
            entries.append(
                {
                    "ref": f"workspace:{path.relative_to(root).as_posix()}",
                    "relative_path": relative_path,
                    "bytes": int(stat.st_size),
                }
            )
        return ResolvedMissionWorkspace(
            root=root,
            mode="discovery",
            entries=tuple(entries),
            truncated=truncated,
            path_policy=path_policy,
        )

    def projection(self) -> dict[str, Any]:
        return self.resolve().projection()

    @staticmethod
    def _ref_projection(
        root: Path,
        ref: str,
        *,
        path_policy: MissionWorkspacePathPolicy,
    ) -> dict[str, Any]:
        value = str(ref).strip()
        item: dict[str, Any] = {"ref": value}
        relative_value = value.removeprefix("workspace:")
        candidate = (root / relative_value).resolve()
        if (
            candidate.is_relative_to(root)
            and (candidate.is_file() or candidate.is_dir())
            and path_policy.allows(candidate, root=root)
        ):
            try:
                item.update(
                    {
                        "relative_path": candidate.relative_to(root).as_posix(),
                        **({"bytes": int(candidate.stat().st_size)} if candidate.is_file() else {}),
                    }
                )
            except OSError:
                item["status"] = "unreadable"
        else:
            item["status"] = "non_filesystem_ref"
        return item


@dataclass(frozen=True)
class ResolvedMissionWorkspace:
    """Immutable search scope shared by child prompts and source routes."""

    root: Path | None
    mode: str
    entries: tuple[Mapping[str, Any], ...]
    path_policy: MissionWorkspacePathPolicy = field(
        default_factory=MissionWorkspacePathPolicy
    )
    truncated: bool = False
    reason: str = ""

    @property
    def allowed_relative_paths(self) -> tuple[str, ...]:
        if self.mode == "discovery" and self.root is not None:
            return (".",)
        return tuple(
            dict.fromkeys(
                str(item.get("relative_path") or "").strip()
                for item in self.entries
                if not item.get("status")
                and str(item.get("relative_path") or "").strip()
            )
        )

    def projection(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "mode": self.mode,
            "root": str(self.root) if self.root is not None else None,
            "content_policy": "ref_and_manifest_only",
            "refs": [copy.deepcopy(dict(item)) for item in self.entries],
        }
        if self.mode == "discovery":
            result["truncated"] = bool(self.truncated)
        if self.reason:
            result["reason"] = self.reason
        return result


@dataclass(frozen=True)
class ChildMission:
    """A child-owned task packet, intentionally separate from parent state."""

    objective: str
    evaluation_summary: str
    enabled_meta_capabilities: tuple[str, ...] = ()
    mission_context: Mapping[str, Any] = field(default_factory=dict)
    artifact_refs: tuple[str, ...] = ()
    work_entry_refs: tuple[str, ...] = ()
    workspace_refs: tuple[str, ...] = ()
    workspace_root: Path | None = None
    allow_workspace_discovery: bool | None = None

    def __post_init__(self) -> None:
        objective = str(self.objective).strip()
        evaluation = str(self.evaluation_summary).strip()
        if not objective:
            raise ChildMissionError("child_objective_required")
        if not evaluation:
            raise ChildMissionError("child_evaluation_summary_required")
        try:
            normalized_capabilities = normalize_meta_capabilities(
                self.enabled_meta_capabilities
            )
        except ValueError as exc:
            raise ChildMissionError(
                f"child_enabled_meta_capabilities_invalid:{exc}"
            ) from exc
        if tuple(self.enabled_meta_capabilities) != normalized_capabilities:
            raise ChildMissionError(
                "child_enabled_meta_capabilities_not_normalized"
            )
        if not isinstance(self.mission_context, Mapping):
            raise ChildMissionError("child_mission_context_must_be_object")
        _check_context_keys(self.mission_context)
        _validate_refs(self.artifact_refs, "artifact")
        if isinstance(self.work_entry_refs, (str, bytes)) or any(
            not isinstance(ref, str) or not ref.startswith("work_entry:")
            for ref in self.work_entry_refs
        ):
            raise ChildMissionError("child_work_entry_refs_invalid")
        _validate_refs(self.workspace_refs, "workspace")
        if self.allow_workspace_discovery is not None and not isinstance(
            self.allow_workspace_discovery, bool
        ):
            raise ChildMissionError("child_workspace_discovery_must_be_boolean")

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any], *, default_root: Path) -> "ChildMission":
        if not isinstance(payload, Mapping):
            raise ChildMissionError("child_mission_payload_must_be_object")
        raw_refs = payload.get("artifact_refs") or ()
        raw_work_refs = payload.get("work_entry_refs") or ()
        if not isinstance(raw_work_refs, Sequence) or isinstance(raw_work_refs, (str, bytes)):
            raise ChildMissionError("child_work_entry_refs_must_be_array")
        raw_workspace_refs = payload.get("workspace_refs") or ()
        raw_meta_capabilities = payload.get("enabled_meta_capabilities") or ()
        if not isinstance(raw_refs, Sequence) or isinstance(raw_refs, (str, bytes)):
            raise ChildMissionError("child_artifact_refs_must_be_array")
        if not isinstance(raw_workspace_refs, Sequence) or isinstance(
            raw_workspace_refs, (str, bytes)
        ):
            raise ChildMissionError("child_workspace_refs_must_be_array")
        if not isinstance(raw_meta_capabilities, Sequence) or isinstance(
            raw_meta_capabilities, (str, bytes)
        ):
            raise ChildMissionError(
                "child_enabled_meta_capabilities_must_be_array"
            )
        root_value = payload.get("workspace_root")
        root = Path(str(root_value)).resolve() if root_value else default_root
        discovery = payload.get("allow_workspace_discovery")
        context = payload.get("mission_context") or {}
        if not isinstance(context, Mapping):
            raise ChildMissionError("child_mission_context_must_be_object")
        return cls(
            objective=str(payload.get("objective") or ""),
            evaluation_summary=str(payload.get("evaluation_summary") or ""),
            enabled_meta_capabilities=normalize_meta_capabilities(
                tuple(str(value).strip() for value in raw_meta_capabilities)
            ),
            mission_context=copy.deepcopy(dict(context)),
            artifact_refs=tuple(str(ref).strip() for ref in raw_refs),
            work_entry_refs=tuple(str(ref).strip() for ref in raw_work_refs),
            workspace_refs=tuple(str(ref).strip() for ref in raw_workspace_refs),
            workspace_root=root,
            allow_workspace_discovery=discovery,
        )

    def workspace(
        self,
        *,
        excluded_relative_paths: Sequence[str] = (),
    ) -> MissionWorkspace:
        discover = self.allow_workspace_discovery
        if discover is None:
            discover = not self.workspace_refs
        return MissionWorkspace(
            root=self.workspace_root,
            refs=tuple(self.workspace_refs),
            discover=bool(discover),
            excluded_relative_paths=tuple(
                str(path).strip()
                for path in excluded_relative_paths
                if str(path).strip()
            ),
        )

    def prompt_projection(
        self,
        *,
        workspace: ResolvedMissionWorkspace | None = None,
    ) -> dict[str, Any]:
        resolved_workspace = workspace or self.workspace().resolve()
        return {
            "objective": self.objective,
            "evaluation_summary": self.evaluation_summary,
            "enabled_meta_capabilities": list(
                self.enabled_meta_capabilities
            ),
            "mission_context": copy.deepcopy(dict(self.mission_context)),
            "mounted_refs": list(self.artifact_refs),
            "work_entry_refs": list(self.work_entry_refs),
            "workspace": resolved_workspace.projection(),
            "white_room": {
                "parent_prompt": "not mounted",
                "parent_memory": "not mounted",
                "parent_wiki": "not mounted",
                "parent_plan": "not mounted",
                "parent_attempts": "not mounted",
                "parent_private_reasoning": "not mounted",
            },
        }


def _check_context_keys(value: Mapping[str, Any], *, path: str = "mission_context") -> None:
    for key, child in value.items():
        normalized = str(key).strip().lower()
        if normalized in _FORBIDDEN_MISSION_KEYS:
            raise ChildMissionError(f"child_mission_context_inherits_parent_state:{path}.{key}")
        if isinstance(child, Mapping):
            _check_context_keys(child, path=f"{path}.{key}")
        elif isinstance(child, Sequence) and not isinstance(child, (str, bytes)):
            for index, item in enumerate(child):
                if isinstance(item, Mapping):
                    _check_context_keys(item, path=f"{path}.{key}[{index}]")


def _validate_refs(refs: Sequence[str], label: str) -> None:
    for ref in refs:
        if not str(ref).strip():
            raise ChildMissionError(f"child_{label}_ref_must_not_be_empty")
