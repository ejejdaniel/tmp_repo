from __future__ import annotations

from typing import Any, Mapping, Sequence


class InvocationTrackingMixin:
    """Track exact refs used and produced during one selected skill invocation."""

    def _pending_readback_ref(self) -> str:
        pending = self._pending_readback_refs()
        return pending[0] if pending else ""

    def _pending_readback_refs(self) -> tuple[str, ...]:
        """Return every immutable output still awaiting exact readback."""
        pending: list[str] = []
        for event in self._events.read():
            if event.get("event_type") != "tool_result":
                continue
            # Fixed skill workflows own their internal route readback. Applying
            # the main-agent pending receipt across that encapsulation can leave
            # a skill-scoped source ref pending after the skill is released.
            if event.get("source") == "skill_workflow":
                continue
            tool = str(event.get("tool", ""))
            result = event.get("raw_result")
            if not isinstance(result, Mapping):
                continue
            produced_refs: tuple[str, ...] = ()
            if tool == "artifact_publish" and result.get("artifact_ref"):
                produced_refs = (str(result.get("artifact_ref") or ""),)
            elif tool in {"write_code_artifact", "edit_code_artifact"}:
                produced_refs = (str(result.get("code_artifact_ref") or ""),)
            elif tool == "development_project_checkpoint":
                produced_refs = (str(result.get("snapshot_ref") or ""),)
            elif tool == "source_probe":
                status = str(result.get("status") or "")
                if status == "source_probe_succeeded":
                    produced_refs = (str(result.get("stdout_ref") or ""),)
                elif status in {
                    "source_probe_failed",
                    "source_probe_timed_out",
                }:
                    produced_refs = (
                        str(result.get("code_ref") or ""),
                        str(result.get("stderr_ref") or ""),
                    )
            if produced_refs:
                for produced_ref in produced_refs:
                    if produced_ref and produced_ref not in pending:
                        pending.append(produced_ref)
                continue
            if tool not in {"read_ref", "artifact_read", "source_read"}:
                continue
            read_ref = ""
            if result.get("status") == "source_page_ready":
                read_ref = str(result.get("source_ref") or "")
            elif result.get("status") == "artifact_resolved":
                read_ref = str(result.get("artifact_ref") or "")
            if read_ref in pending:
                pending.remove(read_ref)
        return tuple(pending)

    def _active_invocation_load_event(self, skill_id: str) -> Mapping[str, Any] | None:
        """Return the existing authoritative load receipt, not later read refs."""
        for event in reversed(self._events.read()):
            if (
                event.get("event_type") != "tool_result"
                or event.get("tool") != "load_skill"
            ):
                continue
            result = event.get("raw_result")
            if not isinstance(result, Mapping):
                continue
            if result.get("status") != "skill_loaded":
                continue
            if str(result.get("skill_id") or "") != skill_id:
                continue
            return event
        return None

    def _active_invocation_seed_refs(self, skill_id: str) -> tuple[str, ...]:
        """Return ordered exact refs read at the boundary that selected this skill."""
        event = self._active_invocation_load_event(skill_id)
        if event is None:
            return ()
        load_sequence = int(event.get("event_sequence", 0))
        result = event["raw_result"]
        if "input_refs" in result:
            raw_refs = result.get("input_refs")
            if isinstance(raw_refs, Sequence) and not isinstance(raw_refs, (str, bytes)):
                return tuple(
                    dict.fromkeys(
                        str(ref).strip() for ref in raw_refs if str(ref).strip()
                    )
                )
            return ()

        # Compatibility for event logs created before load_skill recorded its
        # exact invocation input refs.
        events = self._events.read()
        lower_boundary = 0
        for event in reversed(events):
            sequence = int(event.get("event_sequence", 0))
            if sequence >= load_sequence:
                continue
            if event.get("event_type") == "skill_context_released":
                lower_boundary = sequence
                break

        refs: list[str] = []
        for event in events:
            sequence = int(event.get("event_sequence", 0))
            if sequence <= lower_boundary or sequence >= load_sequence:
                continue
            if (
                event.get("event_type") != "tool_result"
                or event.get("tool") not in {"read_ref", "artifact_read"}
            ):
                continue
            result = event.get("raw_result")
            if not isinstance(result, Mapping):
                continue
            if result.get("status") != "artifact_resolved":
                continue
            artifact_ref = str(result.get("artifact_ref") or "")
            if artifact_ref and artifact_ref not in refs:
                refs.append(artifact_ref)
        return tuple(refs)
    def _active_invocation_artifact_refs(self, skill_id: str) -> tuple[str, ...]:
        events = self._events.read()
        boundary_sequence = 0
        for event in reversed(events):
            if (
                event.get("event_type") != "tool_result"
                or event.get("tool") != "load_skill"
            ):
                continue
            result = event.get("raw_result")
            if not isinstance(result, Mapping):
                continue
            if result.get("status") != "skill_loaded":
                continue
            if str(result.get("skill_id") or "") != skill_id:
                continue
            boundary_sequence = int(event.get("event_sequence", 0))
            break
        refs: list[str] = []
        for event in events:
            if int(event.get("event_sequence", 0)) <= boundary_sequence:
                continue
            if event.get("event_type") != "tool_result":
                continue
            result = event.get("raw_result")
            if not isinstance(result, Mapping):
                continue
            candidate_refs: tuple[str, ...] = ()
            if event.get("tool") == "artifact_publish":
                artifact_ref = str(result.get("artifact_ref") or "")
                candidate_refs = (artifact_ref,) if artifact_ref else ()
            elif (
                event.get("tool") == "development_project_checkpoint"
                and result.get("status")
                == "development_project_checkpoint_created"
            ):
                snapshot_ref = str(result.get("snapshot_ref") or "")
                candidate_refs = (snapshot_ref,) if snapshot_ref else ()
            elif event.get("tool") == "review_child_result":
                review = result.get("review")
                if (
                    isinstance(review, Mapping)
                    and review.get("decision") == "accept"
                ):
                    accepted = review.get("accepted_artifact_refs")
                    if isinstance(accepted, (list, tuple)):
                        candidate_refs = tuple(
                            str(ref) for ref in accepted if str(ref)
                        )
            for artifact_ref in candidate_refs:
                if artifact_ref not in refs:
                    refs.append(artifact_ref)
        return tuple(refs)

    def _active_invocation_read_ref(self, skill_id: str) -> str:
        boundary_sequence = 0
        events = self._events.read()
        for event in reversed(events):
            if (
                event.get("event_type") != "tool_result"
                or event.get("tool") != "load_skill"
            ):
                continue
            result = event.get("raw_result")
            if not isinstance(result, Mapping):
                continue
            if result.get("status") != "skill_loaded":
                continue
            if str(result.get("skill_id") or "") != skill_id:
                continue
            boundary_sequence = int(event.get("event_sequence", 0))
            break
        for index in range(len(events) - 1, -1, -1):
            event = events[index]
            if int(event.get("event_sequence", 0)) <= boundary_sequence:
                return ""
            if (
                event.get("event_type") != "tool_result"
                or event.get("tool") not in {"read_ref", "artifact_read"}
            ):
                continue
            result = event.get("raw_result")
            if not isinstance(result, Mapping):
                continue
            if result.get("status") != "artifact_resolved":
                continue
            artifact_ref = str(result.get("artifact_ref") or "")
            for previous in reversed(events[:index]):
                if int(previous.get("event_sequence", 0)) <= boundary_sequence:
                    return artifact_ref
                if previous.get("event_type") != "tool_result":
                    continue
                previous_result = previous.get("raw_result")
                if (
                    previous.get("tool") == "artifact_publish"
                    and isinstance(previous_result, Mapping)
                    and str(previous_result.get("artifact_ref") or "") == artifact_ref
                ):
                    return ""
                break
            return artifact_ref
        return ""
