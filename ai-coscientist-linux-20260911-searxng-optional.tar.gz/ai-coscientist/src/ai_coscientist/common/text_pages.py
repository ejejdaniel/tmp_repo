from __future__ import annotations

from pathlib import Path
from typing import Any


TEXT_PAGE_BYTES = 8 * 1024


def read_text_page(
    path: Path,
    *,
    offset: int,
    limit: int,
    errors: str = "strict",
) -> dict[str, Any]:
    """Page whole lines using the same universal newlines as the text editor.

    A single oversized line is returned whole so a line-only cursor never skips
    part of a line. The byte target bounds multi-line pages, not individual lines.
    """
    if offset < 0 or limit < 1:
        raise ValueError("text_page_range_invalid")
    selected: list[str] = []
    size = 0
    total = 0
    complete = False
    with path.open("r", encoding="utf-8", errors=errors) as handle:
        for index, line in enumerate(handle):
            total = index + 1
            if index < offset or complete:
                continue
            line_size = len(line.encode("utf-8"))
            if len(selected) >= limit or (
                selected and size + line_size > TEXT_PAGE_BYTES
            ):
                complete = True
                continue
            selected.append(line)
            size += line_size
    next_offset = offset + len(selected)
    return {
        "line_offset": offset,
        "line_count": len(selected),
        "next_line_offset": next_offset if next_offset < total else None,
        "total_lines": total,
        "content": "".join(selected),
    }
