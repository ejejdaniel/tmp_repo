from __future__ import annotations

import copy
import json
from dataclasses import replace

from typing import Any, Mapping, Sequence

from ._runtime_support import (
    exact_string_refs as _exact_string_refs,
    function_tool as _function_tool,
    latest_failed_tool_name as _latest_failed_tool_name,
    observation_current_state_identity as _observation_current_state_identity,
    result_establishes_progress as _result_establishes_progress,
    task_work_skill_cards as _task_work_skill_cards,
)
from ._runtime_tool_specs import (
    execute_node_locally_tool as _execute_node_locally_tool,
    read_ref_tool as _read_ref_tool,
    review_child_result_tool as _review_child_result_tool,
    spawn_child_tool as _spawn_child_tool,
)
from .capabilities import require_child_capability_subset
from .children import ChildMission
from .json_schema import json_schema_issues
from .memory_lifecycle.policy import (
    PromptSource,
    artifact_dependency_closure_refs,
    current_observation_refs,
    related_observation_refs,
)
from .memory_lifecycle.prompt import (
    bounded_projection,
    bounded_text,
    tool_result_prompt_projection,
    tool_receipt_projection,
    preserve_tool_result,
    visible_development_output_refs,
)
from .model import ToolCall, complete_model_turn
from .planning import GRAPH_REVISION_OUTCOME_KIND, active_work_unit
from .planning.node_loop import (
    NodeLoopStepCallLimitError,
    current_step_input_refs,
    next_skill_id,
)
from .sub_loop_toolkit import human_input_tool
from .sub_loop_toolkit import HumanInteractionPause
from .reference_links import ReferenceResolver, create_reference_link_tool, reference_source_read


_TOOL_PAYLOAD_REPAIR_SYSTEM_PROMPT = """Repair the arguments for one already-selected tool.
Return exactly one call to the same tool with the complete corrected arguments.
Preserve every valid value and fix only the listed validation issues.
Preserve every valid exact reference. If validation rejects a reference and the
tool schema enumerates allowed exact references, select the intended unchanged
identity from that enumeration; never invent or fuzzily infer a reference.
Do not change the action, scientific objective, or method.
Do not inspect new data, select another action, or explain the answer in prose."""

_TOOL_DISPATCH_REPAIR_SYSTEM_PROMPT = """Repair one failed low-level tool operation.
The scientific action and authored file content are frozen. Return exactly one
call to the supplied replacement tool. Preserve the exact project id, path,
current file body, and intended replacement body supplied by Runtime. Do not
inspect anything else, alter the implementation, or explain the answer in prose."""

_MAX_TOOL_PAYLOAD_REPAIR_PASSES = 2
_MAX_LOCAL_FILE_REPAIR_BYTES = 64 * 1024
_PYTHON_BODY_OWNING_TOOLS = frozenset({"source_probe", "write_code_artifact"})


def _tool_schema_arguments(call: ToolCall) -> Mapping[str, Any]:
    """Treat an empty optional review as omitted during schema validation."""
    arguments = call.arguments
    if call.name != "artifact_publish":
        return arguments
    self_review = arguments.get("self_review")
    if self_review is not None and not (
        isinstance(self_review, str) and not self_review.strip()
    ):
        return arguments
    if "self_review" not in arguments:
        return arguments
    normalized = dict(arguments)
    normalized.pop("self_review", None)
    return normalized


def _matches_frozen_text_argument(actual: Any, expected: str) -> bool:
    """Allow only the common tool-serialization loss of one terminal newline."""

    if not isinstance(actual, str):
        return False
    return actual == expected or (expected.endswith("\n") and actual == expected[:-1])


def _artifact_publish_payload_source_issue(
    arguments: Mapping[str, Any],
) -> str:
    machine_payload = arguments.get("machine_payload")
    if isinstance(machine_payload, Mapping) and bool(machine_payload):
        return ""
    observation_ref = arguments.get("machine_payload_observation_ref")
    if isinstance(observation_ref, str) and observation_ref.strip():
        return ""
    return "machine_payload_required_for_authored_artifact"


def _artifact_publish_repair_tool_spec(
    call: ToolCall,
    *,
    tool_spec: Mapping[str, Any],
    payload_schema: Mapping[str, Any] | None,
) -> Mapping[str, Any]:
    """Narrow one authored-artifact repair to its registered payload shape."""
    if (
        call.name != "artifact_publish"
        or payload_schema is None
        or str(call.arguments.get("machine_payload_observation_ref") or "").strip()
    ):
        return tool_spec

    repair_spec = copy.deepcopy(dict(tool_spec))
    function = repair_spec.get("function")
    if not isinstance(function, dict):
        return tool_spec
    parameters = function.get("parameters")
    if not isinstance(parameters, dict):
        return tool_spec
    properties = parameters.get("properties")
    if not isinstance(properties, dict):
        return tool_spec

    narrowed_payload_schema = copy.deepcopy(dict(payload_schema))
    generic_payload_schema = properties.get("machine_payload")
    if (
        isinstance(generic_payload_schema, Mapping)
        and "description" in generic_payload_schema
        and "description" not in narrowed_payload_schema
    ):
        narrowed_payload_schema["description"] = generic_payload_schema["description"]
    artifact_kind = str(call.arguments.get("artifact_kind") or "").strip()
    if artifact_kind:
        properties["artifact_kind"] = {
            "type": "string",
            "enum": [artifact_kind],
        }
    properties["machine_payload"] = narrowed_payload_schema
    required = list(parameters.get("required") or ())
    if "machine_payload" not in required:
        required.append("machine_payload")
    parameters["required"] = required
    return repair_spec


class ToolRuntimeMixin:
    """Tool exposure, dispatch, receipts, and exact-ref activation."""

    def _tool_specs(
        self,
        *,
        projection_tier: str = "normal",
        prompt_messages: Sequence[Mapping[str, Any]] | None = None,
    ) -> list[dict[str, Any]]:
        pending_readback_ref = self._pending_readback_ref()
        state = self._state.read()
        formal_artifact_index = self._prompt_artifact_index(
            projection_tier=projection_tier
        )
        visible_read_refs = _visible_read_refs(
            state,
            formal_artifact_index=formal_artifact_index,
        )
        active_skill_id = str(state["c1"]["active_skill_id"] or "")
        disclosure_context: Mapping[str, Any] | None = None
        if active_skill_id:
            resolved_artifacts: list[dict[str, Any]] = []
            for artifact_ref in state["c1"]["resolved_artifact_refs"]:
                try:
                    resolved_artifacts.append(self._read_exact_ref(artifact_ref))
                except (KeyError, OSError, PermissionError, ValueError):
                    continue
            disclosure_context = self._selected_skill_disclosure_context(
                active_skill_id,
                resolved_artifacts=resolved_artifacts,
                artifact_index=formal_artifact_index,
            )
            disclosed_refs = self._skills.disclosure_visible_refs(
                active_skill_id,
                disclosure_context,
            )
            if disclosed_refs is not None:
                # Artifact disclosure must not discard exact transient handles
                # returned by authorized tools in this invocation.
                transient_refs = [ref for ref in visible_read_refs if ref.startswith(
                    (
                        "source_file:",
                        "source_probe:",
                        "workspace_terminal:",
                        "reference:v1:",
                    )
                )]
                visible_read_refs = _readable_exact_refs(
                    disclosed_refs, transient_refs
                )
        output_refs = visible_development_output_refs(
            prompt_messages if prompt_messages is not None else self._memory.recent_messages()
        )
        visible_read_refs = _readable_exact_refs(
            visible_read_refs,
            [ref for ref in output_refs if not self._mission
             or ref in self._owned_external_refs or ref in self._mounted_external_refs],
            sorted(ref for ref in self._mounted_external_refs if ref.startswith("development_output:")),
        )
        if prompt_messages is not None and visible_read_refs:
            visible_read_refs = self._read_refs_available_for_prompt(
                visible_read_refs,
                prompt_messages,
            )
        active_node = active_work_unit(state["c1"]["plan_graph"])
        loop_state = state["c1"]["node_loop_state"]
        planned_skill_id = (
            next_skill_id(loop_state, node_id=str(active_node["node_id"]))
            if active_node is not None
            else ""
        )
        selectable_skill_ids = (
            [planned_skill_id]
            if not active_skill_id and planned_skill_id
            else [
                card.skill_id
                for card in _task_work_skill_cards(
                    self._skills,
                    getattr(self, "_task_formulation_skill_id", ""),
                )
            ]
        )

        def with_human_input(
            specs: list[dict[str, Any]],
        ) -> list[dict[str, Any]]:
            specs.append(_function_tool(
                "work_memory_list", "Search owned work contexts or exact work records. "
                "These are unverified notes and operation receipts, not formal C2 artifacts.",
                {"type": "object", "properties": {
                    "context_ref": {"type": "string"}, "query": {"type": "string"},
                    "cursor": {"type": "integer", "minimum": 0},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 20},
                }, "additionalProperties": False},
            ))
            work_ref_schema = {"anyOf": [
                {"type": "string", "pattern": "^work_(context|entry):[a-f0-9]+$"},
            ]}
            read_spec = next((spec for spec in specs if spec["function"]["name"] == "read_ref"), None)
            if read_spec is None:
                specs.append(_function_tool(
                    "read_ref", "Read an authorized work context or immutable work record.",
                    {"type": "object", "properties": {
                        "ref": work_ref_schema,
                        "line_offset": {"type": "integer", "minimum": 0},
                        "line_limit": {"type": "integer", "minimum": 1, "maximum": 2000},
                    }, "required": ["ref"], "additionalProperties": False},
                ))
            else:
                properties = read_spec["function"]["parameters"]["properties"]
                properties["ref"] = {"anyOf": [properties["ref"], work_ref_schema]}
                read_spec["function"]["description"] += (
                    " Also accepts authorized work_context: or work_entry: refs; "
                    "work entries support line_offset and line_limit."
                )
            scopes = self._available_human_scopes()
            if scopes:
                specs.append(
                    human_input_tool(
                        scopes=scopes,
                        visible_context_refs=self._visible_human_context_refs(),
                    )
                )
            return specs

        if pending_readback_ref:
            return [
                _function_tool(
                    "read_ref",
                    (
                        "Complete the mandatory readback of the exact stored output "
                        "that was just produced."
                    ),
                    {
                        "type": "object",
                        "properties": {
                            "ref": {
                                "type": "string",
                                "enum": [pending_readback_ref],
                                "description": (
                                    "The exact stored-output ref awaiting mandatory readback."
                                ),
                            },
                        },
                        "required": ["ref"],
                        "additionalProperties": False,
                    },
                )
            ]
        pending_child_refs = sorted(
            self._pending_child_terminal_artifact_refs()
            - self._inspected_pending_child_refs
        )
        if self._pending_child_review_packets():
            review_specs: list[dict[str, Any]] = []
            if pending_child_refs:
                review_specs.append(
                    _function_tool(
                        "read_ref",
                        (
                            "Inspect one exact pending child artifact for parent "
                            "review. This does not make it a formal parent input."
                        ),
                        {
                            "type": "object",
                            "properties": {
                                "ref": {
                                    "type": "string",
                                    "enum": pending_child_refs,
                                }
                            },
                            "required": ["ref"],
                            "additionalProperties": False,
                        },
                    )
                )
            review_specs.append(_review_child_result_tool())
            return with_human_input(review_specs)
        if (
            not active_skill_id
            and active_node is not None
            and not bool(loop_state["awaiting_transition"])
            and not planned_skill_id
        ):
            try:
                self._next_node_execution_attempt_index()
            except RuntimeError as exc:
                if not str(exc).startswith("node_execution_attempts_exhausted:"):
                    raise
            else:
                node_specs = [_execute_node_locally_tool()]
                node_read_refs = tuple(
                    ref for ref in self._active_node_input_refs(state)
                    if ref.startswith(("artifact:", "code_artifact:", "execution_observation:"))
                )
                if prompt_messages is not None:
                    node_read_refs = self._read_refs_available_for_prompt(
                        node_read_refs, prompt_messages,
                    )
                if node_read_refs:
                    node_specs.append(_read_ref_tool(
                        node_read_refs,
                        description=(
                            "Read one exact formal, code, or execution ref authorized "
                            "for the active Graph node. Stored content is projected "
                            "into the next prompt. Reading does not complete the node "
                            "or consume a node attempt."
                        ),
                    ))
                if self._child_depth < self._max_child_depth:
                    node_specs.append(
                        _spawn_child_tool(self._enabled_meta_capabilities)
                    )
                return with_human_input(node_specs)
        specs = [
            _function_tool(
                "load_skill",
                "Load one chosen project-local skill's full instructions.",
                {
                    "type": "object",
                    "properties": {
                        "skill_id": {
                            "type": "string",
                            "enum": selectable_skill_ids,
                            "description": "Exact skill_id from skill_menu.",
                        }
                    },
                    "required": ["skill_id"],
                    "additionalProperties": False,
                },
            ),
            _function_tool(
                "artifact_list",
                (
                    "Search or page through the active formal C2 catalog. The "
                    "default prompt index is only a bounded navigation window; "
                    "an omitted artifact is not absent. Use returned exact refs "
                    "with read_ref for stored content."
                ),
                {
                    "type": "object",
                    "properties": {
                        "artifact_kind": {
                            "type": "string",
                            "maxLength": 160,
                            "description": "Optional exact artifact_kind filter.",
                        },
                        "status": {
                            "type": "string",
                            "maxLength": 80,
                            "description": "Optional exact status filter.",
                        },
                        "query": {
                            "type": "string",
                            "maxLength": 300,
                            "description": (
                                "Optional case-insensitive substring over ref, kind, "
                                "status, and authored summary."
                            ),
                        },
                        "cursor": {
                            "type": "integer",
                            "minimum": 0,
                            "description": "Offset returned by the previous page.",
                        },
                        "limit": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 8,
                            "description": "Bounded page size; default 8.",
                        },
                    },
                    "additionalProperties": False,
                },
            ),
            _read_ref_tool(visible_read_refs),
            _function_tool(
                "artifact_publish",
                (
                    "Publish one immutable formal artifact. Authored artifacts must "
                    "pass their complete existing structured payload through "
                    "machine_payload; execution-derived artifacts pass "
                    "machine_payload_observation_ref instead. Markdown never "
                    "substitutes for the machine payload. Code artifacts belong to "
                    "the code store and cannot be published here. The next tool call "
                    "must read_ref the exact returned ref."
                ),
                {
                    "type": "object",
                    "properties": {
                        "artifact_kind": {
                            "type": "string",
                            "description": "One existing project artifact kind.",
                        },
                        "artifact_id": {"type": "string"},
                        "title": {"type": "string"},
                        "markdown": {
                            "type": "string",
                            "description": "Complete human-readable formal artifact content.",
                        },
                        "summary": {"type": "string"},
                        "status": {
                            "type": "string",
                            "description": (
                                "draft, proposed, superseded, or rejected; default proposed."
                            ),
                        },
                        "machine_payload": {
                            "type": "object",
                            "description": (
                                "Complete object using the selected skill's existing "
                                "payload keys; required for authored production artifacts. "
                                "Omit when machine_payload_observation_ref supplies it. If "
                                "both are sent, the stored observation is authoritative and "
                                "the redundant inline payload is ignored."
                            ),
                        },
                        "machine_payload_observation_ref": {
                            "type": "string",
                            "description": (
                                "Exact inspected execution observation whose stored result "
                                "must mechanically supply the machine payload."
                            ),
                        },
                        "depends_on": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "Formal artifact refs whose stored content this "
                                "artifact semantically derives from. With "
                                "machine_payload_observation_ref, runtime appends "
                                "that observation ref and verified formal artifact "
                                "refs already recorded in its metadata."
                            ),
                        },
                        "trace_refs": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "Optional additional trace refs. For observation-derived "
                                "publication, runtime supplies the exact observation and "
                                "its recorded implementation automatically."
                            ),
                        },
                        "self_review": {"type": "object"},
                    },
                    "required": [
                        "artifact_kind",
                        "title",
                        "markdown",
                    ],
                    "additionalProperties": False,
                },
            ),
        ]
        if not visible_read_refs:
            specs = [
                spec
                for spec in specs
                if spec["function"]["name"] != "read_ref"
            ]
        restart_spec = _function_tool(
            "restart_node_attempt",
            (
                "End the current immutable node attempt because the formal state "
                "shows its remaining skill sequence cannot execute or no longer "
                "applies. Use for a missing prerequisite, changed evidence, or a "
                "repeated terminal gap. This consumes the attempt."
            ),
            {
                "type": "object",
                "properties": {
                    "reason": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 2_000,
                    }
                },
                "required": ["reason"],
                "additionalProperties": False,
            },
        )
        if not active_skill_id:
            specs = [
                spec for spec in specs if spec["function"]["name"] != "artifact_publish"
            ]
            if not planned_skill_id:
                specs = [
                    spec for spec in specs if spec["function"]["name"] != "load_skill"
                ]
            if active_node is not None and bool(loop_state["awaiting_transition"]):
                transition_ids = [
                    str(item["transition_id"])
                    for item in active_node["transitions"]
                    if isinstance(item, Mapping)
                ]
                specs.append(
                    _function_tool(
                        "follow_graph_transition",
                        (
                            "Choose one existing conditional edge after the active "
                            "node result has been accepted by its evaluator."
                        ),
                        {
                            "type": "object",
                            "properties": {
                                "transition_id": {
                                    "type": "string",
                                    "enum": transition_ids,
                                }
                            },
                            "required": ["transition_id"],
                            "additionalProperties": False,
                        },
                    )
                )
                specs.append(
                    _function_tool(
                        "report_no_matching_transition",
                        (
                            "Report that accepted node evidence matches none "
                            "of the existing conditional edges, so the current "
                            "Graph cannot carry the observed result and must be rebuilt."
                        ),
                        {
                            "type": "object",
                            "properties": {
                                "reason": {
                                    "type": "string",
                                    "minLength": 1,
                                    "maxLength": 2_000,
                                }
                            },
                            "required": ["reason"],
                            "additionalProperties": False,
                        },
                    )
                )
            elif planned_skill_id:
                specs.append(restart_spec)
        else:
            specs = [
                spec
                for spec in specs
                if spec["function"]["name"] not in {"load_skill", "artifact_list"}
            ]
            if active_node is not None and loop_state["steps"]:
                specs.append(restart_spec)
        if active_skill_id:
            visible_routes = self._routes.visible(active_skill_id)
            specs.extend(
                route.tool_spec()
                for route in visible_routes
                if route.name != "source_read"
            )
            if disclosure_context is not None:
                visible_tool_names = set(
                    self._skills.disclosure_visible_route_names(
                        active_skill_id,
                        [
                            str(spec["function"]["name"])
                            for spec in specs
                            if isinstance(spec.get("function"), Mapping)
                        ],
                        disclosure_context,
                    )
                )
                specs = [
                    spec
                    for spec in specs
                    if str(spec["function"]["name"]) in visible_tool_names
                ]
        if active_skill_id and any(spec["function"]["name"] == "artifact_publish" for spec in specs):
            specs.append(create_reference_link_tool())
        return with_human_input(specs)

    def _tool_result_projector(self, name: str, arguments: Mapping[str, Any]):
        projector = self._routes.result_projector(name)
        if name == "read_ref":
            ref = str(arguments.get("ref") or "")
            if ref.startswith(("source_file:", "source_probe:", "workspace_terminal:")):
                projector = self._routes.result_projector("source_read")
            elif ref.startswith(("development_output:", "reference:")):
                projector = preserve_tool_result
        return projector

    def _tool_spec_for_name(self, name: str) -> Mapping[str, Any] | None:
        for spec in self._tool_specs():
            function = spec.get("function")
            if isinstance(function, Mapping) and function.get("name") == name:
                return spec
        return None

    def _tool_payload_schema_issues(self, call: ToolCall) -> list[str]:
        spec = self._tool_spec_for_name(call.name)
        if spec is None:
            return [f"tool_not_available_in_current_context:{call.name}"]
        function = spec.get("function")
        if not isinstance(function, Mapping):
            return ["tool_spec_function_missing"]
        parameters = function.get("parameters")
        if not isinstance(parameters, Mapping):
            return ["tool_spec_parameters_missing"]
        issues = json_schema_issues(_tool_schema_arguments(call), parameters)
        if not issues:
            try:
                source_arguments = reference_source_read(call.name, call.arguments)
            except ValueError as exc:
                issues.append(str(exc))
            else:
                if source_arguments is not None:
                    issues.extend(self._tool_payload_schema_issues(
                        ToolCall(call.call_id, "read_ref", source_arguments)
                    ))
        if call.name == "artifact_publish":
            payload_source_issue = _artifact_publish_payload_source_issue(
                call.arguments
            )
            if payload_source_issue:
                issues.append(payload_source_issue)
            observation_ref = str(
                call.arguments.get("machine_payload_observation_ref") or ""
            ).strip()
            artifact_kind = str(call.arguments.get("artifact_kind") or "").strip()
            if artifact_kind and not observation_ref:
                try:
                    self._artifact_store.validate_payload(
                        artifact_kind=artifact_kind,
                        machine_payload=call.arguments.get("machine_payload"),
                    )
                except (TypeError, ValueError) as exc:
                    issues.append(str(exc))
        return issues[:24]

    def _tool_payload_issues(
        self,
        call: ToolCall,
        *,
        skip_skill_disclosure: bool = False,
    ) -> list[str]:
        issues = self._tool_payload_schema_issues(call)
        if issues:
            return issues[:24]
        active_skill_id = str(self._state.read()["c1"]["active_skill_id"] or "")
        if self._routes.has(call.name):
            try:
                self._routes.validate(
                    call.name,
                    call.arguments,
                    skill_id=active_skill_id or None,
                )
            except Exception as exc:
                issues.append(str(exc))
        if (
            active_skill_id
            and not skip_skill_disclosure
            # These tools are exposed by Common after skill disclosure. Their
            # ownership/visibility is enforced by the work-memory reader.
            and call.name != "work_memory_list"
            and not (
                call.name == "read_ref"
                and str(call.arguments.get("ref") or "").startswith(
                    ("work_context:", "work_entry:")
                )
            )
            and call.name
            not in {
                "restart_node_attempt",
                "request_human_input",
            }
            and self._skills.has_disclosure(active_skill_id)
        ):
            try:
                self._skills.validate_disclosed_tool_call(
                    active_skill_id,
                    call.name,
                    call.arguments,
                    self._selected_skill_disclosure_context(active_skill_id),
                )
            except Exception as exc:
                issues.append(str(exc))
        return issues[:24]

    def _validate_tool_payload(
        self,
        call: ToolCall,
        *,
        skip_skill_disclosure: bool = False,
    ) -> None:
        issues = self._tool_payload_issues(
            call,
            skip_skill_disclosure=skip_skill_disclosure,
        )
        if issues:
            raise ValueError(
                "tool_payload_invalid:" + "; ".join(str(issue) for issue in issues)
            )

    def _repair_tool_payload_if_needed(
        self,
        call: ToolCall,
        *,
        round_number: int,
        _repair_pass: int = 1,
    ) -> tuple[ToolCall, str]:
        active_skill_id = str(self._state.read()["c1"]["active_skill_id"] or "")
        if not active_skill_id:
            return call, ""
        if call.name == "read_ref" and str(call.arguments.get("ref") or "").startswith(
            ("artifact:", "code_artifact:", "execution_observation:")
        ):
            repaired_arguments = dict(call.arguments)
            removed_pagination = any(
                key in repaired_arguments for key in ("line_offset", "line_limit")
            )
            if removed_pagination:
                repaired_arguments.pop("line_offset", None)
                repaired_arguments.pop("line_limit", None)
                call = ToolCall(
                    call_id=call.call_id,
                    name=call.name,
                    arguments=repaired_arguments,
                )
                remaining = self._tool_payload_schema_issues(call)
                if not remaining:
                    self._events.append(
                        "tool_payload_repair_applied",
                        {
                            "round": round_number,
                            "tool": call.name,
                            "call_id": call.call_id,
                            "mode": "mechanical_non_source_pagination_removal",
                            "executed_arguments": dict(call.arguments),
                        },
                    )
                    return call, ""
        issues = self._tool_payload_schema_issues(call)
        if not issues:
            return call, ""
        tool_spec = self._tool_spec_for_name(call.name)
        if tool_spec is None:
            return call, ""
        mechanically_repaired_ref = _mechanical_source_ref_repair(
            call,
            tool_spec=tool_spec,
            issues=issues,
        )
        if mechanically_repaired_ref is not None:
            repaired_arguments = dict(call.arguments)
            repaired_arguments["ref"] = mechanically_repaired_ref
            repaired = ToolCall(
                call_id=call.call_id,
                name=call.name,
                arguments=repaired_arguments,
            )
            remaining = self._tool_payload_schema_issues(repaired)
            if not remaining:
                self._events.append(
                    "tool_payload_repair_applied",
                    {
                        "round": round_number,
                        "tool": call.name,
                        "call_id": call.call_id,
                        "mode": "mechanical_exact_source_identity",
                        "executed_arguments": dict(repaired.arguments),
                    },
                )
                return repaired, ""
        protected_read_ref, ref_repair_issue = _read_ref_repair_constraint(
            call,
            tool_spec=tool_spec,
            issues=issues,
        )
        if ref_repair_issue:
            return call, ref_repair_issue
        if (
            call.name in _PYTHON_BODY_OWNING_TOOLS
            and not str(call.arguments.get("python_code") or "").strip()
            and any("python_code" in str(issue) for issue in issues)
        ):
            return (
                call,
                "tool_payload_local_repair_not_applicable:"
                "missing_substantive_field=python_code:"
                "active_skill_must_submit_or_edit_complete_source",
            )

        payload_schema = None
        if call.name == "artifact_publish":
            artifact_kind = str(call.arguments.get("artifact_kind") or "").strip()
            if artifact_kind:
                payload_schema = self._artifact_store.payload_schema(artifact_kind)
        repair_tool_spec = _artifact_publish_repair_tool_spec(
            call,
            tool_spec=tool_spec,
            payload_schema=payload_schema,
        )
        purpose = f"repair arguments for selected tool: {call.name}"
        repair_packet = {
            "selected_tool": call.name,
            "validation_issues": issues,
            "previous_arguments": dict(call.arguments),
        }
        messages = [
            {"role": "system", "content": _TOOL_PAYLOAD_REPAIR_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": json.dumps(
                    repair_packet,
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            },
        ]
        tools = [repair_tool_spec]
        self._events.append(
            "tool_payload_repair_started",
            {
                "round": round_number,
                "tool": call.name,
                "call_id": call.call_id,
                "active_skill_id": active_skill_id,
                "issues": issues,
            },
        )
        repair_status = "failed"
        try:
            if active_skill_id:
                self._reserve_active_loop_step_model_call(purpose=purpose)
            self._memory.prepare_for_model_call(call_site=purpose)
            self._memory.record_prompt_projection(
                call_site=purpose,
                messages=messages,
                tools=tools,
                sources=(
                    PromptSource(
                        "instruction",
                        "tool_payload_repair_instruction",
                        messages[0],
                    ),
                    PromptSource(
                        "C5",
                        "previous_tool_arguments",
                        repair_packet["previous_arguments"],
                    ),
                    PromptSource(
                        "C5",
                        "tool_payload_validation_issues",
                        repair_packet["validation_issues"],
                    ),
                    PromptSource(
                        "tool_schema",
                        "selected_tool",
                        repair_tool_spec,
                    ),
                ),
                budget_tier="compact",
            )
            self._events.append(
                "tool_payload_repair_prompt_snapshot",
                {
                    "round": round_number,
                    "purpose": purpose,
                    "messages": messages,
                    "tool_names": [call.name],
                },
            )
            turn = complete_model_turn(
                self._model,
                messages=messages,
                tools=tools,
                purpose=purpose,
                tool_choice="required",
                repair=True,
            )
            self._events.append(
                "tool_payload_repair_model_turn",
                {
                    "round": round_number,
                    "content": turn.content,
                    "tool_calls": [
                        {
                            "call_id": item.call_id,
                            "name": item.name,
                            "arguments": dict(item.arguments),
                        }
                        for item in turn.tool_calls
                    ],
                    "usage": dict(turn.usage),
                },
            )
            if len(turn.tool_calls) != 1:
                raise ValueError(
                    "tool_payload_repair_requires_exactly_one_tool_call:"
                    f"actual={len(turn.tool_calls)}"
                )
            repaired = turn.tool_calls[0]
            if repaired.name != call.name:
                raise ValueError(
                    "tool_payload_repair_changed_tool:"
                    f"expected={call.name}:actual={repaired.name}"
                )
            candidate = ToolCall(
                call_id=call.call_id,
                name=call.name,
                arguments=dict(repaired.arguments),
            )
            if (
                protected_read_ref is not None
                and str(candidate.arguments.get("ref") or "") != protected_read_ref
            ):
                raise ValueError(
                    "tool_payload_repair_changed_exact_read_identity:"
                    f"expected={protected_read_ref}:actual="
                    f"{candidate.arguments.get('ref') or ''}"
                )
            remaining = self._tool_payload_schema_issues(candidate)
            if remaining:
                if (
                    _repair_pass < _MAX_TOOL_PAYLOAD_REPAIR_PASSES
                    and remaining != issues
                ):
                    repaired_again, retry_failure = self._repair_tool_payload_if_needed(
                        candidate,
                        round_number=round_number,
                        _repair_pass=_repair_pass + 1,
                    )
                    if not retry_failure:
                        repair_status = "applied"
                        return repaired_again, ""
                    raise ValueError(retry_failure)
                raise ValueError(
                    "tool_payload_repair_still_invalid:"
                    + "; ".join(str(issue) for issue in remaining)
                )
            repair_status = "applied"
            self._events.append(
                "tool_payload_repair_applied",
                {
                    "round": round_number,
                    "tool": call.name,
                    "call_id": call.call_id,
                    "executed_arguments": dict(candidate.arguments),
                },
            )
            return candidate, ""
        except NodeLoopStepCallLimitError:
            raise
        except Exception as exc:
            failure = f"tool_payload_local_repair_failed:{exc}"
            self._events.append(
                "tool_payload_repair_failed",
                {
                    "round": round_number,
                    "tool": call.name,
                    "call_id": call.call_id,
                    "reason": str(exc),
                },
            )
            return call, failure
        finally:
            self._events.append(
                "tool_payload_repair_cleared",
                {
                    "round": round_number,
                    "tool": call.name,
                    "call_id": call.call_id,
                    "status": repair_status,
                },
            )

    def _repair_failed_tool_dispatch_if_applicable(
        self,
        call: ToolCall,
        *,
        error: str,
        round_number: int,
    ) -> tuple[ToolCall | None, str]:
        """Keep a recoverable file-operation mismatch inside one tool step."""

        if call.name != "development_project_write" or not error.startswith(
            "development_write_file_exists:"
        ):
            return None, ""
        active_skill_id = str(self._state.read()["c1"]["active_skill_id"] or "")
        if not active_skill_id or self._development_projects is None:
            return None, ""
        target_spec = self._tool_spec_for_name("development_project_edit")
        if target_spec is None:
            return None, "development_project_edit_not_available_for_local_repair"

        project_id = str(call.arguments.get("project_id") or "").strip()
        path = str(call.arguments.get("path") or "").strip()
        intended_body = call.arguments.get("content")
        if not project_id or not path or not isinstance(intended_body, str):
            return None, "development_write_repair_source_arguments_invalid"

        try:
            chunks: list[str] = []
            line_offset = 0
            current_size = 0
            while True:
                page = self._development_projects.read_file(
                    project_id,
                    path,
                    line_offset=line_offset,
                    line_limit=2_000,
                )
                content = str(page.get("content") or "")
                current_size += len(content.encode("utf-8"))
                if (
                    current_size + len(intended_body.encode("utf-8"))
                    > _MAX_LOCAL_FILE_REPAIR_BYTES
                ):
                    return None, "development_write_local_repair_context_too_large"
                chunks.append(content)
                next_offset = page.get("next_line_offset")
                if next_offset is None:
                    break
                next_value = int(next_offset)
                if next_value <= line_offset:
                    return None, "development_write_local_repair_read_did_not_advance"
                line_offset = next_value
            current_body = "".join(chunks)
            if not current_body:
                return None, "development_write_local_repair_empty_existing_file"
            if current_body == intended_body:
                return None, "development_write_local_repair_content_already_equal"

            purpose = (
                "repair failed tool dispatch: development_project_write -> "
                "development_project_edit"
            )
            repair_packet = {
                "failed_tool": call.name,
                "failure": error,
                "previous_arguments": dict(call.arguments),
                "required_replacement_arguments": {
                    "project_id": project_id,
                    "path": path,
                    "old_string": current_body,
                    "new_string": intended_body,
                    "replace_all": False,
                },
            }
            messages = [
                {"role": "system", "content": _TOOL_DISPATCH_REPAIR_SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": json.dumps(
                        repair_packet,
                        ensure_ascii=False,
                        separators=(",", ":"),
                    ),
                },
            ]
            tools = [target_spec]
            self._events.append(
                "tool_dispatch_repair_started",
                {
                    "round": round_number,
                    "call_id": call.call_id,
                    "failed_tool": call.name,
                    "replacement_tool": "development_project_edit",
                    "reason": error,
                },
            )
            self._reserve_active_loop_step_model_call(purpose=purpose)
            self._memory.prepare_for_model_call(call_site=purpose)
            self._memory.record_prompt_projection(
                call_site=purpose,
                messages=messages,
                tools=tools,
                sources=(
                    PromptSource(
                        "instruction",
                        "tool_dispatch_repair_instruction",
                        messages[0],
                    ),
                    PromptSource(
                        "C5",
                        "failed_tool_dispatch",
                        repair_packet,
                    ),
                    PromptSource(
                        "tool_schema",
                        "replacement_tool",
                        target_spec,
                    ),
                ),
                budget_tier="compact",
            )
            self._events.append(
                "tool_dispatch_repair_prompt_snapshot",
                {
                    "round": round_number,
                    "purpose": purpose,
                    "messages": messages,
                    "tool_names": ["development_project_edit"],
                },
            )
            turn = complete_model_turn(
                self._model,
                messages=messages,
                tools=tools,
                purpose=purpose,
                tool_choice="required",
                repair=True,
            )
            self._events.append(
                "tool_dispatch_repair_model_turn",
                {
                    "round": round_number,
                    "content": turn.content,
                    "tool_calls": [
                        {
                            "call_id": item.call_id,
                            "name": item.name,
                            "arguments": dict(item.arguments),
                        }
                        for item in turn.tool_calls
                    ],
                    "usage": dict(turn.usage),
                },
            )
            if len(turn.tool_calls) != 1:
                raise ValueError(
                    "tool_dispatch_repair_requires_exactly_one_tool_call:"
                    f"actual={len(turn.tool_calls)}"
                )
            repaired = turn.tool_calls[0]
            if repaired.name != "development_project_edit":
                raise ValueError(
                    "tool_dispatch_repair_changed_replacement_tool:"
                    f"actual={repaired.name}"
                )
            candidate = ToolCall(
                call_id=call.call_id,
                name="development_project_edit",
                arguments=dict(repaired.arguments),
            )
            required_arguments = repair_packet["required_replacement_arguments"]
            for key, expected in required_arguments.items():
                actual = candidate.arguments.get(key)
                if key in {"old_string", "new_string"}:
                    matches = _matches_frozen_text_argument(actual, str(expected))
                else:
                    matches = actual == expected
                if not matches:
                    raise ValueError(
                        "tool_dispatch_repair_changed_frozen_argument:"
                        f"{key}"
                    )
            candidate_arguments = dict(candidate.arguments)
            candidate_arguments["old_string"] = current_body
            candidate_arguments["new_string"] = intended_body
            candidate = ToolCall(
                call_id=candidate.call_id,
                name=candidate.name,
                arguments=candidate_arguments,
            )
            remaining = self._tool_payload_issues(candidate)
            if remaining:
                raise ValueError(
                    "tool_dispatch_repair_invalid_replacement:"
                    + "; ".join(str(issue) for issue in remaining)
                )
            self._events.append(
                "tool_dispatch_repair_applied",
                {
                    "round": round_number,
                    "call_id": call.call_id,
                    "failed_tool": call.name,
                    "replacement_tool": candidate.name,
                    "executed_arguments": dict(candidate.arguments),
                },
            )
            return candidate, ""
        except NodeLoopStepCallLimitError:
            raise
        except Exception as exc:
            failure = f"tool_dispatch_local_repair_failed:{exc}"
            self._events.append(
                "tool_dispatch_repair_failed",
                {
                    "round": round_number,
                    "call_id": call.call_id,
                    "failed_tool": call.name,
                    "reason": str(exc),
                },
            )
            return None, failure

    def _execute_tool_call(
        self,
        call: ToolCall,
        *,
        round_number: int,
        repair_failure: str = "",
        internal_readback: bool = False,
    ) -> Mapping[str, Any]:
        pending_before = self._pending_readback_ref()
        work_before = self._work.ensure()
        state_before = self._state.read()
        active_skill_before = str(state_before["c1"]["active_skill_id"] or "")
        failed_tool_before = _latest_failed_tool_name(
            state_before["c1"]["recent_bounded_receipts"]
        )
        issue_before = str(state_before["c1"]["current_issue"] or "")
        no_progress_intercepted = False
        executed_call = call
        try:
            if internal_readback and (
                call.name not in {"read_ref", "artifact_read"}
                or str(
                    call.arguments.get("ref")
                    or call.arguments.get("artifact_ref")
                    or ""
                )
                != pending_before
            ):
                raise RuntimeError(
                    "runtime_internal_readback_requires_exact_pending_ref"
                )
            no_progress_reason = (
                "" if internal_readback else self._no_progress_call_reason(call)
            )
            if no_progress_reason:
                no_progress_intercepted = True
                raise RuntimeError(no_progress_reason)
            self._validate_tool_payload(
                call,
                skip_skill_disclosure=internal_readback,
            )
            self._validate_transition(
                call,
                round_number=round_number,
                internal_readback=internal_readback,
            )
            raw_result = self._dispatch(
                executed_call.name,
                executed_call.arguments,
                round_number=round_number,
            )
            error = ""
        except HumanInteractionPause:
            raise
        except Exception as exc:
            error = str(exc)
            if repair_failure:
                error = f"{repair_failure}:final_preflight={error}"
            repaired_call, dispatch_repair_failure = (
                self._repair_failed_tool_dispatch_if_applicable(
                    call,
                    error=error,
                    round_number=round_number,
                )
                if not internal_readback
                else (None, "")
            )
            if repaired_call is not None:
                executed_call = repaired_call
                try:
                    self._validate_tool_payload(executed_call)
                    self._validate_transition(
                        executed_call,
                        round_number=round_number,
                        internal_readback=False,
                    )
                    raw_result = self._dispatch(
                        executed_call.name,
                        executed_call.arguments,
                        round_number=round_number,
                    )
                    error = ""
                except Exception as repair_exc:
                    error = f"tool_dispatch_replacement_failed:{repair_exc}"
                    raw_result = {"status": "tool_error", "reason": error}
            else:
                if dispatch_repair_failure:
                    error = f"{error}:{dispatch_repair_failure}"
                raw_result = {"status": "tool_error", "reason": error}
        projector = self._tool_result_projector(executed_call.name, executed_call.arguments)
        receipt_projection = (
            _runtime_readback_receipt_projection(raw_result)
            if internal_readback
            else tool_receipt_projection(raw_result, has_owned_presentation=projector is not None)
        )
        prompt_projection = tool_result_prompt_projection(raw_result, projector=projector)

        work_event_sequence = self._events.append(
            "tool_result",
            {"round": round_number, "call_id": executed_call.call_id,
             "tool": executed_call.name, "executed_arguments": dict(executed_call.arguments),
             "raw_result": raw_result, "prompt_projection": prompt_projection},
        )
        self._record_work_tool(
            call_id=executed_call.call_id, name=executed_call.name,
            arguments=executed_call.arguments, result=raw_result,
            event_sequence=work_event_sequence,
            context_ref=(self._work.ensure() if executed_call.name == "execute_node_locally"
                         else work_before),
            input_refs=tuple(state_before["c1"]["resolved_artifact_refs"]),
        )
        if not error:
            self._activate_tool_result_refs(executed_call.name, raw_result)
            if raw_result.get("status") == "tool_error":
                error = str(raw_result.get("reason") or "tool_execution_failed")
        self._state.record_receipt(
            {
                "tool": executed_call.name,
                "call_id": executed_call.call_id,
                "result": receipt_projection,
            }
        )
        preserve_attempt_issue = _pending_node_attempt_issue_is_authoritative(
            state_before
        )
        if error:
            if not preserve_attempt_issue:
                self._state.set_issue(error)
        elif executed_call.name in {"execute_node_locally", "restart_node_attempt"}:
            # These control actions own their C1 issue state.
            pass
        elif preserve_attempt_issue:
            # Receipts retain later probe outcomes; the finished attempt's root
            # gap remains authoritative until a fresh attempt is planned.
            pass
        elif (
            not issue_before
            or executed_call.name == failed_tool_before
            or call.name == failed_tool_before
            or _result_establishes_progress(executed_call.name, raw_result)
        ):
            self._state.set_issue("")
        if not error and executed_call.name not in {
            "read_ref",
            "artifact_read",
            "request_human_input",
        }:
            self._mark_human_answer_consumed(consumer=f"tool:{executed_call.name}")
        if no_progress_intercepted:
            active_node_id = next(
                (
                    str(node.get("node_id") or "")
                    for node in state_before["c1"]["plan_graph"]["nodes"]
                    if node.get("status") == "in_progress"
                ),
                "",
            )
            invocation_output_refs = (
                self._active_invocation_artifact_refs(active_skill_before)
                if active_skill_before
                else ()
            )
            if active_skill_before:
                if invocation_output_refs:
                    self._events.append(
                        "skill_context_retained",
                        {
                            "round": round_number,
                            "skill_id": active_skill_before,
                            "reason": "formal_output_awaits_bounded_handoff",
                            "artifact_refs": list(invocation_output_refs),
                        },
                    )
                else:
                    self._events.append(
                        "skill_context_retained",
                        {
                            "round": round_number,
                            "skill_id": active_skill_before,
                            "reason": "bounded_repeated_read_correction",
                            "artifact_refs": [],
                        },
                    )
            self._events.append(
                "tool_call_no_progress_intercepted",
                {
                    "round": round_number,
                    "tool": call.name,
                    "call_id": call.call_id,
                    "active_skill_id": active_skill_before,
                    "active_node_id": active_node_id,
                    "formal_output_refs": list(invocation_output_refs),
                    "control_returned_to_graph_node": False,
                },
            )
        if (
            not error
            and pending_before
            and call.name in {"read_ref", "artifact_read"}
            and str(
                call.arguments.get("ref") or call.arguments.get("artifact_ref") or ""
            )
            == pending_before
        ):
            self._state.set_issue("")
        return raw_result

    def _dispatch(
        self,
        name: str,
        arguments: Mapping[str, Any],
        *,
        round_number: int = 0,
    ) -> Any:
        if name == "request_human_input":
            return self._request_human_input(arguments)
        if name == "execute_node_locally":
            attempt_index = self._next_node_execution_attempt_index()
            active = active_work_unit(self._state.read()["c1"]["plan_graph"])
            if active is None:
                raise RuntimeError("node_execution_requires_active_graph_node")
            self._bind_node_work(
                active, attempt_index=attempt_index,
                requested_ref=str(arguments.get("work_context_ref") or ""),
            )
            self._events.append(
                "node_execution_mode_selected",
                {
                    "round": round_number,
                    "node_id": str(active["node_id"]),
                    "attempt_index": attempt_index,
                    "mode": "local",
                },
            )
            graph_changed = self._ensure_node_loop_plan(
                round_number=round_number,
                attempt_index=attempt_index,
            )
            current = self._state.read()
            current_active = active_work_unit(current["c1"]["plan_graph"])
            if graph_changed:
                return {
                    "status": "node_execution_redirected",
                    "active_node_id": (
                        str(current_active["node_id"])
                        if current_active is not None
                        else ""
                    ),
                }
            return {
                "status": "node_local_loop_planned",
                "node_id": str(active["node_id"]),
                "attempt_index": attempt_index,
            }
        if name == "spawn_child":
            mission = ChildMission.from_payload(
                arguments,
                default_root=self._child_source_root(),
            )
            runtime_state = self._state.read()
            active = active_work_unit(runtime_state["c1"]["plan_graph"])
            if active is None:
                raise RuntimeError("spawn_child_requires_active_graph_node")
            node_objective = str(active["outcome"])
            node_evaluation = str(active["completion_condition"])
            mission_context = copy.deepcopy(dict(mission.mission_context))
            mission_context.pop("prior_attempt_handoff", None)
            self._events.append(
                "child_mission_node_authority_applied",
                {
                    "round": round_number,
                    "node_id": str(active["node_id"]),
                    "submitted_objective_matches_node": (
                        mission.objective == node_objective
                    ),
                    "submitted_evaluation_matches_node": (
                        mission.evaluation_summary == node_evaluation
                    ),
                },
            )
            mission = ChildMission(
                objective=node_objective,
                evaluation_summary=node_evaluation,
                enabled_meta_capabilities=(mission.enabled_meta_capabilities),
                mission_context=mission_context,
                artifact_refs=mission.artifact_refs,
                work_entry_refs=mission.work_entry_refs,
                workspace_refs=mission.workspace_refs,
                workspace_root=mission.workspace_root,
                allow_workspace_discovery=mission.allow_workspace_discovery,
            )
            revision_context_refs = self._active_graph_revision_child_context_refs()
            if revision_context_refs:
                existing_refs = set(mission.artifact_refs)
                mission = ChildMission(
                    objective=mission.objective,
                    evaluation_summary=mission.evaluation_summary,
                    enabled_meta_capabilities=(mission.enabled_meta_capabilities),
                    mission_context=mission.mission_context,
                    work_entry_refs=mission.work_entry_refs,
                    artifact_refs=tuple(
                        dict.fromkeys(
                            [*mission.artifact_refs, *revision_context_refs]
                        )
                    ),
                    workspace_refs=mission.workspace_refs,
                    workspace_root=mission.workspace_root,
                    allow_workspace_discovery=mission.allow_workspace_discovery,
                )
                self._events.append(
                    "child_mission_graph_revision_context_attached",
                    {
                        "round": round_number,
                        "node_id": str(active["node_id"]),
                        "revision_outcome_ref": revision_context_refs[0],
                        "added_artifact_refs": [
                            ref
                            for ref in revision_context_refs
                            if ref not in existing_refs
                        ],
                    },
                )
            human_response_refs = self._answered_human_response_refs()
            if human_response_refs:
                mission = ChildMission(
                    objective=mission.objective,
                    evaluation_summary=mission.evaluation_summary,
                    enabled_meta_capabilities=(mission.enabled_meta_capabilities),
                    mission_context=mission.mission_context,
                    work_entry_refs=mission.work_entry_refs,
                    artifact_refs=tuple(
                        dict.fromkeys([*mission.artifact_refs, *human_response_refs])
                    ),
                    workspace_refs=mission.workspace_refs,
                    workspace_root=mission.workspace_root,
                    allow_workspace_discovery=mission.allow_workspace_discovery,
                )
            observation_refs = self._execution_observations_for_inputs(
                mission.artifact_refs, runtime_state,
            )
            operational_refs = self._operational_refs_for_execution_observations(
                observation_refs
            )
            mission = replace(mission, artifact_refs=tuple(dict.fromkeys(
                (*mission.artifact_refs, *observation_refs, *operational_refs)
            )))
            self._validate_dispatch_child_mission(mission)
            attempt_index = self._begin_child_node_attempt(round_number=round_number)
            self._mark_human_answer_consumed(consumer="spawn_child_mission")
            try:
                record = self.spawn_child(
                    mission,
                    child_id=str(arguments.get("child_id") or ""),
                )
            except HumanInteractionPause:
                raise
            except Exception as exc:
                self._events.append(
                    "node_child_attempt_failed",
                    {
                        "round": round_number,
                        "node_id": self._state.read()["c1"]["node_loop_state"][
                            "node_id"
                        ],
                        "attempt_index": attempt_index,
                        "reason": bounded_text(str(exc), 2_000),
                    },
                )
                raise
            return {"status": "child_returned", "child": record}
        if name == "review_child_result":
            raw_refs = arguments.get("accepted_artifact_refs") or ()
            if isinstance(raw_refs, (str, bytes)) or not isinstance(raw_refs, Sequence):
                raise ValueError("accepted_artifact_refs_must_be_array")
            review = self.review_child(
                str(arguments.get("child_id") or ""),
                decision=str(arguments.get("decision") or ""),
                accepted_artifact_refs=tuple(str(ref) for ref in raw_refs),
            )
            return {"status": "child_reviewed", "review": review}
        if name == "follow_graph_transition":
            return self._follow_graph_transition(
                str(arguments.get("transition_id") or ""),
                round_number=round_number,
            )
        if name == "report_no_matching_transition":
            return self._report_no_matching_transition(
                str(arguments.get("reason") or ""),
                round_number=round_number,
            )
        if name == "restart_node_attempt":
            reason = str(arguments.get("reason") or "").strip()
            if not reason:
                raise ValueError("restart_node_attempt_reason_required")
            return self._restart_node_attempt(
                reason,
                round_number=round_number,
            )
        if name == "load_skill":
            state = self._state.read()
            if state["c1"]["active_skill_id"]:
                raise RuntimeError("load_skill_requires_skill_selection_boundary")
            skill_id = str(arguments.get("skill_id", ""))
            active = active_work_unit(state["c1"]["plan_graph"])
            planned_skill = (
                next_skill_id(
                    state["c1"]["node_loop_state"],
                    node_id=str(active["node_id"]),
                )
                if active is not None
                else ""
            )
            if not planned_skill or skill_id != planned_skill:
                raise RuntimeError(
                    f"load_skill_must_follow_node_loop:{planned_skill}:{skill_id}"
                )
            selected_refs = current_step_input_refs(
                state["c1"]["node_loop_state"],
                node_id=str(active["node_id"]),
            )
            produced_refs = tuple(
                str(ref)
                for ref in state["c1"]["node_loop_state"].get("produced_refs", ())
            )
            invocation_refs = tuple(
                dict.fromkeys(
                    [
                        *selected_refs,
                        *produced_refs,
                        *self._answered_human_response_refs(),
                    ]
                )
            )
            repeated_gap_issue = self._repeated_terminal_gap_load_issue(
                skill_id,
                invocation_refs=invocation_refs,
            )
            if repeated_gap_issue:
                raise RuntimeError(repeated_gap_issue)
            detail = self._skills.detail(skill_id)
            if not detail.strip():
                raise ValueError(f"skill_detail_empty:{skill_id}")
            for ref in invocation_refs:
                self._read_exact_ref(ref)
            execution_observations = self._execution_observations_for_inputs(invocation_refs, state)
            self._state.start_skill(
                skill_id,
                resolved_artifact_refs=invocation_refs,
            )
            for ref in dict.fromkeys([
                *self._current_work_projection(consumer=skill_id)["operational_refs"], *execution_observations,
            ]):
                self._activate_observation_ref(ref, self._read_exact_ref(ref))
            return {
                "status": "skill_loaded",
                "skill_id": skill_id,
                "input_refs": list(invocation_refs),
            }
        if name == "artifact_list":
            page = self._artifact_catalog_page(arguments)
            items = list(page.pop("items"))
            return {
                **page,
                "artifacts": items,
            }
        if name == "work_memory_list":
            return self._work.list(**dict(arguments))
        if name == "create_reference_link":
            return self._reference_resolver().create(arguments)
        if name == "read_ref":
            ref = str(arguments.get("ref") or "").strip()
            if ref.startswith("reference:"):
                return self._reference_resolver().read(
                    ref, line_offset=arguments.get("line_offset", 0),
                    line_limit=arguments.get("line_limit", 200),
                )
            if ref.startswith(("work_context:", "work_entry:")):
                return self._work.read(ref, line_offset=int(arguments.get("line_offset", 0)),
                                       line_limit=int(arguments.get("line_limit", 200)))
            if ref.startswith("development_output:"):
                self._ensure_child_external_ref_visible(ref)
                if self._development_projects is None:
                    raise KeyError(f"development_project_store_unavailable:{ref}")
                return self._development_projects.read_output(
                    ref,
                    line_offset=int(arguments.get("line_offset", 0)),
                    line_limit=int(arguments.get("line_limit", 200)),
                )
            if ref.startswith(("source_file:", "source_probe:", "workspace_terminal:")):
                source_arguments: dict[str, Any] = {"source_ref": ref}
                for key in ("line_offset", "line_limit"):
                    if key in arguments:
                        source_arguments[key] = arguments[key]
                active_skill_id = self._state.read()["c1"]["active_skill_id"]
                return self._routes.execute(
                    "source_read",
                    source_arguments,
                    skill_id=active_skill_id,
                )
            if "line_offset" in arguments or "line_limit" in arguments:
                raise ValueError("read_ref_pagination_requires_source_or_output_ref")
            if not ref.startswith(
                ("artifact:", "code_artifact:", "execution_observation:")
            ):
                raise ValueError(f"read_ref_namespace_unknown:{ref}")
            return self._read_formal_ref(ref)
        if name == "artifact_read":
            return self._read_formal_ref(str(arguments.get("artifact_ref", "")).strip())
        if name == "artifact_publish":
            artifact_kind = str(arguments.get("artifact_kind", ""))
            if artifact_kind == "code_artifact":
                raise ValueError("code_artifact_requires_code_store")
            payload_source_issue = _artifact_publish_payload_source_issue(arguments)
            if payload_source_issue:
                raise ValueError(payload_source_issue)
            machine_payload = dict(arguments.get("machine_payload") or {})
            observation_ref = str(
                arguments.get("machine_payload_observation_ref") or ""
            )
            depends_on = list(arguments.get("depends_on") or ())
            trace_refs = list(arguments.get("trace_refs") or ())
            for lineage_ref in self._active_capability_lineage_refs():
                if lineage_ref not in depends_on:
                    depends_on.append(lineage_ref)
            if observation_ref:
                # Stored execution evidence owns execution-derived content. A model may
                # redundantly restate it, but the inline copy cannot override it.
                machine_payload = self._observations.result_for_artifact(
                    observation_ref
                )
                observation = self._observations.read(observation_ref)
                for metadata_ref in _exact_string_refs(observation.get("metadata")):
                    if not metadata_ref.startswith("artifact:"):
                        continue
                    try:
                        self._artifacts.read(metadata_ref)
                    except (KeyError, OSError, PermissionError, ValueError):
                        continue
                    if metadata_ref not in depends_on:
                        depends_on.append(metadata_ref)
                metadata = observation.get("metadata")
                implementation_ref = ""
                if isinstance(metadata, Mapping):
                    current_ref = str(metadata.get("implementation_ref") or "")
                    legacy_code_ref = str(metadata.get("code_artifact_ref") or "")
                    if (
                        current_ref
                        and legacy_code_ref
                        and current_ref != legacy_code_ref
                    ):
                        raise ValueError(
                            "observation_implementation_ref_conflict:"
                            f"{current_ref}:{legacy_code_ref}"
                        )
                    implementation_ref = current_ref or legacy_code_ref
                if (
                    implementation_ref.startswith("code_artifact:")
                    and self._code_artifacts is not None
                ):
                    code_artifact = self._code_artifacts.read(implementation_ref)
                    for dependency_ref in code_artifact.get("depends_on") or ():
                        dependency_ref = str(dependency_ref)
                        if not dependency_ref.startswith("artifact:"):
                            continue
                        self._artifacts.read(dependency_ref)
                        if dependency_ref not in depends_on:
                            depends_on.append(dependency_ref)
                elif implementation_ref.startswith("artifact:"):
                    implementation = self._artifacts.read(implementation_ref)
                    if implementation.get("artifact_kind") != (
                        "development_project_snapshot"
                    ):
                        raise ValueError(
                            f"implementation_artifact_kind_invalid:{implementation_ref}"
                        )
                if observation_ref not in depends_on:
                    depends_on.append(observation_ref)
                for trace_ref in (implementation_ref, observation_ref):
                    if trace_ref and trace_ref not in trace_refs:
                        trace_refs.append(trace_ref)
            verified_external: list[str] = []
            for dependency_ref in depends_on:
                if str(dependency_ref).startswith("execution_observation:"):
                    self._observations.result_for_artifact(str(dependency_ref))
                    verified_external.append(str(dependency_ref))
            receipt = self._artifacts.publish(
                artifact_kind=artifact_kind,
                artifact_id=(
                    str(arguments["artifact_id"])
                    if arguments.get("artifact_id")
                    else None
                ),
                title=str(arguments.get("title", "")),
                markdown=str(arguments.get("markdown", "")),
                summary=str(arguments.get("summary", "")),
                status=str(arguments.get("status", "proposed")),
                machine_payload=machine_payload,
                depends_on=tuple(depends_on),
                trace_refs=tuple(trace_refs),
                self_review=dict(arguments.get("self_review") or {}),
                verified_external_dependencies=tuple(verified_external),
            )
            if artifact_kind == "capability_candidate":
                self._refresh_pending_capabilities()
            return receipt
        active_skill_id = self._state.read()["c1"]["active_skill_id"]
        route_arguments = dict(arguments)
        if "execution_workspace_ref" in route_arguments:
            self._ensure_child_external_ref_visible(str(route_arguments["execution_workspace_ref"]))
        if name == "write_code_artifact":
            dependencies = list(route_arguments.get("depends_on") or ())
            for lineage_ref in self._active_capability_lineage_refs():
                if lineage_ref not in dependencies:
                    dependencies.append(lineage_ref)
            route_arguments["depends_on"] = dependencies
        result = self._routes.execute(
            name,
            route_arguments,
            skill_id=active_skill_id,
        )
        self._active_pending_route_lineage_refs.update(self._routes.lineage_refs(name))
        return result

    def _validate_dispatch_child_mission(self, mission: ChildMission) -> None:
        """Keep whole-node delegation inside the active node dataflow."""
        state = self._state.read()
        try:
            require_child_capability_subset(
                mission.enabled_meta_capabilities,
                parent_values=state["c0"]["enabled_meta_capabilities"],
            )
        except ValueError as exc:
            raise PermissionError(str(exc)) from exc
        if state["c1"]["active_skill_id"]:
            raise RuntimeError("spawn_child_forbidden_inside_active_skill")
        active = active_work_unit(state["c1"]["plan_graph"])
        if active is None:
            raise RuntimeError("spawn_child_requires_active_graph_node")
        loop_state = state["c1"]["node_loop_state"]
        if bool(loop_state["awaiting_transition"]):
            raise RuntimeError("spawn_child_forbidden_while_awaiting_transition")
        if next_skill_id(loop_state, node_id=str(active["node_id"])):
            raise RuntimeError("spawn_child_forbidden_inside_node_loop")
        if self._pending_child_review_packets():
            raise RuntimeError("spawn_child_requires_prior_child_review")
        attempt_index = self._next_node_execution_attempt_index()
        allowed_refs = set(self._active_node_input_refs(state))
        allowed_refs.update(self._active_graph_revision_child_context_refs(state))
        for ref in mission.work_entry_refs:
            entry = self._work.store.read_entry(ref, agent_id=self.agent_id)
            if not self._work.allows(entry["source_refs"]):
                raise PermissionError(f"child_work_entry_sources_not_visible:{ref}")
            allowed_refs.update(entry["source_refs"])
            allowed_refs.update(artifact_dependency_closure_refs(
                self._artifacts.list(), read_artifact=self._artifacts.read,
                explicit_refs=tuple(ref for ref in entry["source_refs"] if ref.startswith("artifact:")),
            ))
            allowed_refs.update(self._observation_dependency_closure_refs(
                tuple(ref for ref in entry["source_refs"] if ref.startswith("execution_observation:")),
            ))
        observation_refs = self._execution_observations_for_inputs(
            mission.artifact_refs, state
        )
        allowed_refs.update(observation_refs)
        allowed_refs.update(
            self._operational_refs_for_execution_observations(observation_refs)
        )
        unauthorized = [ref for ref in mission.artifact_refs if ref not in allowed_refs]
        if unauthorized:
            raise PermissionError(
                "child_mission_ref_outside_active_graph_node:" + ",".join(unauthorized)
            )
        mission_refs = set(mission.artifact_refs)
        required_refs = artifact_dependency_closure_refs(
            self._artifacts.list(),
            read_artifact=self._artifacts.read,
            explicit_refs=mission.artifact_refs,
        )
        missing_dependencies = [ref for ref in required_refs if ref not in mission_refs]
        if missing_dependencies:
            raise ValueError(
                "child_mission_dependency_refs_must_be_explicitly_mounted:"
                + ",".join(missing_dependencies)
            )

    def _observation_dependency_closure_refs(
        self,
        observation_refs: Sequence[str],
    ) -> tuple[str, ...]:
        """Follow only exact observation provenance named by stored metadata."""
        seen = set(observation_refs)
        pending = list(observation_refs)
        dependencies: list[str] = []
        while pending:
            stored = self._read_exact_ref(pending.pop(0))
            identity = _observation_current_state_identity(stored)
            for dependency_ref in identity[1] if identity is not None else ():
                if (
                    not dependency_ref.startswith("execution_observation:")
                    or dependency_ref in seen
                ):
                    continue
                seen.add(dependency_ref)
                dependencies.append(dependency_ref)
                pending.append(dependency_ref)
        return tuple(dependencies)

    def _execution_observations_for_inputs(
        self, input_refs: Sequence[str], state: Mapping[str, Any],
    ) -> tuple[str, ...]:
        """Use the same exact operational inputs for local and delegated work."""
        candidates = [ref for ref in self._mission.artifact_refs
                      if ref.startswith("execution_observation:")] if self._mission else []
        outcome_ref = self._active_graph_revision_outcome_ref(state)
        if outcome_ref:
            payload = self._read_exact_ref(outcome_ref)["machine_payload"]
            candidates.extend(ref for attempt in payload["attempts"]
                              for ref in attempt["observation_refs"])
        inputs = artifact_dependency_closure_refs(
            self._artifacts.list(), read_artifact=self._read_exact_ref,
            explicit_refs=tuple(ref for ref in input_refs if ref.startswith("artifact:")),
        )
        return related_observation_refs(
            tuple(dict.fromkeys(candidates)),
            input_refs=(*inputs, *(ref for ref in input_refs
                                  if not ref.startswith("execution_observation:"))),
            read=self._read_exact_ref, identity=_observation_current_state_identity,
        )

    def _operational_refs_for_execution_observations(
        self,
        observation_refs: Sequence[str],
    ) -> tuple[str, ...]:
        """Mount exact retained workspaces named by already-authorized observations."""
        operational_refs: list[str] = []
        for observation_ref in observation_refs:
            stored = self._read_exact_ref(observation_ref)
            result = stored.get("result")
            if not isinstance(result, Mapping):
                continue
            workspace_ref = str(result.get("execution_workspace_ref") or "").strip()
            if workspace_ref.startswith("materializer_execution_workspace:"):
                operational_refs.append(workspace_ref)
        return tuple(dict.fromkeys(operational_refs))

    def _active_graph_revision_outcome_ref(self, state: Mapping[str, Any]) -> str:
        """Graph revision numbers are local to the producing agent."""
        graph_revision = int(state["c1"]["plan_graph"]["revision"])
        if graph_revision <= 1:
            return ""

        for raw_ref in reversed(state["c1"]["resolved_artifact_refs"]):
            ref = str(raw_ref).strip()
            if not ref.startswith("artifact:"):
                continue
            try:
                stored = self._read_exact_ref(ref)
            except (KeyError, OSError, PermissionError, ValueError):
                continue
            payload = stored.get("machine_payload")
            if (
                stored.get("artifact_kind") == GRAPH_REVISION_OUTCOME_KIND
                and stored.get("status") == "accepted"
                and stored.get("producer_agent_id") == self.agent_id
                and isinstance(payload, Mapping)
                and payload.get("source_revision") == graph_revision - 1
            ):
                return ref
        return ""

    def _active_graph_revision_child_context_refs(
        self,
        state: Mapping[str, Any] | None = None,
    ) -> tuple[str, ...]:
        """Return the exact revision record that produced the current Graph."""
        current = dict(state or self._state.read())
        outcome_ref = self._active_graph_revision_outcome_ref(current)
        if not outcome_ref:
            return ()

        context_refs = artifact_dependency_closure_refs(
            self._artifacts.list(),
            read_artifact=self._artifacts.read,
            explicit_refs=(outcome_ref,),
        )
        allowed_refs = set(self._active_node_input_refs(current))
        allowed_refs.add(outcome_ref)
        unavailable = [ref for ref in context_refs if ref not in allowed_refs]
        if unavailable:
            raise RuntimeError(
                "graph_revision_child_context_dependency_not_visible:"
                + ",".join(unavailable)
            )
        return tuple(context_refs)

    def _read_formal_ref(self, artifact_ref: str) -> dict[str, Any]:
        if self._artifacts.is_quarantined(artifact_ref):
            if not self._is_pending_child_artifact(artifact_ref):
                raise PermissionError(f"artifact_pending_child_review:{artifact_ref}")
            artifact = self._artifacts.read_for_review(artifact_ref)
            self._review_only_artifact = artifact
            self._inspected_pending_child_refs.add(artifact_ref)
            return {
                "status": "child_review_artifact_resolved",
                "artifact_ref": artifact_ref,
                "artifact_kind": artifact["artifact_kind"],
                "review_only": True,
            }
        artifact = self._read_exact_ref(artifact_ref)
        if artifact.get("artifact_kind") == "code_artifact":
            if self._code_artifacts is None:
                raise KeyError("code_artifact_store_unavailable")
            self._state.activate_resolved_artifact_ref(
                artifact_ref,
                superseded_refs=self._code_artifacts.ancestor_refs(artifact_ref),
            )
        elif artifact.get("artifact_kind") == "execution_observation":
            self._activate_observation_ref(artifact_ref, artifact)
        else:
            self._state.add_resolved_artifact_ref(artifact_ref)
        return {
            "status": "artifact_resolved",
            "artifact_ref": artifact_ref,
            "artifact_kind": artifact["artifact_kind"],
        }

    def _release_skill_context(self) -> None:
        """Release C1 invocation refs; formal inputs remain authoritative in C2."""
        self._state.release_skill_context()
        self._active_pending_route_lineage_refs.clear()
        # A skill invocation owns only its selected working refs. Explicit run
        # inputs and mission mounts remain authoritative for later node attempts
        # and must be reintroduced at the next planning boundary.
        self._mount_run_inputs()

    def _activate_tool_result_refs(
        self,
        tool_name: str,
        raw_result: Mapping[str, Any],
    ) -> None:
        workspace_ref = str(raw_result.get("execution_workspace_ref") or "")
        if workspace_ref.startswith("materializer_execution_workspace:"):
            self._owned_external_refs.add(workspace_ref)
        snapshot_ref = str(raw_result.get("snapshot_ref") or "")
        if (
            tool_name == "development_project_checkpoint"
            and raw_result.get("status")
            == "development_project_checkpoint_created"
            and snapshot_ref.startswith("artifact:")
        ):
            self._artifacts.register_produced_refs((snapshot_ref,))

        code_ref = str(raw_result.get("code_artifact_ref") or "")
        if code_ref.startswith("code_artifact:") and tool_name in {
            "write_code_artifact",
            "edit_code_artifact",
        }:
            self._owned_external_refs.add(code_ref)

        if tool_name != "read_ref":
            for key in ("stdout_ref", "stderr_ref", "diff_ref"):
                ref = str(raw_result.get(key) or "")
                if ref.startswith("development_output:"):
                    self._owned_external_refs.add(ref)

        observation_ref = str(raw_result.get("observation_ref") or "")
        if not observation_ref.startswith("execution_observation:"):
            return
        if raw_result.get("status") != "execution_observation_inspected":
            self._owned_external_refs.add(observation_ref)
        self._activate_observation_ref(
            observation_ref,
            self._read_exact_ref(observation_ref),
        )

    def _activate_observation_ref(
        self,
        observation_ref: str,
        stored: Mapping[str, Any],
    ) -> None:
        refs = [ref for ref in self._state.read()["c1"]["resolved_artifact_refs"]
                if ref.startswith("execution_observation:")]
        ordered = self._observations.ordered_refs((*refs, observation_ref))
        current = current_observation_refs(
            ordered, read=self._read_exact_ref,
            identity=_observation_current_state_identity,
            creation_order=self._observations.ordered_refs,
        )
        superseded = [ref for ref in refs if ref not in current]
        if not current:
            return
        self._state.activate_resolved_artifact_ref(
            observation_ref if observation_ref in current else current[-1],
            superseded_refs=tuple(superseded),
        )

    def _read_exact_ref(self, artifact_ref: str) -> dict[str, Any]:
        ref = str(artifact_ref).strip()
        if ref.startswith("reference:"):
            return self._reference_resolver().read(ref)
        if ref.startswith(("work_context:", "work_entry:")):
            return self._work.read(ref)
        if ref.startswith("development_output:"):
            self._ensure_child_external_ref_visible(ref)
            if self._development_projects is None:
                raise KeyError(f"development_project_store_unavailable:{ref}")
            return self._development_projects.read_output(ref)
        if ref.startswith("code_artifact:"):
            self._ensure_child_external_ref_visible(ref)
            if self._code_artifacts is None:
                raise KeyError(f"code_artifact_store_unavailable:{ref}")
            return self._code_artifacts.read(ref)
        if ref.startswith("execution_observation:"):
            self._ensure_child_external_ref_visible(ref)
            stored = self._observations.read(ref)
            stored["_inspected"] = self._observations.is_inspected(ref)
            return stored
        return self._artifacts.read(ref)

    def _reference_resolver(self) -> ReferenceResolver:
        return ReferenceResolver(self._load_reference_source)

    def _load_reference_source(self, ref: str, path: str | None) -> Any:
        if ref.startswith(("source_file:", "source_probe:", "workspace_terminal:")):
            if path is not None:
                raise ValueError("reference_path_requires_snapshot")
            return self._routes.reference_source(ref)
        # Resolve the canonical ref first: scoped stores and child mounts remain authority.
        stored = self._read_exact_ref(ref)
        if path is not None:
            if stored.get("artifact_kind") != "development_project_snapshot":
                raise ValueError("reference_path_requires_snapshot")
            if self._development_projects is None:
                raise ValueError("development_project_store_unavailable")
            return self._development_projects.snapshot_file_bytes(ref, path)
        if ref.startswith("development_output:"):
            return self._development_projects.output_bytes(ref)
        if ref.startswith("execution_observation:"):
            stored.pop("_inspected", None)
        return stored

    def _ensure_child_external_ref_visible(self, ref: str) -> None:
        if (
            self._mission
            and ref not in self._mounted_external_refs
            and ref not in self._owned_external_refs
        ):
            raise PermissionError(f"child_external_ref_not_mounted:{ref}")


def _runtime_readback_receipt_projection(
    result: Mapping[str, Any],
) -> dict[str, Any]:
    """Persist completion identity for a mechanical read without its C4 body."""
    projection: dict[str, Any] = {
        "status": str(result.get("status") or "completed")
    }
    for key in (
        "artifact_ref",
        "code_artifact_ref",
        "observation_ref",
        "source_ref",
    ):
        value = str(result.get(key) or "").strip()
        if value:
            projection[key] = value
    return projection


def _visible_read_refs(
    state: Mapping[str, Any],
    *,
    formal_artifact_index: Sequence[Mapping[str, Any]] = (),
    additional_values: Sequence[Any] = (),
) -> tuple[str, ...]:
    """Expose exact identities already present in the active C1 dataflow."""
    c1 = state.get("c1")
    if not isinstance(c1, Mapping):
        return ()
    values = (
        c1.get("resolved_artifact_refs"),
        c1.get("recent_bounded_receipts"),
        c1.get("node_loop_state"),
        formal_artifact_index,
        *additional_values,
    )
    return _readable_exact_refs(values)


def _readable_exact_refs(*values: Any) -> tuple[str, ...]:
    """Keep readable exact refs from the supplied visibility projection."""
    readable_prefixes = (
        "artifact:",
        "code_artifact:",
        "execution_observation:",
        "source_file:",
        "source_probe:",
        "workspace_terminal:",
        "development_output:",
        "reference:v1:",
    )
    refs: list[str] = []
    for value in values:
        for candidate in _exact_string_refs(value):
            if candidate.startswith(readable_prefixes) and candidate not in refs:
                refs.append(candidate)
    return tuple(refs)


def _pending_node_attempt_issue_is_authoritative(
    state: Mapping[str, Any],
) -> bool:
    """Keep a finished attempt's root gap until the next attempt is planned."""
    c1 = state.get("c1")
    if not isinstance(c1, Mapping) or not str(c1.get("current_issue") or ""):
        return False
    if str(c1.get("active_skill_id") or ""):
        return False
    loop_state = c1.get("node_loop_state")
    if not isinstance(loop_state, Mapping):
        return False
    steps = loop_state.get("steps")
    if (
        int(loop_state.get("attempt_index") or 0) < 1
        or not isinstance(steps, Sequence)
        or isinstance(steps, (str, bytes))
        or bool(steps)
        or bool(loop_state.get("awaiting_transition"))
    ):
        return False
    active = active_work_unit(c1.get("plan_graph") or {})
    return active is not None and str(loop_state.get("node_id") or "") == str(
        active.get("node_id") or ""
    )


def _read_ref_repair_constraint(
    call: ToolCall,
    *,
    tool_spec: Mapping[str, Any],
    issues: Sequence[str],
) -> tuple[str | None, str]:
    """Allow only one unambiguous transcription repair of an exact read ref."""
    if call.name != "read_ref":
        return None, ""
    attempted = str(call.arguments.get("ref") or "").strip()
    if not attempted:
        return None, ""
    parameters = tool_spec.get("function", {}).get("parameters", {})
    ref_schema = parameters.get("properties", {}).get("ref", {})
    allowed = _enumerated_read_refs(ref_schema)
    if attempted in allowed:
        return attempted, ""
    if not {"$.ref:value_not_in_enum", "$.ref:no_matching_any_of"}.intersection(issues):
        return attempted, ""

    namespace = attempted.split(":", 1)[0]
    candidates = tuple(
        item
        for item in allowed
        if item.split(":", 1)[0] == namespace
        and _single_transcription_edit_apart(attempted, item)
    )
    if len(candidates) == 1:
        return candidates[0], ""
    return (
        None,
        "tool_payload_local_repair_not_applicable:"
        "read_ref_exact_identity_unresolvable:"
        f"attempted_ref={attempted}:"
        f"same_namespace_near_match_count={len(candidates)}:"
        "active_skill_must_use_an_exact_visible_ref_or_restart_node_attempt_"
        "with_the_missing_input_gap",
    )


def _mechanical_source_ref_repair(
    call: ToolCall,
    *,
    tool_spec: Mapping[str, Any],
    issues: Sequence[str],
) -> str | None:
    """Recover one source ref when its immutable content digest is exact."""
    if call.name != "read_ref" or not {
        "$.ref:value_not_in_enum", "$.ref:no_matching_any_of",
    }.intersection(issues):
        return None
    attempted = str(call.arguments.get("ref") or "").strip()
    parts = attempted.split(":", 2)
    if len(parts) != 3 or parts[0] != "source_file":
        return None
    digest = parts[1]
    if len(digest) != 64 or any(
        character not in "0123456789abcdef" for character in digest.lower()
    ):
        return None
    parameters = tool_spec.get("function", {}).get("parameters", {})
    ref_schema = parameters.get("properties", {}).get("ref", {})
    matches: list[str] = []
    for value in _enumerated_read_refs(ref_schema):
        candidate_parts = value.split(":", 2)
        if (
            len(candidate_parts) == 3
            and candidate_parts[0] == "source_file"
            and candidate_parts[1].lower() == digest.lower()
        ):
            matches.append(value)
    return matches[0] if len(matches) == 1 else None


def _enumerated_read_refs(schema: Mapping[str, Any]) -> tuple[str, ...]:
    """Collect declared exact identities, including the work-ref alternative."""
    refs = [ref for ref in schema.get("enum", ()) if isinstance(ref, str) and ref]
    for alternative in schema.get("anyOf", ()):
        if isinstance(alternative, Mapping):
            refs.extend(_enumerated_read_refs(alternative))
    return tuple(dict.fromkeys(ref for ref in refs if not json_schema_issues(ref, schema)))


def _single_transcription_edit_apart(left: str, right: str) -> bool:
    """Return true only for one insertion, deletion, or substitution."""
    if left == right or abs(len(left) - len(right)) > 1:
        return False
    if len(left) == len(right):
        return sum(a != b for a, b in zip(left, right)) == 1
    shorter, longer = (left, right) if len(left) < len(right) else (right, left)
    short_index = 0
    long_index = 0
    skipped = False
    while short_index < len(shorter) and long_index < len(longer):
        if shorter[short_index] == longer[long_index]:
            short_index += 1
            long_index += 1
            continue
        if skipped:
            return False
        skipped = True
        long_index += 1
    return True
