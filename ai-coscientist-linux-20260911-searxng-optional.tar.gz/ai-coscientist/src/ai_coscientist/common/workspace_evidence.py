from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


_IGNORED_DIRECTORY_NAMES = {
    ".git",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".venv",
    "__pycache__",
    "backups",
    "node_modules",
    "tmp",
}
_DEFAULT_MAX_TEXT_BYTES = 2 * 1024 * 1024
_MAX_TOOL_LIMIT = 200


class WorkspaceEvidenceError(RuntimeError):
    pass


@dataclass(frozen=True)
class _ArtifactRecord:
    artifact_ref: str
    artifact_kind: str
    status: str
    summary: str
    index_path: Path
    storage_path: Path | None

    def public(self, root: Path) -> dict[str, Any]:
        return {
            "target": self.artifact_ref,
            "artifact_ref": self.artifact_ref,
            "artifact_kind": self.artifact_kind,
            "status": self.status,
            "summary": self.summary[:1_000],
            "summary_truncated": len(self.summary) > 1_000,
            "index_path": _relative_label(root, self.index_path),
            "storage_path": (
                _relative_label(root, self.storage_path)
                if self.storage_path is not None
                else None
            ),
        }


class WorkspaceEvidenceEngine:
    """Indexless, read-only evidence retrieval over one project workspace.

    The engine does not maintain a database. Every process starts from the
    filesystem, discovers formal artifact indexes and ordinary files, and only
    reads bodies selected by a caller. It performs transport-level JSON
    aggregation without interpreting scientific meaning.
    """

    def __init__(
        self,
        root: Path,
        *,
        max_text_bytes: int = _DEFAULT_MAX_TEXT_BYTES,
    ) -> None:
        self._root = root.resolve()
        if not self._root.is_dir():
            raise WorkspaceEvidenceError(
                f"workspace_root_not_directory:{self._root}"
            )
        self._max_text_bytes = int(max_text_bytes)
        self._files_cache: tuple[Path, ...] | None = None
        self._artifact_cache: dict[str, _ArtifactRecord] | None = None
        self._artifact_diagnostics: dict[str, Any] = {}

    @property
    def root(self) -> Path:
        return self._root

    @staticmethod
    def tool_spec() -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": "workspace_evidence",
                "description": (
                    "Search and inspect exact evidence in the current workspace. "
                    "Use search for ordinary files or formal artifacts, inspect "
                    "for exact bodies, aggregate for numeric ranking/counting over "
                    "structured artifact rows or grouping across artifact fields, "
                    "and source_status before making a "
                    "claim about an unavailable external/private source. This is "
                    "read-only and creates no persistent index."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": [
                                "search",
                                "inspect",
                                "aggregate",
                                "source_status",
                            ],
                        },
                        "queries": {
                            "type": "array",
                            "items": {"type": "string"},
                            "maxItems": 8,
                        },
                        "scopes": {
                            "type": "array",
                            "items": {
                                "type": "string",
                                "enum": [
                                    "artifact_catalog",
                                    "file_path",
                                    "file_text",
                                ],
                            },
                        },
                        "artifact_kinds": {
                            "type": "array",
                            "items": {"type": "string"},
                            "maxItems": 20,
                        },
                        "targets": {
                            "type": "array",
                            "items": {"type": "string"},
                            "maxItems": 40,
                        },
                        "artifact_kind": {"type": "string"},
                        "records_path": {
                            "type": "string",
                            "description": (
                                "Dot-separated path to the row list inside each "
                                "artifact, for example machine_payload.ranked_entries."
                            ),
                        },
                        "group_by": {
                            "type": "string",
                            "description": (
                                "Dot-separated scalar field path used to group whole "
                                "artifacts, for example "
                                "machine_payload.direction_card.family_id. Omit "
                                "records_path and ranking fields in this mode."
                            ),
                        },
                        "rank_by": {"type": "string"},
                        "secondary_rank_by": {"type": "string"},
                        "dedupe_by": {"type": "string"},
                        "order": {
                            "type": "string",
                            "enum": ["asc", "desc"],
                        },
                        "statuses": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                        "limit": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": _MAX_TOOL_LIMIT,
                        },
                        "max_chars_per_target": {
                            "type": "integer",
                            "minimum": 500,
                            "maximum": 50000,
                        },
                    },
                    "required": ["action"],
                    "additionalProperties": False,
                },
            },
        }

    def execute(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        action = str(arguments.get("action") or "").strip()
        if action == "search":
            return self.search(arguments)
        if action == "inspect":
            return self.inspect(arguments)
        if action == "aggregate":
            return self.aggregate(arguments)
        if action == "source_status":
            return self.source_status()
        raise WorkspaceEvidenceError(f"workspace_evidence_action_invalid:{action}")

    @classmethod
    def tool_specs(cls) -> tuple[dict[str, Any], ...]:
        """Expose high-level operations as distinct model-visible tools."""
        properties = cls.tool_spec()["function"]["parameters"]["properties"]

        def build(
            name: str,
            description: str,
            keys: Sequence[str],
            required: Sequence[str] = (),
        ) -> dict[str, Any]:
            return {
                "type": "function",
                "function": {
                    "name": name,
                    "description": description,
                    "parameters": {
                        "type": "object",
                        "properties": {key: properties[key] for key in keys},
                        "required": list(required),
                        "additionalProperties": False,
                    },
                },
            }

        return (
            build(
                "search_workspace",
                (
                    "Locate formal artifacts, file paths, or exact text across "
                    "the workspace without a persistent index. Do not guess internal "
                    "artifact kinds: results discover exact kind names, counts, "
                    "representative refs, and numeric collection paths mechanically."
                ),
                ("queries", "scopes", "limit"),
                ("queries",),
            ),
            build(
                "inspect_workspace",
                (
                    "Read exact artifact refs or workspace paths returned by search. "
                    "Inspect one representative structured artifact before choosing "
                    "its records_path and numeric ranking fields."
                ),
                ("targets", "max_chars_per_target"),
                ("targets",),
            ),
            build(
                "aggregate_workspace_artifacts",
                (
                    "Mechanically scan every unique artifact of one kind. For row "
                    "mode, provide records_path, rank_by, and dedupe_by to rank "
                    "structured rows. For artifact-group mode, provide group_by only "
                    "to count whole artifacts by a scalar field; formal artifact_ref "
                    "is the identity automatically. Use this instead of manually "
                    "sampling artifacts for global ranking, count, or coverage."
                ),
                (
                    "artifact_kind",
                    "records_path",
                    "group_by",
                    "rank_by",
                    "secondary_rank_by",
                    "dedupe_by",
                    "order",
                    "statuses",
                    "limit",
                ),
                ("artifact_kind",),
            ),
            build(
                "workspace_source_status",
                (
                    "Report which workspace, private knowledge, and public literature "
                    "sources are actually configured. Call this before interpreting "
                    "zero local matches as a statement about external/private data."
                ),
                (),
            ),
        )

    def dispatch(self, tool_name: str, arguments: Mapping[str, Any]) -> dict[str, Any]:
        action_by_tool = {
            "search_workspace": "search",
            "inspect_workspace": "inspect",
            "aggregate_workspace_artifacts": "aggregate",
            "workspace_source_status": "source_status",
        }
        action = action_by_tool.get(tool_name)
        if action is None:
            raise WorkspaceEvidenceError(
                f"workspace_evidence_tool_invalid:{tool_name}"
            )
        return self.execute({"action": action, **dict(arguments)})

    def search(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        queries = _clean_strings(arguments.get("queries"), maximum=8)
        artifact_kinds = set(
            _clean_strings(arguments.get("artifact_kinds"), maximum=20)
        )
        if not queries and not artifact_kinds:
            raise WorkspaceEvidenceError(
                "workspace_evidence_search_query_or_artifact_kind_required"
            )
        scopes = _clean_strings(arguments.get("scopes"), maximum=3) or [
            "artifact_catalog",
            "file_path",
            "file_text",
        ]
        invalid_scopes = set(scopes) - {
            "artifact_catalog",
            "file_path",
            "file_text",
        }
        if invalid_scopes:
            raise WorkspaceEvidenceError(
                "workspace_evidence_search_scope_invalid:"
                + ",".join(sorted(invalid_scopes))
            )
        limit = _bounded_limit(arguments.get("limit"), default=30)

        artifact_matches: list[dict[str, Any]] = []
        artifact_match_count = 0
        artifact_kind_summary: list[dict[str, Any]] = []
        if "artifact_catalog" in scopes:
            scored: list[tuple[int, _ArtifactRecord]] = []
            for record in self._artifacts().values():
                if artifact_kinds and record.artifact_kind not in artifact_kinds:
                    continue
                haystack = " ".join(
                    (
                        record.artifact_ref,
                        record.artifact_kind,
                        record.status,
                        record.summary,
                        _relative_label(self._root, record.index_path),
                    )
                )
                score = _query_score(haystack, queries)
                score += 4 * _query_score(record.artifact_kind, queries)
                if score or artifact_kinds:
                    scored.append((score, record))
            scored.sort(
                key=lambda item: (
                    -item[0],
                    item[1].artifact_kind,
                    item[1].artifact_ref,
                )
            )
            artifact_match_count = len(scored)
            artifact_matches = [
                {"match_score": score, **record.public(self._root)}
                for score, record in scored[:limit]
            ]
            kind_stats: dict[str, dict[str, Any]] = {}
            for score, record in scored:
                stats = kind_stats.setdefault(
                    record.artifact_kind,
                    {
                        "artifact_kind": record.artifact_kind,
                        "unique_match_count": 0,
                        "best_match_score": score,
                        "representative_target": record.artifact_ref,
                    },
                )
                stats["unique_match_count"] += 1
                stats["best_match_score"] = max(
                    int(stats["best_match_score"]), score
                )
            ranked_kind_stats = sorted(
                kind_stats.values(),
                key=lambda item: (
                    -int(item["best_match_score"]),
                    -int(item["unique_match_count"]),
                    str(item["artifact_kind"]),
                ),
            )[:8]
            hints_by_kind = {
                hint["artifact_kind"]: hint
                for hint in self._structured_collection_hints(
                    {
                        str(item["artifact_kind"])
                        for item in ranked_kind_stats
                    }
                )
            }
            artifact_kind_summary = [
                {
                    **stats,
                    "numeric_collections": hints_by_kind.get(
                        str(stats["artifact_kind"]), {}
                    ).get("collections", []),
                }
                for stats in ranked_kind_stats
            ]

        path_matches: list[dict[str, Any]] = []
        if "file_path" in scopes and queries:
            scored_paths = [
                (_query_score(_relative_label(self._root, path), queries), path)
                for path in self._files()
            ]
            scored_paths = [item for item in scored_paths if item[0] > 0]
            scored_paths.sort(key=lambda item: (-item[0], str(item[1])))
            path_matches = [
                {
                    "target": f"workspace:{_relative_label(self._root, path)}",
                    "relative_path": _relative_label(self._root, path),
                    "evidence_role": _evidence_role(self._root, path),
                    "size_bytes": path.stat().st_size,
                    "match_score": score,
                }
                for score, path in scored_paths[:limit]
            ]

        text_matches: list[dict[str, Any]] = []
        if "file_text" in scopes and queries:
            text_matches = self._search_text(queries, limit=limit)

        return {
            "status": "workspace_evidence_search_ready",
            "queries": queries,
            "scopes": scopes,
            "artifact_kinds": sorted(artifact_kinds),
            "artifact_match_count": artifact_match_count,
            "returned_artifact_match_count": len(artifact_matches),
            "path_match_count": len(path_matches),
            "text_match_count": len(text_matches),
            "artifact_matches": artifact_matches,
            "artifact_kind_summary": artifact_kind_summary,
            "path_matches": path_matches,
            "text_matches": text_matches,
            "catalog_diagnostics": dict(self._artifact_diagnostics),
            "interpretation_warning": (
                "Zero matches describe only the searched workspace scopes. They "
                "do not prove that an unconfigured private or external source is "
                "empty. Use source_status before drawing that conclusion."
            ),
        }

    def _structured_collection_hints(
        self, artifact_kinds: set[str]
    ) -> list[dict[str, Any]]:
        if not artifact_kinds:
            return []
        hints: list[dict[str, Any]] = []
        for artifact_kind in sorted(artifact_kinds):
            observed: dict[str, dict[str, Any]] = {}
            inspected = 0
            for record in self._artifacts().values():
                if record.artifact_kind != artifact_kind or record.storage_path is None:
                    continue
                try:
                    body = json.loads(record.storage_path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    continue
                inspected += 1
                for path, rows in _mapping_list_paths(body):
                    entry = observed.setdefault(
                        path,
                        {
                            "records_path": path,
                            "observed_row_count": 0,
                            "numeric_fields": set(),
                            "other_fields": set(),
                        },
                    )
                    entry["observed_row_count"] += len(rows)
                    for row in rows:
                        for key, value in row.items():
                            if _numeric_value(value) is not None:
                                entry["numeric_fields"].add(str(key))
                            else:
                                entry["other_fields"].add(str(key))
                if inspected >= 5:
                    break
            hints.append(
                {
                    "artifact_kind": artifact_kind,
                    "sample_artifact_count": inspected,
                    "collections": [
                        {
                            **entry,
                            "numeric_fields": sorted(entry["numeric_fields"]),
                            "other_fields": sorted(entry["other_fields"]),
                            "identity_candidates": sorted(
                                field
                                for field in entry["other_fields"]
                                if field == "id"
                                or field.endswith("_id")
                                or field.endswith("_ref")
                            ),
                        }
                        for entry in sorted(
                            observed.values(), key=lambda item: item["records_path"]
                        )
                        if entry["numeric_fields"]
                    ],
                }
            )
        return hints

    def inspect(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        targets = _clean_strings(arguments.get("targets"), maximum=40)
        if not targets:
            raise WorkspaceEvidenceError("workspace_evidence_targets_required")
        max_chars = _bounded_integer(
            arguments.get("max_chars_per_target"),
            default=12_000,
            minimum=500,
            maximum=50_000,
        )
        inspected: list[dict[str, Any]] = []
        for target in targets:
            path: Path | None
            artifact_ref = ""
            if target.startswith("artifact:"):
                artifact_ref = target
                record = self._artifacts().get(target)
                if record is None:
                    inspected.append(
                        {"target": target, "status": "artifact_not_found"}
                    )
                    continue
                path = record.storage_path
                if path is None:
                    inspected.append(
                        {
                            "target": target,
                            "status": "artifact_body_not_found",
                            **record.public(self._root),
                        }
                    )
                    continue
            else:
                path = self._resolve_workspace_target(target)
            try:
                content = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError) as exc:
                inspected.append(
                    {
                        "target": target,
                        "status": "read_failed",
                        "reason": f"{type(exc).__name__}: {exc}",
                    }
                )
                continue
            try:
                parsed = json.loads(content)
            except json.JSONDecodeError:
                parsed = None
            preview = content[:max_chars]
            entry: dict[str, Any] = {
                "target": target,
                "status": "workspace_evidence_ready",
                "relative_path": _relative_label(self._root, path),
                "content_chars": len(content),
                "truncated": len(content) > len(preview),
                "content": preview,
            }
            if artifact_ref:
                entry["artifact_ref"] = artifact_ref
            if isinstance(parsed, Mapping):
                entry["top_level_keys"] = sorted(str(key) for key in parsed)
                payload = parsed.get("machine_payload")
                if isinstance(payload, Mapping):
                    entry["machine_payload_keys"] = sorted(
                        str(key) for key in payload
                    )
            inspected.append(entry)
        return {
            "status": "workspace_evidence_inspection_ready",
            "target_count": len(targets),
            "inspected": inspected,
        }

    def aggregate(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        artifact_kind = str(arguments.get("artifact_kind") or "").strip()
        records_path = str(arguments.get("records_path") or "").strip()
        group_by = str(arguments.get("group_by") or "").strip()
        rank_by = str(arguments.get("rank_by") or "").strip()
        if not artifact_kind:
            raise WorkspaceEvidenceError(
                "workspace_evidence_aggregate_artifact_kind_required"
            )
        if group_by:
            if records_path or rank_by or arguments.get("secondary_rank_by"):
                raise WorkspaceEvidenceError(
                    "workspace_evidence_aggregate_mode_conflict"
                )
            if arguments.get("dedupe_by"):
                raise WorkspaceEvidenceError(
                    "workspace_evidence_artifact_group_uses_artifact_ref_identity"
                )
            return self._aggregate_artifact_groups(
                artifact_kind=artifact_kind,
                group_by=group_by,
                statuses=set(
                    _clean_strings(arguments.get("statuses"), maximum=20)
                ),
                limit=_bounded_limit(arguments.get("limit"), default=20),
            )
        if not records_path:
            raise WorkspaceEvidenceError(
                "workspace_evidence_aggregate_records_path_or_group_by_required"
            )
        if not rank_by:
            raise WorkspaceEvidenceError(
                "workspace_evidence_aggregate_rank_by_required"
            )
        secondary_rank_by = str(
            arguments.get("secondary_rank_by") or ""
        ).strip()
        dedupe_by = str(arguments.get("dedupe_by") or "").strip()
        order = str(arguments.get("order") or "desc").strip()
        if order not in {"asc", "desc"}:
            raise WorkspaceEvidenceError(
                f"workspace_evidence_aggregate_order_invalid:{order}"
            )
        statuses = set(_clean_strings(arguments.get("statuses"), maximum=20))
        limit = _bounded_limit(arguments.get("limit"), default=10)

        rows: list[dict[str, Any]] = []
        source_artifact_count = 0
        unreadable_artifact_refs: list[str] = []
        source_status_counts: dict[str, int] = {}
        for record in self._artifacts().values():
            if record.artifact_kind != artifact_kind:
                continue
            if statuses and record.status not in statuses:
                continue
            source_artifact_count += 1
            source_status_counts[record.status] = (
                source_status_counts.get(record.status, 0) + 1
            )
            if record.storage_path is None:
                unreadable_artifact_refs.append(record.artifact_ref)
                continue
            try:
                body = json.loads(record.storage_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                unreadable_artifact_refs.append(record.artifact_ref)
                continue
            selected = _get_dot_path(body, records_path)
            if isinstance(selected, Mapping):
                selected_rows: Iterable[Any] = (selected,)
            elif isinstance(selected, list):
                selected_rows = selected
            else:
                continue
            for row in selected_rows:
                if not isinstance(row, Mapping):
                    continue
                rows.append(
                    {
                        **dict(row),
                        "_source_artifact_ref": record.artifact_ref,
                        "_source_status": record.status,
                        "_source_path": _relative_label(
                            self._root, record.storage_path
                        ),
                    }
                )

        reverse = order == "desc"
        rows.sort(
            key=lambda row: (
                _sortable_number(_get_dot_path(row, rank_by), reverse=reverse),
                _sortable_number(
                    _get_dot_path(row, secondary_rank_by), reverse=reverse
                )
                if secondary_rank_by
                else 0.0,
                str(row.get(dedupe_by) or "") if dedupe_by else "",
            ),
            reverse=reverse,
        )
        if dedupe_by:
            deduped: list[dict[str, Any]] = []
            seen: set[str] = set()
            for row in rows:
                value = str(_get_dot_path(row, dedupe_by) or "")
                key = value or json.dumps(row, ensure_ascii=False, sort_keys=True)
                if key in seen:
                    continue
                seen.add(key)
                deduped.append(row)
            rows = deduped

        primary_values = [
            _numeric_value(_get_dot_path(row, rank_by)) for row in rows
        ]
        primary_values = [value for value in primary_values if value is not None]
        best_value = primary_values[0] if primary_values else None
        best_tie_count = (
            sum(value == best_value for value in primary_values)
            if best_value is not None
            else 0
        )
        return {
            "status": "workspace_evidence_aggregation_ready",
            "artifact_kind": artifact_kind,
            "records_path": records_path,
            "rank_by": rank_by,
            "secondary_rank_by": secondary_rank_by or None,
            "dedupe_by": dedupe_by or None,
            "dedupe_applied": bool(dedupe_by),
            "order": order,
            "source_artifact_count": source_artifact_count,
            "source_status_counts": source_status_counts,
            "unreadable_artifact_count": len(unreadable_artifact_refs),
            "unreadable_artifact_refs": unreadable_artifact_refs[:20],
            "row_count_after_dedupe": len(rows),
            "best_primary_value": best_value,
            "best_primary_tie_count": best_tie_count,
            "rows": rows[:limit],
        }

    def _aggregate_artifact_groups(
        self,
        *,
        artifact_kind: str,
        group_by: str,
        statuses: set[str],
        limit: int,
    ) -> dict[str, Any]:
        grouped_refs: dict[str, list[str]] = {}
        grouped_statuses: dict[str, dict[str, int]] = {}
        missing_group_value_refs: list[str] = []
        unreadable_artifact_refs: list[str] = []
        source_status_counts: dict[str, int] = {}
        source_artifact_count = 0

        # _artifacts() is keyed by formal artifact_ref, so copied indexes or
        # repeated catalog entries cannot inflate group counts.
        for record in self._artifacts().values():
            if record.artifact_kind != artifact_kind:
                continue
            if statuses and record.status not in statuses:
                continue
            source_artifact_count += 1
            source_status_counts[record.status] = (
                source_status_counts.get(record.status, 0) + 1
            )
            if record.storage_path is None:
                unreadable_artifact_refs.append(record.artifact_ref)
                continue
            try:
                body = json.loads(record.storage_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                unreadable_artifact_refs.append(record.artifact_ref)
                continue
            value = _get_dot_path(body, group_by)
            if value is None or isinstance(value, (Mapping, list)):
                missing_group_value_refs.append(record.artifact_ref)
                continue
            group_value = str(value).strip()
            if not group_value:
                missing_group_value_refs.append(record.artifact_ref)
                continue
            grouped_refs.setdefault(group_value, []).append(record.artifact_ref)
            status_counts = grouped_statuses.setdefault(group_value, {})
            status_counts[record.status] = status_counts.get(record.status, 0) + 1

        groups = [
            {
                "group_value": group_value,
                "artifact_count": len(refs),
                "status_counts": grouped_statuses[group_value],
                "artifact_refs": sorted(refs),
            }
            for group_value, refs in grouped_refs.items()
        ]
        groups.sort(
            key=lambda item: (-int(item["artifact_count"]), str(item["group_value"]))
        )
        return {
            "status": "workspace_evidence_artifact_groups_ready",
            "aggregation_mode": "artifact_groups",
            "artifact_kind": artifact_kind,
            "group_by": group_by,
            "identity_field": "artifact_ref",
            "source_artifact_count": source_artifact_count,
            "source_status_counts": source_status_counts,
            "grouped_artifact_count": sum(
                int(item["artifact_count"]) for item in groups
            ),
            "missing_group_value_count": len(missing_group_value_refs),
            "missing_group_value_refs": missing_group_value_refs[:limit],
            "unreadable_artifact_count": len(unreadable_artifact_refs),
            "unreadable_artifact_refs": unreadable_artifact_refs[:limit],
            "group_count": len(groups),
            "groups": groups[:limit],
        }

    def source_status(self) -> dict[str, Any]:
        private_endpoint = bool(
            str(
                os.environ.get("AI_COSCIENTIST_PRIVATE_KNOWLEDGE_URL") or ""
            ).strip()
        )
        private_mock = bool(
            str(
                os.environ.get("AI_COSCIENTIST_PRIVATE_KNOWLEDGE_MOCK") or ""
            ).strip()
        )
        public_endpoint = bool(
            str(os.environ.get("AI_COSCIENTIST_SEARXNG_URL") or "").strip()
        )
        artifacts = self._artifacts()
        literature_documents = [
            path
            for path in self._files()
            if "literature-documents" in path.parts
        ]
        return {
            "status": "workspace_evidence_source_status_ready",
            "workspace_root": str(self._root),
            "workspace_file_count": len(self._files()),
            "formal_artifact_count": len(artifacts),
            "artifact_index_count": self._artifact_diagnostics.get(
                "artifact_index_count", 0
            ),
            "literature_document_file_count": len(literature_documents),
            "private_knowledge": {
                "configured": private_endpoint or private_mock,
                "endpoint_configured": private_endpoint,
                "mock_configured": private_mock,
                "queryable_now": private_endpoint or private_mock,
            },
            "public_literature_search": {
                "searxng_configured": public_endpoint,
            },
            "interpretation_warning": (
                "An unconfigured source is unavailable, not known to be empty. "
                "Workspace counts exclude content that only exists behind that source."
            ),
        }

    def _files(self) -> tuple[Path, ...]:
        if self._files_cache is None:
            self._files_cache = tuple(
                sorted(
                    (
                        path
                        for path in self._root.rglob("*")
                        if path.is_file() and not _is_ignored(self._root, path)
                    ),
                    key=lambda path: path.relative_to(self._root).as_posix(),
                )
            )
        return self._files_cache

    def _artifacts(self) -> dict[str, _ArtifactRecord]:
        if self._artifact_cache is not None:
            return self._artifact_cache
        records: dict[str, _ArtifactRecord] = {}
        index_count = 0
        malformed_indexes: list[str] = []
        missing_bodies = 0
        for index_path in self._files():
            if index_path.name != "artifact-index.json":
                continue
            index_count += 1
            try:
                raw = json.loads(index_path.read_text(encoding="utf-8"))
                entries = raw.get("entries")
                if not isinstance(entries, Mapping):
                    raise ValueError("entries_not_object")
            except (OSError, json.JSONDecodeError, ValueError) as exc:
                malformed_indexes.append(
                    f"{_relative_label(self._root, index_path)}:{type(exc).__name__}"
                )
                continue
            for artifact_ref, raw_entry in entries.items():
                if not isinstance(raw_entry, Mapping):
                    continue
                ref = str(raw_entry.get("artifact_ref") or artifact_ref).strip()
                if not ref.startswith("artifact:"):
                    continue
                storage_path = self._resolve_artifact_body(
                    index_path,
                    ref,
                    str(raw_entry.get("storage_path") or ""),
                )
                if storage_path is None:
                    missing_bodies += 1
                candidate = _ArtifactRecord(
                    artifact_ref=ref,
                    artifact_kind=str(raw_entry.get("artifact_kind") or ""),
                    status=str(raw_entry.get("status") or ""),
                    summary=str(raw_entry.get("summary") or ""),
                    index_path=index_path,
                    storage_path=storage_path,
                )
                existing = records.get(ref)
                if existing is None or (
                    existing.storage_path is None and storage_path is not None
                ):
                    records[ref] = candidate
        self._artifact_diagnostics = {
            "artifact_index_count": index_count,
            "unique_artifact_count": len(records),
            "malformed_index_count": len(malformed_indexes),
            "malformed_indexes": malformed_indexes[:20],
            "missing_body_entry_count_before_dedupe": missing_bodies,
        }
        self._artifact_cache = records
        return records

    def _resolve_artifact_body(
        self,
        index_path: Path,
        artifact_ref: str,
        stored_path: str,
    ) -> Path | None:
        candidates: list[Path] = []
        if stored_path:
            raw = Path(stored_path)
            candidates.append(raw if raw.is_absolute() else index_path.parent / raw)
        digest = artifact_ref.rsplit("-", 1)[-1]
        artifact_dir = index_path.parent / "artifacts"
        if artifact_dir.is_dir() and re.fullmatch(r"[a-f0-9]{10}", digest):
            candidates.extend(artifact_dir.glob(f"*{digest}.json"))
        for candidate in candidates:
            try:
                resolved = candidate.resolve()
            except OSError:
                continue
            if resolved.is_file() and resolved.is_relative_to(self._root):
                return resolved
        return None

    def _resolve_workspace_target(self, target: str) -> Path:
        label = target[len("workspace:") :] if target.startswith("workspace:") else target
        candidate = (self._root / label).resolve()
        if not candidate.is_relative_to(self._root):
            raise WorkspaceEvidenceError(
                f"workspace_evidence_target_outside_root:{target}"
            )
        if not candidate.is_file():
            raise WorkspaceEvidenceError(
                f"workspace_evidence_target_not_file:{target}"
            )
        return candidate

    def _search_text(
        self, queries: Sequence[str], *, limit: int
    ) -> list[dict[str, Any]]:
        if shutil.which("rg"):
            try:
                return self._search_text_with_ripgrep(queries, limit=limit)
            except (OSError, subprocess.SubprocessError, json.JSONDecodeError):
                pass
        return self._search_text_with_python(queries, limit=limit)

    def _search_text_with_ripgrep(
        self, queries: Sequence[str], *, limit: int
    ) -> list[dict[str, Any]]:
        found: dict[tuple[str, int, str], dict[str, Any]] = {}
        for query in queries:
            command = [
                "rg",
                "--json",
                "--ignore-case",
                "--fixed-strings",
                "--max-count",
                "3",
                "--glob",
                "!**/.git/**",
                "--glob",
                "!**/backups/**",
                "--glob",
                "!**/tmp/**",
            ]
            if _query_match_mode(query) == "identifier":
                command.append("--word-regexp")
            command.extend((query, str(self._root)))
            completed = subprocess.run(
                command,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=45,
                check=False,
            )
            if completed.returncode not in {0, 1}:
                raise subprocess.SubprocessError(
                    f"ripgrep_failed:{completed.returncode}:{completed.stderr[:500]}"
                )
            for line in completed.stdout.splitlines():
                event = json.loads(line)
                if event.get("type") != "match":
                    continue
                data = event.get("data") or {}
                raw_path = str((data.get("path") or {}).get("text") or "")
                path = Path(raw_path).resolve()
                if not path.is_file() or not path.is_relative_to(self._root):
                    continue
                if _is_ignored(self._root, path):
                    continue
                line_number = int(data.get("line_number") or 0)
                line_text = str((data.get("lines") or {}).get("text") or "").strip()
                relative_path = _relative_label(self._root, path)
                key = (relative_path, line_number, line_text)
                found[key] = {
                    "target": f"workspace:{relative_path}",
                    "relative_path": relative_path,
                    "evidence_role": _evidence_role(self._root, path),
                    "line_number": line_number,
                    "line_preview": line_text[:1_000],
                    "matched_query": query,
                }
                if len(found) >= limit:
                    return list(found.values())
        return list(found.values())[:limit]

    def _search_text_with_python(
        self, queries: Sequence[str], *, limit: int
    ) -> list[dict[str, Any]]:
        lowered = [(query, query.casefold()) for query in queries]
        matches: list[dict[str, Any]] = []
        for path in self._files():
            try:
                if path.stat().st_size > self._max_text_bytes:
                    continue
                content = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            for line_number, line in enumerate(content.splitlines(), start=1):
                folded = line.casefold()
                for query, folded_query in lowered:
                    if not _contains_query(folded, folded_query):
                        continue
                    relative_path = _relative_label(self._root, path)
                    matches.append(
                        {
                            "target": f"workspace:{relative_path}",
                            "relative_path": relative_path,
                            "evidence_role": _evidence_role(self._root, path),
                            "line_number": line_number,
                            "line_preview": line.strip()[:1_000],
                            "matched_query": query,
                        }
                    )
                    break
                if len(matches) >= limit:
                    return matches
        return matches


def _is_ignored(root: Path, path: Path) -> bool:
    try:
        parts = path.relative_to(root).parts
    except ValueError:
        return True
    return any(part in _IGNORED_DIRECTORY_NAMES for part in parts)


def _relative_label(root: Path, path: Path | None) -> str:
    if path is None:
        return ""
    try:
        return path.resolve().relative_to(root).as_posix()
    except ValueError:
        return str(path.resolve())


def _clean_strings(value: Any, *, maximum: int) -> list[str]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return []
    return list(
        dict.fromkeys(
            text
            for item in value[:maximum]
            if (text := str(item).strip())
        )
    )


def _query_score(haystack: str, queries: Sequence[str]) -> int:
    normalized = re.sub(r"[_\W]+", " ", haystack.casefold()).strip()
    score = 0
    for query in queries:
        folded = query.casefold()
        if _contains_query(haystack.casefold(), folded):
            score += 10
        if _query_match_mode(query) == "identifier":
            continue
        normalized_query = re.sub(r"[_\W]+", " ", folded).strip()
        if normalized_query and normalized_query in normalized:
            score += 10
        tokens = [token for token in normalized_query.split() if token]
        score += sum(1 for token in tokens if token in normalized)
    return score


def _query_match_mode(query: str) -> str:
    if re.fullmatch(r"[A-Za-z]{1,8}\d{1,8}", query.strip()):
        return "identifier"
    return "substring"


def _contains_query(haystack: str, folded_query: str) -> bool:
    if _query_match_mode(folded_query) != "identifier":
        return folded_query in haystack
    return (
        re.search(
            rf"(?<![A-Za-z0-9]){re.escape(folded_query)}(?![A-Za-z0-9])",
            haystack,
            flags=re.IGNORECASE,
        )
        is not None
    )


def _evidence_role(root: Path, path: Path) -> str:
    parts = path.relative_to(root).parts
    if not parts:
        return "workspace_file"
    top = parts[0]
    if top == "tests":
        return "test_fixture_or_test_code"
    if top in {"src", "scripts", "skills"}:
        return "implementation_or_skill_definition"
    if top in {"outputs", "runs"}:
        return "runtime_output"
    if top in {"cases_gallery", "dataset", "datasets", "data"}:
        return "declared_source_data"
    if top == "docs":
        return "project_documentation"
    return "workspace_file"


def _get_dot_path(value: Any, path: str) -> Any:
    current = value
    if not path:
        return current
    for part in path.split("."):
        if not isinstance(current, Mapping) or part not in current:
            return None
        current = current[part]
    return current


def _mapping_list_paths(
    value: Any, *, prefix: str = "", depth: int = 0
) -> Iterable[tuple[str, list[Mapping[str, Any]]]]:
    if depth > 5:
        return
    if isinstance(value, Mapping):
        for key, child in value.items():
            child_path = f"{prefix}.{key}" if prefix else str(key)
            if isinstance(child, list) and child and all(
                isinstance(item, Mapping) for item in child
            ):
                yield child_path, child
            elif isinstance(child, Mapping):
                yield from _mapping_list_paths(
                    child, prefix=child_path, depth=depth + 1
                )


def _numeric_value(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return None


def _sortable_number(value: Any, *, reverse: bool) -> float:
    number = _numeric_value(value)
    if number is not None:
        return number
    return float("-inf") if reverse else float("inf")


def _bounded_integer(
    value: Any, *, default: int, minimum: int, maximum: int
) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default
    return max(minimum, min(parsed, maximum))


def _bounded_limit(value: Any, *, default: int) -> int:
    return _bounded_integer(
        value, default=default, minimum=1, maximum=_MAX_TOOL_LIMIT
    )
