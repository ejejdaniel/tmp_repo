from __future__ import annotations

import json
from typing import Any, Callable, Mapping, Sequence

from .attempt_handoffs import (
    build_node_attempt_handoff,
)
from .memory_lifecycle.prompt import (
    artifact_prompt_projection,
    bounded_projection,
    bounded_text,
)
from .memory_lifecycle.policy import (
    PromptBudgetExceeded,
    artifact_dependency_closure_refs,
)
from .planning import (
    GRAPH_REVISION_OUTCOME_KIND,
    active_work_unit,
    active_work_unit_context_refs,
    advance_plan_graph,
    build_graph_revision_outcome,
    graph_revision_attempt_fingerprints,
    operational_attempt_fingerprint,
    record_plan_attempt,
    record_plan_completion,
    render_graph_revision_outcome,
    frame_goal_is_ready,
    frame_goal_node,
    settle_frame_graph,
)
from .planning.create_initial_plan import (
    assess_work_unit,
    create_initial_plan,
)
from .planning.node_loop import (
    NODE_LOOP_COST_BY_COMPLEXITY,
    NODE_LOOP_MAX_ATTEMPTS,
    NodeLoopCostLimitError,
    NodeLoopPlanError,
    NodeLoopStepCallLimitError,
    complete_current_step,
    create_node_loop_plan,
    mark_awaiting_transition,
    next_skill_id,
    node_loop_step_llm_call_limit,
)
from .planning.rebuild_graph import GraphRebuildError, rebuild_graph
from .planning.select_frame_goal import select_frame_goal
from ._runtime_support import task_work_skill_cards as _task_work_skill_cards
from .sub_loop_toolkit import human_input_tool as build_human_input_tool


_STALE_PLAN_SIGNAL = (
    "plan_status_conflicts_with_evaluation_state: the current graph has no "
    "active remaining work while success criteria remain unmet"
)

_OPERATIONAL_CONTINUITY_ARTIFACT_KINDS = frozenset(
    {"development_project_snapshot"}
)


def _unmet_criterion_records(
    evaluation_state: Mapping[str, Any],
) -> list[dict[str, Any]]:
    raw_results = evaluation_state.get("criterion_results")
    if isinstance(raw_results, (str, bytes)) or not isinstance(
        raw_results, Sequence
    ):
        raise ValueError("graph_rebuild_evaluation_results_invalid")
    records: list[dict[str, Any]] = []
    for raw in raw_results:
        if not isinstance(raw, Mapping):
            raise ValueError("graph_rebuild_evaluation_result_invalid")
        status = str(raw.get("status") or "").strip()
        if status == "met":
            continue
        if status not in {"unmet", "indeterminate"}:
            raise ValueError("graph_rebuild_evaluation_status_invalid")
        criterion_id = str(raw.get("criterion_id") or "").strip()
        reason = str(raw.get("reason") or "").strip()
        raw_refs = raw.get("evidence_refs")
        if (
            not criterion_id
            or not reason
            or isinstance(raw_refs, (str, bytes))
            or not isinstance(raw_refs, Sequence)
        ):
            raise ValueError("graph_rebuild_evaluation_result_shape_invalid")
        refs = [str(ref).strip() for ref in raw_refs if str(ref).strip()]
        if len(refs) != len(raw_refs) or len(refs) != len(set(refs)):
            raise ValueError("graph_rebuild_evaluation_refs_invalid")
        records.append(
            {
                "criterion_id": criterion_id,
                "status": status,
                "evidence_refs": refs,
                "reason": bounded_text(reason, 2_000),
            }
        )
    return records


class PlanningRuntimeMixin:
    """Private initial-plan and progress-assessment workflow."""

    def _ensure_initial_plan(self) -> None:
        state = self._state.read()
        if state["c1"]["plan_graph"]["nodes"]:
            return
        if self._active_artifact_index():
            initial_closure = self._evaluate_agent_closure(
                round_number=0,
                scope="global",
            )
            if bool(initial_closure.get("complete")):
                self._events.append(
                    "initial_plan_not_required",
                    {"reason": "starting_evidence_satisfies_evaluation_gate"},
                )
                return
        else:
            self._events.append(
                "initial_evaluation_skipped",
                {"reason": "no_accepted_evidence_to_judge"},
            )
        graph = self._build_initial_plan_graph()
        self._state.set_plan_graph(graph)
        self._replace_frame_evaluation_for_graph()
        self._events.append("initial_plan_created", {"plan_graph": graph})

    def _ensure_node_loop_plan(
        self,
        *,
        round_number: int = 0,
        attempt_index: int | None = None,
    ) -> bool:
        """Create the next node-local attempt or rebuild an unusable graph."""
        state = self._state.read()
        active = active_work_unit(state["c1"]["plan_graph"])
        if active is None:
            return False
        node_id = str(active["node_id"])
        loop_state = state["c1"]["node_loop_state"]
        if bool(loop_state["awaiting_transition"]):
            return False
        if next_skill_id(loop_state, node_id=node_id):
            return False

        previous_attempt = (
            int(loop_state["attempt_index"])
            if str(loop_state["node_id"]) == node_id
            else 0
        )
        next_attempt = previous_attempt + 1
        if attempt_index is not None and int(attempt_index) != next_attempt:
            raise RuntimeError(
                "node_local_execution_attempt_out_of_sequence:"
                f"expected={next_attempt}:actual={attempt_index}"
            )
        if previous_attempt == 0 and self._accept_existing_work_unit_evidence(
            round_number=round_number,
        ):
            return True
        if previous_attempt >= NODE_LOOP_MAX_ATTEMPTS:
            reason = (
                f"node_attempts_exhausted:node={node_id}:"
                "the current Graph node used both bounded attempts without "
                "meeting its completion condition"
            )
            self._rebuild_current_graph(
                trigger="node_attempts_exhausted",
                reason=reason,
                round_number=round_number,
            )
            return True

        planning_cards = _task_work_skill_cards(
            self._skills,
            getattr(self, "_task_formulation_skill_id", ""),
        )
        skill_summaries = [
            {
                "skill_id": card.skill_id,
                "description": card.description,
                "estimated_complexity": card.estimated_complexity,
                "accepts_research_mode": getattr(
                    card, "accepts_research_mode", False
                ),
            }
            for card in planning_cards
        ]
        planning_details = {
            item["skill_id"]: item["description"]
            for item in _planning_skill_summaries(self._skills, planning_cards)
        }
        self._memory.prepare_for_model_call(
            call_site="node-loop-plan",
            consumer="node-loop-plan",
        )
        work_context = self._current_work_projection(consumer="node-loop-plan")
        task_contract = state["c1"].get("task_contract_state") or {}
        task_spec_ref = str(task_contract.get("task_spec_ref") or "").strip()
        root_context_refs = [task_spec_ref] if task_spec_ref else []
        root_context_refs.extend(state["c1"]["resolved_artifact_refs"])
        root_context_refs.extend(
            active_work_unit_context_refs(state["c1"]["plan_graph"])
        )
        root_context_refs.extend(
            self._project_dependency_refs_for_work_context(work_context)
        )
        root_context_refs = list(dict.fromkeys(root_context_refs))
        context_refs = list(root_context_refs)
        context_artifacts: dict[str, Mapping[str, Any]] = {}
        pending_context_refs = list(root_context_refs)
        seen_context_refs: set[str] = set()
        while pending_context_refs:
            artifact_ref = str(pending_context_refs.pop(0)).strip()
            if not artifact_ref or artifact_ref in seen_context_refs:
                continue
            seen_context_refs.add(artifact_ref)
            try:
                stored = self._read_exact_ref(artifact_ref)
            except (KeyError, OSError, PermissionError, ValueError):
                continue
            context_artifacts[artifact_ref] = stored
            for raw_dependency in stored.get("depends_on") or ():
                dependency_ref = str(raw_dependency).strip()
                if (
                    not dependency_ref.startswith("artifact:")
                    or dependency_ref in seen_context_refs
                ):
                    continue
                if dependency_ref not in context_refs:
                    context_refs.append(dependency_ref)
                pending_context_refs.append(dependency_ref)
        detailed_context_refs = set(root_context_refs)
        formal_artifacts: list[Mapping[str, Any]] = []
        for artifact_ref in dict.fromkeys(context_refs):
            gate_refs = {
                str(state["c1"]["global_evaluation_state"]["gate_ref"]),
                str(
                    (state["c1"]["frame_evaluation_state"] or {}).get(
                        "gate_ref", ""
                    )
                ),
            }
            if artifact_ref in gate_refs:
                continue
            stored = context_artifacts.get(artifact_ref)
            if stored is None:
                continue
            projection = dict(
                plan_artifact_projection(
                    stored,
                    include_small_machine_content=(
                        artifact_ref in detailed_context_refs
                    ),
                )
            )
            # Publication lifecycle is not Graph acceptance and can mislead the
            # node-local planner about an already authorized input.
            projection.pop("status", None)
            formal_artifacts.append(projection)
        formal_ref_set = {
            str(item.get("artifact_ref") or "") for item in formal_artifacts
        }
        node_context_refs = [
            ref for ref in root_context_refs if ref in formal_ref_set
        ]
        try:
            planned = create_node_loop_plan(
                model=self._model,
                memory=self._memory,
                events=self._events,
                active_node=active,
                attempt_index=next_attempt,
                skill_summaries=skill_summaries,
                formal_artifacts=formal_artifacts,
                current_issue=str(state["c1"]["current_issue"]),
                work_context=work_context,
                node_context_refs=node_context_refs,
                skill_detail=planning_details.__getitem__,
            )
        except NodeLoopCostLimitError as exc:
            replay = self._find_exhausted_operational_replay(
                active_node=active,
                planned=exc.candidate_plan,
            )
            if replay is not None:
                reason = bounded_text(
                    "node_loop_operational_replay:"
                    f"node={node_id}:matched_revision={replay['artifact_ref']}:"
                    f"matched_attempt={replay['attempt_index']}:the rejected "
                    "over-limit plan repeats the exact node outcome, completion "
                    "condition, skill sequence, and input refs of an exhausted "
                    "formal attempt",
                    2_000,
                )
                self._raise_on_repeated_operational_replay(
                    replay=replay,
                    node_id=node_id,
                    attempt_index=exc.candidate_plan["attempt_index"],
                    reason=reason,
                    round_number=round_number,
                )
                self._events.append(
                    "node_loop_plan_failed",
                    {
                        "node_id": node_id,
                        "attempt_index": exc.candidate_plan["attempt_index"],
                        "reason": reason,
                        "matched_graph_revision_ref": replay["artifact_ref"],
                        "matched_attempt_index": replay["attempt_index"],
                    },
                )
                self._rebuild_current_graph(
                    trigger="node_loop_operational_replay",
                    reason=reason,
                    round_number=round_number,
                )
                return True
            reason = bounded_text(
                f"node_loop_plan_failed_after_local_repair:node={node_id}:"
                f"{exc}:the current node could not be expressed as one bounded "
                "executable attempt",
                2_000,
            )
            self._events.append(
                "node_loop_plan_failed",
                {"node_id": node_id, "reason": str(exc)},
            )
            self._rebuild_current_graph(
                trigger="node_loop_plan_not_executable",
                reason=reason,
                round_number=round_number,
            )
            return True
        except NodeLoopPlanError as exc:
            reason = bounded_text(
                f"node_loop_plan_failed_after_local_repair:node={node_id}:"
                f"{exc}:the current node could not be expressed as one bounded "
                "executable attempt",
                2_000,
            )
            self._events.append(
                "node_loop_plan_failed",
                {"node_id": node_id, "reason": str(exc)},
            )
            self._rebuild_current_graph(
                trigger="node_loop_plan_not_executable",
                reason=reason,
                round_number=round_number,
            )
            return True
        replay = self._find_exhausted_operational_replay(
            active_node=active,
            planned=planned,
        )
        if replay is not None:
            reason = bounded_text(
                "node_loop_operational_replay:"
                f"node={node_id}:matched_revision={replay['artifact_ref']}:"
                f"matched_attempt={replay['attempt_index']}:the validated "
                "node outcome, completion condition, skill sequence, and exact "
                "input refs repeat an exhausted formal attempt",
                2_000,
            )
            self._raise_on_repeated_operational_replay(
                replay=replay,
                node_id=node_id,
                attempt_index=planned["attempt_index"],
                reason=reason,
                round_number=round_number,
            )
            self._events.append(
                "node_loop_plan_failed",
                {
                    "node_id": node_id,
                    "attempt_index": planned["attempt_index"],
                    "reason": reason,
                    "matched_graph_revision_ref": replay["artifact_ref"],
                    "matched_attempt_index": replay["attempt_index"],
                },
            )
            self._rebuild_current_graph(
                trigger="node_loop_operational_replay",
                reason=reason,
                round_number=round_number,
            )
            return True
        self._state.set_node_loop_state(planned)
        self._state.set_issue("")
        self._events.append(
            "node_loop_attempt_started",
            {
                "node_id": node_id,
                "attempt_index": planned["attempt_index"],
                "steps": planned["steps"],
                "total_cost": sum(step["cost"] for step in planned["steps"]),
            },
        )
        return False

    def _project_dependency_refs_for_work_context(
        self,
        work_context: Mapping[str, Any],
    ) -> tuple[str, ...]:
        """Recover formal specifications bound to selected mutable projects."""
        projects = getattr(self, "_development_projects", None)
        dependency_refs = getattr(projects, "dependency_refs", None)
        if not callable(dependency_refs):
            return ()
        refs: list[str] = []
        for raw_receipt in work_context.get("project_receipts") or ():
            if not isinstance(raw_receipt, Mapping):
                continue
            project_id = str(raw_receipt.get("project_id") or "").strip()
            if not project_id:
                continue
            try:
                bound_refs = dependency_refs(project_id)
            except (KeyError, OSError, RuntimeError, ValueError) as exc:
                raise RuntimeError(
                    "development_project_dependencies_unresolvable:"
                    f"{project_id}:{exc}"
                ) from exc
            for raw_ref in bound_refs:
                ref = str(raw_ref).strip()
                if not ref or ref in refs:
                    continue
                try:
                    self._read_exact_ref(ref)
                except (KeyError, OSError, PermissionError, ValueError) as exc:
                    raise RuntimeError(
                        "development_project_dependency_unresolvable:"
                        f"{project_id}:{ref}:{exc}"
                    ) from exc
                refs.append(ref)
        return tuple(refs)

    def _active_node_input_refs(
        self,
        state: Mapping[str, Any] | None = None,
    ) -> tuple[str, ...]:
        """Return exact formal refs visible at the active Graph-node boundary."""
        current = dict(state or self._state.read())
        graph = current["c1"]["plan_graph"]
        if active_work_unit(graph) is None:
            return ()
        gate_refs = {
            str(current["c1"]["global_evaluation_state"]["gate_ref"] or ""),
            str(
                (current["c1"]["frame_evaluation_state"] or {}).get(
                    "gate_ref", ""
                )
            ),
        }
        refs = list(current["c1"]["resolved_artifact_refs"])
        refs.extend(active_work_unit_context_refs(graph))
        refs = list(
            artifact_dependency_closure_refs(
                self._artifacts.list(),
                read_artifact=self._artifacts.read,
                explicit_refs=refs,
            )
        )
        visible: list[str] = []
        for raw_ref in refs:
            ref = str(raw_ref).strip()
            if not ref or ref in gate_refs or ref in visible:
                continue
            try:
                stored = self._read_exact_ref(ref)
            except (KeyError, OSError, PermissionError, ValueError):
                continue
            if stored.get("artifact_kind") == GRAPH_REVISION_OUTCOME_KIND:
                continue
            visible.append(ref)
        return tuple(visible)

    def _next_node_execution_attempt_index(self) -> int:
        """Return the next bounded attempt number for the active Graph node."""
        state = self._state.read()
        active = active_work_unit(state["c1"]["plan_graph"])
        if active is None:
            raise RuntimeError("node_execution_requires_active_graph_node")
        loop_state = state["c1"]["node_loop_state"]
        if bool(loop_state["awaiting_transition"]):
            raise RuntimeError("node_execution_forbidden_while_awaiting_transition")
        if next_skill_id(loop_state, node_id=str(active["node_id"])):
            raise RuntimeError("node_execution_mode_already_selected_for_attempt")
        previous_attempt = (
            int(loop_state["attempt_index"])
            if str(loop_state["node_id"]) == str(active["node_id"])
            else 0
        )
        next_attempt = previous_attempt + 1
        if next_attempt > NODE_LOOP_MAX_ATTEMPTS:
            raise RuntimeError(
                "node_execution_attempts_exhausted:"
                f"node={active['node_id']}:attempts={previous_attempt}"
            )
        return next_attempt

    def _begin_child_node_attempt(self, *, round_number: int) -> int:
        """Consume one node attempt for whole-node white-room delegation."""
        state = self._state.read()
        active = active_work_unit(state["c1"]["plan_graph"])
        if active is None:
            raise RuntimeError("spawn_child_requires_active_graph_node")
        attempt_index = self._next_node_execution_attempt_index()
        self._state.set_node_loop_state(
            {
                "node_id": str(active["node_id"]),
                "attempt_index": attempt_index,
                "steps": [],
                "produced_refs": [],
                "next_step_index": 0,
                "awaiting_transition": False,
            }
        )
        self._events.append(
            "node_execution_mode_selected",
            {
                "round": round_number,
                "node_id": str(active["node_id"]),
                "attempt_index": attempt_index,
                "mode": "child",
            },
        )
        return attempt_index

    def _find_exhausted_operational_replay(
        self,
        *,
        active_node: Mapping[str, Any],
        planned: Mapping[str, Any],
    ) -> dict[str, Any] | None:
        """Match a plan only against formal C2 records, never C6 event text."""
        candidate = operational_attempt_fingerprint(
            node=active_node,
            steps=planned["steps"],
        )
        for receipt in reversed(self._active_artifact_index()):
            artifact_ref = str(receipt.get("artifact_ref") or "").strip()
            if not artifact_ref.startswith("artifact:"):
                continue
            try:
                stored = self._read_exact_ref(artifact_ref)
            except (KeyError, OSError, PermissionError, ValueError):
                continue
            if (
                stored.get("artifact_kind") != GRAPH_REVISION_OUTCOME_KIND
                or stored.get("status") != "accepted"
            ):
                continue
            payload = stored.get("machine_payload")
            if not isinstance(payload, Mapping):
                continue
            try:
                attempts = graph_revision_attempt_fingerprints(payload)
            except ValueError:
                # Old outcomes without exact input refs are not authoritative
                # for this check and receive no semantic fallback.
                continue
            for attempt_index, fingerprint in attempts:
                if fingerprint == candidate:
                    return {
                        "artifact_ref": artifact_ref,
                        "attempt_index": attempt_index,
                        "trigger": str(payload.get("trigger") or ""),
                    }
        return None

    def _raise_on_repeated_operational_replay(
        self,
        *,
        replay: Mapping[str, Any],
        node_id: str,
        attempt_index: int,
        reason: str,
        round_number: int,
    ) -> None:
        """Stop after one graph rebuild repeats the same exact operation."""
        if replay.get("trigger") != "node_loop_operational_replay":
            return
        stop_reason = bounded_text(
            "node_loop_repeated_operational_replay_without_new_evidence:"
            f"node={node_id}:matched_revision={replay['artifact_ref']}:"
            f"matched_attempt={replay['attempt_index']}",
            2_000,
        )
        self._state.set_issue(stop_reason)
        self._events.append(
            "node_loop_repeated_operational_replay_stopped",
            {
                "round": round_number,
                "node_id": node_id,
                "attempt_index": attempt_index,
                "reason": reason,
                "stop_reason": stop_reason,
                "matched_graph_revision_ref": replay["artifact_ref"],
                "matched_attempt_index": replay["attempt_index"],
            },
        )
        raise RuntimeError(stop_reason)

    def _accept_existing_work_unit_evidence(
        self,
        *,
        round_number: int,
    ) -> bool:
        """Advance an unattempted node already fulfilled by visible evidence."""
        state = self._state.read()
        graph = state["c1"]["plan_graph"]
        active = active_work_unit(graph)
        if active is None:
            return False

        gate_refs = {
            str(state["c1"]["global_evaluation_state"]["gate_ref"]),
            str(
                (state["c1"]["frame_evaluation_state"] or {}).get(
                    "gate_ref", ""
                )
            ),
        }
        # A completion candidate must already belong to this node's authority:
        # this node's own preserved attempt, or a partial result named by a
        # graph-revision outcome below. Ordinary run/mission mounts are inputs,
        # not completion roots. The initial planner already sees those inputs;
        # admitting them again here lets an upstream result silently complete a
        # downstream node merely because both are scientifically related.
        root_refs: list[str] = []
        for raw_ref in active["attempt_refs"]:
            ref = str(raw_ref).strip()
            if not ref or ref in gate_refs or ref in root_refs:
                continue
            try:
                self._read_exact_ref(ref)
            except (KeyError, OSError, PermissionError, ValueError):
                continue
            root_refs.append(ref)

        # Revision outcomes are audit transports for explicitly promoted
        # partial results. Keep those transports visible without broadening
        # completion authority to every artifact that happened to be read.
        for raw_ref in state["c1"]["resolved_artifact_refs"]:
            ref = str(raw_ref).strip()
            if not ref or ref in gate_refs or ref in root_refs:
                continue
            try:
                stored = self._read_exact_ref(ref)
            except (KeyError, OSError, PermissionError, ValueError):
                continue
            if stored.get("artifact_kind") != GRAPH_REVISION_OUTCOME_KIND:
                continue
            root_refs.append(ref)

        # A graph-revision artifact is a transport and audit root. Expose only
        # its exact failed-attempt result refs to the ordinary work-unit judge
        # so a replacement graph may preserve a narrower completed outcome.
        # Predecessor outputs and completed branches remain available only as
        # Graph inputs; the revision record itself can never satisfy a work
        # unit.
        candidate_refs: list[str] = []
        stored_by_ref: dict[str, Mapping[str, Any]] = {}
        for ref in root_refs:
            stored = self._read_exact_ref(ref)
            if stored.get("artifact_kind") != GRAPH_REVISION_OUTCOME_KIND:
                stored_by_ref[ref] = stored
                candidate_refs.append(ref)
                continue
            payload = stored.get("machine_payload")
            attempts = (
                payload.get("attempts") if isinstance(payload, Mapping) else ()
            )
            if isinstance(attempts, (str, bytes)) or not isinstance(
                attempts, Sequence
            ):
                continue
            for attempt in attempts:
                if not isinstance(attempt, Mapping):
                    continue
                result_refs = attempt.get("result_refs")
                if isinstance(result_refs, (str, bytes)) or not isinstance(
                    result_refs, Sequence
                ):
                    continue
                for raw_result_ref in result_refs:
                    result_ref = str(raw_result_ref).strip()
                    if (
                        not result_ref
                        or result_ref in gate_refs
                        or result_ref in stored_by_ref
                    ):
                        continue
                    try:
                        result = self._read_exact_ref(result_ref)
                    except (KeyError, OSError, PermissionError, ValueError):
                        continue
                    if result.get("artifact_kind") == GRAPH_REVISION_OUTCOME_KIND:
                        continue
                    stored_by_ref[result_ref] = result
                    candidate_refs.append(result_ref)
        if not candidate_refs:
            return False

        stored_candidates = [stored_by_ref[ref] for ref in candidate_refs]
        compact_candidates = [
            plan_artifact_projection(stored) for stored in stored_candidates
        ]
        screening = assess_work_unit(
            model=self._model,
            memory=self._memory,
            events=self._events,
            active_node=active,
            newly_verified_artifacts=compact_candidates,
            resolved_artifacts=[],
            completion_candidate_refs=candidate_refs,
            observed_result={
                "status": "existing_formal_evidence_screening",
                "artifact_refs": candidate_refs,
            },
            purpose="screen existing evidence before node execution",
        )
        selected_refs = list(screening["evidence_refs"])
        warrants_verification = bool(selected_refs)
        self._events.append(
            "plan_existing_evidence_screened",
            {
                "round": round_number,
                "node_id": str(active["node_id"]),
                "candidate_refs": candidate_refs,
                "potentially_fulfilled": warrants_verification,
                "selected_refs": selected_refs,
                "reason": str(screening["reason"]),
            },
        )
        if not warrants_verification:
            return False

        try:
            assessment = assess_work_unit(
                model=self._model,
                memory=self._memory,
                events=self._events,
                active_node=active,
                newly_verified_artifacts=[
                    artifact_prompt_projection(stored_by_ref[ref])
                    for ref in selected_refs
                ],
                resolved_artifacts=compact_candidates,
                completion_candidate_refs=selected_refs,
                observed_result={
                    "status": "existing_formal_evidence_verification",
                    "artifact_refs": selected_refs,
                },
                purpose="verify selected existing evidence before node execution",
                read_ref=self._read_evaluation_ref,
            )
        except PromptBudgetExceeded as exc:
            # Existing-evidence reuse is an optimization. If even the selected
            # stored roots cannot fit, preserve them as normal node context and
            # let the bounded node LOOP inspect them explicitly.
            self._events.append(
                "plan_existing_evidence_verification_deferred",
                {
                    "round": round_number,
                    "node_id": str(active["node_id"]),
                    "selected_refs": selected_refs,
                    "reason": str(exc),
                },
            )
            return False
        self._events.append(
            "plan_existing_evidence_assessed",
            {
                "round": round_number,
                "node_id": str(active["node_id"]),
                "candidate_refs": candidate_refs,
                "fulfilled": bool(assessment["fulfilled"]),
                "evidence_refs": list(assessment["evidence_refs"]),
                "reason": str(assessment["reason"]),
            },
        )
        if not assessment["fulfilled"]:
            return False

        evidence_refs = list(assessment["evidence_refs"])
        node_id = str(active["node_id"])
        if active["transitions"]:
            completed = record_plan_completion(
                graph,
                node_id=node_id,
                evidence_refs=evidence_refs,
            )
            self._state.set_plan_graph(completed)
            loop_state = self._state.read()["c1"]["node_loop_state"]
            self._state.set_node_loop_state(mark_awaiting_transition(loop_state))
            self._events.append(
                "plan_decision_node_awaiting_transition",
                {
                    "round": round_number,
                    "node_id": node_id,
                    "evidence_refs": evidence_refs,
                    "transitions": active["transitions"],
                    "source": "existing_formal_evidence",
                },
            )
            return True

        advanced = advance_plan_graph(
            graph,
            node_id=node_id,
            evidence_refs=evidence_refs,
            task_complete=False,
        )
        self._state.set_plan_graph(advanced)
        self._state.set_issue("")
        self._events.append(
            "plan_progress_applied",
            {
                "node_id": node_id,
                "attempt_refs": [],
                "evidence_refs": evidence_refs,
                "plan_graph": advanced,
                "source": "existing_formal_evidence",
            },
        )
        return True

    def _node_completion_candidate_refs(
        self, artifact_refs: Sequence[str],
    ) -> tuple[str, ...]:
        """Keep this node's preserved outputs eligible across skill invocations."""
        active = active_work_unit(self._state.read()["c1"]["plan_graph"])
        preserved = active["attempt_refs"] if active is not None else ()
        return tuple(dict.fromkeys(
            str(ref).strip() for ref in (*preserved, *artifact_refs)
            if str(ref).strip()
        ))

    def _refresh_plan(
        self,
        artifact_refs: Sequence[str],
        *,
        producer_skill_id: str = "",
        observed_result: Mapping[str, Any] | None = None,
        round_number: int = 0,
    ) -> str:
        """Judge one completed skill result against the active Graph node."""
        refs = list(self._node_completion_candidate_refs(artifact_refs))
        state = self._state.read()
        updated = state["c1"]["plan_graph"]
        active = active_work_unit(updated)
        if active is None:
            if not refs and not observed_result:
                return ""
            raise RuntimeError(_STALE_PLAN_SIGNAL)

        observed = bounded_projection(
            dict(observed_result or {}),
            max_depth=5,
            max_items=24,
        )
        observed_status = str(observed.get("status") or "").strip()
        terminal_without_artifact = observed_status in {
            "blocked",
            "bounded_gap",
            "failed",
            "error",
            "tool_error",
        }
        if not refs and not terminal_without_artifact:
            return ""
        if not refs:
            reason = str(
                observed.get("reason")
                or observed.get("summary")
                or observed_status
                or "The attempt returned no formal result evidence."
            )
            loop_issue = self._complete_node_loop_step(
                node_id=str(active["node_id"]),
                artifact_refs=(),
                terminate_attempt=True,
                reason=reason,
            )
            rendered_issue = bounded_text(
                "The node attempt returned no formal result evidence. "
                + loop_issue
                + " Attempt result: "
                + reason,
                2_000,
            )
            self._events.append(
                "plan_work_unit_not_fulfilled",
                {
                    "node_id": active["node_id"],
                    "attempt_refs": [],
                    "reason": reason,
                },
            )
            return rendered_issue

        loop_state = state["c1"].get("node_loop_state")
        prior_step_refs: list[str] = []
        has_later_planned_step = False
        if (
            isinstance(loop_state, Mapping)
            and str(loop_state.get("node_id") or "")
            == str(active["node_id"])
        ):
            prior_step_refs = [
                str(ref)
                for ref in loop_state.get("produced_refs") or ()
                if str(ref)
            ]
            steps = loop_state.get("steps")
            step_index = loop_state.get("next_step_index")
            has_later_planned_step = (
                isinstance(steps, Sequence)
                and not isinstance(steps, (str, bytes))
                and isinstance(step_index, int)
                and 0 <= step_index < len(steps) - 1
            )

        attempt_result_refs = list(
            dict.fromkeys([*prior_step_refs, *refs])
        )
        # Resolve every accumulated result before changing control state. The
        # immutable LOOP carries successful intermediate outputs into the next
        # planned skill and presents the full attempt to the final judge.
        newly_verified = [
            artifact_prompt_projection(self._read_exact_ref(ref))
            for ref in attempt_result_refs
        ]
        for ref in refs:
            updated = record_plan_attempt(
                updated,
                node_id=str(active["node_id"]),
                artifact_ref=ref,
            )
        self._state.set_plan_graph(updated)
        active = active_work_unit(updated)
        if active is None:
            raise RuntimeError(_STALE_PLAN_SIGNAL)

        if has_later_planned_step and not terminal_without_artifact:
            self._complete_node_loop_step(
                node_id=str(active["node_id"]),
                artifact_refs=refs,
                terminate_attempt=False,
                reason=(
                    "The planned intermediate skill completed; defer Node "
                    "fulfillment assessment until the immutable LOOP's final "
                    "step."
                ),
            )
            return ""

        # Work-unit assessment is scoped by the Graph, not by whichever
        # artifacts happened to be visible inside the just-finished skill.
        # Current and preserved results of this node are expanded above;
        # predecessor results remain supporting context, not completion roots.
        new_ref_set = set(attempt_result_refs)
        context_refs = [
            ref
            for ref in active_work_unit_context_refs(updated)
            if ref not in new_ref_set
        ]
        resolved = [
            plan_artifact_projection(self._read_exact_ref(ref))
            for ref in dict.fromkeys(context_refs)
        ]

        try:
            assessment = assess_work_unit(
                model=self._model,
                memory=self._memory,
                events=self._events,
                active_node=active,
                newly_verified_artifacts=newly_verified,
                resolved_artifacts=resolved,
                completion_candidate_refs=attempt_result_refs,
                read_ref=self._read_evaluation_ref,
                observed_result=observed,
            )
        except Exception:
            # The scientific result is already stored and recorded on the
            # active node. Reset only the uncommitted LOOP attempt so a resume
            # screens that exact evidence before planning another invocation.
            self._state.set_node_loop_state(
                {
                    "node_id": "",
                    "attempt_index": 0,
                    "steps": [],
                    "produced_refs": [],
                    "next_step_index": 0,
                    "awaiting_transition": False,
                }
            )
            raise

        if not assessment["fulfilled"]:
            loop_issue = self._complete_node_loop_step(
                node_id=str(active["node_id"]),
                artifact_refs=refs,
                terminate_attempt=terminal_without_artifact,
                reason=str(assessment["reason"]),
            )
            plan_issue = bounded_projection(
                {
                    "status": "active_work_unit_not_fulfilled",
                    "node_id": str(active["node_id"]),
                    "attempt_refs": attempt_result_refs,
                    "reason": str(assessment["reason"]),
                    "loop_state": self._state.read()["c1"]["node_loop_state"],
                },
                max_depth=4,
                max_items=20,
            )
            rendered_issue = bounded_text(
                "The node evaluator did not accept the current result. "
                + loop_issue
                + " Assessment: "
                + json.dumps(plan_issue, ensure_ascii=False),
                2_000,
            )
            self._events.append(
                "plan_work_unit_not_fulfilled",
                {
                    "node_id": active["node_id"],
                    "attempt_refs": attempt_result_refs,
                    "reason": assessment["reason"],
                },
            )
            return rendered_issue
        evidence_refs = list(assessment["evidence_refs"])

        completed_node_id = str(active["node_id"])
        if active["transitions"]:
            completed = record_plan_completion(
                updated,
                node_id=completed_node_id,
                evidence_refs=evidence_refs,
            )
            self._state.set_plan_graph(completed)
            loop_state = self._state.read()["c1"]["node_loop_state"]
            self._state.set_node_loop_state(mark_awaiting_transition(loop_state))
            self._events.append(
                "plan_decision_node_awaiting_transition",
                {
                    "round": round_number,
                    "node_id": completed_node_id,
                    "evidence_refs": evidence_refs,
                    "transitions": active["transitions"],
                },
            )
            return ""

        advanced = advance_plan_graph(
            updated,
            node_id=completed_node_id,
            evidence_refs=evidence_refs,
            task_complete=False,
        )
        self._state.set_plan_graph(advanced)
        self._events.append(
            "plan_progress_applied",
            {
                "node_id": completed_node_id,
                "attempt_refs": refs,
                "evidence_refs": evidence_refs,
                "plan_graph": advanced,
            },
        )
        return ""

    def _complete_node_loop_step(
        self,
        *,
        node_id: str,
        artifact_refs: Sequence[str],
        terminate_attempt: bool,
        reason: str,
    ) -> str:
        state = self._state.read()
        loop_state = state["c1"].get("node_loop_state")
        if not isinstance(loop_state, Mapping):
            return "No active node-local LOOP step was available to advance."
        if str(loop_state["node_id"]) != node_id or not loop_state["steps"]:
            return "No active node-local LOOP step was available to advance."
        attempt_result_refs = tuple(
            dict.fromkeys(
                [
                    *(
                        str(ref)
                        for ref in loop_state.get("produced_refs") or ()
                        if str(ref)
                    ),
                    *(str(ref) for ref in artifact_refs if str(ref)),
                ]
            )
        )
        updated, attempt_finished = complete_current_step(
            loop_state,
            terminate_attempt=terminate_attempt,
            produced_refs=artifact_refs,
        )
        self._state.set_node_loop_state(updated)
        self._events.append(
            "node_loop_step_completed",
            {
                "node_id": node_id,
                "attempt_index": loop_state["attempt_index"],
                "step_index": loop_state["next_step_index"],
                "artifact_refs": list(artifact_refs),
                "fulfilled": False,
                "reason": reason,
                "attempt_finished": attempt_finished,
            },
        )
        if attempt_finished:
            self._record_local_node_attempt_handoff(
                node_id=node_id,
                attempt_index=int(loop_state["attempt_index"]),
                status="attempt_finished",
                formal_result_refs=attempt_result_refs,
            )
        if not attempt_finished:
            next_skill = next_skill_id(updated, node_id=node_id)
            return f"Continue the same immutable attempt with skill {next_skill}."
        if int(updated["attempt_index"]) >= NODE_LOOP_MAX_ATTEMPTS:
            return (
                "Both bounded attempts are exhausted; the current Graph route "
                "must be recorded and rebuilt before more task work."
            )
        return "The attempt ended; build a fresh second attempt from formal evidence."

    def _follow_graph_transition(
        self,
        transition_id: str,
        *,
        round_number: int,
    ) -> Mapping[str, Any]:
        state = self._state.read()
        graph = state["c1"]["plan_graph"]
        active = active_work_unit(graph)
        loop_state = state["c1"]["node_loop_state"]
        if active is None or not active["transitions"]:
            raise RuntimeError(
                "follow_graph_transition_requires_active_conditional_node"
            )
        if not bool(loop_state["awaiting_transition"]):
            raise RuntimeError("follow_graph_transition_requires_completed_decision")
        selected = str(transition_id).strip()
        transition_ids = {
            str(item["transition_id"])
            for item in active["transitions"]
            if isinstance(item, Mapping)
        }
        if selected not in transition_ids:
            raise ValueError(f"graph_transition_unknown:{selected}")
        evidence_refs = list(active["completion_refs"])
        if not evidence_refs:
            raise RuntimeError("graph_transition_requires_node_completion_evidence")
        advanced = advance_plan_graph(
            graph,
            node_id=str(active["node_id"]),
            evidence_refs=evidence_refs,
            task_complete=False,
            selected_transition_id=selected,
        )
        self._state.set_plan_graph(advanced)
        self._state.set_issue("")
        next_active = active_work_unit(advanced)
        self._events.append(
            "plan_transition_followed",
            {
                "round": round_number,
                "node_id": str(active["node_id"]),
                "selected_transition_id": selected,
                "evidence_refs": evidence_refs,
                "next_node_id": (
                    str(next_active["node_id"]) if next_active else ""
                ),
                "plan_graph": advanced,
            },
        )
        return {
            "status": "graph_transition_followed",
            "transition_id": selected,
            "active_node_id": (
                str(next_active["node_id"]) if next_active else ""
            ),
        }

    def _report_no_matching_transition(
        self,
        reason: str,
        *,
        round_number: int,
    ) -> Mapping[str, Any]:
        state = self._state.read()
        active = active_work_unit(state["c1"]["plan_graph"])
        loop_state = state["c1"]["node_loop_state"]
        if active is None or not active["transitions"]:
            raise RuntimeError(
                "no_matching_transition_requires_active_conditional_node"
            )
        if not bool(loop_state["awaiting_transition"]):
            raise RuntimeError(
                "no_matching_transition_requires_completed_decision"
            )
        if not active["completion_refs"]:
            raise RuntimeError(
                "no_matching_transition_requires_completion_evidence"
            )
        explanation = bounded_text(str(reason).strip(), 2_000)
        if not explanation:
            raise ValueError("no_matching_transition_reason_required")
        return self._rebuild_current_graph(
            trigger="no_matching_transition",
            reason=explanation,
            round_number=round_number,
        )

    def _rebuild_current_graph(
        self,
        *,
        trigger: str,
        reason: str,
        round_number: int,
        revision_scope: str = "node",
        priority_criterion_ids: Sequence[str] = (),
    ) -> Mapping[str, Any]:
        """Record why the current Graph cannot continue and replace it."""
        state = self._state.read()
        source_graph = state["c1"]["plan_graph"]
        active = active_work_unit(source_graph)
        if revision_scope not in {"node", "graph"}:
            raise ValueError("graph_rebuild_scope_invalid")
        if revision_scope == "node" and active is None:
            raise RuntimeError("graph_rebuild_requires_active_node")

        global_evaluation_state = state["c1"]["global_evaluation_state"]
        gate_ref = str(global_evaluation_state["gate_ref"])
        gate = self._load_evaluation_gate(gate_ref)
        if revision_scope == "graph" and active is not None:
            raise RuntimeError("graph_scope_rebuild_requires_exhausted_graph")
        failed_node = active if revision_scope == "node" else None
        unmet_criteria = _unmet_criterion_records(
            global_evaluation_state
        )
        if revision_scope == "graph" and not unmet_criteria:
            raise RuntimeError("graph_scope_rebuild_requires_unmet_criteria")
        still_usable: list[str] = []
        for node in source_graph["nodes"]:
            if node["status"] != "completed":
                continue
            for ref in node["completion_refs"]:
                try:
                    self._read_exact_ref(str(ref))
                except (KeyError, OSError, PermissionError, ValueError) as exc:
                    raise RuntimeError(
                        "graph_rebuild_completed_anchor_evidence_unresolvable:"
                        f"{node['node_id']}:{ref}:{exc}"
                    ) from exc
                if ref not in still_usable:
                    still_usable.append(str(ref))
        active_completion_refs = (
            list(failed_node["completion_refs"])
            if failed_node is not None
            else []
        )
        # Replanning carries forward two mechanically authoritative classes:
        # the formal task contract and refs accepted as node completion evidence.
        # Merely reading an artifact into C1 does not promote it to either class.
        task_contract = state["c1"]["task_contract_state"]
        task_contract_refs = [
            *task_contract["input_refs"],
            task_contract["task_spec_ref"],
        ]
        mounted_input_refs = [
            *self._initial_artifact_refs,
            *self._artifacts.mounted_refs(),
            *sorted(self._mounted_external_refs),
            *task_contract_refs,
        ]
        for ref in [
            *active_completion_refs,
            *mounted_input_refs,
        ]:
            candidate = str(ref).strip()
            if not candidate or candidate == gate_ref or candidate in still_usable:
                continue
            try:
                self._read_exact_ref(candidate)
            except (KeyError, OSError, PermissionError, ValueError):
                continue
            still_usable.append(candidate)
        human_interaction = state["c1"]["human_interaction_state"]
        if human_interaction["status"] == "answered":
            response_ref = str(human_interaction["response_ref"])
            self._read_exact_ref(response_ref)
            if response_ref not in still_usable:
                still_usable.append(response_ref)

        skill_costs = {
            card.skill_id: NODE_LOOP_COST_BY_COMPLEXITY[
                card.estimated_complexity
            ]
            for card in _task_work_skill_cards(
                self._skills,
                getattr(self, "_task_formulation_skill_id", ""),
            )
            if card.estimated_complexity in NODE_LOOP_COST_BY_COMPLEXITY
        }
        outcome = build_graph_revision_outcome(
            source_graph=source_graph,
            failed_node_id=(
                str(failed_node["node_id"])
                if failed_node is not None
                else None
            ),
            revision_scope=revision_scope,
            trigger=trigger,
            reason=reason,
            events=self._events.read(),
            unmet_criteria=unmet_criteria,
            still_usable_refs=still_usable,
            skill_costs=skill_costs,
        )
        # A failed scientific node does not make its partial scientific results
        # accepted. An immutable development-project snapshot is different: it
        # is operational continuation state, not a scientific claim. Preserve
        # that exact checkpoint so the replacement route can continue the
        # implementation without treating the failed node as completed.
        for attempt in outcome["attempts"]:
            for raw_ref in attempt["result_refs"]:
                candidate = str(raw_ref).strip()
                if not candidate or candidate in still_usable:
                    continue
                try:
                    stored = self._read_exact_ref(candidate)
                except (KeyError, OSError, PermissionError, ValueError):
                    continue
                if (
                    stored.get("status") == "accepted"
                    and stored.get("artifact_kind")
                    in _OPERATIONAL_CONTINUITY_ARTIFACT_KINDS
                ):
                    still_usable.append(candidate)
        if outcome["still_usable_refs"] != still_usable:
            outcome = build_graph_revision_outcome(
                source_graph=source_graph,
                failed_node_id=(
                    str(failed_node["node_id"])
                    if failed_node is not None
                    else None
                ),
                revision_scope=revision_scope,
                trigger=trigger,
                reason=reason,
                events=self._events.read(),
                unmet_criteria=unmet_criteria,
                still_usable_refs=still_usable,
                skill_costs=skill_costs,
            )
        trace_refs = list(still_usable)
        for attempt in outcome["attempts"]:
            trace_refs.extend(str(ref) for ref in attempt["result_refs"])
        for criterion in outcome["unmet_criteria"]:
            trace_refs.extend(str(ref) for ref in criterion["evidence_refs"])
        trace_refs = list(dict.fromkeys(trace_refs))
        formal_dependencies: list[str] = []
        for ref in trace_refs:
            if not ref.startswith("artifact:"):
                continue
            try:
                self._artifacts.read(ref)
            except (KeyError, OSError, PermissionError, ValueError):
                continue
            formal_dependencies.append(ref)

        receipt = self._artifacts.publish(
            artifact_kind=GRAPH_REVISION_OUTCOME_KIND,
            artifact_id=(
                f"graph-revision-{source_graph['revision']}-outcome-{trigger}"
            ),
            title=(
                f"Graph revision {source_graph['revision']} outcome: {trigger}"
            ),
            markdown=render_graph_revision_outcome(
                outcome,
                source_graph=source_graph,
            ),
            machine_payload=outcome,
            status="accepted",
            summary=(
                f"Graph revision {source_graph['revision']} could not continue "
                + (
                    f"at node {failed_node['node_id']} because {trigger}."
                    if failed_node is not None
                    else (
                        f"after all reachable work nodes completed because "
                        f"{trigger}."
                    )
                )
            ),
            depends_on=tuple(dict.fromkeys(formal_dependencies)),
            trace_refs=tuple(trace_refs),
            self_review={
                "status": "accepted",
                "reason": "Mechanically projected from current Graph and audit events.",
            },
        )
        outcome_ref = str(receipt["artifact_ref"])
        self._state.add_resolved_artifact_ref(outcome_ref)
        self._events.append(
            "graph_revision_outcome_published",
            {
                "round": round_number,
                "artifact_ref": outcome_ref,
                "source_revision": source_graph["revision"],
                "revision_scope": revision_scope,
                "trigger": trigger,
                "failed_node_id": (
                    str(failed_node["node_id"])
                    if failed_node is not None
                    else ""
                ),
            },
        )

        current_state = self._state.read()
        active_receipts = self._active_artifact_index()
        accepted_artifact_refs = {
            str(ref)
            for ref in still_usable
            if str(ref).startswith("artifact:")
        }
        resolved_artifacts: list[Mapping[str, Any]] = []
        revision_history: list[Mapping[str, Any]] = []
        for item in active_receipts:
            artifact_ref = str(item.get("artifact_ref") or "").strip()
            if not artifact_ref:
                continue
            stored = self._read_exact_ref(artifact_ref)
            if stored.get("artifact_kind") == GRAPH_REVISION_OUTCOME_KIND:
                payload = stored.get("machine_payload")
                if (
                    stored.get("status") == "accepted"
                    and isinstance(payload, Mapping)
                    and payload is not outcome
                ):
                    revision_history.append(dict(payload))
                continue
            if artifact_ref in accepted_artifact_refs:
                resolved_artifacts.append(plan_artifact_projection(stored))
        planning_cards = _task_work_skill_cards(
            self._skills,
            getattr(self, "_task_formulation_skill_id", ""),
        )
        skill_summaries = [
            {
                "skill_id": card.skill_id,
                "description": card.description,
                "estimated_complexity": card.estimated_complexity,
            }
            for card in planning_cards
        ]
        planning_skill_summaries = _planning_skill_summaries(
            self._skills,
            planning_cards,
        )
        replan_human_scopes = (
            ("graph_replan", "frame")
            if revision_scope == "graph"
            else ("graph_replan",)
        )
        replan_human_tool = (
            build_human_input_tool(
                scopes=replan_human_scopes,
                visible_context_refs=tuple(
                    dict.fromkeys(
                        [*self._visible_human_context_refs(), outcome_ref]
                    )
                ),
            )
            if self._human_in_loop_enabled
            else None
        )
        if revision_scope == "graph":
            completed_anchors = [
                dict(node)
                for node in source_graph["nodes"]
                if node["status"] == "completed"
                and str(node["node_id"])
                not in {
                    str(source_graph["goal_node_id"]),
                    "task-start",
                }
                and node["completion_refs"]
            ]
            selected_frame_goal = select_frame_goal(
                model=self._model,
                memory=self._memory,
                events=self._events,
                objective=_frame_goal_objective(current_state, self._read_exact_ref),
                global_evaluation_gate=gate,
                global_evaluation_state=current_state["c1"][
                    "global_evaluation_state"
                ],
                trigger=trigger,
                trigger_reason=reason,
                completed_node_anchors=completed_anchors,
                accepted_artifacts=resolved_artifacts,
                skill_summaries=planning_skill_summaries,
                previous_frame_goal=frame_goal_node(source_graph),
                priority_criterion_ids=priority_criterion_ids,
                mission_packet=(
                    self._mission_prompt_projection() if self._mission else None
                ),
                human_input_tool=replan_human_tool,
                request_human_input=(
                    lambda arguments: self._request_human_input(
                        arguments,
                        allowed_scopes=replan_human_scopes,
                        extra_context_refs=(outcome_ref,),
                    )
                    if replan_human_tool is not None
                    else None
                ),
            )
        else:
            selected_frame_goal = frame_goal_node(source_graph)
            if selected_frame_goal is None:
                raise RuntimeError("graph_rebuild_frame_goal_missing")
        try:
            observation_refs = list(dict.fromkeys(
                ref for attempt in outcome["attempts"]
                for ref in attempt["observation_refs"]
            ))
            resolved_observations = [self._read_exact_ref(ref) for ref in observation_refs]
            replacement = rebuild_graph(
                model=self._model,
                memory=self._memory,
                events=self._events,
                source_graph=source_graph,
                revision_outcome=outcome,
                resolved_artifacts=resolved_artifacts,
                resolved_observations=resolved_observations,
                skill_summaries=planning_skill_summaries,
                revision=int(source_graph["revision"]) + 1,
                revision_history=revision_history,
                mission_packet=(
                    _frame_graph_mission_context(
                        self._mission_prompt_projection()
                    )
                    if self._mission
                    else None
                ),
                human_input_tool=replan_human_tool,
                request_human_input=(
                    lambda arguments: self._request_human_input(
                        arguments,
                        allowed_scopes=replan_human_scopes,
                        extra_context_refs=(outcome_ref,),
                    )
                    if replan_human_tool is not None
                    else None
                ),
                frame_goal=selected_frame_goal,
            )
        except (GraphRebuildError, ValueError) as exc:
            issue = bounded_text(
                f"graph_rebuild_failed:{trigger}:{exc}",
                2_000,
            )
            self._state.set_issue(issue)
            self._events.append(
                "graph_rebuild_failed",
                {
                    "round": round_number,
                    "source_revision": source_graph["revision"],
                    "outcome_ref": outcome_ref,
                    "revision_scope": revision_scope,
                    "trigger": trigger,
                    "reason": str(exc),
                },
            )
            raise RuntimeError(issue) from exc

        self._state.set_plan_graph(replacement)
        self._replace_frame_evaluation_for_graph()
        self._state.set_issue("")
        self._mark_human_answer_consumed(consumer="graph_replan")
        self._events.append(
            "graph_rebuilt",
            {
                "round": round_number,
                "source_revision": source_graph["revision"],
                "outcome_ref": outcome_ref,
                "revision_scope": revision_scope,
                "trigger": trigger,
                "plan_graph": replacement,
            },
        )
        next_active = active_work_unit(replacement)
        return {
            "status": "graph_rebuilt",
            "source_revision": source_graph["revision"],
            "revision": replacement["revision"],
            "outcome_ref": outcome_ref,
            "active_node_id": (
                str(next_active["node_id"]) if next_active is not None else ""
            ),
        }

    def _restart_node_attempt(
        self,
        reason: str,
        *,
        round_number: int,
    ) -> Mapping[str, Any]:
        state = self._state.read()
        active = active_work_unit(state["c1"]["plan_graph"])
        loop_state = state["c1"]["node_loop_state"]
        if active is None or str(loop_state["node_id"]) != str(active["node_id"]):
            raise RuntimeError("restart_node_attempt_requires_active_loop")
        if bool(loop_state["awaiting_transition"]):
            raise RuntimeError("restart_node_attempt_forbidden_after_node_completion")
        if not loop_state["steps"]:
            raise RuntimeError("restart_node_attempt_requires_running_attempt")
        ended = {
            "node_id": str(loop_state["node_id"]),
            "attempt_index": int(loop_state["attempt_index"]),
            "steps": [],
            "produced_refs": [],
            "next_step_index": 0,
            "awaiting_transition": False,
        }
        self._state.set_node_loop_state(ended)
        active_skill_id = str(state["c1"]["active_skill_id"] or "")
        if active_skill_id:
            self._release_skill_context()
        issue = bounded_text(
            f"node_attempt_restarted:node={active['node_id']}:"
            f"attempt={ended['attempt_index']}:{reason}",
            2_000,
        )
        self._state.set_issue(issue)
        exhausted = int(ended["attempt_index"]) >= NODE_LOOP_MAX_ATTEMPTS
        self._events.append(
            "node_loop_attempt_restarted",
            {
                "round": round_number,
                "node_id": str(active["node_id"]),
                "attempt_index": ended["attempt_index"],
                "reason": reason,
                "attempts_exhausted": exhausted,
            },
        )
        self._record_local_node_attempt_handoff(
            node_id=str(active["node_id"]),
            attempt_index=int(ended["attempt_index"]),
            status=(
                "attempts_exhausted" if exhausted else "attempt_restarted"
            ),
            formal_result_refs=(),
        )
        return {
            "status": (
                "node_attempts_exhausted" if exhausted else "node_attempt_restarted"
            ),
            "node_id": str(active["node_id"]),
            "attempt_index": ended["attempt_index"],
        }

    def _reserve_active_loop_step_model_call(
        self,
        *,
        purpose: str,
    ) -> Mapping[str, Any] | None:
        """Reserve one persisted model call against the active LOOP step."""
        state = self._state.read()
        active = active_work_unit(state["c1"]["plan_graph"])
        active_skill_id = str(state["c1"].get("active_skill_id") or "").strip()
        loop_state = state["c1"].get("node_loop_state")
        if active is None or not active_skill_id or not isinstance(
            loop_state, Mapping
        ):
            return None
        node_id = str(loop_state.get("node_id") or "").strip()
        attempt_index = int(loop_state.get("attempt_index") or 0)
        step_index = loop_state.get("next_step_index")
        steps = loop_state.get("steps")
        if (
            node_id != str(active["node_id"])
            or attempt_index < 1
            or not isinstance(step_index, int)
            or not isinstance(steps, Sequence)
            or isinstance(steps, (str, bytes))
            or not 0 <= step_index < len(steps)
            or not isinstance(steps[step_index], Mapping)
        ):
            raise RuntimeError("active_loop_step_model_call_state_invalid")
        step = dict(steps[step_index])
        skill_id = str(step.get("skill_id") or "").strip()
        if skill_id != active_skill_id:
            raise RuntimeError(
                "active_loop_step_model_call_skill_mismatch:"
                f"expected={skill_id}:actual={active_skill_id}"
            )
        limit = node_loop_step_llm_call_limit(step)
        used = 0
        for receipt in reversed(state["c1"]["recent_bounded_receipts"]):
            if (
                str(receipt.get("receipt_kind") or "")
                != "node_loop_step_model_call_budget"
                or str(receipt.get("node_id") or "") != node_id
                or int(receipt.get("attempt_index") or 0) != attempt_index
                or int(receipt.get("step_index", -1)) != step_index
                or str(receipt.get("skill_id") or "") != skill_id
            ):
                continue
            receipt_limit = receipt.get("limit")
            receipt_used = receipt.get("used")
            if (
                isinstance(receipt_limit, bool)
                or not isinstance(receipt_limit, int)
                or receipt_limit != limit
                or isinstance(receipt_used, bool)
                or not isinstance(receipt_used, int)
                or not 0 <= receipt_used <= limit
            ):
                raise RuntimeError("node_loop_step_model_call_receipt_invalid")
            used = receipt_used
            break
        if used >= limit:
            raise NodeLoopStepCallLimitError(
                node_id=node_id,
                attempt_index=attempt_index,
                step_index=step_index,
                skill_id=skill_id,
                used=used,
                limit=limit,
            )
        receipt = {
            "receipt_kind": "node_loop_step_model_call_budget",
            "node_id": node_id,
            "attempt_index": attempt_index,
            "step_index": step_index,
            "skill_id": skill_id,
            "used": used + 1,
            "limit": limit,
            "last_purpose": bounded_text(str(purpose).strip(), 500),
        }
        self._state.record_receipt(receipt)
        self._events.append("node_loop_step_model_call_reserved", receipt)
        return {
            **receipt,
            "call_index": receipt["used"],
            "call_limit": receipt["limit"],
            "purpose": receipt["last_purpose"],
        }

    def _exhaust_active_loop_step_model_calls(
        self,
        error: NodeLoopStepCallLimitError,
        *,
        round_number: int,
    ) -> Mapping[str, Any]:
        """Fail one attempt mechanically while preserving its partial work."""
        state = self._state.read()
        active = active_work_unit(state["c1"]["plan_graph"])
        if active is None or str(active["node_id"]) != error.node_id:
            raise RuntimeError("step_call_limit_active_node_changed")
        loop_state = state["c1"]["node_loop_state"]
        partial_refs = list(
            dict.fromkeys(
                [
                    *(
                        str(ref)
                        for ref in loop_state.get("produced_refs") or ()
                        if str(ref)
                    ),
                    *self._active_invocation_artifact_refs(error.skill_id),
                ]
            )
        )
        graph = state["c1"]["plan_graph"]
        for ref in partial_refs:
            graph = record_plan_attempt(
                graph,
                node_id=error.node_id,
                artifact_ref=ref,
            )
        self._state.set_plan_graph(graph)
        reason = str(error)
        loop_issue = self._complete_node_loop_step(
            node_id=error.node_id,
            artifact_refs=partial_refs,
            terminate_attempt=True,
            reason=reason,
        )
        self._release_skill_context()
        issue = bounded_text(reason + ". " + loop_issue, 2_000)
        self._state.set_issue(issue)
        self._events.append(
            "node_loop_step_model_call_limit_exhausted",
            {
                "round": round_number,
                "node_id": error.node_id,
                "attempt_index": error.attempt_index,
                "step_index": error.step_index,
                "skill_id": error.skill_id,
                "used": error.used,
                "limit": error.limit,
                "partial_result_refs": partial_refs,
            },
        )
        return {
            "status": "node_attempt_failed",
            "node_id": error.node_id,
            "attempt_index": error.attempt_index,
            "reason": reason,
            "partial_result_refs": partial_refs,
        }

    def _record_local_node_attempt_handoff(
        self,
        *,
        node_id: str,
        attempt_index: int,
        status: str,
        formal_result_refs: Sequence[str],
    ) -> Mapping[str, Any]:
        events = self._events.read()
        for event in reversed(events):
            if str(event.get("event_type") or "") != "node_attempt_handoff":
                continue
            if (
                str(event.get("node_id") or "") == str(node_id)
                and int(event.get("attempt_index") or 0) == int(attempt_index)
                and str(event.get("executor") or "") == "local"
            ):
                return dict(event)
        handoff = build_node_attempt_handoff(
            node_id=node_id,
            attempt_index=attempt_index,
            executor="local",
            status=status,
            formal_result_refs=formal_result_refs,
            work_context_ref=self._state.read()["c1"]["active_work_context_ref"],
            operational_refs=tuple(
                ref for ref in self._state.read()["c1"]["resolved_artifact_refs"]
                if ref.startswith("execution_observation:")
            ),
        )
        self._events.append("node_attempt_handoff", handoff)
        return handoff

    def _record_active_local_node_attempt_handoff(
        self,
        *,
        status: str,
    ) -> Mapping[str, Any] | None:
        state = self._state.read()
        loop_state = state["c1"]["node_loop_state"]
        node_id = str(loop_state.get("node_id") or "").strip()
        attempt_index = int(loop_state.get("attempt_index") or 0)
        steps = loop_state.get("steps")
        has_steps = isinstance(steps, Sequence) and not isinstance(
            steps, (str, bytes)
        ) and bool(steps)
        if (
            not node_id
            or attempt_index < 1
            or (
                not str(state["c1"].get("active_skill_id") or "").strip()
                and not has_steps
            )
        ):
            return None
        return self._record_local_node_attempt_handoff(
            node_id=node_id,
            attempt_index=attempt_index,
            status=status,
            formal_result_refs=tuple(
                str(ref)
                for ref in loop_state.get("produced_refs") or ()
                if str(ref)
            ),
        )

    def _advance_frame_boundary(
        self,
        *,
        frame_closure: Mapping[str, Any],
        round_number: int,
        current_issue: str,
    ) -> Mapping[str, Any] | None:
        """Settle one Frame, then either finish globally or build the next."""
        state = self._state.read()
        graph = state["c1"]["plan_graph"]
        active = active_work_unit(graph)
        if active is not None and not bool(frame_closure.get("complete")):
            return None

        raw_issues = frame_closure.get("issues")
        closure_issues = (
            [str(item) for item in raw_issues]
            if isinstance(raw_issues, Sequence)
            and not isinstance(raw_issues, (str, bytes))
            else []
        )
        evaluator_failures = [
            issue
            for issue in closure_issues
            if issue.startswith("agent_evaluator_failed:")
        ]
        if evaluator_failures:
            failure = bounded_text(evaluator_failures[-1], 1_200)
            issue = (
                "agent_evaluator_failed_after_local_repair: the scientific "
                "work graph is preserved because evaluator infrastructure "
                "failure is not evidence that the graph is invalid. "
                f"Evaluator failure: {failure}"
            )
            self._state.set_issue(issue)
            self._events.append(
                "graph_execution_stopped",
                {
                    "round": round_number,
                    "reason": "agent_evaluator_failure_is_not_graph_evidence",
                    "plan_revision": graph["revision"],
                    "evaluator_failure": failure,
                },
            )
            raise RuntimeError(issue)

        goal_ready = frame_goal_is_ready(graph)
        if not bool(frame_closure.get("complete")):
            settled_graph = settle_frame_graph(graph)
            self._state.set_plan_graph(settled_graph)
            graph = settled_graph
            self._events.append(
                "frame_plan_settled",
                {
                    "round": round_number,
                    "gate_ref": frame_closure["gate_ref"],
                    "success": False,
                    "triggered_stop_id": "",
                    "reason": "enabled_graph_route_exhausted",
                    "goal_predecessors_complete": goal_ready,
                    "settled_plan_graph": settled_graph,
                },
            )

        self._events.append(
            "frame_settled",
            {
                "round": round_number,
                "plan_revision": graph["revision"],
                "goal_node_id": graph["goal_node_id"],
                "goal_predecessors_complete": goal_ready,
                "frame_closure": dict(frame_closure),
            },
        )

        global_closure = self._evaluate_agent_closure(
            round_number=round_number,
            scope="global",
        )
        task_formulation_enabled = bool(
            getattr(self, "_task_formulation_skill_id", "")
        )
        if task_formulation_enabled:
            contract_decision = self._reconcile_task_contract_at_frame_boundary(
                global_closure=global_closure,
            )
            if contract_decision["decision"] == "reformulate_from_sources":
                state = self._state.read()
                self._bootstrap_or_load_evaluation(
                    objective=str(state["c0"]["objective"]),
                    evaluation_request=str(state["c0"]["evaluation_summary"]),
                )
                self._resume_pending_contract_graph_rebuild(
                    round_number=round_number
                )
                return None
        if bool(global_closure.get("complete")):
            self._events.append(
                "global_evaluation_terminal",
                {
                    "round": round_number,
                    "result": dict(global_closure),
                },
            )
            return global_closure

        reason = bounded_text(
            "frame_settled_before_global_completion: the current Frame has "
            "received its judgment, while Global Evaluation still has unmet "
            "criteria. Preserve accepted outcomes and build the next Frame "
            "toward the remaining Global criteria.",
            1_200,
        )
        if task_formulation_enabled:
            self._schedule_contract_graph_rebuild(reason)
            self._resume_pending_contract_graph_rebuild(
                round_number=round_number
            )
        else:
            self._rebuild_current_graph(
                trigger="frame_settled_before_global_completion",
                reason=reason,
                round_number=round_number,
                revision_scope="graph",
            )
        if current_issue:
            self._state.set_issue("")
        return None

    def _build_initial_plan_graph(self) -> dict[str, Any]:
        state = self._state.read()
        visible_refs = [
            str(ref) for ref in state["c1"]["resolved_artifact_refs"]
        ]
        unique_refs = list(dict.fromkeys(visible_refs))
        resolved_artifacts: list[Mapping[str, Any]] = []
        for ref in unique_refs:
            gate_refs = {
                str(state["c1"]["global_evaluation_state"]["gate_ref"]),
                str(
                    (state["c1"]["frame_evaluation_state"] or {}).get(
                        "gate_ref", ""
                    )
                ),
            }
            if ref in gate_refs:
                continue
            projection = dict(
                plan_artifact_projection(self._read_exact_ref(ref))
            )
            # Mission-authorized evidence is already available to this agent.
            # Artifact publication status is a separate lifecycle and must not
            # make the planner recreate an existing upstream result.
            projection.pop("status", None)
            resolved_artifacts.append(projection)
        planning_cards = _task_work_skill_cards(
            self._skills,
            getattr(self, "_task_formulation_skill_id", ""),
        )
        skill_summaries = [
            {
                "skill_id": card.skill_id,
                "description": card.description,
                "estimated_complexity": card.estimated_complexity,
            }
            for card in planning_cards
        ]
        planning_skill_summaries = _planning_skill_summaries(
            self._skills,
            planning_cards,
        )
        gate = self._load_evaluation_gate(
            str(state["c1"]["global_evaluation_state"]["gate_ref"]),
            expected_scope="global",
        )
        selected_frame_goal = select_frame_goal(
            model=self._model,
            memory=self._memory,
            events=self._events,
            objective=_frame_goal_objective(state, self._read_exact_ref),
            global_evaluation_gate=gate,
            global_evaluation_state=state["c1"]["global_evaluation_state"],
            trigger="initial_frame",
            trigger_reason=(
                "No active Frame graph exists. Select the nearest bounded "
                "outcome that can begin progress from current accepted evidence."
            ),
            completed_node_anchors=(),
            accepted_artifacts=resolved_artifacts,
            skill_summaries=planning_skill_summaries,
            previous_frame_goal=None,
            mission_packet=(
                self._mission_prompt_projection() if self._mission else None
            ),
        )
        return create_initial_plan(
            model=self._model,
            memory=self._memory,
            events=self._events,
            objective=str(state["c0"]["objective"]),
            evaluation_gate=gate,
            evaluation_state=state["c1"]["global_evaluation_state"],
            mission_packet=(
                self._mission_prompt_projection() if self._mission else None
            ),
            resolved_artifacts=resolved_artifacts,
            current_issue=str(state["c1"]["current_issue"]),
            skill_summaries=skill_summaries,
            causal_skill_summaries=planning_skill_summaries,
            revision=int(state["c1"]["plan_graph"]["revision"]) + 1,
            frame_goal=selected_frame_goal,
        )


def _frame_graph_mission_context(
    mission_projection: Mapping[str, Any],
) -> dict[str, Any]:
    """Keep mounted-input context while withholding Global goal authority."""
    return {
        key: value
        for key, value in mission_projection.items()
        if key not in {"objective", "evaluation_summary"}
    }


_PLANNING_SKILL_SECTION_NAMES = (
    "Responsibility and boundary",
    "Entry conditions and authority",
)


def _frame_goal_objective(
    state: Mapping[str, Any],
    read_ref: Callable[[str], Mapping[str, Any]],
) -> str:
    objective = str(state["c0"]["objective"])
    contract = state["c1"].get("task_contract_state") or {}
    ref = str(contract.get("task_spec_ref") or "")
    if not ref:
        return objective
    stored = read_ref(ref)
    return (
        objective + "\n\nExact active task contract: " + ref
        + "\nThe following stored content owns task definitions and constraints; "
        "artifact summaries and previous Frame wording do not replace it.\n"
        + json.dumps(stored["machine_payload"], ensure_ascii=False, indent=2)
    )


def _planning_skill_summaries(
    catalog: Any,
    cards: Sequence[Any],
) -> list[dict[str, str]]:
    """Project planning-relevant SKILL.md sections without exposing workflow internals."""
    summaries: list[dict[str, str]] = []
    detail_loader = getattr(catalog, "detail", None)
    for card in cards:
        detail = (
            str(detail_loader(card.skill_id))
            if callable(detail_loader)
            else ""
        )
        sections = _markdown_sections(
            detail,
            names=_PLANNING_SKILL_SECTION_NAMES,
        )
        description = str(card.description).strip()
        if sections:
            description = (
                f"{description}\n\nPlanning contract excerpt:\n{sections}"
            )
        summaries.append(
            {
                "skill_id": card.skill_id,
                "description": description,
                "estimated_complexity": card.estimated_complexity,
            }
        )
    return summaries


def _markdown_sections(text: str, *, names: Sequence[str]) -> str:
    """Extract exact named Markdown sections by document structure only."""
    wanted = set(names)
    collected: list[str] = []
    current: list[str] = []
    current_name = ""
    for line in str(text).splitlines():
        if line.startswith("## "):
            if current_name in wanted:
                collected.append("\n".join(current).strip())
            current_name = line[3:].strip()
            current = [line]
            continue
        if current_name:
            current.append(line)
    if current_name in wanted:
        collected.append("\n".join(current).strip())
    return "\n\n".join(part for part in collected if part)


def plan_artifact_projection(
    stored: Mapping[str, Any],
    *,
    include_small_machine_content: bool = False,
) -> Mapping[str, Any]:
    """Expose only compact stored-result identity to private planning calls."""
    machine_payload = stored.get("machine_payload")
    authored_summary = str(
        stored.get("summary") or stored.get("purpose") or ""
    ).strip()
    structural_summary = (
        _plan_machine_result_summary(
            machine_payload,
            include_small_content=include_small_machine_content,
        )
        if isinstance(machine_payload, Mapping)
        else ""
    )
    summary = "; ".join(
        part for part in (authored_summary, structural_summary) if part
    )
    projection = {
        "artifact_ref": (
            stored.get("artifact_ref")
            or stored.get("code_artifact_ref")
            or stored.get("observation_ref")
        ),
        "artifact_kind": stored.get("artifact_kind"),
        "status": stored.get("status"),
        "title": stored.get("title") or stored.get("purpose"),
        "summary": summary,
        "depends_on": stored.get("depends_on", []),
    }
    if isinstance(machine_payload, Mapping):
        for key in ("target_kind", "target_id"):
            value = machine_payload.get(key)
            if isinstance(value, str) and value.strip():
                projection[key] = value.strip()
    return projection


def _plan_machine_result_summary(
    payload: Mapping[str, Any],
    *,
    include_small_content: bool = False,
) -> str:
    """Summarize result shape without exposing large values or semantics."""
    if include_small_content:
        rendered_payload = json.dumps(
            payload,
            ensure_ascii=False,
            separators=(",", ":"),
        )
        if len(rendered_payload) <= 4_000:
            return "stored machine result: " + rendered_payload
    parts: list[str] = []
    items = list(payload.items())
    for raw_key, value in items[:12]:
        key = str(raw_key)
        if key == "artifact_kind":
            continue
        if value is None or isinstance(value, bool):
            rendered = json.dumps(value)
        elif isinstance(value, str):
            if key == "status" or key.endswith("_status"):
                rendered = json.dumps(value[:120], ensure_ascii=False)
            else:
                rendered = f"<string:{len(value)} chars>"
        elif isinstance(value, (int, float)):
            rendered = f"<{type(value).__name__}>"
        elif isinstance(value, Mapping):
            rendered = f"<mapping:{len(value)} entries>"
        elif isinstance(value, Sequence) and not isinstance(
            value, (str, bytes, bytearray)
        ):
            rendered = f"<sequence:{len(value)} items>"
        else:
            rendered = f"<{type(value).__name__}>"
        parts.append(f"{key}={rendered}")
    if len(items) > 12:
        parts.append(f"additional_fields=<{len(items) - 12}>")
    if not parts:
        return ""
    return "stored machine result: " + "; ".join(parts)
