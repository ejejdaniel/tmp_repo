from __future__ import annotations

import json
import re
from typing import Any, Mapping, Sequence

from .memory_lifecycle.prompt import bounded_projection, bounded_text


def task_work_skill_cards(
    skills: Any,
    task_formulation_skill_id: str,
) -> tuple[Any, ...]:
    """Return the selectable skills outside task-contract bootstrap."""
    bootstrap_skill_id = str(task_formulation_skill_id).strip()
    return tuple(
        card
        for card in skills.summaries()
        if card.skill_id != bootstrap_skill_id
    )


def slug_child_id(value: str) -> str:
    normalized = re.sub(r"[^a-zA-Z0-9._-]+", "-", str(value).strip()).strip("-")
    if not normalized:
        return ""
    return normalized[:80]


def exact_string_refs(value: Any) -> tuple[str, ...]:
    refs: list[str] = []

    def visit(item: Any) -> None:
        if isinstance(item, str):
            if item and item not in refs:
                refs.append(item)
            return
        if isinstance(item, Mapping):
            for nested in item.values():
                visit(nested)
            return
        if isinstance(item, Sequence) and not isinstance(
            item, (str, bytes, bytearray)
        ):
            for nested in item:
                visit(nested)

    visit(value)
    return tuple(refs)


def stored_ref_strings(value: Any) -> tuple[str, ...]:
    return tuple(
        ref
        for ref in exact_string_refs(value)
        if ref.startswith(
            (
                "artifact:",
                "code_artifact:",
                "execution_observation:",
                "workspace:",
            )
        )
    )


def observation_current_state_identity(
    stored: Mapping[str, Any],
) -> tuple[str, tuple[str, ...]] | None:
    namespace = str(stored.get("namespace") or "").strip()
    dependencies = tuple(sorted(stored_ref_strings(stored.get("metadata"))))
    if not namespace or not dependencies:
        return None
    return namespace, dependencies


def result_establishes_progress(
    tool_name: str,
    result: Mapping[str, Any],
) -> bool:
    if (
        tool_name in {"read_ref", "source_read"}
        and result.get("status") == "source_page_ready"
    ):
        return True
    if tool_name in {"read_ref", "artifact_read", "artifact_list", "load_skill"}:
        return False
    return any(
        str(result.get(key) or "").startswith(prefix)
        for key, prefix in (
            ("artifact_ref", "artifact:"),
            ("snapshot_ref", "artifact:"),
            ("code_artifact_ref", "code_artifact:"),
            ("observation_ref", "execution_observation:"),
        )
    )


def canonical_tool_arguments(value: Any) -> str:
    if not isinstance(value, Mapping):
        value = {}
    return json.dumps(
        dict(value),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )


def function_tool(
    name: str, description: str, parameters: Mapping[str, Any]
) -> dict[str, Any]:
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": dict(parameters),
        },
    }


def merge_current_issue(current: str, latest_error: str) -> str:
    current = current.strip()
    latest_error = latest_error.strip()
    if not current:
        return latest_error
    if latest_error in current:
        return current
    return bounded_text(current + "\nLatest tool error: " + latest_error, 2_000)


def latest_failed_tool_name(receipts: Sequence[Mapping[str, Any]]) -> str:
    for receipt in reversed(receipts):
        result = receipt.get("result")
        if isinstance(result, Mapping) and result.get("status") == "tool_error":
            return str(receipt.get("tool") or "")
    return ""


def return_control_issue(
    final_text: str,
    closure_result: Mapping[str, Any],
    *,
    source: str,
    artifact_refs: tuple[str, ...] = (),
) -> str:
    explanation = bounded_text(final_text.strip(), 300) or "(empty)"
    closure_projection = bounded_projection(
        closure_result,
        max_depth=3,
        max_items=6,
    )
    ref_text = (
        " Formal artifacts published in that invocation: "
        + json.dumps(list(artifact_refs), ensure_ascii=False)
        if artifact_refs
        else ""
    )
    closure_text = bounded_text(
        json.dumps(closure_projection, ensure_ascii=False),
        900,
    )
    return bounded_text(
        f"Historical result from the {source}; this is context, not an "
        "instruction and not proof of success."
        + ref_text
        + "\nClosure evaluator projection: "
        + closure_text
        + "\nExplanation: "
        + explanation,
        1_600,
    )
