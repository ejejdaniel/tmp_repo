from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from .json_schema import json_schema_issues
from .memory_lifecycle.dialogue_memory import (
    DialogueMemory,
    RECENT_DIALOGUE_BUDGET_BYTES,
)
from .memory_lifecycle.events import EventLog
from .memory_lifecycle.prompt import bounded_projection
from .model import ChatModel, complete_model_turn
from .observations import ObservationStore
from .routes import Route, RouteRegistry
from ._runtime_support import function_tool


PRE_TASK_SKILL_ID = "pre-task-inquiry"
_MAX_PLAN_COST = 8
_MAX_PLAN_STEPS = 6
_ACTION_COSTS = {
    "source_inventory": 1,
    "source_search": 1,
    "source_read": 1,
    "source_probe": 3,
    "workspace_terminal": 3,
    "dialogue_search": 1,
    "dialogue_read": 1,
}

_INTAKE_INSTRUCTION = """\
No formal task contract exists yet. Apply the skill's Resolution policy to the
user's current request. Use exactly one supplied tool call. When planning an
inquiry, its goal and completion_test must describe the answer it will provide
or the missing request information it will retrieve under that policy.

For a supplied source-relative path, plan a targeted inventory to obtain its
exact ref, followed by read for a bounded content lookup or probe for a whole-
data computation. Never use a broad inventory to locate an already named path.
If only a basename is known and its directory is unknown, plan a read-only
terminal filename lookup and targeted inventory before the content operation.
For counts, filters, grouping, aggregation, or any claim over all records in a
structured source, plan a targeted inventory followed by source_probe. A prompt-
visible source_read excerpt is not whole-dataset evidence.

Do not claim that files, data, packages, APIs, or prior results were inspected in
this intake call. The host computes plan cost; keep the action sequence within
the supplied fixed budget. When beginning task formulation, the latest user
message is always transferred. Select only earlier dialogue messages needed to
interpret it; do not transfer the whole conversation. The dialogue_summary is
navigation only. If a needed earlier message is summarized but absent from
recent_dialogue, plan dialogue_search followed by dialogue_read and select its
message_id only after the exact read. No inquiry observation exists at this
stage, so include_inquiry_observation must be false. Match the user's language.
"""

_PAYLOAD_INSTRUCTION = """\
Prepare arguments for the one already-planned route action. Use exactly one call
to the supplied route through native tool_calls, with no ordinary response prose
or literal tool-protocol markup. Use only refs and paths present in the user
request, supplied tool description, or prior receipts. Do not change the plan,
add another action, or claim a result.
For source_inventory, pass the exact relative_path whenever the user or a prior
receipt supplies it; do not drop a known path and inventory the whole tree.
For terminal inspection, use a read-only command compatible with the disclosed
host shell and exact Python executable. For source_probe, operate only on the
staged SOURCE_ROOT inputs and return explicit machine-readable results.
For a whole-dataset query, parse the complete staged source and print compact
JSON containing the answer, matching record ids, and the mechanical rule used.
"""

_FINAL_INSTRUCTION = """\
Apply the skill's Resolution policy to the user's remaining request after the
bounded inquiry. Use exactly one supplied tool call. Assess what the receipts
establish, then decide how to address the request. The local completion_test
does not decide whether the user's request is answered or formal work can start.

Inventory and search results are locators only. Cite only exact refs in the
supplied inspected_evidence_refs. State uncertainty plainly and match the user's
language. Partial or truncated evidence cannot support a complete answer;
choose the next resolution under the same policy. Do not present this inquiry as
accepted scientific evidence. When beginning task formulation, select only earlier dialogue messages
needed to interpret the latest user message. A summarized old message can be
selected only after dialogue_read returned its exact content. Include the
bounded inquiry observation only when its inspected result materially informs
formulation.
"""

_EXECUTION_REPAIR_INSTRUCTION = """\
Repair the failed execution of the current planned action using the skill's
Bounded LOOP policy. The last prior_receipt contains the exact failed arguments,
result, and output readbacks. Return one corrected call of the same route. Keep
the purpose, read-only scope, and timeout; do not add actions or install anything.
Use the disclosed shell and executable. Interpret missing resources only within
the environment actually probed. Preserve genuine failure evidence.
"""


@dataclass(frozen=True)
class PreTaskLoopResult:
    status: str
    turn_id: str
    user_message_id: str
    message: str = ""
    evidence_refs: tuple[str, ...] = ()
    supporting_refs: tuple[str, ...] = ()
    context_message_ids: tuple[str, ...] = ()
    include_inquiry_observation: bool = False


class PreTaskLoop:
    """One skill-bounded LOOP that runs before CommonAgent establishes C0."""

    def __init__(
        self,
        *,
        model: ChatModel,
        routes: RouteRegistry,
        dialogue_memory: DialogueMemory,
        observations: ObservationStore,
        events: EventLog,
        skill_path: Path,
    ) -> None:
        self._model = model
        self._routes = routes
        self._dialogue_memory = dialogue_memory
        self._dialogue = dialogue_memory.dialogue
        self._observations = observations
        self._events = events
        self._skill_path = skill_path.resolve()
        if not self._skill_path.is_file():
            raise FileNotFoundError(
                f"pre_task_skill_missing:{self._skill_path}"
            )

    def run(self, user_text: str) -> PreTaskLoopResult:
        normalized = str(user_text).strip()
        if not normalized:
            raise ValueError("pre_task_user_text_required")
        recent = list(
            self._dialogue_memory.recent(
                max_bytes=RECENT_DIALOGUE_BUDGET_BYTES
            )
        )
        visible_message_ids = list(_existing_dialogue_message_ids(recent))
        dialogue_summary = self._dialogue_memory.summary()
        turn_id = f"turn-{uuid.uuid4().hex}"
        message_id = f"msg-{uuid.uuid4().hex}"
        self._dialogue.append_message(
            message_id=message_id,
            turn_id=turn_id,
            role="user",
            content=normalized,
        )
        intake = self._model_action(
            purpose="decide pre-task dialogue resolution",
            instruction=_INTAKE_INSTRUCTION,
            payload={
                "latest_user_message": normalized,
                "dialogue_summary": dialogue_summary,
                "recent_dialogue": recent,
                "plan_costs": dict(_ACTION_COSTS),
                "maximum_plan_cost": _MAX_PLAN_COST,
            },
            tools=_intake_tools(
                _existing_dialogue_refs(recent),
                visible_message_ids,
            ),
            allowed={
                "reply_to_user",
                "ask_user_clarification",
                "begin_task_formulation",
                "plan_pre_task_inquiry",
            },
            planning_call=True,
        )
        name = intake["name"]
        arguments = intake["arguments"]
        if name == "reply_to_user":
            return self._finish(
                status="answered",
                turn_id=turn_id,
                user_message_id=message_id,
                message=str(arguments["message"]),
                evidence_refs=arguments.get("evidence_refs") or (),
            )
        if name == "ask_user_clarification":
            return self._finish(
                status="clarification_required",
                turn_id=turn_id,
                user_message_id=message_id,
                message=str(arguments["question"]),
            )
        if name == "begin_task_formulation":
            return PreTaskLoopResult(
                status="task_ready",
                turn_id=turn_id,
                user_message_id=message_id,
                context_message_ids=tuple(arguments["context_message_ids"]),
                include_inquiry_observation=bool(
                    arguments["include_inquiry_observation"]
                ),
            )

        plan = _validated_plan(arguments)
        receipts: list[dict[str, Any]] = []
        inspected_refs: list[str] = []
        for index, step in enumerate(plan["steps"], start=1):
            route = _route(self._routes, str(step["action"]))
            for execution_attempt in range(2):
                prepared = self._model_action(
                    purpose=f"prepare pre-task action {index}",
                    instruction=_PAYLOAD_INSTRUCTION + (
                        "\n" + _EXECUTION_REPAIR_INSTRUCTION
                        if execution_attempt else ""
                    ),
                    payload={
                        "latest_user_message": normalized,
                        "plan": plan,
                        "current_step": dict(step),
                        "prior_receipts": bounded_projection(
                            receipts,
                            max_depth=6,
                            max_items=80,
                        ),
                    },
                    tools=(route.tool_spec(),),
                    allowed={route.name},
                    argument_validator=lambda arguments, route_name=route.name: (
                        self._routes.validate(
                            route_name,
                            arguments,
                            skill_id=PRE_TASK_SKILL_ID,
                        )
                    ),
                    scientific_call=route.name in {"workspace_terminal", "source_probe"},
                    repair_call=bool(execution_attempt),
                )
                result = self._execute_route(route, prepared["arguments"])
                readback_refs, readbacks = self._automatic_readback(route.name, result)
                for ref in readback_refs:
                    if ref not in inspected_refs:
                        inspected_refs.append(ref)
                if route.name == "source_read":
                    ref = str(prepared["arguments"].get("source_ref") or "")
                    if ref and ref not in inspected_refs:
                        inspected_refs.append(ref)
                if route.name == "dialogue_read":
                    read_message = result.get("message")
                    if isinstance(read_message, Mapping):
                        read_message_id = str(read_message.get("message_id") or "").strip()
                        if read_message_id and read_message_id not in visible_message_ids:
                            visible_message_ids.append(read_message_id)
                receipt = {
                    "step": index,
                    "action": route.name,
                    "purpose": str(step["purpose"]),
                    "arguments": dict(prepared["arguments"]),
                    "result": result,
                }
                if readbacks:
                    receipt["automatic_readback"] = readbacks
                receipts.append(receipt)
                self._events.append(
                    "pre_task_action_completed",
                    {
                        "turn_id": turn_id,
                        "step": index,
                        "action": route.name,
                        "result": result,
                        "automatic_readback_refs": list(readback_refs),
                    },
                )
                if result.get("status") not in {
                    "workspace_terminal_failed", "source_probe_failed"
                } or result.get("timed_out"):
                    break
            if result.get("status") in {
                "pre_task_route_failed", "workspace_terminal_failed",
                "source_probe_failed", "workspace_terminal_timed_out",
                "source_probe_timed_out",
            }:
                break

        final = self._model_action(
            purpose="finish pre-task inquiry",
            instruction=_FINAL_INSTRUCTION,
            payload={
                "latest_user_message": normalized,
                "dialogue_summary": dialogue_summary,
                "recent_dialogue": recent,
                "plan": plan,
                "action_receipts": bounded_projection(
                    receipts,
                    max_depth=7,
                    max_items=120,
                ),
                "inspected_evidence_refs": inspected_refs,
            },
            tools=_final_tools(inspected_refs, visible_message_ids),
            allowed={
                "reply_to_user",
                "ask_user_clarification",
                "begin_task_formulation",
                "report_bounded_gap",
            },
            planning_call=True,
        )
        final_name = final["name"]
        final_arguments = final["arguments"]
        observation_ref = self._publish_observation(
            turn_id=turn_id,
            user_text=normalized,
            plan=plan,
            receipts=receipts,
            inspected_refs=inspected_refs,
            conclusion={
                "action": final_name,
                "arguments": dict(final_arguments),
            },
        )
        if final_name == "begin_task_formulation":
            include_observation = bool(
                final_arguments["include_inquiry_observation"]
            )
            return PreTaskLoopResult(
                status="task_ready",
                turn_id=turn_id,
                user_message_id=message_id,
                supporting_refs=(
                    (observation_ref,) if include_observation else ()
                ),
                context_message_ids=tuple(
                    final_arguments["context_message_ids"]
                ),
                include_inquiry_observation=include_observation,
            )
        supporting_refs = (observation_ref,)
        if final_name == "ask_user_clarification":
            return self._finish(
                status="clarification_required",
                turn_id=turn_id,
                user_message_id=message_id,
                message=str(final_arguments["question"]),
                evidence_refs=supporting_refs,
            )
        if final_name == "report_bounded_gap":
            return self._finish(
                status="bounded_gap",
                turn_id=turn_id,
                user_message_id=message_id,
                message=str(final_arguments["message"]),
                evidence_refs=(
                    *final_arguments.get("evidence_refs", ()),
                    observation_ref,
                ),
            )
        return self._finish(
            status="answered",
            turn_id=turn_id,
            user_message_id=message_id,
            message=str(final_arguments["message"]),
            evidence_refs=(
                *final_arguments.get("evidence_refs", ()),
                observation_ref,
            ),
        )

    def finish_deferred(
        self,
        result: PreTaskLoopResult,
        *,
        status: str,
        message: str,
    ) -> PreTaskLoopResult:
        return self._finish(
            status=status,
            turn_id=result.turn_id,
            user_message_id=result.user_message_id,
            message=message,
            evidence_refs=result.supporting_refs,
        )

    def _finish(
        self,
        *,
        status: str,
        turn_id: str,
        user_message_id: str,
        message: str,
        evidence_refs: Sequence[str] = (),
    ) -> PreTaskLoopResult:
        normalized = str(message).strip()
        if not normalized:
            raise RuntimeError("pre_task_assistant_message_required")
        refs = tuple(
            dict.fromkeys(str(ref) for ref in evidence_refs if str(ref))
        )
        self._dialogue.append_message(
            message_id=f"msg-{uuid.uuid4().hex}",
            turn_id=turn_id,
            role="assistant",
            content=normalized,
            evidence_refs=refs,
        )
        self._events.append(
            "pre_task_turn_completed",
            {
                "turn_id": turn_id,
                "status": status,
                "evidence_refs": list(refs),
            },
        )
        try:
            self._dialogue_memory.maybe_compact(turn_id=turn_id)
        except Exception as exc:
            self._events.append(
                "dialogue_compaction_deferred",
                {"turn_id": turn_id, "reason": str(exc)},
            )
        return PreTaskLoopResult(
            status=status,
            turn_id=turn_id,
            user_message_id=user_message_id,
            message=normalized,
            evidence_refs=refs,
        )

    def _execute_route(
        self,
        route: Route,
        arguments: Mapping[str, Any],
    ) -> dict[str, Any]:
        issues = json_schema_issues(arguments, route.parameters)
        if issues:
            raise ValueError(
                "pre_task_route_arguments_invalid:"
                + "; ".join(issues[:12])
            )
        try:
            result = self._routes.execute(
                route.name,
                arguments,
                skill_id=PRE_TASK_SKILL_ID,
            )
        except Exception as exc:
            return {
                "status": "pre_task_route_failed",
                "route": route.name,
                "error": f"{type(exc).__name__}:{exc}",
            }
        if not isinstance(result, Mapping):
            raise TypeError(
                f"pre_task_route_result_must_be_object:{route.name}"
            )
        return dict(result)

    def _automatic_readback(
        self,
        route_name: str,
        result: Mapping[str, Any],
    ) -> tuple[tuple[str, ...], list[dict[str, Any]]]:
        if route_name not in {"source_probe", "workspace_terminal"}:
            return (), []
        refs = []
        for key in ("stdout_ref", "stderr_ref"):
            ref = str(result.get(key) or "")
            if not ref:
                continue
            if key == "stderr_ref" and not str(
                result.get("stderr_preview") or ""
            ).strip() and str(result.get("status") or "").endswith(
                "succeeded"
            ):
                continue
            refs.append(ref)
        readbacks = [
            dict(
                self._routes.execute(
                    "source_read",
                    {"source_ref": ref, "line_offset": 0, "line_limit": 2000},
                    skill_id=PRE_TASK_SKILL_ID,
                )
            )
            for ref in refs
        ]
        return tuple(refs), readbacks

    def _publish_observation(
        self,
        *,
        turn_id: str,
        user_text: str,
        plan: Mapping[str, Any],
        receipts: Sequence[Mapping[str, Any]],
        inspected_refs: Sequence[str],
        conclusion: Mapping[str, Any],
    ) -> str:
        receipt = self._observations.publish(
            namespace="pre-task-inquiry",
            status="pre_task_inquiry_completed",
            result={
                "user_request": user_text,
                "plan": dict(plan),
                "action_receipts": [dict(item) for item in receipts],
                "inspected_evidence_refs": list(inspected_refs),
                "conclusion": dict(conclusion),
            },
            metadata={"turn_id": turn_id, "skill_id": PRE_TASK_SKILL_ID},
        )
        return str(receipt["observation_ref"])

    def _model_action(
        self,
        *,
        purpose: str,
        instruction: str,
        payload: Mapping[str, Any],
        tools: Sequence[Mapping[str, Any]],
        allowed: set[str],
        argument_validator: Any | None = None,
        scientific_call: bool = False,
        planning_call: bool = False,
        repair_call: bool = False,
    ) -> dict[str, Any]:
        issue = ""
        for attempt in range(1, 4):
            call_payload = dict(payload)
            if issue:
                call_payload["format_repair"] = issue
            messages = [
                {
                    "role": "system",
                    "content": self._skill_path.read_text(encoding="utf-8")
                    + "\n\n"
                    + instruction,
                },
                {
                    "role": "user",
                    "content": json.dumps(
                        call_payload,
                        ensure_ascii=False,
                        default=str,
                    ),
                },
            ]
            self._events.append(
                "prompt_snapshot",
                {
                    "call_site": purpose,
                    "messages": messages,
                    "tools": list(tools),
                    "source": "pre_task_inquiry",
                },
            )
            is_repair = repair_call or bool(issue)
            call_purpose = purpose if not is_repair else f"repair {purpose}"
            turn = complete_model_turn(
                self._model,
                messages=messages,
                tools=tools,
                purpose=call_purpose,
                tool_choice="required",
                repair=is_repair,
                scientific=scientific_call and not is_repair,
                planning=planning_call and not is_repair,
            )
            self._events.append(
                "pre_task_model_turn",
                {
                    "purpose": purpose,
                    "attempt": attempt,
                    "content": turn.content,
                    "tool_calls": [
                        {
                            "call_id": call.call_id,
                            "name": call.name,
                            "arguments": dict(call.arguments),
                        }
                        for call in turn.tool_calls
                    ],
                    "usage": dict(turn.usage),
                },
            )
            if len(turn.tool_calls) != 1:
                issue = "Use exactly one supplied tool."
                continue
            call = turn.tool_calls[0]
            if call.name not in allowed:
                issue = f"Choose one allowed action, not {call.name}."
                continue
            tool = next(
                item for item in tools if item["function"]["name"] == call.name
            )
            schema = tool["function"]["parameters"]
            issues = json_schema_issues(call.arguments, schema)
            if issues:
                issue = "; ".join(issues[:12])
                continue
            if call.name == "plan_pre_task_inquiry":
                try:
                    _validated_plan(call.arguments)
                except (TypeError, ValueError) as exc:
                    issue = str(exc)
                    continue
            if argument_validator is not None:
                try:
                    argument_validator(call.arguments)
                except (
                    KeyError,
                    PermissionError,
                    RuntimeError,
                    TypeError,
                    ValueError,
                ) as exc:
                    issue = str(exc)
                    continue
            return {"name": call.name, "arguments": dict(call.arguments)}
        raise RuntimeError(f"pre_task_model_action_exhausted:{purpose}:{issue}")


def _route(routes: RouteRegistry, name: str) -> Route:
    for route in routes.visible(PRE_TASK_SKILL_ID):
        if route.name == name:
            return route
    raise KeyError(f"pre_task_route_unavailable:{name}")


def _validated_plan(value: Mapping[str, Any]) -> dict[str, Any]:
    steps = value.get("steps")
    if not isinstance(steps, list) or not steps:
        raise ValueError("pre_task_plan_steps_required")
    if len(steps) > _MAX_PLAN_STEPS:
        raise ValueError("pre_task_plan_too_many_steps")
    cost = 0
    normalized_steps: list[dict[str, str]] = []
    for index, raw in enumerate(steps):
        if not isinstance(raw, Mapping):
            raise TypeError(f"pre_task_plan_step_invalid:{index}")
        action = str(raw.get("action") or "")
        purpose = str(raw.get("purpose") or "").strip()
        if action not in _ACTION_COSTS or not purpose:
            raise ValueError(f"pre_task_plan_step_invalid:{index}")
        cost += _ACTION_COSTS[action]
        normalized_steps.append({"action": action, "purpose": purpose})
    if cost > _MAX_PLAN_COST:
        raise ValueError(
            f"pre_task_plan_cost_exceeded:cost={cost}:limit={_MAX_PLAN_COST}"
        )
    return {
        "goal": str(value["goal"]).strip(),
        "completion_test": str(value["completion_test"]).strip(),
        "steps": normalized_steps,
        "computed_cost": cost,
    }


def _intake_tools(
    visible_refs: Sequence[str],
    visible_message_ids: Sequence[str] = (),
) -> tuple[dict[str, Any], ...]:
    return (
        _reply_tool(visible_refs),
        _clarification_tool(),
        _begin_task_tool(
            visible_message_ids,
            inquiry_observation_available=False,
        ),
        function_tool(
            "plan_pre_task_inquiry",
            "Plan one bounded inquiry under the skill's Resolution policy; "
            "its local completion test does not replace the user's request.",
            {
                "type": "object",
                "properties": {
                    "goal": {"type": "string", "minLength": 1},
                    "completion_test": {"type": "string", "minLength": 1},
                    "steps": {
                        "type": "array",
                        "minItems": 1,
                        "maxItems": _MAX_PLAN_STEPS,
                        "items": {
                            "type": "object",
                            "properties": {
                                "action": {
                                    "type": "string",
                                    "enum": list(_ACTION_COSTS),
                                },
                                "purpose": {"type": "string", "minLength": 1},
                            },
                            "required": ["action", "purpose"],
                            "additionalProperties": False,
                        },
                    },
                },
                "required": ["goal", "completion_test", "steps"],
                "additionalProperties": False,
            },
        ),
    )


def _final_tools(
    visible_refs: Sequence[str],
    visible_message_ids: Sequence[str] = (),
) -> tuple[dict[str, Any], ...]:
    return (
        _reply_tool(visible_refs),
        _clarification_tool(),
        _begin_task_tool(
            visible_message_ids,
            inquiry_observation_available=True,
        ),
        function_tool(
            "report_bounded_gap",
            "Report an evidenced obstacle under the skill's Resolution policy, "
            "including its scope and required external change.",
            {
                "type": "object",
                "properties": {
                    "message": {"type": "string", "minLength": 1},
                    "evidence_refs": _refs_schema(visible_refs),
                },
                "required": ["message", "evidence_refs"],
                "additionalProperties": False,
            },
        ),
    )


def _reply_tool(visible_refs: Sequence[str]) -> dict[str, Any]:
    return function_tool(
        "reply_to_user",
        "Answer the user's current request under the skill's Resolution policy, "
        "grounded in visible dialogue or inspected evidence.",
        {
            "type": "object",
            "properties": {
                "message": {"type": "string", "minLength": 1},
                "evidence_refs": _refs_schema(visible_refs),
            },
            "required": ["message", "evidence_refs"],
            "additionalProperties": False,
        },
    )


def _clarification_tool() -> dict[str, Any]:
    return function_tool(
        "ask_user_clarification",
        "Ask for a missing human decision or essential input under the skill's "
        "Resolution policy.",
        {
            "type": "object",
            "properties": {"question": {"type": "string", "minLength": 1}},
            "required": ["question"],
            "additionalProperties": False,
        },
    )


def _begin_task_tool(
    visible_message_ids: Sequence[str],
    *,
    inquiry_observation_available: bool,
) -> dict[str, Any]:
    include_schema: dict[str, Any] = {"type": "boolean"}
    if not inquiry_observation_available:
        include_schema["enum"] = [False]
    return function_tool(
        "begin_task_formulation",
        (
            "Start an isolated formal research run from the exact latest user "
            "message plus only deliberately selected prior dialogue context, "
            "under the skill's Resolution policy. This starts investigation; "
            "it does not certify implementation readiness or success."
        ),
        {
            "type": "object",
            "properties": {
                "reason": {"type": "string", "minLength": 1},
                "context_message_ids": _message_ids_schema(
                    visible_message_ids
                ),
                "include_inquiry_observation": include_schema,
            },
            "required": [
                "reason",
                "context_message_ids",
                "include_inquiry_observation",
            ],
            "additionalProperties": False,
        },
    )


def _message_ids_schema(visible_message_ids: Sequence[str]) -> dict[str, Any]:
    message_ids = list(dict.fromkeys(str(item) for item in visible_message_ids))
    if not message_ids:
        return {
            "type": "array",
            "items": {"type": "string", "minLength": 1},
            "maxItems": 0,
        }
    return {
        "type": "array",
        "items": {
            "type": "string",
            "minLength": 1,
            "enum": message_ids,
        },
        "uniqueItems": True,
        "maxItems": len(message_ids),
    }


def _refs_schema(visible_refs: Sequence[str]) -> dict[str, Any]:
    refs = list(visible_refs)
    if not refs:
        return {
            "type": "array",
            "items": {"type": "string", "minLength": 1},
            "maxItems": 0,
        }
    item: dict[str, Any] = {
        "type": "string",
        "minLength": 1,
        "enum": refs,
    }
    return {
        "type": "array",
        "items": item,
        "uniqueItems": True,
    }


def _existing_dialogue_refs(messages: Sequence[Mapping[str, Any]]) -> tuple[str, ...]:
    refs: list[str] = []
    for message in messages:
        for key in ("attachment_refs", "evidence_refs"):
            for raw in message.get(key) or ():
                ref = str(raw).strip()
                if ref and ref not in refs:
                    refs.append(ref)
    return tuple(refs)


def _existing_dialogue_message_ids(
    messages: Sequence[Mapping[str, Any]],
) -> tuple[str, ...]:
    return tuple(
        dict.fromkeys(
            str(message.get("message_id") or "").strip()
            for message in messages
            if str(message.get("message_id") or "").strip()
        )
    )
