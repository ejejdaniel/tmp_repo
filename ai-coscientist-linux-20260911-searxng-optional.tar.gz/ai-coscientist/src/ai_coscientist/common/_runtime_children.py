from __future__ import annotations

import copy
from dataclasses import replace
from pathlib import Path
from typing import Any, Mapping, Sequence

from ._runtime_support import slug_child_id
from .attempt_handoffs import build_node_attempt_handoff
from .artifacts import ArtifactStore
from .children import (
    ChildMission,
    ChildMissionError,
    MissionWorkspace,
    ResolvedMissionWorkspace,
)
from .code_artifacts import CodeArtifactStore
from .memory_lifecycle.prompt import bounded_projection, bounded_text
from .observations import ObservationStore
from .planning import GRAPH_REVISION_OUTCOME_KIND
from .routes import RouteRegistry
from .source_exploration import SourceExplorer
from .sub_loop_toolkit import HumanInteractionPause


_WORKSPACE_SOURCE_ROUTE_NAMES = frozenset(
    {
        "source_inventory",
        "source_search",
        "source_read",
        "source_probe",
        "workspace_terminal",
    }
)


class ChildRuntimeMixin:
    """White-room child creation, quarantine, and parent review boundary."""

    def _child_source_root(self) -> Path:
        explorer = _source_explorer(self._routes)
        return explorer.source_root.resolve() if explorer else self._workspace_root

    def _resolve_child_workspace(self, mission: ChildMission) -> ResolvedMissionWorkspace:
        root = (mission.workspace_root or self._child_source_root()).resolve()
        explorer = _source_explorer(self._routes)
        exclusions = []
        for relative in self._workspace_excluded_relative_paths:
            excluded = (self._workspace_root / relative).resolve()
            if excluded.is_relative_to(root):
                exclusions.append(excluded.relative_to(root).as_posix())
        same_source = explorer is not None and root == explorer.source_root.resolve()
        if same_source and explorer.path_policy is not None:
            exclusions.extend(explorer.path_policy.excluded_relative_paths)
        workspace = replace(mission, workspace_root=root).workspace(
            excluded_relative_paths=tuple(dict.fromkeys(exclusions))
        ).resolve()
        if not same_source or "." in explorer.allowed_relative_paths:
            return workspace

        # Discovery inherits the parent's source scope, never the entire root.
        intersection = []
        for request in workspace.allowed_relative_paths:
            candidate = (root / request).resolve()
            for allowed in explorer.allowed_relative_paths:
                authority = (root / allowed).resolve()
                if candidate == authority or (authority.is_dir() and candidate.is_relative_to(authority)):
                    intersection.append(candidate.relative_to(root).as_posix())
                elif candidate.is_dir() and authority.is_relative_to(candidate):
                    intersection.append(authority.relative_to(root).as_posix())
        return MissionWorkspace(
            root=root, refs=tuple(dict.fromkeys(intersection)), discover=False,
            excluded_relative_paths=workspace.path_policy.excluded_relative_paths,
        ).resolve()

    def spawn_child(
        self,
        mission: ChildMission,
        *,
        child_id: str | None = None,
    ) -> Mapping[str, Any]:
        """Run a fresh common-agent child with the supplied mission packet."""
        if not isinstance(mission, ChildMission):
            raise TypeError("child_mission_must_be_ChildMission")
        self._validate_child_work_refs(mission)
        if self._child_depth >= self._max_child_depth:
            raise ChildMissionError("child_depth_limit_reached")
        requested_id = child_id or f"child-{len(self._children) + 1}"
        safe_id = slug_child_id(requested_id)
        if not safe_id:
            raise ChildMissionError("child_id_required")
        if safe_id in self._children:
            raise ChildMissionError(f"child_id_already_used:{safe_id}")

        if mission.workspace_root is None:
            mission = ChildMission(
                objective=mission.objective,
                evaluation_summary=mission.evaluation_summary,
                enabled_meta_capabilities=(
                    mission.enabled_meta_capabilities
                ),
                mission_context=mission.mission_context,
                artifact_refs=mission.artifact_refs,
                work_entry_refs=mission.work_entry_refs,
                workspace_refs=mission.workspace_refs,
                workspace_root=self._child_source_root(),
                allow_workspace_discovery=mission.allow_workspace_discovery,
            )
        child = self._build_child_runtime(child_id=safe_id, mission=mission)
        child_agent_id = child.agent_id
        self._events.append(
            "child_spawned",
            {
                "child_id": safe_id,
                "child_agent_id": child_agent_id,
                "depth": child._child_depth,
                "mission": child._mission_prompt_projection(),
                "skill_ids": [card.skill_id for card in child._skills.summaries()],
            },
        )
        result = child.run(
            objective=mission.objective,
            evaluation_summary=mission.evaluation_summary,
        )
        if result.status == "paused_for_human":
            self._hold_paused_child(
                child_id=safe_id,
                child=child,
                mission=mission,
                rounds=result.rounds,
            )
            raise HumanInteractionPause()
        return self._finalize_child_return(
            child_id=safe_id,
            child=child,
            mission=mission,
            result=result,
            rounds=result.rounds,
        )

    def _build_child_runtime(
        self,
        *,
        child_id: str,
        mission: ChildMission,
    ) -> Any:
        child_agent_id = f"{self.agent_id}.child.{child_id}"
        child_root = self._event_log_path.parent / "children" / child_id
        child_root.mkdir(parents=True, exist_ok=True)
        child_artifacts = ArtifactStore(
            self._artifact_store.root,
            agent_id=child_agent_id,
            run_id=child_agent_id,
            payload_validators=self._artifact_store.payload_validators,
            payload_schemas=self._artifact_store.payload_schemas,
        )
        child_observations = ObservationStore(self._artifact_store.root)
        child_code_artifacts = (
            CodeArtifactStore(self._artifact_store.root)
            if self._code_artifacts is not None
            else None
        )
        mission = replace(mission, workspace_root=mission.workspace_root or self._child_source_root())
        mission_workspace = self._resolve_child_workspace(mission)
        child_routes = _mission_scoped_route_registry(
            self._routes,
            workspace=mission_workspace,
        )
        from .runtime import CommonAgent

        return CommonAgent(
            agent_id=child_agent_id,
            model=self._model,
            skills=self._skills.clone_for_child(),
            artifacts=child_artifacts,
            routes=child_routes,
            closure_evaluator=None,
            event_log_path=child_root / "events.jsonl",
            observations=child_observations,
            code_artifacts=child_code_artifacts,
            development_projects=self._development_projects,
            state_path=child_root / "agent-state.json",
            role_instructions="",
            memory_compact_after_chars=self._memory.compact_after_chars,
            prompt_budget_bytes=self._memory.prompt_budget_bytes,
            max_rounds=self._max_rounds,
            mission=mission,
            mission_workspace=mission_workspace,
            child_depth=self._child_depth + 1,
            max_child_depth=self._max_child_depth,
            human_in_loop_enabled=self._human_in_loop_enabled,
            task_formulation_skill_id=self._task_formulation_skill_id,
            workspace_excluded_relative_paths=(
                mission_workspace.path_policy.excluded_relative_paths
            ),
        )

    def _recover_paused_child_from_disk(self) -> None:
        if self._paused_child is not None:
            return
        open_spawns: dict[str, Mapping[str, Any]] = {}
        for event in self._events.read():
            event_type = str(event.get("event_type") or "")
            child_id = str(event.get("child_id") or "")
            if not child_id:
                continue
            if event_type == "child_spawned":
                open_spawns[child_id] = event
            elif event_type == "child_returned":
                open_spawns.pop(child_id, None)
        recoverable: list[tuple[str, Mapping[str, Any]]] = []
        for child_id, event in open_spawns.items():
            state_path = (
                self._event_log_path.parent
                / "children"
                / child_id
                / "agent-state.json"
            )
            if not state_path.is_file():
                continue
            from .memory_lifecycle.state import AgentStateStore

            interaction = AgentStateStore(state_path).read()["c1"][
                "human_interaction_state"
            ]
            if interaction["status"] in {"pending", "answered"}:
                recoverable.append((child_id, event))
        if not recoverable:
            return
        if len(recoverable) != 1:
            raise RuntimeError("multiple_paused_children_recovery_forbidden")
        child_id, event = recoverable[0]
        mission = _mission_from_spawn_event(event)
        child = self._build_child_runtime(child_id=child_id, mission=mission)
        self._quarantine_child_outputs(child)
        child_rounds = max(
            (
                int(item.get("round") or 0)
                for item in child._events.read()
            ),
            default=0,
        )
        self._paused_child = {
            "child_id": child_id,
            "child": child,
            "mission": mission,
            "rounds": child_rounds,
        }
        pending = child.pending_human_interaction()
        current = child._sub_loop_toolkit.current()
        self._events.append(
            "child_human_pause_recovered",
            {
                "child_id": child_id,
                "child_agent_id": child.agent_id,
                "request_id": str(
                    (pending or current or {}).get("request_id") or ""
                ),
            },
        )

    def _paused_child_runtime(self) -> Any | None:
        paused = self._paused_child
        return paused["child"] if paused is not None else None

    def _resume_paused_child_if_ready(self) -> Mapping[str, Any] | None:
        paused = self._paused_child
        if paused is None:
            return None
        child = paused["child"]
        if child.pending_human_interaction() is not None:
            raise HumanInteractionPause()
        mission = paused["mission"]
        result = child.run(
            objective=mission.objective,
            evaluation_summary=mission.evaluation_summary,
        )
        total_rounds = int(paused["rounds"]) + int(result.rounds)
        if result.status == "paused_for_human":
            paused["rounds"] = total_rounds
            self._quarantine_child_outputs(child)
            raise HumanInteractionPause()
        child_id = str(paused["child_id"])
        self._paused_child = None
        return self._finalize_child_return(
            child_id=child_id,
            child=child,
            mission=mission,
            result=result,
            rounds=total_rounds,
        )

    def _hold_paused_child(
        self,
        *,
        child_id: str,
        child: Any,
        mission: ChildMission,
        rounds: int,
    ) -> None:
        if self._paused_child is not None:
            raise RuntimeError("only_one_paused_child_is_supported")
        self._quarantine_child_outputs(child)
        self._paused_child = {
            "child_id": child_id,
            "child": child,
            "mission": mission,
            "rounds": int(rounds),
        }
        pending = child.pending_human_interaction()
        self._events.append(
            "child_paused_for_human",
            {
                "child_id": child_id,
                "child_agent_id": child.agent_id,
                "request_id": (
                    str(pending["request_id"]) if pending is not None else ""
                ),
            },
        )

    def _quarantine_child_outputs(self, child: Any) -> tuple[str, ...]:
        refs = _child_mission_output_refs(child)
        return self._artifacts.quarantine_refs(refs)

    def _finalize_child_return(
        self,
        *,
        child_id: str,
        child: Any,
        mission: ChildMission,
        result: Any,
        rounds: int,
    ) -> Mapping[str, Any]:
        artifact_refs = list(_child_mission_output_refs(child))
        self._artifacts.quarantine_refs(artifact_refs)
        self._mounted_external_refs.update(child._owned_external_refs)
        work_entry_refs = self._import_child_work(child.agent_id)
        record = {
            "child_id": child_id,
            "child_agent_id": child.agent_id,
            "depth": child._child_depth,
            "status": result.status,
            "rounds": int(rounds),
            "final_text": result.final_text,
            "closure": dict(result.closure),
            "artifact_refs": artifact_refs,
            "work_entry_refs": list(work_entry_refs),
            "review": None,
        }
        try:
            parent_loop = self._state.read()["c1"]["node_loop_state"]
        except (OSError, RuntimeError, ValueError):
            parent_loop = {}
        node_id = str(parent_loop.get("node_id") or "").strip()
        attempt_index = int(parent_loop.get("attempt_index") or 0)
        if node_id and attempt_index > 0:
            record["operational_handoff"] = build_node_attempt_handoff(
                node_id=node_id,
                attempt_index=attempt_index,
                executor="child",
                child_id=child_id,
                status=str(result.status),
                formal_result_refs=artifact_refs,
                work_context_ref=child._state.read()["c1"]["active_work_context_ref"],
                operational_refs=tuple(
                    ref for ref in child._state.read()["c1"]["resolved_artifact_refs"]
                    if ref.startswith("execution_observation:")
                ),
            )
        record["review_packet"] = self._build_child_review_packet(
            mission=mission,
            record=record,
        )
        self._children[child_id] = record
        self._events.append(
            "child_returned",
            {
                "child_id": child_id,
                "child_agent_id": child.agent_id,
                "depth": child._child_depth,
                "status": result.status,
                "rounds": int(rounds),
                "artifact_refs": artifact_refs,
                "closure": dict(result.closure),
                "review_packet": record["review_packet"],
                "work_entry_refs": list(work_entry_refs),
            },
        )
        handoff = record.get("operational_handoff")
        if isinstance(handoff, Mapping):
            self._events.append("node_attempt_handoff", dict(handoff))
            self._mounted_external_refs.update(handoff.get("operational_refs") or ())
        returned = copy.deepcopy(record)
        returned.pop("operational_handoff", None)
        return returned

    def review_child(
        self,
        child_id: str,
        *,
        decision: str,
        accepted_artifact_refs: Sequence[str] = (),
    ) -> Mapping[str, Any]:
        """Mount only parent-selected child outputs after review."""
        safe_id = slug_child_id(child_id)
        record = self._children.get(safe_id)
        if record is None:
            raise KeyError(f"unknown_child_id:{safe_id}")
        normalized = str(decision).strip().lower()
        if normalized not in {"accept", "reject"}:
            raise ValueError("child_review_decision_must_be_accept_or_reject")
        refs = tuple(
            str(ref).strip()
            for ref in accepted_artifact_refs
            if str(ref).strip()
        )
        if normalized == "accept":
            allowed = set(record["artifact_refs"])
            if not refs or not set(refs).issubset(allowed):
                raise ValueError(
                    "child_review_refs_must_be_nonempty_subset_of_child_output"
                )
            refs = self._child_owned_dependency_closure(record, refs)
            self._artifacts.unquarantine_refs(refs)
            self._artifacts.mount_refs(refs)
            for ref in refs:
                self._state.add_resolved_artifact_ref(ref)
            # Review changes source visibility, not the immutable child notes.
            # Import newly readable entries only after their C2 sources are accepted.
            record["work_entry_refs"] = list(self._import_child_work(record["child_agent_id"]))
        self._review_only_artifact = None
        self._inspected_pending_child_refs.clear()
        record["review"] = {
            "decision": normalized,
            "accepted_artifact_refs": list(refs),
        }
        self._events.append(
            "child_reviewed",
            {"child_id": safe_id, **record["review"]},
        )
        return copy.deepcopy(record["review"])

    def _child_operational_handoff(
        self,
        child_id: str,
    ) -> Mapping[str, Any] | None:
        record = self._children.get(slug_child_id(child_id))
        if record is None:
            return None
        handoff = record.get("operational_handoff")
        return copy.deepcopy(dict(handoff)) if isinstance(handoff, Mapping) else None

    def _pending_child_artifact_refs(self) -> set[str]:
        refs: set[str] = set()
        for record in self._children.values():
            if record.get("review") is not None:
                continue
            refs.update(str(ref) for ref in record.get("artifact_refs", ()))
        return refs

    def _pending_child_terminal_artifact_refs(self) -> set[str]:
        """Return review roots, falling back to all outputs for malformed packets."""
        refs: set[str] = set()
        for record in self._children.values():
            if record.get("review") is not None:
                continue
            packet = record.get("review_packet")
            if not isinstance(packet, Mapping):
                continue
            summaries = packet.get("artifact_summaries")
            if not isinstance(summaries, Sequence) or isinstance(
                summaries, (str, bytes)
            ):
                continue
            for summary in summaries:
                if not isinstance(summary, Mapping) or not bool(
                    summary.get("terminal_candidate")
                ):
                    continue
                ref = str(summary.get("artifact_ref") or "").strip()
                if ref:
                    refs.add(ref)
        return refs or self._pending_child_artifact_refs()

    def _is_pending_child_artifact(self, artifact_ref: str) -> bool:
        return str(artifact_ref).strip() in self._pending_child_artifact_refs()

    def _pending_child_review_packets(self) -> list[dict[str, Any]]:
        """Return bounded review packets without exposing child runtime state."""
        packets: list[dict[str, Any]] = []
        for child_id, record in self._children.items():
            if record.get("review") is not None:
                continue
            packet = record.get("review_packet")
            if not isinstance(packet, Mapping):
                continue
            packets.append(
                {
                    "child_id": child_id,
                    "review_packet": copy.deepcopy(dict(packet)),
                }
            )
        return packets

    def _child_owned_dependency_closure(
        self,
        record: Mapping[str, Any],
        terminal_refs: Sequence[str],
    ) -> tuple[str, ...]:
        """Expand accepted roots through child-owned formal dependencies only."""
        allowed = {
            str(ref).strip()
            for ref in record.get("artifact_refs", ())
            if str(ref).strip()
        }
        closure: list[str] = []
        pending = [str(ref).strip() for ref in terminal_refs if str(ref).strip()]
        while pending:
            ref = pending.pop(0)
            if ref in closure:
                continue
            if ref not in allowed:
                raise ValueError(
                    f"child_dependency_closure_left_child_outputs:{ref}"
                )
            artifact = self._artifact_store.read(ref)
            closure.append(ref)
            for dependency_ref in artifact.get("depends_on", ()):
                dependency = str(dependency_ref).strip()
                if dependency in allowed and dependency not in closure:
                    pending.append(dependency)
        return tuple(closure)

    def _build_child_review_packet(
        self,
        *,
        mission: ChildMission,
        record: Mapping[str, Any],
    ) -> dict[str, Any]:
        child_refs = {
            str(ref) for ref in record.get("artifact_refs", ()) if str(ref)
        }
        depended_on_by_child: set[str] = set()
        for ref in child_refs:
            try:
                stored = self._artifact_store.read(ref)
            except (KeyError, OSError, ValueError):
                continue
            depended_on_by_child.update(
                str(dependency)
                for dependency in stored.get("depends_on", ())
                if str(dependency) in child_refs
            )
        artifact_summaries: list[dict[str, Any]] = []
        for raw_ref in record.get("artifact_refs", ()):
            ref = str(raw_ref)
            try:
                stored = self._artifact_store.read(ref)
            except (KeyError, OSError, ValueError):
                artifact_summaries.append(
                    {
                        "artifact_ref": ref,
                        "status": "unreadable",
                    }
                )
                continue
            artifact_summaries.append(
                {
                    "artifact_ref": ref,
                    "artifact_kind": stored.get("artifact_kind"),
                    "status": stored.get("status"),
                    "title": stored.get("title"),
                    "summary": bounded_text(
                        str(stored.get("summary") or ""),
                        1_000,
                    ),
                    "depends_on": list(stored.get("depends_on", ())),
                    "producer_agent_id": stored.get("producer_agent_id"),
                    "terminal_candidate": ref not in depended_on_by_child,
                }
            )
        return {
            "objective": mission.objective,
            "evaluation_summary": mission.evaluation_summary,
            "child_status": record.get("status"),
            "child_final_text": bounded_text(
                str(record.get("final_text") or ""),
                2_000,
            ),
            "child_closure": bounded_projection(
                record.get("closure") or {},
                max_depth=4,
                max_items=8,
            ),
            "artifact_summaries": artifact_summaries,
            "review_rule": (
                "Inspect pending refs only for review. Select exact terminal roots "
                "that are valid, relevant, and useful even when the child did not "
                "fulfill the whole mission; runtime releases their child-owned "
                "dependency closure only after review_child_result accepts them. "
                "Acceptance admits evidence and does not itself complete the parent "
                "Graph node."
            ),
        }


def _mission_from_spawn_event(event: Mapping[str, Any]) -> ChildMission:
    projection = event.get("mission")
    if not isinstance(projection, Mapping):
        raise RuntimeError("paused_child_mission_projection_missing")
    workspace = projection.get("workspace")
    if not isinstance(workspace, Mapping):
        raise RuntimeError("paused_child_workspace_projection_missing")
    mode = str(workspace.get("mode") or "")
    workspace_refs: tuple[str, ...] = ()
    if mode == "allowlist":
        raw_refs = workspace.get("refs") or ()
        if not isinstance(raw_refs, Sequence) or isinstance(
            raw_refs, (str, bytes)
        ):
            raise RuntimeError("paused_child_workspace_refs_invalid")
        workspace_refs = tuple(
            str(item.get("ref") or "")
            for item in raw_refs
            if isinstance(item, Mapping) and str(item.get("ref") or "")
        )
    root_value = str(workspace.get("root") or "").strip()
    default_root = Path(root_value) if root_value else Path.cwd()
    return ChildMission.from_payload(
        {
            "objective": str(projection.get("objective") or ""),
            "evaluation_summary": str(
                projection.get("evaluation_summary") or ""
            ),
            "enabled_meta_capabilities": list(
                projection.get("enabled_meta_capabilities") or ()
            ),
            "mission_context": copy.deepcopy(
                dict(projection.get("mission_context") or {})
            ),
            "artifact_refs": list(projection.get("mounted_refs") or ()),
            "work_entry_refs": list(projection.get("work_entry_refs") or ()),
            "workspace_refs": list(workspace_refs),
            "workspace_root": root_value,
            "allow_workspace_discovery": mode == "discovery",
        },
        default_root=default_root,
    )


def _source_explorer(routes: RouteRegistry) -> SourceExplorer | None:
    return next((
        owner for route in routes.all()
        if route.name in _WORKSPACE_SOURCE_ROUTE_NAMES
        and isinstance(owner := getattr(route.handler, "__self__", None), SourceExplorer)
    ), None)


def _mission_scoped_route_registry(
    parent_routes: RouteRegistry,
    *,
    workspace: ResolvedMissionWorkspace,
) -> RouteRegistry:
    """Rebind workspace source routes to the exact child mission snapshot."""
    registered = parent_routes.all()
    source_routes = tuple(
        route for route in registered if route.name in _WORKSPACE_SOURCE_ROUTE_NAMES
    )
    if not source_routes:
        return parent_routes

    parent_explorer = _source_explorer(parent_routes)
    if parent_explorer is None:
        raise RuntimeError("child_workspace_source_routes_not_rebindable")

    source_root = (
        workspace.root
        if workspace.root is not None and workspace.root.is_dir()
        else parent_explorer.source_root.resolve()
    )
    explorer = SourceExplorer(
        source_root=source_root,
        workspace_root=parent_explorer.workspace_root,
        allowed_relative_paths=workspace.allowed_relative_paths,
        python_executable=parent_explorer.python_executable,
        path_policy=workspace.path_policy,
    )
    owner_ids = tuple(
        dict.fromkeys(
            skill_id
            for route in source_routes
            for skill_id in route.skill_ids
        )
    )
    generated = {
        route.name: route
        for route in explorer.routes(
            skill_ids=owner_ids or ("__mission_workspace__",)
        )
    }
    replacements = {
        route.name: replace(generated[route.name], skill_ids=route.skill_ids)
        for route in source_routes
    }
    return RouteRegistry(
        [
            replacements.get(route.name, route)
            for route in registered
        ]
    )


def _child_mission_output_refs(child: Any) -> tuple[str, ...]:
    """Exclude child-local control records from the parent review surface."""
    internal_kinds = {
        "agent_evaluation_gate",
        "task_spec",
        GRAPH_REVISION_OUTCOME_KIND,
    }
    return tuple(
        ref
        for ref in child._artifacts.owned_refs()
        if child._artifact_store.read(ref).get("artifact_kind")
        not in internal_kinds
    )
