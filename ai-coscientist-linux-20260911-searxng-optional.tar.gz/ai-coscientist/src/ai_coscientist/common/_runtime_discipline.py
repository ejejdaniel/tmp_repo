from __future__ import annotations

import json
from typing import Any, Mapping, Sequence

from ._runtime_support import canonical_tool_arguments as _canonical_tool_arguments
from .memory_lifecycle.prompt import FOCUSED_C4_SOURCE_PREFIX
from .model import ToolCall


class TransitionDisciplineMixin:
    """Validate transitions and avoid rereading exact bodies still in the prompt."""

    def _validate_transition(
        self,
        call: ToolCall,
        *,
        round_number: int,
        internal_readback: bool = False,
    ) -> None:
        no_progress_reason = (
            "" if internal_readback else self._no_progress_call_reason(call)
        )
        if no_progress_reason:
            raise RuntimeError(no_progress_reason)
        pending = self._pending_readback_ref()
        if pending:
            if (
                call.name not in {"read_ref", "artifact_read"}
                or str(
                    call.arguments.get("ref")
                    or call.arguments.get("artifact_ref")
                    or ""
                ) != pending
            ):
                raise RuntimeError(
                    "stored_output_readback_required: call read_ref with "
                    f"exact ref {pending} before any other tool"
                )
        if internal_readback:
            return
        if call.name == "work_memory_list" or (
            call.name == "read_ref" and str(call.arguments.get("ref") or "").startswith(
                ("work_context:", "work_entry:")
            )
        ):
            return
        active_skill_id = str(
            self._state.read()["c1"]["active_skill_id"] or ""
        )
        if call.name in {
            "execute_node_locally",
            "spawn_child",
            "review_child_result",
        }:
            return
        if call.name in {
            "load_skill",
            "follow_graph_transition",
            "report_no_matching_transition",
            "restart_node_attempt",
            "request_human_input",
        }:
            return
        if (
            call.name in {"read_ref", "artifact_read"}
            and self._is_pending_child_artifact(
                str(
                    call.arguments.get("ref")
                    or call.arguments.get("artifact_ref")
                    or ""
                )
            )
        ):
            return
        if active_skill_id and self._skills.has_disclosure(active_skill_id):
            self._skills.validate_disclosed_tool_call(
                active_skill_id,
                call.name,
                call.arguments,
                self._selected_skill_disclosure_context(active_skill_id),
            )

    def _no_progress_call_reason(self, call: ToolCall) -> str:
        # Failure history is not current execution state; retries use normal
        # validation and the existing step-call budget.
        return self._immediate_repeated_read_reason(call)

    def _immediate_repeated_read_reason(self, call: ToolCall) -> str:
        """Reject a repeated read only while its prior body is still visible."""
        if call.name not in {
            "read_ref",
            "artifact_read",
            "development_project_read",
        }:
            return ""
        signature = _tool_call_signature(call.name, call.arguments)
        events = self._events.read()
        current_turn = _model_turn_for_call(events, call.call_id)
        if current_turn is None:
            return ""
        current_sequence = int(current_turn.get("event_sequence", 0))
        prompt_messages = _prompt_messages_before(events, current_sequence)
        if prompt_messages is None:
            return ""
        boundary_sequence = self._read_history_boundary(events)
        for event in reversed(events):
            if int(event.get("event_sequence", 0)) >= current_sequence:
                continue
            if int(event.get("event_sequence", 0)) <= boundary_sequence:
                break
            if event.get("event_type") != "tool_result":
                continue
            executed_arguments = event.get("executed_arguments")
            if not isinstance(executed_arguments, Mapping):
                continue
            prior_signature = _tool_call_signature(
                str(event.get("tool") or ""),
                executed_arguments,
            )
            if prior_signature != signature:
                continue
            raw_result = event.get("raw_result")
            if (
                not isinstance(raw_result, Mapping)
                or raw_result.get("status") == "tool_error"
            ):
                continue
            requested_ref = str(
                call.arguments.get("ref")
                or call.arguments.get("artifact_ref")
                or ""
            )
            if requested_ref.startswith("development_output:") and self._development_projects is not None:
                # Terminal streams can grow after a previously visible read.
                try:
                    current_page = self._development_projects.read_output(
                        requested_ref,
                        line_offset=int(call.arguments.get("line_offset", 0)),
                        line_limit=int(call.arguments.get("line_limit", 200)),
                    )
                except (OSError, ValueError, RuntimeError):
                    return ""
                if current_page != raw_result:
                    return ""
            if call.name == "development_project_read":
                # A mutable file or retained execution log can change while an
                # older page remains in the prompt. Compare bytes, not location.
                try:
                    current_page = self._routes.execute(
                        call.name, call.arguments,
                        skill_id=self._state.read()["c1"]["active_skill_id"],
                    )
                except (KeyError, OSError, ValueError, RuntimeError):
                    return ""
                if current_page != raw_result:
                    return ""
            if not _read_body_visible_in_prompt(
                prompt_messages,
                prior_call_id=str(event.get("call_id") or ""),
                requested_ref=requested_ref,
                expected_result=raw_result,
            ):
                return ""
            return (
                "repeated_successful_read_requires_changed_action:"
                f"tool={call.name}:"
                "the_same_exact_read_body_is_still_visible_in_the_current_prompt:"
                "use_the_visible_stored_content_choose_another_action_or_return_"
                "the_bounded_skill_handoff"
            )
        return ""

    def _read_refs_available_for_prompt(
        self,
        refs: Sequence[str],
        prompt_messages: Sequence[Mapping[str, Any]],
    ) -> tuple[str, ...]:
        """Hide exact reads whose successful result is still in this prompt."""
        exact_prefixes = (
            "artifact:",
            "code_artifact:",
            "execution_observation:",
        )
        events = self._events.read()
        boundary_sequence = self._read_history_boundary(events)
        available: list[str] = []
        for ref in refs:
            if ref.startswith("reference:v1:"):
                if any(
                    ref in str(message.get("content") or "")
                    for message in prompt_messages
                ):
                    available.append(ref)
                continue
            if not ref.startswith(exact_prefixes):
                available.append(ref)
                continue
            prior_body_visible = False
            for event in reversed(events):
                if int(event.get("event_sequence", 0)) <= boundary_sequence:
                    break
                if event.get("event_type") != "tool_result":
                    continue
                if event.get("tool") not in {"read_ref", "artifact_read"}:
                    continue
                executed_arguments = event.get("executed_arguments")
                if not isinstance(executed_arguments, Mapping):
                    continue
                requested_ref = str(
                    executed_arguments.get("ref")
                    or executed_arguments.get("artifact_ref")
                    or ""
                )
                if requested_ref != ref:
                    continue
                raw_result = event.get("raw_result")
                if (
                    not isinstance(raw_result, Mapping)
                    or raw_result.get("status") == "tool_error"
                ):
                    continue
                prior_body_visible = _read_body_visible_in_prompt(
                    prompt_messages,
                    prior_call_id=str(event.get("call_id") or ""),
                    requested_ref=ref,
                    expected_result=raw_result,
                )
                break
            if not prior_body_visible:
                available.append(ref)
        return tuple(available)

    def _read_history_boundary(
        self,
        events: list[Mapping[str, object]],
    ) -> int:
        """Limit exact-read suppression to the current invocation."""
        active_skill_id = str(
            self._state.read()["c1"]["active_skill_id"] or ""
        )
        for event in reversed(events):
            sequence = int(event.get("event_sequence", 0))
            if active_skill_id:
                if (
                    event.get("event_type") != "tool_result"
                    or event.get("tool") != "load_skill"
                ):
                    continue
                result = event.get("raw_result")
                if (
                    isinstance(result, Mapping)
                    and result.get("status") == "skill_loaded"
                    and str(result.get("skill_id") or "") == active_skill_id
                ):
                    return sequence
                continue
            if event.get("event_type") in {
                "initial_plan_created",
                "graph_rebuilt",
                "graph_transition_followed",
                "plan_progress_applied",
                "skill_context_released",
                "node_loop_attempt_started",
                "node_loop_attempt_restarted",
            }:
                return sequence
        return 0


def _tool_call_signature(
    tool_name: str,
    arguments: Any,
) -> tuple[str, str]:
    """Canonicalize mechanically equivalent calls before loop detection."""
    normalized = dict(arguments) if isinstance(arguments, Mapping) else {}
    if tool_name == "source_inventory":
        relative_path = (
            str(normalized.get("relative_path") or "")
            .strip()
            .replace("\\", "/")
            .strip("/")
        )
        if relative_path in {"", "."}:
            normalized.pop("relative_path", None)
        else:
            normalized["relative_path"] = relative_path
    return tool_name, _canonical_tool_arguments(normalized)


def _model_turn_for_call(
    events: Sequence[Mapping[str, Any]],
    call_id: str,
) -> Mapping[str, Any] | None:
    target = str(call_id or "")
    if not target:
        return None
    for event in reversed(events):
        if event.get("event_type") != "model_turn":
            continue
        tool_calls = event.get("tool_calls")
        if not isinstance(tool_calls, Sequence) or isinstance(
            tool_calls, (str, bytes, bytearray)
        ):
            continue
        if any(
            isinstance(item, Mapping)
            and str(item.get("call_id") or "") == target
            for item in tool_calls
        ):
            return event
    return None


def _prompt_messages_before(
    events: Sequence[Mapping[str, Any]],
    model_turn_sequence: int,
) -> tuple[Mapping[str, Any], ...] | None:
    for event in reversed(events):
        if int(event.get("event_sequence", 0)) >= model_turn_sequence:
            continue
        if event.get("event_type") != "prompt_snapshot":
            continue
        messages = event.get("messages")
        if not isinstance(messages, Sequence) or isinstance(
            messages, (str, bytes, bytearray)
        ):
            return None
        if not all(isinstance(message, Mapping) for message in messages):
            return None
        return tuple(messages)
    return None


def _read_body_visible_in_prompt(
    messages: Sequence[Mapping[str, Any]],
    *,
    prior_call_id: str,
    requested_ref: str,
    expected_result: Mapping[str, Any] | None = None,
) -> bool:
    for message in messages:
        if (
            prior_call_id
            and message.get("role") == "tool"
            and str(message.get("tool_call_id") or "") == prior_call_id
        ):
            content = str(message.get("content") or "")
            try:
                tool_result = json.loads(content)
            except json.JSONDecodeError:
                tool_result = None
            if (
                isinstance(tool_result, Mapping)
                and isinstance(tool_result.get("content"), str)
                and isinstance(expected_result, Mapping)
                and all(
                    tool_result.get(key) == expected_result.get(key)
                    for key in ("content", "line_offset", "line_count", "next_line_offset")
                )
            ):
                return True
        content = str(message.get("content") or "")
        if (
            requested_ref
            and content.startswith(FOCUSED_C4_SOURCE_PREFIX)
            and f"artifact_ref: {requested_ref}\n" in content
        ):
            return True
        if message.get("role") != "user" or not content.startswith("{"):
            continue
        try:
            payload = json.loads(content)
        except json.JSONDecodeError:
            continue
        if not isinstance(payload, Mapping):
            continue
        projections = payload.get("resolved_inputs_for_active_skill")
        if not isinstance(projections, Sequence) or isinstance(
            projections, (str, bytes, bytearray)
        ):
            continue
        for projection in projections:
            if not isinstance(projection, Mapping):
                continue
            projection_ref = str(
                projection.get("artifact_ref")
                or projection.get("code_artifact_ref")
                or projection.get("observation_ref")
                or ""
            )
            if (
                projection_ref == requested_ref
                and projection.get("prompt_projection")
                == "exact_or_bounded_content"
            ):
                return True
    return False
