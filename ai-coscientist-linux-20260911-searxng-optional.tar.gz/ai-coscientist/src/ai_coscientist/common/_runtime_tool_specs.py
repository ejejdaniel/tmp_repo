from __future__ import annotations

from typing import Any, Sequence

from ._runtime_support import function_tool


def read_ref_tool(
    visible_refs: Sequence[str], *, description: str | None = None,
) -> dict[str, Any]:
    return function_tool(
        "read_ref",
        description or (
            "Read one exact ref. Formal, code, and execution refs resolve "
            "their stored content. Source, probe-output, and terminal-output "
            "refs resolve one bounded line page; use line_offset to continue. "
            "Ref namespace selects the storage authority mechanically."
        ),
        {
            "type": "object",
            "properties": {
                "ref": {
                    "type": "string",
                    "enum": list(visible_refs),
                    "description": (
                        "Exact artifact:, code_artifact:, execution_observation:, "
                        "source_file:, source_probe:, workspace_terminal:, or "
                        "development_output: ref, or an exact reference:v1: link, "
                        "enumerated from the current visible prompt. Links retain "
                        "the underlying source permissions."
                    ),
                },
                "line_offset": {
                    "type": "integer", "minimum": 0,
                    "description": "Source/output refs or reference links; zero-based offset within selected content.",
                },
                "line_limit": {
                    "type": "integer", "minimum": 1, "maximum": 2000,
                    "description": "Source/output refs or reference links; bounded page size.",
                },
            },
            "required": ["ref"],
            "additionalProperties": False,
        },
    )


def execute_node_locally_tool() -> dict[str, Any]:
    return function_tool(
        "execute_node_locally",
        (
            "Execute the whole active Graph node in this agent. Runtime will "
            "create one bounded node-local LOOP and mechanically load its planned "
            "skills. This action does not select a skill itself. Optionally resume an "
            "owned work_context_ref from work_memory_list; omitted means new work. "
            "A retry of the same node retains its bound work and obtains fresh action quota."
        ),
        {
            "type": "object",
            "properties": {"work_context_ref": {"type": "string", "minLength": 1}},
            "additionalProperties": False,
        },
    )


def spawn_child_tool(
    enabled_meta_capabilities: Sequence[str] = (),
) -> dict[str, Any]:
    properties: dict[str, Any] = {
        "child_id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 80,
            "description": "Stable id used to review this child result.",
        },
        "objective": {
            "type": "string",
            "minLength": 1,
            "description": (
                "Copy active_work_unit.outcome verbatim. Runtime binds "
                "the child to that Graph-node result. It is not a skill, "
                "route, tool, or parent LOOP step."
            ),
        },
        "evaluation_summary": {
            "type": "string",
            "minLength": 1,
            "description": (
                "Copy active_work_unit.completion_condition verbatim. "
                "Runtime binds the child to that node-local condition. "
                "It must be judgeable before the child returns and must "
                "not require later parent or successor consumption."
            ),
        },
        "mission_context": {
            "type": "object",
            "description": (
                "Only context the child needs for its own mission; do not "
                "copy parent runtime state or prescribe a skill, route, "
                "tool, or parent LOOP step."
            ),
        },
        "artifact_refs": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Exact formal, code, or observation refs to mount.",
        },
        "work_entry_refs": {
            "type": "array", "items": {"type": "string"}, "uniqueItems": True,
            "description": "Explicit immutable work_entry refs to share. No whole parent memory "
                           "or future entries are inherited; source refs must also be authorized.",
        },
        "workspace_refs": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Exact task-source file or directory paths to mount; resolved against the current source routes' root, not the code project root.",
        },
        "allow_workspace_discovery": {
            "type": "boolean",
            "description": (
                "When true, let the child discover within the current task source "
                "scope; this does not broaden a parent allowlist. Runtime/private "
                "files remain excluded."
            ),
        },
    }
    allowed_meta_capabilities = list(
        dict.fromkeys(
            str(item).strip()
            for item in enabled_meta_capabilities
            if str(item).strip()
        )
    )
    if allowed_meta_capabilities:
        properties["enabled_meta_capabilities"] = {
            "type": "array",
            "items": {
                "type": "string",
                "enum": allowed_meta_capabilities,
            },
            "uniqueItems": True,
            "description": (
                "Optional explicit subset of the parent C0 meta authorities. "
                "It defaults to empty and never inherits."
            ),
        }
    return function_tool(
        "spawn_child",
        (
            "Delegate the whole active Graph node to one white-room common-agent "
            "child. Repeat the active node outcome and completion condition "
            "verbatim; runtime keeps the Graph node as mission authority. "
            "The child builds its own Graph and LOOP; it never executes one parent "
            "skill or one parent LOOP step. It receives only the supplied mission "
            "context, exact refs, and task workspace discovery when enabled; it "
            "does not inherit parent prompt or memory."
        ),
        {
            "type": "object",
            "properties": properties,
            "required": ["child_id", "objective", "evaluation_summary"],
            "additionalProperties": False,
        },
    )


def review_child_result_tool() -> dict[str, Any]:
    return function_tool(
        "review_child_result",
        (
            "Review one returned child result at the parent boundary. Accept only "
            "the exact child artifact refs that should enter this agent's formal "
            "dataflow, including useful partial results from an unfinished child. "
            "Acceptance is evidence admission, not proof that the parent Graph "
            "node is complete; reject only when no returned result is usable."
        ),
        {
            "type": "object",
            "properties": {
                "child_id": {
                    "type": "string",
                    "minLength": 1,
                    "description": "The id supplied when the child was spawned.",
                },
                "decision": {
                    "type": "string",
                    "enum": ["accept", "reject"],
                },
                "accepted_artifact_refs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Exact terminal child result roots to accept. Runtime also "
                        "mounts their child-owned depends_on closure. Leave empty "
                        "when rejecting."
                    ),
                },
            },
            "required": ["child_id", "decision"],
            "additionalProperties": False,
        },
    )
