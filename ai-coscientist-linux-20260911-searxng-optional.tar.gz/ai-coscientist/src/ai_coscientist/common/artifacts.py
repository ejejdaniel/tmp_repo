from __future__ import annotations

import copy
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence


ArtifactPayloadValidator = Callable[[Any], None]
ArtifactPayloadSchema = Mapping[str, Any]


class ArtifactStore:
    """Immutable formal artifacts addressed by exact refs."""

    def __init__(
        self,
        root: Path,
        *,
        agent_id: str,
        run_id: str,
        payload_validators: Mapping[str, ArtifactPayloadValidator] | None = None,
        payload_schemas: Mapping[str, ArtifactPayloadSchema] | None = None,
    ) -> None:
        self._root = root.resolve()
        self._agent_id = _slug(agent_id)
        self._run_id = run_id
        self._payload_validators = dict(payload_validators or {})
        self._payload_schemas = copy.deepcopy(dict(payload_schemas or {}))
        self._artifact_dir = self._root / "artifacts"
        self._index_path = self._root / "artifact-index.json"
        self._index_cache: dict[str, Any] = {}
        self._index_signature: tuple[int, int] | None = None
        self._artifact_cache: dict[str, dict[str, Any]] = {}
        self._latest_by_artifact_id: dict[str, str] = {}
        self._artifact_dir.mkdir(parents=True, exist_ok=True)
        if not self._index_path.exists():
            self._write_json(self._index_path, {"order": [], "entries": {}})
        self._reload_index()

    def publish(
        self,
        *,
        artifact_kind: str,
        title: str,
        markdown: str,
        machine_payload: Mapping[str, Any],
        artifact_id: str | None = None,
        status: str = "proposed",
        summary: str = "",
        depends_on: Sequence[str] = (),
        trace_refs: Sequence[str] = (),
        self_review: Mapping[str, Any] | None = None,
        verified_external_dependencies: Sequence[str] = (),
    ) -> dict[str, Any]:
        index = self._read_index()
        verified_external = set(verified_external_dependencies)
        missing = [
            ref
            for ref in depends_on
            if ref not in index["entries"] and ref not in verified_external
        ]
        if missing:
            raise KeyError(f"unknown_artifact_dependencies:{missing}")

        self.validate_payload(
            artifact_kind=artifact_kind,
            machine_payload=machine_payload,
        )

        stable_id = _slug(artifact_id or title or artifact_kind)
        canonical = {
            "artifact_id": stable_id,
            "artifact_kind": artifact_kind,
            "title": title,
            "markdown": markdown,
            "status": status,
            "summary": summary,
            "depends_on": list(depends_on),
            "trace_refs": list(trace_refs),
            "self_review": dict(self_review or {}),
            "machine_payload": dict(machine_payload),
        }
        digest = hashlib.sha256(
            json.dumps(canonical, ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()[:10]
        artifact_ref = f"artifact:{self._agent_id}:{stable_id}-{digest}"
        if artifact_ref in index["entries"]:
            return _public_receipt(index["entries"][artifact_ref])

        envelope = {
            "artifact_ref": artifact_ref,
            "producer_agent_id": self._agent_id,
            "mission_id": self._run_id,
            **canonical,
        }
        # Multiple agents share one runtime artifact directory. The producer
        # is part of artifact identity, so it must also namespace the backing
        # file; otherwise identical canonical content from parent and child
        # agents overwrites one envelope with another agent's artifact_ref.
        artifact_path = self._artifact_dir / f"{self._agent_id}-{digest}.json"
        self._write_json(artifact_path, envelope)
        receipt = {
            "artifact_ref": artifact_ref,
            "artifact_id": stable_id,
            "artifact_kind": artifact_kind,
            "status": status,
            "summary": summary,
            "depends_on": list(depends_on),
            "storage_path": str(artifact_path),
        }
        index["order"].append(artifact_ref)
        index["entries"][artifact_ref] = receipt
        self._write_index(index)
        self._artifact_cache[artifact_ref] = copy.deepcopy(envelope)
        return _public_receipt(receipt)

    def list(self) -> tuple[dict[str, Any], ...]:
        index = self._read_index()
        return tuple(_public_receipt(index["entries"][ref]) for ref in index["order"])

    def active_receipts(
        self,
        *,
        explicit_refs: Sequence[str] = (),
    ) -> tuple[dict[str, Any], ...]:
        """Return current C2 revisions and their exact dependency closure."""
        index = self._read_index()
        entries = index["entries"]
        active_refs = set(self._latest_by_artifact_id.values())
        active_refs.update(ref for ref in explicit_refs if ref in entries)
        pending = list(active_refs)
        while pending:
            artifact_ref = pending.pop()
            entry = entries.get(artifact_ref)
            if not isinstance(entry, Mapping):
                continue
            for raw_dependency in entry.get("depends_on") or ():
                dependency = str(raw_dependency)
                if dependency in entries and dependency not in active_refs:
                    active_refs.add(dependency)
                    pending.append(dependency)
        return tuple(
            _public_receipt(entries[ref])
            for ref in index["order"]
            if ref in active_refs
        )

    @property
    def root(self) -> Path:
        return self._root

    @property
    def payload_validators(self) -> Mapping[str, ArtifactPayloadValidator]:
        return dict(self._payload_validators)

    @property
    def payload_schemas(self) -> Mapping[str, ArtifactPayloadSchema]:
        return copy.deepcopy(self._payload_schemas)

    def payload_schema(self, artifact_kind: str) -> dict[str, Any] | None:
        schema = self._payload_schemas.get(artifact_kind)
        return copy.deepcopy(schema) if schema is not None else None

    def validate_payload(
        self,
        *,
        artifact_kind: str,
        machine_payload: Any,
    ) -> None:
        """Apply the same registered payload contract used by publication."""
        payload_validator = self._payload_validators.get(artifact_kind)
        if payload_validator is not None:
            payload_validator(machine_payload)
        if not isinstance(machine_payload, Mapping):
            raise TypeError("artifact_machine_payload_must_be_object")
        payload_kind = machine_payload.get("artifact_kind")
        if payload_kind is not None and payload_kind != artifact_kind:
            raise ValueError(
                "artifact_kind_conflict:"
                f"envelope={artifact_kind}:payload={payload_kind}"
            )

    def read(self, artifact_ref: str) -> dict[str, Any]:
        cached = self._artifact_cache.get(artifact_ref)
        if cached is not None:
            return copy.deepcopy(cached)
        entry = self._read_index()["entries"].get(artifact_ref)
        if entry is None:
            raise KeyError(f"unknown_artifact_ref:{artifact_ref}")
        path = Path(entry["storage_path"]).resolve()
        if not path.is_relative_to(self._artifact_dir):
            raise ValueError(f"artifact_path_outside_store:{artifact_ref}")
        artifact = json.loads(path.read_text(encoding="utf-8"))
        if artifact.get("artifact_ref") != artifact_ref:
            raise ValueError(f"artifact_ref_content_conflict:{artifact_ref}")
        self._artifact_cache[artifact_ref] = copy.deepcopy(artifact)
        return copy.deepcopy(artifact)

    def _read_index(self) -> dict[str, Any]:
        if self._current_index_signature() != self._index_signature:
            self._reload_index()
        return copy.deepcopy(self._index_cache)

    def _reload_index(self) -> None:
        index = json.loads(self._index_path.read_text(encoding="utf-8"))
        self._index_cache = index
        self._index_signature = self._current_index_signature()
        latest: dict[str, str] = {}
        for artifact_ref in index["order"]:
            entry = index["entries"][artifact_ref]
            artifact_id = str(entry.get("artifact_id") or "")
            if not artifact_id:
                try:
                    stored = json.loads(
                        Path(entry["storage_path"]).read_text(encoding="utf-8")
                    )
                except (OSError, json.JSONDecodeError, KeyError, TypeError):
                    artifact_id = artifact_ref
                else:
                    artifact_id = str(stored.get("artifact_id") or artifact_ref)
            latest[artifact_id] = artifact_ref
        self._latest_by_artifact_id = latest

    def _write_index(self, value: Mapping[str, Any]) -> None:
        self._write_json(self._index_path, value)
        self._reload_index()

    def _current_index_signature(self) -> tuple[int, int] | None:
        if not self._index_path.exists():
            return None
        stat = self._index_path.stat()
        return stat.st_size, stat.st_mtime_ns

    @staticmethod
    def _write_json(path: Path, value: Mapping[str, Any]) -> None:
        temporary = path.with_suffix(f"{path.suffix}.tmp")
        temporary.write_text(
            json.dumps(value, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, path)


def _public_receipt(entry: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "artifact_ref": entry["artifact_ref"],
        "artifact_kind": entry["artifact_kind"],
        "status": entry["status"],
        "summary": entry.get("summary", ""),
        "depends_on": list(entry.get("depends_on", [])),
    }


def _slug(value: str) -> str:
    normalized = re.sub(r"[^a-zA-Z0-9._-]+", "-", value.strip()).strip("-")
    return normalized or "artifact"
