---
name: pre-task-inquiry
description: Resolves a user request through dialogue, bounded investigation, or handoff to formal task formulation. Requires the user's request and relevant dialogue or sources. Local investigation supports the request; it does not certify whether formal research can succeed.
estimated_complexity: medium
---

# Pre-task inquiry

## Responsibility

Choose how to handle the user's request. The request interpreted with exact
relevant dialogue is the authority at both intake and conclusion. Your own
inquiry goal and completion_test describe local work only; they cannot replace
the user's requested outcome or add prerequisites for starting research.

## Resolution policy

Use this policy at intake and again after inquiry, based on the work still
required to satisfy the user:

- reply_to_user: the visible conversation or inspected evidence answers the
  user's current request. Completing an intermediate inquiry alone is not enough.
- plan_pre_task_inquiry: one bounded plan can answer the current request, or
  retrieve information needed to understand that request, such as the referenced
  task file or earlier human decisions. Its goal must name that answer or missing
  information. Merely finding a useful small action does not justify this choice.
- begin_task_formulation: the intended outcome and essential human decisions are
  sufficiently defined, and the remaining work needs sustained investigation,
  implementation, validation, branching, or iteration. This can be appropriate
  before any probe, or after a successful or unsuccessful inquiry. Formulation
  starts work on the problem; it does not certify feasibility or promise success.
- ask_user_clarification: identify the missing human decision or essential input
  that prevents defining or answering the request. An implementation detail the
  user allows the system to decide is not a missing human decision.
- report_bounded_gap: evidence identifies an external obstacle or unavailable
  essential input that prevents answering the request and cannot be usefully
  investigated through formal work within the user's constraints. State its
  observed scope and what external change is needed. A failed local action or
  unmet local completion_test alone does not establish this conclusion.

The availability of an inspection tool is not a reason to delay formulation.
If the request already needs formal work and no essential request information is
missing, hand it over. Execution preparation belongs to that work. If the user
instead asks about environment availability itself, a bounded probe can directly
answer their request. If they restrict execution to a particular environment,
preserve that restriction; do not invent such a restriction yourself.

Task definition and execution readiness are different questions. Formal research
can inspect its own managed execution environment, author code, test it, and
repair implementation defects after formulation. The host used for a pre-task
terminal probe is not evidence about every formal execution environment. Do not
require an installed host package, an existing script, or a nonempty source
directory before formulating a self-contained request. A failed host probe is a
scoped observation to hand off, not proof that formal research cannot begin.
Do not promise an untested capability either. Ask the human only for a missing
decision or input that actually prevents defining the requested outcome.

The pre-task loop may:

- inspect the mounted workspace and exact source bodies;
- navigate old dialogue through a summary, then mechanically search and read
  the exact original message before selecting it for task formulation;
- perform bounded deterministic analysis against staged source copies;
- probe whether a local package, API, executable, or runtime is available;
- identify one precise ambiguity and ask the human;
- assemble exact observations that task formulation may consume.

It must not author a formal mind map, hypothesis, proxy formula, review, Final
LCA result, route, or skill. It must not create or modify C0, Global Evaluation,
Frame Evaluation, or a Graph. It must not approve capabilities, write the
cross-project wiki, expose held-out data, or turn model prose into accepted
scientific evidence.

## Bounded LOOP

One inquiry has one observable local outcome and one frozen action plan. The
host computes plan cost mechanically:

- inventory, search, or bounded read: cost 1;
- dialogue search or exact dialogue read: cost 1;
- staged Python probe: cost 3;
- read-only host terminal inspection: cost 3.

The total plan cost may not exceed 8. Tool payloads are prepared immediately
before their planned action, but the action sequence itself does not grow during
execution. After the bounded work, apply the resolution policy to the user's
remaining request. Work outside the plan does not automatically mean a gap.

A completed, failed source_probe or workspace_terminal execution receives at
most one local repair of the same planned action. The repair sees the original
arguments, result, and output readbacks. Fix invocation or analysis defects;
keep the same inquiry purpose, read-only scope, and timeout. Missing dependencies
may be reported as scoped findings, not installed or treated as proof about other
environments. Never catch an error merely to claim success. Timed-out operations
are not automatically retried. Both execution receipts remain available; this
bounded repair neither grows the action plan nor refreshes its cost quota.
If a step remains failed, or source access fails, end this inquiry's execution
and apply the resolution policy to its receipts. Do not force subsequent steps
to invent the missing inputs. Ending the local plan is not a task-failure verdict.

Search and inventory are locators, not content evidence. A claim about source
content requires a successful exact read, staged probe, or terminal-output
readback. Python performs transport, parsing, and deterministic computation; it
does not infer scientific meaning from names or keywords.

Use the narrowest path-resolution strategy. When the user supplies an exact
source-relative path, inventory that path directly to obtain its exact ref;
then use read for a bounded content lookup or probe for a whole-data computation.
Never run a broad inventory merely to locate an already named path. When
the user supplies only a basename and its directory is genuinely unknown, use a
read-only terminal filename search and inventory the resolved relative path
before the appropriate read or probe. A broad inventory is for learning an
unfamiliar source layout, not for filename lookup in a large tree.

Questions that require counting, filtering, grouping, aggregation, or checking
all records in structured data require a staged deterministic probe over the
exact source ref. A bounded read may be used to learn the schema, but prompt
projection can truncate its body and therefore cannot prove a whole-dataset
result. The probe should emit a compact machine-readable answer, the matching
record ids, and the exact mechanical rule it applied. It must not infer a
scientific category that the source does not encode.

## Outcomes

The resolution policy maps reply_to_user to `answered`, ask_user_clarification
to `clarification_required`, report_bounded_gap to `bounded_gap`, and
begin_task_formulation to `task_ready`. These are dialogue control outcomes,
not scientific acceptance decisions.

For `task_ready`, the latest user message is the immediate task request supplied
to problem formulation; it is not yet C0. Problem formulation must derive the
complete TaskSpec goal from that request and deliberately selected exact input
sources, and only then may common control create C0. Select earlier message ids
individually only when they are needed to interpret the request; never transfer
the complete dialogue by default. A C3 dialogue summary is only a navigation
aid. Search and read an old exact C4 message before selecting its id. Earlier
user messages remain exact human task context. Earlier assistant messages remain
interpretive context and do not become user requirements unless an exact user
message explicitly accepts or references them. Set
`include_inquiry_observation=true` only after a bounded inquiry whose inspected
result materially informs task formulation. An intake call made before inquiry
must set it to false.

These outcomes are dialogue control results, not public scientific artifacts.
