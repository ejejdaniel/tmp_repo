from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ._runtime_children import ChildRuntimeMixin
from ._runtime_dialogue import DialogueRuntimeMixin
from ._runtime_discipline import TransitionDisciplineMixin
from ._runtime_evaluation import EvaluationRuntimeMixin
from ._runtime_human import HumanInteractionRuntimeMixin
from ._runtime_invocation import InvocationTrackingMixin
from ._runtime_loop import AgentResult, ExecutionLoopMixin
from ._runtime_planning import PlanningRuntimeMixin
from ._runtime_prompting import PromptRuntimeMixin
from ._runtime_support import (
    canonical_tool_arguments as _canonical_tool_arguments,
    merge_current_issue as _merge_current_issue,
    return_control_issue as _return_control_issue,
)
from ._runtime_tools import ToolRuntimeMixin
from ._runtime_workflows import SkillWorkflowRuntimeMixin
from .artifact_scope import ArtifactScope
from .artifacts import ArtifactStore
from .capabilities import normalize_meta_capabilities
from .children import ChildMission, ResolvedMissionWorkspace
from .code_artifacts import CodeArtifactStore
from .dialogue import DialogueStore
from .development import DevelopmentProjectStore
from .memory_lifecycle.engine import MemoryStore
from .memory_lifecycle.dialogue_memory import DialogueMemory
from .memory_lifecycle.events import EventLog
from .memory_lifecycle.migration import migrate_agent_v16_dialogue_memory
from .memory_lifecycle.state import AgentStateStore
from .memory_lifecycle.work_store import WorkMemoryStore
from .memory_lifecycle.work_context import WorkContext
from .memory_lifecycle.runtime import WorkMemoryRuntimeMixin
from .memory_lifecycle.prompt import tool_result_prompt_projection
from .model import ChatModel
from .observations import ObservationStore
from .routes import RouteRegistry
from .skills import SkillCatalog
from .sub_loop_toolkit import SubLoopToolkit

ClosureEvaluator = Callable[[Any], Mapping[str, Any]]
_TASK_AUTHORITY_MODES = frozenset({"configured_source", "dialogue_launch"})

__all__ = [
    "AgentResult",
    "CommonAgent",
    "_canonical_tool_arguments",
    "_merge_current_issue",
    "_return_control_issue",
]


class CommonAgent(
    WorkMemoryRuntimeMixin,
    DialogueRuntimeMixin,
    ExecutionLoopMixin,
    InvocationTrackingMixin,
    TransitionDisciplineMixin,
    ChildRuntimeMixin,
    EvaluationRuntimeMixin,
    PlanningRuntimeMixin,
    PromptRuntimeMixin,
    SkillWorkflowRuntimeMixin,
    ToolRuntimeMixin,
    HumanInteractionRuntimeMixin,
):
    """Thin dynamic coordinator hosting project-local skills and routes."""

    def __init__(
        self,
        *,
        agent_id: str,
        model: ChatModel,
        skills: SkillCatalog,
        artifacts: ArtifactStore,
        routes: RouteRegistry,
        closure_evaluator: ClosureEvaluator | None,
        event_log_path: Path,
        observations: ObservationStore | None = None,
        code_artifacts: CodeArtifactStore | None = None,
        development_projects: DevelopmentProjectStore | None = None,
        state_path: Path | None = None,
        role_instructions: str = "",
        memory_compact_after_chars: int = 16_000,
        prompt_budget_bytes: int = 192_000,
        max_rounds: int = 120,
        mission: ChildMission | None = None,
        initial_artifact_refs: Sequence[str] = (),
        child_depth: int = 0,
        max_child_depth: int = 2,
        human_in_loop_enabled: bool = False,
        mission_workspace: ResolvedMissionWorkspace | None = None,
        project_workspace_root: Path | None = None,
        workspace_excluded_relative_paths: Sequence[str] = (),
        task_formulation_skill_id: str = "",
        task_authority_mode: str = "configured_source",
        dialogue_memory: DialogueMemory | None = None,
        preformulated_task_spec_ref: str = "",
        preformulated_task_input_refs: Sequence[str] = (),
    ) -> None:
        if child_depth < 0:
            raise ValueError("child_depth_must_not_be_negative")
        if max_child_depth < 0:
            raise ValueError("max_child_depth_must_not_be_negative")
        if child_depth > max_child_depth:
            raise ValueError("child_depth_exceeds_maximum")
        self.agent_id = agent_id
        self._model = model
        self._skills = skills
        self._artifact_store = artifacts
        self._artifacts = ArtifactScope(
            artifacts,
            agent_id=agent_id,
            isolated=mission is not None,
            mounted_refs=(
                tuple(
                    ref
                    for ref in mission.artifact_refs
                    if ref.startswith("artifact:")
                )
                if mission
                else ()
            ),
        )
        self._routes = routes
        # Kept only for construction compatibility; it is not terminal authority.
        self._legacy_closure_evaluator = closure_evaluator
        self._event_log_path = event_log_path.resolve()
        self._events = EventLog(self._event_log_path)
        self._observations = observations or ObservationStore(event_log_path.parent)
        self._code_artifacts = code_artifacts
        self._development_projects = development_projects
        self._state = AgentStateStore(
            state_path or event_log_path.parent / "agent-state.json"
        )
        work_store = WorkMemoryStore(
            self._artifact_store.root / "work-memory.sqlite3"
        )
        migrate_agent_v16_dialogue_memory(
            state_store=self._state,
            work_store=work_store,
            dialogue_id=agent_id,
        )
        self._dialogue_memory = dialogue_memory or DialogueMemory(
            dialogue_id=agent_id,
            dialogue=DialogueStore(self._event_log_path.parent / "dialogue"),
            work_store=work_store,
            model=self._model,
            events=self._events,
        )
        if self._dialogue_memory.dialogue_id != agent_id:
            raise ValueError("dialogue_memory_agent_identity_mismatch")
        if self._dialogue_memory.work_store.path != work_store.path:
            raise ValueError("dialogue_memory_work_store_mismatch")
        self._dialogue = self._dialogue_memory.dialogue
        self._work = WorkContext(
            work_store,
            self._state, agent_id,
            source_visible=self._work_source_visible, view_policy=self._work_view_policy,
        )
        self._events.continue_after(self._work.store.last_source_event_sequence(agent_id=agent_id))
        self._memory = MemoryStore(
            state=self._state,
            events=self._events,
            model=self._model,
            compact_after_chars=memory_compact_after_chars,
            prompt_budget_bytes=prompt_budget_bytes,
            work=self._work,
            project_result=lambda name, arguments, result: tool_result_prompt_projection(
                result, projector=self._tool_result_projector(name, arguments)
            ),
        )
        self._role_instructions = role_instructions.strip()
        self._max_rounds = max_rounds
        self._mission = mission
        self._enabled_meta_capabilities = normalize_meta_capabilities(
            mission.enabled_meta_capabilities if mission is not None else ()
        )
        self._active_pending_route_lineage_refs: set[str] = set()
        self._configure_meta_skill_catalog(
            self._enabled_meta_capabilities,
            require_support=bool(self._enabled_meta_capabilities),
        )
        self._workspace_excluded_relative_paths = tuple(
            dict.fromkeys(
                str(path).strip().replace("\\", "/")
                for path in workspace_excluded_relative_paths
                if str(path).strip()
            )
        )
        self._mission_workspace = (
            mission_workspace
            if mission_workspace is not None
            else (
                mission.workspace(
                    excluded_relative_paths=(
                        self._workspace_excluded_relative_paths
                    )
                ).resolve()
                if mission
                else None
            )
        )
        self._task_authority_mode = str(task_authority_mode).strip()
        if self._task_authority_mode not in _TASK_AUTHORITY_MODES:
            raise ValueError(
                "task_authority_mode_invalid:"
                f"{self._task_authority_mode}"
            )
        self._preformulated_task_spec_ref = str(
            preformulated_task_spec_ref
        ).strip()
        self._preformulated_task_input_refs = tuple(
            dict.fromkeys(
                str(ref).strip()
                for ref in preformulated_task_input_refs
                if str(ref).strip()
            )
        )
        if (
            self._preformulated_task_input_refs
            and not self._preformulated_task_spec_ref
        ):
            raise ValueError(
                "preformulated_task_inputs_require_task_spec_ref"
            )
        if (
            self._preformulated_task_spec_ref
            and self._task_authority_mode != "dialogue_launch"
        ):
            raise ValueError(
                "preformulated_task_spec_requires_dialogue_launch"
            )
        self._initial_artifact_refs = tuple(
            dict.fromkeys(
                (
                    *(
                        str(ref).strip()
                        for ref in initial_artifact_refs
                        if str(ref).strip()
                    ),
                    *(
                        ref
                        for ref in self._preformulated_task_input_refs
                        if ref.startswith("artifact:")
                    ),
                    *(
                        (self._preformulated_task_spec_ref,)
                        if self._preformulated_task_spec_ref
                        else ()
                    ),
                )
            )
        )
        invalid_initial_refs = [
            ref
            for ref in self._initial_artifact_refs
            if not ref.startswith("artifact:")
        ]
        if invalid_initial_refs:
            raise ValueError(
                "initial_artifact_refs_must_be_artifact_refs:"
                + ",".join(invalid_initial_refs)
            )
        self._child_depth = child_depth
        self._max_child_depth = max_child_depth
        self._human_in_loop_enabled = bool(human_in_loop_enabled)
        self._task_formulation_skill_id = str(
            task_formulation_skill_id
        ).strip()
        if self._task_formulation_skill_id:
            known_skill_ids = {
                card.skill_id for card in self._skills.summaries()
            }
            if self._task_formulation_skill_id not in known_skill_ids:
                raise ValueError(
                    "task_formulation_skill_unknown:"
                    f"{self._task_formulation_skill_id}"
                )
            if not self._skills.has_workflow(
                self._task_formulation_skill_id
            ):
                raise ValueError(
                    "task_formulation_skill_workflow_required:"
                    f"{self._task_formulation_skill_id}"
                )
        self._workspace_root = (
            mission.workspace_root.resolve()
            if mission and mission.workspace_root is not None
            else (
                project_workspace_root.resolve()
                if project_workspace_root is not None
                else self._event_log_path.parent
            )
        )
        if not self._workspace_root.is_dir():
            raise ValueError(
                f"project_workspace_root_not_directory:{self._workspace_root}"
            )
        self._mounted_external_refs = set(
            mission.artifact_refs if mission else ()
        )
        self._owned_external_refs: set[str] = set()
        self._recover_owned_work_refs()

        self._sub_loop_toolkit = SubLoopToolkit(
            enabled=self._human_in_loop_enabled,
            state=self._state,
            publish_artifact=self._artifacts.publish,
            validate_ref=self._validate_human_context_ref,
            events=self._events,
        )

        self._children: dict[str, dict[str, Any]] = {}
        self._paused_child: dict[str, Any] | None = None
        self._review_only_artifact: Mapping[str, Any] | None = None
        self._inspected_pending_child_refs: set[str] = set()
        self._recover_paused_child_from_disk()


    def _refresh_pending_capabilities(self) -> None:
        refresh = getattr(self._skills, "refresh_pending_candidates", None)
        if callable(refresh):
            refresh(self._artifacts)
        pending_routes = getattr(self._skills, "pending_agent_routes", None)
        if not callable(pending_routes):
            return
        for route in pending_routes():
            if self._routes.has(route.name):
                continue
            self._routes.register(route)

    def _active_capability_lineage_refs(self) -> tuple[str, ...]:
        state = self._state.read()
        active_skill_id = str(state["c1"]["active_skill_id"] or "")
        refs: list[str] = []
        lineage = getattr(self._skills, "lineage_refs", None)
        if active_skill_id and callable(lineage):
            refs.extend(str(ref) for ref in lineage(active_skill_id))
        refs.extend(sorted(self._active_pending_route_lineage_refs))
        return tuple(dict.fromkeys(ref for ref in refs if ref))

    def _configure_meta_skill_catalog(
        self,
        capabilities: Sequence[str],
        *,
        require_support: bool,
    ) -> None:
        configure = getattr(self._skills, "for_meta_capabilities", None)
        if configure is None:
            if require_support:
                raise RuntimeError(
                    "authorized_meta_capabilities_require_meta_catalog"
                )
            self._refresh_pending_capabilities()
            return
        self._skills = configure(capabilities)
        # Reconfiguring meta capabilities rebuilds the production catalog.
        # Restore task-local pending Skills and Routes from current artifacts
        # before the next prompt is projected.
        self._refresh_pending_capabilities()

    def _mission_prompt_projection(self) -> dict[str, Any]:
        if self._mission is None:
            return {}
        return self._mission.prompt_projection(workspace=self._mission_workspace)
