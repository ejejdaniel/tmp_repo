from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Protocol, Sequence


@dataclass(frozen=True)
class ToolCall:
    call_id: str
    name: str
    arguments: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ModelTurn:
    content: str = ""
    tool_calls: tuple[ToolCall, ...] = ()
    usage: Mapping[str, Any] = field(default_factory=dict)
    finish_reason: str = "stop"


class ChatModel(Protocol):
    def complete(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
        purpose: str,
        tool_choice: str | Mapping[str, Any] | None = None,
        max_output_tokens: int | None = None,
    ) -> ModelTurn: ...


def complete_model_turn(
    model: ChatModel,
    *,
    messages: Sequence[Mapping[str, Any]],
    tools: Sequence[Mapping[str, Any]],
    purpose: str,
    tool_choice: str | Mapping[str, Any] | None = None,
    repair: bool = False,
    scientific: bool = False,
    planning: bool = False,
    without_reasoning: bool = False,
    max_output_tokens: int | None = None,
) -> ModelTurn:
    """Use an explicitly selected model profile when the model supports it."""
    if sum((repair, scientific, planning, without_reasoning)) > 1:
        raise ValueError("model_turn_reasoning_profile_ambiguous")
    common_kwargs: dict[str, Any] = {
        "messages": messages,
        "tools": tools,
        "purpose": purpose,
        "tool_choice": tool_choice,
    }
    if max_output_tokens is not None:
        if int(max_output_tokens) < 1:
            raise ValueError("model_turn_max_output_tokens_must_be_positive")
        common_kwargs["max_output_tokens"] = int(max_output_tokens)
    if repair:
        complete_repair = getattr(model, "complete_repair", None)
        if callable(complete_repair):
            return complete_repair(**common_kwargs)
    if scientific:
        complete_scientific = getattr(model, "complete_scientific", None)
        if callable(complete_scientific):
            return complete_scientific(**common_kwargs)
    if planning:
        complete_planning = getattr(model, "complete_planning", None)
        if callable(complete_planning):
            return complete_planning(**common_kwargs)
    if without_reasoning:
        complete_without_reasoning = getattr(model, "complete_without_reasoning", None)
        if callable(complete_without_reasoning):
            return complete_without_reasoning(**common_kwargs)
    return model.complete(**common_kwargs)


def retry_model_turn_without_reasoning(
    model: ChatModel,
    *,
    error: Exception,
    before_retry: Callable[[], None],
    messages: Sequence[Mapping[str, Any]],
    tools: Sequence[Mapping[str, Any]],
    purpose: str,
    tool_choice: str | Mapping[str, Any] | None = None,
    repair: bool = False,
    scientific: bool = False,
    planning: bool = False,
    max_output_tokens: int | None = None,
) -> ModelTurn:
    """Retry only answerless output exhaustion; the caller owns quota and audit."""
    # The transport imports ModelTurn, so import its error only when needed.
    from .openai_compatible import ModelProtocolError

    if sum((repair, scientific, planning)) > 1:
        raise ValueError("model_turn_reasoning_profile_ambiguous")
    profile = "repair" if repair else "scientific" if scientific else "planning" if planning else ""
    effort = (
        getattr(model, f"{profile}_reasoning_effort", "") if profile else ""
    ) or getattr(model, "reasoning_effort", "")
    if (
        not isinstance(error, ModelProtocolError)
        or str(error) != "model_output_limit_without_answer"
        or effort == "none"
        or not callable(getattr(model, "complete_without_reasoning", None))
    ):
        raise error
    before_retry()
    # No failed reasoning or partial response becomes a semantic input.
    return complete_model_turn(
        model, messages=messages, tools=tools, purpose=purpose,
        tool_choice=tool_choice, without_reasoning=True,
        max_output_tokens=max_output_tokens,
    )
