from __future__ import annotations

import copy
import json

from typing import Any, Callable, Mapping

from ..sub_loop_toolkit import (
    BoundedRepairController,
    BoundedRepairLimits,
    DraftFileWorkbench,
)


_FILE_REPAIR_SYSTEM = """\
Repair one rejected candidate source tree as a new unsealed draft through
ordinary file operations. Candidate identity, manifest fields, dependency bindings,
source_kind=path inputs, approval state, and registry state are host-frozen.
Do not return or rewrite the complete candidate.

Use read_file to obtain exact current text before editing. Use edit_file with
the smallest unique old_string and its replacement; do not place a complete
existing file in new_string. Use write_file only when the exact validator error
requires one absent authored file. The host applies the operation to the C5
draft and submits the resulting exact tree through the same validator. Never
claim validation or publication.
The supplied file_validation_contract remains authoritative during repair.
Preserve every validator rule not named by the current error. A read result
already covering the current file revision remains visible; do not request the
same or a smaller covered range again.

Choose stop_bounded_gap when the error requires a manifest, dependency,
scientific responsibility, public contract, source_kind=path, deletion, or
host-owned state change. An exact review that identifies a contradiction
confined to source sections is editable when the declared responsibility and
formal result remain unchanged. Return every field. Fields unused by the
selected action must be empty, zero, or false as appropriate."""

_FILE_REPAIR_ACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "action": {
            "type": "string",
            "enum": [
                "read_file",
                "write_file",
                "edit_file",
                "stop_bounded_gap",
            ],
        },
        "reason": {"type": "string", "minLength": 1, "maxLength": 1_200},
        "path": {"type": "string", "maxLength": 500},
        "line_offset": {
            "type": "integer",
            "minimum": 0,
            "maximum": 1_000_000,
        },
        "line_limit": {
            "type": "integer",
            "minimum": 0,
            "maximum": 2_000,
        },
        "content": {"type": "string", "maxLength": 120_000},
        "old_string": {"type": "string", "maxLength": 24_000},
        "new_string": {"type": "string", "maxLength": 24_000},
        "replace_all": {"type": "boolean"},
    },
    "required": ["action", "reason"],
    "additionalProperties": False,
}

_MAX_FILE_REPAIR_DECISIONS = 8


def submit_skill_candidate_with_bounded_file_repair(
    runtime: Any,
    *,
    draft: Mapping[str, Any],
    manifest_builder: Callable[[Mapping[str, Any]], Mapping[str, Any]],
    repair_purpose: str,
    file_validation_contract: str = "",
    initial_repair_request: str = "",
) -> dict[str, Any]:
    """Seal one Skill draft after bounded invocation-local file repair."""
    current = copy.deepcopy(dict(draft))

    def submit(value: Mapping[str, Any]) -> dict[str, Any]:
        return runtime.call_route(
            "capability_candidate_submit",
            {
                "manifest": dict(manifest_builder(value)),
                "files": copy.deepcopy(list(value.get("files") or [])),
            },
        )

    repair_request = str(initial_repair_request).strip()
    if repair_request:
        latest_error = "review_required_source_repair:" + repair_request
    else:
        try:
            return submit(current)
        except (RuntimeError, ValueError) as exc:
            latest_error = f"{type(exc).__name__}: {exc}"

    workbench = DraftFileWorkbench(list(current.get("files") or []))
    immutable_envelope = {
        key: copy.deepcopy(value)
        for key, value in current.items()
        if key != "files"
    }
    controller = BoundedRepairController(
        BoundedRepairLimits(
            max_inspections=2,
            max_edits=2,
            max_actions=4,
            max_rejections=2,
        ),
        inspection_actions=frozenset({"read_file"}),
        edit_actions=frozenset({"write_file", "edit_file"}),
    )
    observations: list[dict[str, Any]] = []
    rejected_actions: list[dict[str, str]] = []
    continuation_messages: list[dict[str, str]] = []
    decision_index = 0
    repair_system = _FILE_REPAIR_SYSTEM
    validation_contract = str(file_validation_contract).strip()
    if validation_contract:
        repair_system += (
            "\n\nAuthoritative file validation contract:\n"
            + validation_contract
        )
    initial_context = json.dumps(
        {
            "exact_packaging_error": latest_error,
            "repair_origin": (
                "exact_candidate_review"
                if repair_request
                else "candidate_validator"
            ),
            "immutable_candidate_envelope": immutable_envelope,
            "file_catalog": workbench.catalog(),
            "repair_quota": controller.projection(),
        },
        ensure_ascii=False,
        indent=2,
    )

    while (
        controller.can_continue()
        and decision_index < _MAX_FILE_REPAIR_DECISIONS
    ):
        decision_index += 1
        action = runtime.generate_json(
            repair_system,
            initial_context,
            purpose=f"{repair_purpose}-file-action-{decision_index}",
            schema=_FILE_REPAIR_ACTION_SCHEMA,
            continuation_messages=tuple(continuation_messages),
        )
        continuation_messages.append(
            {
                "role": "assistant",
                "content": "Selected file action:\n"
                + json.dumps(action, ensure_ascii=False, sort_keys=True),
            }
        )
        issue = _file_action_issue(action)
        if issue:
            rejected_actions.append(
                {"action": str(action.get("action") or ""), "error": issue}
            )
            terminal = controller.record_rejection(issue)
            _append_file_tool_result(
                continuation_messages,
                status="rejected",
                payload={"error": issue},
                latest_error=latest_error,
                workbench=workbench,
                controller=controller,
            )
            if terminal:
                raise RuntimeError(
                    f"candidate_file_repair_stopped:{terminal}:"
                    f"last_error={latest_error}"
                )
            continue

        if str(action.get("action") or "") == "read_file" and _read_is_visible(
            action,
            observations=observations,
            file_catalog=workbench.catalog(),
        ):
            cached = workbench.read_file(
                str(action.get("path") or ""),
                line_offset=int(action.get("line_offset") or 0),
                line_limit=int(action.get("line_limit") or 0),
            )
            cached["cache_hit"] = True
            cached["next_action_instruction"] = (
                "This exact current-revision range was already visible. Use "
                "the returned text now; do not read the same range again."
            )
            observation = {"action": "read_file", "result": cached}
            observations.append(observation)
            _append_file_tool_result(
                continuation_messages,
                status="cache_hit",
                payload=observation,
                latest_error=latest_error,
                workbench=workbench,
                controller=controller,
            )
            continue

        admission = controller.admit(action)
        if admission == "model_requested_bounded_gap":
            raise RuntimeError(
                "candidate_file_repair_stopped:"
                + str(action.get("reason") or admission)
                + f":last_error={latest_error}"
            )
        if admission:
            rejected_actions.append(
                {
                    "action": str(action.get("action") or ""),
                    "error": admission,
                }
            )
            terminal = controller.record_rejection(admission)
            _append_file_tool_result(
                continuation_messages,
                status="rejected",
                payload={"error": admission},
                latest_error=latest_error,
                workbench=workbench,
                controller=controller,
            )
            if terminal:
                raise RuntimeError(
                    f"candidate_file_repair_stopped:{terminal}:"
                    f"last_error={latest_error}"
                )
            continue

        action_name = str(action["action"])
        try:
            if action_name == "read_file":
                observation = {
                    "action": action_name,
                    "result": workbench.read_file(
                        str(action.get("path") or ""),
                        line_offset=int(action.get("line_offset") or 0),
                        line_limit=int(action.get("line_limit") or 0),
                    ),
                }
                observations.append(observation)
                _append_file_tool_result(
                    continuation_messages,
                    status="completed",
                    payload=observation,
                    latest_error=latest_error,
                    workbench=workbench,
                    controller=controller,
                )
                continue
            if action_name == "write_file":
                result = workbench.write_file(
                    str(action.get("path") or ""),
                    str(action.get("content") or ""),
                )
            else:
                result = workbench.edit_file(
                    str(action.get("path") or ""),
                    old_string=str(action.get("old_string") or ""),
                    new_string=str(action.get("new_string") or ""),
                    replace_all=bool(action.get("replace_all")),
                )
            observation = {
                "action": action_name,
                "request": {
                        "path": str(action.get("path") or ""),
                        "content": (
                            str(action.get("content") or "")
                            if action_name == "write_file"
                            else ""
                        ),
                        "old_string": (
                            str(action.get("old_string") or "")
                            if action_name == "edit_file"
                            else ""
                        ),
                        "new_string": (
                            str(action.get("new_string") or "")
                            if action_name == "edit_file"
                            else ""
                        ),
                        "replace_all": bool(action.get("replace_all")),
                },
                "result": result,
            }
            observations.append(observation)
        except (KeyError, PermissionError, TypeError, ValueError) as exc:
            observation = {
                "action": action_name,
                "error": f"{type(exc).__name__}: {exc}",
            }
            observations.append(observation)
            _append_file_tool_result(
                continuation_messages,
                status="failed",
                payload=observation,
                latest_error=latest_error,
                workbench=workbench,
                controller=controller,
            )
            continue

        current["files"] = workbench.snapshot()
        try:
            return submit(current)
        except (RuntimeError, ValueError) as exc:
            latest_error = f"{type(exc).__name__}: {exc}"
            validation = {
                "action": "validate_candidate",
                "error": latest_error,
            }
            observations.append(validation)
            _append_file_tool_result(
                continuation_messages,
                status="validation_failed",
                payload={
                    "file_operation": observation,
                    "candidate_validation": validation,
                },
                latest_error=latest_error,
                workbench=workbench,
                controller=controller,
            )

    if decision_index >= _MAX_FILE_REPAIR_DECISIONS:
        raise RuntimeError(
            "candidate_file_repair_decision_quota_exhausted:"
            f"last_error={latest_error}"
        )
    raise RuntimeError(
        "candidate_file_repair_action_quota_exhausted:"
        f"last_error={latest_error}"
    )


def _append_file_tool_result(
    messages: list[dict[str, str]],
    *,
    status: str,
    payload: Mapping[str, Any],
    latest_error: str,
    workbench: DraftFileWorkbench,
    controller: BoundedRepairController,
) -> None:
    messages.append(
        {
            "role": "user",
            "content": "File tool result:\n"
            + json.dumps(
                {
                    "status": str(status),
                    "result": copy.deepcopy(dict(payload)),
                    "current_validator_error": str(latest_error),
                    "file_catalog": workbench.catalog(),
                    "repair_quota": controller.projection(),
                },
                ensure_ascii=False,
                indent=2,
            ),
        }
    )


def _file_action_issue(action: Mapping[str, Any]) -> str:
    name = str(action.get("action") or "")
    path = str(action.get("path") or "")
    line_offset = action.get("line_offset")
    line_limit = action.get("line_limit")
    content = str(action.get("content") or "")
    old_string = str(action.get("old_string") or "")
    new_string = str(action.get("new_string") or "")
    replace_all = bool(action.get("replace_all"))
    if name == "read_file":
        if not path or line_offset is None or not line_limit:
            return "read_file_requires_path_and_positive_line_limit"
        return ""
    if name == "write_file":
        if not path:
            return "write_file_requires_path"
        return ""
    if name == "edit_file":
        if not path or not old_string:
            return "edit_file_requires_path_and_old_string"
        if old_string == new_string:
            return "edit_file_requires_changed_text"
        return ""
    if name == "stop_bounded_gap":
        return ""
    return f"candidate_file_repair_action_unknown:{name or 'missing'}"


def _read_is_visible(
    action: Mapping[str, Any],
    *,
    observations: list[dict[str, Any]],
    file_catalog: list[dict[str, Any]],
) -> bool:
    path = str(action.get("path") or "")
    offset = int(action.get("line_offset") or 0)
    limit = int(action.get("line_limit") or 0)
    catalog_entry = next(
        (item for item in file_catalog if item.get("path") == path),
        None,
    )
    if catalog_entry is None:
        return False
    revision = int(catalog_entry.get("revision") or 0)
    for observation in reversed(observations):
        if observation.get("action") != "read_file":
            continue
        result = observation.get("result")
        if not isinstance(result, Mapping):
            continue
        if (
            result.get("path") != path
            or int(result.get("revision") or 0) != revision
        ):
            continue
        visible_start = int(result.get("line_offset") or 0)
        visible_end = result.get("next_line_offset")
        if visible_end is None:
            visible_end = int(result.get("total_lines") or 0)
        requested_end = min(
            offset + limit,
            int(result.get("total_lines") or offset + limit),
        )
        if visible_start <= offset and requested_end <= int(visible_end):
            return True
    return False
