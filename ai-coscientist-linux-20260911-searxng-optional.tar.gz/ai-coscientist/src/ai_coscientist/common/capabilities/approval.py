from __future__ import annotations

import copy
from pathlib import Path
from typing import Any, Mapping, Sequence

from ..artifacts import ArtifactStore
from ..memory_lifecycle.events import EventLog
from ..skills import SkillCatalog
from .registry import CapabilityRegistry
from .routes import skill_source_tree_hash


class CapabilityApprovalService:
    """Human-only exact promotion; intentionally absent from agent tools."""

    def __init__(
        self,
        *,
        registry: CapabilityRegistry,
        artifacts: ArtifactStore,
        production_skills_root: Path,
        reserved_route_names: Sequence[str],
        event_log: EventLog | None = None,
    ) -> None:
        self._registry = registry
        self._artifacts = artifacts
        self._production_skills_root = production_skills_root.resolve()
        self._reserved_route_names = tuple(
            dict.fromkeys(str(name) for name in reserved_route_names)
        )
        self._event_log = event_log

    def approve(
        self,
        *,
        candidate_ref: str,
        review_ref: str,
        package_hash: str,
        approved_by: str,
    ) -> dict[str, Any]:
        candidate = self._artifacts.read(str(candidate_ref))
        review = self._artifacts.read(str(review_ref))
        production = SkillCatalog(self._production_skills_root)
        reserved_skill_ids = tuple(
            card.skill_id for card in production.summaries()
        )
        baseline_hashes = {
            skill_id: skill_source_tree_hash(
                self._production_skills_root / skill_id
            )
            for skill_id in reserved_skill_ids
        }
        receipt = self._registry.approve(
            candidate_artifact=candidate,
            review_artifact=review,
            package_hash=str(package_hash),
            approved_by=str(approved_by),
            reserved_skill_ids=reserved_skill_ids,
            reserved_route_names=self._reserved_route_names,
            baseline_skill_hashes=baseline_hashes,
        )
        if self._event_log is not None:
            self._event_log.append(
                "capability_candidate_approved",
                copy.deepcopy(receipt),
            )
        return copy.deepcopy(receipt)
