from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence


META_CAPABILITY_ORDER = (
    "skill-optimization",
    "skill-creation",
    "skill-onboarding",
    "route-creation",
    "route-onboarding",
    "candidate-review",
)
META_CAPABILITY_SET = frozenset(META_CAPABILITY_ORDER)
_COMMAND_PREFIX = "@enable "


class CapabilityAuthorizationError(ValueError):
    pass


@dataclass(frozen=True)
class ParsedTaskAuthorization:
    objective: str
    enabled_meta_capabilities: tuple[str, ...]


def parse_task_authorization(objective: str) -> ParsedTaskAuthorization:
    """Remove one root-task command block and return its exact authorities."""
    raw = str(objective).removeprefix("\ufeff")
    lines = raw.splitlines()
    requested: set[str] = set()
    consumed = 0
    for line in lines:
        command = line.strip()
        if not command.startswith("@enable"):
            break
        consumed += 1
        if not command.startswith(_COMMAND_PREFIX):
            raise CapabilityAuthorizationError(
                f"meta_capability_command_invalid:{command}"
            )
        capability = command[len(_COMMAND_PREFIX) :].strip()
        if capability not in META_CAPABILITY_SET:
            raise CapabilityAuthorizationError(
                f"meta_capability_unknown:{capability or 'empty'}"
            )
        requested.add(capability)

    cleaned = "\n".join(lines[consumed:]).strip()
    if not cleaned:
        raise CapabilityAuthorizationError(
            "task_objective_required_after_meta_capability_commands"
        )
    return ParsedTaskAuthorization(
        objective=cleaned,
        enabled_meta_capabilities=normalize_meta_capabilities(requested),
    )


def normalize_meta_capabilities(values: Sequence[str]) -> tuple[str, ...]:
    if isinstance(values, (str, bytes)):
        raise CapabilityAuthorizationError(
            "enabled_meta_capabilities_must_be_array"
        )
    normalized = {str(value).strip() for value in values}
    if "" in normalized:
        raise CapabilityAuthorizationError(
            "enabled_meta_capability_must_not_be_empty"
        )
    unknown = sorted(normalized - META_CAPABILITY_SET)
    if unknown:
        raise CapabilityAuthorizationError(
            f"enabled_meta_capability_unknown:{unknown}"
        )
    return tuple(
        capability
        for capability in META_CAPABILITY_ORDER
        if capability in normalized
    )


def require_child_capability_subset(
    child_values: Sequence[str],
    *,
    parent_values: Sequence[str],
) -> tuple[str, ...]:
    child = normalize_meta_capabilities(child_values)
    parent = set(normalize_meta_capabilities(parent_values))
    unauthorized = [value for value in child if value not in parent]
    if unauthorized:
        raise CapabilityAuthorizationError(
            f"child_meta_capability_not_authorized:{unauthorized}"
        )
    return child
