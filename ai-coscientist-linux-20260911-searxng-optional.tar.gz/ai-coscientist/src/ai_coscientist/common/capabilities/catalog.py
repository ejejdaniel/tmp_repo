from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Sequence

from ..skills import SkillCard, SkillCatalog
from .authorization import normalize_meta_capabilities


_META_CAPABILITY_COMPANIONS = {
    "route-creation": ("python-package-resolver",),
}


class AuthorizedSkillCatalog:
    """Compose production and separately stored, explicitly authorized meta skills."""

    def __init__(
        self,
        production: SkillCatalog,
        *,
        meta_root: Path,
        enabled_meta_capabilities: Sequence[str] = (),
    ) -> None:
        self._production = production
        self._meta_root = meta_root.resolve()
        self._enabled = normalize_meta_capabilities(
            enabled_meta_capabilities
        )
        mounted_meta_skills = tuple(
            dict.fromkeys(
                skill_id
                for capability in self._enabled
                for skill_id in (
                    capability,
                    *_META_CAPABILITY_COMPANIONS.get(capability, ()),
                )
            )
        )
        self._meta = SkillCatalog(
            self._meta_root,
            include_ids=mounted_meta_skills,
        )
        self._owners: dict[str, SkillCatalog] = {}
        for catalog in (self._production, self._meta):
            for card in catalog.summaries():
                if card.skill_id in self._owners:
                    raise ValueError(
                        f"duplicate_skill_across_catalogs:{card.skill_id}"
                    )
                self._owners[card.skill_id] = catalog

    @property
    def root(self) -> Path:
        return self._production.root

    @property
    def enabled_meta_capabilities(self) -> tuple[str, ...]:
        return self._enabled

    def for_meta_capabilities(
        self, values: Sequence[str]
    ) -> "AuthorizedSkillCatalog":
        return AuthorizedSkillCatalog(
            self._production.clone_for_child(),
            meta_root=self._meta_root,
            enabled_meta_capabilities=values,
        )

    def clone_for_child(self) -> "AuthorizedSkillCatalog":
        return AuthorizedSkillCatalog(
            self._production.clone_for_child(),
            meta_root=self._meta_root,
            enabled_meta_capabilities=self._enabled,
        )

    def summaries(self) -> tuple[SkillCard, ...]:
        cards = [
            card
            for catalog in (self._production, self._meta)
            for card in catalog.summaries()
        ]
        return tuple(sorted(cards, key=lambda card: card.skill_id))

    def refresh_pending_candidates(self, artifacts: Any) -> None:
        self._production.refresh_pending_candidates(artifacts)
        self._rebuild_owners()

    def lineage_refs(self, skill_id: str) -> tuple[str, ...]:
        return self._owner(skill_id).lineage_refs(skill_id)

    def managed_route_summaries(
        self,
        *,
        skill_id: str,
        require_agent_callable: bool = False,
        require_code_callable: bool = False,
    ) -> tuple[dict[str, Any], ...]:
        return self._owner(skill_id).managed_route_summaries(
            skill_id=skill_id,
            require_agent_callable=require_agent_callable,
            require_code_callable=require_code_callable,
        )

    def pending_agent_routes(self) -> tuple[Any, ...]:
        return self._production.pending_agent_routes()

    def pending_candidate_snapshot(
        self,
        package_ref: str,
        *,
        max_text_chars: int = 32_000,
    ) -> dict[str, Any]:
        return self._production.pending_candidate_snapshot(
            package_ref, max_text_chars=max_text_chars
        )

    def detail(self, skill_id: str) -> str:
        return self._owner(skill_id).detail(skill_id)

    def describe_execution_capability(self, skill_id: str) -> str:
        return self._owner(skill_id).describe_execution_capability(skill_id)

    def has_disclosure(self, skill_id: str) -> bool:
        return self._owner(skill_id).has_disclosure(skill_id)

    def render_detail(
        self,
        skill_id: str,
        context: Mapping[str, Any],
    ) -> str:
        return self._owner(skill_id).render_detail(skill_id, context)

    def disclosure_visible_refs(
        self,
        skill_id: str,
        context: Mapping[str, Any],
    ) -> tuple[str, ...] | None:
        return self._owner(skill_id).disclosure_visible_refs(
            skill_id, context
        )

    def disclosure_visible_route_names(
        self,
        skill_id: str,
        route_names: Sequence[str],
        context: Mapping[str, Any],
    ) -> tuple[str, ...]:
        return self._owner(skill_id).disclosure_visible_route_names(
            skill_id, route_names, context
        )

    def validate_disclosed_tool_call(
        self,
        skill_id: str,
        tool_name: str,
        arguments: Mapping[str, Any],
        context: Mapping[str, Any],
    ) -> None:
        self._owner(skill_id).validate_disclosed_tool_call(
            skill_id,
            tool_name,
            arguments,
            context,
        )

    def has_workflow(self, skill_id: str) -> bool:
        return self._owner(skill_id).has_workflow(skill_id)

    def workflow(self, skill_id: str) -> Any:
        return self._owner(skill_id).workflow(skill_id)

    def _owner(self, skill_id: str) -> SkillCatalog:
        owner = self._owners.get(str(skill_id))
        if owner is None:
            raise KeyError(f"unknown_skill:{skill_id}")
        return owner

    def _rebuild_owners(self) -> None:
        owners: dict[str, SkillCatalog] = {}
        for catalog in (self._production, self._meta):
            for card in catalog.summaries():
                if card.skill_id in owners:
                    raise ValueError(
                        f"duplicate_skill_across_catalogs:{card.skill_id}"
                    )
                owners[card.skill_id] = catalog
        self._owners = owners
