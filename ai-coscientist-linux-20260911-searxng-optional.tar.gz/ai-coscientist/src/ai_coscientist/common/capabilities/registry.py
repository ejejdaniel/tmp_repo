from __future__ import annotations

import copy
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

from ..json_schema import json_schema_issues
from .execution import (
    CapabilityExecutionError,
    DockerPythonExecutor,
    DockerRouteExecutorPool,
    LocalPythonExecutor,
    RUNTIME_LOCK_PATH,
    RouteExecutionResult,
    RouteExecutor,
    validate_runtime_lock,
)
from .manifests import (
    build_file_receipts,
    capability_candidate_payload,
    candidate_package_hash,
    route_names,
    validate_capability_candidate_payload,
    validate_capability_review_payload,
    validate_candidate_manifest,
)


_CATEGORY = {"skill": "skills", "route_package": "route_packages"}
_PHYSICAL_CATEGORY = {"skill": "skills", "route_package": "routes"}
_APPROVED_ROUTE_REF = re.compile(
    r"^approved_route:([a-z0-9][a-z0-9._-]{0,79}):([0-9a-f]{64})$"
)
_PENDING_ROUTE_REF = re.compile(
    r"^pending_route:([a-z0-9][a-z0-9._-]{0,79}):([0-9a-f]{64})$"
)
_PYTHON_DISTRIBUTION_NAME = re.compile(
    r"^[A-Za-z0-9](?:[A-Za-z0-9._-]{0,126}[A-Za-z0-9])?$"
)
_ACTIVE_KEYS = frozenset({"schema_version", "skills", "routes"})
_ACTIVE_ROUTE_KEYS = frozenset({"package_id", "package_hash"})
_PENDING_ENVIRONMENT_INSPECTION_SKILLS = frozenset(
    {"route-creation", "route-onboarding", "python-package-resolver"}
)
_PACKAGE_DIRECTORY_REPLACE_RETRY_DELAYS = (0.05, 0.2, 0.5)


def _docker_executor_broker_spec(
    executor: DockerPythonExecutor,
) -> dict[str, Any]:
    return {
        "cache_root": str(executor.cache_root),
        "base_image_repository": executor.base_image_repository,
        "base_image_digest": executor.base_image_digest,
        "base_image_reference": executor.base_image_reference,
        "docker_executable": executor.docker_executable,
        "memory_limit": executor.memory_limit,
        "cpu_limit": executor.cpu_limit,
        "pids_limit": executor.pids_limit,
        "tmpfs_size": executor.tmpfs_size,
    }


class CapabilityRegistryError(RuntimeError):
    pass


class CapabilityRegistry:
    """Immutable pending/approved packages with one atomic active overlay."""

    def __init__(
        self,
        root: Path,
        *,
        python_executable: str,
        route_executor: RouteExecutor | None = None,
    ) -> None:
        self.root = root.resolve()
        self.python_executable = str(python_executable)
        self.route_executor = route_executor or LocalPythonExecutor(
            self.python_executable
        )
        self.skills_root = self.root / "skills"
        self.routes_root = self.root / "routes"
        self.reviews_root = self.root / "reviews"
        self.approvals_root = self.root / "approvals"
        self.active_path = self.root / "active.json"
        self.catalog_path = self.root / "CAPABILITY_CATALOG.md"
        for base in (self.skills_root, self.routes_root):
            for state in ("pending", "approved"):
                (base / state).mkdir(parents=True, exist_ok=True)
        self.reviews_root.mkdir(parents=True, exist_ok=True)
        self.approvals_root.mkdir(parents=True, exist_ok=True)
        if not self.active_path.exists():
            self._write_json_atomic(
                self.active_path,
                {"schema_version": 1, "skills": {}, "routes": {}},
            )
        self.active()

    def submit_candidate(
        self,
        manifest: Mapping[str, Any],
        *,
        payload_files: Mapping[str, bytes],
    ) -> dict[str, Any]:
        """Store one exact pending package and return its C2 payload."""
        normalized = copy.deepcopy(dict(manifest))
        receipts = build_file_receipts(payload_files)
        if normalized.get("files") != receipts:
            raise CapabilityRegistryError(
                "candidate_file_receipts_do_not_match_payload"
            )
        requested_hash = normalized.get("package_hash")
        normalized["package_hash"] = None
        validate_candidate_manifest(normalized)
        sealed_payload_files = dict(payload_files)
        if normalized.get("asset_type") == "route_package":
            try:
                sealed_payload_files = self.route_executor.seal_payload(
                    normalized,
                    payload_files,
                )
            except CapabilityExecutionError as exc:
                raise CapabilityRegistryError(str(exc)) from exc
            normalized["files"] = build_file_receipts(sealed_payload_files)
            validate_candidate_manifest(normalized)
        elif RUNTIME_LOCK_PATH in sealed_payload_files:
            raise CapabilityRegistryError("candidate_runtime_lock_is_host_owned")
        package_hash = candidate_package_hash(normalized)
        if requested_hash not in {None, "", package_hash}:
            raise CapabilityRegistryError("candidate_declared_package_hash_mismatch")
        normalized["package_hash"] = package_hash
        validate_candidate_manifest(normalized)

        package_dir = self._package_dir(
            "pending",
            str(normalized["asset_type"]),
            str(normalized["asset_id"]),
            package_hash,
        )
        if package_dir.exists():
            stored = self._verify_package(package_dir)
            if stored != normalized:
                raise CapabilityRegistryError(
                    "candidate_hash_directory_content_conflict"
                )
        else:
            self._write_package_atomic(
                package_dir,
                manifest=normalized,
                payload_files=sealed_payload_files,
            )
            self._verify_package(package_dir)

        self._refresh_human_catalog()
        package_ref = self._pending_package_ref(normalized)
        return capability_candidate_payload(
            normalized,
            package_ref=package_ref,
        )

    def invocation_broker_spec(self, *, timeout_seconds: float) -> dict[str, Any]:
        """Export only trusted executor settings needed by the Route broker."""
        executor = self.route_executor
        if isinstance(executor, LocalPythonExecutor):
            executor_spec: dict[str, Any] = {"kind": "local-python"}
        elif isinstance(executor, DockerPythonExecutor):
            executor_spec = {
                "kind": "docker-python-v1",
                **_docker_executor_broker_spec(executor),
            }
        elif isinstance(executor, DockerRouteExecutorPool):
            executor_spec = {
                "kind": "docker-python-pool-v1",
                "default_base_image_digest": (
                    executor.default_executor.base_image_digest
                ),
                "executors": [
                    _docker_executor_broker_spec(item) for item in executor.executors
                ],
            }
        else:
            raise CapabilityRegistryError(
                f"approved_route_executor_broker_unsupported:{type(executor).__name__}"
            )
        return {
            "registry_root": str(self.root),
            "python_executable": self.python_executable,
            "timeout_seconds": float(timeout_seconds),
            "executor": executor_spec,
        }

    def active(self) -> dict[str, Any]:
        try:
            active = json.loads(self.active_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise CapabilityRegistryError(
                f"capability_active_unreadable:{exc}"
            ) from exc
        if not isinstance(active, Mapping) or set(active) != _ACTIVE_KEYS:
            raise CapabilityRegistryError("capability_active_shape_invalid")
        if active.get("schema_version") != 1:
            raise CapabilityRegistryError("capability_active_version_invalid")
        skills = active.get("skills")
        routes = active.get("routes")
        if not isinstance(skills, Mapping) or not isinstance(routes, Mapping):
            raise CapabilityRegistryError("capability_active_maps_invalid")
        for skill_id, package_hash in skills.items():
            if not _asset_id(skill_id) or not _sha256(package_hash):
                raise CapabilityRegistryError(
                    f"capability_active_skill_invalid:{skill_id}"
                )
        for route_name, binding in routes.items():
            if (
                not _asset_id(route_name)
                or not isinstance(binding, Mapping)
                or set(binding) != _ACTIVE_ROUTE_KEYS
                or not _asset_id(binding.get("package_id"))
                or not _sha256(binding.get("package_hash"))
            ):
                raise CapabilityRegistryError(
                    f"capability_active_route_invalid:{route_name}"
                )
        return copy.deepcopy(dict(active))

    def approve(
        self,
        *,
        candidate_artifact: Mapping[str, Any],
        review_artifact: Mapping[str, Any],
        package_hash: str,
        approved_by: str,
        reserved_skill_ids: Sequence[str] = (),
        reserved_route_names: Sequence[str] = (),
        baseline_skill_hashes: Mapping[str, str] | None = None,
    ) -> dict[str, Any]:
        """Human-only exact promotion; review advice never grants authority."""
        candidate_ref, candidate = _artifact_payload(
            candidate_artifact, "capability_candidate"
        )
        review_ref, review = _artifact_payload(
            review_artifact, "capability_candidate_review"
        )
        validate_capability_candidate_payload(candidate)
        validate_capability_review_payload(review)
        exact_hash = str(package_hash)
        if not _sha256(exact_hash) or candidate["package_hash"] != exact_hash:
            raise CapabilityRegistryError("approval_package_hash_mismatch")
        if (
            review["candidate_ref"] != candidate_ref
            or review["candidate_id"] != candidate["candidate_id"]
            or review["package_hash"] != exact_hash
            or review["baseline_package_hash"] != candidate["base_package_hash"]
        ):
            raise CapabilityRegistryError("approval_review_candidate_binding_mismatch")
        approver = str(approved_by).strip()
        if not approver:
            raise CapabilityRegistryError("approval_human_identity_required")

        asset_type = str(candidate["asset_type"])
        asset_id = str(candidate["asset_id"])
        pending_dir = self._package_dir("pending", asset_type, asset_id, exact_hash)
        manifest = self._verify_package(pending_dir)
        self._require_artifact_matches_manifest(candidate, manifest)
        self._require_approved_dependencies(manifest)

        active = self.active()
        revised = copy.deepcopy(active)
        if asset_type == "skill":
            self._activate_skill(
                revised,
                manifest,
                reserved_skill_ids=set(reserved_skill_ids),
                baseline_skill_hashes=dict(baseline_skill_hashes or {}),
            )
        else:
            self._activate_route_package(
                revised,
                manifest,
                reserved_route_names=set(reserved_route_names),
            )

        approved_dir = self._package_dir("approved", asset_type, asset_id, exact_hash)
        if approved_dir.exists():
            approved_manifest = self._verify_package(approved_dir)
            if approved_manifest != manifest:
                raise CapabilityRegistryError(
                    "approved_hash_directory_content_conflict"
                )
        else:
            self._copy_package_atomic(pending_dir, approved_dir)
            self._verify_package(approved_dir)
        self._write_json_atomic(self.active_path, revised)

        receipt = {
            "candidate_ref": candidate_ref,
            "review_ref": review_ref,
            "asset_type": asset_type,
            "asset_id": asset_id,
            "package_hash": exact_hash,
            "approved_by": approver,
        }
        receipt_path = self.approvals_root / (
            f"{asset_type}-{asset_id}-{exact_hash}.json"
        )
        if receipt_path.exists():
            stored_receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
            if stored_receipt != receipt:
                raise CapabilityRegistryError("approval_receipt_conflict")
        else:
            self._write_json_atomic(receipt_path, receipt)
        self._refresh_human_catalog()
        return copy.deepcopy(receipt)

    def active_skill_roots(self) -> dict[str, Path]:
        roots: dict[str, Path] = {}
        for skill_id, package_hash in self.active()["skills"].items():
            package_dir = self._package_dir(
                "approved", "skill", str(skill_id), str(package_hash)
            )
            manifest = self._verify_package(package_dir)
            if manifest["asset_id"] != skill_id:
                raise CapabilityRegistryError(
                    f"active_skill_manifest_mismatch:{skill_id}"
                )
            roots[str(skill_id)] = package_dir / "payload"
        return roots

    def pending_candidate_payloads(self) -> tuple[dict[str, Any], ...]:
        """Return valid, non-active pending packages in stable order."""
        active = self.active()
        payloads: list[dict[str, Any]] = []
        seen: set[tuple[str, str, str]] = set()
        for asset_type in ("route_package", "skill"):
            category = _PHYSICAL_CATEGORY[asset_type]
            state_root = self.root / category / "pending"
            for manifest_path in sorted(state_root.glob("*/*/candidate.json")):
                try:
                    manifest_hint = json.loads(
                        manifest_path.read_text(encoding="utf-8")
                    )
                except (OSError, json.JSONDecodeError) as exc:
                    raise CapabilityRegistryError(
                        f"candidate_manifest_unreadable:{manifest_path.parent}:{exc}"
                    ) from exc
                validate_candidate_manifest(manifest_hint)
                if self._manifest_is_active(manifest_hint, active=active):
                    continue
                manifest = self._verify_package(manifest_path.parent)
                identity = (
                    str(manifest["asset_type"]),
                    str(manifest["asset_id"]),
                    str(manifest["package_hash"]),
                )
                if identity in seen:
                    continue
                seen.add(identity)
                payloads.append(
                    capability_candidate_payload(
                        manifest,
                        package_ref=self._pending_package_ref(manifest),
                    )
                )
        return tuple(copy.deepcopy(payload) for payload in payloads)

    def pending_candidate_snapshot(
        self,
        package_ref: str,
        *,
        max_text_chars: int = 240_000,
    ) -> dict[str, Any]:
        """Read one exact pending package for an authorized review workflow."""
        package_dir = self._pending_dir_from_ref(package_ref)
        manifest = self._verify_package(package_dir)
        remaining = max(0, int(max_text_chars))
        files: list[dict[str, Any]] = []
        for receipt in manifest["files"]:
            relative = str(receipt["path"])
            body = (package_dir / "payload" / relative).read_bytes()
            try:
                decoded = body.decode("utf-8")
            except UnicodeDecodeError:
                files.append(
                    {
                        "path": relative,
                        "sha256": receipt["sha256"],
                        "text": None,
                        "truncated": False,
                        "size_bytes": len(body),
                    }
                )
                continue
            visible = decoded[:remaining]
            files.append(
                {
                    "path": relative,
                    "sha256": receipt["sha256"],
                    "text": visible,
                    "truncated": len(visible) != len(decoded),
                    "size_bytes": len(body),
                }
            )
            remaining -= len(visible)
        return {
            "package_ref": str(package_ref),
            "manifest": manifest,
            "files": files,
        }

    def managed_route_package_snapshot(
        self,
        route_ref: str,
        *,
        max_text_chars: int = 240_000,
    ) -> dict[str, Any]:
        """Read the exact immutable package behind one managed Route ref."""
        descriptor = self.resolve_managed_route_ref(route_ref)
        payload_root = Path(str(descriptor["payload_root"])).resolve()
        manifest = self._verify_package(payload_root.parent)
        remaining = max(0, int(max_text_chars))
        files: list[dict[str, Any]] = []
        for receipt in manifest["files"]:
            relative = str(receipt["path"])
            body = (payload_root / relative).read_bytes()
            try:
                decoded = body.decode("utf-8")
            except UnicodeDecodeError:
                decoded = None
            visible = decoded[:remaining] if decoded is not None else None
            files.append(
                {
                    "path": relative,
                    "sha256": receipt["sha256"],
                    "text": visible,
                    "truncated": (
                        decoded is not None and len(visible or "") != len(decoded)
                    ),
                    "size_bytes": len(body),
                }
            )
            if visible is not None:
                remaining -= len(visible)
        return {
            "route_ref": str(route_ref),
            "manifest": manifest,
            "files": files,
        }

    def managed_route_package_files(self, route_ref: str) -> dict[str, bytes]:
        """Return verified immutable package bytes, excluding the host runtime lock."""
        descriptor = self.resolve_managed_route_ref(route_ref)
        payload_root = Path(str(descriptor["payload_root"])).resolve()
        manifest = self._verify_package(payload_root.parent)
        files: dict[str, bytes] = {}
        for receipt in manifest["files"]:
            relative = str(receipt["path"])
            if relative == RUNTIME_LOCK_PATH:
                continue
            body = (payload_root / relative).read_bytes()
            if hashlib.sha256(body).hexdigest() != receipt["sha256"]:
                raise CapabilityRegistryError(
                    f"managed_route_package_file_hash_mismatch:{relative}"
                )
            files[relative] = body
        return files

    def submit_managed_route_revision(
        self,
        base_route_ref: str,
        *,
        payload_files: Mapping[str, bytes],
    ) -> dict[str, Any]:
        """Seal implementation files under one frozen managed Route contract."""
        descriptor = self.resolve_managed_route_ref(base_route_ref)
        payload_root = Path(str(descriptor["payload_root"])).resolve()
        base = self._verify_package(payload_root.parent)
        if base["asset_type"] != "route_package":
            raise CapabilityRegistryError(
                "managed_route_revision_requires_route_package"
            )
        normalized_files = {
            str(path): bytes(body)
            for path, body in payload_files.items()
            if str(path) != RUNTIME_LOCK_PATH
        }
        if not normalized_files:
            raise CapabilityRegistryError("managed_route_revision_files_required")
        manifest = copy.deepcopy(dict(base))
        manifest.update(
            {
                "candidate_kind": "revision",
                "candidate_origin": "task_authored",
                "base_package_hash": str(base["package_hash"]),
                "files": build_file_receipts(normalized_files),
                "package_hash": None,
            }
        )
        validate_candidate_manifest(manifest)
        return self.submit_candidate(manifest, payload_files=normalized_files)

    def pending_skill_root(
        self,
        package_ref: str,
        *,
        candidate_payload: Mapping[str, Any],
    ) -> Path:
        """Resolve one exact locally referenced pending Skill package."""
        validate_capability_candidate_payload(candidate_payload)
        package_dir = self._pending_dir_from_ref(package_ref)
        manifest = self._verify_package(package_dir)
        if manifest["asset_type"] != "skill":
            raise CapabilityRegistryError(
                "pending_skill_resolution_requires_skill_package"
            )
        self._require_artifact_matches_manifest(candidate_payload, manifest)
        return (package_dir / "payload").resolve()

    def candidate_payload_for_package_ref(self, package_ref: str) -> dict[str, Any]:
        """Recreate the exact immutable C2 payload for one pending package."""
        package_dir = self._pending_dir_from_ref(package_ref)
        manifest = self._verify_package(package_dir)
        return capability_candidate_payload(
            manifest,
            package_ref=self._pending_package_ref(manifest),
        )

    def invoke_pending_route(
        self,
        package_ref: str,
        route_name: str,
        route_input: Mapping[str, Any],
        *,
        timeout_seconds: float = 3600.0,
    ) -> dict[str, Any]:
        """Execute one exact pending adapter only inside candidate review."""
        package_dir = self._pending_dir_from_ref(package_ref)
        manifest = self._verify_package(package_dir)
        if manifest["asset_type"] != "route_package":
            raise CapabilityRegistryError(
                "pending_route_execution_requires_route_package"
            )
        matches = [
            route
            for route in manifest["routes"]
            if route["route_name"] == str(route_name)
        ]
        if len(matches) != 1:
            raise CapabilityRegistryError(f"pending_route_not_found:{route_name}")
        route_ref = f"pending_route:{route_name}:{manifest['package_hash']}"
        route = {
            **copy.deepcopy(dict(matches[0])),
            "payload_root": str((package_dir / "payload").resolve()),
            "dependency_lock_path": manifest["dependency_lock_path"],
        }
        return self._execute_adapter(
            route_ref,
            route,
            route_input,
            timeout_seconds=timeout_seconds,
            error_prefix="pending_route",
        )

    def pending_route_ref(self, package_ref: str, route_name: str) -> str:
        """Return one exact pending Route ref from one package ref."""
        package_dir = self._pending_dir_from_ref(package_ref)
        manifest = self._verify_package(package_dir)
        if manifest["asset_type"] != "route_package":
            raise CapabilityRegistryError("pending_route_ref_requires_route_package")
        name = str(route_name)
        matches = [route for route in manifest["routes"] if route["route_name"] == name]
        if len(matches) != 1:
            raise KeyError(f"pending_route_not_found:{name}")
        return f"pending_route:{name}:{manifest['package_hash']}"

    def inspect_python_environment(
        self,
        *,
        environment_ref: str,
        python_code: str,
        caller_skill_id: str,
        timeout_seconds: float,
    ) -> dict[str, Any]:
        """Run read-only diagnostic Python in one exact Route environment."""
        ref = str(environment_ref).strip()
        caller = str(caller_skill_id).strip()
        payload_root, dependency_lock_path, environment_scope = (
            self._resolve_python_environment_ref(ref, caller)
        )

        with tempfile.TemporaryDirectory(
            prefix="python-environment-inspection-",
            dir=str(self.root),
        ) as directory:
            temporary = Path(directory)
            execution_payload_root = temporary / "payload"
            shutil.copytree(payload_root, execution_payload_root)
            inspection_path = temporary / "inspection.py"
            inspection_path.write_text(str(python_code), encoding="utf-8")
            try:
                completed = self.route_executor.inspect_python_environment(
                    payload_root=execution_payload_root,
                    dependency_lock_path=dependency_lock_path,
                    inspection_path=inspection_path,
                    working_directory=temporary,
                    timeout_seconds=float(timeout_seconds),
                    environment_scope=environment_scope,
                )
            except subprocess.TimeoutExpired as exc:
                return {
                    "status": "timed_out",
                    "returncode": None,
                    "stdout": _bounded_process_text(exc.stdout),
                    "stderr": _bounded_process_text(exc.stderr),
                }
            except CapabilityExecutionError as exc:
                return {
                    "status": "failed",
                    "returncode": None,
                    "stdout": "",
                    "stderr": _bounded_process_text(str(exc)),
                }
        return {
            "status": "passed" if completed.returncode == 0 else "failed",
            "returncode": int(completed.returncode),
            "stdout": _bounded_process_text(completed.stdout),
            "stderr": _bounded_process_text(completed.stderr),
        }

    def inspect_python_package_index(
        self,
        *,
        environment_ref: str,
        distribution_name: str,
        caller_skill_id: str,
        timeout_seconds: float = 120.0,
    ) -> dict[str, Any]:
        """Query installable versions from one exact Python runtime."""
        ref = str(environment_ref).strip()
        caller = str(caller_skill_id).strip()
        distribution = str(distribution_name).strip()
        if _PYTHON_DISTRIBUTION_NAME.fullmatch(distribution) is None:
            raise ValueError("python_distribution_name_invalid")
        payload_root, dependency_lock_path, environment_scope = (
            self._resolve_python_environment_ref(ref, caller)
        )
        with tempfile.TemporaryDirectory(
            prefix="python-package-index-",
            dir=str(self.root),
        ) as directory:
            temporary = Path(directory)
            execution_payload_root = temporary / "payload"
            shutil.copytree(payload_root, execution_payload_root)
            try:
                completed = self.route_executor.inspect_python_package_index(
                    payload_root=execution_payload_root,
                    dependency_lock_path=dependency_lock_path,
                    distribution_name=distribution,
                    working_directory=temporary,
                    timeout_seconds=float(timeout_seconds),
                    environment_scope=environment_scope,
                )
            except subprocess.TimeoutExpired as exc:
                return {
                    "status": "timed_out",
                    "distribution_name": distribution,
                    "latest_version": None,
                    "available_versions": [],
                    "stderr": _bounded_process_text(exc.stderr),
                }
            except CapabilityExecutionError as exc:
                return {
                    "status": "failed",
                    "distribution_name": distribution,
                    "latest_version": None,
                    "available_versions": [],
                    "stderr": _bounded_process_text(str(exc)),
                }
        return _python_package_index_payload(distribution, completed)

    def project_environment_descriptor(
        self,
        *,
        environment_ref: str,
        caller_skill_id: str,
    ) -> dict[str, Any]:
        """Resolve one exact managed runtime without invoking its Route API."""
        payload_root, dependency_lock_path, environment_scope = (
            self._resolve_project_environment_ref(
                str(environment_ref).strip(),
                str(caller_skill_id).strip(),
            )
        )
        runtime_lock = validate_runtime_lock(
            payload_root=payload_root,
            dependency_lock_path=dependency_lock_path,
            required=True,
        )
        assert runtime_lock is not None
        return {
            "environment_ref": str(environment_ref).strip(),
            "environment_scope": environment_scope,
            "runtime_kind": runtime_lock["runtime_kind"],
            "base_image_digest": runtime_lock["base_image_digest"],
            "requirements_sha256": runtime_lock["requirements_sha256"],
        }

    @property
    def default_project_environment_ref(self) -> str:
        """Return the infrastructure-owned environment used by coding projects."""
        return self.route_executor.default_project_environment_ref

    def describe_default_project_environment(self) -> str:
        """Read installed distribution metadata in the actual fixed runtime."""
        environment_ref = self.default_project_environment_ref
        probe = (
            "import importlib.metadata as m, json, sys; "
            "print(json.dumps({'python_version':sys.version.split()[0], "
            "'distributions':sorted((d.metadata['Name'], d.version) "
            "for d in m.distributions() if d.metadata['Name'])}))"
        )
        executable = (
            self.route_executor.python_executable
            if isinstance(self.route_executor, LocalPythonExecutor) else "python"
        )
        try:
            with tempfile.TemporaryDirectory(prefix="project-runtime-metadata-") as temp:
                result = self.execute_project_in_default_environment(
                    project_root=Path(temp), entry_command=(executable, "-c", probe),
                    working_directory=".", environment={}, timeout_seconds=30,
                )
            if result.returncode != 0:
                return (
                    f"Fixed runtime: {environment_ref}. Package inventory unavailable "
                    f"(exit {result.returncode}); availability is unknown, not absent."
                )
            metadata = json.loads(result.stdout)
            if not isinstance(metadata, dict) or not isinstance(metadata.get("distributions"), list):
                raise ValueError("invalid_runtime_distribution_metadata")
        except (OSError, ValueError, subprocess.SubprocessError, CapabilityExecutionError) as exc:
            return (
                f"Fixed runtime: {environment_ref}. Package inventory unavailable "
                f"({type(exc).__name__}); availability is unknown, not absent."
            )
        return (
            f"Fixed runtime: {environment_ref}. Installed distribution metadata "
            "(not a guarantee of a working import or successful calculation):\n"
            + json.dumps(metadata, ensure_ascii=False, sort_keys=True)
        )

    def execute_project_in_default_environment(
        self,
        *,
        project_root: Path,
        entry_command: Sequence[str],
        working_directory: str,
        environment: Mapping[str, str],
        timeout_seconds: float,
    ) -> RouteExecutionResult:
        """Run a project without exposing environment selection to its author."""
        return self.route_executor.execute_default_project(
            project_root=Path(project_root).resolve(),
            entry_command=tuple(str(item) for item in entry_command),
            working_directory=str(working_directory),
            environment={str(key): str(value) for key, value in environment.items()},
            timeout_seconds=float(timeout_seconds),
        )

    def default_project_shell_launch(
        self,
        *,
        project_root: Path,
        working_directory: str,
        command: str,
        environment: Mapping[str, str],
        readonly_execution_root: Path | None = None,
    ) -> tuple[list[str], Path, dict[str, str]]:
        """Build one terminal launch in the same fixed project environment."""
        return self.route_executor.default_project_shell_launch(
            project_root=Path(project_root).resolve(),
            working_directory=str(working_directory),
            command=str(command),
            environment={str(key): str(value) for key, value in environment.items()},
            **({"readonly_execution_root": readonly_execution_root}
               if readonly_execution_root is not None else {}),
        )

    def execute_project_in_environment(
        self,
        *,
        environment_ref: str,
        caller_skill_id: str,
        project_root: Path,
        entry_command: Sequence[str],
        working_directory: str,
        environment: Mapping[str, str],
        timeout_seconds: float,
    ) -> RouteExecutionResult:
        """Run a whole project in an exact environment, independent of Routes."""
        payload_root, dependency_lock_path, environment_scope = (
            self._resolve_project_environment_ref(
                str(environment_ref).strip(),
                str(caller_skill_id).strip(),
            )
        )
        return self.route_executor.execute_project(
            payload_root=payload_root,
            dependency_lock_path=dependency_lock_path,
            project_root=Path(project_root).resolve(),
            entry_command=tuple(str(item) for item in entry_command),
            working_directory=str(working_directory),
            environment={str(key): str(value) for key, value in environment.items()},
            timeout_seconds=float(timeout_seconds),
            environment_scope=environment_scope,
        )

    def _resolve_python_environment_ref(
        self,
        ref: str,
        caller: str,
    ) -> tuple[Path, str, str]:
        if ref.startswith("workspace:capability_registry/pending/"):
            if caller not in _PENDING_ENVIRONMENT_INSPECTION_SKILLS:
                raise PermissionError(
                    f"pending_environment_not_visible:{ref}:{caller or 'none'}"
                )
            package_dir = self._pending_dir_from_ref(ref)
            manifest = self._verify_package(package_dir)
            if manifest["asset_type"] != "route_package":
                raise CapabilityRegistryError(
                    "python_environment_inspection_requires_route_package"
                )
            return (
                package_dir / "payload",
                str(manifest["dependency_lock_path"]),
                "pending",
            )
        if ref.startswith("approved_route:"):
            route = self.resolve_route_ref(ref)
            if caller not in route["visible_to_skill_ids"]:
                raise PermissionError(
                    f"approved_environment_not_visible:{ref}:{caller or 'none'}"
                )
            return (
                Path(str(route["payload_root"])).resolve(),
                str(route["dependency_lock_path"]),
                "approved",
            )
        raise CapabilityRegistryError(f"python_environment_ref_invalid:{ref}")

    def _resolve_project_environment_ref(
        self,
        ref: str,
        caller: str,
    ) -> tuple[Path, str, str]:
        if _APPROVED_ROUTE_REF.fullmatch(ref) is not None:
            route = self.resolve_route_ref(ref)
            scope = "approved"
        elif _PENDING_ROUTE_REF.fullmatch(ref) is not None:
            route = self.resolve_managed_route_ref(ref)
            scope = "pending"
        else:
            raise CapabilityRegistryError(f"project_environment_ref_invalid:{ref}")
        if caller not in route["visible_to_skill_ids"]:
            raise PermissionError(
                f"project_environment_not_visible:{ref}:{caller or 'none'}"
            )
        return (
            Path(str(route["payload_root"])).resolve(),
            str(route["dependency_lock_path"]),
            scope,
        )

    def release_pending_python_environment(
        self,
        package_ref: str,
        *,
        timeout_seconds: float = 120.0,
    ) -> dict[str, str]:
        """Release one run-scoped pending Route dependency environment."""
        package_dir = self._pending_dir_from_ref(package_ref)
        manifest = self._verify_package(package_dir)
        if manifest["asset_type"] != "route_package":
            raise CapabilityRegistryError(
                "pending_environment_release_requires_route_package"
            )
        try:
            released = self.route_executor.release_pending_environment(
                payload_root=(package_dir / "payload").resolve(),
                dependency_lock_path=str(manifest["dependency_lock_path"]),
                timeout_seconds=float(timeout_seconds),
            )
        except CapabilityExecutionError as exc:
            raise CapabilityRegistryError(
                f"pending_environment_release_failed:{package_ref}:{exc}"
            ) from exc
        return {"status": "released" if released else "not_present"}

    def record_review_evidence(
        self,
        value: Mapping[str, Any],
    ) -> str:
        """Persist exact candidate-test evidence outside scientific C2."""
        normalized = copy.deepcopy(dict(value))
        digest = hashlib.sha256(
            json.dumps(
                normalized,
                ensure_ascii=False,
                allow_nan=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
        ).hexdigest()
        path = self.reviews_root / "evidence" / f"{digest}.json"
        if path.exists():
            existing = json.loads(path.read_text(encoding="utf-8"))
            if existing != normalized:
                raise CapabilityRegistryError("candidate_review_evidence_hash_conflict")
        else:
            self._write_json_atomic(path, normalized)
        return f"workspace:capability_registry/reviews/evidence/{digest}.json"

    def active_route_summaries(
        self,
        *,
        skill_id: str,
        require_agent_callable: bool = False,
        require_code_callable: bool = False,
    ) -> tuple[dict[str, Any], ...]:
        summaries: list[dict[str, Any]] = []
        for route_name in sorted(self.active()["routes"]):
            route = self.resolve_route_ref(self.approved_route_ref(route_name))
            if skill_id not in route["visible_to_skill_ids"]:
                continue
            if require_agent_callable and not route["agent_callable"]:
                continue
            if require_code_callable and not route["code_callable"]:
                continue
            summaries.append(
                {
                    "route_ref": route["route_ref"],
                    "description": route["description"],
                    "input_schema": copy.deepcopy(route["input_schema"]),
                    "output_schema": copy.deepcopy(route["output_schema"]),
                    "agent_callable": route["agent_callable"],
                    "code_callable": route["code_callable"],
                    "estimated_complexity": route["estimated_complexity"],
                }
            )
        return tuple(summaries)

    def active_route_dependency_summaries(
        self,
    ) -> tuple[dict[str, Any], ...]:
        """Return exact active Route identities for authorized Skill authoring."""
        active = self.active()
        summaries: list[dict[str, Any]] = []
        for route_name, binding in sorted(active["routes"].items()):
            route_ref = self.approved_route_ref(route_name)
            descriptor = self.resolve_route_ref(route_ref)
            summaries.append(
                {
                    "route_name": route_name,
                    "package_hash": str(binding["package_hash"]),
                    "route_ref": route_ref,
                    "description": str(descriptor["description"]),
                    "visible_to_skill_ids": list(descriptor["visible_to_skill_ids"]),
                    "agent_callable": bool(descriptor["agent_callable"]),
                    "code_callable": bool(descriptor["code_callable"]),
                    "approval_state": "approved",
                    "candidate_artifact_ref": None,
                }
            )
        return tuple(summaries)

    def agent_routes(self) -> tuple[Any, ...]:
        """Build normal Route objects only for active agent-callable entries."""
        from ..routes import Route

        routes: list[Route] = []
        active = self.active()
        for route_name in sorted(active["routes"]):
            route_ref = self.approved_route_ref(route_name)
            descriptor = self.resolve_route_ref(route_ref)
            if not descriptor["agent_callable"]:
                continue

            def invoke(
                arguments: Mapping[str, Any],
                skill_id: str | None,
                *,
                exact_ref: str = route_ref,
            ) -> Any:
                if skill_id is None:
                    raise PermissionError(
                        f"approved_route_requires_selected_skill:{exact_ref}"
                    )
                return self.invoke(
                    exact_ref,
                    arguments,
                    caller_skill_id=skill_id,
                )["result"]

            routes.append(
                Route(
                    name=route_name,
                    description=str(descriptor["description"]),
                    parameters=copy.deepcopy(descriptor["input_schema"]),
                    handler=lambda arguments: arguments,
                    skill_ids=tuple(descriptor["visible_to_skill_ids"]),
                    contextual_handler=invoke,
                )
            )
        return tuple(routes)

    def approved_route_ref(self, route_name: str) -> str:
        binding = self.active()["routes"].get(route_name)
        if not isinstance(binding, Mapping):
            raise KeyError(f"active_approved_route_not_found:{route_name}")
        return f"approved_route:{route_name}:{binding['package_hash']}"

    def resolve_route_ref(self, route_ref: str) -> dict[str, Any]:
        match = _APPROVED_ROUTE_REF.fullmatch(str(route_ref))
        if match is None:
            raise CapabilityRegistryError(f"approved_route_ref_invalid:{route_ref}")
        route_name, package_hash = match.groups()
        matches: list[tuple[Path, Mapping[str, Any], Mapping[str, Any]]] = []
        route_packages = self.routes_root / "approved"
        for package_dir in sorted(route_packages.glob(f"*/{package_hash}")):
            manifest = self._verify_package(package_dir)
            for route in manifest["routes"]:
                if route["route_name"] == route_name:
                    matches.append((package_dir, manifest, route))
        if not matches:
            raise KeyError(f"approved_route_ref_not_found:{route_ref}")
        if len(matches) != 1:
            raise CapabilityRegistryError(f"approved_route_ref_ambiguous:{route_ref}")
        package_dir, manifest, route = matches[0]
        return {
            **copy.deepcopy(dict(route)),
            "route_ref": route_ref,
            "package_id": manifest["asset_id"],
            "package_hash": package_hash,
            "payload_root": str((package_dir / "payload").resolve()),
            "dependency_lock_path": manifest["dependency_lock_path"],
        }

    def resolve_managed_route_ref(self, route_ref: str) -> dict[str, Any]:
        """Resolve one exact approved or pending Route identity."""
        raw_ref = str(route_ref)
        if _APPROVED_ROUTE_REF.fullmatch(raw_ref) is not None:
            return self.resolve_route_ref(raw_ref)
        match = _PENDING_ROUTE_REF.fullmatch(raw_ref)
        if match is None:
            raise CapabilityRegistryError(f"managed_route_ref_invalid:{route_ref}")
        route_name, package_hash = match.groups()
        matches: list[tuple[Path, Mapping[str, Any], Mapping[str, Any]]] = []
        for package_dir in sorted(
            (self.routes_root / "pending").glob(f"*/{package_hash}")
        ):
            manifest = self._verify_package(package_dir)
            for route in manifest["routes"]:
                if route["route_name"] == route_name:
                    matches.append((package_dir, manifest, route))
        if not matches:
            raise KeyError(f"pending_route_ref_not_found:{route_ref}")
        if len(matches) != 1:
            raise CapabilityRegistryError(f"pending_route_ref_ambiguous:{route_ref}")
        package_dir, manifest, route = matches[0]
        package_ref = self._pending_package_ref(manifest)
        return {
            **copy.deepcopy(dict(route)),
            "route_ref": raw_ref,
            "package_id": manifest["asset_id"],
            "package_hash": package_hash,
            "package_ref": package_ref,
            "candidate_payload": capability_candidate_payload(
                manifest,
                package_ref=package_ref,
            ),
            "payload_root": str((package_dir / "payload").resolve()),
            "dependency_lock_path": manifest["dependency_lock_path"],
        }

    def invoke(
        self,
        route_ref: str,
        route_input: Mapping[str, Any],
        *,
        caller_skill_id: str,
        require_code_callable: bool = False,
        timeout_seconds: float = 3600.0,
    ) -> dict[str, Any]:
        route = self.resolve_route_ref(route_ref)
        if caller_skill_id not in route["visible_to_skill_ids"]:
            raise PermissionError(
                f"approved_route_not_visible:{route_ref}:{caller_skill_id}"
            )
        callable_key = "code_callable" if require_code_callable else "agent_callable"
        if not route[callable_key]:
            raise PermissionError(f"approved_route_not_{callable_key}:{route_ref}")
        return self._execute_adapter(
            route_ref,
            route,
            route_input,
            timeout_seconds=timeout_seconds,
            error_prefix="approved_route",
        )

    def invoke_managed(
        self,
        route_ref: str,
        route_input: Mapping[str, Any],
        *,
        caller_skill_id: str,
        require_code_callable: bool = False,
        timeout_seconds: float = 3600.0,
    ) -> dict[str, Any]:
        """Invoke one exact approved or eligible task-bound pending Route."""
        raw_ref = str(route_ref)
        if _APPROVED_ROUTE_REF.fullmatch(raw_ref) is not None:
            return self.invoke(
                raw_ref,
                route_input,
                caller_skill_id=caller_skill_id,
                require_code_callable=require_code_callable,
                timeout_seconds=timeout_seconds,
            )
        route = self.resolve_managed_route_ref(raw_ref)
        if caller_skill_id not in route["visible_to_skill_ids"]:
            raise PermissionError(
                f"pending_route_not_visible:{raw_ref}:{caller_skill_id}"
            )
        callable_key = "code_callable" if require_code_callable else "agent_callable"
        if not route[callable_key]:
            raise PermissionError(f"pending_route_not_{callable_key}:{raw_ref}")
        return self._execute_adapter(
            raw_ref,
            route,
            route_input,
            timeout_seconds=timeout_seconds,
            error_prefix="pending_route",
        )

    def _execute_adapter(
        self,
        route_ref: str,
        route: Mapping[str, Any],
        route_input: Mapping[str, Any],
        *,
        timeout_seconds: float,
        error_prefix: str,
    ) -> dict[str, Any]:
        normalized_input = copy.deepcopy(dict(route_input))
        input_issues = json_schema_issues(normalized_input, route["input_schema"])
        if input_issues:
            raise CapabilityRegistryError(
                f"{error_prefix}_input_invalid:{route_ref}:{input_issues}"
            )

        payload_root = Path(str(route["payload_root"])).resolve()
        with tempfile.TemporaryDirectory(
            prefix=f"{error_prefix.replace('_', '-')}-", dir=str(self.root)
        ) as directory:
            temporary = Path(directory)
            execution_payload_root = temporary / "payload"
            shutil.copytree(payload_root, execution_payload_root)
            input_path = temporary / "input.json"
            output_path = temporary / "output.json"
            input_path.write_text(
                json.dumps(
                    normalized_input,
                    ensure_ascii=False,
                    allow_nan=False,
                    sort_keys=True,
                ),
                encoding="utf-8",
            )
            try:
                completed = self.route_executor.execute(
                    payload_root=execution_payload_root,
                    dependency_lock_path=str(route["dependency_lock_path"]),
                    adapter_entrypoint=str(route["adapter_entrypoint"]),
                    input_path=input_path,
                    output_path=output_path,
                    route_token=hashlib.sha256(route_ref.encode("utf-8")).hexdigest()[
                        :16
                    ],
                    working_directory=temporary,
                    timeout_seconds=float(timeout_seconds),
                    environment_scope=(
                        "pending" if error_prefix == "pending_route" else "approved"
                    ),
                )
            except CapabilityExecutionError as exc:
                raise CapabilityRegistryError(
                    f"{error_prefix}_execution_setup_failed:{route_ref}:{exc}"
                ) from exc
            if completed.returncode != 0:
                raise CapabilityRegistryError(
                    f"{error_prefix}_execution_failed:"
                    f"{route_ref}:{completed.returncode}:"
                    f"{completed.stderr[-4000:]}"
                )
            if not output_path.is_file():
                raise CapabilityRegistryError(
                    f"{error_prefix}_output_missing:{route_ref}"
                )
            try:
                route_output = json.loads(output_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError as exc:
                raise CapabilityRegistryError(
                    f"{error_prefix}_output_not_json:{route_ref}:{exc}"
                ) from exc
        output_issues = json_schema_issues(route_output, route["output_schema"])
        if output_issues:
            raise CapabilityRegistryError(
                f"{error_prefix}_output_invalid:{route_ref}:{output_issues}"
            )
        return {
            "result": route_output,
            "stdout": completed.stdout[-4000:],
            "stderr": completed.stderr[-4000:],
        }

    def _pending_dir_from_ref(self, package_ref: str) -> Path:
        prefix = "workspace:capability_registry/pending/"
        raw = str(package_ref)
        if not raw.startswith(prefix):
            raise CapabilityRegistryError(f"pending_package_ref_invalid:{package_ref}")
        parts = raw[len(prefix) :].split("/")
        if len(parts) != 3:
            raise CapabilityRegistryError(f"pending_package_ref_invalid:{package_ref}")
        category, asset_id, package_hash = parts
        asset_type = {
            "skills": "skill",
            "route_packages": "route_package",
        }.get(category)
        if asset_type is None:
            raise CapabilityRegistryError(f"pending_package_ref_invalid:{package_ref}")
        return self._package_dir(
            "pending",
            asset_type,
            asset_id,
            package_hash,
        )

    def _activate_skill(
        self,
        active: dict[str, Any],
        manifest: Mapping[str, Any],
        *,
        reserved_skill_ids: set[str],
        baseline_skill_hashes: Mapping[str, str],
    ) -> None:
        skill_id = str(manifest["asset_id"])
        current = active["skills"].get(
            skill_id,
            baseline_skill_hashes.get(skill_id),
        )
        if manifest["candidate_kind"] == "new":
            if current is not None or skill_id in reserved_skill_ids:
                raise CapabilityRegistryError(f"new_skill_name_conflict:{skill_id}")
        elif current != manifest["base_package_hash"]:
            raise CapabilityRegistryError(f"skill_revision_base_not_active:{skill_id}")
        active["skills"][skill_id] = manifest["package_hash"]

    def _activate_route_package(
        self,
        active: dict[str, Any],
        manifest: Mapping[str, Any],
        *,
        reserved_route_names: set[str],
    ) -> None:
        package_id = str(manifest["asset_id"])
        new_names = set(route_names(manifest))
        current_routes = active["routes"]
        if manifest["candidate_kind"] == "new":
            conflicts = sorted(new_names & (set(current_routes) | reserved_route_names))
            if conflicts:
                raise CapabilityRegistryError(f"new_route_name_conflict:{conflicts}")
        else:
            base_hash = manifest["base_package_hash"]
            replaced = {
                route_name
                for route_name, binding in current_routes.items()
                if binding["package_id"] == package_id
                and binding["package_hash"] == base_hash
            }
            base_is_pending = False
            if not replaced:
                pending_base = self._package_dir(
                    "pending",
                    "route_package",
                    package_id,
                    str(base_hash),
                )
                if pending_base.is_dir():
                    self._verify_package(pending_base)
                    base_is_pending = True
                else:
                    raise CapabilityRegistryError(
                        f"route_revision_base_not_active_or_pending:{package_id}"
                    )
            unrelated = set(current_routes) - replaced
            conflicts = sorted(new_names & (unrelated | reserved_route_names))
            if conflicts:
                raise CapabilityRegistryError(
                    f"route_revision_name_conflict:{conflicts}"
                )
            if not base_is_pending:
                for route_name in replaced:
                    del current_routes[route_name]
        binding = {
            "package_id": package_id,
            "package_hash": manifest["package_hash"],
        }
        for route_name in sorted(new_names):
            current_routes[route_name] = copy.deepcopy(binding)

    def _require_approved_dependencies(self, manifest: Mapping[str, Any]) -> None:
        if manifest["asset_type"] != "skill":
            return
        for dependency in manifest["route_dependencies"]:
            route_ref = (
                f"approved_route:{dependency['route_name']}:"
                f"{dependency['package_hash']}"
            )
            self.resolve_route_ref(route_ref)

    def _require_artifact_matches_manifest(
        self,
        artifact: Mapping[str, Any],
        manifest: Mapping[str, Any],
    ) -> None:
        expected = capability_candidate_payload(
            manifest,
            package_ref=self._pending_package_ref(manifest),
        )
        if dict(artifact) != expected:
            raise CapabilityRegistryError("candidate_artifact_manifest_mismatch")

    def _verify_package(self, package_dir: Path) -> dict[str, Any]:
        package_dir = package_dir.resolve()
        if not package_dir.is_relative_to(self.root) or not package_dir.is_dir():
            raise CapabilityRegistryError(
                f"candidate_package_directory_missing:{package_dir}"
            )
        manifest_path = package_dir / "candidate.json"
        payload_root = package_dir / "payload"
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise CapabilityRegistryError(
                f"candidate_manifest_unreadable:{package_dir}:{exc}"
            ) from exc
        validate_candidate_manifest(manifest)
        actual_files: dict[str, bytes] = {}
        for path in sorted(payload_root.rglob("*")):
            if path.is_symlink():
                raise CapabilityRegistryError(
                    f"candidate_payload_symlink_forbidden:{path}"
                )
            if path.is_file():
                relative = path.relative_to(payload_root).as_posix()
                actual_files[relative] = path.read_bytes()
        if build_file_receipts(actual_files) != manifest["files"]:
            raise CapabilityRegistryError(
                f"candidate_payload_receipt_mismatch:{package_dir}"
            )
        if manifest["asset_type"] == "route_package":
            try:
                validate_runtime_lock(
                    payload_root=payload_root,
                    dependency_lock_path=str(manifest["dependency_lock_path"]),
                    required=False,
                )
            except CapabilityExecutionError as exc:
                raise CapabilityRegistryError(str(exc)) from exc
        elif RUNTIME_LOCK_PATH in actual_files:
            raise CapabilityRegistryError("skill_package_runtime_lock_forbidden")
        expected_hash = candidate_package_hash(manifest)
        if manifest["package_hash"] != expected_hash:
            raise CapabilityRegistryError(
                f"candidate_package_hash_mismatch:{package_dir}"
            )
        if package_dir.name != expected_hash:
            raise CapabilityRegistryError(
                f"candidate_package_directory_hash_mismatch:{package_dir}"
            )
        return copy.deepcopy(dict(manifest))

    def _pending_package_ref(self, manifest: Mapping[str, Any]) -> str:
        category = _CATEGORY[str(manifest["asset_type"])]
        return (
            "workspace:capability_registry/pending/"
            f"{category}/{manifest['asset_id']}/{manifest['package_hash']}"
        )

    def _package_dir(
        self,
        state: str,
        asset_type: str,
        asset_id: str,
        package_hash: str,
    ) -> Path:
        if state not in {"pending", "approved"}:
            raise CapabilityRegistryError("capability_package_state_invalid")
        category = _PHYSICAL_CATEGORY.get(asset_type)
        if category is None or not _asset_id(asset_id) or not _sha256(package_hash):
            raise CapabilityRegistryError("capability_package_identity_invalid")
        base = self.root / category / state
        path = (base / asset_id / package_hash).resolve()
        if not path.is_relative_to(base.resolve()):
            raise CapabilityRegistryError("capability_package_path_escape")
        return path

    def _refresh_human_catalog(self) -> None:
        active = self.active()
        rows: list[tuple[str, ...]] = []
        seen_packages: set[tuple[str, str, str]] = set()
        for asset_type in ("route_package", "skill"):
            category = _PHYSICAL_CATEGORY[asset_type]
            for state in ("approved", "pending"):
                state_root = self.root / category / state
                for manifest_path in sorted(state_root.glob("*/*/candidate.json")):
                    package_dir = manifest_path.parent
                    manifest = self._verify_package(package_dir)
                    package_hash = str(manifest["package_hash"])
                    asset_id = str(manifest["asset_id"])
                    package_key = (asset_type, asset_id, package_hash)
                    if package_key in seen_packages:
                        continue
                    seen_packages.add(package_key)
                    exposed_names = (
                        ", ".join(route_names(manifest))
                        if asset_type == "route_package"
                        else asset_id
                    )
                    is_active = self._manifest_is_active(
                        manifest,
                        active=active,
                    )
                    approval = self._approval_summary(
                        asset_type=asset_type,
                        asset_id=asset_id,
                        package_hash=package_hash,
                    )
                    rows.append(
                        (
                            "Route 套件" if asset_type == "route_package" else "Skill",
                            asset_id,
                            "active" if is_active else state,
                            exposed_names,
                            package_hash,
                            str(manifest.get("base_package_hash") or "-"),
                            str(manifest.get("candidate_origin") or "-"),
                            approval,
                            package_dir.relative_to(self.root).as_posix(),
                        )
                    )

        lines = [
            "# 受管能力目錄",
            "",
            "本檔由專案能力登錄器自動產生，請勿手動編輯。",
            "",
            "- `active`：已核准，會由 `active.json` 提供給一般研究流程。",
            "- `approved`：已核准但目前未被選為生效版本。",
            "- `pending`：尚未核准；只有某次任務明確持有完全相符的 "
            "`capability_candidate` artifact 時，才能在該任務內帶 lineage 使用。",
            "",
            "| 種類 | 套件 | 狀態 | 對外名稱 | 套件 hash | "
            "基底 hash | 來源 | 人類核准者 | 實體位置 |",
            "| --- | --- | --- | --- | --- | --- | --- | --- | --- |",
        ]
        if rows:
            lines.extend(
                "| " + " | ".join(_markdown_cell(value) for value in row) + " |"
                for row in rows
            )
        else:
            lines.append("| - | - | empty | - | - | - | - | - | - |")
        lines.extend(
            [
                "",
                "全域核准能力以 `active.json` 為權威；任務內 pending 能力的權威是"
                "該任務可見、內容與套件完全相符的 `capability_candidate` artifact。"
                "本檔只做人類可讀盤點，不授予執行權。",
                "",
            ]
        )
        self._write_text_atomic(self.catalog_path, "\n".join(lines))

    def _manifest_is_active(
        self,
        manifest: Mapping[str, Any],
        *,
        active: Mapping[str, Any],
    ) -> bool:
        package_hash = str(manifest["package_hash"])
        if manifest["asset_type"] == "skill":
            return active["skills"].get(manifest["asset_id"]) == package_hash
        package_id = str(manifest["asset_id"])
        names = route_names(manifest)
        return bool(names) and all(
            active["routes"].get(name)
            == {"package_id": package_id, "package_hash": package_hash}
            for name in names
        )

    def _approval_summary(
        self,
        *,
        asset_type: str,
        asset_id: str,
        package_hash: str,
    ) -> str:
        receipt_path = self.approvals_root / (
            f"{asset_type}-{asset_id}-{package_hash}.json"
        )
        if not receipt_path.is_file():
            return "-"
        try:
            receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return "invalid receipt"
        return str(receipt.get("approved_by") or "approved")

    @staticmethod
    def _write_json_atomic(path: Path, value: Mapping[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(
            json.dumps(value, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, path)

    @staticmethod
    def _write_text_atomic(path: Path, value: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(value, encoding="utf-8")
        os.replace(temporary, path)

    def _write_package_atomic(
        self,
        package_dir: Path,
        *,
        manifest: Mapping[str, Any],
        payload_files: Mapping[str, bytes],
    ) -> None:
        package_dir.parent.mkdir(parents=True, exist_ok=True)
        temporary = package_dir.parent / f".{package_dir.name}.tmp"
        if temporary.exists():
            shutil.rmtree(temporary)
        try:
            payload_root = temporary / "payload"
            payload_root.mkdir(parents=True)
            for relative, body in payload_files.items():
                normalized = next(
                    item["path"] for item in build_file_receipts({relative: body})
                )
                target = (payload_root / normalized).resolve()
                if not target.is_relative_to(payload_root.resolve()):
                    raise CapabilityRegistryError("candidate_payload_path_escape")
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(body)
            self._write_json_atomic(temporary / "candidate.json", manifest)
            _replace_package_directory(temporary, package_dir)
        except Exception:
            if temporary.exists():
                shutil.rmtree(temporary)
            raise

    @staticmethod
    def _copy_package_atomic(source: Path, destination: Path) -> None:
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.parent / f".{destination.name}.tmp"
        if temporary.exists():
            shutil.rmtree(temporary)
        try:
            shutil.copytree(source, temporary)
            _replace_package_directory(temporary, destination)
        except Exception:
            if temporary.exists():
                shutil.rmtree(temporary)
            raise


def _replace_package_directory(source: Path, destination: Path) -> None:
    """Retry transient Windows directory locks without changing package bytes."""
    for attempt in range(len(_PACKAGE_DIRECTORY_REPLACE_RETRY_DELAYS) + 1):
        try:
            os.replace(source, destination)
            return
        except PermissionError:
            if attempt >= len(_PACKAGE_DIRECTORY_REPLACE_RETRY_DELAYS):
                raise
            time.sleep(_PACKAGE_DIRECTORY_REPLACE_RETRY_DELAYS[attempt])


def _artifact_payload(
    artifact: Mapping[str, Any], expected_kind: str
) -> tuple[str, Mapping[str, Any]]:
    if not isinstance(artifact, Mapping):
        raise CapabilityRegistryError(f"{expected_kind}_artifact_invalid")
    artifact_ref = str(artifact.get("artifact_ref") or "")
    payload = artifact.get("machine_payload")
    if (
        not artifact_ref.startswith("artifact:")
        or artifact.get("artifact_kind") != expected_kind
        or not isinstance(payload, Mapping)
    ):
        raise CapabilityRegistryError(f"{expected_kind}_artifact_invalid")
    return artifact_ref, payload


def _bounded_process_text(value: Any, *, max_chars: int = 12_000) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        text = value.decode("utf-8", errors="replace")
    else:
        text = str(value)
    return text[-max_chars:]


def _markdown_cell(value: Any) -> str:
    return str(value).replace("|", "\\|").replace("\r", " ").replace("\n", " ")


def _python_package_index_payload(
    distribution_name: str,
    completed: RouteExecutionResult,
) -> dict[str, Any]:
    stdout = str(completed.stdout or "")
    stderr = _bounded_process_text(completed.stderr)
    combined = (stdout + "\n" + stderr).lower()
    if "no matching distribution found for" in combined:
        return {
            "status": "not_found",
            "distribution_name": distribution_name,
            "latest_version": None,
            "available_versions": [],
            "stderr": stderr,
        }
    if int(completed.returncode) != 0:
        return {
            "status": "failed",
            "distribution_name": distribution_name,
            "latest_version": None,
            "available_versions": [],
            "stderr": stderr,
        }

    latest_version: str | None = None
    versions: list[str] = []
    for raw_line in stdout.splitlines():
        line = raw_line.strip()
        if line.startswith("Available versions:"):
            versions.extend(
                item.strip()
                for item in line.partition(":")[2].split(",")
                if item.strip()
            )
            continue
        header = re.fullmatch(r".+?\s+\(([^()]+)\)", line)
        if header is not None and latest_version is None:
            latest_version = header.group(1).strip() or None
    versions = list(dict.fromkeys(versions))
    if latest_version is None and versions:
        latest_version = versions[0]
    if latest_version is None or not versions:
        diagnostic = "python_package_index_output_unparseable"
        return {
            "status": "failed",
            "distribution_name": distribution_name,
            "latest_version": None,
            "available_versions": [],
            "stderr": (stderr + "\n" + diagnostic).strip(),
        }
    return {
        "status": "found",
        "distribution_name": distribution_name,
        "latest_version": latest_version,
        "available_versions": versions,
        "stderr": stderr,
    }


def _asset_id(value: Any) -> bool:
    return bool(re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,79}", str(value or "")))


def _sha256(value: Any) -> bool:
    return bool(re.fullmatch(r"[0-9a-f]{64}", str(value or "")))
