from __future__ import annotations

import copy
import json
import os
import shutil
import subprocess
import threading
import time
import uuid

from pathlib import Path
from typing import Any, Mapping, Sequence

from .registry import CapabilityRegistry, CapabilityRegistryError


class ManagedRouteBrokerSessions:
    """Create exact JSON broker bindings usable from any implementation language."""

    def __init__(
        self,
        root: Path,
        *,
        registry: CapabilityRegistry,
    ) -> None:
        self.root = (root.resolve() / "managed-route-brokers").resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.registry = registry
        self.script_path = (
            Path(__file__).resolve().parent / "invocation_broker.py"
        ).resolve()
        self.project_client_path = (
            Path(__file__).resolve().parent / "project_broker_client.py"
        ).resolve()

    def create(
        self,
        *,
        route_refs: Sequence[str],
        caller_skill_id: str,
        require_code_callable: bool,
        max_route_calls: int,
        timeout_seconds: float,
    ) -> dict[str, Any]:
        caller = str(caller_skill_id).strip()
        if not caller:
            raise CapabilityRegistryError("managed_broker_caller_skill_required")
        if (
            isinstance(max_route_calls, bool)
            or not isinstance(max_route_calls, int)
            or not 1 <= max_route_calls <= 10_000
        ):
            raise CapabilityRegistryError("managed_broker_call_quota_invalid")
        if not 1.0 <= float(timeout_seconds) <= 86_400.0:
            raise CapabilityRegistryError("managed_broker_timeout_invalid")
        normalized_refs = tuple(
            dict.fromkeys(str(ref).strip() for ref in route_refs if str(ref).strip())
        )
        if not normalized_refs:
            raise CapabilityRegistryError("managed_broker_route_refs_required")
        routes: dict[str, Any] = {}
        for route_ref in normalized_refs:
            descriptor = self.registry.resolve_managed_route_ref(route_ref)
            if caller not in descriptor.get("visible_to_skill_ids", ()):
                raise PermissionError(
                    f"managed_broker_route_not_visible:{route_ref}:{caller}"
                )
            callable_key = (
                "code_callable" if require_code_callable else "agent_callable"
            )
            if descriptor.get(callable_key) is not True:
                raise PermissionError(
                    f"managed_broker_route_not_{callable_key}:{route_ref}"
                )
            routes[route_ref] = {
                "input_schema": copy.deepcopy(descriptor["input_schema"]),
                "output_schema": copy.deepcopy(descriptor["output_schema"]),
                "approval_state": (
                    "pending" if route_ref.startswith("pending_route:") else "approved"
                ),
                "package_hash": str(descriptor["package_hash"]),
                "package_ref": descriptor.get("package_ref"),
            }
        broker_id = uuid.uuid4().hex[:16]
        broker_root = self.root / broker_id
        broker_root.mkdir(parents=True, exist_ok=False)
        ledger_path = broker_root / "ledger.json"
        _write_json(ledger_path, {"calls": []})
        binding = {
            "schema_version": 1,
            "mode": "record",
            "broker": self.registry.invocation_broker_spec(
                timeout_seconds=float(timeout_seconds)
            ),
            "caller_skill_id": caller,
            "require_code_callable": bool(require_code_callable),
            "max_route_calls": max_route_calls,
            "routes": routes,
            "ledger_path": str(ledger_path),
        }
        binding_path = broker_root / "binding.json"
        _write_json(binding_path, binding)
        return self._binding_receipt(
            binding_path=binding_path,
            binding=binding,
            broker_id=broker_id,
            route_refs=normalized_refs,
        )

    def create_replay(self, record_binding_path: Path) -> dict[str, Any]:
        """Create a second binding that replays the exact first-run Route calls."""
        record_binding = self._owned_binding(record_binding_path)
        if record_binding.get("mode", "record") != "record":
            raise CapabilityRegistryError("managed_broker_record_binding_required")
        ledger_path = Path(str(record_binding.get("ledger_path") or "")).resolve()
        if not ledger_path.is_relative_to(Path(record_binding_path).resolve().parent):
            raise CapabilityRegistryError("managed_broker_record_ledger_invalid")
        ledger = _read_json(ledger_path)
        calls = ledger.get("calls")
        if not isinstance(calls, list) or not calls:
            raise CapabilityRegistryError("managed_broker_record_calls_required")
        if any(
            not isinstance(item, Mapping)
            or not isinstance(item.get("receipt"), Mapping)
            or not isinstance(item.get("response"), Mapping)
            for item in calls
        ):
            raise CapabilityRegistryError("managed_broker_record_calls_invalid")

        broker_id = uuid.uuid4().hex[:16]
        broker_root = self.root / broker_id
        broker_root.mkdir(parents=True, exist_ok=False)
        source_ledger_path = broker_root / "source-ledger.json"
        _write_json(source_ledger_path, {"calls": copy.deepcopy(calls)})
        replay_ledger_path = broker_root / "ledger.json"
        _write_json(replay_ledger_path, {"calls": []})
        binding = copy.deepcopy(record_binding)
        binding.update(
            {
                "mode": "sequence_replay",
                "max_route_calls": len(calls),
                "ledger_path": str(replay_ledger_path),
                "replay_source_ledger_path": str(source_ledger_path),
            }
        )
        binding_path = broker_root / "binding.json"
        _write_json(binding_path, binding)
        return self._binding_receipt(
            binding_path=binding_path,
            binding=binding,
            broker_id=broker_id,
            route_refs=tuple(str(ref) for ref in binding["routes"]),
        )

    def read_ledger(self, binding_path: Path) -> dict[str, Any]:
        binding = self._owned_binding(binding_path)
        ledger_path = Path(str(binding.get("ledger_path") or "")).resolve()
        if not ledger_path.is_relative_to(Path(binding_path).resolve().parent):
            raise CapabilityRegistryError("managed_broker_ledger_not_owned")
        ledger = _read_json(ledger_path)
        calls = ledger.get("calls")
        if not isinstance(calls, list):
            raise CapabilityRegistryError("managed_broker_ledger_invalid")
        return copy.deepcopy(ledger)

    def project_bridge(
        self,
        binding_path: Path,
        *,
        shared_control_root: Path,
        timeout_seconds: float,
    ) -> "ManagedRouteProjectBridge":
        """Bridge one container project to the existing host Route broker."""
        binding = Path(binding_path).resolve()
        self._owned_binding(binding)
        return ManagedRouteProjectBridge(
            sessions=self,
            binding_path=binding,
            shared_control_root=Path(shared_control_root).resolve(),
            timeout_seconds=float(timeout_seconds),
        )

    def _binding_receipt(
        self,
        *,
        binding_path: Path,
        binding: Mapping[str, Any],
        broker_id: str,
        route_refs: Sequence[str],
    ) -> dict[str, Any]:
        return {
            "status": "managed_route_broker_ready",
            "broker_id": broker_id,
            "binding_path": str(binding_path),
            "broker_script_path": str(self.script_path),
            "python_executable": self.registry.python_executable,
            "route_refs": list(route_refs),
            "mode": str(binding.get("mode") or "record"),
            "max_route_calls": int(binding["max_route_calls"]),
            "request_contract": {
                "route_ref": "one exact bound route ref",
                "payload": "one JSON object matching that Route input schema",
            },
            "command_argv_prefix": [
                self.registry.python_executable,
                "-I",
                "-B",
                str(self.script_path),
                str(binding_path),
            ],
        }

    def _owned_binding(self, binding_path: Path) -> dict[str, Any]:
        binding = Path(binding_path).resolve()
        if not binding.is_relative_to(self.root) or not binding.is_file():
            raise CapabilityRegistryError("managed_broker_binding_not_owned")
        return _read_json(binding)

    def invoke(
        self,
        binding_path: Path,
        *,
        route_ref: str,
        payload: Mapping[str, Any],
        timeout_seconds: float,
    ) -> dict[str, Any]:
        """Small deterministic helper for tests and runtime-owned preflights."""
        binding = Path(binding_path).resolve()
        if not binding.is_relative_to(self.root) or not binding.is_file():
            raise CapabilityRegistryError("managed_broker_binding_not_owned")
        broker_root = binding.parent
        call_id = uuid.uuid4().hex[:16]
        request_path = broker_root / f"request-{call_id}.json"
        response_path = broker_root / f"response-{call_id}.json"
        _write_json(
            request_path,
            {"route_ref": str(route_ref), "payload": copy.deepcopy(dict(payload))},
        )
        completed = subprocess.run(
            [
                self.registry.python_executable,
                "-I",
                "-B",
                str(self.script_path),
                str(binding),
                str(request_path),
                str(response_path),
            ],
            cwd=str(broker_root),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=float(timeout_seconds),
            check=False,
        )
        if completed.returncode != 0:
            raise CapabilityRegistryError(
                "managed_broker_invocation_failed:"
                f"returncode={completed.returncode}:"
                f"stderr={completed.stderr[-4000:]}"
            )
        if not response_path.is_file():
            raise CapabilityRegistryError("managed_broker_response_missing")
        response = json.loads(response_path.read_text(encoding="utf-8"))
        if not isinstance(response, dict):
            raise CapabilityRegistryError("managed_broker_response_invalid")
        return response


class ManagedRouteProjectBridge:
    """Serve file-based Route requests from one mounted project workspace."""

    def __init__(
        self,
        *,
        sessions: ManagedRouteBrokerSessions,
        binding_path: Path,
        shared_control_root: Path,
        timeout_seconds: float,
    ) -> None:
        if not 1.0 <= timeout_seconds <= 86_400.0:
            raise CapabilityRegistryError("managed_project_bridge_timeout_invalid")
        self.sessions = sessions
        self.binding_path = binding_path
        self.shared_control_root = shared_control_root
        self.timeout_seconds = timeout_seconds
        self.mailbox_root = shared_control_root / "managed-route-mailbox"
        self.client_path = shared_control_root / "managed-route-client.py"
        self.command_argv_prefix = [
            "python",
            "/workspace/control/managed-route-client.py",
            "/workspace/control/managed-route-mailbox",
        ]
        self._stop = threading.Event()
        self._service_error: BaseException | None = None
        self._thread: threading.Thread | None = None

    def __enter__(self) -> "ManagedRouteProjectBridge":
        self.shared_control_root.mkdir(parents=True, exist_ok=True)
        self.mailbox_root.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(self.sessions.project_client_path, self.client_path)
        self._thread = threading.Thread(
            target=self._serve,
            name="managed-route-project-bridge",
            daemon=True,
        )
        self._thread.start()
        return self

    def __exit__(self, exc_type: Any, _exc: Any, _traceback: Any) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5.0)
            if self._thread.is_alive() and exc_type is None:
                raise CapabilityRegistryError("managed_project_bridge_shutdown_timeout")
        if self._service_error is not None and exc_type is None:
            raise CapabilityRegistryError(
                f"managed_project_bridge_failed:{self._service_error}"
            ) from self._service_error

    def _serve(self) -> None:
        try:
            while not self._stop.is_set() or self._pending_requests():
                handled = False
                for request_path in sorted(self.mailbox_root.glob("request-*.json")):
                    if self._handle_request(request_path):
                        handled = True
                if not handled:
                    time.sleep(0.02)
        except BaseException as exc:
            self._service_error = exc

    def _pending_requests(self) -> bool:
        return next(self.mailbox_root.glob("request-*.json"), None) is not None

    def _handle_request(self, request_path: Path) -> bool:
        call_id = request_path.stem.removeprefix("request-")
        if not call_id or any(char not in "0123456789abcdef" for char in call_id):
            request_path.unlink(missing_ok=True)
            return True
        processing_path = self.mailbox_root / f"processing-{call_id}.json"
        try:
            os.replace(request_path, processing_path)
        except FileNotFoundError:
            return False
        response_path = self.mailbox_root / f"response-{call_id}.json"
        try:
            request = _read_json(processing_path)
            if set(request) != {"route_ref", "payload"} or not isinstance(
                request.get("payload"), Mapping
            ):
                raise CapabilityRegistryError("managed_project_bridge_request_invalid")
            response = self.sessions.invoke(
                self.binding_path,
                route_ref=str(request["route_ref"]),
                payload=dict(request["payload"]),
                timeout_seconds=self.timeout_seconds,
            )
        except BaseException as exc:
            response = {
                "__bridge_error__": f"{type(exc).__name__}:{exc}",
            }
        finally:
            processing_path.unlink(missing_ok=True)
        _write_json(response_path, response)
        return True


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise CapabilityRegistryError(
            f"managed_broker_json_invalid:{path.name}"
        ) from exc
    if not isinstance(value, dict):
        raise CapabilityRegistryError(
            f"managed_broker_json_object_required:{path.name}"
        )
    return value
