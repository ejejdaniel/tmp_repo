from __future__ import annotations

import copy
import hashlib
import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, Mapping, Sequence

from ..routes import Route
if TYPE_CHECKING:
    from ..development.projects import DevelopmentProjectStore
from .manifests import (
    CAPABILITY_REVIEW_CHECK_SUMMARY_MAX_CHARS,
    build_file_receipts,
    normalize_payload_path,
    validate_candidate_manifest,
)
from .registry import CapabilityRegistry, CapabilityRegistryError


_AUTHORING_SKILLS = (
    "skill-optimization",
    "skill-creation",
    "skill-onboarding",
    "route-creation",
    "python-package-resolver",
    "route-onboarding",
)
_REVIEW_SKILLS = ("candidate-review",)


class CapabilityDevelopmentRoutes:
    """Controlled pending-package operations available only behind meta skills."""

    def __init__(
        self,
        registry: CapabilityRegistry,
        *,
        source_roots: Sequence[Path],
        production_skills_root: Path,
        skill_validator_path: Path,
        development_projects: "DevelopmentProjectStore | None" = None,
    ) -> None:
        self._registry = registry
        self._source_roots = tuple(
            dict.fromkeys(Path(root).resolve() for root in source_roots)
        )
        self._production_skills_root = production_skills_root.resolve()
        self._skill_validator_path = skill_validator_path.resolve()
        self._development_projects = development_projects

    def routes(self) -> tuple[Route, ...]:
        routes = [
            Route(
                name="capability_candidate_submit",
                description=(
                    "Seal one exact Skill or Route-package candidate in the "
                    "pending registry. It never approves or activates it."
                ),
                parameters=_SUBMIT_SCHEMA,
                handler=self._submit,
                skill_ids=_AUTHORING_SKILLS,
            ),
            Route(
                name="capability_active_route_dependency_catalog",
                description=(
                    "Read exact active Route names, package hashes, callable "
                    "metadata, and Skill visibility for one pending Skill "
                    "authoring decision. It cannot invoke or modify a Route."
                ),
                parameters={
                    "type": "object",
                    "properties": {},
                    "additionalProperties": False,
                },
                handler=lambda _arguments: {
                    "routes": list(
                        self._registry.active_route_dependency_summaries()
                    )
                },
                skill_ids=("skill-creation",),
            ),
            Route(
                name="capability_skill_baseline_snapshot",
                description=(
                    "Read the exact current source and hash of one production "
                    "Skill for a bounded optimization candidate."
                ),
                parameters={
                    "type": "object",
                    "properties": {"skill_id": {"type": "string"}},
                    "required": ["skill_id"],
                    "additionalProperties": False,
                },
                handler=self._skill_baseline_snapshot,
                skill_ids=("skill-optimization",),
            ),
            Route(
                name="capability_candidate_snapshot",
                description=(
                    "Read one exact pending candidate manifest and bounded "
                    "source snapshot for review."
                ),
                parameters=_PACKAGE_REF_SCHEMA,
                handler=lambda arguments: self._registry.pending_candidate_snapshot(
                    str(arguments["package_ref"])
                ),
                skill_ids=(
                    *_REVIEW_SKILLS,
                    "skill-creation",
                    "route-creation",
                    "python-package-resolver",
                ),
            ),
            Route(
                name="capability_candidate_test",
                description=(
                    "Run structural checks and exact small Route contract "
                    "executions in the pending-candidate sandbox."
                ),
                parameters=_TEST_SCHEMA,
                handler=self._test_candidate,
                skill_ids=(
                    *_REVIEW_SKILLS,
                    "route-creation",
                    "python-package-resolver",
                ),
            ),
            Route(
                name="capability_pending_environment_release",
                description=(
                    "Release the temporary Docker venv used to test one exact "
                    "pending Route package. This does not alter the package."
                ),
                parameters=_PACKAGE_REF_SCHEMA,
                handler=lambda arguments: (
                    self._registry.release_pending_python_environment(
                        str(arguments["package_ref"])
                    )
                ),
                skill_ids=(
                    *_REVIEW_SKILLS,
                    "route-creation",
                    "python-package-resolver",
                ),
            ),
            Route(
                name="inspect_python_package_index",
                description=(
                    "Query the Python package index for exact installable "
                    "versions of one proposed distribution from the pinned "
                    "interpreter used by one visible Route environment. It "
                    "does not install packages or alter the candidate."
                ),
                parameters=_PACKAGE_INDEX_SCHEMA,
                handler=self._inspect_python_package_index,
                skill_ids=("python-package-resolver",),
            ),
        ]
        if self._development_projects is not None:
            routes.extend(
                [
                    Route(
                        name="capability_route_project_checkout",
                        description=(
                            "Revision-only: checkout one exact approved or pending "
                            "Route package whose implementation has failed into a "
                            "mission-local multi-file development project. This does "
                            "not consume a working Route or provide a runtime to an "
                            "unrelated implementation. The public Route contract is "
                            "frozen."
                        ),
                        parameters=_ROUTE_CHECKOUT_SCHEMA,
                        handler=self._route_project_checkout,
                        skill_ids=("materializer", "route-creation"),
                    ),
                    Route(
                        name="capability_route_revision_submit",
                        description=(
                            "Revision-only: seal one repaired immutable development "
                            "checkpoint as a pending revision of an exact Route "
                            "package after its implementation has failed. Public "
                            "schemas, visibility, names, and callable flags are "
                            "copied from the base and cannot be changed by this call."
                        ),
                        parameters=_ROUTE_REVISION_SCHEMA,
                        handler=self._route_revision_submit,
                        skill_ids=("materializer", "route-creation"),
                    ),
                ]
            )
        return tuple(routes)

    def _route_project_checkout(
        self, arguments: Mapping[str, Any]
    ) -> dict[str, Any]:
        if self._development_projects is None:
            raise RuntimeError("development_projects_not_configured")
        route_ref = str(arguments.get("route_ref") or "")
        dependencies = [str(ref) for ref in arguments.get("depends_on") or ()]
        descriptor = self._registry.resolve_managed_route_ref(route_ref)
        if route_ref.startswith("pending_route:"):
            expected = descriptor.get("candidate_payload")
            candidate_refs = self._candidate_artifact_refs(expected)
            if not set(candidate_refs).intersection(dependencies):
                raise CapabilityRegistryError(
                    "pending_route_checkout_candidate_dependency_required:"
                    f"route_ref={route_ref}:candidate_refs={candidate_refs}"
                )
        snapshot = self._registry.managed_route_package_snapshot(
            route_ref,
            max_text_chars=0,
        )
        manifest = snapshot["manifest"]
        project = self._development_projects.open_project(
            purpose=f"Revise managed Route package {manifest['asset_id']}",
            entry_command=[
                self._registry.python_executable,
                "-m",
                "compileall",
                "-q",
                ".",
            ],
            working_directory=".",
            depends_on=dependencies,
        )
        self._development_projects.import_files(
            str(project["project_id"]),
            self._registry.managed_route_package_files(route_ref),
        )
        return {
            **self._development_projects.project_receipt(
                str(project["project_id"])
            ),
            "base_route_ref": route_ref,
            "base_package_hash": manifest["package_hash"],
            "frozen_route_contracts": copy.deepcopy(list(manifest["routes"])),
        }

    def _route_revision_submit(
        self, arguments: Mapping[str, Any]
    ) -> dict[str, Any]:
        if self._development_projects is None:
            raise RuntimeError("development_projects_not_configured")
        base_route_ref = str(arguments.get("base_route_ref") or "")
        snapshot_ref = str(arguments.get("snapshot_ref") or "")
        files = self._development_projects.snapshot_files(snapshot_ref)
        candidate = self._registry.submit_managed_route_revision(
            base_route_ref,
            payload_files=files,
        )
        return {
            **candidate,
            "base_route_ref": base_route_ref,
            "development_project_snapshot_ref": snapshot_ref,
        }

    def _candidate_artifact_refs(self, expected: Any) -> list[str]:
        if not isinstance(expected, Mapping) or self._development_projects is None:
            return []
        refs: list[str] = []
        artifacts = self._development_projects.artifacts
        for receipt in artifacts.list():
            if receipt.get("artifact_kind") != "capability_candidate":
                continue
            ref = str(receipt.get("artifact_ref") or "")
            if artifacts.read(ref).get("machine_payload") == expected:
                refs.append(ref)
        return refs

    def _inspect_python_package_index(
        self,
        arguments: Mapping[str, Any],
    ) -> dict[str, Any]:
        return self._registry.inspect_python_package_index(
            environment_ref=str(arguments.get("environment_ref") or ""),
            distribution_name=str(
                arguments.get("distribution_name") or ""
            ),
            caller_skill_id="python-package-resolver",
            timeout_seconds=120.0,
        )

    def _submit(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        manifest = copy.deepcopy(dict(arguments.get("manifest") or {}))
        raw_files = arguments.get("files")
        if not isinstance(raw_files, list) or not raw_files:
            raise CapabilityRegistryError("candidate_submit_files_required")
        payload_files: dict[str, bytes] = {}
        for index, raw_file in enumerate(raw_files):
            if not isinstance(raw_file, Mapping):
                raise CapabilityRegistryError(
                    f"candidate_submit_file_invalid:{index}"
                )
            path = normalize_payload_path(raw_file.get("path"))
            source_kind = str(raw_file.get("source_kind") or "")
            content = raw_file.get("content")
            source_path = str(raw_file.get("source_path") or "").strip()
            if source_kind == "inline":
                if not isinstance(content, str):
                    raise CapabilityRegistryError(
                        f"candidate_submit_content_must_be_text:{index}"
                    )
                if source_path:
                    raise CapabilityRegistryError(
                        f"candidate_submit_inline_source_path_forbidden:{index}"
                    )
                body = content.encode("utf-8")
            elif source_kind == "path":
                if content not in {None, ""} or not source_path:
                    raise CapabilityRegistryError(
                        f"candidate_submit_path_content_forbidden:{index}"
                    )
                body = self._read_exact_source_file(source_path)
            else:
                raise CapabilityRegistryError(
                    f"candidate_submit_source_kind_invalid:{index}"
                )
            if path in payload_files:
                raise CapabilityRegistryError(
                    f"candidate_submit_file_duplicate:{path}"
                )
            payload_files[path] = body
        manifest["files"] = build_file_receipts(payload_files)
        manifest["package_hash"] = None
        validate_candidate_manifest(manifest)
        if manifest["asset_type"] == "skill":
            self._validate_skill_payload_before_submit(
                manifest,
                payload_files,
            )
        return self._registry.submit_candidate(
            manifest,
            payload_files=payload_files,
        )

    def _validate_skill_payload_before_submit(
        self,
        manifest: Mapping[str, Any],
        payload_files: Mapping[str, bytes],
    ) -> None:
        with tempfile.TemporaryDirectory(
            prefix="candidate-skill-authoring-",
            dir=str(self._registry.root),
        ) as directory:
            skill_root = Path(directory) / str(manifest["asset_id"])
            skill_root.mkdir()
            for relative, body in payload_files.items():
                destination = skill_root / normalize_payload_path(relative)
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(body)
            returncode, summary = self._run_skill_validator(skill_root)
        if returncode != 0:
            raise CapabilityRegistryError(
                "skill_candidate_structure_invalid:"
                + (summary or "project Skill validator failed without output")
            )

    def _run_skill_validator(self, skill_root: Path) -> tuple[int, str]:
        completed = subprocess.run(
            [
                self._registry.python_executable,
                "-I",
                str(self._skill_validator_path),
                str(skill_root),
            ],
            capture_output=True,
            text=True,
            timeout=120.0,
            check=False,
        )
        summary = _bounded_failure_summary(
            (completed.stdout + "\n" + completed.stderr).strip(),
            max_chars=1_800,
        )
        return completed.returncode, summary

    def _read_exact_source_file(self, raw_path: str) -> bytes:
        requested = Path(raw_path)
        candidates = (
            (requested.resolve(),)
            if requested.is_absolute()
            else tuple((root / requested).resolve() for root in self._source_roots)
        )
        matches = [
            path
            for path in candidates
            if path.is_file()
            and any(path.is_relative_to(root) for root in self._source_roots)
        ]
        if len(matches) != 1:
            raise CapabilityRegistryError(
                f"candidate_source_file_not_unique:{raw_path}:{len(matches)}"
            )
        return matches[0].read_bytes()

    def _skill_baseline_snapshot(
        self, arguments: Mapping[str, Any]
    ) -> dict[str, Any]:
        skill_id = str(arguments.get("skill_id") or "").strip()
        active = self._registry.active()["skills"].get(skill_id)
        if active is not None:
            roots = self._registry.active_skill_roots()
            root = roots.get(skill_id)
            if root is None:
                raise CapabilityRegistryError(
                    f"active_skill_root_missing:{skill_id}"
                )
            baseline_hash = str(active)
            source = "approved_overlay"
            manifest = json.loads(
                (root.parent / "candidate.json").read_text(encoding="utf-8")
            )
            route_dependencies = list(
                manifest.get("route_dependencies") or []
            )
        else:
            root = (self._production_skills_root / skill_id).resolve()
            if (
                not root.is_relative_to(self._production_skills_root)
                or not (root / "SKILL.md").is_file()
            ):
                raise CapabilityRegistryError(
                    f"production_skill_not_found:{skill_id}"
                )
            baseline_hash = skill_source_tree_hash(root)
            source = "production_baseline"
            route_dependencies = []
        return {
            "skill_id": skill_id,
            "base_package_hash": baseline_hash,
            "source": source,
            "route_dependencies": route_dependencies,
            "files": _text_tree_snapshot(root),
        }

    def _test_candidate(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        package_ref = str(arguments.get("package_ref") or "")
        snapshot = self._registry.pending_candidate_snapshot(package_ref)
        manifest = snapshot["manifest"]
        tests = arguments.get("route_tests")
        if not isinstance(tests, list):
            raise CapabilityRegistryError("candidate_route_tests_must_be_array")
        evidence: dict[str, Any] = {
            "package_ref": package_ref,
            "package_hash": manifest["package_hash"],
            "asset_type": manifest["asset_type"],
            "checks": [],
        }
        if manifest["asset_type"] == "skill":
            evidence["checks"].extend(
                self._test_skill_candidate(package_ref, manifest)
            )
        else:
            evidence["checks"].extend(
                self._test_route_candidate(package_ref, manifest, tests)
            )
        evidence_ref = self._registry.record_review_evidence(evidence)
        checks = []
        for check in evidence["checks"]:
            checks.append(
                {
                    "check_id": check["check_id"],
                    "status": check["status"],
                    "summary": check["summary"],
                    "evidence_refs": [evidence_ref],
                }
            )
        return {"checks": checks, "evidence_ref": evidence_ref}

    def _test_skill_candidate(
        self,
        package_ref: str,
        manifest: Mapping[str, Any],
    ) -> list[dict[str, Any]]:
        package_dir = self._registry._pending_dir_from_ref(package_ref)
        payload_root = package_dir / "payload"
        with tempfile.TemporaryDirectory(
            prefix="candidate-skill-review-",
            dir=str(self._registry.root),
        ) as directory:
            review_root = Path(directory) / str(manifest["asset_id"])
            shutil.copytree(payload_root, review_root)
            returncode, summary = self._run_skill_validator(review_root)
        return [
            {
                "check_id": f"skill:{manifest['asset_id']}:structure",
                "status": "passed" if returncode == 0 else "failed",
                "summary": summary or "Project Skill structural validator completed.",
            },
            {
                "check_id": (
                    f"skill:{manifest['asset_id']}:real-integration-execution"
                ),
                "status": "not_run",
                "summary": (
                    "A task-specific real integration execution was not supplied "
                    "by this generic structural test."
                ),
            },
        ]

    def _test_route_candidate(
        self,
        package_ref: str,
        manifest: Mapping[str, Any],
        tests: Sequence[Any],
    ) -> list[dict[str, Any]]:
        supplied: dict[str, Mapping[str, Any]] = {}
        for index, raw_test in enumerate(tests):
            if not isinstance(raw_test, Mapping):
                raise CapabilityRegistryError(
                    f"candidate_route_test_invalid:{index}"
                )
            name = str(raw_test.get("route_name") or "")
            route_input = raw_test.get("input")
            if name in supplied or not isinstance(route_input, Mapping):
                raise CapabilityRegistryError(
                    f"candidate_route_test_invalid:{index}:{name}"
                )
            supplied[name] = dict(route_input)
        checks: list[dict[str, Any]] = []
        for route in manifest["routes"]:
            name = str(route["route_name"])
            check_id = f"route:{name}:real-contract-execution"
            if name not in supplied:
                checks.append(
                    {
                        "check_id": check_id,
                        "status": "not_run",
                        "summary": "No exact small contract input was supplied.",
                    }
                )
                continue
            try:
                result = self._registry.invoke_pending_route(
                    package_ref,
                    name,
                    supplied[name],
                )
            except Exception as exc:
                checks.append(
                    {
                        "check_id": check_id,
                        "status": "failed",
                        "summary": _bounded_failure_summary(
                            f"{type(exc).__name__}: {exc}"
                        ),
                    }
                )
            else:
                checks.append(
                    {
                        "check_id": check_id,
                        "status": "passed",
                        "summary": (
                            "Exact pending adapter accepted the supplied input, "
                            "executed in isolation, and returned schema-valid JSON. "
                            f"stdout={str(result.get('stdout') or '')[:800]}"
                        ),
                    }
                )
        unknown = sorted(set(supplied) - {r["route_name"] for r in manifest["routes"]})
        for name in unknown:
            checks.append(
                {
                    "check_id": f"route:{name}:undeclared-test-request",
                    "status": "failed",
                    "summary": (
                        "The requested development or review test names a Route "
                        "that is absent from the exact pending manifest; no "
                        "execution was attempted for that name."
                    ),
                }
            )
        return checks


def skill_source_tree_hash(root: Path) -> str:
    receipts = []
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        relative = path.relative_to(root).as_posix()
        receipts.append(
            {
                "path": relative,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
        )
    canonical = json.dumps(
        receipts,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _bounded_failure_summary(
    value: str,
    *,
    max_chars: int = CAPABILITY_REVIEW_CHECK_SUMMARY_MAX_CHARS,
) -> str:
    text = str(value)
    if len(text) <= max_chars:
        return text
    marker = "\n... diagnostic middle omitted ...\n"
    head_chars = min(600, max_chars // 4)
    tail_chars = max_chars - head_chars - len(marker)
    return text[:head_chars] + marker + text[-tail_chars:]


def _text_tree_snapshot(root: Path, max_chars: int = 240_000) -> list[dict[str, Any]]:
    remaining = int(max_chars)
    files: list[dict[str, Any]] = []
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        relative = path.relative_to(root).as_posix()
        body = path.read_bytes()
        try:
            decoded = body.decode("utf-8")
        except UnicodeDecodeError:
            continue
        visible = decoded[:remaining]
        files.append(
            {
                "path": relative,
                "text": visible,
                "truncated": len(visible) != len(decoded),
            }
        )
        remaining -= len(visible)
        if remaining <= 0:
            break
    return files


_PACKAGE_REF_SCHEMA = {
    "type": "object",
    "properties": {"package_ref": {"type": "string"}},
    "required": ["package_ref"],
    "additionalProperties": False,
}

_PACKAGE_INDEX_SCHEMA = {
    "type": "object",
    "properties": {
        "environment_ref": {"type": "string"},
        "distribution_name": {"type": "string"},
    },
    "required": ["environment_ref", "distribution_name"],
    "additionalProperties": False,
}

_SUBMIT_SCHEMA = {
    "type": "object",
    "properties": {
        "manifest": {"type": "object", "additionalProperties": True},
        "files": {
            "type": "array",
            "minItems": 1,
            "items": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "source_kind": {
                        "type": "string",
                        "enum": ["inline", "path"],
                    },
                    "content": {"type": "string"},
                    "source_path": {"type": "string"},
                },
                "required": [
                    "path",
                    "source_kind",
                    "content",
                    "source_path",
                ],
                "additionalProperties": False,
            },
        },
    },
    "required": ["manifest", "files"],
    "additionalProperties": False,
}

_TEST_SCHEMA = {
    "type": "object",
    "properties": {
        "package_ref": {"type": "string"},
        "route_tests": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "route_name": {"type": "string"},
                    "input": {"type": "object", "additionalProperties": True},
                },
                "required": ["route_name", "input"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["package_ref", "route_tests"],
    "additionalProperties": False,
}

_ROUTE_CHECKOUT_SCHEMA = {
    "type": "object",
    "properties": {
        "route_ref": {"type": "string"},
        "depends_on": {
            "type": "array",
            "items": {"type": "string"},
        },
    },
    "required": ["route_ref", "depends_on"],
    "additionalProperties": False,
}

_ROUTE_REVISION_SCHEMA = {
    "type": "object",
    "properties": {
        "base_route_ref": {"type": "string"},
        "snapshot_ref": {"type": "string"},
    },
    "required": ["base_route_ref", "snapshot_ref"],
    "additionalProperties": False,
}
