from __future__ import annotations

import hashlib
import json
import re
from pathlib import PurePosixPath
from typing import Any, Mapping


CAPABILITY_REVIEW_CHECK_SUMMARY_MAX_CHARS = 2_000


_ASSET_ID = re.compile(r"^[a-z0-9][a-z0-9._-]{0,79}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_ENTRYPOINT = re.compile(
    r"^[a-zA-Z_][a-zA-Z0-9_.]*:[a-zA-Z_][a-zA-Z0-9_]*$"
)
_COMPLEXITIES = frozenset({"low", "medium", "high"})
_CANDIDATE_KINDS = frozenset({"new", "revision"})
_SKILL_ORIGINS = frozenset(
    {"experience_evolved", "task_authored", "third_party"}
)
_ROUTE_ORIGINS = frozenset(
    {
        "experience_evolved",
        "task_authored",
        "third_party",
        "source_onboarding",
    }
)
_SKILL_KEYS = frozenset(
    {
        "schema_version",
        "asset_type",
        "asset_id",
        "candidate_kind",
        "candidate_origin",
        "purpose",
        "base_package_hash",
        "route_dependencies",
        "files",
        "package_hash",
    }
)
_ROUTE_PACKAGE_KEYS = frozenset(
    {
        "schema_version",
        "asset_type",
        "asset_id",
        "candidate_kind",
        "candidate_origin",
        "purpose",
        "base_package_hash",
        "source_paths",
        "adapter_paths",
        "dependency_lock_path",
        "routes",
        "files",
        "package_hash",
    }
)
_ROUTE_KEYS = frozenset(
    {
        "route_name",
        "description",
        "input_schema",
        "output_schema",
        "adapter_entrypoint",
        "agent_callable",
        "code_callable",
        "visible_to_skill_ids",
        "estimated_complexity",
        "repairable_input_paths",
    }
)
_CANDIDATE_ARTIFACT_KEYS = frozenset(
    {
        "artifact_kind",
        "candidate_id",
        "asset_type",
        "asset_id",
        "candidate_kind",
        "candidate_origin",
        "purpose",
        "package_ref",
        "package_hash",
        "base_package_hash",
        "route_dependencies",
    }
)
_REVIEW_ARTIFACT_KEYS = frozenset(
    {
        "artifact_kind",
        "candidate_ref",
        "candidate_id",
        "package_hash",
        "baseline_package_hash",
        "checks",
        "comparison_outcome",
        "recommendation",
    }
)
_REVIEW_CHECK_KEYS = frozenset(
    {"check_id", "status", "summary", "evidence_refs"}
)


class CapabilityManifestError(ValueError):
    pass


def validate_candidate_manifest(manifest: Mapping[str, Any]) -> None:
    if not isinstance(manifest, Mapping):
        raise CapabilityManifestError("candidate_manifest_must_be_object")
    asset_type = str(manifest.get("asset_type") or "")
    expected = {
        "skill": _SKILL_KEYS,
        "route_package": _ROUTE_PACKAGE_KEYS,
    }.get(asset_type)
    if expected is None:
        raise CapabilityManifestError(
            f"candidate_asset_type_invalid:{asset_type or 'empty'}"
        )
    _require_exact_keys(manifest, expected, "candidate")
    if manifest.get("schema_version") != 1:
        raise CapabilityManifestError("candidate_schema_version_invalid")
    _require_asset_id(manifest.get("asset_id"), "candidate_asset_id")
    candidate_kind = str(manifest.get("candidate_kind") or "")
    if candidate_kind not in _CANDIDATE_KINDS:
        raise CapabilityManifestError("candidate_kind_invalid")
    base_hash = manifest.get("base_package_hash")
    if candidate_kind == "new":
        if base_hash is not None:
            raise CapabilityManifestError("new_candidate_base_hash_forbidden")
    elif not _valid_sha256(base_hash):
        raise CapabilityManifestError("revision_candidate_base_hash_required")
    purpose = str(manifest.get("purpose") or "").strip()
    if not purpose or len(purpose) > 500:
        raise CapabilityManifestError("candidate_purpose_invalid")
    package_hash = manifest.get("package_hash")
    if package_hash not in {None, ""} and not _valid_sha256(package_hash):
        raise CapabilityManifestError("candidate_package_hash_invalid")
    files = _validate_files(manifest.get("files"))

    if asset_type == "skill":
        _validate_skill_manifest(manifest, files)
    else:
        _validate_route_package_manifest(manifest, files)


def candidate_package_hash(manifest: Mapping[str, Any]) -> str:
    validate_candidate_manifest(manifest)
    behavior = {
        key: manifest[key]
        for key in sorted(manifest)
        if key not in {"files", "package_hash"}
    }
    files = sorted(
        (
            {"path": str(item["path"]), "sha256": str(item["sha256"])}
            for item in manifest["files"]
        ),
        key=lambda item: item["path"],
    )
    canonical = json.dumps(
        {"behavior": behavior, "files": files},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def build_file_receipts(files: Mapping[str, bytes]) -> list[dict[str, str]]:
    receipts: list[dict[str, str]] = []
    for raw_path, body in files.items():
        path = normalize_payload_path(raw_path)
        if not isinstance(body, bytes):
            raise CapabilityManifestError(
                f"candidate_file_body_must_be_bytes:{path}"
            )
        receipts.append(
            {
                "path": path,
                "sha256": hashlib.sha256(body).hexdigest(),
            }
        )
    receipts.sort(key=lambda item: item["path"])
    if not receipts:
        raise CapabilityManifestError("candidate_files_required")
    return receipts


def normalize_payload_path(value: Any) -> str:
    raw = str(value).strip().replace("\\", "/")
    path = PurePosixPath(raw)
    if (
        not raw
        or path.is_absolute()
        or raw.startswith("/")
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise CapabilityManifestError(
            f"candidate_payload_path_invalid:{raw or 'empty'}"
        )
    return path.as_posix()


def route_names(manifest: Mapping[str, Any]) -> tuple[str, ...]:
    if manifest.get("asset_type") != "route_package":
        return ()
    return tuple(str(route["route_name"]) for route in manifest["routes"])


def capability_candidate_payload(
    manifest: Mapping[str, Any], *, package_ref: str
) -> dict[str, Any]:
    validate_candidate_manifest(manifest)
    package_hash = str(manifest.get("package_hash") or "")
    if not _valid_sha256(package_hash):
        raise CapabilityManifestError(
            "candidate_artifact_package_hash_required"
        )
    normalized_ref = str(package_ref).strip()
    if not normalized_ref.startswith("workspace:capability_registry/pending/"):
        raise CapabilityManifestError("candidate_package_ref_invalid")
    dependencies = (
        list(manifest["route_dependencies"])
        if manifest["asset_type"] == "skill"
        else []
    )
    payload = {
        "artifact_kind": "capability_candidate",
        "candidate_id": (
            f"{manifest['asset_type']}:{manifest['asset_id']}:{package_hash}"
        ),
        "asset_type": manifest["asset_type"],
        "asset_id": manifest["asset_id"],
        "candidate_kind": manifest["candidate_kind"],
        "candidate_origin": manifest["candidate_origin"],
        "purpose": manifest["purpose"],
        "package_ref": normalized_ref,
        "package_hash": package_hash,
        "base_package_hash": manifest["base_package_hash"],
        "route_dependencies": dependencies,
    }
    validate_capability_candidate_payload(payload)
    return payload


def validate_capability_candidate_payload(payload: Mapping[str, Any]) -> None:
    if not isinstance(payload, Mapping):
        raise CapabilityManifestError(
            "capability_candidate_payload_must_be_object"
        )
    _require_exact_keys(
        payload,
        _CANDIDATE_ARTIFACT_KEYS,
        "capability_candidate",
    )
    if payload.get("artifact_kind") != "capability_candidate":
        raise CapabilityManifestError("capability_candidate_kind_invalid")
    asset_type = str(payload.get("asset_type") or "")
    if asset_type not in {"skill", "route_package"}:
        raise CapabilityManifestError(
            "capability_candidate_asset_type_invalid"
        )
    asset_id = _require_asset_id(
        payload.get("asset_id"), "capability_candidate_asset_id"
    )
    package_hash = str(payload.get("package_hash") or "")
    if not _valid_sha256(package_hash):
        raise CapabilityManifestError(
            "capability_candidate_package_hash_invalid"
        )
    expected_id = f"{asset_type}:{asset_id}:{package_hash}"
    if payload.get("candidate_id") != expected_id:
        raise CapabilityManifestError("capability_candidate_id_invalid")
    if payload.get("candidate_kind") not in _CANDIDATE_KINDS:
        raise CapabilityManifestError(
            "capability_candidate_candidate_kind_invalid"
        )
    allowed_origins = (
        _SKILL_ORIGINS if asset_type == "skill" else _ROUTE_ORIGINS
    )
    if payload.get("candidate_origin") not in allowed_origins:
        raise CapabilityManifestError(
            "capability_candidate_origin_invalid"
        )
    purpose = str(payload.get("purpose") or "").strip()
    if not purpose or len(purpose) > 500:
        raise CapabilityManifestError(
            "capability_candidate_purpose_invalid"
        )
    package_ref = str(payload.get("package_ref") or "")
    if not package_ref.startswith("workspace:capability_registry/pending/"):
        raise CapabilityManifestError(
            "capability_candidate_package_ref_invalid"
        )
    base_hash = payload.get("base_package_hash")
    if payload["candidate_kind"] == "new":
        if base_hash is not None:
            raise CapabilityManifestError(
                "capability_candidate_new_base_hash_forbidden"
            )
    elif not _valid_sha256(base_hash):
        raise CapabilityManifestError(
            "capability_candidate_revision_base_hash_required"
        )
    dependencies = payload.get("route_dependencies")
    if not isinstance(dependencies, list):
        raise CapabilityManifestError(
            "capability_candidate_dependencies_must_be_array"
        )
    if asset_type == "route_package" and dependencies:
        raise CapabilityManifestError(
            "route_package_candidate_dependencies_forbidden"
        )


def validate_capability_review_payload(payload: Mapping[str, Any]) -> None:
    if not isinstance(payload, Mapping):
        raise CapabilityManifestError(
            "capability_review_payload_must_be_object"
        )
    _require_exact_keys(payload, _REVIEW_ARTIFACT_KEYS, "capability_review")
    if payload.get("artifact_kind") != "capability_candidate_review":
        raise CapabilityManifestError("capability_review_kind_invalid")
    if not str(payload.get("candidate_ref") or "").startswith("artifact:"):
        raise CapabilityManifestError("capability_review_candidate_ref_invalid")
    if not str(payload.get("candidate_id") or "").strip():
        raise CapabilityManifestError("capability_review_candidate_id_invalid")
    if not _valid_sha256(payload.get("package_hash")):
        raise CapabilityManifestError("capability_review_package_hash_invalid")
    baseline_hash = payload.get("baseline_package_hash")
    if baseline_hash is not None and not _valid_sha256(baseline_hash):
        raise CapabilityManifestError(
            "capability_review_baseline_hash_invalid"
        )
    checks = payload.get("checks")
    if not isinstance(checks, list) or not checks:
        raise CapabilityManifestError("capability_review_checks_required")
    seen: set[str] = set()
    for index, check in enumerate(checks):
        if not isinstance(check, Mapping):
            raise CapabilityManifestError(
                f"capability_review_check_invalid:{index}"
            )
        _require_exact_keys(
            check, _REVIEW_CHECK_KEYS, f"capability_review_check:{index}"
        )
        check_id = str(check.get("check_id") or "").strip()
        if not check_id or check_id in seen:
            raise CapabilityManifestError(
                f"capability_review_check_id_invalid:{index}"
            )
        seen.add(check_id)
        if check.get("status") not in {"passed", "failed", "not_run"}:
            raise CapabilityManifestError(
                f"capability_review_check_status_invalid:{check_id}"
            )
        summary = str(check.get("summary") or "").strip()
        if (
            not summary
            or len(summary) > CAPABILITY_REVIEW_CHECK_SUMMARY_MAX_CHARS
        ):
            raise CapabilityManifestError(
                f"capability_review_check_summary_invalid:{check_id}"
            )
        evidence_refs = check.get("evidence_refs")
        if not isinstance(evidence_refs, list) or not all(
            isinstance(ref, str) and ref.strip() for ref in evidence_refs
        ):
            raise CapabilityManifestError(
                f"capability_review_evidence_refs_invalid:{check_id}"
            )
    if payload.get("comparison_outcome") not in {
        "improved",
        "not_improved",
        "inconclusive",
    }:
        raise CapabilityManifestError(
            "capability_review_comparison_outcome_invalid"
        )
    if payload.get("recommendation") not in {
        "approve",
        "reject",
        "needs_changes",
    }:
        raise CapabilityManifestError(
            "capability_review_recommendation_invalid"
        )


def _validate_skill_manifest(
    manifest: Mapping[str, Any], files: set[str]
) -> None:
    origin = str(manifest.get("candidate_origin") or "")
    if origin not in _SKILL_ORIGINS:
        raise CapabilityManifestError("skill_candidate_origin_invalid")
    if origin == "task_authored" and manifest["candidate_kind"] != "new":
        raise CapabilityManifestError(
            "task_authored_skill_must_be_new"
        )
    if "SKILL.md" not in files:
        raise CapabilityManifestError("skill_candidate_skill_md_required")
    if origin == "experience_evolved":
        forbidden = sorted(
            path
            for path in files
            if path != "SKILL.md" and not path.startswith("references/")
        )
        if forbidden:
            raise CapabilityManifestError(
                f"skill_optimization_file_forbidden:{forbidden}"
            )
    dependencies = manifest.get("route_dependencies")
    if not isinstance(dependencies, list):
        raise CapabilityManifestError(
            "skill_route_dependencies_must_be_array"
        )
    seen: set[tuple[str, str]] = set()
    for index, dependency in enumerate(dependencies):
        if not isinstance(dependency, Mapping) or set(dependency) != {
            "route_name",
            "package_hash",
        }:
            raise CapabilityManifestError(
                f"skill_route_dependency_invalid:{index}"
            )
        route_name = _require_asset_id(
            dependency.get("route_name"),
            f"skill_route_dependency_name:{index}",
        )
        package_hash = str(dependency.get("package_hash") or "")
        if not _valid_sha256(package_hash):
            raise CapabilityManifestError(
                f"skill_route_dependency_hash_invalid:{index}"
            )
        identity = (route_name, package_hash)
        if identity in seen:
            raise CapabilityManifestError(
                f"skill_route_dependency_duplicate:{index}"
            )
        seen.add(identity)


def _validate_route_package_manifest(
    manifest: Mapping[str, Any], files: set[str]
) -> None:
    origin = str(manifest.get("candidate_origin") or "")
    if origin not in _ROUTE_ORIGINS:
        raise CapabilityManifestError(
            "route_package_candidate_origin_invalid"
        )
    # A task may discover and repair an implementation defect in one exact
    # managed Route. The revision keeps the frozen public route contract and
    # remains pending; task authorship is therefore valid for both lifecycle
    # kinds.
    source_paths = _path_array(manifest.get("source_paths"), "source_paths")
    adapter_paths = _path_array(
        manifest.get("adapter_paths"), "adapter_paths"
    )
    dependency_lock_path = normalize_payload_path(
        manifest.get("dependency_lock_path")
    )
    required_paths = {*source_paths, *adapter_paths, dependency_lock_path}
    missing_paths = sorted(required_paths - files)
    if missing_paths:
        raise CapabilityManifestError(
            f"route_package_declared_file_missing:{missing_paths}"
        )
    routes = manifest.get("routes")
    if not isinstance(routes, list) or not routes:
        raise CapabilityManifestError("route_package_routes_required")
    seen_names: set[str] = set()
    for index, route in enumerate(routes):
        if not isinstance(route, Mapping):
            raise CapabilityManifestError(f"route_manifest_invalid:{index}")
        _require_exact_keys(route, _ROUTE_KEYS, f"route:{index}")
        route_name = _require_asset_id(
            route.get("route_name"), f"route_name:{index}"
        )
        if route_name in seen_names:
            raise CapabilityManifestError(
                f"route_name_duplicate:{route_name}"
            )
        seen_names.add(route_name)
        description = str(route.get("description") or "").strip()
        if not description or len(description) > 2000:
            raise CapabilityManifestError(
                f"route_description_invalid:{route_name}"
            )
        for schema_name in ("input_schema", "output_schema"):
            schema = route.get(schema_name)
            if not isinstance(schema, Mapping) or schema.get("type") != "object":
                raise CapabilityManifestError(
                    f"route_{schema_name}_invalid:{route_name}"
                )
        entrypoint = str(route.get("adapter_entrypoint") or "")
        if not _ENTRYPOINT.fullmatch(entrypoint):
            raise CapabilityManifestError(
                f"route_adapter_entrypoint_invalid:{route_name}"
            )
        module_name = entrypoint.split(":", 1)[0]
        module_path = module_name.replace(".", "/") + ".py"
        package_path = module_name.replace(".", "/") + "/__init__.py"
        if module_path not in adapter_paths and package_path not in adapter_paths:
            raise CapabilityManifestError(
                f"route_adapter_entrypoint_not_declared:{route_name}"
            )
        agent_callable = route.get("agent_callable")
        code_callable = route.get("code_callable")
        if not isinstance(agent_callable, bool) or not isinstance(
            code_callable, bool
        ):
            raise CapabilityManifestError(
                f"route_callable_flags_invalid:{route_name}"
            )
        if not agent_callable and not code_callable:
            raise CapabilityManifestError(
                f"route_not_callable:{route_name}"
            )
        visible = route.get("visible_to_skill_ids")
        if not isinstance(visible, list) or not visible:
            raise CapabilityManifestError(
                f"route_visible_skills_required:{route_name}"
            )
        normalized_visible = [
            _require_asset_id(value, f"route_visible_skill:{route_name}")
            for value in visible
        ]
        if len(normalized_visible) != len(set(normalized_visible)):
            raise CapabilityManifestError(
                f"route_visible_skills_duplicate:{route_name}"
            )
        if route.get("estimated_complexity") not in _COMPLEXITIES:
            raise CapabilityManifestError(
                f"route_complexity_invalid:{route_name}"
            )
        repairable = route.get("repairable_input_paths")
        if not isinstance(repairable, list) or not all(
            isinstance(path, str) and (path == "" or path.startswith("/"))
            for path in repairable
        ):
            raise CapabilityManifestError(
                f"route_repairable_input_paths_invalid:{route_name}"
            )
        if len(repairable) != len(set(repairable)):
            raise CapabilityManifestError(
                f"route_repairable_input_paths_duplicate:{route_name}"
            )


def _validate_files(value: Any) -> set[str]:
    if not isinstance(value, list) or not value:
        raise CapabilityManifestError("candidate_files_required")
    paths: set[str] = set()
    for index, item in enumerate(value):
        if not isinstance(item, Mapping) or set(item) != {"path", "sha256"}:
            raise CapabilityManifestError(
                f"candidate_file_receipt_invalid:{index}"
            )
        path = normalize_payload_path(item.get("path"))
        if path in paths:
            raise CapabilityManifestError(
                f"candidate_file_path_duplicate:{path}"
            )
        if not _valid_sha256(item.get("sha256")):
            raise CapabilityManifestError(
                f"candidate_file_hash_invalid:{path}"
            )
        paths.add(path)
    return paths


def _path_array(value: Any, label: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not value:
        raise CapabilityManifestError(f"route_package_{label}_required")
    paths = tuple(normalize_payload_path(item) for item in value)
    if len(paths) != len(set(paths)):
        raise CapabilityManifestError(f"route_package_{label}_duplicate")
    return paths


def _require_asset_id(value: Any, label: str) -> str:
    normalized = str(value or "").strip()
    if not _ASSET_ID.fullmatch(normalized):
        raise CapabilityManifestError(f"{label}_invalid:{normalized or 'empty'}")
    return normalized


def _valid_sha256(value: Any) -> bool:
    return bool(_SHA256.fullmatch(str(value or "")))


def _require_exact_keys(
    value: Mapping[str, Any], expected: frozenset[str], label: str
) -> None:
    actual = set(value)
    if actual != set(expected):
        missing = sorted(set(expected) - actual)
        extra = sorted(actual - set(expected))
        raise CapabilityManifestError(
            f"{label}_keys_invalid:missing={missing}:extra={extra}"
        )
