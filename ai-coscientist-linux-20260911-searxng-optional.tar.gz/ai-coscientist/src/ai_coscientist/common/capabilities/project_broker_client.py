from __future__ import annotations

import json
import os
import sys
import time
import uuid

from pathlib import Path
from typing import Any, Mapping


def main() -> int:
    if len(sys.argv) not in {2, 4}:
        raise SystemExit(
            "usage: project_broker_client.py MAILBOX "
            "[REQUEST_PATH RESPONSE_PATH]"
        )
    mailbox = Path(sys.argv[1]).resolve()
    stream_mode = len(sys.argv) == 2
    request_path = Path(sys.argv[2]).resolve() if not stream_mode else None
    response_path = Path(sys.argv[3]).resolve() if not stream_mode else None
    request = _read_stream_object() if stream_mode else _read_object(request_path)
    if set(request) != {"route_ref", "payload"} or not isinstance(
        request.get("payload"), Mapping
    ):
        raise ValueError("project_broker_request_invalid")

    call_id = uuid.uuid4().hex
    mailbox.mkdir(parents=True, exist_ok=True)
    pending_path = mailbox / f"request-{call_id}.json"
    _write_object(pending_path, request)
    mailbox_response = mailbox / f"response-{call_id}.json"
    timeout_seconds = float(
        os.environ.get("AI_COSCIENTIST_ROUTE_BROKER_CLIENT_TIMEOUT", "86400")
    )
    deadline = time.monotonic() + timeout_seconds
    while not mailbox_response.is_file():
        if time.monotonic() >= deadline:
            raise TimeoutError("project_broker_response_timeout")
        time.sleep(0.05)

    response = _read_object(mailbox_response)
    mailbox_response.unlink(missing_ok=True)
    error = response.get("__bridge_error__")
    if error is not None:
        raise RuntimeError(f"project_broker_host_error:{error}")
    if stream_mode:
        sys.stdout.write(
            json.dumps(
                response,
                ensure_ascii=False,
                allow_nan=False,
                sort_keys=True,
            )
        )
        sys.stdout.flush()
    else:
        assert response_path is not None
        _write_object(response_path, response)
    return 0


def _read_stream_object() -> dict[str, Any]:
    try:
        value = json.load(sys.stdin)
    except json.JSONDecodeError as exc:
        raise ValueError("project_broker_stdin_json_invalid") from exc
    if not isinstance(value, dict):
        raise ValueError("project_broker_stdin_object_required")
    return value


def _read_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"project_broker_json_object_required:{path.name}")
    return value


def _write_object(path: Path, value: Mapping[str, Any]) -> None:
    temporary = path.with_suffix(f"{path.suffix}.tmp-{uuid.uuid4().hex}")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True),
        encoding="utf-8",
    )
    os.replace(temporary, path)


if __name__ == "__main__":
    raise SystemExit(main())
