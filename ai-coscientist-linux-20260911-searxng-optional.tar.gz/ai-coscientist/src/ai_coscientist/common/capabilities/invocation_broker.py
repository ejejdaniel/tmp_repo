from __future__ import annotations

import json
import hashlib
import os
import sys
import time
from pathlib import Path
from typing import Any, Mapping


SOURCE_ROOT = Path(__file__).resolve().parents[3]
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))


from ai_coscientist.common.capabilities.execution import (  # noqa: E402
    DockerPythonExecutor,
    DockerRouteExecutorPool,
    LocalPythonExecutor,
)
from ai_coscientist.common.capabilities.registry import (  # noqa: E402
    CapabilityRegistry,
)


def main() -> int:
    if len(sys.argv) not in {2, 4}:
        raise SystemExit(
            "usage: invocation_broker.py BINDING_PATH "
            "[REQUEST_PATH RESPONSE_PATH]"
        )
    binding_path = Path(sys.argv[1]).resolve()
    stream_mode = len(sys.argv) == 2
    request_path = Path(sys.argv[2]).resolve() if not stream_mode else None
    response_path = Path(sys.argv[3]).resolve() if not stream_mode else None
    binding = _read_object(binding_path)
    broker = binding.get("broker")
    if not isinstance(broker, Mapping):
        raise ValueError("approved_route_broker_configuration_missing")
    request = _read_stream_object() if stream_mode else _read_object(request_path)
    if set(request) != {"route_ref", "payload"}:
        raise ValueError("approved_route_broker_request_shape_invalid")
    payload = request["payload"]
    if not isinstance(payload, Mapping):
        raise ValueError("approved_route_broker_payload_must_be_object")

    route_ref = str(request["route_ref"])
    bound_routes = binding.get("routes")
    if not isinstance(bound_routes, Mapping) or route_ref not in bound_routes:
        raise PermissionError(f"managed_route_not_bound:{route_ref}")
    caller_skill_id = str(
        binding.get("caller_skill_id") or "materializer"
    ).strip()
    if not caller_skill_id:
        raise ValueError("managed_route_broker_caller_skill_required")
    require_code_callable = bool(
        binding.get("require_code_callable", True)
    )
    mode = str(binding.get("mode") or "record")
    if mode not in {"record", "sequence_replay"}:
        raise ValueError(f"managed_route_broker_mode_invalid:{mode}")

    registry = CapabilityRegistry(
        Path(str(broker["registry_root"])),
        python_executable=str(broker["python_executable"]),
        route_executor=_route_executor(broker),
    )
    ledger_path = _ledger_path(binding_path, binding.get("ledger_path"))
    if ledger_path is None:
        result = registry.invoke_managed(
            route_ref,
            payload,
            caller_skill_id=caller_skill_id,
            require_code_callable=require_code_callable,
            timeout_seconds=float(broker["timeout_seconds"]),
        )
        call_index = None
    else:
        with _LedgerLock(ledger_path.with_suffix(".lock")):
            ledger = _read_object(ledger_path)
            calls = ledger.get("calls")
            if not isinstance(calls, list):
                raise ValueError("managed_route_broker_ledger_invalid")
            max_calls = binding.get("max_route_calls")
            if (
                isinstance(max_calls, bool)
                or not isinstance(max_calls, int)
                or max_calls < 1
            ):
                raise ValueError("managed_route_broker_call_quota_invalid")
            if len(calls) >= max_calls:
                raise RuntimeError("managed_route_call_quota_exceeded")
            call_index = len(calls)
            if mode == "record":
                result = registry.invoke_managed(
                    route_ref,
                    payload,
                    caller_skill_id=caller_skill_id,
                    require_code_callable=require_code_callable,
                    timeout_seconds=float(broker["timeout_seconds"]),
                )
            else:
                result = _replayed_result(
                    binding_path,
                    binding,
                    call_index=call_index,
                    route_ref=route_ref,
                    payload=payload,
                )
            receipt = _receipt(
                registry,
                route_ref=route_ref,
                payload=payload,
                result=result,
                call_index=call_index,
            )
            calls.append(
                {
                    "receipt": receipt,
                    "response": dict(result),
                    "mode": mode,
                }
            )
            _write_object(ledger_path, {"calls": calls})
    receipt = _receipt(
        registry,
        route_ref=route_ref,
        payload=payload,
        result=result,
        call_index=call_index,
    )
    response_text = json.dumps(
        {**result, "receipt": receipt},
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
    )
    if stream_mode:
        sys.stdout.write(response_text)
        sys.stdout.flush()
    else:
        assert response_path is not None
        response_path.write_text(response_text, encoding="utf-8")
    return 0


def _read_stream_object() -> dict[str, Any]:
    try:
        value = json.load(sys.stdin)
    except json.JSONDecodeError as exc:
        raise ValueError("approved_route_broker_stdin_json_invalid") from exc
    if not isinstance(value, dict):
        raise ValueError("approved_route_broker_stdin_object_required")
    return value


def _route_executor(broker: Mapping[str, Any]) -> Any:
    executor = broker.get("executor")
    if not isinstance(executor, Mapping):
        raise ValueError("approved_route_broker_executor_missing")
    kind = str(executor.get("kind") or "")
    if kind == "local-python":
        return LocalPythonExecutor(str(broker["python_executable"]))
    if kind == "docker-python-v1":
        return _docker_executor(executor)
    if kind == "docker-python-pool-v1":
        raw_executors = executor.get("executors")
        if not isinstance(raw_executors, list) or not raw_executors:
            raise ValueError("approved_route_broker_executor_pool_empty")
        built = [
            _docker_executor(item)
            for item in raw_executors
            if isinstance(item, Mapping)
        ]
        if len(built) != len(raw_executors):
            raise ValueError("approved_route_broker_executor_pool_invalid")
        default_digest = str(
            executor.get("default_base_image_digest") or ""
        )
        defaults = [
            item for item in built if item.base_image_digest == default_digest
        ]
        if len(defaults) != 1:
            raise ValueError(
                "approved_route_broker_executor_pool_default_invalid"
            )
        default = defaults[0]
        return DockerRouteExecutorPool(
            default,
            [item for item in built if item is not default],
        )
    raise ValueError(f"approved_route_broker_executor_unsupported:{kind}")


def _docker_executor(value: Mapping[str, Any]) -> DockerPythonExecutor:
    return DockerPythonExecutor(
        cache_root=Path(str(value["cache_root"])),
        base_image_repository=str(value["base_image_repository"]),
        base_image_digest=str(value["base_image_digest"]),
        base_image_reference=(
            str(value["base_image_reference"])
            if value.get("base_image_reference") is not None
            else None
        ),
        docker_executable=str(value["docker_executable"]),
        memory_limit=str(value["memory_limit"]),
        cpu_limit=str(value["cpu_limit"]),
        pids_limit=int(value["pids_limit"]),
        tmpfs_size=str(value["tmpfs_size"]),
    )


def _read_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"approved_route_broker_json_object_required:{path}")
    return value


def _write_object(path: Path, value: Mapping[str, Any]) -> None:
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _ledger_path(binding_path: Path, value: Any) -> Path | None:
    if value in {None, ""}:
        return None
    path = Path(str(value)).resolve()
    if not path.is_relative_to(binding_path.parent) or not path.is_file():
        raise ValueError("managed_route_broker_ledger_path_invalid")
    return path


def _replayed_result(
    binding_path: Path,
    binding: Mapping[str, Any],
    *,
    call_index: int,
    route_ref: str,
    payload: Mapping[str, Any],
) -> dict[str, Any]:
    source_path = _owned_binding_file(
        binding_path,
        binding.get("replay_source_ledger_path"),
        label="managed_route_broker_replay_source",
    )
    source = _read_object(source_path)
    source_calls = source.get("calls")
    if not isinstance(source_calls, list) or call_index >= len(source_calls):
        raise RuntimeError("managed_route_replay_call_count_mismatch")
    source_call = source_calls[call_index]
    if not isinstance(source_call, Mapping):
        raise ValueError("managed_route_replay_call_invalid")
    source_receipt = source_call.get("receipt")
    source_response = source_call.get("response")
    if not isinstance(source_receipt, Mapping) or not isinstance(
        source_response, Mapping
    ):
        raise ValueError("managed_route_replay_call_invalid")
    if str(source_receipt.get("route_ref") or "") != route_ref:
        raise RuntimeError("managed_route_replay_route_mismatch")
    if str(source_receipt.get("input_sha256") or "") != _json_hash(payload):
        raise RuntimeError("managed_route_replay_input_mismatch")
    return dict(source_response)


def _owned_binding_file(
    binding_path: Path,
    value: Any,
    *,
    label: str,
) -> Path:
    path = Path(str(value or "")).resolve()
    if not path.is_relative_to(binding_path.parent) or not path.is_file():
        raise ValueError(f"{label}_path_invalid")
    return path


def _receipt(
    registry: CapabilityRegistry,
    *,
    route_ref: str,
    payload: Mapping[str, Any],
    result: Mapping[str, Any],
    call_index: int | None,
) -> dict[str, Any]:
    descriptor = registry.resolve_managed_route_ref(route_ref)
    return {
        "call_index": call_index,
        "route_ref": route_ref,
        "approval_state": (
            "pending" if route_ref.startswith("pending_route:") else "approved"
        ),
        "package_hash": str(descriptor["package_hash"]),
        "package_ref": descriptor.get("package_ref"),
        "input_sha256": _json_hash(payload),
        "output_sha256": _json_hash(result["result"]),
    }


def _json_hash(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()


class _LedgerLock:
    def __init__(self, path: Path, *, timeout_seconds: float = 30.0) -> None:
        self.path = path
        self.timeout_seconds = timeout_seconds
        self._fd: int | None = None

    def __enter__(self) -> "_LedgerLock":
        deadline = time.monotonic() + self.timeout_seconds
        while True:
            try:
                self._fd = os.open(
                    self.path,
                    os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                )
                os.write(self._fd, str(os.getpid()).encode("ascii"))
                return self
            except FileExistsError:
                if time.monotonic() >= deadline:
                    raise TimeoutError("managed_route_broker_ledger_lock_timeout")
                time.sleep(0.05)

    def __exit__(self, _exc_type: Any, _exc: Any, _traceback: Any) -> None:
        if self._fd is not None:
            os.close(self._fd)
            self._fd = None
        try:
            self.path.unlink()
        except FileNotFoundError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
