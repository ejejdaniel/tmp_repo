from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence


RUNTIME_LOCK_PATH = "runtime.lock.json"
DOCKER_RUNTIME_KIND = "docker-python-v1"
ADAPTER_HARNESS_VERSION = 1

_ENVIRONMENT_SCOPES = frozenset({"pending", "approved"})

_RUNTIME_LOCK_KEYS = frozenset(
    {
        "runtime_kind",
        "base_image_digest",
        "requirements_sha256",
        "harness_version",
    }
)
_SHA256_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")


def resolve_local_docker_image_id(
    image_reference: str,
    *,
    docker_executable: str = "docker",
) -> str:
    """Resolve one mutable local tag once, then return its immutable image ID."""
    reference = str(image_reference).strip()
    if not reference:
        raise ValueError("docker_local_image_reference_required")
    completed = subprocess.run(
        [
            str(docker_executable),
            "image",
            "inspect",
            reference,
            "--format",
            "{{.Id}}",
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=30.0,
        check=False,
    )
    image_id = completed.stdout.strip().lower()
    if completed.returncode != 0 or _SHA256_DIGEST.fullmatch(image_id) is None:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise CapabilityExecutionError(
            f"docker_local_image_unavailable:{reference}:{detail}"
        )
    return image_id

_ADAPTER_HARNESS = r"""
import importlib.util
import json
import pathlib
import sys

payload_root = pathlib.Path(sys.argv[1]).resolve()
entrypoint = sys.argv[2]
input_path = pathlib.Path(sys.argv[3]).resolve()
output_path = pathlib.Path(sys.argv[4]).resolve()
module_name, function_name = entrypoint.split(":", 1)
module_file = payload_root.joinpath(*module_name.split(".")).with_suffix(".py")
package_file = payload_root.joinpath(*module_name.split("."), "__init__.py")
if module_file.is_file():
    load_path = module_file
    search_locations = None
elif package_file.is_file():
    load_path = package_file
    search_locations = [str(package_file.parent)]
else:
    raise RuntimeError("approved_route_adapter_missing:" + module_name)
unique_name = "approved_route_adapter_" + sys.argv[5]
spec = importlib.util.spec_from_file_location(
    unique_name,
    load_path,
    submodule_search_locations=search_locations,
)
if spec is None or spec.loader is None:
    raise RuntimeError("approved_route_adapter_unloadable:" + module_name)
module = importlib.util.module_from_spec(spec)
sys.path.insert(0, str(payload_root))
try:
    spec.loader.exec_module(module)
    function = getattr(module, function_name, None)
    if not callable(function):
        raise RuntimeError("approved_route_entrypoint_not_callable:" + entrypoint)
    with input_path.open("r", encoding="utf-8") as handle:
        route_input = json.load(handle)
    route_output = function(route_input)
    with output_path.open("w", encoding="utf-8") as handle:
        json.dump(
            route_output,
            handle,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
        )
finally:
    if sys.path and sys.path[0] == str(payload_root):
        sys.path.pop(0)
"""

_ENVIRONMENT_INSPECTION_HARNESS = r"""
import pathlib
import sys

payload_root = pathlib.Path(sys.argv[1]).resolve()
inspection_path = pathlib.Path(sys.argv[2]).resolve()
sys.path.insert(0, str(payload_root))
try:
    source = inspection_path.read_text(encoding="utf-8")
    namespace = {
        "__name__": "__main__",
        "PACKAGE_ROOT": payload_root,
    }
    exec(compile(source, "<python-environment-inspection>", "exec"), namespace)
finally:
    if sys.path and sys.path[0] == str(payload_root):
        sys.path.pop(0)
"""


class CapabilityExecutionError(RuntimeError):
    pass


@dataclass(frozen=True)
class RouteExecutionResult:
    returncode: int
    stdout: str
    stderr: str


class RouteExecutor(Protocol):
    @property
    def default_project_environment_ref(self) -> str: ...

    def seal_payload(
        self,
        manifest: Mapping[str, Any],
        payload_files: Mapping[str, bytes],
    ) -> dict[str, bytes]: ...

    def execute(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        adapter_entrypoint: str,
        input_path: Path,
        output_path: Path,
        route_token: str,
        working_directory: Path,
        timeout_seconds: float,
        environment_scope: str = "approved",
    ) -> RouteExecutionResult: ...

    def inspect_python_environment(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        inspection_path: Path,
        working_directory: Path,
        timeout_seconds: float,
        environment_scope: str = "approved",
    ) -> RouteExecutionResult: ...

    def inspect_python_package_index(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        distribution_name: str,
        working_directory: Path,
        timeout_seconds: float,
        environment_scope: str = "approved",
    ) -> RouteExecutionResult: ...

    def release_pending_environment(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        timeout_seconds: float,
    ) -> bool: ...

    def execute_project(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        project_root: Path,
        entry_command: Sequence[str],
        working_directory: str,
        environment: Mapping[str, str],
        timeout_seconds: float,
        environment_scope: str = "approved",
    ) -> RouteExecutionResult: ...

    def execute_default_project(
        self,
        *,
        project_root: Path,
        entry_command: Sequence[str],
        working_directory: str,
        environment: Mapping[str, str],
        timeout_seconds: float,
    ) -> RouteExecutionResult: ...

    def default_project_shell_launch(
        self,
        *,
        project_root: Path,
        working_directory: str,
        command: str,
        environment: Mapping[str, str],
        readonly_execution_root: Path | None = None,
    ) -> tuple[list[str], Path, dict[str, str]]: ...


class LocalPythonExecutor:
    """Legacy host-Python executor for existing and deterministic tests."""

    def __init__(self, python_executable: str) -> None:
        self.python_executable = str(python_executable)

    @property
    def default_project_environment_ref(self) -> str:
        return f"host-python:{Path(self.python_executable).resolve()}"

    def seal_payload(
        self,
        manifest: Mapping[str, Any],
        payload_files: Mapping[str, bytes],
    ) -> dict[str, bytes]:
        del manifest
        if RUNTIME_LOCK_PATH in payload_files:
            raise CapabilityExecutionError("candidate_runtime_lock_is_host_owned")
        return dict(payload_files)

    def execute(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        adapter_entrypoint: str,
        input_path: Path,
        output_path: Path,
        route_token: str,
        working_directory: Path,
        timeout_seconds: float,
        environment_scope: str = "approved",
    ) -> RouteExecutionResult:
        del dependency_lock_path
        _validate_environment_scope(environment_scope)
        if (payload_root / RUNTIME_LOCK_PATH).exists():
            raise CapabilityExecutionError(
                "docker_bound_route_requires_docker_executor"
            )
        completed = subprocess.run(
            [
                self.python_executable,
                "-I",
                "-B",
                "-c",
                _ADAPTER_HARNESS,
                str(payload_root),
                adapter_entrypoint,
                str(input_path),
                str(output_path),
                route_token,
            ],
            cwd=str(working_directory),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=float(timeout_seconds),
            check=False,
            env={
                **os.environ,
                "PYTHONHASHSEED": "0",
                "PYTHONDONTWRITEBYTECODE": "1",
            },
        )
        return RouteExecutionResult(
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

    def inspect_python_environment(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        inspection_path: Path,
        working_directory: Path,
        timeout_seconds: float,
        environment_scope: str = "approved",
    ) -> RouteExecutionResult:
        del dependency_lock_path
        _validate_environment_scope(environment_scope)
        if (payload_root / RUNTIME_LOCK_PATH).exists():
            raise CapabilityExecutionError(
                "docker_bound_route_requires_docker_executor"
            )
        completed = subprocess.run(
            [
                self.python_executable,
                "-I",
                "-B",
                "-c",
                _ENVIRONMENT_INSPECTION_HARNESS,
                str(payload_root),
                str(inspection_path),
            ],
            cwd=str(working_directory),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=float(timeout_seconds),
            check=False,
            env={
                **os.environ,
                "PYTHONHASHSEED": "0",
                "PYTHONDONTWRITEBYTECODE": "1",
            },
        )
        return RouteExecutionResult(
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

    def inspect_python_package_index(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        distribution_name: str,
        working_directory: Path,
        timeout_seconds: float,
        environment_scope: str = "approved",
    ) -> RouteExecutionResult:
        del dependency_lock_path
        _validate_environment_scope(environment_scope)
        if (payload_root / RUNTIME_LOCK_PATH).exists():
            raise CapabilityExecutionError(
                "docker_bound_route_requires_docker_executor"
            )
        completed = subprocess.run(
            [
                self.python_executable,
                "-m",
                "pip",
                "--disable-pip-version-check",
                "--no-color",
                "--no-input",
                "--no-cache-dir",
                "index",
                "versions",
                str(distribution_name),
            ],
            cwd=str(working_directory),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=float(timeout_seconds),
            check=False,
            env={
                **os.environ,
                "PIP_DISABLE_PIP_VERSION_CHECK": "1",
                "PIP_NO_INPUT": "1",
            },
        )
        return RouteExecutionResult(
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

    def release_pending_environment(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        timeout_seconds: float,
    ) -> bool:
        del payload_root, dependency_lock_path, timeout_seconds
        return False

    def execute_project(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        project_root: Path,
        entry_command: Sequence[str],
        working_directory: str,
        environment: Mapping[str, str],
        timeout_seconds: float,
        environment_scope: str = "approved",
    ) -> RouteExecutionResult:
        del dependency_lock_path
        _validate_environment_scope(environment_scope)
        if (payload_root / RUNTIME_LOCK_PATH).exists():
            raise CapabilityExecutionError(
                "docker_bound_environment_requires_docker_executor"
            )
        root = Path(project_root).resolve()
        cwd = (root / Path(str(working_directory))).resolve()
        if not cwd.is_relative_to(root) or not cwd.is_dir():
            raise CapabilityExecutionError(
                "project_execution_working_directory_invalid"
            )
        completed = subprocess.run(
            [str(item) for item in entry_command],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=float(timeout_seconds),
            check=False,
            env={**os.environ, **{str(k): str(v) for k, v in environment.items()}},
        )
        return RouteExecutionResult(
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

    def execute_default_project(
        self,
        *,
        project_root: Path,
        entry_command: Sequence[str],
        working_directory: str,
        environment: Mapping[str, str],
        timeout_seconds: float,
    ) -> RouteExecutionResult:
        root = Path(project_root).resolve()
        cwd = _project_working_directory(root, working_directory)
        completed = subprocess.run(
            [str(item) for item in entry_command],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=float(timeout_seconds),
            check=False,
            env={**os.environ, **{str(k): str(v) for k, v in environment.items()}},
        )
        return RouteExecutionResult(
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

    def default_project_shell_launch(
        self,
        *,
        project_root: Path,
        working_directory: str,
        command: str,
        environment: Mapping[str, str],
        readonly_execution_root: Path | None = None,
    ) -> tuple[list[str], Path, dict[str, str]]:
        if readonly_execution_root is not None:
            raise CapabilityExecutionError("project_terminal_readonly_mount_requires_docker")
        root = Path(project_root).resolve()
        cwd = _project_working_directory(root, working_directory)
        return (
            _host_shell_argv(command),
            cwd,
            {**os.environ, **{str(k): str(v) for k, v in environment.items()}},
        )


class DockerPythonExecutor:
    """Run pending venvs and approved images in isolated Linux containers."""

    def __init__(
        self,
        *,
        cache_root: Path,
        base_image_repository: str,
        base_image_digest: str,
        base_image_reference: str | None = None,
        docker_executable: str = "docker",
        memory_limit: str = "2g",
        cpu_limit: str = "2.0",
        pids_limit: int = 256,
        tmpfs_size: str = "128m",
    ) -> None:
        repository = str(base_image_repository).strip()
        digest = str(base_image_digest).strip().lower()
        if (
            not repository
            or "@" in repository
            or any(char.isspace() for char in repository)
        ):
            raise ValueError("docker_base_image_repository_invalid")
        if _SHA256_DIGEST.fullmatch(digest) is None:
            raise ValueError("docker_base_image_digest_invalid")
        reference = (
            str(base_image_reference).strip()
            if base_image_reference is not None
            else f"{repository}@{digest}"
        )
        if reference not in {digest, f"{repository}@{digest}"}:
            raise ValueError("docker_base_image_reference_not_exact")
        if int(pids_limit) < 1:
            raise ValueError("docker_pids_limit_invalid")
        self.cache_root = Path(cache_root).resolve()
        self.cache_root.mkdir(parents=True, exist_ok=True)
        self.base_image_repository = repository
        self.base_image_digest = digest
        self.base_image_reference = reference
        self.docker_executable = str(docker_executable)
        self.memory_limit = str(memory_limit)
        self.cpu_limit = str(cpu_limit)
        self.pids_limit = int(pids_limit)
        self.tmpfs_size = str(tmpfs_size)
        self._ready_approved_environment_volumes: set[str] = set()
        self._session_id = uuid.uuid4().hex[:12]
        self._pending_environment_volumes: dict[str, str] = {}

    @property
    def default_project_environment_ref(self) -> str:
        return f"docker-image:{self.base_image_digest}"

    @property
    def pinned_base_image(self) -> str:
        return self.base_image_reference

    def seal_payload(
        self,
        manifest: Mapping[str, Any],
        payload_files: Mapping[str, bytes],
    ) -> dict[str, bytes]:
        if RUNTIME_LOCK_PATH in payload_files:
            raise CapabilityExecutionError("candidate_runtime_lock_is_host_owned")
        declared_paths = {
            *tuple(manifest.get("source_paths") or ()),
            *tuple(manifest.get("adapter_paths") or ()),
            str(manifest.get("dependency_lock_path") or ""),
        }
        if RUNTIME_LOCK_PATH in declared_paths:
            raise CapabilityExecutionError(
                "candidate_runtime_lock_cannot_be_declared_as_source"
            )
        dependency_path = str(manifest.get("dependency_lock_path") or "")
        dependency_body = payload_files.get(dependency_path)
        if dependency_body is None:
            raise CapabilityExecutionError(
                "candidate_dependency_lock_missing_before_runtime_seal"
            )
        runtime_lock = {
            "runtime_kind": DOCKER_RUNTIME_KIND,
            "base_image_digest": self.base_image_digest,
            "requirements_sha256": hashlib.sha256(dependency_body).hexdigest(),
            "harness_version": ADAPTER_HARNESS_VERSION,
        }
        sealed = dict(payload_files)
        sealed[RUNTIME_LOCK_PATH] = (
            json.dumps(
                runtime_lock,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
            + "\n"
        ).encode("utf-8")
        return sealed

    def execute(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        adapter_entrypoint: str,
        input_path: Path,
        output_path: Path,
        route_token: str,
        working_directory: Path,
        timeout_seconds: float,
        environment_scope: str = "approved",
    ) -> RouteExecutionResult:
        runtime_lock = validate_runtime_lock(
            payload_root=payload_root,
            dependency_lock_path=dependency_lock_path,
            required=True,
        )
        if runtime_lock["base_image_digest"] != self.base_image_digest:
            raise CapabilityExecutionError("docker_runtime_base_image_digest_mismatch")
        if runtime_lock["harness_version"] != ADAPTER_HARNESS_VERSION:
            raise CapabilityExecutionError("docker_runtime_harness_version_unsupported")

        image, environment_volume = self._resolve_environment(
            dependency_lock=payload_root / dependency_lock_path,
            runtime_lock=runtime_lock,
            timeout_seconds=timeout_seconds,
            environment_scope=environment_scope,
        )
        harness_path = working_directory / "adapter_harness.py"
        harness_path.write_text(_ADAPTER_HARNESS, encoding="utf-8")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        command = self._runtime_command(
            image=image,
            payload_root=payload_root,
            harness_path=harness_path,
            input_path=input_path,
            output_directory=output_path.parent,
            output_name=output_path.name,
            adapter_entrypoint=adapter_entrypoint,
            route_token=route_token,
            environment_volume=environment_volume,
        )
        completed = self._run(
            command,
            cwd=working_directory,
            timeout_seconds=timeout_seconds,
        )
        return RouteExecutionResult(
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

    def inspect_python_environment(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        inspection_path: Path,
        working_directory: Path,
        timeout_seconds: float,
        environment_scope: str = "approved",
    ) -> RouteExecutionResult:
        runtime_lock = validate_runtime_lock(
            payload_root=payload_root,
            dependency_lock_path=dependency_lock_path,
            required=True,
        )
        if runtime_lock["base_image_digest"] != self.base_image_digest:
            raise CapabilityExecutionError("docker_runtime_base_image_digest_mismatch")
        if runtime_lock["harness_version"] != ADAPTER_HARNESS_VERSION:
            raise CapabilityExecutionError("docker_runtime_harness_version_unsupported")
        image, environment_volume = self._resolve_environment(
            dependency_lock=payload_root / dependency_lock_path,
            runtime_lock=runtime_lock,
            timeout_seconds=timeout_seconds,
            environment_scope=environment_scope,
        )
        harness_path = working_directory / "environment_inspection_harness.py"
        harness_path.write_text(
            _ENVIRONMENT_INSPECTION_HARNESS,
            encoding="utf-8",
        )
        command = self._inspection_runtime_command(
            image=image,
            payload_root=payload_root,
            harness_path=harness_path,
            inspection_path=inspection_path,
            environment_volume=environment_volume,
        )
        completed = self._run(
            command,
            cwd=working_directory,
            timeout_seconds=timeout_seconds,
        )
        return RouteExecutionResult(
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

    def inspect_python_package_index(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        distribution_name: str,
        working_directory: Path,
        timeout_seconds: float,
        environment_scope: str = "approved",
    ) -> RouteExecutionResult:
        runtime_lock = validate_runtime_lock(
            payload_root=payload_root,
            dependency_lock_path=dependency_lock_path,
            required=True,
        )
        if runtime_lock["base_image_digest"] != self.base_image_digest:
            raise CapabilityExecutionError("docker_runtime_base_image_digest_mismatch")
        if runtime_lock["harness_version"] != ADAPTER_HARNESS_VERSION:
            raise CapabilityExecutionError("docker_runtime_harness_version_unsupported")
        image, environment_volume = self._resolve_environment(
            dependency_lock=payload_root / dependency_lock_path,
            runtime_lock=runtime_lock,
            timeout_seconds=timeout_seconds,
            environment_scope=environment_scope,
        )
        completed = self._run(
            self._package_index_runtime_command(
                image=image,
                distribution_name=distribution_name,
                environment_volume=environment_volume,
            ),
            cwd=working_directory,
            timeout_seconds=timeout_seconds,
        )
        return RouteExecutionResult(
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

    def release_pending_environment(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        timeout_seconds: float,
    ) -> bool:
        runtime_lock = validate_runtime_lock(
            payload_root=payload_root,
            dependency_lock_path=dependency_lock_path,
            required=True,
        )
        identity = _runtime_identity(runtime_lock)
        volume = self._pending_environment_volumes.pop(identity, None)
        if volume is None:
            return False
        self._remove_pending_environment_volume(
            volume,
            timeout_seconds=timeout_seconds,
            strict=True,
        )
        return True

    def execute_project(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
        project_root: Path,
        entry_command: Sequence[str],
        working_directory: str,
        environment: Mapping[str, str],
        timeout_seconds: float,
        environment_scope: str = "approved",
    ) -> RouteExecutionResult:
        """Execute an arbitrary project in one exact managed environment."""
        runtime_lock = validate_runtime_lock(
            payload_root=payload_root,
            dependency_lock_path=dependency_lock_path,
            required=True,
        )
        if runtime_lock["base_image_digest"] != self.base_image_digest:
            raise CapabilityExecutionError("docker_runtime_base_image_digest_mismatch")
        image, environment_volume = self._resolve_environment(
            dependency_lock=payload_root / dependency_lock_path,
            runtime_lock=runtime_lock,
            timeout_seconds=timeout_seconds,
            environment_scope=environment_scope,
        )
        completed = self._run(
            self._project_runtime_command(
                image=image,
                payload_root=payload_root,
                project_root=project_root,
                entry_command=entry_command,
                working_directory=working_directory,
                environment=environment,
                environment_volume=environment_volume,
            ),
            cwd=Path(project_root).resolve(),
            timeout_seconds=timeout_seconds,
        )
        return RouteExecutionResult(
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

    def execute_default_project(
        self,
        *,
        project_root: Path,
        entry_command: Sequence[str],
        working_directory: str,
        environment: Mapping[str, str],
        timeout_seconds: float,
    ) -> RouteExecutionResult:
        completed = self._run(
            self._default_project_runtime_command(
                project_root=project_root,
                entry_command=entry_command,
                working_directory=working_directory,
                environment=environment,
            ),
            cwd=Path(project_root).resolve(),
            timeout_seconds=timeout_seconds,
        )
        return RouteExecutionResult(
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

    def default_project_shell_launch(
        self,
        *,
        project_root: Path,
        working_directory: str,
        command: str,
        environment: Mapping[str, str],
        readonly_execution_root: Path | None = None,
    ) -> tuple[list[str], Path, dict[str, str]]:
        root = Path(project_root).resolve()
        return (
            self._default_project_runtime_command(
                project_root=root,
                entry_command=("sh", "-lc", str(command)),
                working_directory=working_directory,
                environment=environment,
                readonly_execution_root=readonly_execution_root,
            ),
            root,
            os.environ.copy(),
        )

    def close(self, *, timeout_seconds: float = 120.0) -> None:
        volumes = tuple(self._pending_environment_volumes.values())
        self._pending_environment_volumes.clear()
        for volume in volumes:
            self._remove_pending_environment_volume(
                volume,
                timeout_seconds=timeout_seconds,
                strict=False,
            )

    def _resolve_environment(
        self,
        *,
        dependency_lock: Path,
        runtime_lock: Mapping[str, Any],
        timeout_seconds: float,
        environment_scope: str,
    ) -> tuple[str, str | None]:
        scope = _validate_environment_scope(environment_scope)
        if not dependency_lock.read_bytes().strip():
            return self.pinned_base_image, None
        if scope == "pending":
            return (
                self.pinned_base_image,
                self._ensure_pending_environment_volume(
                    dependency_lock=dependency_lock,
                    runtime_lock=runtime_lock,
                    timeout_seconds=timeout_seconds,
                ),
            )
        return (
            self.pinned_base_image,
            self._ensure_approved_environment_volume(
                dependency_lock=dependency_lock,
                runtime_lock=runtime_lock,
                timeout_seconds=timeout_seconds,
            ),
        )

    def _ensure_pending_environment_volume(
        self,
        *,
        dependency_lock: Path,
        runtime_lock: Mapping[str, Any],
        timeout_seconds: float,
    ) -> str:
        identity = _runtime_identity(runtime_lock)
        existing = self._pending_environment_volumes.get(identity)
        if existing is not None:
            return existing
        volume = f"ai-coscientist-route-venv-{self._session_id}-{identity[:16]}"
        created = self._run(
            [
                self.docker_executable,
                "volume",
                "create",
                "--label",
                "ai-coscientist.pending-runtime=true",
                "--label",
                f"ai-coscientist.runtime={identity}",
                "--label",
                f"ai-coscientist.session={self._session_id}",
                "--name",
                volume,
            ],
            cwd=self.cache_root,
            timeout_seconds=timeout_seconds,
        )
        if created.returncode != 0:
            raise CapabilityExecutionError(
                "docker_pending_environment_volume_create_failed:"
                f"{created.returncode}:{created.stderr[-4000:]}"
            )
        try:
            installed = self._run(
                self._pending_environment_install_command(
                    volume=volume,
                    dependency_lock=dependency_lock,
                ),
                cwd=self.cache_root,
                timeout_seconds=timeout_seconds,
            )
        except BaseException:
            self._remove_pending_environment_volume(
                volume,
                timeout_seconds=timeout_seconds,
                strict=False,
            )
            raise
        if installed.returncode != 0:
            self._remove_pending_environment_volume(
                volume,
                timeout_seconds=timeout_seconds,
                strict=False,
            )
            raise CapabilityExecutionError(
                "docker_pending_environment_install_failed:"
                f"{installed.returncode}:{installed.stderr[-4000:]}"
            )
        self._pending_environment_volumes[identity] = volume
        return volume

    def _pending_environment_install_command(
        self,
        *,
        volume: str,
        dependency_lock: Path,
        ready_identity: str | None = None,
    ) -> list[str]:
        install_script = (
            "python -m venv /opt/venv && "
            "mkdir -p /opt/venv/.install-tmp && "
            "TMPDIR=/opt/venv/.install-tmp "
            "/opt/venv/bin/python -m pip install --no-cache-dir "
            "--requirement /input/requirements.lock && "
            "rm -rf /opt/venv/.install-tmp"
        )
        if ready_identity is not None:
            install_script += (
                " && printf '%s\\n' '"
                + ready_identity
                + "' > /opt/venv/.ai-coscientist-runtime"
            )
        return [
            self.docker_executable,
            "run",
            "--rm",
            "--network",
            "bridge",
            "--read-only",
            "--cap-drop",
            "ALL",
            "--security-opt",
            "no-new-privileges",
            "--pids-limit",
            str(self.pids_limit),
            "--cpus",
            self.cpu_limit,
            "--memory",
            self.memory_limit,
            "--tmpfs",
            f"/tmp:rw,nosuid,nodev,size={self.tmpfs_size}",
            "--mount",
            _docker_volume_mount(volume, "/opt/venv", read_only=False),
            "--mount",
            _docker_mount(
                dependency_lock,
                "/input/requirements.lock",
                read_only=True,
            ),
            "--workdir",
            "/tmp",
            "--env",
            "PIP_DISABLE_PIP_VERSION_CHECK=1",
            "--env",
            "PIP_ROOT_USER_ACTION=ignore",
            self.pinned_base_image,
            "sh",
            "-c",
            install_script,
        ]

    def _remove_pending_environment_volume(
        self,
        volume: str,
        *,
        timeout_seconds: float,
        strict: bool,
    ) -> None:
        try:
            removed = self._run(
                [self.docker_executable, "volume", "rm", "--force", volume],
                cwd=self.cache_root,
                timeout_seconds=timeout_seconds,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            if strict:
                raise CapabilityExecutionError(
                    "docker_pending_environment_volume_remove_failed:"
                    f"{type(exc).__name__}:{exc}"
                ) from exc
            return
        if strict and removed.returncode != 0:
            raise CapabilityExecutionError(
                "docker_pending_environment_volume_remove_failed:"
                f"{removed.returncode}:{removed.stderr[-4000:]}"
            )

    def _ensure_approved_environment_volume(
        self,
        *,
        dependency_lock: Path,
        runtime_lock: Mapping[str, Any],
        timeout_seconds: float,
    ) -> str:
        identity = _runtime_identity(runtime_lock)
        volume = f"ai-coscientist-route-venv-approved-{identity[:24]}"
        if volume in self._ready_approved_environment_volumes:
            return volume
        inspected = self._run(
            [
                self.docker_executable,
                "volume",
                "inspect",
                "--format",
                '{{ index .Labels "ai-coscientist.runtime" }}',
                volume,
            ],
            cwd=self.cache_root,
            timeout_seconds=timeout_seconds,
        )
        if inspected.returncode == 0:
            if inspected.stdout.strip() != identity:
                raise CapabilityExecutionError(
                    f"docker_approved_environment_volume_identity_mismatch:{volume}"
                )
            if self._approved_environment_ready(
                volume=volume,
                identity=identity,
                timeout_seconds=timeout_seconds,
            ):
                self._ready_approved_environment_volumes.add(volume)
                return volume
            self._remove_pending_environment_volume(
                volume,
                timeout_seconds=timeout_seconds,
                strict=True,
            )

        created = self._run(
            [
                self.docker_executable,
                "volume",
                "create",
                "--label",
                "ai-coscientist.approved-runtime=true",
                "--label",
                f"ai-coscientist.runtime={identity}",
                "--name",
                volume,
            ],
            cwd=self.cache_root,
            timeout_seconds=timeout_seconds,
        )
        if created.returncode != 0:
            raise CapabilityExecutionError(
                "docker_approved_environment_volume_create_failed:"
                f"{created.returncode}:{created.stderr[-4000:]}"
            )
        try:
            installed = self._run(
                self._pending_environment_install_command(
                    volume=volume,
                    dependency_lock=dependency_lock,
                    ready_identity=identity,
                ),
                cwd=self.cache_root,
                timeout_seconds=timeout_seconds,
            )
        except BaseException:
            self._remove_pending_environment_volume(
                volume,
                timeout_seconds=timeout_seconds,
                strict=False,
            )
            raise
        if installed.returncode != 0:
            self._remove_pending_environment_volume(
                volume,
                timeout_seconds=timeout_seconds,
                strict=False,
            )
            raise CapabilityExecutionError(
                "docker_approved_environment_install_failed:"
                f"{installed.returncode}:{installed.stderr[-4000:]}"
            )
        self._ready_approved_environment_volumes.add(volume)
        return volume

    def _approved_environment_ready(
        self,
        *,
        volume: str,
        identity: str,
        timeout_seconds: float,
    ) -> bool:
        checked = self._run(
            [
                self.docker_executable,
                "run",
                "--rm",
                "--network",
                "none",
                "--read-only",
                "--cap-drop",
                "ALL",
                "--security-opt",
                "no-new-privileges",
                "--mount",
                _docker_volume_mount(volume, "/opt/venv", read_only=True),
                self.pinned_base_image,
                "sh",
                "-c",
                (
                    'test "$(cat /opt/venv/.ai-coscientist-runtime '
                    "2>/dev/null)\" = '" + identity + "'"
                ),
            ],
            cwd=self.cache_root,
            timeout_seconds=timeout_seconds,
        )
        return checked.returncode == 0

    def _runtime_command(
        self,
        *,
        image: str,
        payload_root: Path,
        harness_path: Path,
        input_path: Path,
        output_directory: Path,
        output_name: str,
        adapter_entrypoint: str,
        route_token: str,
        environment_volume: str | None,
    ) -> list[str]:
        mounts = {
            "payload": _docker_mount(payload_root, "/route", read_only=True),
            "harness": _docker_mount(
                harness_path, "/runtime/adapter_harness.py", read_only=True
            ),
            "input": _docker_mount(input_path, "/input/input.json", read_only=True),
            "output": _docker_mount(output_directory, "/output", read_only=False),
        }
        command = [
            self.docker_executable,
            "run",
            "--rm",
            "--network",
            "none",
            "--read-only",
            "--cap-drop",
            "ALL",
            "--security-opt",
            "no-new-privileges",
            "--pids-limit",
            str(self.pids_limit),
            "--cpus",
            self.cpu_limit,
            "--memory",
            self.memory_limit,
            "--tmpfs",
            f"/tmp:rw,nosuid,nodev,size={self.tmpfs_size}",
            "--user",
            "65532:65532",
            "--workdir",
            "/tmp",
            "--env",
            "PYTHONHASHSEED=0",
            "--env",
            "PYTHONDONTWRITEBYTECODE=1",
        ]
        for name in ("payload", "harness", "input", "output"):
            command.extend(["--mount", mounts[name]])
        if environment_volume is not None:
            command.extend(
                [
                    "--mount",
                    _docker_volume_mount(
                        environment_volume,
                        "/opt/venv",
                        read_only=True,
                    ),
                ]
            )
        command.extend(
            [
                image,
                (
                    "/opt/venv/bin/python"
                    if environment_volume is not None
                    else "python"
                ),
                "-I",
                "-B",
                "/runtime/adapter_harness.py",
                "/route",
                adapter_entrypoint,
                "/input/input.json",
                f"/output/{output_name}",
                route_token,
            ]
        )
        return command

    def _project_runtime_command(
        self,
        *,
        image: str,
        payload_root: Path,
        project_root: Path,
        entry_command: Sequence[str],
        working_directory: str,
        environment: Mapping[str, str],
        environment_volume: str | None,
    ) -> list[str]:
        root = Path(project_root).resolve()
        relative_workdir = Path(str(working_directory).replace("\\", "/"))
        if relative_workdir.is_absolute() or ".." in relative_workdir.parts:
            raise CapabilityExecutionError(
                "project_execution_working_directory_invalid"
            )
        argv = [str(item) for item in entry_command]
        if not argv or not argv[0].strip():
            raise CapabilityExecutionError("project_execution_command_invalid")
        if environment_volume is not None and argv[0] in {
            "python",
            "python3",
        }:
            argv[0] = "/opt/venv/bin/python"
        command = [
            self.docker_executable,
            "run",
            "--rm",
            "--network",
            "none",
            "--read-only",
            "--cap-drop",
            "ALL",
            "--security-opt",
            "no-new-privileges",
            "--pids-limit",
            str(self.pids_limit),
            "--cpus",
            self.cpu_limit,
            "--memory",
            self.memory_limit,
            "--tmpfs",
            f"/tmp:rw,nosuid,nodev,size={self.tmpfs_size}",
            "--mount",
            _docker_mount(root, "/workspace", read_only=False),
            "--mount",
            _docker_mount(
                Path(payload_root).resolve(),
                "/capability-environment",
                read_only=True,
            ),
            "--workdir",
            (
                "/workspace"
                if str(relative_workdir) in {"", "."}
                else "/workspace/" + relative_workdir.as_posix()
            ),
            "--env",
            "PYTHONHASHSEED=0",
            "--env",
            "PYTHONDONTWRITEBYTECODE=1",
            "--env",
            "AI_COSCIENTIST_ENVIRONMENT_PACKAGE=/capability-environment",
        ]
        for key, value in sorted(environment.items()):
            if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", str(key)) is None:
                raise CapabilityExecutionError(
                    f"project_execution_environment_key_invalid:{key}"
                )
            command.extend(["--env", f"{key}={value}"])
        if environment_volume is not None:
            command.extend(
                [
                    "--mount",
                    _docker_volume_mount(
                        environment_volume,
                        "/opt/venv",
                        read_only=True,
                    ),
                    "--env",
                    "PATH=/opt/venv/bin:/usr/local/bin:/usr/bin:/bin",
                ]
            )
        command.extend([image, *argv])
        return command

    def _default_project_runtime_command(
        self,
        *,
        project_root: Path,
        entry_command: Sequence[str],
        working_directory: str,
        environment: Mapping[str, str],
        readonly_execution_root: Path | None = None,
    ) -> list[str]:
        root = Path(project_root).resolve()
        relative_workdir = _relative_project_working_directory(working_directory)
        argv = [str(item) for item in entry_command]
        if not argv or not argv[0].strip():
            raise CapabilityExecutionError("project_execution_command_invalid")
        command = [
            self.docker_executable,
            "run",
            "--rm",
            "--network",
            "none",
            "--read-only",
            "--cap-drop",
            "ALL",
            "--security-opt",
            "no-new-privileges",
            "--pids-limit",
            str(self.pids_limit),
            "--cpus",
            self.cpu_limit,
            "--memory",
            self.memory_limit,
            "--tmpfs",
            f"/tmp:rw,nosuid,nodev,size={self.tmpfs_size}",
            "--mount",
            _docker_mount(root, "/workspace", read_only=False),
            "--workdir",
            (
                "/workspace"
                if str(relative_workdir) in {"", "."}
                else "/workspace/" + relative_workdir.as_posix()
            ),
            "--env",
            "PYTHONHASHSEED=0",
            "--env",
            "PYTHONDONTWRITEBYTECODE=1",
        ]
        for key, value in sorted(environment.items()):
            if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", str(key)) is None:
                raise CapabilityExecutionError(
                    f"project_execution_environment_key_invalid:{key}"
                )
            command.extend(["--env", f"{key}={value}"])
        if readonly_execution_root is not None:
            execution_root = Path(readonly_execution_root).resolve(strict=True)
            if not execution_root.is_dir() or execution_root.is_relative_to(root) or root.is_relative_to(execution_root):
                raise CapabilityExecutionError("project_execution_readonly_mount_overlaps_worktree")
            command.extend([
                "--mount", _docker_mount(execution_root, "/execution", read_only=True),
                "--env", "AI_COSCIENTIST_EXECUTION_DIR=/execution",
            ])
        command.extend([self.pinned_base_image, *argv])
        return command

    def _inspection_runtime_command(
        self,
        *,
        image: str,
        payload_root: Path,
        harness_path: Path,
        inspection_path: Path,
        environment_volume: str | None,
    ) -> list[str]:
        mounts = (
            _docker_mount(payload_root, "/route", read_only=True),
            _docker_mount(
                harness_path,
                "/runtime/environment_inspection_harness.py",
                read_only=True,
            ),
            _docker_mount(
                inspection_path,
                "/inspection/inspection.py",
                read_only=True,
            ),
        )
        command = [
            self.docker_executable,
            "run",
            "--rm",
            "--network",
            "none",
            "--read-only",
            "--cap-drop",
            "ALL",
            "--security-opt",
            "no-new-privileges",
            "--pids-limit",
            str(self.pids_limit),
            "--cpus",
            self.cpu_limit,
            "--memory",
            self.memory_limit,
            "--tmpfs",
            f"/tmp:rw,nosuid,nodev,size={self.tmpfs_size}",
            "--user",
            "65532:65532",
            "--workdir",
            "/tmp",
            "--env",
            "PYTHONHASHSEED=0",
            "--env",
            "PYTHONDONTWRITEBYTECODE=1",
        ]
        for mount in mounts:
            command.extend(["--mount", mount])
        if environment_volume is not None:
            command.extend(
                [
                    "--mount",
                    _docker_volume_mount(
                        environment_volume,
                        "/opt/venv",
                        read_only=True,
                    ),
                ]
            )
        command.extend(
            [
                image,
                (
                    "/opt/venv/bin/python"
                    if environment_volume is not None
                    else "python"
                ),
                "-I",
                "-B",
                "/runtime/environment_inspection_harness.py",
                "/route",
                "/inspection/inspection.py",
            ]
        )
        return command

    def _package_index_runtime_command(
        self,
        *,
        image: str,
        distribution_name: str,
        environment_volume: str | None,
    ) -> list[str]:
        command = [
            self.docker_executable,
            "run",
            "--rm",
            "--network",
            "bridge",
            "--read-only",
            "--cap-drop",
            "ALL",
            "--security-opt",
            "no-new-privileges",
            "--pids-limit",
            str(self.pids_limit),
            "--cpus",
            self.cpu_limit,
            "--memory",
            self.memory_limit,
            "--tmpfs",
            f"/tmp:rw,nosuid,nodev,size={self.tmpfs_size}",
            "--user",
            "65532:65532",
            "--workdir",
            "/tmp",
            "--env",
            "PIP_DISABLE_PIP_VERSION_CHECK=1",
            "--env",
            "PIP_NO_INPUT=1",
        ]
        if environment_volume is not None:
            command.extend(
                [
                    "--mount",
                    _docker_volume_mount(
                        environment_volume,
                        "/opt/venv",
                        read_only=True,
                    ),
                ]
            )
        command.extend(
            [
                image,
                (
                    "/opt/venv/bin/python"
                    if environment_volume is not None
                    else "python"
                ),
                "-m",
                "pip",
                "--disable-pip-version-check",
                "--no-color",
                "--no-input",
                "--no-cache-dir",
                "index",
                "versions",
                str(distribution_name),
            ]
        )
        return command

    def _run(
        self,
        command: list[str],
        *,
        cwd: Path,
        timeout_seconds: float,
    ) -> subprocess.CompletedProcess[str]:
        if (
            len(command) >= 2
            and command[0] == self.docker_executable
            and command[1] == "run"
        ):
            return self._run_container(
                command,
                cwd=cwd,
                timeout_seconds=timeout_seconds,
            )
        return subprocess.run(
            command,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=float(timeout_seconds),
            check=False,
        )

    def _run_container(
        self,
        command: list[str],
        *,
        cwd: Path,
        timeout_seconds: float,
    ) -> subprocess.CompletedProcess[str]:
        invocation_id = uuid.uuid4().hex[:12]
        container_name = f"ai-coscientist-route-{self._session_id}-{invocation_id}"
        owned_command = [
            command[0],
            "run",
            "--name",
            container_name,
            "--label",
            "ai-coscientist.route-runtime=true",
            "--label",
            f"ai-coscientist.executor-session={self._session_id}",
            "--label",
            f"ai-coscientist.invocation={invocation_id}",
            *command[2:],
        ]
        process = subprocess.Popen(
            owned_command,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        try:
            stdout, stderr = process.communicate(timeout=float(timeout_seconds))
        except subprocess.TimeoutExpired as exc:
            stdout, stderr = _finish_timed_out_process(process, exc)
            if not self._force_remove_container(container_name):
                stderr = (
                    f"{stderr}\nroute_container_cleanup_failed:{container_name}"
                ).strip()
            raise subprocess.TimeoutExpired(
                owned_command,
                float(timeout_seconds),
                output=stdout,
                stderr=stderr,
            ) from exc
        except BaseException:
            _terminate_subprocess(process)
            self._force_remove_container(container_name)
            raise
        return subprocess.CompletedProcess(
            owned_command,
            int(process.returncode or 0),
            stdout,
            stderr,
        )

    def _force_remove_container(self, container_name: str) -> bool:
        command = [
            self.docker_executable,
            "rm",
            "--force",
            container_name,
        ]
        for _attempt in range(2):
            try:
                completed = subprocess.run(
                    command,
                    cwd=str(self.cache_root),
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=30.0,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError):
                continue
            if completed.returncode == 0 or "No such container" in (
                completed.stderr or ""
            ):
                return True
        return False


def _finish_timed_out_process(
    process: subprocess.Popen[str],
    timeout_error: subprocess.TimeoutExpired,
) -> tuple[str, str]:
    if process.poll() is None:
        process.kill()
    try:
        return process.communicate(timeout=3.0)
    except (OSError, subprocess.TimeoutExpired):
        if process.poll() is None:
            process.kill()
        _close_process_pipes(process)
        return (
            _subprocess_text(timeout_error.output),
            _subprocess_text(timeout_error.stderr),
        )


def _terminate_subprocess(process: subprocess.Popen[str]) -> None:
    if process.poll() is None:
        try:
            process.kill()
        except OSError:
            pass
    try:
        process.communicate(timeout=3.0)
    except (OSError, subprocess.TimeoutExpired):
        _close_process_pipes(process)


def _close_process_pipes(process: subprocess.Popen[str]) -> None:
    for stream in (process.stdout, process.stderr):
        if stream is not None:
            try:
                stream.close()
            except OSError:
                pass


def _subprocess_text(value: str | bytes | None) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


class DockerRouteExecutorPool:
    """Dispatch exact Docker-bound Route packages by runtime-lock digest."""

    def __init__(
        self,
        default_executor: DockerPythonExecutor,
        additional_executors: Sequence[DockerPythonExecutor] = (),
    ) -> None:
        executors = (default_executor, *tuple(additional_executors))
        by_digest: dict[str, DockerPythonExecutor] = {}
        for executor in executors:
            digest = executor.base_image_digest
            if digest in by_digest:
                raise ValueError(f"docker_route_executor_digest_duplicate:{digest}")
            by_digest[digest] = executor
        self.default_executor = default_executor
        self._executors_by_digest = by_digest

    @property
    def executors(self) -> tuple[DockerPythonExecutor, ...]:
        return (
            self.default_executor,
            *tuple(
                executor
                for digest, executor in sorted(self._executors_by_digest.items())
                if digest != self.default_executor.base_image_digest
            ),
        )

    @property
    def default_project_environment_ref(self) -> str:
        return self.default_executor.default_project_environment_ref

    def seal_payload(
        self,
        manifest: Mapping[str, Any],
        payload_files: Mapping[str, bytes],
    ) -> dict[str, bytes]:
        return self.default_executor.seal_payload(manifest, payload_files)

    def execute(self, **kwargs: Any) -> RouteExecutionResult:
        return self._executor_for_payload(
            payload_root=kwargs["payload_root"],
            dependency_lock_path=kwargs["dependency_lock_path"],
        ).execute(**kwargs)

    def inspect_python_environment(self, **kwargs: Any) -> RouteExecutionResult:
        return self._executor_for_payload(
            payload_root=kwargs["payload_root"],
            dependency_lock_path=kwargs["dependency_lock_path"],
        ).inspect_python_environment(**kwargs)

    def inspect_python_package_index(self, **kwargs: Any) -> RouteExecutionResult:
        return self._executor_for_payload(
            payload_root=kwargs["payload_root"],
            dependency_lock_path=kwargs["dependency_lock_path"],
        ).inspect_python_package_index(**kwargs)

    def release_pending_environment(self, **kwargs: Any) -> bool:
        return self._executor_for_payload(
            payload_root=kwargs["payload_root"],
            dependency_lock_path=kwargs["dependency_lock_path"],
        ).release_pending_environment(**kwargs)

    def execute_project(self, **kwargs: Any) -> RouteExecutionResult:
        return self._executor_for_payload(
            payload_root=kwargs["payload_root"],
            dependency_lock_path=kwargs["dependency_lock_path"],
        ).execute_project(**kwargs)

    def execute_default_project(self, **kwargs: Any) -> RouteExecutionResult:
        return self.default_executor.execute_default_project(**kwargs)

    def default_project_shell_launch(
        self, **kwargs: Any
    ) -> tuple[list[str], Path, dict[str, str]]:
        return self.default_executor.default_project_shell_launch(**kwargs)

    def close(self, *, timeout_seconds: float = 120.0) -> None:
        for executor in self.executors:
            executor.close(timeout_seconds=timeout_seconds)

    def _executor_for_payload(
        self,
        *,
        payload_root: Path,
        dependency_lock_path: str,
    ) -> DockerPythonExecutor:
        runtime_lock = validate_runtime_lock(
            payload_root=payload_root,
            dependency_lock_path=dependency_lock_path,
            required=True,
        )
        assert runtime_lock is not None
        digest = str(runtime_lock["base_image_digest"])
        executor = self._executors_by_digest.get(digest)
        if executor is None:
            raise CapabilityExecutionError(
                f"docker_runtime_base_image_digest_unregistered:{digest}"
            )
        return executor


def validate_runtime_lock(
    *,
    payload_root: Path,
    dependency_lock_path: str,
    required: bool,
) -> dict[str, Any] | None:
    runtime_path = payload_root / RUNTIME_LOCK_PATH
    if not runtime_path.is_file():
        if required:
            raise CapabilityExecutionError("docker_runtime_lock_missing")
        return None
    try:
        value = json.loads(runtime_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise CapabilityExecutionError(f"docker_runtime_lock_unreadable:{exc}") from exc
    if not isinstance(value, Mapping) or set(value) != set(_RUNTIME_LOCK_KEYS):
        raise CapabilityExecutionError("docker_runtime_lock_shape_invalid")
    if value.get("runtime_kind") != DOCKER_RUNTIME_KIND:
        raise CapabilityExecutionError("docker_runtime_kind_invalid")
    digest = str(value.get("base_image_digest") or "").lower()
    if _SHA256_DIGEST.fullmatch(digest) is None:
        raise CapabilityExecutionError("docker_runtime_base_image_digest_invalid")
    requirement_hash = str(value.get("requirements_sha256") or "")
    dependency_path = payload_root / dependency_lock_path
    if not dependency_path.is_file():
        raise CapabilityExecutionError("docker_dependency_lock_missing")
    actual_hash = hashlib.sha256(dependency_path.read_bytes()).hexdigest()
    if requirement_hash != actual_hash:
        raise CapabilityExecutionError("docker_runtime_requirements_hash_mismatch")
    if value.get("harness_version") != ADAPTER_HARNESS_VERSION:
        raise CapabilityExecutionError("docker_runtime_harness_version_invalid")
    return {
        "runtime_kind": DOCKER_RUNTIME_KIND,
        "base_image_digest": digest,
        "requirements_sha256": requirement_hash,
        "harness_version": ADAPTER_HARNESS_VERSION,
    }


def _validate_environment_scope(value: str) -> str:
    scope = str(value).strip()
    if scope not in _ENVIRONMENT_SCOPES:
        raise CapabilityExecutionError(
            f"python_environment_scope_invalid:{scope or 'none'}"
        )
    return scope


def _runtime_identity(runtime_lock: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(
            dict(runtime_lock),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()


def _relative_project_working_directory(value: str) -> Path:
    relative = Path(str(value).replace("\\", "/"))
    if relative.is_absolute() or ".." in relative.parts:
        raise CapabilityExecutionError(
            "project_execution_working_directory_invalid"
        )
    return relative


def _project_working_directory(root: Path, value: str) -> Path:
    relative = _relative_project_working_directory(value)
    cwd = (Path(root).resolve() / relative).resolve()
    if not cwd.is_relative_to(Path(root).resolve()) or not cwd.is_dir():
        raise CapabilityExecutionError(
            "project_execution_working_directory_invalid"
        )
    return cwd


def _host_shell_argv(command: str) -> list[str]:
    if os.name == "nt":
        powershell = Path(
            r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
        )
        if powershell.is_file():
            return [
                str(powershell),
                "-NoLogo",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                str(command),
            ]
        return [os.environ.get("COMSPEC", r"C:\Windows\System32\cmd.exe"), "/d", "/s", "/c", str(command)]
    return ["/bin/sh", "-lc", str(command)]


def _docker_mount(source: Path, target: str, *, read_only: bool) -> str:
    resolved = str(Path(source).resolve())
    if "," in resolved:
        raise CapabilityExecutionError("docker_mount_path_contains_comma")
    options = f"type=bind,src={resolved},dst={target}"
    return options + (",readonly" if read_only else "")


def _docker_volume_mount(
    volume: str,
    target: str,
    *,
    read_only: bool,
) -> str:
    name = str(volume).strip()
    if not name or "," in name:
        raise CapabilityExecutionError("docker_volume_name_invalid")
    options = f"type=volume,src={name},dst={target}"
    return options + (",readonly" if read_only else "")
