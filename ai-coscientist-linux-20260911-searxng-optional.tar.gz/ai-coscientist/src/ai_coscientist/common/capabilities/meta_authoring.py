from __future__ import annotations

import copy
import json
import re
from typing import Any, Callable, Mapping


_FILE_ITEM = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "minLength": 1},
        "source_kind": {
            "type": "string",
            "enum": ["inline", "path"],
            "description": (
                "Use inline for newly authored content and path only for an "
                "exact user-supplied source file."
            ),
        },
        "content": {
            "type": "string",
            "description": "Complete UTF-8 content for inline; empty for path.",
        },
        "source_path": {
            "type": "string",
            "description": (
                "Exact supplied path for source_kind=path; always empty for "
                "source_kind=inline."
            ),
        },
    },
    "required": ["path", "source_kind", "content", "source_path"],
    "additionalProperties": False,
}

_ROUTE_DEPENDENCY = {
    "type": "object",
    "properties": {
        "route_name": {"type": "string"},
        "package_hash": {"type": "string"},
    },
    "required": ["route_name", "package_hash"],
    "additionalProperties": False,
}

_ROUTE_DESCRIPTOR = {
    "type": "object",
    "properties": {
        "route_name": {"type": "string"},
        "description": {"type": "string", "maxLength": 2000},
        "input_schema": {"type": "object", "additionalProperties": True},
        "output_schema": {"type": "object", "additionalProperties": True},
        "adapter_entrypoint": {
            "type": "string",
            "description": (
                "Python module:function whose module path maps exactly to one "
                "declared adapter_paths file."
            ),
        },
        "agent_callable": {"type": "boolean"},
        "code_callable": {"type": "boolean"},
        "visible_to_skill_ids": {
            "type": "array",
            "minItems": 1,
            "items": {"type": "string"},
        },
        "estimated_complexity": {
            "type": "string",
            "enum": ["low", "medium", "high"],
        },
        "repairable_input_paths": {
            "type": "array",
            "items": {"type": "string"},
        },
    },
    "required": [
        "route_name",
        "description",
        "input_schema",
        "output_schema",
        "adapter_entrypoint",
        "agent_callable",
        "code_callable",
        "visible_to_skill_ids",
        "estimated_complexity",
        "repairable_input_paths",
    ],
    "additionalProperties": False,
}

SKILL_CANDIDATE_SCHEMA = {
    "type": "object",
    "properties": {
        "asset_id": {"type": "string"},
        "purpose": {
            "type": "string",
            "maxLength": 500,
            "description": (
                "One catalog-navigation sentence naming the capability and "
                "its boundary. Target at most 300 characters; complete "
                "requirements belong in SKILL.md."
            ),
        },
        "route_dependencies": {
            "type": "array",
            "items": _ROUTE_DEPENDENCY,
        },
        "files": {
            "type": "array",
            "minItems": 1,
            "items": _FILE_ITEM,
        },
    },
    "required": ["asset_id", "purpose", "route_dependencies", "files"],
    "additionalProperties": False,
}

SKILL_OPTIMIZATION_TARGET_SCHEMA = {
    "type": "object",
    "properties": {
        "skill_id": {"type": "string"},
        "purpose": {"type": "string", "maxLength": 500},
    },
    "required": ["skill_id", "purpose"],
    "additionalProperties": False,
}

SKILL_OPTIMIZATION_FILES_SCHEMA = {
    "type": "object",
    "properties": {
        "files": {
            "type": "array",
            "minItems": 1,
            "items": _FILE_ITEM,
        }
    },
    "required": ["files"],
    "additionalProperties": False,
}

ROUTE_PACKAGE_CANDIDATE_SCHEMA = {
    "type": "object",
    "properties": {
        "asset_id": {"type": "string"},
        "purpose": {"type": "string", "maxLength": 500},
        "source_paths": {
            "type": "array",
            "minItems": 1,
            "items": {"type": "string"},
        },
        "adapter_paths": {
            "type": "array",
            "minItems": 1,
            "items": {"type": "string"},
        },
        "dependency_lock_path": {"type": "string"},
        "routes": {
            "type": "array",
            "minItems": 1,
            "items": _ROUTE_DESCRIPTOR,
        },
        "files": {
            "type": "array",
            "minItems": 1,
            "items": _FILE_ITEM,
        },
    },
    "required": [
        "asset_id",
        "purpose",
        "source_paths",
        "adapter_paths",
        "dependency_lock_path",
        "routes",
        "files",
    ],
    "additionalProperties": False,
}

CANDIDATE_REVIEW_PREFLIGHT_SCHEMA = {
    "type": "object",
    "properties": {
        "route_tests": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "route_name": {"type": "string"},
                    "input": {"type": "object", "additionalProperties": True},
                },
                "required": ["route_name", "input"],
                "additionalProperties": False,
            },
        },
        "contract_check": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "enum": ["passed", "failed", "not_run"],
                },
                "summary": {"type": "string", "maxLength": 2000},
                "evidence_refs": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": ["status", "summary", "evidence_refs"],
            "additionalProperties": False,
        },
    },
    "required": ["route_tests", "contract_check"],
    "additionalProperties": False,
}

CANDIDATE_REVIEW_DECISION_SCHEMA = {
    "type": "object",
    "properties": {
        "comparison_outcome": {
            "type": "string",
            "enum": ["improved", "not_improved", "inconclusive"],
        },
        "recommendation": {
            "type": "string",
            "enum": ["approve", "reject", "needs_changes"],
        },
        "reason": {"type": "string", "maxLength": 1200},
    },
    "required": ["comparison_outcome", "recommendation", "reason"],
    "additionalProperties": False,
}


def authoring_context(
    payload: Mapping[str, Any],
    *,
    mode: str,
    baseline: Mapping[str, Any] | None = None,
) -> str:
    context = {
        "mode": str(mode),
        "objective": str(payload.get("objective") or ""),
        "evaluation_summary": str(
            payload.get("evaluation_summary") or ""
        ),
        "active_work_unit": copy.deepcopy(
            payload.get("active_work_unit")
        ),
        "resolved_inputs": copy.deepcopy(
            list(payload.get("resolved_inputs") or [])
        ),
        "baseline": copy.deepcopy(dict(baseline or {})),
    }
    if "managed_route_dependencies" in payload:
        context["managed_route_dependencies"] = copy.deepcopy(
            list(payload.get("managed_route_dependencies") or [])
        )
    return json.dumps(
        context,
        ensure_ascii=False,
        indent=2,
    )


def skill_manifest(
    draft: Mapping[str, Any],
    *,
    candidate_kind: str,
    candidate_origin: str,
    base_package_hash: str | None,
) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "asset_type": "skill",
        "asset_id": str(draft["asset_id"]),
        "candidate_kind": candidate_kind,
        "candidate_origin": candidate_origin,
        "purpose": str(draft["purpose"]),
        "base_package_hash": base_package_hash,
        "route_dependencies": copy.deepcopy(
            list(draft.get("route_dependencies") or [])
        ),
        "files": [],
        "package_hash": None,
    }


def route_manifest(
    draft: Mapping[str, Any],
    *,
    candidate_origin: str,
) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "asset_type": "route_package",
        "asset_id": str(draft["asset_id"]),
        "candidate_kind": "new",
        "candidate_origin": candidate_origin,
        "purpose": str(draft["purpose"]),
        "base_package_hash": None,
        "source_paths": copy.deepcopy(list(draft["source_paths"])),
        "adapter_paths": copy.deepcopy(list(draft["adapter_paths"])),
        "dependency_lock_path": str(draft["dependency_lock_path"]),
        "routes": copy.deepcopy(list(draft["routes"])),
        "files": [],
        "package_hash": None,
    }


def candidate_dependencies(payload: Mapping[str, Any]) -> list[str]:
    return list(
        dict.fromkeys(
            str(item.get("artifact_ref") or "")
            for item in payload.get("resolved_inputs") or []
            if isinstance(item, Mapping)
            and str(item.get("artifact_ref") or "").startswith("artifact:")
        )
    )


def candidate_markdown(candidate: Mapping[str, Any]) -> str:
    return (
        f"# Pending capability candidate\n\n"
        f"- Candidate: `{candidate['candidate_id']}`\n"
        f"- Asset: `{candidate['asset_type']}:{candidate['asset_id']}`\n"
        f"- Package hash: `{candidate['package_hash']}`\n"
        f"- Origin: `{candidate['candidate_origin']}`\n"
        f"- Purpose: {candidate['purpose']}\n\n"
        "This candidate is pending. It is neither installed nor approved.\n"
    )


PYTHON_ENVIRONMENT_PROBE_SYSTEM = """\
Write one small read-only Python diagnostic for one exact pending Route-package
environment after exact Route execution failed. Inspect only facts needed to
distinguish an implementation/API mismatch from a Python distribution,
version, extra, or transitive-install failure. Use importlib.metadata to
distinguish import names from distribution names. Actually test relevant
imports and inspect the installed module tree, exported symbols, signatures,
and source locations needed to establish the supported API. Start from the
exact candidate source in candidate_snapshot and follow the import binding used
by the failing implementation. If that source imports ``from A import B``,
inspect A.B itself, including any wrapper source and return behavior needed for
the failure. Never substitute a same-named callable from a dependency or
transitive package. For callable source locations use inspect.getmodule or
inspect.getsourcefile; do not assume a function has __file__. Isolate optional
inspection failures so one missing attribute does not suppress later signature
or source facts. A name from dir(), a source filename, or metadata for an
uninstalled distribution is only a lead. PACKAGE_ROOT is a pathlib.Path and the
payload is on sys.path. Print concise facts. Do not edit files, access the
network, perform the full scientific calculation, or return replacement
implementation code."""

PYTHON_ENVIRONMENT_PROBE_SCHEMA = {
    "type": "object",
    "properties": {
        "purpose": {"type": "string", "minLength": 1, "maxLength": 500},
        "python_code": {
            "type": "string",
            "minLength": 1,
            "maxLength": 16_000,
        },
    },
    "required": ["purpose", "python_code"],
    "additionalProperties": False,
}

_MISSING_MODULE_PATTERN = re.compile(
    r"No module named ['\"]([A-Za-z_][A-Za-z0-9_.]*)['\"]"
)
_PARENT_EXPORT_PROBE_KIND = "missing-child-parent-export-v1"


def inspect_missing_import_parent_export(
    runtime: Any,
    *,
    candidate: Mapping[str, Any],
    exact_sandbox_checks: Mapping[str, Any],
    artifact_purpose: str,
) -> dict[str, Any] | None:
    """Mechanically test whether one missing child import is a parent export."""
    target = _single_failed_missing_module(exact_sandbox_checks)
    if target is None or "." not in target:
        return None
    parent, leaf = target.rsplit(".", 1)
    python_code = _parent_export_probe_code(
        target=target,
        parent=parent,
        leaf=leaf,
    )
    dependencies = [str(candidate["package_ref"])]
    evidence_ref = str(exact_sandbox_checks.get("evidence_ref") or "")
    if evidence_ref:
        dependencies.append(evidence_ref)
    receipt = runtime.call_route(
        "write_code_artifact",
        {
            "purpose": f"{artifact_purpose}:{target}",
            "python_code": python_code,
            "depends_on": dependencies,
        },
    )
    code_ref = str(receipt.get("code_artifact_ref") or "")
    runtime.read_ref(code_ref)
    result = runtime.call_route(
        "inspect_python_environment",
        {
            "environment_ref": str(candidate["package_ref"]),
            "code_artifact_ref": code_ref,
            "timeout_seconds": 120,
        },
    )
    return {
        "code_artifact_ref": code_ref,
        "status": result.get("status"),
        "returncode": result.get("returncode"),
        "stdout": result.get("stdout"),
        "stderr": result.get("stderr"),
    }


def parent_callable_import_mismatch(
    probe: Mapping[str, Any] | None,
) -> dict[str, Any] | None:
    """Return exact private probe facts only for a conclusive API mismatch."""
    if not isinstance(probe, Mapping) or probe.get("status") != "passed":
        return None
    stdout = str(probe.get("stdout") or "").strip()
    if not stdout:
        return None
    try:
        facts = json.loads(stdout.splitlines()[-1])
    except (json.JSONDecodeError, TypeError):
        return None
    if not isinstance(facts, Mapping):
        return None
    target = str(facts.get("target") or "")
    if (
        facts.get("probe_kind") != _PARENT_EXPORT_PROBE_KIND
        or "." not in target
        or facts.get("target_spec_found") is not False
        or facts.get("target_imported") is not False
        or facts.get("target_import_error_type") != "ModuleNotFoundError"
        or facts.get("target_import_missing_name") != target
        or facts.get("parent_imported") is not True
        or facts.get("parent_has_leaf") is not True
        or facts.get("parent_leaf_callable") is not True
    ):
        return None
    return copy.deepcopy(dict(facts))


def _single_failed_missing_module(
    exact_sandbox_checks: Mapping[str, Any],
) -> str | None:
    targets: set[str] = set()
    failed_count = 0
    for check in exact_sandbox_checks.get("checks") or []:
        if not isinstance(check, Mapping) or check.get("status") == "passed":
            continue
        failed_count += 1
        matches = set(
            _MISSING_MODULE_PATTERN.findall(str(check.get("summary") or ""))
        )
        if not matches:
            return None
        targets.update(matches)
    if failed_count < 1 or len(targets) != 1:
        return None
    return next(iter(targets))


def _parent_export_probe_code(
    *, target: str, parent: str, leaf: str
) -> str:
    return (
        "import importlib\n"
        "import importlib.util\n"
        "import inspect\n"
        "import json\n\n"
        f"target = {target!r}\n"
        f"parent_name = {parent!r}\n"
        f"leaf = {leaf!r}\n"
        "facts = {\n"
        f"    'probe_kind': {_PARENT_EXPORT_PROBE_KIND!r},\n"
        "    'target': target,\n"
        "    'parent': parent_name,\n"
        "    'leaf': leaf,\n"
        "}\n"
        "try:\n"
        "    facts['target_spec_found'] = (\n"
        "        importlib.util.find_spec(target) is not None\n"
        "    )\n"
        "except Exception as exc:\n"
        "    facts['target_spec_found'] = None\n"
        "    facts['target_spec_error'] = f'{type(exc).__name__}: {exc}'\n"
        "try:\n"
        "    importlib.import_module(target)\n"
        "    facts['target_imported'] = True\n"
        "except Exception as exc:\n"
        "    facts['target_imported'] = False\n"
        "    facts['target_import_error_type'] = type(exc).__name__\n"
        "    facts['target_import_error'] = str(exc)\n"
        "    facts['target_import_missing_name'] = getattr(exc, 'name', None)\n"
        "try:\n"
        "    parent_module = importlib.import_module(parent_name)\n"
        "    facts['parent_imported'] = True\n"
        "    facts['parent_has_leaf'] = hasattr(parent_module, leaf)\n"
        "    value = getattr(parent_module, leaf, None)\n"
        "    facts['parent_leaf_callable'] = callable(value)\n"
        "    facts['parent_leaf_module'] = getattr(value, '__module__', None)\n"
        "    try:\n"
        "        facts['parent_leaf_signature'] = str(inspect.signature(value))\n"
        "    except (TypeError, ValueError):\n"
        "        facts['parent_leaf_signature'] = None\n"
        "except Exception as exc:\n"
        "    facts['parent_imported'] = False\n"
        "    facts['parent_import_error'] = f'{type(exc).__name__}: {exc}'\n"
        "print(json.dumps(facts, sort_keys=True))\n"
    )


def inspect_python_candidate_environment(
    runtime: Any,
    *,
    objective: Any,
    candidate: Mapping[str, Any],
    snapshot: Mapping[str, Any],
    exact_sandbox_checks: Mapping[str, Any],
    prior_attempts: list[dict[str, Any]],
    selection_purpose: str,
    artifact_purpose: str,
) -> dict[str, Any]:
    """Inspect one immutable candidate environment without changing it."""
    request = runtime.generate_json(
        PYTHON_ENVIRONMENT_PROBE_SYSTEM,
        json.dumps(
            {
                "objective": objective,
                "candidate_snapshot": copy.deepcopy(dict(snapshot)),
                "exact_sandbox_checks": exact_sandbox_checks,
                "prior_attempts": prior_attempts,
            },
            ensure_ascii=False,
            indent=2,
        ),
        purpose=selection_purpose,
        schema=PYTHON_ENVIRONMENT_PROBE_SCHEMA,
    )
    dependencies = [str(candidate["package_ref"])]
    evidence_ref = str(exact_sandbox_checks.get("evidence_ref") or "")
    if evidence_ref:
        dependencies.append(evidence_ref)
    receipt = runtime.call_route(
        "write_code_artifact",
        {
            "purpose": artifact_purpose + ":" + str(request["purpose"]),
            "python_code": str(request["python_code"]),
            "depends_on": dependencies,
        },
    )
    code_ref = str(receipt.get("code_artifact_ref") or "")
    runtime.read_ref(code_ref)
    result = runtime.call_route(
        "inspect_python_environment",
        {
            "environment_ref": str(candidate["package_ref"]),
            "code_artifact_ref": code_ref,
            "timeout_seconds": 120,
        },
    )
    return {
        "code_artifact_ref": code_ref,
        "status": result.get("status"),
        "returncode": result.get("returncode"),
        "stdout": result.get("stdout"),
        "stderr": result.get("stderr"),
    }


class PendingPythonEnvironmentLease:
    """Release run-scoped pending Route environments at Skill exit."""

    def __init__(self, runtime: Any, payload: Mapping[str, Any]) -> None:
        self._runtime = runtime
        self._package_refs: list[str] = []
        for item in payload.get("resolved_inputs") or []:
            if not isinstance(item, Mapping):
                continue
            candidate = item.get("machine_payload")
            if isinstance(candidate, Mapping):
                self.track(candidate)

    def __enter__(self) -> "PendingPythonEnvironmentLease":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> bool:
        del exc_value, traceback
        cleanup_error: Exception | None = None
        for package_ref in tuple(dict.fromkeys(self._package_refs)):
            try:
                self._runtime.call_route(
                    "capability_pending_environment_release",
                    {"package_ref": package_ref},
                )
            except Exception as exc:
                if cleanup_error is None:
                    cleanup_error = exc
        if cleanup_error is not None and exc_type is None:
            raise cleanup_error
        return False

    def track(self, candidate: Mapping[str, Any]) -> None:
        if str(candidate.get("asset_type") or "") != "route_package":
            return
        package_ref = str(candidate.get("package_ref") or "").strip()
        if package_ref:
            self._package_refs.append(package_ref)


AUTHOR_SKILL_SYSTEM = """\
Create one project-local Skill candidate for the exact task capability gap.
The result is pending only. Do not claim installation, approval, execution, or
scientific evidence. The supplied authoritative generated-Skill production
contract is the sole authority for candidate frontmatter, required body
sections, C0-C6 projection, production responsibility, formal output, and
failure behavior. Apply it to the first draft, not only after a validator
failure. SKILL.md is the generated Skill's source of truth. The
manifest purpose is only a catalog-navigation summary: write exactly one short
sentence, target at most 300 characters, naming the capability and its boundary.
Do not enumerate requirements there; preserve complete detail in SKILL.md.
Instantiate the supplied contract for the requested capability's production
behavior under task-local pending lineage or later global approval; do not copy
abstract guidance unchanged.
Its entry authority, workflow, formal output, consumer, failure behavior, and
C0-C6 meanings must belong to the requested capability, not to this external
meta-authoring invocation.
Use source_kind=inline for authored UTF-8 files. Use source_kind=path only to
copy an exact user-provided file named in the task. For path files, content must
be empty; for inline files, source_path must be empty. Never create approval
receipts or active-registry files. Author only the candidate package. Do not put
an advisory review, approval recommendation, sandbox verdict, or claimed test
evidence inside that package; candidate-review owns the separate downstream
review. Every declared Route dependency must copy an exact route_name and
package_hash pair from managed_route_dependencies. Never emit a generic
dependency name, blank hash, placeholder, version label, or guessed hash."""

ONBOARD_SKILL_SYSTEM = """\
Package one explicitly supplied third-party Skill without changing its owned
responsibility into a different capability. Preserve exact supplied files with
source_kind=path whenever available; author only the minimum wrapper or
SKILL.md corrections required by the project contract. The package remains
pending and executable Python must not be run here. Do not approve or install it."""

AUTHOR_ROUTE_SYSTEM = """\
Create one pending Route package for an explicit callable capability family.
Define bounded input and output JSON object schemas, one shared source/adapter
implementation, dependency lock, callable flags, visible Skill ids, complexity,
and only genuinely repairable JSON Pointer inputs. Every declared adapter
entrypoint is called by the host as function(route_input), where route_input is
the one JSON object validated by that Route's input schema. Therefore each
entrypoint must accept exactly that one mapping argument, unpack it internally,
and return one JSON object matching the output schema; do not expose one Python
positional argument per input property. Every required input must actually
control execution or be explicitly rejected. Do not merely echo a requested
method, model, basis, unit, or option in provenance while the implementation
uses a different default. Keep scientific choices explicit in the contract
rather than inferring them from names. Use inline files for newly authored
source and path files only for exact user-provided sources. Do not author
runtime.lock.json; the host binds the sealed package to its execution runtime
after submission. When the context contains one exact prior pending package,
repair only the explicitly supplied failure source. An author_development_gap
permits an implementation or adapter revision from the failed author test. Its
paired exact_python_environment_probe is authoritative for installed module
paths, exported symbols, signatures, source locations, and the observed import
chain; use it instead of guessing package APIs. Preserve the prior dependency
lock verbatim during this implementation repair. A hash-bound
needs_changes_review permits a revision of the exact review findings.
Preserve the requested capability and public Route names while addressing those
actual failed checks. A dependency-only failure belongs to Python Package
Resolver, not an implementation rewrite. The old package remains immutable. Do
not approve, activate, or claim successful execution."""

ONBOARD_ROUTE_SYSTEM = """\
Wrap explicitly supplied third-party source or function as one pending Route
package. Preserve the exact source by source_kind=path, keep adapter code thin,
declare dependencies exactly, and expose bounded JSON contracts. The host calls
every declared adapter entrypoint as function(route_input), with one input-
schema-validated JSON object; the thin adapter must accept that one mapping,
translate it to the third-party function's native signature, and return one
output-schema-valid JSON object. Every required Route input must affect the
native call or be explicitly rejected. Source code correctness does not imply
wrapper correctness. Do not rewrite the function into a different scientific
responsibility or author runtime.lock.json; the host owns runtime binding. Do
not approve or activate it."""

OPTIMIZATION_TARGET_SYSTEM = """\
Identify exactly one existing production Skill and one bounded improvement
purpose from the task. Do not propose edits yet and do not choose more than one
Skill."""

OPTIMIZATION_FILES_SYSTEM = """\
Produce one pending text-only revision of the supplied exact Skill baseline for
the single stated purpose. You may change only SKILL.md and references/*. Do not
change workflow.py, disclosure.py, scripts, Routes, schemas, or responsibility.
Preserve valid behavior and return the complete replacement text files, not a
patch. Do not approve or install the revision."""

REVIEW_PREFLIGHT_SYSTEM = """\
Inspect one exact pending capability package before its sandbox tests run. For
every Route, propose one honest small contract input that exercises the real
adapter; do not use mocks or omit a Route merely because it may fail. For a
Skill, leave route_tests empty. Assess constitutional responsibility,
prompt/validator/handoff alignment, and dependency precision from the exact
source snapshot. For a Skill, assess its production behavior separately from
its pending package lifecycle. Task-local pending use must preserve exact
candidate lineage and does not grant approval. Treat copied
skill-creation authorization, candidate-package authoring workflow,
capability_candidate formal output, or candidate-review handoff as a source
responsibility defect; a correctly pending package does not cure that defect.
For a Skill, follow skill_production_boundary_dossier.mandatory_review_order
before reading its remaining source. The contract_check summary must state the
candidate's declared production result, what its Skill-local workflow literally
does, and whether that workflow belongs to production or to the external
candidate-authoring lifecycle. If the workflow authors, validates, repairs,
seals, or publishes its own candidate package instead of producing the declared
production result, contract_check.status must be failed even when structure and
scientific detail are otherwise valid.
This call does not make the final recommendation. Do not treat the absence of
not-yet-created sandbox evidence as a source-contract defect.
Evidence refs must be selected only from exact refs visible in the supplied
context."""

REVIEW_DECISION_SYSTEM = """\
Make one advisory decision after the pending package's exact sandbox checks have
run. Read the preflight assessment and every mechanical check. A passed check is
real development evidence; failed or not_run checks remain explicit gaps.
Recommend approve only when all required checks passed and no material contract
gap remains. Use needs_changes for repairable gaps and reject only when the
capability responsibility or contract is fundamentally unsuitable. A defect
confined to candidate source sections, local workflow wording, handoff wording,
or another bounded package edit is repairable when the declared production
responsibility, dependencies, and formal result are otherwise suitable; classify
that case as needs_changes, not reject. When a Skill production-boundary dossier
is supplied, inspect its exact sections to determine repair scope instead of
inferring fundamental unsuitability from a failed status alone. This has no
promotion authority and must not claim scientific validation. Keep reason at
most 800 characters: state the classification difference and required action
without copying the full check summaries."""


CANDIDATE_PACKAGING_REPAIR_SYSTEM = """\
Repair one complete pending capability draft after its exact packaging was
rejected. This is a bounded structural repair, not a redesign or an approval.
Preserve the requested capability, public Route names, callable responsibility,
schemas, and valid source behavior unless the exact error requires a change.
Fix every occurrence of the reported problem and audit these adjacent package
invariants before returning the complete replacement draft:
- source_kind=inline requires complete content and an empty source_path;
- source_kind=path requires empty content and one exact supplied source_path;
- every declared source, adapter, and dependency-lock path has one file entry;
- every adapter_entrypoint module maps exactly to a declared adapter path;
- candidate ids, candidate package hash, file receipts, runtime.lock.json,
  approvals, and active state remain host-owned;
- Skill Route dependency names and hashes must be copied exactly from the
  supplied managed_route_dependencies catalog. Never guess or synthesize them;
- every packaged references/... file must be linked from root SKILL.md with
  Markdown link syntax [label](references/file); a code span or plain path is
  not a link and does not satisfy progressive disclosure;
- for a Skill structural failure, preserve every complete candidate file and
  use authoritative_packaging_context.candidate_production_contract as the
  sole frontmatter, body, C0-C6, and production-responsibility authority while
  correcting every validator issue before returning the complete replacement
  draft. Never substitute the external authoring lifecycle for that contract.
Do not claim that code executed or that the candidate was approved."""


def submit_candidate_with_one_repair(
    runtime: Any,
    *,
    draft: Mapping[str, Any],
    schema: Mapping[str, Any],
    manifest_builder: Callable[[Mapping[str, Any]], Mapping[str, Any]],
    repair_purpose: str,
    authoritative_packaging_context: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Seal one draft, allowing one model-owned structural packaging repair."""
    current = copy.deepcopy(dict(draft))

    def submit(value: Mapping[str, Any]) -> dict[str, Any]:
        return runtime.call_route(
            "capability_candidate_submit",
            {
                "manifest": dict(manifest_builder(value)),
                "files": copy.deepcopy(list(value.get("files") or [])),
            },
        )

    try:
        return submit(current)
    except (RuntimeError, ValueError) as exc:
        repair_context = {
            "exact_packaging_error": f"{type(exc).__name__}: {str(exc)}",
            "previous_complete_draft": current,
        }
        if authoritative_packaging_context:
            repair_context["authoritative_packaging_context"] = (
                copy.deepcopy(dict(authoritative_packaging_context))
            )
        repaired = runtime.generate_json(
            CANDIDATE_PACKAGING_REPAIR_SYSTEM,
            json.dumps(
                repair_context,
                ensure_ascii=False,
                indent=2,
            ),
            purpose=repair_purpose,
            schema=schema,
        )
        return submit(repaired)
