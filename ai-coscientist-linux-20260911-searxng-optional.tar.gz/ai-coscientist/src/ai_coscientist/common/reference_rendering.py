from __future__ import annotations

import base64
import hashlib
import html
from html.parser import HTMLParser
from typing import Callable

from .reference_links import ReferenceResolver


class _Links(HTMLParser):
    def __init__(self, anchor: Callable[[str], str], after_block: Callable[[], str]):
        super().__init__(convert_charrefs=False)
        self.anchor = anchor
        self.after_block = after_block
        self.parts: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag != "a" or not any(key == "href" and (value or "").startswith("reference:") for key, value in attrs):
            self.parts.append(self.get_starttag_text())
            return
        attrs = [(key, self.anchor(value) if key == "href" else value) for key, value in attrs]
        self.parts.append("<a" + "".join(
            " " + key if value is None else f' {key}="{html.escape(value, quote=True)}"'
            for key, value in attrs) + ">")

    def handle_startendtag(self, tag, attrs):
        self.parts.append(self.get_starttag_text())

    def handle_endtag(self, tag):
        self.parts.append(f"</{tag}>")
        if tag in {"p", "h1", "h2", "h3", "blockquote", "table", "ul", "ol"}:
            self.parts.append(self.after_block())

    def handle_data(self, data):
        self.parts.append(data)

    def handle_entityref(self, name):
        self.parts.append(f"&{name};")

    def handle_charref(self, name):
        self.parts.append(f"&#{name};")

    def handle_comment(self, data):
        self.parts.append(f"<!--{data}-->")

    def handle_decl(self, decl):
        self.parts.append(f"<!{decl}>")


def render_reference_links(markup: str, resolver: ReferenceResolver, *, inline: bool = False) -> str:
    """Resolve actual links to exact excerpts, optionally next to their source blocks."""
    excerpts: dict[str, str] = {}
    emitted: set[str] = set()

    def flush() -> str:
        pending = [key for key in excerpts if key not in emitted]
        emitted.update(pending)
        return "".join(excerpts[key] for key in pending)

    def anchor(link: str) -> str:
        key = "reference-" + hashlib.sha256(link.encode("utf-8")).hexdigest()[:20]
        if key in excerpts:
            return "#" + key
        selected = resolver.resolve(link)
        if selected.pdf:
            import pymupdf
            pages = []
            with pymupdf.open(stream=selected.body, filetype="pdf") as document:
                for index in selected.page_indices(len(document)):
                    png = document[index].get_pixmap(matrix=pymupdf.Matrix(1.5, 1.5)).tobytes("png")
                    pages.append(f'<figure><figcaption>原文第 {index + 1} 頁</figcaption>'
                        '<img style="width:100%;height:auto" alt="原始 PDF 頁面" '
                        f'src="data:image/png;base64,{base64.b64encode(png).decode()}" /></figure>')
            body = "".join(pages)
        else:
            body = ('<pre style="white-space:pre-wrap;overflow-wrap:anywhere">'
                    + html.escape(selected.text()) + "</pre>")
        excerpts[key] = (
            f'<section id="{key}" class="reference-excerpt" style="break-inside:auto;overflow-wrap:anywhere">'
            f'<h3>{html.escape(selected.label)}</h3>'
            f'<p>來源：{html.escape(str(selected.locator["ref"]))}<br>'
            f'內容版本：{selected.locator["content_sha256"]}</p>{body}</section>'
        )
        return "#" + key

    parser = _Links(anchor, flush if inline else lambda: "")
    parser.feed(markup)
    parser.close()
    result = "".join(parser.parts)
    appendix = flush()
    return result.replace("</body>", appendix + "</body>") if "</body>" in result else result + appendix
