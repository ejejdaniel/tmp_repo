from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from threading import Lock
from typing import Any, BinaryIO, Callable, Iterable, Mapping, Sequence

from .model import ModelTurn, ToolCall


StatusCallback = Callable[[Mapping[str, Any]], None]


_TRANSIENT_ATTEMPTS = 4
_REQUIRED_TOOL_REPEAT_MIN_CHARS = 2_048
_REQUIRED_TOOL_REPEAT_MIN_PERIOD = 16
_REQUIRED_TOOL_REPEAT_MAX_PERIOD = 512
_REQUIRED_TOOL_REPEAT_COUNT = 4


class ModelProtocolError(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        code: str = "",
        tool_name: str = "",
        raw_argument_chars: int = 0,
        finish_reason: str = "",
        json_error: str = "",
    ) -> None:
        super().__init__(message)
        self.code = code
        self.tool_name = tool_name
        self.raw_argument_chars = raw_argument_chars
        self.finish_reason = finish_reason
        self.json_error = json_error


def _invalid_tool_arguments_error(
    *,
    tool_name: str,
    raw_arguments: str,
    error: json.JSONDecodeError,
    finish_reason: str,
) -> ModelProtocolError:
    normalized_finish = finish_reason or "unknown"
    preview = repr(raw_arguments[:500])
    message = (
        f"tool_call_invalid_arguments:{tool_name}:"
        f"json_error={error.msg}:line={error.lineno}:column={error.colno}:"
        f"position={error.pos}:raw_chars={len(raw_arguments)}:"
        f"finish_reason={normalized_finish}:prefix={preview}"
    )
    return ModelProtocolError(
        message,
        code="tool_call_invalid_arguments",
        tool_name=tool_name,
        raw_argument_chars=len(raw_arguments),
        finish_reason=finish_reason,
        json_error=error.msg,
    )


@dataclass
class OpenAICompatibleModel:
    base_url: str
    model: str
    api_key: str = ""
    timeout_seconds: float = 600.0
    max_tokens: int = 16_384
    temperature: float = 0.0
    reasoning_effort: str = ""
    scientific_reasoning_effort: str = ""
    repair_reasoning_effort: str = ""
    planning_reasoning_effort: str = ""
    stream: bool = True
    on_status: StatusCallback | None = None
    debug_trace_path: str | Path | None = None
    _debug_sequence: int = field(default=0, init=False, repr=False)
    _debug_lock: Lock = field(default_factory=Lock, init=False, repr=False)

    def complete(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
        purpose: str,
        tool_choice: str | Mapping[str, Any] | None = None,
        max_output_tokens: int | None = None,
        _reasoning_effort_override: str | None = None,
    ) -> ModelTurn:
        effective_max_tokens = (
            self.max_tokens
            if max_output_tokens is None
            else int(max_output_tokens)
        )
        if effective_max_tokens < 1:
            raise ValueError("max_output_tokens_must_be_positive")
        effective_reasoning_effort = (
            self.reasoning_effort
            if _reasoning_effort_override is None
            else str(_reasoning_effort_override).strip()
        )
        endpoint = self.base_url.rstrip("/") + "/chat/completions"
        requires_tool_call = tool_choice == "required" or isinstance(
            tool_choice, Mapping
        )
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": list(messages),
            "stream": self.stream,
            "temperature": self.temperature,
            "max_tokens": effective_max_tokens,
        }
        if tools:
            payload["tools"] = list(tools)
            payload["tool_choice"] = tool_choice or "auto"
            if tool_choice in ("required", "auto") or isinstance(tool_choice, Mapping):
                payload["parallel_tool_calls"] = False
        if effective_reasoning_effort:
            payload["reasoning_effort"] = effective_reasoning_effort
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        request = urllib.request.Request(
            endpoint,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        turn: ModelTurn | None = None
        for attempt in range(_TRANSIENT_ATTEMPTS):
            reasoning_parts: list[str] = []
            self._status({"event": "start", "purpose": purpose})
            try:
                with urllib.request.urlopen(
                    request, timeout=self.timeout_seconds
                ) as response:
                    if self.stream:
                        turn = collect_openai_stream(
                            iter_sse_data(response),
                            purpose=purpose,
                            on_status=self.on_status,
                            on_reasoning_delta=reasoning_parts.append,
                            required_tool_call=requires_tool_call,
                        )
                    else:
                        raw_response = response.read().decode(
                            "utf-8", errors="replace"
                        )
                        turn = collect_openai_response(
                            json.loads(raw_response),
                            on_reasoning_delta=reasoning_parts.append,
                        )
                    turn = recover_embedded_harmony_tool_call(turn, tools)
                    self._record_reasoning_debug(
                        purpose=purpose,
                        attempt=attempt + 1,
                        reasoning_effort_sent=effective_reasoning_effort,
                        reasoning_content="".join(reasoning_parts),
                        turn=turn,
                    )
                    required_tool_missing = (
                        tools and requires_tool_call and not turn.tool_calls
                    )
                    empty_turn = not turn.tool_calls and not turn.content.strip()
                    if empty_turn and turn.finish_reason == "length":
                        self._status({
                            "event": "error", "purpose": purpose,
                            "reason": "model_output_limit_without_answer",
                        })
                        # Exhausted generation is not a transient transport error.
                        # The owning workflow may repair its request, never this
                        # client replaying the identical reasoning task.
                        raise ModelProtocolError("model_output_limit_without_answer")
                    if empty_turn:
                        self._status(
                            {
                                "event": "error",
                                "purpose": purpose,
                                "reason": "empty_model_turn",
                            }
                        )
                        if attempt < _TRANSIENT_ATTEMPTS - 1:
                            turn = None
                            time.sleep(min(2.0**attempt, 4.0))
                            continue
                        raise ModelProtocolError("empty_model_turn_after_retry")
                    if required_tool_missing:
                        self._status(
                            {
                                "event": "error",
                                "purpose": purpose,
                                "reason": "required_tool_call_missing",
                            }
                        )
                        # Tool-contract enforcement belongs to the caller. Some
                        # callers can recover mechanically from a nonempty turn.
            except urllib.error.HTTPError as exc:
                body = exc.read().decode("utf-8", errors="replace")
                self._status(
                    {
                        "event": "error",
                        "purpose": purpose,
                        "status": exc.code,
                        "body": body,
                    }
                )
                if (
                    exc.code == 400
                    and attempt < _TRANSIENT_ATTEMPTS - 1
                ):
                    time.sleep(min(2.0**attempt, 4.0))
                    continue
                raise RuntimeError(
                    f"llm_http_error:{exc.code}:{body[:2000]}"
                ) from exc
            except urllib.error.URLError as exc:
                self._status(
                    {"event": "error", "purpose": purpose, "reason": str(exc)}
                )
                raise RuntimeError(f"llm_connection_error:{exc}") from exc
            break
        if turn is None:
            raise RuntimeError("llm_response_missing_after_transport_retry")
        self._status(
            {
                "event": "finish",
                "purpose": purpose,
                "tool_calls": len(turn.tool_calls),
                "content_chars": len(turn.content),
                "finish_reason": turn.finish_reason or None,
            }
        )
        return turn

    def complete_without_reasoning(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
        purpose: str,
        tool_choice: str | Mapping[str, Any] | None = None,
        max_output_tokens: int | None = None,
    ) -> ModelTurn:
        return self.complete(
            messages=messages, tools=tools, purpose=purpose,
            tool_choice=tool_choice, max_output_tokens=max_output_tokens,
            _reasoning_effort_override="none",
        )

    def complete_repair(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
        purpose: str,
        tool_choice: str | Mapping[str, Any] | None = None,
        max_output_tokens: int | None = None,
    ) -> ModelTurn:
        return self.complete(
            messages=messages,
            tools=tools,
            purpose=purpose,
            tool_choice=tool_choice,
            max_output_tokens=max_output_tokens,
            _reasoning_effort_override=(
                self.repair_reasoning_effort or self.reasoning_effort
            ),
        )

    def complete_scientific(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
        purpose: str,
        tool_choice: str | Mapping[str, Any] | None = None,
        max_output_tokens: int | None = None,
    ) -> ModelTurn:
        return self.complete(
            messages=messages,
            tools=tools,
            purpose=purpose,
            tool_choice=tool_choice,
            max_output_tokens=max_output_tokens,
            _reasoning_effort_override=(
                self.scientific_reasoning_effort or self.reasoning_effort
            ),
        )

    def complete_planning(
        self,
        *,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
        purpose: str,
        tool_choice: str | Mapping[str, Any] | None = None,
        max_output_tokens: int | None = None,
    ) -> ModelTurn:
        return self.complete(
            messages=messages,
            tools=tools,
            purpose=purpose,
            tool_choice=tool_choice,
            max_output_tokens=max_output_tokens,
            _reasoning_effort_override=(
                self.planning_reasoning_effort or self.reasoning_effort
            ),
        )

    def _status(self, event: Mapping[str, Any]) -> None:
        if self.on_status is not None:
            self.on_status(event)

    def _record_reasoning_debug(
        self,
        *,
        purpose: str,
        attempt: int,
        reasoning_effort_sent: str,
        reasoning_content: str,
        turn: ModelTurn,
    ) -> None:
        if self.debug_trace_path is None:
            return
        path = Path(self.debug_trace_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with self._debug_lock:
            self._debug_sequence += 1
            record = {
                "debug_sequence": self._debug_sequence,
                "timestamp_unix": time.time(),
                "purpose": purpose,
                "attempt": attempt,
                "model": self.model,
                "reasoning_effort_sent": reasoning_effort_sent or None,
                "reasoning_content_chars": len(reasoning_content),
                "reasoning_content": reasoning_content,
                "visible_content_chars": len(turn.content),
                "tool_call_names": [call.name for call in turn.tool_calls],
                "finish_reason": turn.finish_reason or None,
                "usage": dict(turn.usage),
            }
            with path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def _normalize_tool_call_arguments(
    tool_name: str, arguments: Mapping[str, Any]
) -> dict[str, Any]:
    if set(arguments) <= {"name", "arguments", "args"}:
        nested_name = arguments.get("name")
        nested_keys = [key for key in ("arguments", "args") if key in arguments]
        nested_arguments = (
            arguments.get(nested_keys[0]) if len(nested_keys) == 1 else None
        )
        if nested_name == tool_name and isinstance(nested_arguments, Mapping):
            return dict(nested_arguments)
    return dict(arguments)


def visible_tool_protocol_issue(content: str) -> str:
    """Reject wire-format tool text, not quoted protocol documentation.

    Native tool_calls are the execution authority. Do not interpret leaked text
    as additional actions, even when a valid native call accompanied it.
    """
    fence = ""
    for line in content.splitlines():
        boundary = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", line)
        if boundary:
            marker, suffix = boundary.groups()
            if not fence:
                fence = marker
            elif marker[0] == fence[0] and len(marker) >= len(fence) and not suffix.strip():
                fence = ""
            continue
        if fence:
            continue
        unquoted = re.sub(r"(`+)(.*?)\1", "", line)
        if re.search(
            r"</?\uff5cDSML\uff5c|<\uff5c\uff5ctool|<\|(?:channel|message|tool_call)\|>",
            unquoted,
        ):
            return "visible_tool_protocol_in_content"
    return ""


def recover_embedded_harmony_tool_call(
    turn: ModelTurn,
    tools: Sequence[Mapping[str, Any]],
) -> ModelTurn:
    """Recover a valid declared tool call leaked as Harmony protocol text."""
    if turn.tool_calls or not tools:
        return turn
    content = turn.content.strip()
    if not content.startswith("<|channel|>") or "<|message|>" not in content:
        return turn
    recipient = re.search(
        r"\bto=functions\.([A-Za-z_][A-Za-z0-9_.-]*)\b",
        content,
    )
    if recipient is None:
        return turn
    tool_name = recipient.group(1)
    declared_names = {
        str(function.get("name") or "")
        for tool in tools
        if isinstance(tool, Mapping)
        for function in [tool.get("function")]
        if isinstance(function, Mapping)
    }
    if tool_name not in declared_names:
        return turn
    raw_payload = content.split("<|message|>", 1)[1].lstrip()
    try:
        arguments, end = json.JSONDecoder().raw_decode(raw_payload)
    except json.JSONDecodeError:
        return turn
    remainder = raw_payload[end:].strip()
    if remainder and re.fullmatch(r"(?:<\|[^|]+\|>\s*)+", remainder) is None:
        return turn
    if not isinstance(arguments, Mapping):
        return turn
    return ModelTurn(
        content="",
        tool_calls=(
            ToolCall(
                call_id="embedded_harmony_call_0",
                name=tool_name,
                arguments=_normalize_tool_call_arguments(tool_name, arguments),
            ),
        ),
        usage=turn.usage,
        finish_reason=turn.finish_reason,
    )


def collect_openai_response(
    response: Mapping[str, Any],
    *,
    on_reasoning_delta: Callable[[str], None] | None = None,
) -> ModelTurn:
    choices = response.get("choices") or []
    if not choices or not isinstance(choices[0], Mapping):
        raise ModelProtocolError("response_choice_missing")
    message = choices[0].get("message") or {}
    if not isinstance(message, Mapping):
        raise ModelProtocolError("response_message_invalid")
    raw_finish_reason = choices[0].get("finish_reason")
    finish_reason = (
        str(raw_finish_reason).strip()
        if isinstance(raw_finish_reason, str)
        else ""
    )
    content = message.get("content")
    content = content if isinstance(content, str) else ""
    reasoning_content = message.get("reasoning_content") or message.get("reasoning")
    if isinstance(reasoning_content, str) and on_reasoning_delta is not None:
        on_reasoning_delta(reasoning_content)
    tool_calls: list[ToolCall] = []
    for index, raw_call in enumerate(message.get("tool_calls") or []):
        if not isinstance(raw_call, Mapping):
            raise ModelProtocolError(f"tool_call_invalid:{index}")
        function = raw_call.get("function") or {}
        if not isinstance(function, Mapping):
            raise ModelProtocolError(f"tool_call_function_invalid:{index}")
        name = str(function.get("name") or "")
        if not name:
            raise ModelProtocolError(f"tool_call_missing_name:{index}")
        raw_argument_value = function.get("arguments")
        if (
            "arguments" not in function
            or raw_argument_value is None
            or raw_argument_value == ""
        ):
            raise ModelProtocolError(f"tool_call_missing_arguments:{name}")
        raw_arguments = raw_argument_value
        if isinstance(raw_arguments, str):
            try:
                arguments = json.loads(raw_arguments)
            except json.JSONDecodeError as exc:
                raise _invalid_tool_arguments_error(
                    tool_name=name,
                    raw_arguments=raw_arguments,
                    error=exc,
                    finish_reason=finish_reason,
                ) from exc
        else:
            arguments = raw_arguments
        if not isinstance(arguments, Mapping):
            raise ModelProtocolError(
                f"tool_call_arguments_must_be_object:{name}"
            )
        tool_calls.append(
            ToolCall(
                call_id=str(raw_call.get("id") or f"call_{index}"),
                name=name,
                arguments=_normalize_tool_call_arguments(name, arguments),
            )
        )
    usage = response.get("usage")
    return ModelTurn(
        content=content,
        tool_calls=tuple(tool_calls),
        usage=dict(usage) if isinstance(usage, Mapping) else {},
        finish_reason=finish_reason,
    )


def iter_sse_data(stream: BinaryIO) -> Iterable[str]:
    for raw_line in stream:
        line = raw_line.decode("utf-8", errors="replace").strip()
        if not line or line.startswith(":") or not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if data == "[DONE]":
            break
        yield data


def collect_openai_stream(
    events: Iterable[str],
    *,
    purpose: str,
    on_status: StatusCallback | None = None,
    on_reasoning_delta: Callable[[str], None] | None = None,
    required_tool_call: bool = False,
) -> ModelTurn:
    content_parts: list[str] = []
    call_parts: dict[int, dict[str, str]] = {}
    usage: dict[str, Any] = {}
    finish_reason = ""
    for data in events:
        try:
            chunk = json.loads(data)
        except json.JSONDecodeError as exc:
            raise ModelProtocolError(f"invalid_sse_json:{data[:500]}") from exc
        if isinstance(chunk.get("usage"), Mapping):
            usage.update(chunk["usage"])
        choices = chunk.get("choices") or []
        if not choices:
            continue
        raw_finish_reason = choices[0].get("finish_reason")
        if isinstance(raw_finish_reason, str):
            finish_reason = raw_finish_reason.strip()
        delta = choices[0].get("delta") or {}
        reasoning_content = delta.get("reasoning_content") or delta.get("reasoning")
        if isinstance(reasoning_content, str) and on_reasoning_delta is not None:
            on_reasoning_delta(reasoning_content)
        content = delta.get("content")
        if isinstance(content, str):
            content_parts.append(content)
            if on_status is not None:
                on_status(
                    {
                        "event": "delta",
                        "purpose": purpose,
                        "content_chars": len(content),
                    }
                )
        for fragment in delta.get("tool_calls") or []:
            index = int(fragment.get("index", 0))
            current = call_parts.setdefault(
                index, {"id": "", "name": "", "arguments": ""}
            )
            if fragment.get("id"):
                current["id"] = str(fragment["id"])
            function = fragment.get("function") or {}
            if function.get("name"):
                current["name"] += str(function["name"])
            if function.get("arguments"):
                current["arguments"] += str(function["arguments"])
        # JSON arguments do not end the message. Consume through the SSE end
        # so late ordinary text and the final usage chunk are also preserved.
        if (
            required_tool_call
            and not call_parts
            and _has_repeated_visible_suffix("".join(content_parts))
        ):
            raise ModelProtocolError(
                "repeated_visible_content_before_required_tool_call"
            )

    tool_calls: list[ToolCall] = []
    for index in sorted(call_parts):
        part = call_parts[index]
        if not part["name"]:
            raise ModelProtocolError(f"tool_call_missing_name:{index}")
        raw_arguments = part["arguments"]
        if not raw_arguments:
            raise ModelProtocolError(
                f"tool_call_missing_arguments:{part['name']}"
            )
        try:
            arguments = json.loads(raw_arguments)
        except json.JSONDecodeError as exc:
            raise _invalid_tool_arguments_error(
                tool_name=part["name"],
                raw_arguments=raw_arguments,
                error=exc,
                finish_reason=finish_reason,
            ) from exc
        if not isinstance(arguments, Mapping):
            raise ModelProtocolError(
                f"tool_call_arguments_must_be_object:{part['name']}"
            )
        normalized_arguments = _normalize_tool_call_arguments(part["name"], arguments)
        tool_calls.append(
            ToolCall(
                call_id=part["id"] or f"call_{index}",
                name=part["name"],
                arguments=normalized_arguments,
            )
        )
    return ModelTurn(
        content="".join(content_parts),
        tool_calls=tuple(tool_calls),
        usage=usage,
        finish_reason=finish_reason,
    )


def _has_repeated_visible_suffix(content: str) -> bool:
    if len(content) < _REQUIRED_TOOL_REPEAT_MIN_CHARS:
        return False
    maximum_period = min(
        _REQUIRED_TOOL_REPEAT_MAX_PERIOD,
        len(content) // _REQUIRED_TOOL_REPEAT_COUNT,
    )
    for period in range(_REQUIRED_TOOL_REPEAT_MIN_PERIOD, maximum_period + 1):
        repeated = content[-period:]
        if not repeated.strip():
            continue
        if content.endswith(repeated * _REQUIRED_TOOL_REPEAT_COUNT):
            return True
    return False
