from __future__ import annotations

import copy
from typing import Any, Mapping, Sequence

from ._runtime_support import exact_string_refs
from .planning import active_work_unit, active_work_unit_context_refs


_GLOBAL_EVALUATION_CONFIRMATION_PREFIX = (
    "Confirm Global Evaluation amendment and start a new Frame:\n"
)
_GLOBAL_EVALUATION_CONFIRMATION_REASON = (
    "global_evaluation_amendment_confirmation:"
)


class HumanInteractionRuntimeMixin:
    """Host-facing and model-facing boundaries for one global interruption."""

    def pending_human_interaction(self) -> dict[str, Any] | None:
        pending = self._sub_loop_toolkit.pending()
        if pending is not None:
            return pending
        child = self._paused_child_runtime()
        if child is None:
            return None
        return child.pending_human_interaction()

    def submit_human_response(
        self,
        request_id: str,
        response_text: str,
        declared_response_role: str | None = None,
        attachment_refs: Sequence[str] = (),
    ) -> dict[str, Any]:
        local_pending = self._sub_loop_toolkit.pending()
        if local_pending is not None:
            return self._sub_loop_toolkit.submit_response(
                request_id=request_id,
                response_text=response_text,
                declared_response_role=declared_response_role,
                attachment_refs=attachment_refs,
            )
        child = self._paused_child_runtime()
        if child is not None and child.pending_human_interaction() is not None:
            receipt = child.submit_human_response(
                request_id=request_id,
                response_text=response_text,
                declared_response_role=declared_response_role,
                attachment_refs=attachment_refs,
            )
            self._quarantine_child_outputs(child)
            return receipt
        raise RuntimeError("human_interaction_pending_request_required")

    def _request_human_input(
        self,
        arguments: Mapping[str, Any],
        *,
        allowed_scopes: Sequence[str] | None = None,
        extra_context_refs: Sequence[str] = (),
    ) -> Mapping[str, Any]:
        paused_child = self._paused_child_runtime()
        child_interaction = (
            paused_child._sub_loop_toolkit.current()
            if paused_child is not None
            else None
        )
        if child_interaction is not None and child_interaction["status"] != "idle":
            raise RuntimeError(
                "human_interaction_already_active_in_child:"
                f"{child_interaction['request_id']}"
            )
        scopes = tuple(allowed_scopes or self._available_human_scopes())
        visible_refs = tuple(
            dict.fromkeys(
                [*self._visible_human_context_refs(), *extra_context_refs]
            )
        )
        state = self._state.read()
        requester = str(state["c1"]["active_skill_id"] or "main_agent")
        requested_context_refs = tuple(
            dict.fromkeys(
                [
                    *(arguments.get("context_refs") or ()),
                    *extra_context_refs,
                ]
            )
        )
        expected_role = str(
            arguments.get("expected_response_role") or ""
        ).strip()
        requested_scope = str(arguments.get("scope") or "").strip()
        question = str(arguments.get("question") or "").strip()
        reason = str(arguments.get("reason") or "").strip()
        if (
            expected_role == "task_contract_change"
            and requested_scope
            not in {
                "task_formulation",
                "evaluation_build",
                "evaluation_judgment",
            }
        ):
            if not question.startswith(_GLOBAL_EVALUATION_CONFIRMATION_PREFIX):
                question = _GLOBAL_EVALUATION_CONFIRMATION_PREFIX + question
            if not reason.startswith(_GLOBAL_EVALUATION_CONFIRMATION_REASON):
                reason = _GLOBAL_EVALUATION_CONFIRMATION_REASON + reason
        return self._sub_loop_toolkit.request(
            scope=requested_scope,
            requester=requester,
            question=question,
            reason=reason,
            expected_response_role=expected_role,
            context_refs=requested_context_refs,
            resume_anchor=self._human_resume_anchor(),
            allowed_scopes=scopes,
            allowed_context_refs=visible_refs,
        )

    def _available_human_scopes(self) -> tuple[str, ...]:
        if not self._human_in_loop_enabled or not self._state.path.exists():
            return ()
        state = self._state.read()
        control_phase = str(
            state["c1"]["task_contract_state"]["phase"]
        )
        if control_phase == "task_formulation":
            return ("task_formulation",)
        if control_phase == "evaluation_build":
            return ("evaluation_build",)
        if control_phase == "contract_reconciliation":
            return ("task_formulation", "evaluation_judgment")
        active = active_work_unit(state["c1"]["plan_graph"])
        if active is None:
            return ()
        loop = state["c1"]["node_loop_state"]
        scopes = ["attempt"]
        if (
            str(loop.get("node_id") or "") == str(active["node_id"])
            and loop.get("steps")
            and int(loop.get("next_step_index") or 0) < len(loop["steps"])
        ):
            scopes.insert(0, "step")
        return tuple(scopes)

    def _human_resume_anchor(self) -> dict[str, Any]:
        state = self._state.read()
        graph = state["c1"]["plan_graph"]
        active = active_work_unit(graph)
        loop = state["c1"]["node_loop_state"]
        return {
            "control_phase": str(
                state["c1"]["task_contract_state"]["phase"]
            ),
            "graph_revision": int(graph["revision"]),
            "node_id": str(active["node_id"]) if active is not None else "",
            "attempt_index": int(loop.get("attempt_index") or 0),
            "step_index": int(loop.get("next_step_index") or 0),
        }

    def _visible_human_context_refs(self) -> tuple[str, ...]:
        state = self._state.read()
        values: list[Any] = [
            state["c1"]["resolved_artifact_refs"],
            state["c1"]["recent_bounded_receipts"],
            state["c1"]["node_loop_state"],
            self._active_artifact_index(),
            active_work_unit_context_refs(state["c1"]["plan_graph"]),
        ]
        refs: list[str] = []
        allowed_prefixes = (
            "artifact:",
            "code_artifact:",
            "execution_observation:",
            "source_file:",
            "source_probe:",
            "workspace_terminal:",
        )
        for value in values:
            for ref in exact_string_refs(value):
                if ref.startswith(allowed_prefixes) and ref not in refs:
                    refs.append(ref)
        return tuple(refs)

    def _validate_human_context_ref(self, raw_ref: str) -> None:
        ref = str(raw_ref).strip()
        if not ref:
            raise ValueError("human_interaction_ref_required")
        if ref.startswith(
            ("source_file:", "source_probe:", "workspace_terminal:")
        ):
            if ref not in self._visible_human_context_refs():
                raise PermissionError(f"human_interaction_ref_not_visible:{ref}")
            return
        self._read_exact_ref(ref)

    def _human_interaction_prompt_projection(self) -> dict[str, Any] | None:
        current = self._sub_loop_toolkit.current()
        if current is None or current["status"] == "idle":
            return None
        return copy.deepcopy(current)

    def _answered_human_response_refs(self) -> tuple[str, ...]:
        if not self._state.path.exists():
            return ()
        interaction = self._state.read()["c1"]["human_interaction_state"]
        if interaction["status"] != "answered":
            return ()
        response_ref = str(interaction["response_ref"])
        stored = self._read_exact_ref(response_ref)
        if stored.get("artifact_kind") != "human_interaction_response":
            raise RuntimeError("human_interaction_response_kind_invalid")
        return (response_ref,)

    def _human_response_requires_new_frame(self) -> bool:
        current = self._sub_loop_toolkit.current()
        if current is None or current["status"] != "answered":
            return False
        response = self._read_exact_ref(str(current["response_ref"]))
        payload = response.get("machine_payload")
        return bool(
            isinstance(payload, Mapping)
            and payload.get("declared_response_role") == "task_contract_change"
            and current["expected_response_role"] == "task_contract_change"
            and str(current["reason"]).startswith(
                _GLOBAL_EVALUATION_CONFIRMATION_REASON
            )
        )

    def _pending_global_evaluation_confirmation(self) -> bool:
        current = self._sub_loop_toolkit.pending()
        return bool(
            current is not None
            and current["expected_response_role"] == "task_contract_change"
            and str(current["reason"]).startswith(
                _GLOBAL_EVALUATION_CONFIRMATION_REASON
            )
        )

    def _confirmed_global_evaluation_requirement(self) -> str | None:
        if not self._human_response_requires_new_frame():
            return None
        current = self._sub_loop_toolkit.current()
        if current is None:
            return None
        question = str(current["question"])
        if not question.startswith(_GLOBAL_EVALUATION_CONFIRMATION_PREFIX):
            raise RuntimeError(
                "global_evaluation_confirmation_question_invalid"
            )
        requirement = question[len(_GLOBAL_EVALUATION_CONFIRMATION_PREFIX) :].strip()
        if not requirement:
            raise RuntimeError(
                "global_evaluation_confirmation_requirement_missing"
            )
        return requirement

    def _human_resume_anchor_is_current(self) -> bool:
        current = self._sub_loop_toolkit.current()
        if current is None or current["status"] != "answered":
            return True
        return current["resume_anchor"] == self._human_resume_anchor()

    def _mark_human_answer_consumed(self, *, consumer: str) -> None:
        self._sub_loop_toolkit.mark_answer_consumed(consumer=consumer)
