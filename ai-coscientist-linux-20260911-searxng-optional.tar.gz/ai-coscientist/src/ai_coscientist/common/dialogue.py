from __future__ import annotations

import copy
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence


class DialogueStoreError(RuntimeError):
    pass


HUMAN_CONVERSATION_ROLES = frozenset(
    {"feedback", "scientific_input", "task_contract_change"}
)


@dataclass(frozen=True)
class DialogueTurnResult:
    status: str
    turn_id: str
    message: str
    research_status: str = ""
    rounds: int = 0
    closure: Mapping[str, Any] = field(default_factory=dict)
    evidence_refs: tuple[str, ...] = ()


class DialogueStore:
    """Append-only C4 storage for exact run-scoped human dialogue."""

    def __init__(self, root: Path) -> None:
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "transcript.jsonl"
        if not self.path.exists():
            self.path.touch()
        self._messages: list[dict[str, Any]] = []
        self._by_id: dict[str, dict[str, Any]] = {}
        self._file_signature: tuple[int, int] | None = None
        self._reload()

    def append_message(
        self,
        *,
        message_id: str,
        turn_id: str,
        role: str,
        content: str,
        attachment_refs: Sequence[str] = (),
        evidence_refs: Sequence[str] = (),
    ) -> dict[str, Any]:
        message = {
            "message_id": str(message_id).strip(),
            "turn_id": str(turn_id).strip(),
            "role": str(role).strip(),
            "content": str(content).strip(),
            "attachment_refs": _normalized_refs(attachment_refs),
            "evidence_refs": _normalized_refs(evidence_refs),
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        _validate_message(message)
        self._refresh_if_changed()
        if message["message_id"] in self._by_id:
            raise DialogueStoreError(
                f"dialogue_message_id_exists:{message['message_id']}"
            )
        serialized = json.dumps(message, ensure_ascii=False, sort_keys=True)
        with self.path.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(serialized + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        self._messages.append(copy.deepcopy(message))
        self._by_id[message["message_id"]] = copy.deepcopy(message)
        self._file_signature = self._current_file_signature()
        return dict(message)

    def read(self) -> tuple[dict[str, Any], ...]:
        self._refresh_if_changed()
        return tuple(copy.deepcopy(self._messages))

    def _reload(self) -> None:
        messages: list[dict[str, Any]] = []
        seen_ids: set[str] = set()
        for line_number, raw_line in enumerate(
            self.path.read_text(encoding="utf-8").splitlines(), start=1
        ):
            if not raw_line.strip():
                continue
            try:
                value = json.loads(raw_line)
            except json.JSONDecodeError as exc:
                raise DialogueStoreError(
                    f"dialogue_transcript_invalid_json:line={line_number}:{exc}"
                ) from exc
            _validate_message(value)
            message_id = str(value["message_id"])
            if message_id in seen_ids:
                raise DialogueStoreError(
                    f"dialogue_message_id_duplicated:{message_id}"
                )
            seen_ids.add(message_id)
            messages.append(dict(value))
        self._messages = messages
        self._by_id = {
            str(message["message_id"]): copy.deepcopy(message)
            for message in messages
        }
        self._file_signature = self._current_file_signature()

    def _refresh_if_changed(self) -> None:
        if self._current_file_signature() != self._file_signature:
            self._reload()

    def _current_file_signature(self) -> tuple[int, int] | None:
        if not self.path.exists():
            return None
        stat = self.path.stat()
        return stat.st_size, stat.st_mtime_ns

    def get(self, message_id: str) -> dict[str, Any]:
        normalized = str(message_id).strip()
        self._refresh_if_changed()
        message = self._by_id.get(normalized)
        if message is not None:
            return copy.deepcopy(message)
        raise KeyError(f"dialogue_message_unknown:{normalized}")

    def recent(self, *, max_bytes: int) -> tuple[dict[str, Any], ...]:
        if max_bytes < 1:
            raise ValueError("dialogue_recent_max_bytes_must_be_positive")
        selected: list[dict[str, Any]] = []
        used = 0
        self._refresh_if_changed()
        for message in reversed(self._messages):
            size = len(
                json.dumps(message, ensure_ascii=False).encode("utf-8")
            )
            if used + size > max_bytes:
                break
            selected.append(dict(message))
            used += size
        selected.reverse()
        return tuple(selected)


def publish_human_conversation_input(
    *,
    artifacts: Any,
    events: Any,
    user_message: Mapping[str, Any],
    declared_response_role: str,
) -> str:
    """Publish one exact human message without changing control state."""
    payload = {
        "artifact_kind": "human_conversation_input",
        "message_id": str(user_message["message_id"]),
        "turn_id": str(user_message["turn_id"]),
        "declared_response_role": str(declared_response_role),
        "attachment_refs": list(user_message["attachment_refs"]),
    }
    validate_human_conversation_input(payload)
    attachments = tuple(str(ref) for ref in user_message["attachment_refs"])
    receipt = artifacts.publish(
        artifact_kind="human_conversation_input",
        artifact_id=f"human-conversation-{user_message['message_id']}",
        title=f"Human conversation input {user_message['message_id']}",
        markdown=str(user_message["content"]),
        summary=f"Human supplied {declared_response_role} through chat.",
        status=(
            "proposed"
            if declared_response_role == "task_contract_change"
            else "accepted"
        ),
        machine_payload=payload,
        depends_on=tuple(
            ref for ref in attachments if ref.startswith("artifact:")
        ),
        trace_refs=attachments,
        verified_external_dependencies=tuple(
            ref for ref in attachments if not ref.startswith("artifact:")
        ),
    )
    ref = str(receipt["artifact_ref"])
    events.append(
        "dialogue_input_promoted",
        {
            "turn_id": user_message["turn_id"],
            "message_id": user_message["message_id"],
            "artifact_ref": ref,
            "declared_response_role": declared_response_role,
        },
    )
    return ref


def _normalized_refs(values: Sequence[str]) -> list[str]:
    return list(
        dict.fromkeys(str(value).strip() for value in values if str(value).strip())
    )


def validate_human_conversation_input(value: Any) -> None:
    if not isinstance(value, Mapping):
        raise ValueError("human_conversation_input_payload_must_be_object")
    expected = {
        "artifact_kind",
        "message_id",
        "turn_id",
        "declared_response_role",
        "attachment_refs",
    }
    if set(value) != expected:
        raise ValueError("human_conversation_input_payload_fields_invalid")
    if value["artifact_kind"] != "human_conversation_input":
        raise ValueError("human_conversation_input_artifact_kind_invalid")
    if not all(
        isinstance(value[field], str) and value[field].strip()
        for field in ("message_id", "turn_id")
    ):
        raise ValueError("human_conversation_input_identity_invalid")
    if value["declared_response_role"] not in HUMAN_CONVERSATION_ROLES:
        raise ValueError("human_conversation_input_role_invalid")
    refs = value["attachment_refs"]
    if (
        not isinstance(refs, list)
        or not all(isinstance(ref, str) and ref for ref in refs)
        or len(refs) != len(set(refs))
    ):
        raise ValueError("human_conversation_input_attachment_refs_invalid")


def _validate_message(value: Any) -> None:
    if not isinstance(value, Mapping):
        raise DialogueStoreError("dialogue_message_must_be_object")
    expected = {
        "message_id",
        "turn_id",
        "role",
        "content",
        "attachment_refs",
        "evidence_refs",
        "created_at",
    }
    if set(value) != expected:
        raise DialogueStoreError("dialogue_message_fields_invalid")
    if value["role"] not in {"user", "assistant"}:
        raise DialogueStoreError("dialogue_message_role_invalid")
    if not all(
        isinstance(value[field], str) and value[field].strip()
        for field in ("message_id", "turn_id", "content", "created_at")
    ):
        raise DialogueStoreError("dialogue_message_text_invalid")
    for ref_field in ("attachment_refs", "evidence_refs"):
        refs = value[ref_field]
        if (
            not isinstance(refs, list)
            or not all(isinstance(ref, str) and ref for ref in refs)
            or len(refs) != len(set(refs))
        ):
            raise DialogueStoreError(
                f"dialogue_message_{ref_field}_invalid"
            )
    try:
        timestamp = datetime.fromisoformat(value["created_at"])
    except ValueError as exc:
        raise DialogueStoreError("dialogue_message_created_at_invalid") from exc
    if timestamp.tzinfo is None:
        raise DialogueStoreError("dialogue_message_created_at_timezone_required")
