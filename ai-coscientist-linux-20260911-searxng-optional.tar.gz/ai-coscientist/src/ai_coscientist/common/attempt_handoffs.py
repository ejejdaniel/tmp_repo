from __future__ import annotations

from typing import Any, Mapping, Sequence

from .memory_lifecycle.prompt import bounded_text


def build_node_attempt_handoff(
    *, node_id: str, attempt_index: int, executor: str, status: str,
    formal_result_refs: Sequence[str] = (), operational_refs: Sequence[str] = (),
    child_id: str = "", work_context_ref: str | None = None,
) -> dict[str, Any]:
    """Graph failure audit link, not a copy of mutable development state."""
    if not node_id.strip():
        raise ValueError("node_attempt_handoff_node_id_required")
    if isinstance(attempt_index, bool) or not isinstance(attempt_index, int) or attempt_index < 1:
        raise ValueError("node_attempt_handoff_attempt_index_invalid")
    if executor not in {"child", "local"}:
        raise ValueError("node_attempt_handoff_executor_invalid")
    if work_context_ref is not None and not work_context_ref.startswith("work_context:"):
        raise ValueError("node_attempt_handoff_work_context_invalid")
    return {
        "node_id": node_id, "attempt_index": attempt_index, "executor": executor,
        "child_id": child_id, "status": bounded_text(status, 400),
        "work_context_ref": work_context_ref,
        "operational_refs": list(dict.fromkeys(operational_refs)),
        "formal_result_refs": list(dict.fromkeys(formal_result_refs)),
    }


def node_attempt_handoff_issue(handoff: Mapping[str, Any]) -> str:
    return bounded_text(
        f"node_attempt_handoff:node={handoff.get('node_id')}:"
        f"attempt={handoff.get('attempt_index')}:executor={handoff.get('executor')}:"
        f"status={handoff.get('status')}:"
        f"work_context_ref={handoff.get('work_context_ref')}:"
        "Read persistent work records for observations and unverified working notes. "
        "Action quota and plan authority are unchanged.",
        2000,
    )
