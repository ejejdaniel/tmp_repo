---
name: build-evaluation-gate
description: Defines one agent's observable success criteria, legal stop criteria, optional scorer code, and agent-local evaluator before planning starts.
estimated_complexity: high
---

# Build Evaluation Gate

This is private common bootstrap infrastructure. It never appears in the normal
skill menu. Every published `agent_evaluation_gate.machine_payload` declares one
exact `scope`: `global` or `frame`.

The Global gate is built once from the full task objective and evaluation
request. It remains authoritative across Frames and decides whole-task closure.
It may be amended only after an explicit human confirmation of the exact new
requirement; a skill result, reviewer suggestion, or ordinary human feedback
cannot silently change it.

The Frame gate is derived mechanically after one control graph is accepted. It
uses that graph's single `frame-goal` as the current-frame outcome and decides
only whether the Frame has settled or reached a legal stop. It does not redefine
the task, replace Global criteria, or require another multi-stage gate-authoring
LLM workflow. Replanning replaces the Frame gate while preserving the Global
gate and Global evaluation state.

Build an evaluation gate from this agent's own objective and task-provided
evaluation request. It also receives the current skill menu's compact summaries
so it can distinguish formal output boundaries without loading skill details or
turning available capabilities into task requirements. The skill first
classifies exact task excerpts as required
outcomes, optional directions, execution constraints, or evaluation
measurements, with closure rules isolated from production outcomes. Compound
sentences are split into their distinct roles rather than forced into one bucket.
A focused local review then examines each closure rule independently and uses the
same clause-map contract to add any mandatory stored result or lineage that was
classified only as closure. This does not approve the clause map's other
interpretations. The success stage receives that draft, the full original task
context, and the compact skill summaries. It reconciles the draft against the
task and defines observable success evidence. Later stages separately decide
whether accepted evidence can support one executable objective scorer and
extract genuine task-authored stops. These focused stages are combined
mechanically into the existing gate format.
The formulated task's goal, evaluation priority, output requirements and
constraints, together with its evaluation request, own task meaning. Without
a formulated task, the objective and evaluation request supply that authority.
Intermediate clause maps are fallible working drafts, not accepted task contracts.
Skill summaries define capability vocabulary only. Exact source-excerpt checks
prove quotation fidelity, not the correctness of an interpretation.
Success criteria must describe observable outcomes and the evidence needed to
judge them. They must not prescribe a production skill or a fixed workflow.
Ordinary task verbs such as `publish`, `store`, `record`, `return`, or `emit`
mean that the formal result must enter the accepted evidence flow. They do not
by themselves require mutation of an artifact envelope's lifecycle `status`.
Create a status-transition requirement only when the exact task language names
the canonical `status` field and its required target value.

Keep success and stop separate. A completion or quality requirement belongs only
in `success_criteria`; do not repeat it in `task_stop_criteria`.
`task_stop_criteria` is only for a task-authored instruction to terminate without
meeting every success criterion, such as an explicit abort, declared failure exit,
or whole-task attempt limit. An activity-local result/attempt-limit alternative
must remain attached to that activity's required outcome; it does not waive
unrelated deliverables. The clause and success stages preserve its exact scope
and conditions, and the stop stage excludes it from whole-task exits.
Copy a short contiguous excerpt from the task as its source. If
the task contains no such instruction, return an empty list. Python adds the
runtime action limit mechanically.

A prohibition, workflow constraint, required ordering, or forbidden behavior is
not permission to terminate. For example, "do not fabricate", "do not use X", or
"use Y only after evidence exists" constrains execution but does not create a task
stop. Do not convert such constraints into `task_stop_criteria`.

Do not invent exhaustion, low quality, uncertainty, lack of novelty, or lack of
promising ideas as stop conditions.

Set `scorer.needed=true` only when one success criterion needs one objective
numeric or algorithmic measurement whose raw inputs will exist in accepted
evidence and whose result will not already be present. Do not create a duplicate
scorer for held-out inputs or a measurement assigned to another evaluator. The
scorer computes only that measurement. It does not perform
the agent's domain work, reconstruct missing inputs, validate the whole artifact,
or decide scientific success. Reference checks, required sections, execution
status, prose quality, and rubric judgment belong to runtime bookkeeping, the
producing skill, or the evaluator. When a scorer is genuinely needed, describe
that one narrow measurement and produce Python with a top-level `def run(ctx)`.

The scorer receives a JSON-compatible mapping with `success_criteria` and
`accepted_evidence`. Each item contains an exact `ref` and its full stored
`artifact`. The `ref` is opaque and must not be interpreted as an artifact kind.
A formal artifact exposes its scientific payload through
`artifact.machine_payload`; an execution observation exposes its returned value
through `artifact.result`. Describe scorer inputs semantically without inventing
another storage wrapper such as `artifact.payload`. Its returned mapping is
objective evidence, not a closure decision.

The workflow publishes one immutable `agent_evaluation_gate`, writes one
agent-local evaluator `SKILL.md`, and returns a compact evaluation summary.
Execution constraints and closure rules are rendered into that evaluator skill;
they are not turned into extra success artifacts. The full gate remains
authoritative. The summary is only the non-forgettable prompt projection.

### LLM call contracts

| Stage purpose | Authoritative inputs | Allowed work | Output and validator | Local repair | Consumer |
|---|---|---|---|---|---|
| Classify task clauses | Full task spec when supplied, objective and evaluation request; compact summaries for capability vocabulary only | Build a draft clause map of outcomes, directions, constraints, measurements and closure rules; capabilities do not become requirements | Existing clause-map tool shape; every excerpt must be traceable to source text, without approving its interpretation | One same-stage protocol repair and one shape/content repair | Closure-overlap review and success design |
| Review one closure/outcome overlap | Full task context; one closure excerpt and existing outcomes as working drafts | Check only whether that excerpt also requires a stored outcome; carry other draft entries unchanged without approving them | Same clause-map shape and exact source-excerpt validation | Same stage and original task context | Updated draft required-outcome list |
| Define success evidence | Full task context owns meaning; draft required outcomes aid navigation; compact summaries own formal-output vocabulary | Correct, combine or discard draft interpretations and recover omissions against the task; `requirement` owns the whole obligation and `evidence_expectation` maps it to evidence without adding obligations | Existing success-design tool shape and criterion validation; no one-to-one clause mapping | Same stage, source and rules on repair | Host criterion ids, scorer decision, and rendered evaluator |
| Decide objective scorer | Exact success criteria, task-authored measurements/constraints, and guaranteed accepted-evidence interface | Decide whether one narrow objective computation is genuinely missing | Existing scorer-decision tool shape; no domain work or closure judgment allowed | One same-stage protocol/shape repair | Optional scorer-code stage |
| Extract legal task stops | Full task context; draft closure rules aid navigation | Keep only task-authored whole-task termination clauses; not local activity completion, prohibitions or quality concerns | Existing task-stop tool shape plus exact source-excerpt validation | Same stage and original task context | Global task stop ids; runtime limit is separately handled by the Frame gate |
| Implement objective scorer | Accepted narrow scorer contract only | Write Python `def run(ctx)` for that measurement, not an evaluator or producer | Existing scorer-code tool shape plus AST/runtime-subset validation | One same-stage protocol/shape repair | Immutable code artifact referenced by the agent-local evaluator |

The temporary evaluator is rendered mechanically from these accepted results.
It does not receive a separate model-authoring call, so it cannot silently add
criteria, stops, or scorer responsibilities.
