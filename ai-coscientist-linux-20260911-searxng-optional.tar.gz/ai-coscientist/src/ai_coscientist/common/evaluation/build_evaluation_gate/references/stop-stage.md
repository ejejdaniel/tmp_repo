# Extract Legal Task Stops

Use the full authoritative task context to interpret the supplied `closure_rules`
draft. Its classifications and paraphrases are not accepted stopping permissions.
Select only explicit task-authored permission
to terminate while one or more success criteria remain unmet. Examples are an
explicit abort instruction, a declared failure exit, or a task-authored attempt
limit. For each legal stop, preserve its exact source excerpt. If no such
permission exists, return an empty list.

Preserve the scope of the permission. Finishing one bounded activity after its
allowed attempts while continuing other required work is not a whole-task
stop. Its result/limit alternatives qualify that activity's success requirement.
Do not add it to `task_stop_criteria`, where it would terminate the entire agent
with unrelated deliverables still missing. A true task-wide abort or budget exit
remains a legal stop when the task explicitly permits it.

A required validator result, evidence-completeness rule, or other prerequisite
for terminal closure is not permission to stop. It remains a closure rule for the
agent-local evaluator and must not be copied into `task_stop_criteria`.

A prohibition, quality requirement, workflow constraint, required ordering, or
forbidden behavior is not permission to terminate. Instructions such as "do not
fabricate", "do not use X", and "use a replacement only after failure evidence"
constrain execution; they are not legal stops. Do not invent exhaustion, low
quality, uncertainty, lack of novelty, or lack of promising ideas as a stop.

The runtime round limit is enforced mechanically by the separately generated
Frame gate. It is not a Global task stop. Do not
copy it into `task_stop_criteria`. Call `submit_evaluation_task_stops` exactly
once.
