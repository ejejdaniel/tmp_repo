# Review One Closure Rule For A Required Outcome

Review only the single closure rule in the candidate clause map. Return one
complete clause map in the same existing shape.

The candidate `required_outcomes` are an upstream working draft, not accepted
requirements. Carry that list unchanged because this stage only checks one
closure overlap; the later success-design stage reconciles the draft against
the full task. The payload's `objective` is just the focused source excerpt,
not the whole objective. Use the accompanying authoritative task context to
retain its qualifiers. Ask one question about the supplied closure rule:

> Does this exact task clause require a new stored artifact, result, final
> response, count, dependency lineage, or other observable evidence that is not
> already required by any candidate `required_outcomes` item?

If yes, add that exact source excerpt to `required_outcomes` with a faithful
obligation. Keep it in `closure_rules` as well. If no, do not add it to
`required_outcomes`.

Do not duplicate an existing outcome merely because the closure rule uses a
different source excerpt. A rule that limits the valid status of an already
required judgment, or requires its evidence to be complete, is not a second
judgment artifact. Do not add any other outcome. Do not reinterpret an allowed
terminal status, evaluator decision, or permission to stop as a work product.
Preserve exact underscores, hyphens, punctuation, spacing, and wording from the
supplied source. Do not design workflow steps, skills, scorers, or scientific
judgments.

Call `submit_evaluation_task_clause_map` exactly once.
