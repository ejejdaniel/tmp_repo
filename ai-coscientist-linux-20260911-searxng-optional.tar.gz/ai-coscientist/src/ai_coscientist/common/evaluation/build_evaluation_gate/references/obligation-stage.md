# Classify Task Clauses Before Defining Success

When `task_spec` is present, treat its goal, constraints, evaluation priority,
and output format as the formulated task authority; the raw objective remains
provenance rather than a competing task description. Also read the task
evaluation request. When no `task_spec` is supplied, use the objective directly
for legacy callers. Classify exact task clauses without yet designing criteria,
workflows, or scorers.

The payload also contains `available_skill_summaries`. They describe formal
capability outputs and boundaries; they are not additional task requirements.
Use them only to distinguish separately required outputs that the task names.
When one task sentence or list requires multiple outputs with different formal
boundaries, emit one `required_outcomes` item per output. Do not let an artifact
that merely discusses, recommends, or anticipates another output stand in for
that output.

- `required_outcomes`: observable work products or results that the task requires
  to exist by completion. A required artifact or final response remains an
  outcome even when introduced by words such as `formal completion requires` or
  `after closure`.
- `optional_directions`: permitted, soft, optional, or example work. A clause
  using `may`, `can`, `optional`, or `soft` belongs here unless another exact
  task clause separately makes the same outcome mandatory.
- `execution_constraints`: rules governing acceptable work or evidence, including
  prohibitions, privacy boundaries, and fidelity requirements. They constrain an
  outcome but are not themselves an additional work product.
- `evaluation_measurements`: explicit deterministic quantities, targets, or
  algorithms intended for evaluation rather than domain production. A statement
  identifying the primary metric or its target belongs here unless it separately
  requires a stored result. Defining how a comparison or outcome is measured
  does not itself require that a favorable value be achieved. Keep that definition
  available without converting it into a separate always-required outcome.
- `closure_rules`: statements defining valid terminal statuses, evaluator
  completion requirements, or when the agent may end after evidence exists.
  These govern closure but do not define a work product to create. If a sentence
  says completion requires a stored artifact, that artifact requirement belongs
  in `required_outcomes`; only its terminal rule belongs here.

Split a compound sentence when its clauses have different roles, but keep the
conditions that define completion attached to the required outcome. A required
bounded activity may end on a stated result or after a stated amount of valid
work. Preserve that alternative, the comparison quantity/baseline and what
counts as valid work together in its existing `obligation`. Select a contiguous
`source_excerpt` long enough to support those conditions. Do not reduce the
outcome to "perform at most N attempts" while moving its only completion
conditions into optional directions or closure rules. A permission to finish
that required activity early is a qualification of the activity, not an
independent optional deliverable. Do not invent such a condition for a task
that states only a cap.

Keep the scope of an ending rule exact. Ending one activity and continuing
other required work does not authorize ending the whole agent task. That
activity's bounded completion belongs with its required outcome; only genuine
whole-task ending rules belong in `closure_rules`.

Each `source_excerpt` may be a shorter contiguous fragment of the sentence. For
example, an outcome joined to a privacy restriction must yield one required
outcome excerpt and one execution-constraint excerpt. Do not force the whole
sentence into only one category. These categories are not mutually exclusive:
the same exact excerpt may appear in both `required_outcomes` and
`closure_rules` when it both mandates stored completion evidence and governs
legal closure.

Never add a required outcome only because a skill can produce it, and never
prescribe a skill or workflow in the clause map.

Treat ordinary production verbs such as `publish`, `store`, `record`, `return`,
or `emit` as requiring the named formal result to exist in accepted stored
evidence. In this runtime, publishing an artifact is the act that creates that
immutable evidence; it is not an implicit request to mutate the artifact
envelope's lifecycle `status`. Do not turn those verbs into a separate status
transition, approval, admission, or review outcome. A lifecycle transition is a
required outcome only when the exact task clause explicitly names the canonical
`status` field and the target value it must hold.

For every item, copy one short contiguous `source_excerpt` exactly from the
task specification or task evaluation request (or the objective for a legacy
caller). Explain only that excerpt in the category's
second field. Use these exact second-field names: `obligation` for
`required_outcomes`, `meaning` for `optional_directions`, `constraint` for
`execution_constraints`, `measurement` for `evaluation_measurements`, and
`rule` for `closure_rules`. Preserve conjunctions, alternatives, counts,
tolerances, and modal strength. Do not promote an optional direction into a
required outcome. Never insert `...`, an ellipsis character, brackets, or any
other omission marker inside a `source_excerpt`; shorten it only by selecting a
smaller contiguous fragment. Categories other than `required_outcomes` may be
empty. Leave a category empty when no exact task clause supports an item in it.

Keep every second-field explanation concise: it must be non-empty and no more
than 600 characters. Summarize the classified meaning instead of copying the
entire source excerpt into that field. When the objective and evaluation
request restate the same formal work product, emit one required outcome for
that product and classify the additional acceptance details under the other
applicable categories; do not duplicate the outcome solely because it appears
in both authorities.

Call `submit_evaluation_task_clause_map` exactly once.
