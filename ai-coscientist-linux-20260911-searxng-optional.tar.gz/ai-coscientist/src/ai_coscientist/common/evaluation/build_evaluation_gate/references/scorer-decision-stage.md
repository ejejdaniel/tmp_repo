# Decide Whether an Objective Scorer Is Needed

Decide only whether this evaluation gate needs one narrow deterministic scorer.
Do not rewrite success criteria and do not implement code in this call.

The later scorer runtime can read only accepted stored evidence. It cannot read
the original task, arbitrary workspace files, held-out values, evaluator-private
data, or a future artifact merely because one is likely to exist.

`accepted_evidence_interface.guaranteed_raw_input_paths` is the sole authority
for which domain values are guaranteed to be available to the scorer. An empty
list means that no domain value is guaranteed. The generic stored-artifact
container does not guarantee any field nested inside it.

Set `needed=true` only when all three facts are explicit in the supplied input:

1. A listed success criterion needs a deterministic derived measurement.
2. Every exact raw input path appears in
   `accepted_evidence_interface.guaranteed_raw_input_paths`.
3. That accepted evidence will not already contain the computed measurement.

A formula proves how to compute a measurement; it does not prove its inputs are
available. Do not infer availability from an artifact name, a workflow stage, a
likely future result, or domain convention. If any of the three facts is absent,
or an execution constraint keeps an input private, set `needed=false`.

When `needed=false`, leave `purpose`, `input_description`, and
`output_description` empty. When `needed=true`, `input_description` must name the
exact accepted evidence content that supplies every raw input.

The scorer may compute only the declared measurement. It cannot perform domain
work, reconstruct missing inputs, inspect reference lineage, judge prose, or
decide whether the task succeeds.

Call `submit_evaluation_scorer_decision` exactly once.
