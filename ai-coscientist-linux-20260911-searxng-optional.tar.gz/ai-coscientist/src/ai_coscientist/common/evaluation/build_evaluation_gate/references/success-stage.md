# Define Observable Success Evidence

Define observable completion evidence from the full authoritative task context. The
evaluator requires every emitted `requirement` to be met: the checklist is a
conjunction, not a menu of alternatives. Each requirement must state its complete
allowed forms and conditions. Several source clauses can describe one required
activity; combine its definition and completion alternatives rather than creating
an unconditional criterion for one branch alongside a criterion allowing either
branch. A definition of a favorable comparison is not an independent demand to
achieve it. Read the resulting requirements together against the original task.

This call preserves activity-completion conditions but does not prescribe
workflow, invent constraints or scorers, or define whole-task stop criteria.

The supplied `required_outcomes` are a fallible clause-map draft, not accepted
requirements. `source_excerpt` locates a clause; `obligation` interprets it.
Neither the draft's categories nor its wording defines the task's logical scope.
Use the full authoritative task context to correct, combine, or discard draft
interpretations and recover any required outcome the draft omitted.
Preserve its quantity, required operation or relationship, comparison scope,
and conditional limits even when those definitions occur elsewhere in the task.
Classification into a measurement or constraint does not make a definition
irrelevant to the result it defines. Correct an inaccurate interpretation from
the original source; do not use the intersection of two paraphrases to weaken
the task. Preserve all and only the outcomes the task actually requires.
Never turn `not required`, absence-is-acceptable, or other negative boundary
language into a positive completion item.

The appended common delivery policy is the separate authority for explaining
and citing how a result was obtained. Incorporate that minimum obligation
visibly into the existing requirements where it fits; do not duplicate clauses
already covering it. It does not authorize new scientific experiments or
validation obligations beyond the task.

The payload also contains `available_skill_summaries`. Use those summaries only
to understand formal output boundaries when describing acceptable evidence.
They do not make a skill mandatory and must not introduce new requirements.
When a matching summary explicitly names a formal output identity, name that
identity in `evidence_expectation`. Require the completed formal output, not a
different artifact that merely mentions, recommends, or plans it. Do not require
the producing skill itself; another route may satisfy the criterion only by
publishing the same canonical formal-output identity. Once a matching summary
and its non-substitution boundary establish that identity, do not append an
alternative such as `other formal outputs`, `a combination of declared outputs`,
or semantically similar content stored under another artifact kind.

The formal-output vocabulary is closed over exact task language and identities
explicitly declared by the available skill summaries. Never coin a new artifact
kind, snake_case output identity, or umbrella result merely to make a criterion
sound concrete. When no single declared formal output owns the required
evidence, describe the observable evidence semantically and allow the evaluator
to judge the relevant combination of existing declared outputs.

Distinguish the required output's identity from the location of its supporting
evidence. The canonical output must exist; its exact authorized dependencies
may substantiate its content. An execution record supporting a result is not a
different-kind replacement for that result. Unless the task requires an exact
field or self-contained presentation, do not require supporting values, code,
or observations to be copied into that output's body.

Treat each summary's formal-output definition and explicit non-substitution
boundary as authoritative capability vocabulary. When a required outcome asks
for that result, copy the canonical output identity into
`evidence_expectation`; do not paraphrase it away into a broad scientific noun.
Match the scientific head result rather than requiring identical grammar. A
task may add domain modifiers or ask for a set, list, collection, or multiple
instances of a result that one capability summary produces one at a time. In
that case retain the summary's canonical output identity and express the task's
plurality or count as the required number or collection of those formal
outputs. Never let an upstream landscape, draft, or plan substitute because its
prose contains similar domain nouns.

Preserve the task-authored deliverable noun in `requirement`. The semantic
`obligation` may explain that noun but must not rename a requested hypothesis,
formula, report, review, dataset, or other result into one of its internal
properties or topics.

One declared formal output may contain independently judgeable content for
several task obligations. When a capability summary explicitly says that its
formal result contains such content, allow the same exact result refs to support
each applicable criterion unless the task requires separate stored results.
Name the existing canonical result and the content each criterion must inspect;
do not coin a second artifact identity for an internal recommendation, list,
section, or field, and do not add a generic different-kind alternative.
For example, if one summary defines a landscape or draft as an idea source and
another defines a separate formal result, evidence for the idea source cannot
satisfy the formal-result criterion even when its prose resembles that result.
Preserve any task-authored singular, plural, or minimum-count requirement for
the formal result.

Every task-required outcome must remain represented semantically. There is no
one-to-one mapping between draft items and final criteria. A category label in
the draft does not turn a definition, optional direction, or boundary into a
mandatory result, nor erase an obligation misclassified elsewhere. Do not
invent work beyond the task.

The full task is the authority for logical scope. Preserve every explicit
conjunction, alternative, quantity, minimum count, tolerance, mandatory
deliverable, and required evidence lineage. In particular:

- When a required outcome names an exact canonical stored field or field path,
  such as `depends_on` or `machine_payload.some_key`, preserve that exact name
  and relationship in both the requirement and evidence expectation. Do not
  weaken it to prose such as `linked`, `mentions`, `cites`, or `associated with`.
  Text in Markdown, a summary, or another field is not equivalent to the named
  canonical field.

- The converse is equally strict: when the source excerpt asks for provenance,
  lineage, dependencies, or traceability without naming a canonical field or
  requiring inline content, do not invent a storage location. Canonical artifact
  envelope refs and their resolvable dependency closure are valid stored
  provenance. Do not add phrases such as `as named fields`, `inside the payload`,
  or `rather than references` unless the exact task clause states that boundary.
  Requiring exact provenance means the identities and relationships must remain
  exact and readable; it does not mean copying every dependency into one result.

- If the objective requires A **and** B, the criteria must require both; never
  weaken it to A **or** B or `and/or`.
- If the objective permits A **or** B, do not make both mandatory.
- A cap on work is not by itself evidence that the work is complete. When a
  required activity may finish on a stated result, or otherwise must continue
  until a stated valid-work limit, preserve both allowed forms in one
  `requirement`. Its `evidence_expectation` must identify the comparison
  quantity, baseline and observed result for the early branch, or the valid
  work performed for the limit branch. Merely staying below the cap does not
  establish either branch. Use the original task context to retain these
  qualifications even when clause classification split their source sentences.
  Do not add a minimum effort to a task that only states a maximum, and do not
  turn ending this activity into permission to omit other required outputs.
- If the objective requires B only when A has one observed value and requires C
  only when A has another observed value, preserve that implication as one
  conditional success rule. Do not emit separate always-required criteria for
  mutually exclusive B and C.
- When a general required result is followed by mutually exclusive clauses that
  define its allowed forms, combine them into one criterion. Its evidence must
  show which antecedent was observed and that the corresponding result was
  produced. Do not add a duplicate umbrella criterion for the same result.
- Preserve explicit singular/plural and numeric requirements. Do not invent a
  count when none is stated.
- Preserve obligation strength. `Must`, `shall`, `required`, and explicit
  completion conditions may define success criteria. `May`, `can`, `optional`,
  `soft`, and examples describe permitted or desirable work; never promote them
  into mandatory completion criteria.
- Do not merge separately required deliverables when that would let one stored
  result impersonate the others.
- Separate semantic obligations do not by themselves require separate storage
  artifacts. Unless the exact task explicitly requires separate documents,
  artifacts, files, records, or outputs, never add `distinct`, `separate`,
  `dedicated`, or equivalent storage-separation language. One formal artifact,
  or one combination of declared formal outputs, may satisfy multiple criteria
  when its stored content independently makes every requested result observable.
  Keep the criteria semantically distinct while allowing them to cite the same
  exact evidence refs.
- A result that proposes, discusses, or recommends a future deliverable is not
  evidence that the separately required deliverable was actually produced.
- When skill summaries distinguish two formal outputs, keep their evidence
  expectations distinct even if both contribute to the same scientific goal.

Each criterion must state a result that can be checked from stored evidence. Do
not prescribe a production skill, a fixed workflow, or a favorable scientific
answer when the task only requires a supported result.

`requirement` defines what must be achieved. `evidence_expectation` maps that
same obligation to its declared formal identity and the observable content or
relationship an evaluator should inspect. It is not a second requirement.
Do not put additional obligations, stronger delivery rules, or "satisfies all
the other criteria" in this field. If an outcome genuinely has several required
parts, state them in `requirement`; otherwise judge the other parts under their
own criteria. In particular, a criterion requiring a formal result's existence
must not silently become a duplicate judgment of all its scientific properties.
An exception or alternative in `evidence_expectation` cannot repair an
unconditional `requirement`: put the complete allowed alternatives in the
requirement itself, without a second criterion that makes one branch mandatory.
Where useful, distinguish supporting observations from a mere completion claim.
Do not prescribe one mandatory evidence format when equivalent stored evidence
can establish the same fact, and do not invent refs before work exists.

Match the depth of checking to the task. A requested proposal can be established
by its authored content. Actual execution needs the relevant observed result
linked to the implementation or inputs used; an author's statement that it ran
is not that link. For a required execution setting, the exact implementation or
input that contains the setting together with the corresponding execution can
support compliance. Do not additionally demand independent replication,
step-by-step traces, extra measurements, or stronger scientific validation
unless the task requires them. A requested numerical output requires its value
and any task-required interpretation, not merely the name of the quantity.

When a required outcome uses `publish`, `store`, `record`, `return`, or `emit`
without explicitly naming the canonical artifact-envelope `status` field and a
target status value, evidence publication means that the formal artifact exists
in the accepted evidence flow and resolves to its stored content. Do not add an
extra requirement that `status` change from `proposed`, and do not invent a
`published` status value. Preserve an actual lifecycle-status requirement only
when the exact task language explicitly names that field and target value.

Do not extract whole-task stop conditions in this stage. Call
`submit_evaluation_success_design` exactly once with the complete result.
