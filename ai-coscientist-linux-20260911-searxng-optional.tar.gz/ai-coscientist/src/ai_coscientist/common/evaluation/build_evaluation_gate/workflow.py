from __future__ import annotations

import ast
import copy
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ..._runtime_support import function_tool
from ...memory_lifecycle.prompt import bounded_text
from ...model import ChatModel, ModelTurn
from ...openai_compatible import ModelProtocolError
from ...sub_loop_toolkit import HumanInteractionPause


_ROOT = Path(__file__).resolve().parent
_OBLIGATION_STAGE_DETAIL = (
    _ROOT / "references" / "obligation-stage.md"
).read_text(encoding="utf-8")
_CLOSURE_OUTCOME_REVIEW_STAGE_DETAIL = (
    _ROOT / "references" / "closure-outcome-review-stage.md"
).read_text(encoding="utf-8")
_SUCCESS_STAGE_DETAIL = (_ROOT / "references" / "success-stage.md").read_text(
    encoding="utf-8"
) + "\n\n" + (_ROOT.parent / "references" / "evidence-completeness.md").read_text(encoding="utf-8")
_SCORER_DECISION_STAGE_DETAIL = (
    _ROOT / "references" / "scorer-decision-stage.md"
).read_text(encoding="utf-8")
_STOP_STAGE_DETAIL = (_ROOT / "references" / "stop-stage.md").read_text(
    encoding="utf-8"
)


def build_evaluation_gate(
    *,
    model: ChatModel,
    events: Any,
    artifacts: Any,
    code_artifacts: Any | None,
    agent_runtime_root: Path,
    agent_id: str,
    objective: str,
    evaluation_request: str,
    max_rounds: int,
    scope: str = "global",
    mission_packet: Mapping[str, Any] | None = None,
    skill_summaries: Sequence[Mapping[str, str]] = (),
    task_spec: Mapping[str, Any] | None = None,
    task_spec_ref: str = "",
    previous_gate_ref: str = "",
    human_input_tool: Mapping[str, Any] | None = None,
    request_human_input: Callable[[Mapping[str, Any]], None] | None = None,
) -> dict[str, Any]:
    """Construct and publish one immutable agent-local evaluation authority."""
    objective = str(objective).strip()
    evaluation_request = str(evaluation_request).strip()
    if not objective:
        raise ValueError("evaluation_gate_objective_required")
    scope = str(scope).strip()
    if scope not in {"global", "frame"}:
        raise ValueError("evaluation_gate_scope_invalid")

    normalized_task_spec = (
        copy.deepcopy(dict(task_spec)) if task_spec is not None else None
    )
    normalized_task_spec_ref = str(task_spec_ref).strip()
    normalized_previous_gate_ref = str(previous_gate_ref).strip()
    if normalized_task_spec is not None:
        if normalized_task_spec.get("artifact_kind") != "task_spec":
            raise ValueError("evaluation_gate_task_spec_kind_invalid")
        if not normalized_task_spec_ref.startswith("artifact:"):
            raise ValueError("evaluation_gate_task_spec_ref_required")
    elif normalized_task_spec_ref:
        raise ValueError("evaluation_gate_task_spec_content_required")
    source_text = _task_authority_source_text(
        objective=objective,
        evaluation_request=evaluation_request,
        task_spec=normalized_task_spec,
    )
    available_skill_summaries = [dict(item) for item in skill_summaries]
    task_clause_map = _required_stage_call(
        model=model,
        events=events,
        purpose="build evaluation gate: classify task clauses",
        instruction=_OBLIGATION_STAGE_DETAIL,
        payload={
            "objective": objective,
            "task_evaluation_request": evaluation_request,
            "task_spec": normalized_task_spec,
            "available_skill_summaries": available_skill_summaries,
        },
        tool=_task_clause_map_tool(
            source_excerpts=_task_clause_source_excerpts(
                objective=objective,
                evaluation_request=evaluation_request,
                task_spec=normalized_task_spec,
            )
        ),
        validator=lambda arguments: _validated_task_clause_map(
            arguments,
            source_text=source_text,
        ),
        alternate_tool=human_input_tool,
        alternate_tool_callback=request_human_input,
    )
    task_clause_map = _review_closure_outcome_overlaps(
        model=model,
        events=events,
        task_clause_map=task_clause_map,
        source_text=source_text,
    )
    success_design = _required_stage_call(
        model=model,
        events=events,
        purpose="build evaluation gate: define success evidence",
        instruction=_SUCCESS_STAGE_DETAIL,
        payload={
            "required_outcomes": task_clause_map["required_outcomes"],
            "available_skill_summaries": available_skill_summaries,
        },
        source_context=source_text,
        tool=_success_design_tool(),
        validator=_validated_success_design,
    )
    success_criteria = [
        {
            "criterion_id": f"success-{index}",
            "requirement": item["requirement"],
            "evidence_expectation": item["evidence_expectation"],
        }
        for index, item in enumerate(
            success_design["success_criteria"], start=1
        )
    ]
    scorer = _required_stage_call(
        model=model,
        events=events,
        purpose="build evaluation gate: decide objective scorer",
        instruction=_SCORER_DECISION_STAGE_DETAIL,
        payload={
            "success_criteria": success_criteria,
            "evaluation_measurements": task_clause_map[
                "evaluation_measurements"
            ],
            "execution_constraints": task_clause_map[
                "execution_constraints"
            ],
            "accepted_evidence_interface": _accepted_evidence_interface(
                mission_packet
            ),
        },
        tool=_scorer_decision_tool(),
        validator=_validated_scorer_decision,
    )
    task_stop_criteria = _required_stage_call(
        model=model,
        events=events,
        purpose="build evaluation gate: extract legal task stops",
        instruction=_STOP_STAGE_DETAIL,
        payload={
            "closure_rules": task_clause_map["closure_rules"],
        },
        source_context=source_text,
        tool=_task_stop_tool(),
        validator=lambda arguments: _validated_task_stops(
            arguments,
            source_text=source_text,
        ),
    )
    stop_criteria = [
        {
            "stop_id": f"stop-task-{index}",
            "condition": item["condition"],
            "source": "task",
            "source_excerpt": item["source_excerpt"],
        }
        for index, item in enumerate(task_stop_criteria, start=1)
    ]
    scorer_refs: list[str] = []
    if scorer["needed"]:
        if code_artifacts is None:
            raise RuntimeError(
                "evaluation_gate_scorer_requested_but_code_store_unavailable"
            )
        python_code = _required_stage_call(
            model=model,
            events=events,
            purpose="build evaluation gate: implement objective scorer",
            instruction=_SCORER_INSTRUCTION,
            payload={"scorer_contract": scorer},
            tool=_scorer_code_tool(),
            validator=_validated_scorer_code,
        )
        scorer_receipt = code_artifacts.publish(
            code=python_code,
            purpose=str(scorer["purpose"]),
            depends_on=(),
        )
        scorer_refs.append(str(scorer_receipt["code_artifact_ref"]))
        events.append(
            "evaluation_gate_scorer_published",
            {
                "code_artifact_ref": scorer_refs[-1],
                "purpose": scorer["purpose"],
            },
        )

    evaluator_root = (
        Path(agent_runtime_root).resolve()
        / "agent-local-skills"
        / _safe_segment(agent_id)
        / "evaluator"
    )
    evaluator_root.mkdir(parents=True, exist_ok=True)
    evaluator_path = evaluator_root / "SKILL.md"
    evaluator_skill = _render_evaluator_skill(
        success_criteria=success_criteria,
        stop_criteria=stop_criteria,
        scorer_refs=scorer_refs,
        execution_constraints=task_clause_map["execution_constraints"],
        closure_rules=task_clause_map["closure_rules"],
    )
    _atomic_write_text(evaluator_path, evaluator_skill)
    relative_evaluator_path = evaluator_path.relative_to(
        Path(agent_runtime_root).resolve()
    ).as_posix()
    evaluator_skill_ref = f"workspace:{relative_evaluator_path}"

    machine_payload = {
        "artifact_kind": "agent_evaluation_gate",
        "scope": scope,
        "success_criteria": success_criteria,
        "stop_criteria": stop_criteria,
        "evaluator_skill_ref": evaluator_skill_ref,
        "scorer_refs": scorer_refs,
    }
    summary = _render_evaluation_summary(machine_payload)
    dependencies = tuple(
        dict.fromkeys(
            ref
            for ref in (
                normalized_task_spec_ref,
                normalized_previous_gate_ref,
                *scorer_refs,
            )
            if ref
        )
    )
    receipt = artifacts.publish(
        artifact_kind="agent_evaluation_gate",
        artifact_id=f"agent-{scope}-evaluation-gate",
        title=f"Agent {scope} evaluation gate",
        markdown=_render_gate_markdown(machine_payload),
        machine_payload=machine_payload,
        status="accepted",
        summary=summary,
        depends_on=dependencies,
        verified_external_dependencies=tuple(scorer_refs),
    )
    gate_ref = str(receipt["artifact_ref"])
    gate = artifacts.read(gate_ref)
    events.append(
        "evaluation_gate_built",
        {
            "gate_ref": gate_ref,
            "scope": scope,
            "evaluation_summary": summary,
            "evaluator_skill_ref": evaluator_skill_ref,
            "scorer_refs": scorer_refs,
            "task_spec_ref": normalized_task_spec_ref,
            "previous_gate_ref": normalized_previous_gate_ref,
        },
    )
    return {
        "gate_ref": gate_ref,
        "evaluation_summary": summary,
        "gate": gate,
    }


def build_frame_evaluation_gate(
    *,
    events: Any,
    artifacts: Any,
    agent_runtime_root: Path,
    agent_id: str,
    plan_graph: Mapping[str, Any],
    max_rounds: int,
    global_gate_ref: str,
) -> dict[str, Any]:
    """Project one Frame goal into the existing evaluator contract."""
    goal_id = str(plan_graph.get("goal_node_id") or "").strip()
    nodes = plan_graph.get("nodes")
    if not goal_id or not isinstance(nodes, Sequence) or isinstance(
        nodes, (str, bytes)
    ):
        raise ValueError("frame_evaluation_plan_graph_invalid")
    goal = next(
        (
            item
            for item in nodes
            if isinstance(item, Mapping)
            and str(item.get("node_id") or "").strip() == goal_id
        ),
        None,
    )
    if goal is None:
        raise ValueError("frame_evaluation_goal_missing")
    outcome = _bounded_required_text(
        goal.get("outcome"),
        "frame_evaluation_goal_outcome_invalid",
        1_000,
    )
    completion_condition = _bounded_required_text(
        goal.get("completion_condition"),
        "frame_evaluation_goal_completion_invalid",
        1_000,
    )
    revision = plan_graph.get("revision")
    if not isinstance(revision, int) or revision < 1:
        raise ValueError("frame_evaluation_graph_revision_invalid")

    success_criteria = [
        {
            "criterion_id": "frame-success-1",
            "requirement": outcome,
            "evidence_expectation": completion_condition,
        }
    ]
    stop_criteria: list[dict[str, str]] = []
    evaluator_root = (
        Path(agent_runtime_root).resolve()
        / "agent-local-skills"
        / _safe_segment(agent_id)
        / f"frame-evaluator-r{revision}"
    )
    evaluator_root.mkdir(parents=True, exist_ok=True)
    evaluator_path = evaluator_root / "SKILL.md"
    evaluator_skill = _render_evaluator_skill(
        success_criteria=success_criteria,
        stop_criteria=stop_criteria,
        scorer_refs=(),
        execution_constraints=(),
        closure_rules=(),
    )
    _atomic_write_text(evaluator_path, evaluator_skill)
    relative_evaluator_path = evaluator_path.relative_to(
        Path(agent_runtime_root).resolve()
    ).as_posix()
    machine_payload = {
        "artifact_kind": "agent_evaluation_gate",
        "scope": "frame",
        "success_criteria": success_criteria,
        "stop_criteria": stop_criteria,
        "evaluator_skill_ref": f"workspace:{relative_evaluator_path}",
        "scorer_refs": [],
    }
    summary = _render_evaluation_summary(machine_payload)
    dependencies = tuple(
        ref for ref in (str(global_gate_ref).strip(),) if ref
    )
    receipt = artifacts.publish(
        artifact_kind="agent_evaluation_gate",
        artifact_id=f"agent-frame-evaluation-gate-r{revision}",
        title=f"Agent frame evaluation gate r{revision}",
        markdown=_render_gate_markdown(machine_payload),
        machine_payload=machine_payload,
        status="accepted",
        summary=summary,
        depends_on=dependencies,
    )
    gate_ref = str(receipt["artifact_ref"])
    gate = artifacts.read(gate_ref)
    events.append(
        "evaluation_gate_built",
        {
            "gate_ref": gate_ref,
            "scope": "frame",
            "graph_revision": revision,
            "evaluation_summary": summary,
            "evaluator_skill_ref": machine_payload["evaluator_skill_ref"],
            "scorer_refs": [],
        },
    )
    return {
        "gate_ref": gate_ref,
        "evaluation_summary": summary,
        "gate": gate,
    }


def amend_global_evaluation_gate(
    *,
    events: Any,
    artifacts: Any,
    agent_runtime_root: Path,
    agent_id: str,
    current_gate: Mapping[str, Any],
    confirmed_requirement: str,
    confirmation_response_ref: str,
) -> dict[str, Any]:
    """Append one human-confirmed requirement without rewriting old criteria."""
    current_ref = str(current_gate.get("artifact_ref") or "").strip()
    payload = current_gate.get("machine_payload")
    if not current_ref or not isinstance(payload, Mapping):
        raise ValueError("global_evaluation_amendment_gate_invalid")
    scope = str(payload.get("scope") or "global").strip()
    if scope != "global":
        raise ValueError("global_evaluation_amendment_scope_invalid")
    requirement = _bounded_required_text(
        confirmed_requirement,
        "global_evaluation_amendment_requirement_invalid",
        2_000,
    )
    response_ref = str(confirmation_response_ref).strip()
    if not response_ref.startswith("artifact:"):
        raise ValueError("global_evaluation_amendment_confirmation_ref_invalid")

    success_criteria = [dict(item) for item in payload["success_criteria"]]
    if any(str(item.get("requirement") or "").strip() == requirement for item in success_criteria):
        return {
            "gate_ref": current_ref,
            "evaluation_summary": _render_evaluation_summary(payload),
            "gate": dict(current_gate),
            "criterion_added": False,
        }
    digest = hashlib.sha256(requirement.encode("utf-8")).hexdigest()[:10]
    criterion_id = f"success-human-{digest}"
    existing_ids = {str(item.get("criterion_id") or "") for item in success_criteria}
    if criterion_id in existing_ids:
        raise ValueError("global_evaluation_amendment_criterion_id_conflict")
    success_criteria.append(
        {
            "criterion_id": criterion_id,
            "requirement": requirement,
            "evidence_expectation": (
                "Accepted formal evidence that directly answers this "
                "human-confirmed Global Evaluation requirement."
            ),
        }
    )
    stop_criteria = [dict(item) for item in payload["stop_criteria"]]
    scorer_refs = [str(ref) for ref in payload.get("scorer_refs") or ()]
    evaluator_root = (
        Path(agent_runtime_root).resolve()
        / "agent-local-skills"
        / _safe_segment(agent_id)
        / f"global-evaluator-{digest}"
    )
    evaluator_root.mkdir(parents=True, exist_ok=True)
    evaluator_path = evaluator_root / "SKILL.md"
    evaluator_skill = _render_evaluator_skill(
        success_criteria=success_criteria,
        stop_criteria=stop_criteria,
        scorer_refs=scorer_refs,
        execution_constraints=(),
        closure_rules=(),
    )
    _atomic_write_text(evaluator_path, evaluator_skill)
    evaluator_ref = "workspace:" + evaluator_path.relative_to(
        Path(agent_runtime_root).resolve()
    ).as_posix()
    machine_payload = {
        "artifact_kind": "agent_evaluation_gate",
        "scope": "global",
        "success_criteria": success_criteria,
        "stop_criteria": stop_criteria,
        "evaluator_skill_ref": evaluator_ref,
        "scorer_refs": scorer_refs,
    }
    summary = _render_evaluation_summary(machine_payload)
    dependencies = tuple(
        dict.fromkeys([current_ref, response_ref, *scorer_refs])
    )
    receipt = artifacts.publish(
        artifact_kind="agent_evaluation_gate",
        artifact_id=f"agent-global-evaluation-gate-{digest}",
        title="Amended agent global evaluation gate",
        markdown=_render_gate_markdown(machine_payload),
        machine_payload=machine_payload,
        status="accepted",
        summary=summary,
        depends_on=dependencies,
        verified_external_dependencies=tuple(scorer_refs),
    )
    gate_ref = str(receipt["artifact_ref"])
    gate = artifacts.read(gate_ref)
    events.append(
        "global_evaluation_gate_amended",
        {
            "previous_gate_ref": current_ref,
            "gate_ref": gate_ref,
            "criterion_id": criterion_id,
            "confirmation_response_ref": response_ref,
        },
    )
    return {
        "gate_ref": gate_ref,
        "evaluation_summary": summary,
        "gate": gate,
        "criterion_added": True,
    }


def _review_closure_outcome_overlaps(
    *,
    model: ChatModel,
    events: Any,
    task_clause_map: Mapping[str, Sequence[Mapping[str, str]]],
    source_text: str,
) -> dict[str, list[dict[str, str]]]:
    required_outcomes = [
        dict(item) for item in task_clause_map["required_outcomes"]
    ]
    for index, closure_rule in enumerate(
        task_clause_map["closure_rules"],
        start=1,
    ):
        rule = dict(closure_rule)
        target_excerpt = rule["source_excerpt"]
        if any(
            item["source_excerpt"] == target_excerpt
            for item in required_outcomes
        ):
            continue
        focused_map = {
            "required_outcomes": [dict(item) for item in required_outcomes],
            "optional_directions": [],
            "execution_constraints": [],
            "evaluation_measurements": [],
            "closure_rules": [rule],
        }
        reviewed = _required_stage_call(
            model=model,
            events=events,
            purpose=(
                "build evaluation gate: review closure rule for outcome "
                f"{index}"
            ),
            instruction=_CLOSURE_OUTCOME_REVIEW_STAGE_DETAIL,
            payload={
                "candidate_clause_map": focused_map,
                "objective": rule["source_excerpt"],
                "task_evaluation_request": "",
            },
            source_context=source_text,
            tool=_task_clause_map_tool(
                source_excerpts=tuple(
                    dict.fromkeys(
                        item["source_excerpt"]
                        for item in (*required_outcomes, rule)
                    )
                )
            ),
            validator=lambda arguments: _validated_task_clause_map(
                arguments,
                source_text=source_text,
            ),
        )
        selected = next(
            (
                item
                for item in reviewed["required_outcomes"]
                if item["source_excerpt"] == target_excerpt
            ),
            None,
        )
        if selected is not None and not any(
            item["source_excerpt"] == target_excerpt
            for item in required_outcomes
        ):
            required_outcomes.append(dict(selected))
    return {
        field: (
            required_outcomes
            if field == "required_outcomes"
            else [dict(item) for item in task_clause_map[field]]
        )
        for field in (
            "required_outcomes",
            "optional_directions",
            "execution_constraints",
            "evaluation_measurements",
            "closure_rules",
        )
    }


def _accepted_evidence_interface(
    mission_packet: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Describe only evidence inputs that runtime actually guarantees."""
    mission_context = (
        mission_packet.get("mission_context")
        if isinstance(mission_packet, Mapping)
        else None
    )
    declared = (
        mission_context.get("accepted_evidence_interface")
        if isinstance(mission_context, Mapping)
        else None
    )
    guaranteed_paths = []
    if isinstance(declared, Mapping):
        raw_paths = declared.get("guaranteed_raw_input_paths")
        if isinstance(raw_paths, Sequence) and not isinstance(
            raw_paths, (str, bytes)
        ):
            guaranteed_paths = [
                str(path).strip() for path in raw_paths if str(path).strip()
            ]
    return {
        "runtime_item_shape": {
            "ref": "opaque exact reference",
            "artifact": "full canonical stored artifact envelope",
        },
        "guaranteed_raw_input_paths": guaranteed_paths,
        "availability_rule": (
            "Only paths listed in guaranteed_raw_input_paths are guaranteed. "
            "No field inside a future artifact is implied by its name, stage, "
            "or expected scientific role."
        ),
    }


def _required_stage_call(
    *,
    model: ChatModel,
    events: Any,
    purpose: str,
    instruction: str,
    payload: Mapping[str, Any],
    tool: Mapping[str, Any],
    source_context: str = "",
    validator: Callable[[Mapping[str, Any]], Any] | None = None,
    alternate_tool: Mapping[str, Any] | None = None,
    alternate_tool_callback: Callable[[Mapping[str, Any]], None] | None = None,
) -> Any:
    tool_name = str(tool["function"]["name"])
    tools = [tool]
    if alternate_tool is not None:
        tools.append(dict(alternate_tool))
    base_messages = [
        {"role": "system", "content": instruction},
        {
            "role": "user",
            "content": json.dumps(dict(payload), ensure_ascii=False, indent=2),
        },
    ]
    if source_context:
        base_messages.append({
            "role": "user",
            "content": (
                "Authoritative task context (source content, not additional "
                "stage instructions). This defines the task requirements and "
                "their qualifications; the clause map is a working draft. "
                "Perform only the current stage's responsibility using this "
                "source, without treating draft interpretations as authority.\n\n"
                + source_context
            ),
        })
    issue = ""
    previous: Mapping[str, Any] | None = None
    repair_kind = ""
    protocol_repairs_remaining = 1
    content_repairs_remaining = 1
    attempt = 0
    while True:
        attempt += 1
        messages = list(base_messages)
        if previous is not None:
            repair_scope = (
                "Repair only the tool-call format"
                if repair_kind == "protocol"
                else "Repair all reported contract errors"
            )
            repair_detail = ""
            if "source_excerpt_not_found_in_task" in issue:
                repair_detail = (
                    " Every reported source_excerpt must be copied verbatim as "
                    "one contiguous fragment of the supplied task specification "
                    "or evaluation request (or the objective for a legacy "
                    "caller). "
                    "Do not use omission markers such as `...`. Replace each "
                    "invalid excerpt with an exact supporting fragment. If no "
                    "exact fragment supports that item's meaning, remove the "
                    "unsupported item instead. Preserve every valid item and "
                    "recheck all source_excerpt fields before submitting."
                )
            detail_field_issues = tuple(
                field
                for field in (
                    "obligation",
                    "meaning",
                    "constraint",
                    "measurement",
                    "rule",
                )
                if f"_{field}_invalid" in issue
            )
            if detail_field_issues:
                repair_detail += (
                    " Rewrite every reported "
                    + ", ".join(detail_field_issues)
                    + " field as a non-empty concise explanation of at most "
                    "600 characters. Do not copy the entire source_excerpt "
                    "into the explanation. Preserve the source clause's "
                    "counts, alternatives, tolerances, and modal strength."
                )
            messages.extend(
                [
                    {
                        "role": "assistant",
                        "content": "Previous invalid structured attempt:\n"
                        + json.dumps(previous, ensure_ascii=False),
                    },
                    {
                        "role": "user",
                        "content": (
                            f"{repair_scope} and call {tool_name} once. "
                            f"Validation issue: {issue}.{repair_detail}"
                        ),
                    },
                ]
            )
        events.append(
            "evaluation_gate_prompt_snapshot",
            {
                "purpose": purpose,
                "attempt": attempt,
                "messages": messages,
                "tools": tools,
                "prompt_sources": _prompt_source_summary(
                    instruction=instruction,
                    payload=payload,
                    tool=tool,
                    previous=previous,
                    source_context=source_context,
                ),
            },
        )
        try:
            turn = model.complete(
                messages=messages,
                tools=tools,
                purpose=purpose,
                tool_choice="required",
            )
        except ModelProtocolError as exc:
            issue = f"model_protocol_error:{exc}"
            previous = {"content": "", "tool_calls": []}
            repair_kind = "protocol"
            if protocol_repairs_remaining <= 0:
                break
            protocol_repairs_remaining -= 1
            continue
        events.append(
            "evaluation_gate_model_turn",
            {
                "purpose": purpose,
                "attempt": attempt,
                "content": turn.content,
                "tool_calls": [
                    {"name": call.name, "arguments": dict(call.arguments)}
                    for call in turn.tool_calls
                ],
                "usage": dict(turn.usage),
            },
        )
        if (
            len(turn.tool_calls) == 1
            and turn.tool_calls[0].name == "request_human_input"
        ):
            if alternate_tool_callback is None:
                raise RuntimeError(
                    "evaluation_gate_human_input_callback_missing"
                )
            alternate_tool_callback(turn.tool_calls[0].arguments)
            raise HumanInteractionPause()
        try:
            arguments = _single_tool_arguments(turn, tool_name)
            _validate_top_level_tool_shape(arguments, tool)
        except RuntimeError as exc:
            issue = str(exc)
            previous = {
                "content": bounded_text(turn.content, 1_000),
                "tool_calls": [
                    {"name": call.name, "arguments": dict(call.arguments)}
                    for call in turn.tool_calls
                ],
            }
            repair_kind = "protocol"
            if protocol_repairs_remaining <= 0:
                break
            protocol_repairs_remaining -= 1
            continue
        try:
            return validator(arguments) if validator is not None else arguments
        except RuntimeError as exc:
            issue = str(exc)
            previous = {
                "content": bounded_text(turn.content, 1_000),
                "tool_calls": [
                    {"name": call.name, "arguments": dict(call.arguments)}
                    for call in turn.tool_calls
                ],
            }
            repair_kind = "content"
            if content_repairs_remaining <= 0:
                break
            content_repairs_remaining -= 1
    raise RuntimeError(f"evaluation_gate_stage_failed:{purpose}:{issue}")


def _prompt_source_summary(
    *,
    instruction: str,
    payload: Mapping[str, Any],
    tool: Mapping[str, Any],
    previous: Mapping[str, Any] | None,
    source_context: str = "",
) -> list[dict[str, Any]]:
    task_keys = {
        "objective",
        "task_evaluation_request",
        "task_spec",
        "mission_packet",
        "required_outcomes",
        "success_criteria",
        "evaluation_measurements",
        "execution_constraints",
        "closure_rules",
        "scorer_contract",
        "accepted_evidence_interface",
    }
    task_authority = {
        key: value for key, value in payload.items() if key in task_keys
    }
    working_context = {
        key: value for key, value in payload.items() if key not in task_keys
    }

    def source(storage_class: str, name: str, value: Any) -> dict[str, Any]:
        rendered = json.dumps(value, ensure_ascii=False, default=str)
        return {
            "storage_class": storage_class,
            "name": name,
            "serialized_chars": len(rendered),
        }

    return [
        source("instruction", "evaluation_gate_stage_instruction", instruction),
        source("C0", "evaluation_gate_task_authority", (task_authority, source_context)),
        source(
            "instruction",
            "evaluation_gate_skill_summaries",
            payload.get("available_skill_summaries") or [],
        ),
        source("C5", "evaluation_gate_stage_working_context", working_context),
        source("C5", "evaluation_gate_rejected_attempt", previous or {}),
        source("tool_schema", "evaluation_gate_stage_result", tool),
    ]


def _task_authority_source_text(
    *,
    objective: str,
    evaluation_request: str,
    task_spec: Mapping[str, Any] | None,
) -> str:
    if task_spec is None:
        return "\n".join(
            part for part in (objective, evaluation_request) if part
        )
    parts: list[str] = []
    for key in ("goal", "evaluation_priority", "output_format"):
        value = str(task_spec.get(key) or "").strip()
        if value:
            parts.append(value)
    constraints = task_spec.get("constraints")
    if isinstance(constraints, Sequence) and not isinstance(
        constraints, (str, bytes)
    ):
        parts.extend(
            str(item).strip() for item in constraints if str(item).strip()
        )
    if evaluation_request:
        parts.append(evaluation_request)
    return "\n".join(parts)


def _single_tool_arguments(turn: ModelTurn, tool_name: str) -> Mapping[str, Any]:
    if len(turn.tool_calls) != 1:
        raise RuntimeError(
            f"evaluation_gate_requires_one_tool_call:{len(turn.tool_calls)}"
        )
    call = turn.tool_calls[0]
    if call.name != tool_name:
        raise RuntimeError(
            f"evaluation_gate_tool_mismatch:{tool_name}:{call.name}"
        )
    return dict(call.arguments)


def _validate_top_level_tool_shape(
    arguments: Mapping[str, Any],
    tool: Mapping[str, Any],
) -> None:
    parameters = tool.get("function", {}).get("parameters", {})
    required = set(parameters.get("required", ()))
    properties = set(parameters.get("properties", {}))
    actual = set(arguments)
    missing = sorted(required - actual)
    unexpected = sorted(actual - properties) if properties else []
    if missing or unexpected:
        raise RuntimeError(
            "evaluation_gate_tool_arguments_shape_invalid:"
            f"missing={missing}:unexpected={unexpected}"
        )


def _validated_success_design(arguments: Mapping[str, Any]) -> dict[str, Any]:
    if set(arguments) != {"success_criteria"}:
        raise RuntimeError("evaluation_gate_success_design_fields_invalid")
    success = _object_list(
        arguments["success_criteria"],
        field="success_criteria",
        required_keys={"requirement", "evidence_expectation"},
        minimum=1,
        maximum=12,
    )
    normalized_success: list[dict[str, str]] = []
    for index, item in enumerate(success, start=1):
        normalized_success.append(
            {
                "requirement": _bounded_required_text(
                    item["requirement"],
                    f"success_{index}_requirement_invalid",
                    600,
                ),
                "evidence_expectation": _bounded_required_text(
                    item["evidence_expectation"],
                    f"success_{index}_evidence_invalid",
                    600,
                ),
            }
        )

    return {"success_criteria": normalized_success}


def _validated_scorer_decision(arguments: Mapping[str, Any]) -> dict[str, Any]:
    scorer_keys = {
        "needed",
        "purpose",
        "input_description",
        "output_description",
    }
    if set(arguments) != scorer_keys:
        raise RuntimeError("evaluation_gate_scorer_fields_invalid")
    needed = arguments["needed"]
    if not isinstance(needed, bool):
        raise RuntimeError("evaluation_gate_scorer_needed_must_be_boolean")
    normalized_scorer = {
        "needed": needed,
        "purpose": str(arguments["purpose"]).strip(),
        "input_description": str(arguments["input_description"]).strip(),
        "output_description": str(arguments["output_description"]).strip(),
    }
    if not needed:
        return {
            "needed": False,
            "purpose": "",
            "input_description": "",
            "output_description": "",
        }
    if needed and any(not normalized_scorer[key] for key in scorer_keys - {"needed"}):
        raise RuntimeError("evaluation_gate_scorer_contract_incomplete")
    return normalized_scorer


def _validated_task_clause_map(
    arguments: Mapping[str, Any],
    *,
    source_text: str,
) -> dict[str, list[dict[str, str]]]:
    fields = {
        "required_outcomes": "obligation",
        "optional_directions": "meaning",
        "execution_constraints": "constraint",
        "evaluation_measurements": "measurement",
        "closure_rules": "rule",
    }
    if set(arguments) != set(fields):
        raise RuntimeError("evaluation_gate_task_clause_map_fields_invalid")
    shape_issues: list[str] = []
    normalized: dict[str, list[dict[str, str]]] = {}
    content_issues: list[str] = []
    for field, detail_key in fields.items():
        normalized_items: list[dict[str, str]] = []
        value = arguments[field]
        if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
            shape_issues.append(f"evaluation_gate_{field}_must_be_array")
            normalized[field] = normalized_items
            continue
        minimum = 1 if field == "required_outcomes" else 0
        if not minimum <= len(value) <= 16:
            shape_issues.append(
                f"evaluation_gate_{field}_length_must_be_{minimum}_to_16"
            )
            normalized[field] = normalized_items
            continue
        required_keys = {"source_excerpt", detail_key}
        for index, item in enumerate(value, start=1):
            if not isinstance(item, Mapping):
                shape_issues.append(
                    f"evaluation_gate_{field}_{index}_fields_invalid:"
                    f"expected={sorted(required_keys)}:"
                    f"actual_type={type(item).__name__}"
                )
                continue
            actual_keys = set(item)
            if actual_keys != required_keys:
                shape_issues.append(
                    f"evaluation_gate_{field}_{index}_fields_invalid:"
                    f"expected={sorted(required_keys)}:"
                    f"actual={sorted(actual_keys)}"
                )

            excerpt_valid = False
            canonical_excerpt: str | None = None
            if "source_excerpt" in item:
                try:
                    excerpt = _bounded_required_text(
                        item["source_excerpt"],
                        f"{field}_{index}_source_excerpt_invalid",
                        1_000,
                    )
                except RuntimeError as exc:
                    content_issues.append(str(exc))
                else:
                    canonical_excerpt = _canonical_source_excerpt(
                        excerpt,
                        source_text,
                    )
                    if canonical_excerpt is None:
                        content_issues.append(
                            f"{field}_{index}_source_excerpt_not_found_in_task"
                        )
                    else:
                        excerpt_valid = True

            detail_valid = False
            detail = ""
            if detail_key in item:
                try:
                    detail = _bounded_required_text(
                        item[detail_key],
                        f"{field}_{index}_{detail_key}_invalid",
                        600,
                    )
                except RuntimeError as exc:
                    content_issues.append(str(exc))
                else:
                    detail_valid = True

            if not excerpt_valid or not detail_valid:
                continue
            normalized_items.append(
                {"source_excerpt": canonical_excerpt, detail_key: detail}
            )
        normalized[field] = normalized_items
    issues: list[str] = []
    if shape_issues:
        issues.append(
            "evaluation_gate_task_clause_map_shape_invalid:"
            + "|".join(shape_issues)
        )
    issues.extend(content_issues)
    if issues:
        raise RuntimeError("|".join(issues))
    return normalized


def _validated_task_stops(
    arguments: Mapping[str, Any],
    *,
    source_text: str,
) -> list[dict[str, str]]:
    if set(arguments) != {"task_stop_criteria"}:
        raise RuntimeError("evaluation_gate_task_stop_fields_invalid")
    stops = _object_list(
        arguments["task_stop_criteria"],
        field="task_stop_criteria",
        required_keys={"condition", "source_excerpt"},
        minimum=0,
        maximum=6,
    )
    normalized_stops: list[dict[str, str]] = []
    for index, item in enumerate(stops, start=1):
        condition = _bounded_required_text(
            item["condition"], f"stop_{index}_condition_invalid", 500
        )
        excerpt = _bounded_required_text(
            item["source_excerpt"], f"stop_{index}_excerpt_invalid", 500
        )
        canonical_excerpt = _canonical_source_excerpt(excerpt, source_text)
        if canonical_excerpt is None:
            raise RuntimeError(
                f"stop_{index}_source_excerpt_not_found_in_task"
            )
        normalized_stops.append(
            {"condition": condition, "source_excerpt": canonical_excerpt}
        )
    return normalized_stops


def _validated_scorer_code(arguments: Mapping[str, Any]) -> str:
    if set(arguments) != {"python_code"}:
        raise RuntimeError("evaluation_gate_scorer_code_fields_invalid")
    code = str(arguments["python_code"])
    if not code.strip():
        raise RuntimeError("evaluation_gate_scorer_python_code_required")
    try:
        tree = ast.parse(code, filename="<evaluation-gate-scorer>")
    except SyntaxError as exc:
        raise RuntimeError(
            f"evaluation_gate_scorer_syntax_error:{exc.msg}:line={exc.lineno}"
        ) from exc
    run_functions = [
        node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == "run"
    ]
    if len(run_functions) != 1 or len(run_functions[0].args.args) != 1:
        raise RuntimeError("evaluation_gate_scorer_requires_def_run_ctx")
    return code


def _success_design_tool() -> dict[str, Any]:
    return function_tool(
        "submit_evaluation_success_design",
        "Submit observable success criteria.",
        {
            "type": "object",
            "properties": {
                "success_criteria": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 12,
                    "items": {
                        "type": "object",
                        "properties": {
                            "requirement": {"type": "string"},
                            "evidence_expectation": {"type": "string"},
                        },
                        "required": ["requirement", "evidence_expectation"],
                        "additionalProperties": False,
                    },
                },
            },
            "required": ["success_criteria"],
            "additionalProperties": False,
        },
    )


def _scorer_decision_tool() -> dict[str, Any]:
    return function_tool(
        "submit_evaluation_scorer_decision",
        "Decide whether one narrow objective scorer is executable from accepted evidence.",
        {
            "type": "object",
            "properties": {
                "needed": {"type": "boolean"},
                "purpose": {"type": "string"},
                "input_description": {"type": "string"},
                "output_description": {"type": "string"},
            },
            "required": [
                "needed",
                "purpose",
                "input_description",
                "output_description",
            ],
            "additionalProperties": False,
        },
    )


def _task_clause_map_tool(
    *,
    source_excerpts: Sequence[str] = (),
) -> dict[str, Any]:
    allowed_excerpts = list(dict.fromkeys(source_excerpts))

    def clause_list(detail_key: str) -> dict[str, Any]:
        excerpt_schema: dict[str, Any] = {"type": "string"}
        if allowed_excerpts:
            excerpt_schema["enum"] = allowed_excerpts
        return {
            "type": "array",
            "maxItems": 16,
            "items": {
                "type": "object",
                "properties": {
                    "source_excerpt": excerpt_schema,
                    detail_key: {"type": "string"},
                },
                "required": ["source_excerpt", detail_key],
                "additionalProperties": False,
            },
        }

    return function_tool(
        "submit_evaluation_task_clause_map",
        "Classify exact task clauses before defining success evidence.",
        {
            "type": "object",
            "properties": {
                "required_outcomes": clause_list("obligation"),
                "optional_directions": clause_list("meaning"),
                "execution_constraints": clause_list("constraint"),
                "evaluation_measurements": clause_list("measurement"),
                "closure_rules": clause_list("rule"),
            },
            "required": [
                "required_outcomes",
                "optional_directions",
                "execution_constraints",
                "evaluation_measurements",
                "closure_rules",
            ],
            "additionalProperties": False,
        },
    )


def _task_clause_source_excerpts(
    *,
    objective: str,
    evaluation_request: str,
    task_spec: Mapping[str, Any] | None,
) -> tuple[str, ...]:
    """Expose exact authority fragments for the first clause-map call.

    The model still classifies the clauses, but it no longer has to retype
    source evidence. Structured task constraints are preferred because they
    are already bounded, one-line authority fragments; legacy callers fall
    back to non-empty source lines.
    """
    candidates: list[str] = []
    if task_spec is not None:
        constraints = task_spec.get("constraints")
        if isinstance(constraints, Sequence) and not isinstance(
            constraints, (str, bytes)
        ):
            candidates.extend(str(item).strip() for item in constraints)
        candidates.append(str(evaluation_request).strip())
    else:
        for value in (objective, evaluation_request):
            candidates.extend(
                line.strip().lstrip("- ")
                for line in str(value).splitlines()
            )
    return tuple(
        dict.fromkeys(
            candidate
            for candidate in candidates
            if 0 < len(candidate) <= 1_000
        )
    )


def _task_stop_tool() -> dict[str, Any]:
    return function_tool(
        "submit_evaluation_task_stops",
        "Submit only task-authored permission to terminate incomplete work.",
        {
            "type": "object",
            "properties": {
                "task_stop_criteria": {
                    "type": "array",
                    "maxItems": 6,
                    "items": {
                        "type": "object",
                        "properties": {
                            "condition": {"type": "string"},
                            "source_excerpt": {"type": "string"},
                        },
                        "required": ["condition", "source_excerpt"],
                        "additionalProperties": False,
                    },
                }
            },
            "required": ["task_stop_criteria"],
            "additionalProperties": False,
        },
    )


def _scorer_code_tool() -> dict[str, Any]:
    return function_tool(
        "submit_evaluation_scorer_code",
        "Submit complete Python source implementing the declared scorer contract.",
        {
            "type": "object",
            "properties": {"python_code": {"type": "string"}},
            "required": ["python_code"],
            "additionalProperties": False,
        },
    )


def _object_list(
    value: Any,
    *,
    field: str,
    required_keys: set[str],
    minimum: int,
    maximum: int,
) -> list[Mapping[str, Any]]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise RuntimeError(f"evaluation_gate_{field}_must_be_array")
    if not minimum <= len(value) <= maximum:
        raise RuntimeError(
            f"evaluation_gate_{field}_length_must_be_{minimum}_to_{maximum}"
        )
    result: list[Mapping[str, Any]] = []
    for index, item in enumerate(value, start=1):
        if not isinstance(item, Mapping):
            raise RuntimeError(
                f"evaluation_gate_{field}_{index}_fields_invalid:"
                f"expected={sorted(required_keys)}:"
                f"actual_type={type(item).__name__}"
            )
        actual_keys = set(item)
        if actual_keys != required_keys:
            raise RuntimeError(
                f"evaluation_gate_{field}_{index}_fields_invalid:"
                f"expected={sorted(required_keys)}:"
                f"actual={sorted(actual_keys)}"
            )
        result.append(item)
    return result


def _bounded_required_text(value: Any, issue: str, limit: int) -> str:
    text = str(value).strip()
    if not text or len(text) > limit:
        raise RuntimeError(issue)
    return text


def _canonical_source_excerpt(excerpt: str, source_text: str) -> str | None:
    """Recover an exact source quote across harmless transport normalization."""
    if excerpt in source_text:
        return excerpt
    pattern: list[str] = []
    in_whitespace = False
    for character in excerpt:
        if character.isspace():
            if not in_whitespace:
                pattern.append(r"\s+")
            in_whitespace = True
            continue
        in_whitespace = False
        if character in "_-\u2010\u2011\u2012\u2013\u2014\u2015":
            pattern.append(r"[_\-\u2010-\u2015]")
        else:
            pattern.append(re.escape(character))
    matches = list(re.finditer("".join(pattern), source_text, re.IGNORECASE))
    if not matches:
        return None
    return matches[0].group(0)


def _render_evaluation_summary(gate: Mapping[str, Any]) -> str:
    lines = [f"Evaluation gate ({gate.get('scope', 'legacy')}):"]
    for criterion in gate["success_criteria"]:
        lines.append(
            f"- {criterion['criterion_id']}: {criterion['requirement']}"
        )
    lines.append("Legal stop conditions:")
    for stop in gate["stop_criteria"]:
        lines.append(f"- {stop['stop_id']}: {stop['condition']}")
    lines.append(
        "Closure requires the agent-local evaluator to cite accepted evidence "
        "for every satisfied criterion."
    )
    return "\n".join(lines)


def _render_gate_markdown(gate: Mapping[str, Any]) -> str:
    lines = [
        "# Agent Evaluation Gate",
        "",
        f"Scope: `{gate.get('scope', 'legacy')}`",
        "",
        "## Success Criteria",
        "",
    ]
    for criterion in gate["success_criteria"]:
        lines.extend(
            [
                f"### {criterion['criterion_id']}",
                "",
                criterion["requirement"],
                "",
                f"Evidence: {criterion['evidence_expectation']}",
                "",
            ]
        )
    lines.extend(["## Stop Criteria", ""])
    for stop in gate["stop_criteria"]:
        lines.append(
            f"- `{stop['stop_id']}` ({stop['source']}): {stop['condition']}"
        )
    if gate["scorer_refs"]:
        lines.extend(["", "## Scorers", ""])
        lines.extend(f"- `{ref}`" for ref in gate["scorer_refs"])
    return "\n".join(lines).rstrip() + "\n"


def _render_evaluator_skill(
    *,
    success_criteria: Sequence[Mapping[str, Any]],
    stop_criteria: Sequence[Mapping[str, Any]],
    scorer_refs: Sequence[str],
    execution_constraints: Sequence[Mapping[str, Any]],
    closure_rules: Sequence[Mapping[str, Any]],
) -> str:
    criteria_text = "\n".join(
        f"- {item['criterion_id']}\n"
        f"  Requirement: {item['requirement']}\n"
        f"  Evidence expectation (how to check): {item['evidence_expectation']}"
        for item in success_criteria
    )
    stop_text = "\n".join(
        f"- {item['stop_id']} ({item['source']}): {item['condition']}"
        for item in stop_criteria
    )
    scorer_text = "\n".join(f"- {ref}" for ref in scorer_refs) or "- none"
    constraint_text = (
        "\n".join(
            f"- {item['constraint']} Source: {item['source_excerpt']}"
            for item in execution_constraints
        )
        or "- none"
    )
    closure_rule_text = (
        "\n".join(
            f"- {item['rule']} Source: {item['source_excerpt']}"
            for item in closure_rules
        )
        or "- none"
    )
    return f"""---
name: agent-local-evaluator
description: Judges this agent's accepted formal evidence against its immutable evaluation gate.
estimated_complexity: medium
---

# Agent-Local Evaluator

Judge accepted formal artifacts and their authorized stored dependencies visible
through exact refs. A plan status, completion claim, or receipt does not itself
establish the requested result. The evidence index is a
locator, not the evidence content. Runtime constructs `accepted_evidence_index`
only from Graph-node-approved completion refs and their accepted dependency
closure. Therefore an artifact's presence in that index is the mechanical proof
that it entered this agent's approved evidence flow; do not demand a separate
approval, review-event, or plan-status artifact. This proves admission only, not
the artifact's scientific content, which must still be inspected when needed. An
artifact envelope's publication status is a separate storage-lifecycle value and
must not override the Graph admission proven by this index. An
empty or short compact summary means the content was not projected; it never
means the artifact contains no evidence.
Read the relevant stored content needed to decide each criterion, including
supporting refs where the root only asserts the required fact. Stop tracing when
the requirement has sufficient support or a concrete evidence gap is identified;
do not audit unrelated ancestry. Read as needed within the existing allowance,
then submit one final checklist. Do not add, remove, or rewrite criteria.

Each `requirement` defines the obligation being judged. Its
`evidence_expectation` identifies the corresponding formal output and how to
check that obligation; it does not add obligations or condition this criterion
on other criteria. Apply the expectation within the requirement's scope, not as
a second checklist. An existence criterion and a scientific-content criterion
can therefore have different statuses for the same artifact.

At final judgment, mark a criterion `met` only when the cited evidence directly supports it. Use
`indeterminate` when the available evidence cannot decide it, and `unmet` when
evidence affirmatively shows it is not satisfied. A task stop may trigger only
when its declared condition is supported. Runtime limit handling is mechanical.
When the requirement's formal output is identified in the evidence expectation,
that canonical output must exist. A plan or different artifact kind merely
describing it cannot replace it. This identity rule does not require every
supporting fact to reside inside that output. Judge its scientific content from
the root and its exact authorized dependencies under the Evidence Completeness
instructions, not from the artifact kind or completion claim alone.
When a criterion names an exact canonical stored field or field path, inspect
that exact field in the stored artifact. A ref merely appearing in Markdown,
summary prose, a title, or another field cannot satisfy a requirement on
`depends_on` or any other named field. An empty named field does not become
nonempty because prose describes the intended relationship.
When a criterion requires provenance, lineage, dependencies, or traceability
without naming an exact storage field or requiring inline content, inspect the
canonical artifact envelope and follow its accepted `depends_on` and
`trace_refs` closure. Exact readable refs and their stored relationships are
valid provenance evidence. Do not require dependency content to be duplicated
inside the semantic payload merely because the criterion uses the word exact.
For a conditional criterion of the form `if A, require B`, first judge A from
accepted evidence. If A is conclusively false, the conditional criterion is
satisfied: mark it `met` and cite the exact evidence that establishes A is
false. If A is true, require B. If A itself cannot yet be decided, use
`indeterminate`. Do not call a conclusively inapplicable branch indeterminate.
During an unfinished run, a criterion with no accepted result artifact is
`indeterminate`, not `unmet`. Reserve `unmet` for exact accepted evidence that
affirmatively contradicts the criterion.
`success` is true exactly when every success criterion is `met`. `terminal`
is true only when success is true or one declared stop criterion is actually
triggered. Missing evidence, an unfinished criterion, or a currently unavailable
result means `terminal=false`; it does not end the agent and must remain visible
to the active execution controller.

Execution constraints govern whether evidence is admissible. They are not extra
deliverables. Evidence that violates an applicable constraint cannot establish a
criterion as met.

Closure rules govern the final terminal decision after evidence has been judged.
They are not production criteria or permission to skip required work. When a
closure rule names a required validator result or terminal status, require exact
accepted evidence for it before returning `terminal=true`.

## Success Criteria

{criteria_text}

## Legal Stop Criteria

{stop_text}

## Evidence Admissibility Constraints

{constraint_text}

## Closure Rules

{closure_rule_text}

## Optional Objective-Measurement Code Refs

{scorer_text}

These refs identify measurement code, not measurement results. When matching
execution observations are present in accepted evidence, judge from those
observations. Never treat source code alone as proof that a criterion is met.
"""


def _safe_segment(value: str) -> str:
    normalized = "".join(
        character if character.isalnum() or character in "._-" else "-"
        for character in str(value).strip()
    ).strip("-")
    return normalized or "agent"


def _atomic_write_text(path: Path, value: str) -> None:
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(value, encoding="utf-8")
    os.replace(temporary, path)


_SCORER_INSTRUCTION = """\
Implement only the single objective measurement described by the supplied scorer
contract. Do not turn it into a general artifact validator and do not reproduce,
repair, or replace the agent's domain algorithm.

`ctx` is a JSON-compatible mapping with exactly the inputs needed here:
- `success_criteria`: the immutable criteria defined by the gate.
- `accepted_evidence`: a list of objects containing `ref` and the full stored
  `artifact` visible to this agent.

The storage shape is authoritative:
- `ref` is an opaque exact reference. Never compare it with an artifact kind or
  infer scientific content from its text.
- A formal stored artifact identifies itself with `artifact.artifact_kind` and
  carries its machine-readable content in `artifact.machine_payload`.
- An execution observation identifies itself with
  `artifact.artifact_kind == "execution_observation"` and carries the executed
  return value in `artifact.result`.
- Do not assume an `artifact.payload` field exists. Inspect the actual canonical
  fields above and tolerate unrelated evidence entries.

Return complete Python source through the required tool. The source must define
exactly one top-level `def run(ctx)` entry point and return a JSON-compatible
mapping containing the declared measurement. Do not decide whether the overall
task succeeds and do not embed task-specific example answers.
"""
