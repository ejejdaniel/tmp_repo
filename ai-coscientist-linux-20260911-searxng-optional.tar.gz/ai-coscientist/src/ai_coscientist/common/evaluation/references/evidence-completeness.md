# Task Delivery And Evidence

Minimum delivery means answering the task, briefly explaining how the result
was obtained (sources, method, material assumptions), and linking the basis
needed to interpret the main result. Separate actual observations from
inference and disclose known interpretation-changing limitations. This is not
a universal scientific-quality checklist: no fixed length, section count,
citation count, mandatory experiment, or independent proof of every new idea.
A requested hypothesis or method can be delivered before it is validated;
cite its actual basis and label untested claims. Self-citation is not independent
confirmation, and missing external literature is not automatically failure.

Gate construction must express this delivery obligation visibly in the existing
requirements, merging it into task clauses that already cover it rather than
duplicating them. Evidence expectations describe verification, not hidden extra
obligations. For an already-issued gate, do not retroactively add a requirement;
apply its saved clauses until an authorized task revision changes them.

When publishing citations to stored sources, use create_reference_link to
produce openable Markdown links, rather than only listing raw ref identifiers
in prose or code spans. It locates an exact source, snapshot file, JSON Pointer
field, and optional 1-based inclusive line/page range. No range is needed when
the entire selected content is relevant. Put the returned reference_link in
Markdown as [a descriptive label](reference_link), and retain source_ref in
existing depends_on/trace_refs. Do not author hashes or encoded links yourself.
Readers may open reference:v1: links through their normal read tool; they
confer no permissions or scientific endorsement. Evaluator evidence_refs and
report evidence_index continue to use canonical source refs, not encoded links.

The task and active work unit define the required deliverable. A formal result
and its exact, authorized stored dependencies can form one logical deliverable.
Required facts may reside in the root result or those dependencies. Unless the
task explicitly requires a self-contained report or names a specific output
field, do not interpret "contains", "includes", or "reports" as requiring every
fact to be copied into the root Markdown or machine payload.

A reference alone is not proof. Read the linked content needed for the current
requirement, not every dependency recursively. If the content is missing, unreadable, inconsistent,
or does not support the requirement, report the actual gap. A producer's
completion claim, a receipt, a summary, or an unrelated log is not a substitute.
Do not expand visibility or treat raw C6 audit history as scientific evidence.

If a self-contained report is explicitly required, its requested results and
explanations must be readable in that report without following references.
Dependencies can substantiate the report but cannot replace its required
presentation. Existing explicitly required machine fields also remain required.

Distinguish missing evidence from missing requested presentation. Evidence that
already exists does not need to be recomputed or republished solely because it
is stored in a dependency. An incomplete self-contained account can be corrected
from verified stored evidence without rerunning the calculation. Satisfying
delivery requirements does not establish unperformed checks or scientific
validity beyond what the evidence supports.
