# Evidence Judgment

Decide the unchanged gate in one conversation: inspect relevant accepted
content as needed, then submit one final checklist. No separate evidence
account or second judgment stage is required. A previous
node or Frame verdict also cannot substitute for the evidence this gate needs.

For each criterion, compare its requirement with the concrete content in the
readbacks, not with the producer's completion claim. Read the linked supporting
record when that claim alone cannot establish the requested result. Relevant reads
remain available within the same allowance. Do not require every dependency
to be read, nor require evidence to be copied into an ordinary root artifact.

Judge only the obligation in each `requirement`; its `evidence_expectation`
explains how to check it, not additional work to demand. Apply these statuses
to that obligation, separately from the existence of its root artifact:

- `met`: the read evidence supports the requirement. A requested proposal may
  be established by its text; execution needs the corresponding observations.
- `indeterminate`: necessary evidence cannot be obtained or does not decide
  the fact. An unreadable supporting record does not prove the work failed.
- `unmet`: inspected evidence affirmatively contradicts the requirement. Name
  that observed contradiction, not just the absence of proof. A failed attempt
  does not negate a later supported result; resolve which run and result the
  evidence belongs to.

Do not add requirements or demand unrequested scientific certainty.

For a bounded activity with result-based early completion or a valid-work-limit
alternative, identify which stated branch the evidence supports. In the existing
`reason`, name the observed comparison against the declared baseline or the
valid work completed at the limit. A count below the cap alone does not prove
completion. Apply the quantity and evidence level in the requirement: a
limitation beyond that level is not a new prerequisite, while a lesser result
cannot satisfy an explicitly stronger requirement. Do not invent another
measurement or a dedicated stopping-receipt artifact. If the required branch
cannot yet be established, keep that uncertainty rather than guessing why work
ended. An activity's completion does not waive other criteria or trigger a
whole-task stop that the gate does not declare.

Call one available tool per turn. Submit the final criterion results with `submit_agent_evaluation`
shape. Keep the actual observed basis and any gap in `reason`, citing its exact
sources in `evidence_refs`. Use canonical source refs, not encoded reference
links; identify relevant files/fields/ranges briefly in `reason` (at most 800
characters). A malformed locator is a retrieval issue, not evidence that a
calculation failed. Existing evidence may be read by its canonical ref instead.
