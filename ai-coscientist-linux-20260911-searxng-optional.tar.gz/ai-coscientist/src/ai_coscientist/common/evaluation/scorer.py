from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence


def execute_evaluation_scorers(
    *,
    gate: Mapping[str, Any],
    evidence_index: Sequence[Mapping[str, Any]],
    read_ref: Callable[[str], Mapping[str, Any]],
    code_artifacts: Any | None,
    observations: Any,
    run_root: Path,
    events: Any,
    timeout_seconds: float = 60.0,
) -> list[dict[str, Any]]:
    """Execute optional narrow gate measurements against accepted evidence."""
    payload = gate.get("machine_payload")
    if not isinstance(payload, Mapping):
        raise ValueError("agent_evaluation_gate_payload_invalid")
    scorer_refs = tuple(
        str(ref).strip()
        for ref in payload.get("scorer_refs", ())
        if str(ref).strip()
    )
    if not scorer_refs:
        return []
    if code_artifacts is None:
        raise RuntimeError("evaluation_gate_scorer_code_store_unavailable")

    gate_ref = str(gate.get("artifact_ref") or "")
    accepted_evidence = _resolved_evidence(
        evidence_index,
        read_ref=read_ref,
        excluded_refs={gate_ref, *scorer_refs},
    )
    if not accepted_evidence:
        return []

    context = {
        "success_criteria": [
            dict(item) for item in payload.get("success_criteria", ())
        ],
        "accepted_evidence": accepted_evidence,
    }
    workspace = Path(run_root).resolve() / "workspace" / "evaluation-scorers"
    workspace.mkdir(parents=True, exist_ok=True)
    receipts: list[dict[str, Any]] = []
    evidence_refs = tuple(item["ref"] for item in accepted_evidence)
    for scorer_ref in scorer_refs:
        stored_code = code_artifacts.read(scorer_ref)
        digest = hashlib.sha256(
            json.dumps(
                {"scorer_ref": scorer_ref, "evidence_refs": evidence_refs},
                ensure_ascii=False,
                sort_keys=True,
            ).encode("utf-8")
        ).hexdigest()[:16]
        input_path = workspace / f"{digest}-input.json"
        output_path = workspace / f"{digest}-output.json"
        input_path.write_text(
            json.dumps(context, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        output_path.unlink(missing_ok=True)
        status, result, process = _execute_scorer(
            code_path=Path(stored_code["path"]),
            input_path=input_path,
            output_path=output_path,
            cwd=workspace,
            timeout_seconds=timeout_seconds,
        )
        receipt = observations.publish(
            namespace="agent-evaluation-scorer",
            result=result,
            status=status,
            metadata={
                "code_artifact_ref": scorer_ref,
                "accepted_evidence_refs": list(evidence_refs),
                "process": process,
            },
        )
        observation_ref = str(receipt["observation_ref"])
        observations.inspect(observation_ref, selected_paths=("result",))
        evidence_receipt = {
            **dict(receipt),
            "summary": (
                "Objective measurement result produced by "
                f"{scorer_ref}; status={status}."
            ),
            "producer_ref": scorer_ref,
        }
        receipts.append(evidence_receipt)
        events.append(
            "evaluation_scorer_executed",
            {
                "code_artifact_ref": scorer_ref,
                "observation_ref": observation_ref,
                "status": status,
                "accepted_evidence_refs": list(evidence_refs),
            },
        )
    return receipts


def _resolved_evidence(
    evidence_index: Sequence[Mapping[str, Any]],
    *,
    read_ref: Callable[[str], Mapping[str, Any]],
    excluded_refs: set[str],
) -> list[dict[str, Any]]:
    resolved: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in evidence_index:
        ref = _receipt_ref(item)
        if not ref or ref in excluded_refs or ref in seen:
            continue
        try:
            stored = dict(read_ref(ref))
        except (KeyError, OSError, PermissionError, ValueError):
            continue
        resolved.append({"ref": ref, "artifact": stored})
        seen.add(ref)
    return resolved


def _receipt_ref(item: Mapping[str, Any]) -> str:
    for key in ("artifact_ref", "code_artifact_ref", "observation_ref", "ref"):
        value = str(item.get(key) or "").strip()
        if value:
            return value
    return ""


def _execute_scorer(
    *,
    code_path: Path,
    input_path: Path,
    output_path: Path,
    cwd: Path,
    timeout_seconds: float,
) -> tuple[str, dict[str, Any], dict[str, Any]]:
    creationflags = 0
    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        completed = subprocess.run(
            [
                sys.executable,
                "-I",
                "-c",
                _SCORER_HARNESS,
                str(code_path.resolve()),
                str(input_path.resolve()),
                str(output_path.resolve()),
            ],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
            creationflags=creationflags,
            env={
                **os.environ,
                "PYTHONHASHSEED": "0",
                "PYTHONDONTWRITEBYTECODE": "1",
            },
        )
    except subprocess.TimeoutExpired as exc:
        return (
            "code_artifact_execution_failed",
            {"error": "evaluation_scorer_timeout"},
            {
                "returncode": None,
                "stdout": str(exc.stdout or "")[-4000:],
                "stderr": str(exc.stderr or "")[-4000:],
            },
        )
    process = {
        "returncode": completed.returncode,
        "stdout": completed.stdout[-4000:],
        "stderr": completed.stderr[-4000:],
    }
    if completed.returncode != 0:
        return (
            "code_artifact_execution_failed",
            {
                "error": "evaluation_scorer_execution_failed",
                "detail": completed.stderr[-4000:],
            },
            process,
        )
    if not output_path.is_file():
        return (
            "code_artifact_execution_failed",
            {"error": "evaluation_scorer_output_missing"},
            process,
        )
    try:
        result = json.loads(output_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        return (
            "code_artifact_execution_failed",
            {"error": "evaluation_scorer_output_invalid", "detail": str(exc)},
            process,
        )
    if not isinstance(result, Mapping):
        return (
            "code_artifact_execution_failed",
            {"error": "evaluation_scorer_result_must_be_object"},
            process,
        )
    return "code_artifact_executed", dict(result), process


_SCORER_HARNESS = r"""
import importlib.util
import json
import sys
from collections.abc import Mapping

code_path, input_path, output_path = sys.argv[1:4]
spec = importlib.util.spec_from_file_location("agent_evaluation_scorer", code_path)
if spec is None or spec.loader is None:
    raise RuntimeError("evaluation_scorer_import_failed")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
run = getattr(module, "run", None)
if not callable(run):
    raise RuntimeError("evaluation_scorer_run_missing")
with open(input_path, "r", encoding="utf-8") as handle:
    context = json.load(handle)
result = run(context)
if not isinstance(result, Mapping):
    raise TypeError("evaluation_scorer_result_must_be_object")
with open(output_path, "w", encoding="utf-8") as handle:
    json.dump(dict(result), handle, ensure_ascii=False, indent=2)
"""
