from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from .._runtime_support import function_tool
from ..memory_lifecycle.prompt import bounded_projection, bounded_text
from ..model import ChatModel, complete_model_turn
from ..openai_compatible import ModelProtocolError
from ..sub_loop_toolkit import HumanInteractionPause
from ..reference_links import SOURCE_CONTENT_PREFIXES, evidence_ref_strings, source_ref


_CRITERION_STATUSES = frozenset({"met", "unmet", "indeterminate"})


def evidence_completeness_instruction() -> str:
    return (Path(__file__).parent / "references" / "evidence-completeness.md").read_text(
        encoding="utf-8"
    ).strip()


_EVIDENCE_LINEAGE_RULES = """\
Evidence lineage is ordered, not a bag of mutually current claims. A failure or
Graph-revision artifact in a result's dependency ancestry records why later work
was needed. It does not by itself negate a later accepted result that was
produced after that failure. Judge the later result from its own exact content.
When an accepted capability_candidate contains an exact pending package_ref,
that linked package is readable content evidence for the candidate. Read it when
the candidate envelope is insufficient; do not infer that the package is empty.
"""


def initial_evaluation_state(
    gate_ref: str,
    gate_payload: Mapping[str, Any],
) -> dict[str, Any]:
    criteria = _gate_success_criteria(gate_payload)
    return {
        "gate_ref": str(gate_ref),
        "terminal": False,
        "success": False,
        "criterion_results": [
            {
                "criterion_id": criterion["criterion_id"],
                "status": "indeterminate",
                "evidence_refs": [],
                "reason": "Not evaluated yet.",
            }
            for criterion in criteria
        ],
        "triggered_stop_id": "",
    }


def evaluate_agent_gate(
    *,
    model: ChatModel,
    events: Any,
    gate: Mapping[str, Any],
    evaluator_skill: str,
    evidence_index: Sequence[Mapping[str, Any]],
    read_ref: Callable[..., Mapping[str, Any]],
    previous_state: Mapping[str, Any],
    round_number: int,
    max_reads: int | None = None,
    fresh_evidence_by_criterion: Mapping[str, Sequence[str]] | None = None,
    human_input_tool: Mapping[str, Any] | None = None,
    request_human_input: Callable[[Mapping[str, Any]], None] | None = None,
) -> dict[str, Any]:
    """Run the bounded agent-local evaluator and return validated closure state."""
    gate_ref = str(gate.get("artifact_ref") or "")
    gate_payload = gate.get("machine_payload")
    if not gate_ref or not isinstance(gate_payload, Mapping):
        raise ValueError("agent_evaluation_gate_invalid")
    evaluation_scope = str(gate_payload.get("scope") or "global").strip()
    if evaluation_scope not in {"global", "frame"}:
        raise ValueError("agent_evaluation_gate_scope_invalid")
    criteria = _gate_success_criteria(gate_payload)
    stop_criteria = _gate_stop_criteria(gate_payload)
    allowed_refs = _initial_allowed_refs(
        evidence_index,
        gate_payload=gate_payload,
        gate_ref=gate_ref,
    )
    compact_index = [
        dict(item)
        for item in evidence_index
        if str(item.get("artifact_ref") or item.get("code_artifact_ref") or "")
        != gate_ref
    ]
    fresh_evidence = _normalized_fresh_evidence(
        fresh_evidence_by_criterion,
        criterion_ids={str(item["criterion_id"]) for item in criteria},
        allowed_refs=allowed_refs,
    )
    instruction = "\n\n".join((
        "The saved evaluator defines the task requirements and final judgment. "
        "Read the required evidence as needed, then submit one final checklist. "
        "No separate evidence-account draft is required.",
        evaluator_skill, _EVIDENCE_LINEAGE_RULES, evidence_completeness_instruction(),
    ))
    stage_pages = Path(__file__).parent / "references"
    judgment_instruction = (stage_pages / "evidence-judgment.md").read_text(encoding="utf-8")
    instruction += "\n\n" + judgment_instruction
    messages: list[dict[str, Any]] = [
        {
            "role": "system",
            "content": instruction,
        },
        {
            "role": "user",
            "content": json.dumps(
                {
                    "evaluation_gate": dict(gate_payload),
                    "previous_evaluation_state": bounded_projection(
                        dict(previous_state), max_depth=5, max_items=24
                    ),
                    "accepted_evidence_index": compact_index,
                    "runtime": {"round_number": int(round_number)},
                },
                ensure_ascii=False,
                indent=2,
            ),
        },
    ]
    if fresh_evidence:
        messages.append(
            {
                "role": "user",
                "content": (
                    "Fresh Graph-approved completion evidence now directly "
                    "addresses criteria that were not met in the previous "
                    "evaluation:\n"
                    + json.dumps(fresh_evidence, ensure_ascii=False, indent=2)
                    + "\nThe previous evaluation is historical context, not "
                    "current authority. Read every listed ref before submitting. "
                    "For each listed criterion, cite at least one of its fresh "
                    "refs in the new result whether the criterion becomes met, "
                    "remains unmet, or remains indeterminate."
                ),
            }
        )
    read_limit = (
        max(0, int(max_reads))
        if max_reads is not None
        else len(allowed_refs - {gate_ref})
    )
    reads_used = 0
    read_refs: set[str] = set()
    read_requests: set[tuple[str, str | None, int, int]] = set()
    last_issue = ""
    evaluator_turn = 0
    repair_pending = False
    # Reads and format repair share the existing evaluation budget.
    while evaluator_turn < read_limit + 4:
        evaluator_turn += 1
        messages = [
            {"role": "system", "content": instruction},
            *messages[1:],
        ]
        tools = [_read_evidence_tool(), _submit_evaluation_tool()]
        if human_input_tool is not None:
            tools.append(dict(human_input_tool))
        events.append(
            "agent_evaluator_prompt_snapshot",
            {
                "round": round_number,
                "evaluator_turn": evaluator_turn,
                "messages": messages,
                "tool_names": [tool["function"]["name"] for tool in tools],
                "prompt_sources": _prompt_source_summary(
                    evaluator_skill=messages[0]["content"],
                    gate_payload=gate_payload,
                    previous_state=previous_state,
                    evidence_index=compact_index,
                    messages=messages,
                    tools=tools,
                ),
            },
        )
        is_repair = repair_pending
        repair_pending = False
        try:
            turn = complete_model_turn(
                model,
                messages=messages,
                tools=tools,
                purpose=f"evaluate agent-local {evaluation_scope} closure",
                tool_choice="required",
                scientific=not is_repair,
                repair=is_repair,
            )
        except ModelProtocolError as exc:
            repair_pending = True
            last_issue = f"model_protocol_error:{exc}"
            messages.append(
                {
                    "role": "user",
                    "content": (
                        "The evaluator response violated the required tool "
                        f"protocol: {last_issue}. Follow the active stage's "
                        "response protocol; do not change the task or evidence."
                    ),
                }
            )
            continue
        events.append(
            "agent_evaluator_model_turn",
            {
                "round": round_number,
                "evaluator_turn": evaluator_turn,
                "content": turn.content,
                "tool_calls": [
                    {"name": call.name, "arguments": dict(call.arguments)}
                    for call in turn.tool_calls
                ],
                "usage": dict(turn.usage),
            },
        )
        if len(turn.tool_calls) != 1:
            repair_pending = True
            last_issue = (
                "agent_evaluator_requires_one_tool_call:"
                f"{len(turn.tool_calls)}"
            )
            messages.append(
                {
                    "role": "user",
                    "content": last_issue + ". Call exactly one available tool.",
                }
            )
            continue
        call = turn.tool_calls[0]
        if call.name == "request_human_input":
            if request_human_input is None:
                raise RuntimeError(
                    "agent_evaluator_human_input_callback_missing"
                )
            request_human_input(call.arguments)
            raise HumanInteractionPause()
        if call.name == "read_evaluation_evidence":
            if reads_used >= read_limit:
                last_issue = "agent_evaluator_read_budget_exhausted"
                messages.append(
                    {
                        "role": "user",
                        "content": (
                            last_issue
                            + ". All reads authorized for this evaluation have "
                            "been consumed. Finish the current stage from the "
                            "read content, explicitly retaining any evidence gaps."
                        ),
                    }
                )
                continue
            try:
                ref, path, offset, limit = _evaluation_read_request(call.arguments)
                canonical_ref = source_ref(ref)
            except ValueError as exc:
                repair_pending = True
                last_issue = str(exc)
                messages.append({"role": "user", "content": last_issue})
                continue
            if canonical_ref not in allowed_refs:
                last_issue = f"agent_evaluator_ref_not_accepted:{ref}"
                messages.append(
                    {
                        "role": "user",
                        "content": (
                            last_issue
                            + ". Read only an exact ref from accepted evidence."
                        ),
                    }
                )
                continue
            request_key = (ref, path, offset, limit)
            if request_key in read_requests:
                last_issue = f"agent_evaluator_ref_already_read:{ref}"
                messages.append(
                    {
                        "role": "user",
                        "content": (
                            last_issue
                            + ". This exact page or record is already shown. Use "
                            "it, or read a different file/page or accepted ref."
                        ),
                    }
                )
                continue
            try:
                paged = path is not None or ref.startswith(("reference:", *SOURCE_CONTENT_PREFIXES))
                stored = dict(read_ref(ref) if not paged else read_ref(
                    ref, path=path, line_offset=offset, line_limit=limit,
                ))
            except Exception as exc:
                last_issue = f"agent_evaluator_ref_read_failed:{ref}:{exc}"
                messages.append({"role": "user", "content": last_issue})
                continue
            reads_used += 1
            read_refs.add(canonical_ref)
            read_requests.add(request_key)
            discovered_refs: list[str] = []
            for discovered in (() if paged else evidence_ref_strings(stored)):
                if discovered == gate_ref:
                    continue
                try:
                    read_ref(discovered)
                except Exception:
                    continue
                if discovered not in allowed_refs:
                    discovered_refs.append(discovered)
                    if max_reads is None:
                        read_limit += 1
                allowed_refs.add(discovered)
            linked_ref_note = ""
            if discovered_refs:
                linked_ref_note = (
                    "\n\nReadable exact refs discovered inside this accepted "
                    "evidence:\n- "
                    + "\n- ".join(discovered_refs)
                    + "\nRead any ref needed to judge content. A linked pending "
                    "package is the candidate's exact source, not a separate "
                    "unaccepted claim."
                )
            messages.extend(
                [
                    {
                        "role": "assistant",
                        "content": "Requested accepted evidence: " + json.dumps(
                            dict(call.arguments), ensure_ascii=False),
                    },
                    {
                        "role": "user",
                        "content": (
                            "Exact stored record (retrieved content, not a verified conclusion):\n"
                        )
                        + json.dumps(
                            stored if paged else _evidence_projection(stored),
                            ensure_ascii=False,
                            indent=2,
                        )
                        + linked_ref_note,
                    },
                ]
            )
            continue
        if call.name != "submit_agent_evaluation":
            repair_pending = True
            last_issue = f"agent_evaluator_unknown_tool:{call.name}"
            messages.append({"role": "user", "content": last_issue})
            continue
        unread_fresh_refs = set(
            ref for refs in fresh_evidence.values() for ref in refs
        ) - read_refs
        if unread_fresh_refs:
            last_issue = (
                "agent_evaluator_fresh_evidence_unread:"
                + ",".join(sorted(unread_fresh_refs))
            )
            messages.append(
                {
                    "role": "user",
                    "content": (
                        last_issue
                        + ". Read each fresh Graph completion ref before "
                        "submitting the current evaluation."
                    ),
                }
            )
            continue
        submission, bounded_reasons = _bound_evaluation_reason_text(
            call.arguments
        )
        if bounded_reasons:
            events.append(
                "agent_evaluation_reason_text_bounded",
                {
                    "round": round_number,
                    "evaluator_turn": evaluator_turn,
                    "criterion_reasons": bounded_reasons,
                },
            )
        submission, attached_fresh_refs = (
            _attach_missing_fresh_evidence_anchors(
                submission,
                fresh_evidence_by_criterion=fresh_evidence,
                allowed_refs=allowed_refs,
            )
        )
        if attached_fresh_refs:
            events.append(
                "agent_evaluation_fresh_evidence_anchors_attached",
                {
                    "round": round_number,
                    "evaluator_turn": evaluator_turn,
                    "criterion_refs": attached_fresh_refs,
                },
            )
        try:
            state = _validated_evaluation_submission(
                submission,
                gate_ref=gate_ref,
                criteria=criteria,
                stop_criteria=stop_criteria,
                allowed_refs=allowed_refs,
                fresh_evidence_by_criterion=fresh_evidence,
            )
        except RuntimeError as exc:
            repair_pending = True
            last_issue = str(exc)
            messages.extend(
                [
                    {
                        "role": "assistant",
                        "content": "Previous invalid evaluation:\n"
                        + json.dumps(dict(call.arguments), ensure_ascii=False),
                    },
                    {
                        "role": "user",
                        "content": (
                            "Repair only this evaluation contract error and call "
                            f"submit_agent_evaluation again: {last_issue}"
                        ),
                    },
                ]
            )
            continue
        closure = _closure_projection(state)
        events.append(
            "agent_evaluation_completed",
            {
                "round": round_number,
                "evaluation_state": state,
                "closure": closure,
            },
        )
        return closure

    fallback = _validated_previous_or_initial(
        previous_state,
        gate_ref=gate_ref,
        gate_payload=gate_payload,
    )
    closure = _closure_projection(
        fallback,
        extra_issue=f"agent_evaluator_failed:{last_issue or 'turn_limit'}",
    )
    events.append(
        "agent_evaluation_failed",
        {
            "round": round_number,
            "reason": last_issue or "turn_limit",
            "closure": closure,
        },
    )
    return closure


def _bound_evaluation_reason_text(
    arguments: Mapping[str, Any],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Enforce the declared text bound without changing evaluation semantics."""
    repaired = copy.deepcopy(dict(arguments))
    raw_results = repaired.get("criterion_results")
    if isinstance(raw_results, (str, bytes)) or not isinstance(
        raw_results, Sequence
    ):
        return repaired, []

    results = list(raw_results)
    changes: list[dict[str, Any]] = []
    for index, raw in enumerate(results):
        if not isinstance(raw, Mapping):
            continue
        reason = raw.get("reason")
        if not isinstance(reason, str):
            continue
        normalized = reason.strip()
        if len(normalized) <= 800:
            continue
        bounded = normalized[:797].rstrip() + "..."
        item = dict(raw)
        item["reason"] = bounded
        results[index] = item
        changes.append(
            {
                "criterion_id": str(raw.get("criterion_id") or ""),
                "original_length": len(normalized),
                "bounded_length": len(bounded),
            }
        )
    repaired["criterion_results"] = results
    return repaired, changes


def _attach_missing_fresh_evidence_anchors(
    arguments: Mapping[str, Any],
    *,
    fresh_evidence_by_criterion: Mapping[str, Sequence[str]],
    allowed_refs: set[str],
) -> tuple[dict[str, Any], dict[str, str]]:
    """Repair citation bookkeeping without changing evaluator semantics."""
    repaired = copy.deepcopy(dict(arguments))
    raw_results = repaired.get("criterion_results")
    if isinstance(raw_results, (str, bytes)) or not isinstance(
        raw_results, Sequence
    ):
        return repaired, {}

    attached: dict[str, str] = {}
    for raw in raw_results:
        if not isinstance(raw, Mapping) or set(raw) != {
            "criterion_id",
            "status",
            "evidence_refs",
            "reason",
        }:
            continue
        criterion_id = str(raw.get("criterion_id") or "").strip()
        required = [
            str(ref).strip()
            for ref in fresh_evidence_by_criterion.get(criterion_id) or ()
            if str(ref).strip() in allowed_refs
        ]
        raw_refs = raw.get("evidence_refs")
        if (
            not required
            or isinstance(raw_refs, (str, bytes))
            or not isinstance(raw_refs, Sequence)
        ):
            continue
        refs = [str(ref).strip() for ref in raw_refs if str(ref).strip()]
        # This is citation-only repair. Empty, duplicated, or unauthorized
        # evidence remains an evaluator contract error for the LLM to repair.
        if (
            not refs
            or len(refs) != len(set(refs))
            or set(refs) - allowed_refs
            or set(required).intersection(refs)
        ):
            continue
        anchor = required[0]
        raw["evidence_refs"] = [*refs, anchor]
        attached[criterion_id] = anchor
    return repaired, attached


def _prompt_source_summary(
    *,
    evaluator_skill: str,
    gate_payload: Mapping[str, Any],
    previous_state: Mapping[str, Any],
    evidence_index: Sequence[Mapping[str, Any]],
    messages: Sequence[Mapping[str, Any]],
    tools: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    def source(storage_class: str, name: str, value: Any) -> dict[str, Any]:
        rendered = json.dumps(value, ensure_ascii=False, default=str)
        return {
            "storage_class": storage_class,
            "name": name,
            "serialized_chars": len(rendered),
        }

    initial_message_count = 2
    return [
        source("instruction", "agent_local_evaluator_skill", evaluator_skill),
        source("C0", "agent_evaluation_gate", gate_payload),
        source("C1", "previous_evaluation_state", previous_state),
        source("C2", "accepted_evidence_index", evidence_index),
        source(
            "C5",
            "evaluator_readback_and_repair_context",
            list(messages[initial_message_count:]),
        ),
        source("tool_schema", "agent_evaluator_tools", tools),
    ]


def evaluation_state_from_closure(closure: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "gate_ref": str(closure.get("gate_ref") or ""),
        "terminal": bool(closure.get("complete")),
        "success": bool(closure.get("success")),
        "criterion_results": copy.deepcopy(
            list(closure.get("criterion_results") or [])
        ),
        "triggered_stop_id": str(closure.get("triggered_stop_id") or ""),
    }


def _validated_evaluation_submission(
    arguments: Mapping[str, Any],
    *,
    gate_ref: str,
    criteria: Sequence[Mapping[str, Any]],
    stop_criteria: Sequence[Mapping[str, Any]],
    allowed_refs: set[str],
    fresh_evidence_by_criterion: Mapping[str, Sequence[str]] | None = None,
) -> dict[str, Any]:
    if set(arguments) != {
        "terminal",
        "success",
        "criterion_results",
        "triggered_stop_id",
    }:
        raise RuntimeError("agent_evaluation_fields_invalid")
    if not isinstance(arguments["terminal"], bool):
        raise RuntimeError("agent_evaluation_terminal_must_be_boolean")
    if not isinstance(arguments["success"], bool):
        raise RuntimeError("agent_evaluation_success_must_be_boolean")
    raw_results = arguments["criterion_results"]
    if isinstance(raw_results, (str, bytes)) or not isinstance(
        raw_results, Sequence
    ):
        raise RuntimeError("agent_evaluation_results_must_be_array")
    criterion_ids = [str(item["criterion_id"]) for item in criteria]
    if len(raw_results) != len(criterion_ids):
        raise RuntimeError("agent_evaluation_must_cover_every_criterion")
    normalized_results: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, raw in enumerate(raw_results, start=1):
        if not isinstance(raw, Mapping) or set(raw) != {
            "criterion_id",
            "status",
            "evidence_refs",
            "reason",
        }:
            raise RuntimeError(
                f"agent_evaluation_result_{index}_fields_invalid"
            )
        criterion_id = str(raw["criterion_id"]).strip()
        if criterion_id not in criterion_ids or criterion_id in seen:
            raise RuntimeError(
                f"agent_evaluation_result_{index}_criterion_invalid"
            )
        status = str(raw["status"]).strip()
        if status not in _CRITERION_STATUSES:
            raise RuntimeError(
                f"agent_evaluation_result_{index}_status_invalid"
            )
        raw_refs = raw["evidence_refs"]
        if isinstance(raw_refs, (str, bytes)) or not isinstance(
            raw_refs, Sequence
        ):
            raise RuntimeError(
                f"agent_evaluation_result_{index}_evidence_refs_invalid"
            )
        refs = [str(ref).strip() for ref in raw_refs if str(ref).strip()]
        if len(refs) != len(set(refs)) or set(refs) - allowed_refs:
            raise RuntimeError(
                f"agent_evaluation_result_{index}_evidence_not_accepted"
            )
        required_fresh_refs = set(
            (fresh_evidence_by_criterion or {}).get(criterion_id) or ()
        )
        if required_fresh_refs and not required_fresh_refs.intersection(refs):
            raise RuntimeError(
                "agent_evaluation_result_fresh_evidence_required:"
                f"{criterion_id}"
            )
        if status == "met" and not refs:
            raise RuntimeError(
                f"agent_evaluation_result_{index}_met_requires_evidence"
            )
        reason = str(raw["reason"]).strip()
        if not reason or len(reason) > 800:
            raise RuntimeError(
                f"agent_evaluation_result_{index}_reason_invalid:"
                f"reason_must_be_1_to_800_characters:actual_length={len(reason)}"
            )
        seen.add(criterion_id)
        normalized_results.append(
            {
                "criterion_id": criterion_id,
                "status": status,
                "evidence_refs": refs,
                "reason": reason,
            }
        )
    normalized_results.sort(
        key=lambda item: criterion_ids.index(item["criterion_id"])
    )
    all_met = all(item["status"] == "met" for item in normalized_results)
    success = bool(arguments["success"])
    terminal = bool(arguments["terminal"])
    if success != all_met:
        raise RuntimeError("agent_evaluation_success_conflicts_with_criteria")

    triggered_stop_id = str(arguments["triggered_stop_id"] or "").strip()
    if triggered_stop_id.lower() in {"none", "null", "n/a"}:
        triggered_stop_id = ""
    stops_by_id = {str(item["stop_id"]): item for item in stop_criteria}
    if triggered_stop_id and triggered_stop_id not in stops_by_id:
        raise RuntimeError("agent_evaluation_triggered_stop_unknown")
    if success and triggered_stop_id:
        raise RuntimeError("agent_evaluation_success_must_not_trigger_stop")
    expected_terminal = success or bool(triggered_stop_id)
    if terminal != expected_terminal:
        raise RuntimeError(
            "agent_evaluation_terminal_state_invalid: terminal must be false "
            "while any success criterion remains unmet or indeterminate and "
            "no declared stop criterion is triggered; missing evidence is "
            "unfinished work, not a terminal result"
        )
    return {
        "gate_ref": gate_ref,
        "terminal": terminal,
        "success": success,
        "criterion_results": normalized_results,
        "triggered_stop_id": triggered_stop_id,
    }


def _closure_projection(
    state: Mapping[str, Any],
    *,
    extra_issue: str = "",
) -> dict[str, Any]:
    issues = [
        f"{item['criterion_id']}:{item['status']}:{item['reason']}"
        for item in state["criterion_results"]
        if item["status"] != "met"
    ]
    if extra_issue:
        issues.append(extra_issue)
    return {
        "complete": bool(state["terminal"]),
        "success": bool(state["success"]),
        "gate_ref": str(state["gate_ref"]),
        "criterion_results": copy.deepcopy(list(state["criterion_results"])),
        "triggered_stop_id": str(state["triggered_stop_id"]),
        "issues": issues,
    }


def _validated_previous_or_initial(
    previous: Mapping[str, Any],
    *,
    gate_ref: str,
    gate_payload: Mapping[str, Any],
) -> dict[str, Any]:
    initial = initial_evaluation_state(gate_ref, gate_payload)
    if not isinstance(previous, Mapping):
        return initial
    try:
        if set(previous) != set(initial):
            return initial
        if str(previous["gate_ref"]) != gate_ref:
            return initial
        criterion_ids = [
            item["criterion_id"] for item in initial["criterion_results"]
        ]
        previous_ids = [
            str(item.get("criterion_id") or "")
            for item in previous["criterion_results"]
            if isinstance(item, Mapping)
        ]
        if previous_ids != criterion_ids:
            return initial
        return copy.deepcopy(dict(previous))
    except Exception:
        return initial


def _gate_success_criteria(payload: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    value = payload.get("success_criteria")
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence) or not value:
        raise ValueError("agent_evaluation_gate_success_criteria_invalid")
    result: list[Mapping[str, Any]] = []
    ids: set[str] = set()
    for item in value:
        if not isinstance(item, Mapping) or set(item) != {
            "criterion_id",
            "requirement",
            "evidence_expectation",
        }:
            raise ValueError("agent_evaluation_gate_success_criterion_invalid")
        criterion_id = str(item["criterion_id"])
        if not criterion_id or criterion_id in ids:
            raise ValueError("agent_evaluation_gate_criterion_ids_invalid")
        ids.add(criterion_id)
        result.append(item)
    return result


def _gate_stop_criteria(payload: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    value = payload.get("stop_criteria")
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValueError("agent_evaluation_gate_stop_criteria_invalid")
    result: list[Mapping[str, Any]] = []
    ids: set[str] = set()
    for item in value:
        if not isinstance(item, Mapping) or set(item) != {
            "stop_id",
            "condition",
            "source",
            "source_excerpt",
        }:
            raise ValueError("agent_evaluation_gate_stop_criterion_invalid")
        stop_id = str(item["stop_id"])
        if not stop_id or stop_id in ids:
            raise ValueError("agent_evaluation_gate_stop_ids_invalid")
        ids.add(stop_id)
        result.append(item)
    return result


def _initial_allowed_refs(
    index: Sequence[Mapping[str, Any]],
    *,
    gate_payload: Mapping[str, Any],
    gate_ref: str,
) -> set[str]:
    refs: set[str] = set()
    for item in index:
        refs.update(evidence_ref_strings(item))
        direct = str(
            item.get("artifact_ref")
            or item.get("code_artifact_ref")
            or item.get("observation_ref")
            or ""
        )
        if direct:
            refs.add(direct)
    refs.update(str(ref) for ref in gate_payload.get("scorer_refs") or [])
    refs.discard(gate_ref)
    return refs


def _normalized_fresh_evidence(
    value: Mapping[str, Sequence[str]] | None,
    *,
    criterion_ids: set[str],
    allowed_refs: set[str],
) -> dict[str, list[str]]:
    normalized: dict[str, list[str]] = {}
    for raw_criterion_id, raw_refs in (value or {}).items():
        criterion_id = str(raw_criterion_id).strip()
        if criterion_id not in criterion_ids:
            continue
        refs = list(
            dict.fromkeys(
                str(ref).strip()
                for ref in raw_refs
                if str(ref).strip() in allowed_refs
            )
        )
        if refs:
            normalized[criterion_id] = refs
    return normalized


def _evidence_projection(stored: Mapping[str, Any]) -> Mapping[str, Any]:
    package_ref = str(stored.get("package_ref") or "")
    if package_ref.startswith("workspace:capability_registry/pending/"):
        projection = dict(
            bounded_projection(
                dict(stored),
                max_depth=8,
                max_items=32,
                max_text_chars=12_000,
            )
        )
        files = stored.get("files")
        if isinstance(files, Sequence) and not isinstance(files, (str, bytes)):
            remaining = 24_000
            exact_files: list[dict[str, Any]] = []
            for raw in files[:32]:
                if not isinstance(raw, Mapping):
                    continue
                item = dict(raw)
                text = raw.get("text")
                if isinstance(text, str):
                    visible = text[:remaining]
                    item["text"] = visible
                    item["prompt_truncated"] = len(visible) != len(text)
                    remaining -= len(visible)
                exact_files.append(item)
            projection["files"] = exact_files
        return projection
    projection = bounded_projection(dict(stored), max_depth=8, max_items=32)
    if isinstance(projection, Mapping):
        projection = dict(projection)
        for key in ("markdown", "code"):
            if key in stored:
                projection[key] = bounded_text(str(stored[key]), 12_000)
    return projection


def _evaluation_read_request(arguments: Mapping[str, Any]) -> tuple[str, str | None, int, int]:
    if set(arguments) - {"ref", "path", "line_offset", "line_limit"}:
        raise ValueError("agent_evaluator_read_unknown_argument")
    ref = arguments.get("ref")
    if not isinstance(ref, str) or not ref.strip():
        raise ValueError("agent_evaluator_read_ref_required")
    path = arguments.get("path")
    is_link = ref.startswith("reference:")
    is_source = ref.startswith(SOURCE_CONTENT_PREFIXES)
    if is_link and "path" in arguments:
        raise ValueError("reference_path_override_not_allowed")
    if is_source and "path" in arguments:
        raise ValueError("reference_path_requires_snapshot")
    if path is None:
        if "path" in arguments or (not (is_link or is_source) and {"line_offset", "line_limit"}.intersection(arguments)):
            raise ValueError("agent_evaluator_read_page_requires_path")
        if not (is_link or is_source):
            return ref.strip(), None, 0, 200
    elif not isinstance(path, str) or not path.strip():
        raise ValueError("agent_evaluator_read_path_required")
    offset, limit = arguments.get("line_offset", 0), arguments.get("line_limit", 200)
    if type(offset) is not int or offset < 0:
        raise ValueError("agent_evaluator_read_line_offset_invalid")
    if type(limit) is not int or not 1 <= limit <= 2_000:
        raise ValueError("agent_evaluator_read_line_limit_invalid")
    return ref.strip(), path, offset, limit


def _read_evidence_tool() -> dict[str, Any]:
    return function_tool(
        "read_evaluation_evidence",
        "Read an exact accepted evidence ref. For a development_project_snapshot, "
        "ref alone returns its manifest, not source code. Use path and optional "
        "line_offset/line_limit to read a hash-verified immutable file from that "
        "snapshot; follow next_line_offset for more. This never reads mutable files. "
        "Also accepts reference:v1: links with an already-authorized underlying source. "
        "Links support pagination within their selected content, without path override. "
        "Linked source_file/source_probe/workspace_terminal refs use the same pagination "
        "without path; the existing source reader retains mission scope and source identity checks. "
        "Cite canonical source refs, not encoded links; identify relevant files/ranges briefly in reason.",
        {
            "type": "object",
            "properties": {
                "ref": {"type": "string"},
                "path": {"type": "string", "minLength": 1,
                         "description": "Relative file path listed in this exact project snapshot."},
                "line_offset": {"type": "integer", "minimum": 0,
                                "description": "Zero-based line offset; default 0. Requires snapshot path, source content ref or reference link."},
                "line_limit": {"type": "integer", "minimum": 1, "maximum": 2000,
                               "description": "Maximum lines; default 200. Requires snapshot path, source content ref or reference link."},
            },
            "required": ["ref"],
            "additionalProperties": False,
        },
    )


def _submit_evaluation_tool() -> dict[str, Any]:
    return function_tool(
        "submit_agent_evaluation",
        "Submit one complete criterion-by-criterion evaluation.",
        {
            "type": "object",
            "properties": {
                "terminal": {
                    "type": "boolean",
                    "description": (
                        "True only when success is true or an exact declared "
                        "stop_id is triggered. Missing evidence or unfinished "
                        "criteria require false."
                    ),
                },
                "success": {
                    "type": "boolean",
                    "description": "True exactly when every criterion status is met.",
                },
                "criterion_results": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "criterion_id": {"type": "string"},
                            "status": {
                                "type": "string",
                                "enum": ["met", "unmet", "indeterminate"],
                            },
                            "evidence_refs": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                            "reason": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": 800,
                                "description": (
                                    "Concise evidence-based reason, between 1 "
                                    "and 800 characters inclusive. Put exact "
                                    "artifact identities in evidence_refs instead "
                                    "of repeating their full contents here."
                                ),
                            },
                        },
                        "required": [
                            "criterion_id",
                            "status",
                            "evidence_refs",
                            "reason",
                        ],
                        "additionalProperties": False,
                    },
                },
                "triggered_stop_id": {
                    "type": "string",
                    "description": (
                        "Exact declared stop_id, or an empty string when no stop "
                        "criterion is triggered. Never write none, null, or n/a."
                    ),
                },
            },
            "required": [
                "terminal",
                "success",
                "criterion_results",
                "triggered_stop_id",
            ],
            "additionalProperties": False,
        },
    )
