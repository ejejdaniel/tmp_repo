from __future__ import annotations

import json
from typing import Any, Callable, Mapping, Sequence

from .._runtime_support import function_tool
from ..memory_lifecycle.prompt import bounded_projection, bounded_text
from ..model import ChatModel
from ..openai_compatible import ModelProtocolError
from ..sub_loop_toolkit import HumanInteractionPause


_INSTRUCTION = """\
Reconcile the active task contract after one research Frame has settled.

Decide only whether newly accepted authoritative information proves that the
current task specification itself is incomplete or wrong. A poor result, an
unmet success criterion, an implementation failure, or a new scientific finding
normally changes the next research plan, not the task contract.

Choose reformulate_from_sources only when one or more supplied exact source refs
contain task-defining information that must change the task goal, constraints,
evaluation priority, output boundary, or legal stopping rules. Return only the
minimal exact refs that justify reformulation. Otherwise keep the current
contract. Do not design the next Frame, choose a scientific method, score
evidence, or rewrite the task here.

If indispensable human authority is missing and human input is available, ask
one precise question instead of guessing. Return a decision only through
submit_task_contract_reconciliation.
"""


def reconcile_task_contract(
    *,
    model: ChatModel,
    events: Any,
    task_spec_ref: str,
    task_spec: Mapping[str, Any],
    global_evaluation: Mapping[str, Any],
    accepted_sources: Sequence[Mapping[str, Any]],
    allowed_source_refs: Sequence[str],
    human_input_tool: Mapping[str, Any] | None = None,
    request_human_input: Callable[[Mapping[str, Any]], None] | None = None,
) -> dict[str, Any]:
    allowed = tuple(
        dict.fromkeys(str(ref).strip() for ref in allowed_source_refs if str(ref).strip())
    )
    result_tool = _result_tool(allowed)
    tools = [result_tool]
    if human_input_tool is not None:
        tools.append(dict(human_input_tool))
    base_messages = [
        {"role": "system", "content": _INSTRUCTION},
        {
            "role": "user",
            "content": json.dumps(
                {
                    "active_task_spec_ref": str(task_spec_ref),
                    "active_task_spec": bounded_projection(
                        dict(task_spec), max_depth=6, max_items=96
                    ),
                    "current_global_evaluation": bounded_projection(
                        dict(global_evaluation), max_depth=6, max_items=96
                    ),
                    "newly_accepted_sources": [
                        bounded_projection(dict(item), max_depth=6, max_items=64)
                        for item in accepted_sources
                    ],
                },
                ensure_ascii=False,
                indent=2,
            ),
        },
    ]
    issue = ""
    previous: Mapping[str, Any] | None = None
    for attempt in range(2):
        messages = list(base_messages)
        if previous is not None:
            messages.extend(
                [
                    {
                        "role": "assistant",
                        "content": "Previous invalid decision:\n"
                        + json.dumps(previous, ensure_ascii=False),
                    },
                    {
                        "role": "user",
                        "content": (
                            "Repair only the reported contract error and call "
                            "submit_task_contract_reconciliation once: " + issue
                        ),
                    },
                ]
            )
        events.append(
            "task_contract_reconciliation_prompt_snapshot",
            {
                "attempt": attempt + 1,
                "messages": messages,
                "tool_names": [tool["function"]["name"] for tool in tools],
                "task_spec_ref": str(task_spec_ref),
                "allowed_source_refs": list(allowed),
            },
        )
        try:
            turn = model.complete(
                messages=messages,
                tools=tools,
                purpose="reconcile task contract at frame boundary",
                tool_choice="required",
            )
        except ModelProtocolError as exc:
            issue = f"model_protocol_error:{exc}"
            previous = {"content": "", "tool_calls": []}
            continue
        events.append(
            "task_contract_reconciliation_model_turn",
            {
                "attempt": attempt + 1,
                "content": turn.content,
                "tool_calls": [
                    {"name": call.name, "arguments": dict(call.arguments)}
                    for call in turn.tool_calls
                ],
                "usage": dict(turn.usage),
            },
        )
        if (
            len(turn.tool_calls) == 1
            and turn.tool_calls[0].name == "request_human_input"
        ):
            if request_human_input is None:
                raise RuntimeError(
                    "task_contract_reconciliation_human_callback_missing"
                )
            request_human_input(turn.tool_calls[0].arguments)
            raise HumanInteractionPause()
        if len(turn.tool_calls) != 1:
            issue = (
                "task_contract_reconciliation_requires_one_tool_call:"
                f"{len(turn.tool_calls)}"
            )
            previous = {
                "content": bounded_text(turn.content, 1_000),
                "tool_calls": [
                    {"name": call.name, "arguments": dict(call.arguments)}
                    for call in turn.tool_calls
                ],
            }
            continue
        call = turn.tool_calls[0]
        if call.name != "submit_task_contract_reconciliation":
            issue = f"task_contract_reconciliation_tool_invalid:{call.name}"
            previous = {"name": call.name, "arguments": dict(call.arguments)}
            continue
        try:
            result = _validated_decision(call.arguments, allowed_refs=set(allowed))
        except RuntimeError as exc:
            issue = str(exc)
            previous = dict(call.arguments)
            continue
        events.append(
            "task_contract_reconciliation_completed",
            {"task_spec_ref": str(task_spec_ref), "result": result},
        )
        return result
    raise RuntimeError(f"task_contract_reconciliation_failed:{issue}")


def _result_tool(allowed_refs: Sequence[str]) -> dict[str, Any]:
    ref_schema: dict[str, Any] = {"type": "string", "minLength": 1}
    if allowed_refs:
        ref_schema["enum"] = list(allowed_refs)
    return function_tool(
        "submit_task_contract_reconciliation",
        "Keep the active task contract or select exact sources for reformulation.",
        {
            "type": "object",
            "properties": {
                "decision": {
                    "type": "string",
                    "enum": [
                        "keep_current_contract",
                        "reformulate_from_sources",
                    ],
                },
                "source_refs": {
                    "type": "array",
                    "items": ref_schema,
                    "uniqueItems": True,
                },
                "reason": {"type": "string", "minLength": 1, "maxLength": 2_000},
            },
            "required": ["decision", "source_refs", "reason"],
            "additionalProperties": False,
        },
    )


def _validated_decision(
    value: Mapping[str, Any],
    *,
    allowed_refs: set[str],
) -> dict[str, Any]:
    if set(value) != {"decision", "source_refs", "reason"}:
        raise RuntimeError("task_contract_reconciliation_fields_invalid")
    decision = str(value.get("decision") or "").strip()
    if decision not in {
        "keep_current_contract",
        "reformulate_from_sources",
    }:
        raise RuntimeError("task_contract_reconciliation_decision_invalid")
    raw_refs = value.get("source_refs")
    if not isinstance(raw_refs, list):
        raise RuntimeError("task_contract_reconciliation_source_refs_invalid")
    refs = [str(ref).strip() for ref in raw_refs]
    if any(not ref for ref in refs) or len(refs) != len(set(refs)):
        raise RuntimeError("task_contract_reconciliation_source_refs_invalid")
    unauthorized = sorted(set(refs) - allowed_refs)
    if unauthorized:
        raise RuntimeError(
            "task_contract_reconciliation_source_ref_not_allowed:"
            + ",".join(unauthorized)
        )
    if decision == "keep_current_contract" and refs:
        raise RuntimeError("task_contract_reconciliation_keep_refs_forbidden")
    if decision == "reformulate_from_sources" and not refs:
        raise RuntimeError("task_contract_reconciliation_sources_required")
    reason = str(value.get("reason") or "").strip()
    if not reason or len(reason) > 2_000:
        raise RuntimeError("task_contract_reconciliation_reason_invalid")
    return {"decision": decision, "source_refs": refs, "reason": reason}
