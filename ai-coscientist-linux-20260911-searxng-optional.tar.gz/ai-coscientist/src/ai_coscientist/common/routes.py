from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Sequence


RouteHandler = Callable[[Mapping[str, Any]], Any]
ContextualRouteHandler = Callable[[Mapping[str, Any], str | None], Any]
RouteValidator = Callable[[Mapping[str, Any]], None]
ResultProjector = Callable[[Mapping[str, Any]], Mapping[str, Any]]


@dataclass(frozen=True)
class Route:
    name: str
    description: str
    parameters: Mapping[str, Any]
    handler: RouteHandler
    skill_ids: tuple[str, ...] = field(default_factory=tuple)
    validator: RouteValidator | None = None
    contextual_handler: ContextualRouteHandler | None = None
    lineage_refs: tuple[str, ...] = field(default_factory=tuple)
    result_projector: ResultProjector | None = None
    reference_reader: Callable[[str], bytes] | None = None

    def is_visible_to(self, skill_id: str | None) -> bool:
        return not self.skill_ids or (
            skill_id is not None and skill_id in self.skill_ids
        )

    def tool_spec(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": dict(self.parameters),
            },
        }


class RouteRegistry:
    """Project routes exposed only inside their owning selected skills."""

    def __init__(self, routes: Sequence[Route] = ()) -> None:
        self._routes: dict[str, Route] = {}
        for route in routes:
            self.register(route)

    def register(self, route: Route) -> None:
        if route.name in self._routes:
            raise ValueError(f"duplicate_route:{route.name}")
        self._routes[route.name] = route

    def all(self) -> tuple[Route, ...]:
        """Return registered routes in stable registration order."""
        return tuple(self._routes.values())

    def reference_source(self, ref: str) -> bytes:
        """Use the existing source route's scoped reader, without a new model action."""
        route = self._routes.get("source_read")
        reader = route.reference_reader if route is not None else None
        if reader is None:
            raise ValueError("source_reference_reader_unavailable")
        # The SourceExplorer reader retains its mission allowlist, hash and path policy.
        # Common citation reads need not have a source-exploration skill loaded.
        return reader(ref)

    def visible(self, skill_id: str | None) -> tuple[Route, ...]:
        return tuple(
            route
            for route in self._routes.values()
            if route.is_visible_to(skill_id)
        )

    def has(self, name: str) -> bool:
        return name in self._routes

    def result_projector(self, name: str) -> ResultProjector | None:
        route = self._routes.get(name)
        return route.result_projector if route is not None else None

    def lineage_refs(self, name: str) -> tuple[str, ...]:
        route = self._routes.get(name)
        if route is None:
            raise KeyError(f"unknown_route:{name}")
        return tuple(route.lineage_refs)

    def validate(
        self, name: str, arguments: Mapping[str, Any], *, skill_id: str | None
    ) -> None:
        route = self._routes.get(name)
        if route is None:
            raise KeyError(f"unknown_route:{name}")
        if not route.is_visible_to(skill_id):
            raise PermissionError(f"route_not_visible:{name}:{skill_id or 'none'}")
        if route.validator is not None:
            route.validator(arguments)

    def execute(
        self, name: str, arguments: Mapping[str, Any], *, skill_id: str | None
    ) -> Any:
        route = self._routes.get(name)
        self.validate(name, arguments, skill_id=skill_id)
        assert route is not None
        if route.contextual_handler is not None:
            return route.contextual_handler(arguments, skill_id)
        return route.handler(arguments)
