from __future__ import annotations

import ast
import base64
import hashlib
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from .children import MissionWorkspacePathPolicy
from .routes import Route
from .memory_lifecycle.prompt import preserve_tool_result
from .text_pages import read_text_page


_MAX_CODE_CHARS = 32_000
_MAX_COMMAND_CHARS = 32_000


class SourceExplorationError(RuntimeError):
    pass


def _reject_reserved_probe_bindings(python_code: str) -> None:
    """Protect runtime-provided names without interpreting probe semantics."""
    try:
        tree = ast.parse(python_code)
    except SyntaxError:
        return

    harmless_normalizations = {
        id(node.targets[0])
        for node in ast.walk(tree)
        if _is_harmless_source_root_normalization(node)
    }

    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Name)
            and node.id == "SOURCE_ROOT"
            and isinstance(node.ctx, (ast.Store, ast.Del))
        ):
            if id(node) in harmless_normalizations:
                continue
            raise SourceExplorationError(
                "source_probe_reserved_name_assignment:SOURCE_ROOT"
            )
        if isinstance(node, ast.arg) and node.arg == "SOURCE_ROOT":
            raise SourceExplorationError(
                "source_probe_reserved_name_assignment:SOURCE_ROOT"
            )
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if node.name == "SOURCE_ROOT":
                raise SourceExplorationError(
                    "source_probe_reserved_name_assignment:SOURCE_ROOT"
                )
        if isinstance(node, ast.alias):
            bound_name = node.asname or node.name.split(".", 1)[0]
            if bound_name == "SOURCE_ROOT":
                raise SourceExplorationError(
                    "source_probe_reserved_name_assignment:SOURCE_ROOT"
                )
        if isinstance(node, ast.ExceptHandler) and node.name == "SOURCE_ROOT":
            raise SourceExplorationError(
                "source_probe_reserved_name_assignment:SOURCE_ROOT"
            )


def _is_harmless_source_root_normalization(node: ast.AST) -> bool:
    """Allow only the common no-op `pathlib.Path(SOURCE_ROOT)` rebinding."""
    if (
        not isinstance(node, ast.Assign)
        or len(node.targets) != 1
        or not isinstance(node.targets[0], ast.Name)
        or node.targets[0].id != "SOURCE_ROOT"
        or not isinstance(node.value, ast.Call)
        or node.value.keywords
        or len(node.value.args) != 1
        or not isinstance(node.value.args[0], ast.Name)
        or node.value.args[0].id != "SOURCE_ROOT"
    ):
        return False
    function = node.value.func
    return (
        isinstance(function, ast.Attribute)
        and function.attr == "Path"
        and isinstance(function.value, ast.Name)
        and function.value.id == "pathlib"
    )


@dataclass(frozen=True)
class SourceExplorer:
    """Read-only, mission-scoped source exploration behind a selected skill."""

    source_root: Path
    workspace_root: Path
    allowed_relative_paths: tuple[str, ...]
    python_executable: str = sys.executable
    path_policy: MissionWorkspacePathPolicy | None = None

    def __post_init__(self) -> None:
        source_root = self.source_root.resolve()
        if not source_root.is_dir():
            raise SourceExplorationError(f"source_root_not_directory:{source_root}")
        workspace_root = self.workspace_root.resolve()
        workspace_root.mkdir(parents=True, exist_ok=True)
        for relative_path in self.allowed_relative_paths:
            self._resolve_allowed_root(relative_path)

    def routes(
        self,
        *,
        skill_ids: Sequence[str],
        include_workspace_terminal: bool = False,
    ) -> tuple[Route, ...]:
        owners = tuple(str(skill_id) for skill_id in skill_ids)
        if not owners:
            raise ValueError("source_exploration_skill_ids_required")
        routes = [
            Route(
                name="source_inventory",
                description=(
                    "List mission-allowed source files with stable refs, paths, "
                    "sizes, media types, and text/binary hints. Content is not read. "
                    "When an exact source-relative path is known, pass it as "
                    "relative_path instead of listing the whole source tree. "
                    "A broad result may be represented as a bounded prompt sample; "
                    "use relative_path to inspect a narrower visible directory."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "relative_path": {"type": "string"},
                        "max_entries": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 1000,
                        },
                    },
                    "additionalProperties": False,
                },
                handler=self.inventory,
                skill_ids=owners,
            ),
            Route(
                name="source_search",
                description=(
                    "Search UTF-8-compatible mission sources. Return bounded line "
                    "matches with exact source refs; binary files are reported as skipped."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "source_refs": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                        "regex": {"type": "boolean"},
                        "max_matches": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 200,
                        },
                    },
                    "required": ["query"],
                    "additionalProperties": False,
                },
                handler=self.search,
                skill_ids=owners,
            ),
            Route(
                name="source_read",
                reference_reader=self.reference_bytes,
                description=(
                    "Read one exact source, probe-output, or terminal-output ref in "
                    "bounded line pages. "
                    "Use next_line_offset to continue; unchanged refs remain authoritative."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "source_ref": {"type": "string"},
                        "line_offset": {"type": "integer", "minimum": 0},
                        "line_limit": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 2000,
                        },
                    },
                    "required": ["source_ref"],
                    "additionalProperties": False,
                },
                handler=self.read,
                skill_ids=owners,
                result_projector=preserve_tool_result,
            ),
            Route(
                name="source_probe",
                description=(
                    "Run one stateless bounded Python script against staged copies "
                    "of source or prior probe refs. Runtime prepends SOURCE_ROOT as "
                    "a pathlib.Path variable pointing at the copied-input root; it "
                    "is not an environment variable and must not be assigned or "
                    "redefined. Use SOURCE_ROOT / 'file' or "
                    "SOURCE_ROOT.rglob(...). Every call, including a retry, must "
                    "supply the complete python_code because no previous probe code "
                    "is reused. Let source-access and parsing exceptions fail the "
                    "probe; do not catch them merely to print a success-looking "
                    "result. Full code/stdout/stderr stay in C4 and are returned as "
                    "readable refs."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "purpose": {"type": "string"},
                        "source_refs": {
                            "type": "array",
                            "items": {"type": "string"},
                            "minItems": 1,
                        },
                        "python_code": {"type": "string"},
                        "timeout_seconds": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 120,
                        },
                    },
                    "required": ["purpose", "source_refs", "python_code"],
                    "additionalProperties": False,
                },
                handler=self.probe,
                skill_ids=owners,
                validator=self._validate_probe_arguments,
            ),
        ]
        if "source-observation" in owners or include_workspace_terminal:
            terminal_owners = (
                owners
                if include_workspace_terminal
                else ("source-observation",)
            )
            routes.append(
                Route(
                    name="workspace_terminal",
                    description=(
                        "Run one host-shell command from the mission source root for "
                        "repository-wide inventory, aggregation, or cross-file inspection "
                        "that bounded source routes cannot express efficiently. The route "
                        "belongs to the selected skill. Full command/stdout/stderr stay "
                        "in C4 and are returned as readable refs. "
                        f"Host shell: {_host_shell_argv('')[0]}. "
                        f"Host Python executable: {self.python_executable}. "
                        + ("Use PowerShell syntax; invoke a quoted executable path with &. "
                           if os.name == "nt" else "Use the disclosed shell's quoting syntax. ")
                        + "For host Python probes use that exact executable, not a guessed "
                        "python/python3 alias. This command runs on the host, not in a "
                        "managed scientific execution environment; its package results "
                        "apply only to the probed environment."
                    ),
                    parameters={
                        "type": "object",
                        "properties": {
                            "purpose": {"type": "string"},
                            "command": {"type": "string"},
                            "timeout_seconds": {
                                "type": "integer",
                                "minimum": 1,
                                "maximum": 120,
                            },
                        },
                        "required": ["purpose", "command", "timeout_seconds"],
                        "additionalProperties": False,
                    },
                    handler=self.terminal,
                    skill_ids=terminal_owners,
                    validator=self._validate_terminal_arguments,
                )
            )
        return tuple(routes)

    def inventory(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        max_entries = _bounded_integer(
            arguments.get("max_entries"), default=200, minimum=1, maximum=1000
        )
        requested = str(arguments.get("relative_path") or "").strip()
        roots = (
            (self._resolve_requested(requested),)
            if requested
            else self._allowed_roots()
        )
        paths = sorted(
            self._iter_files(roots),
            key=lambda path: path.relative_to(self.source_root.resolve()).as_posix(),
        )
        entries = [self._file_entry(path) for path in paths[:max_entries]]
        return {
            "status": "source_inventory_ready",
            "requested_relative_path": requested,
            "entry_count": len(entries),
            "total_file_count": len(paths),
            "truncated": len(paths) > len(entries),
            "entries": entries,
        }

    def search(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        query = str(arguments.get("query") or "")
        if not query:
            raise SourceExplorationError("source_search_query_required")
        use_regex = bool(arguments.get("regex", False))
        max_matches = _bounded_integer(
            arguments.get("max_matches"), default=80, minimum=1, maximum=200
        )
        pattern = re.compile(query) if use_regex else None
        refs = _string_list(arguments.get("source_refs"))
        if (
            not refs
            and not use_regex
            and "\n" not in query
            and self.path_policy is not None
        ):
            fast_result = self._search_with_ripgrep(
                query=query,
                max_matches=max_matches,
                roots=self._allowed_roots(),
            )
            if fast_result is not None:
                return fast_result
        paths = (
            [self._path_from_source_ref(ref) for ref in refs]
            if refs
            else list(self._iter_files(self._allowed_roots()))
        )
        matches: list[dict[str, Any]] = []
        skipped_binary: list[str] = []
        searched = 0
        for path in paths:
            if not self._text_likely(path):
                skipped_binary.append(self._source_ref(path))
                continue
            searched += 1
            with path.open("r", encoding="utf-8", errors="replace") as handle:
                for line_number, line in enumerate(handle, start=1):
                    found = bool(pattern.search(line)) if pattern else query in line
                    if not found:
                        continue
                    matches.append(
                        {
                            "source_ref": self._source_ref(path),
                            "relative_path": self._relative_path(path),
                            "line_number": line_number,
                            "line_preview": line.rstrip("\r\n")[:500],
                        }
                    )
                    if len(matches) >= max_matches:
                        return {
                            "status": "source_search_ready",
                            "query": query,
                            "regex": use_regex,
                            "searched_file_count": searched,
                            "skipped_binary_refs": skipped_binary,
                            "match_count": len(matches),
                            "truncated": True,
                            "matches": matches,
                        }
        return {
            "status": "source_search_ready",
            "query": query,
            "regex": use_regex,
            "searched_file_count": searched,
            "skipped_binary_refs": skipped_binary,
            "match_count": len(matches),
            "truncated": False,
            "matches": matches,
        }

    def _search_with_ripgrep(
        self,
        *,
        query: str,
        max_matches: int,
        roots: Sequence[Path],
    ) -> dict[str, Any] | None:
        executable = shutil.which("rg")
        if executable is None:
            return None
        source_root = self.source_root.resolve()
        relative_roots = [
            root.resolve().relative_to(source_root).as_posix() or "."
            for root in roots
        ]
        command = [
            executable,
            "--json",
            "--fixed-strings",
            "--line-number",
            "--no-heading",
            "--color",
            "never",
            "--no-ignore",
            "--hidden",
        ]
        assert self.path_policy is not None
        for glob in self.path_policy.ripgrep_exclusion_globs():
            command.extend(("--glob", glob))
        command.extend(("--", query, *relative_roots))
        try:
            process = subprocess.Popen(
                command,
                cwd=source_root,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
        except OSError:
            return None

        matches: list[dict[str, Any]] = []
        searched_file_count = 0
        truncated = False
        assert process.stdout is not None
        try:
            for raw_line in process.stdout:
                try:
                    event = json.loads(raw_line)
                except json.JSONDecodeError:
                    continue
                event_type = str(event.get("type") or "")
                data = event.get("data")
                if not isinstance(data, Mapping):
                    continue
                if event_type == "summary":
                    stats = data.get("stats")
                    if isinstance(stats, Mapping):
                        searched_file_count = int(stats.get("searches") or 0)
                    continue
                if event_type != "match":
                    continue
                path_data = data.get("path")
                line_data = data.get("lines")
                if not isinstance(path_data, Mapping) or not isinstance(
                    line_data, Mapping
                ):
                    continue
                relative_path = str(path_data.get("text") or "").replace(
                    "\\", "/"
                )
                candidate = (source_root / relative_path).resolve()
                if not candidate.is_file() or not self._is_allowed(candidate):
                    continue
                matches.append(
                    {
                        "source_ref": self._source_ref(candidate),
                        "relative_path": self._relative_path(candidate),
                        "line_number": int(data.get("line_number") or 0),
                        "line_preview": str(line_data.get("text") or "")
                        .rstrip("\r\n")[:500],
                    }
                )
                if len(matches) >= max_matches:
                    truncated = True
                    process.terminate()
                    break
        finally:
            process.stdout.close()
        if process.poll() is None:
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
        assert process.stderr is not None
        stderr = process.stderr.read()
        process.stderr.close()
        if process.returncode not in {0, 1} and not truncated:
            if stderr:
                return None
            return None
        if searched_file_count == 0 and matches:
            searched_file_count = len(
                {item["relative_path"] for item in matches}
            )
        return {
            "status": "source_search_ready",
            "query": query,
            "regex": False,
            "searched_file_count": searched_file_count,
            "skipped_binary_refs": [],
            "match_count": len(matches),
            "truncated": truncated,
            "matches": matches,
        }

    def reference_bytes(self, ref: str) -> bytes:
        path, _label = self._readable_path(ref)
        if ref.startswith("source_file:") and not (self.path_policy or MissionWorkspacePathPolicy()).allows(
            path, root=self.source_root,
        ):
            raise SourceExplorationError(f"source_reference_private_path:{ref}")
        body = path.read_bytes()
        # Recheck the body that will actually be cited, not just an earlier stat.
        if ref.startswith("source_file:") and hashlib.sha256(body).hexdigest() != ref.split(":", 2)[1]:
            raise SourceExplorationError(f"source_file_changed:{ref}")
        return body

    def read(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        source_ref = str(arguments.get("source_ref") or "").strip()
        if not source_ref:
            raise SourceExplorationError("source_read_ref_required")
        offset = _bounded_integer(
            arguments.get("line_offset"), default=0, minimum=0, maximum=10**9
        )
        limit = _bounded_integer(
            arguments.get("line_limit"), default=200, minimum=1, maximum=2000
        )
        path, label = self._readable_path(source_ref)
        if source_ref.startswith("source_file:") and not self._text_likely(path):
            return {
                "status": "source_binary_not_text",
                "source_ref": source_ref,
                "label": label,
                "size_bytes": path.stat().st_size,
                "media_type": mimetypes.guess_type(path.name)[0]
                or "application/octet-stream",
            }
        page = _read_text_page(path, offset=offset, limit=limit)
        return {
            "status": "source_page_ready",
            "source_ref": source_ref,
            "label": label,
            **page,
        }

    def _validate_probe_arguments(self, arguments: Mapping[str, Any]) -> None:
        purpose = str(arguments.get("purpose") or "").strip()
        python_code = str(arguments.get("python_code") or "")
        refs = _string_list(arguments.get("source_refs"))
        if not purpose:
            raise SourceExplorationError("source_probe_purpose_required")
        if not refs:
            raise SourceExplorationError("source_probe_refs_required")
        if not python_code.strip():
            raise SourceExplorationError("source_probe_code_required")
        if len(python_code) > _MAX_CODE_CHARS:
            raise SourceExplorationError(
                f"source_probe_code_too_large:{len(python_code)}"
            )
        _reject_reserved_probe_bindings(python_code)

    def probe(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        self._validate_probe_arguments(arguments)
        purpose = str(arguments.get("purpose") or "").strip()
        python_code = str(arguments.get("python_code") or "")
        refs = _string_list(arguments.get("source_refs"))
        timeout_seconds = _bounded_integer(
            arguments.get("timeout_seconds"),
            default=45,
            minimum=1,
            maximum=120,
        )

        source_inputs = [self._readable_path(ref) for ref in refs]
        probe_id = uuid.uuid4().hex[:16]
        probe_dir = self.workspace_root.resolve() / "source-probes" / probe_id
        inputs_dir = probe_dir / "inputs"
        inputs_dir.mkdir(parents=True, exist_ok=False)
        resolved_inputs_dir = inputs_dir.resolve()
        for source_path, relative_label in source_inputs:
            relative_target = Path(str(relative_label).replace("\\", "/"))
            target = (resolved_inputs_dir / relative_target).resolve()
            if (
                relative_target.is_absolute()
                or ".." in relative_target.parts
                or not target.is_relative_to(resolved_inputs_dir)
            ):
                raise SourceExplorationError(
                    f"source_probe_input_label_invalid:{relative_label}"
                )
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source_path, target)

        code_path = probe_dir / "probe.py"
        stdout_path = probe_dir / "stdout.txt"
        stderr_path = probe_dir / "stderr.txt"
        manifest_path = probe_dir / "manifest.json"
        code_path.write_text(
            "from pathlib import Path\n"
            "SOURCE_ROOT = Path(__file__).resolve().parent / 'inputs'\n\n"
            + python_code.rstrip()
            + "\n",
            encoding="utf-8",
        )
        env = dict(os.environ)
        env.update({"PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"})
        status = "source_probe_failed"
        return_code: int | None = None
        timed_out = False
        with (
            stdout_path.open("wb") as stdout_handle,
            stderr_path.open("wb") as stderr_handle,
        ):
            try:
                completed = subprocess.run(
                    [
                        self.python_executable,
                        "-I",
                        "-X",
                        "utf8",
                        str(code_path),
                    ],
                    cwd=inputs_dir,
                    env=env,
                    stdout=stdout_handle,
                    stderr=stderr_handle,
                    timeout=timeout_seconds,
                    check=False,
                )
                return_code = int(completed.returncode)
                status = (
                    "source_probe_succeeded"
                    if return_code == 0
                    else "source_probe_failed"
                )
            except subprocess.TimeoutExpired:
                timed_out = True
                status = "source_probe_timed_out"

        manifest = {
            "probe_id": probe_id,
            "purpose": purpose,
            "status": status,
            "return_code": return_code,
            "timed_out": timed_out,
            "timeout_seconds": timeout_seconds,
            "source_refs": refs,
            "code_sha256": _sha256(code_path),
            "stdout_sha256": _sha256(stdout_path),
            "stderr_sha256": _sha256(stderr_path),
        }
        manifest_path.write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return {
            "status": status,
            "probe_id": probe_id,
            "purpose": purpose,
            "return_code": return_code,
            "timed_out": timed_out,
            "source_refs": refs,
            "code_ref": f"source_probe:{probe_id}:code",
            "stdout_ref": f"source_probe:{probe_id}:stdout",
            "stderr_ref": f"source_probe:{probe_id}:stderr",
            "manifest_ref": f"source_probe:{probe_id}:manifest",
            "stdout_preview": _text_preview(stdout_path),
            "stderr_preview": _text_preview(stderr_path),
        }

    def _validate_terminal_arguments(self, arguments: Mapping[str, Any]) -> None:
        purpose = str(arguments.get("purpose") or "").strip()
        command = str(arguments.get("command") or "")
        if not purpose:
            raise SourceExplorationError("workspace_terminal_purpose_required")
        if not command.strip():
            raise SourceExplorationError("workspace_terminal_command_required")
        if len(command) > _MAX_COMMAND_CHARS:
            raise SourceExplorationError(
                f"workspace_terminal_command_too_large:{len(command)}"
            )

    def terminal(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        """Run one host command and persist an exact, readable execution record."""
        self._validate_terminal_arguments(arguments)
        purpose = str(arguments.get("purpose") or "").strip()
        command = str(arguments.get("command") or "")
        timeout_seconds = _bounded_integer(
            arguments.get("timeout_seconds"),
            default=45,
            minimum=1,
            maximum=120,
        )

        terminal_id = uuid.uuid4().hex[:16]
        terminal_dir = (
            self.workspace_root.resolve() / "workspace-terminals" / terminal_id
        )
        terminal_dir.mkdir(parents=True, exist_ok=False)
        command_path = terminal_dir / "command.txt"
        stdout_path = terminal_dir / "stdout.txt"
        stderr_path = terminal_dir / "stderr.txt"
        manifest_path = terminal_dir / "manifest.json"
        command_path.write_text(command.rstrip() + "\n", encoding="utf-8")

        env = dict(os.environ)
        env.update({"PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"})
        status = "workspace_terminal_failed"
        return_code: int | None = None
        timed_out = False
        with (
            stdout_path.open("wb") as stdout_handle,
            stderr_path.open("wb") as stderr_handle,
        ):
            try:
                completed = subprocess.run(
                    _host_shell_argv(command),
                    cwd=self.source_root.resolve(),
                    env=env,
                    stdout=stdout_handle,
                    stderr=stderr_handle,
                    timeout=timeout_seconds,
                    check=False,
                )
                return_code = int(completed.returncode)
                status = (
                    "workspace_terminal_succeeded"
                    if return_code == 0
                    else "workspace_terminal_failed"
                )
            except subprocess.TimeoutExpired:
                timed_out = True
                status = "workspace_terminal_timed_out"

        manifest = {
            "terminal_id": terminal_id,
            "purpose": purpose,
            "status": status,
            "return_code": return_code,
            "timed_out": timed_out,
            "timeout_seconds": timeout_seconds,
            "working_directory": str(self.source_root.resolve()),
            "command_sha256": _sha256(command_path),
            "stdout_sha256": _sha256(stdout_path),
            "stderr_sha256": _sha256(stderr_path),
        }
        manifest_path.write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return {
            "status": status,
            "terminal_id": terminal_id,
            "purpose": purpose,
            "return_code": return_code,
            "timed_out": timed_out,
            "command_ref": f"workspace_terminal:{terminal_id}:command",
            "stdout_ref": f"workspace_terminal:{terminal_id}:stdout",
            "stderr_ref": f"workspace_terminal:{terminal_id}:stderr",
            "manifest_ref": f"workspace_terminal:{terminal_id}:manifest",
            "stdout_preview": _text_preview(stdout_path),
            "stderr_preview": _text_preview(stderr_path),
        }

    def _allowed_roots(self) -> tuple[Path, ...]:
        return tuple(
            self._resolve_allowed_root(relative_path)
            for relative_path in self.allowed_relative_paths
        )

    def _resolve_allowed_root(self, relative_path: str) -> Path:
        value = str(relative_path).strip().replace("\\", "/")
        if not value:
            raise SourceExplorationError("source_allowlist_path_required")
        path = (self.source_root.resolve() / value).resolve()
        if not path.is_relative_to(self.source_root.resolve()):
            raise SourceExplorationError(f"source_path_escaped:{relative_path}")
        if not path.exists():
            raise SourceExplorationError(f"source_path_missing:{relative_path}")
        if self.path_policy is not None and not self.path_policy.allows(
            path,
            root=self.source_root,
        ):
            raise SourceExplorationError(
                f"source_path_not_mission_allowed:{relative_path}"
            )
        return path

    def _resolve_requested(self, relative_path: str) -> Path:
        value = relative_path.replace("\\", "/")
        path = (self.source_root.resolve() / value).resolve()
        if not path.is_relative_to(self.source_root.resolve()):
            raise SourceExplorationError(f"source_path_escaped:{relative_path}")
        if not path.exists() or not self._is_allowed(path):
            raise SourceExplorationError(
                f"source_path_not_mission_allowed:{relative_path}"
            )
        return path

    def _is_allowed(self, path: Path) -> bool:
        resolved = path.resolve()
        if self.path_policy is not None and not self.path_policy.allows(
            resolved,
            root=self.source_root,
        ):
            return False
        for allowed in self._allowed_roots():
            if allowed.is_dir() and resolved.is_relative_to(allowed):
                return True
            if allowed.is_file() and resolved == allowed:
                return True
        return False

    def _iter_files(self, roots: Iterable[Path]) -> Iterable[Path]:
        seen: set[Path] = set()
        source_root = self.source_root.resolve()
        for root in roots:
            if root.is_dir():
                candidates = self._walk_visible_files(root)
            else:
                candidates = (root,)
            for candidate in candidates:
                try:
                    resolved = (
                        candidate.resolve()
                        if candidate.is_symlink()
                        else candidate
                    )
                except OSError:
                    continue
                if (
                    resolved in seen
                    or not resolved.is_file()
                    or not resolved.is_relative_to(source_root)
                ):
                    continue
                seen.add(resolved)
                yield resolved

    def _walk_visible_files(self, root: Path) -> Iterable[Path]:
        source_root = self.source_root.resolve()
        for current, directory_names, file_names in os.walk(root):
            current_path = Path(current)
            directory_names[:] = [
                name
                for name in directory_names
                if self.path_policy is None
                or self.path_policy.allows_relative(
                    (current_path / name).relative_to(source_root)
                )
            ]
            for name in file_names:
                candidate = current_path / name
                if (
                    self.path_policy is not None
                    and not self.path_policy.allows_relative(
                        candidate.relative_to(source_root)
                    )
                ):
                    continue
                yield candidate

    def _file_entry(self, path: Path) -> dict[str, Any]:
        media_type = mimetypes.guess_type(path.name)[0]
        return {
            "source_ref": self._source_ref(path),
            "relative_path": self._relative_path(path),
            "size_bytes": path.stat().st_size,
            "media_type": media_type or "application/octet-stream",
            "text_likely": self._text_likely(path),
        }

    def _source_ref(self, path: Path) -> str:
        relative = self._relative_path(path)
        encoded = (
            base64.urlsafe_b64encode(relative.encode("utf-8"))
            .decode("ascii")
            .rstrip("=")
        )
        return f"source_file:{_sha256(path)}:{encoded}"

    def _path_from_source_ref(self, source_ref: str) -> Path:
        parts = str(source_ref).split(":", 2)
        if len(parts) != 3 or parts[0] != "source_file":
            raise SourceExplorationError(f"source_file_ref_invalid:{source_ref}")
        expected_digest, encoded = parts[1], parts[2]
        padding = "=" * (-len(encoded) % 4)
        try:
            relative = base64.urlsafe_b64decode(encoded + padding).decode("utf-8")
        except (ValueError, UnicodeDecodeError) as exc:
            raise SourceExplorationError(
                f"source_file_ref_invalid:{source_ref}"
            ) from exc
        path = self._resolve_requested(relative)
        if not path.is_file():
            raise SourceExplorationError(f"source_ref_not_file:{source_ref}")
        actual_digest = _sha256(path)
        if actual_digest != expected_digest:
            raise SourceExplorationError(
                f"source_file_changed:ref={source_ref}:actual_sha256={actual_digest}"
            )
        return path

    def _readable_path(self, source_ref: str) -> tuple[Path, str]:
        if source_ref.startswith("source_file:"):
            path = self._path_from_source_ref(source_ref)
            return path, self._relative_path(path)
        match = re.fullmatch(
            r"source_probe:([a-f0-9]{16}):(code|stdout|stderr|manifest)",
            source_ref,
        )
        if match is not None:
            probe_id, stream = match.groups()
            filename = {
                "code": "probe.py",
                "stdout": "stdout.txt",
                "stderr": "stderr.txt",
                "manifest": "manifest.json",
            }[stream]
            path = (
                self.workspace_root.resolve()
                / "source-probes"
                / probe_id
                / filename
            ).resolve()
            probe_root = (self.workspace_root.resolve() / "source-probes").resolve()
            if not path.is_relative_to(probe_root) or not path.is_file():
                raise SourceExplorationError(
                    f"source_probe_output_missing:{source_ref}"
                )
            return path, f"probe/{probe_id}/{filename}"

        terminal_match = re.fullmatch(
            r"workspace_terminal:([a-f0-9]{16}):(command|stdout|stderr|manifest)",
            source_ref,
        )
        if terminal_match is None:
            raise SourceExplorationError(f"source_read_ref_invalid:{source_ref}")
        terminal_id, stream = terminal_match.groups()
        filename = {
            "command": "command.txt",
            "stdout": "stdout.txt",
            "stderr": "stderr.txt",
            "manifest": "manifest.json",
        }[stream]
        terminal_root = (
            self.workspace_root.resolve() / "workspace-terminals"
        ).resolve()
        path = (terminal_root / terminal_id / filename).resolve()
        if not path.is_relative_to(terminal_root) or not path.is_file():
            raise SourceExplorationError(
                f"workspace_terminal_output_missing:{source_ref}"
            )
        return path, f"terminal/{terminal_id}/{filename}"

    def _relative_path(self, path: Path) -> str:
        return path.resolve().relative_to(self.source_root.resolve()).as_posix()

    @staticmethod
    def _text_likely(path: Path) -> bool:
        try:
            with path.open("rb") as handle:
                sample = handle.read(4096)
        except OSError:
            return False
        if b"\x00" in sample:
            return False
        try:
            sample.decode("utf-8")
        except UnicodeDecodeError:
            return False
        return True


def _read_text_page(path: Path, *, offset: int, limit: int) -> dict[str, Any]:
    page = read_text_page(path, offset=offset, limit=limit, errors="replace")
    page.pop("total_lines")
    return {**page, "truncated": page["next_line_offset"] is not None}


def _text_preview(path: Path, limit: int = 4_000) -> str:
    text = path.read_text(encoding="utf-8", errors="replace")
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n...[{len(text) - limit} chars stored behind ref]"


def _host_shell_argv(command: str) -> list[str]:
    if os.name == "nt":
        executable = shutil.which("powershell.exe") or shutil.which("pwsh")
        if executable is None:
            raise SourceExplorationError("workspace_terminal_shell_missing:powershell")
        return [
            executable,
            "-NoLogo",
            "-NoProfile",
            "-NonInteractive",
            "-Command",
            command,
        ]
    executable = os.environ.get("SHELL") or "/bin/sh"
    return [executable, "-lc", command]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _bounded_integer(value: Any, *, default: int, minimum: int, maximum: int) -> int:
    result = default if value is None else int(value)
    if result < minimum or result > maximum:
        raise ValueError(
            f"integer_out_of_range:value={result}:minimum={minimum}:maximum={maximum}"
        )
    return result


def _string_list(value: Any) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise TypeError("source_refs_must_be_array")
    refs = [str(item).strip() for item in value]
    if any(not ref for ref in refs):
        raise ValueError("source_ref_required")
    return refs
