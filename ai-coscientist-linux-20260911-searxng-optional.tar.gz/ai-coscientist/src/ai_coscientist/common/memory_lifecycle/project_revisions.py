from __future__ import annotations

from typing import Any, Callable, Mapping, Sequence


def current_project_snapshot_refs(
    visible_snapshots: Sequence[Mapping[str, Any]],
    *,
    read_stored: Callable[[str], Mapping[str, Any]],
) -> tuple[str, ...]:
    """Resolve visible revision tips through stored, same-project ancestry.

    Intermediate versions are bookkeeping inputs only. Return no new refs or
    bodies, and do not replace intentionally selected history with an unseen tip.
    """
    snapshots = {
        str(item["artifact_ref"]): item
        for item in visible_snapshots
        if item.get("artifact_kind") == "development_project_snapshot"
        and item.get("artifact_ref")
    }
    cache = dict(snapshots)
    superseded: set[str] = set()

    def read(ref: str) -> Mapping[str, Any]:
        if ref not in cache:
            cache[ref] = read_stored(ref)
        return cache[ref]

    for tip_ref, tip in snapshots.items():
        project_id = _project_id(tip)
        if not project_id:
            continue
        pending = list(_dependencies(tip))
        visited: set[str] = set()
        while pending:
            ref = pending.pop()
            if ref == tip_ref:
                raise ValueError(f"development_project_revision_cycle:{tip_ref}")
            if ref in visited:
                continue
            visited.add(ref)
            # A corrupt/missing formal dependency must not become a false tip.
            ancestor = read(ref)
            if _project_id(ancestor) != project_id:
                continue
            if ref in snapshots:
                superseded.add(ref)
            pending.extend(_dependencies(ancestor))
    return tuple(ref for ref in snapshots if ref not in superseded)


def _project_id(stored: Mapping[str, Any]) -> str:
    if stored.get("artifact_kind") != "development_project_snapshot":
        return ""
    payload = stored.get("machine_payload")
    return str(payload.get("project_id") or "") if isinstance(payload, Mapping) else ""


def _dependencies(stored: Mapping[str, Any]) -> tuple[str, ...]:
    # Formal snapshot dependencies are written by DevelopmentProjectStore,
    # not inferred from titles, receipt order, or source code.
    return tuple(
        ref for ref in stored.get("depends_on", ())
        if isinstance(ref, str) and ref.startswith("artifact:")
    )
