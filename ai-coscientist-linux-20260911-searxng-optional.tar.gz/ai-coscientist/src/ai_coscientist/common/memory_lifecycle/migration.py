from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from .state import AgentStateStore
from .work_context import exact_work_refs
from .work_store import WorkMemoryStore


def migrate_agent_v16_dialogue_memory(
    *,
    state_store: AgentStateStore,
    work_store: WorkMemoryStore,
    dialogue_id: str,
) -> bool:
    """Move the former AgentState dialogue summary into WorkMemoryStore once."""
    if not state_store.path.exists():
        return False
    try:
        state = json.loads(state_store.path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"agent_v16_dialogue_migration_state_unreadable:{exc}") from exc
    version = state.get("version") if isinstance(state, Mapping) else None
    if version == 17:
        return False
    if version != 16:
        raise ValueError(
            "agent_v16_dialogue_migration_version_invalid:"
            f"version={version}"
        )
    try:
        old_summary = state["c3"]["dialogue_summary"]
        old_cursor = state["c1"]["dialogue_summary_through_count"]
    except (KeyError, TypeError) as exc:
        raise ValueError("agent_v16_dialogue_fields_missing") from exc
    if not isinstance(old_summary, str):
        raise ValueError("agent_v16_dialogue_summary_invalid")
    if (
        isinstance(old_cursor, bool)
        or not isinstance(old_cursor, int)
        or old_cursor < 0
    ):
        raise ValueError("agent_v16_dialogue_cursor_invalid")
    existing = work_store.dialogue_memory(dialogue_id)
    existing_pair = (
        str(existing["summary_markdown"]),
        int(existing["through_message_count"]),
    )
    old_pair = (old_summary, old_cursor)
    if existing_pair != ("", 0) and existing_pair != old_pair:
        raise ValueError(
            "agent_v16_dialogue_memory_conflict:"
            f"dialogue_id={dialogue_id}"
        )
    if existing_pair == ("", 0) and old_pair != ("", 0):
        work_store.commit_dialogue_memory(
            dialogue_id,
            summary_markdown=old_summary,
            through_message_count=old_cursor,
        )
    migrated = copy.deepcopy(state)
    migrated["version"] = 17
    del migrated["c3"]["dialogue_summary"]
    del migrated["c1"]["dialogue_summary_through_count"]
    state_store._write(migrated)
    return True


def migrate_agent_v15(
    *, source_state: Path, source_events: Path, target_state: Path,
    work_store: WorkMemoryStore, agent_id: str,
) -> dict[str, Any]:
    """Explicit offline conversion; never called as a fallback by runtime reads."""
    if source_state.resolve() == target_state.resolve() or target_state.exists():
        raise ValueError("work_migration_requires_new_target_state")
    state = json.loads(source_state.read_text(encoding="utf-8"))
    if state.get("version") != 15:
        raise ValueError("work_migration_requires_state_v15")
    events = [json.loads(line) for line in source_events.read_text(encoding="utf-8").splitlines() if line.strip()]
    revision, node_id = 0, "bootstrap"
    graph: Mapping[str, Any] = {}
    calls: dict[str, Mapping[str, Any]] = {}
    prompt_refs: tuple[str, ...] | None = None
    records: list[tuple[tuple[int, str], str, str, Mapping[str, Any], Sequence[str]]] = []
    titles: dict[tuple[int, str], str] = {(0, "bootstrap"): state["c0"]["objective"]}
    for event in events:
        event_type = event.get("event_type")
        if event_type == "prompt_snapshot":
            visible_refs: list[str] = []
            for message in event.get("messages", ()):
                # Only exact structured references from the saved visible
                # prompt; never scan narrative text or hidden reasoning.
                content = message.get("content")
                if isinstance(content, str):
                    try:
                        content = json.loads(content)
                    except json.JSONDecodeError:
                        continue
                visible_refs.extend(exact_work_refs(content))
            prompt_refs = tuple(dict.fromkeys(visible_refs))
        candidate = event.get("plan_graph")
        if isinstance(candidate, Mapping) and "revision" in candidate and "nodes" in candidate:
            graph = candidate
            revision = int(graph["revision"])
            active = [node for node in graph["nodes"] if node.get("status") == "in_progress"]
            if len(active) > 1:
                raise ValueError(f"work_migration_ambiguous_active_node:event={event['event_sequence']}")
            node_id = str(active[0]["node_id"]) if active else "graph-control"
        if event_type in {"node_execution_mode_selected", "node_loop_attempt_started"}:
            node_id = str(event["node_id"])
        key = (revision, node_id)
        title = next((str(node["outcome"]) for node in graph.get("nodes", ())
                      if node["node_id"] == node_id), node_id)
        titles.setdefault(key, title)
        sequence = int(event["event_sequence"])
        if event_type == "model_turn":
            for call in event.get("tool_calls") or ():
                calls[str(call["call_id"])] = call["arguments"]
            content = str(event.get("content") or "")
            if content.strip():
                if prompt_refs is None:
                    raise ValueError(f"work_migration_note_missing_prompt:event={sequence}")
                records.append((key, f"{agent_id}:{sequence}:note", "note", {"markdown": content}, prompt_refs))
        elif event_type == "tool_result":
            arguments = event.get("executed_arguments")
            if not isinstance(arguments, Mapping):
                arguments = calls.get(str(event.get("call_id") or ""))
            result = event.get("raw_result")
            if not isinstance(arguments, Mapping) or not isinstance(result, Mapping):
                raise ValueError(f"work_migration_missing_exact_operation:event={sequence}")
            records.append((key, f"{agent_id}:{sequence}:tool", "tool_result", {
                "call_id": str(event["call_id"]), "tool_name": str(event["tool"]),
                "executed_arguments": dict(arguments), "result": dict(result),
            }, tuple(dict.fromkeys((
                *exact_work_refs(result),
                *(ref for ref in exact_work_refs(arguments)
                  if result.get("status") != "tool_error" or ref in (prompt_refs or ())),
            )))))
    active_nodes = [node for node in state["c1"]["plan_graph"]["nodes"] if node["status"] == "in_progress"]
    active_key = (int(state["c1"]["plan_graph"]["revision"]),
                  str(active_nodes[0]["node_id"]) if active_nodes else "graph-control")
    titles.setdefault(active_key, str(active_nodes[0]["outcome"]) if active_nodes else "Graph control")
    contexts = {key: work_store.create_context(owner_agent_id=agent_id, title=title)
                for key, title in titles.items()}
    for key, event_id, kind, payload, refs in records:
        work_store.append(contexts[key], agent_id=agent_id, source_event_id=event_id,
                          entry_kind=kind, payload=payload, source_refs=refs)
    old_summary = str(state["c3"]["wiki_summary"])
    if old_summary.strip():
        work_store.append(contexts[active_key], agent_id=agent_id,
                          source_event_id=f"{agent_id}:migration-v15:summary",
                          entry_kind="note", payload={"markdown": (
                              "Legacy v15 C3 summary (unverified, copied without reconstruction):\n" + old_summary
                          )}, source_refs=state["c1"]["resolved_artifact_refs"])
    migrated = copy.deepcopy(state)
    migrated["version"] = 17
    del migrated["c3"]["wiki_summary"]
    del migrated["c1"]["wiki_summary_through_sequence"]
    migrated["c1"]["active_work_context_ref"] = contexts[active_key]
    AgentStateStore(target_state)._write(migrated)
    return {"source_state": str(source_state), "target_state": str(target_state),
            "agent_id": agent_id, "contexts": len(contexts), "entries": len(records),
            "active_work_context_ref": contexts[active_key], "legacy_summary_imported": bool(old_summary.strip())}
