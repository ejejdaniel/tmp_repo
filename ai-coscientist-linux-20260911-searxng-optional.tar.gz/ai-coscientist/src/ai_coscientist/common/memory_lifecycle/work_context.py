from __future__ import annotations

import hashlib
import json
from typing import Any, Callable, Mapping, Sequence

from .state import AgentStateStore
from .work_store import WorkMemoryError, WorkMemoryStore


_REF_PREFIXES = (
    "artifact:", "code_artifact:", "execution_observation:", "development_output:",
    "materializer_execution_workspace:", "source_file:", "source_probe:",
    "workspace_terminal:", "work_entry:",
)


def exact_work_refs(value: Any) -> tuple[str, ...]:
    """Collect transport identities, never search prose for scientific meaning."""
    found: list[str] = []

    def visit(item: Any) -> None:
        if isinstance(item, str):
            if item.startswith(_REF_PREFIXES) and not any(c.isspace() for c in item):
                found.append(item)
        elif isinstance(item, Mapping):
            for child in item.values():
                visit(child)
        elif isinstance(item, (list, tuple)):
            for child in item:
                visit(child)

    visit(value)
    return tuple(dict.fromkeys(found))


class WorkContext:
    """One agent's owned work selection and source-filtered memory view."""

    def __init__(
        self, store: WorkMemoryStore, state: AgentStateStore, agent_id: str,
        *, source_visible: Callable[[str], bool] | None = None,
        view_policy: Callable[[], Mapping[str, Any]] | None = None,
    ) -> None:
        self.store, self.state, self.agent_id = store, state, agent_id
        self.source_visible = source_visible or (lambda ref: True)
        self.view_policy = view_policy or (lambda: {})
        self.consumer = "main-agent"

    def ensure(self, *, title: str | None = None, input_refs: Sequence[str] = ()) -> str:
        persisted = self.state.read()
        ref = persisted["c1"]["active_work_context_ref"]
        if ref:
            self.store.context(ref, agent_id=self.agent_id)
            return str(ref)
        ref = self.store.create_context(
            owner_agent_id=self.agent_id,
            title=title or persisted["c0"]["objective"] or "Bootstrap",
            input_refs=input_refs,
        )
        self.state.bind_work_context(ref)
        return ref

    def select(self, ref: str) -> None:
        self.store.context(ref, agent_id=self.agent_id)
        self.state.bind_work_context(ref)

    def allows(self, refs: Sequence[str], _seen: set[str] | None = None) -> bool:
        seen = set() if _seen is None else _seen
        for ref in refs:
            if ref in seen:
                continue
            seen.add(ref)
            if ref.startswith("work_entry:"):
                try:
                    entry = self.store.read_entry(ref, agent_id=self.agent_id)
                except WorkMemoryError:
                    return False
                if not self.allows(entry["source_refs"], seen):
                    return False
            elif not self.source_visible(ref):
                return False
        return True

    @property
    def view_key(self) -> str:
        encoded = json.dumps(
            {"agent": self.agent_id, "consumer": self.consumer, "policy": self.view_policy()},
            sort_keys=True, separators=(",", ":"), ensure_ascii=False,
        ).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()

    def checkpoint(self) -> dict[str, Any]:
        ref = self.state.read()["c1"]["active_work_context_ref"]
        if not ref:
            return {"context_ref": None, "view_key": self.view_key,
                    "through_sequence": 0, "markdown": "", "source_refs": []}
        checkpoint = self.store.summary(
            ref, agent_id=self.agent_id, view_key=self.view_key,
        )
        if not self.allows(checkpoint["source_refs"]):
            # The policy callback must fingerprint changed grants; never show a
            # stale summary if a source was independently revoked or removed.
            return {**checkpoint, "through_sequence": 0, "markdown": "", "source_refs": []}
        return checkpoint

    def entries(self, *, after_sequence: int = 0) -> list[tuple[int, dict[str, Any]]]:
        ref = self.state.read()["c1"]["active_work_context_ref"]
        if not ref:
            return []
        return self.store.materialized_entries(
            ref, agent_id=self.agent_id, after_sequence=after_sequence,
            allow_sources=self.allows,
        )

    def record_note(self, markdown: str, *, event_id: str, source_refs: Sequence[str] = ()) -> None:
        if markdown.strip():
            self.store.append(
                self.ensure(), agent_id=self.agent_id, source_event_id=event_id,
                entry_kind="note", payload={"markdown": markdown}, source_refs=source_refs,
            )

    def latest_skill_note(self, skill_id: str) -> str:
        suffix = f":workflow-note:{skill_id}"
        notes = (entry for _, entry in self.entries()
                 if entry["entry_kind"] == "note" and entry["source_event_id"].endswith(suffix))
        latest = max(notes, key=lambda entry: entry["sequence"], default=None)
        return latest["payload"]["markdown"] if latest else ""

    def record_tool(
        self, *, event_id: str, call_id: str, tool_name: str,
        arguments: Mapping[str, Any], result: Mapping[str, Any],
        context_ref: str | None = None, source_refs: Sequence[str] = (),
    ) -> dict[str, Any]:
        return self.store.append(
            context_ref or self.ensure(), agent_id=self.agent_id, source_event_id=event_id,
            entry_kind="tool_result",
            payload={"call_id": call_id, "tool_name": tool_name,
                     "executed_arguments": dict(arguments), "result": dict(result)},
            source_refs=tuple(dict.fromkeys((*source_refs, *exact_work_refs(result), *(ref for ref in
                exact_work_refs(arguments)
                if self.allows((ref,)))))),
        )

    def list(self, **arguments: Any) -> dict[str, Any]:
        return self.store.list(agent_id=self.agent_id, allow_sources=self.allows, **arguments)

    def read(self, ref: str, *, line_offset: int = 0, line_limit: int = 200) -> dict[str, Any]:
        if line_offset < 0 or not 1 <= line_limit <= 2000:
            raise WorkMemoryError("work_memory_read_page_invalid")
        if ref.startswith("work_context:"):
            context = self.store.context(ref, agent_id=self.agent_id)
            if not self.allows(context["input_refs"]):
                raise WorkMemoryError(f"work_context_sources_not_visible:{ref}")
            return self.store.list(
                agent_id=self.agent_id, context_ref=ref, cursor=line_offset,
                limit=min(line_limit, 20), allow_sources=self.allows,
            )
        entry = self.store.read_entry(ref, agent_id=self.agent_id)
        if not self.allows(entry["source_refs"]):
            raise WorkMemoryError(f"work_entry_sources_not_visible:{ref}")
        lines = json.dumps(entry, ensure_ascii=False, indent=2).splitlines()
        end = min(len(lines), line_offset + line_limit)
        return {"ref": ref, "content": "\n".join(lines[line_offset:end]),
                "line_offset": line_offset, "total_lines": len(lines),
                "next_line_offset": end if end < len(lines) else None}
