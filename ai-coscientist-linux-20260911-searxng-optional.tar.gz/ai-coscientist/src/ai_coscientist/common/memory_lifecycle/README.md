# Common Memory Lifecycle

This directory is the single implementation home for common-agent C0-C6
storage lifecycle, metabolism, prompt projection policy, and audit receipts.

- `state.py`: persisted C0 and C1 control-state boundaries.
- `engine.py`: pre-model lifecycle checks, C3 compaction, and C5 stage memory.
- `work_store.py`: persistent C3 work and dialogue-navigation checkpoints.
- `dialogue_memory.py`: shared C3 navigation over exact append-only C4 dialogue.
- `policy.py`: active C2 revision projection, bounded catalog pages, and
  prompt-budget receipts.
- `prompt.py`: bounded prompt projections; it does not own stored content.
- `events.py`: append-only C6 audit storage.

C1 receipt metabolism keeps a bounded recent window while retaining the latest
active C4 source-probe producer/readback ref chain. The C4 bodies remain the
authority; C1 retains only the current control pointers needed to continue the
selected skill.

C2 storage and C2 prompt visibility are deliberately different. The runtime
renders a bounded, priority-aware catalog window and exposes filtered cursor
pages for discovery. Omitted receipts remain stored and readable by exact ref.
Resolved C2/C4 bodies receive a shared detail budget; only the focused input
and current transition evidence are mandatory details, while other inputs
degrade to reference projections.

Every normal runtime call is measured after messages and tools are assembled.
An over-budget normal projection is rebuilt once as a minimal projection. The
minimal form shrinks the catalog, removes C3 from that call, and keeps
non-focused stored inputs as refs. If it is still over budget, the call fails
explicitly and both budget receipts remain in C6.

Callers may choose which authoritative inputs a prompt needs. They must not
reimplement revision selection, compaction, prompt budgeting, C5 cleanup, or C6
replay outside this directory. C2 and C4 bodies remain in their dedicated
stores; this directory owns only their lifecycle and prompt visibility policy.
