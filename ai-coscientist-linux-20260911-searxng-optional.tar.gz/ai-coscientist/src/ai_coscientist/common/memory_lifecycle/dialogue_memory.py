from __future__ import annotations

import json
from typing import Any, Mapping, Sequence

from ..dialogue import DialogueStore
from ..model import ChatModel
from ..routes import Route
from .events import EventLog
from .work_store import WorkMemoryStore


RECENT_DIALOGUE_BUDGET_BYTES = 24_000
_DIALOGUE_SUMMARY_LIMIT_CHARS = 8_000
_DIALOGUE_SUMMARY_TARGET_CHARS = 6_000
_DIALOGUE_MIN_OUTPUT_TOKENS = 64

_DIALOGUE_DELTA_INSTRUCTION = """\
Extract only durable changes from the exact completed chat messages: explicit
user instructions, scientific inputs, decisions, confirmed constraints,
rescinded or superseded decisions, unresolved questions, and exact refs. For
every retained user statement, preserve its exact message_id so the original
C4 message can be found and read later. Ignore pleasantries and transient run
narration. Return concise Markdown. Do not invent facts.
"""

_DIALOGUE_CURATION_INSTRUCTION = """\
Update the durable conversation navigation summary from the previous summary
and semantic delta. Preserve user authority, current decisions, unresolved
questions, exact refs, and the exact message_id for every retained user
statement. Mark superseded decisions as superseded rather than treating them as
current. Remove repetition while retaining the latest decision. This summary is
navigation, not task authority or scientific evidence. Return concise Markdown
only. Do not invent facts.
"""


def _next_output_budget(*, current_tokens: int, actual_chars: int) -> int:
    if current_tokens <= _DIALOGUE_MIN_OUTPUT_TOKENS:
        return current_tokens
    ratio = _DIALOGUE_SUMMARY_LIMIT_CHARS / max(actual_chars, 1)
    scaled = int(current_tokens * ratio * 0.8)
    return max(
        _DIALOGUE_MIN_OUTPUT_TOKENS,
        min(current_tokens - 1, scaled),
    )


class DialogueMemory:
    """Shared C3 navigation over exact append-only C4 dialogue."""

    def __init__(
        self,
        *,
        dialogue_id: str,
        dialogue: DialogueStore,
        work_store: WorkMemoryStore,
        model: ChatModel,
        events: EventLog,
    ) -> None:
        normalized = str(dialogue_id).strip()
        if not normalized:
            raise ValueError("dialogue_memory_id_required")
        self.dialogue_id = normalized
        self.dialogue = dialogue
        self.work_store = work_store
        self._model = model
        self._events = events

    def checkpoint(self) -> dict[str, Any]:
        return self.work_store.dialogue_memory(self.dialogue_id)

    def summary(self) -> str:
        return str(self.checkpoint()["summary_markdown"])

    def recent(
        self,
        *,
        max_bytes: int = RECENT_DIALOGUE_BUDGET_BYTES,
    ) -> tuple[dict[str, Any], ...]:
        return self.dialogue.recent(max_bytes=max_bytes)

    def search(
        self,
        *,
        query: str,
        role: str = "any",
        cursor: int = 0,
        limit: int = 8,
    ) -> dict[str, Any]:
        """Mechanically locate exact dialogue messages; no semantic inference."""
        needle = str(query).strip().casefold()
        normalized_role = str(role).strip()
        if not needle:
            raise ValueError("dialogue_search_query_required")
        if normalized_role not in {"any", "user", "assistant"}:
            raise ValueError("dialogue_search_role_invalid")
        if isinstance(cursor, bool) or not isinstance(cursor, int) or cursor < 0:
            raise ValueError("dialogue_search_cursor_invalid")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 20:
            raise ValueError("dialogue_search_limit_invalid")
        matches = [
            message
            for message in self.dialogue.read()
            if (normalized_role == "any" or message["role"] == normalized_role)
            and needle in str(message["content"]).casefold()
        ]
        page = matches[cursor : cursor + limit]
        return {
            "status": "dialogue_search_completed",
            "query": str(query).strip(),
            "role": normalized_role,
            "items": [
                {
                    "message_id": str(message["message_id"]),
                    "turn_id": str(message["turn_id"]),
                    "role": str(message["role"]),
                    "preview": str(message["content"])[:500],
                }
                for message in page
            ],
            "total": len(matches),
            "next_cursor": (
                cursor + limit if cursor + limit < len(matches) else None
            ),
        }

    def read_message(self, message_id: str) -> dict[str, Any]:
        message = self.dialogue.get(str(message_id))
        return {
            "status": "dialogue_message_read",
            "message": message,
        }

    def routes(self, *, skill_ids: Sequence[str]) -> tuple[Route, ...]:
        visible_to = tuple(str(skill_id) for skill_id in skill_ids)
        return (
            Route(
                name="dialogue_search",
                description=(
                    "Mechanically search the exact dialogue transcript. The "
                    "result is a locator; call dialogue_read before selecting "
                    "an old message as task-formulation context."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "minLength": 1},
                        "role": {
                            "type": "string",
                            "enum": ["any", "user", "assistant"],
                        },
                        "cursor": {"type": "integer", "minimum": 0},
                        "limit": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 20,
                        },
                    },
                    "required": ["query", "role", "cursor", "limit"],
                    "additionalProperties": False,
                },
                handler=lambda arguments: self.search(
                    query=str(arguments["query"]),
                    role=str(arguments["role"]),
                    cursor=int(arguments["cursor"]),
                    limit=int(arguments["limit"]),
                ),
                skill_ids=visible_to,
            ),
            Route(
                name="dialogue_read",
                description=(
                    "Read one exact C4 dialogue message by message_id before "
                    "using it as task-formulation authority or context."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "message_id": {"type": "string", "minLength": 1},
                    },
                    "required": ["message_id"],
                    "additionalProperties": False,
                },
                handler=lambda arguments: self.read_message(
                    str(arguments["message_id"])
                ),
                skill_ids=visible_to,
            ),
        )

    def maybe_compact(self, *, turn_id: str) -> None:
        messages = self.dialogue.read()
        checkpoint = self.checkpoint()
        previous = str(checkpoint["summary_markdown"])
        through_count = int(checkpoint["through_message_count"])
        if through_count > len(messages):
            raise RuntimeError("dialogue_summary_cursor_beyond_transcript")
        recent_count = len(self.recent())
        if not previous and through_count == 0 and recent_count == len(messages):
            return
        exact_messages = list(messages[through_count:])
        if not exact_messages:
            return
        delta = self._compaction_call(
            purpose="extract dialogue semantic delta",
            instruction=_DIALOGUE_DELTA_INSTRUCTION,
            payload={"completed_dialogue": exact_messages},
        )
        summary = self._compaction_call(
            purpose="curate durable dialogue summary",
            instruction=_DIALOGUE_CURATION_INSTRUCTION,
            payload={"previous_summary": previous, "semantic_delta": delta},
        )
        self.work_store.commit_dialogue_memory(
            self.dialogue_id,
            summary_markdown=summary,
            through_message_count=len(messages),
        )
        transcript_bytes = len(
            json.dumps(messages, ensure_ascii=False, default=str).encode("utf-8")
        )
        self._events.append(
            "dialogue_summary_updated",
            {
                "turn_id": str(turn_id),
                "dialogue_id": self.dialogue_id,
                "transcript_bytes": transcript_bytes,
                "summary_chars": len(summary),
                "from_message_count": through_count,
                "through_message_count": len(messages),
            },
        )

    def _compaction_call(
        self,
        *,
        purpose: str,
        instruction: str,
        payload: Mapping[str, Any],
    ) -> str:
        messages = [
            {"role": "system", "content": instruction},
            {
                "role": "user",
                "content": json.dumps(payload, ensure_ascii=False, default=str),
            },
        ]
        self._events.append(
            "dialogue_compaction_prompt",
            {"purpose": purpose, "messages": messages},
        )
        turn = self._model.complete(
            messages=messages,
            tools=(),
            purpose=purpose,
            max_output_tokens=_DIALOGUE_SUMMARY_TARGET_CHARS,
        )
        result = str(turn.content).strip()
        self._events.append(
            "dialogue_compaction_model_turn",
            {
                "purpose": purpose,
                "content": turn.content,
                "usage": dict(turn.usage),
            },
        )
        if not result:
            raise RuntimeError("dialogue_compaction_empty_output")
        output_tokens = _DIALOGUE_SUMMARY_TARGET_CHARS
        while len(result) > _DIALOGUE_SUMMARY_LIMIT_CHARS:
            next_tokens = _next_output_budget(
                current_tokens=output_tokens,
                actual_chars=len(result),
            )
            if next_tokens >= output_tokens:
                raise RuntimeError("dialogue_reduction_budget_did_not_decrease")
            instruction = (
                "Semantically reduce the supplied durable dialogue navigation "
                f"summary to at most {_DIALOGUE_SUMMARY_TARGET_CHARS:,} "
                "characters. Preserve user authority, current and superseded "
                "decisions, unresolved questions, exact refs, and message_ids. "
                "Return ordinary Markdown without inventing facts."
            )
            messages = [
                {"role": "system", "content": instruction},
                {"role": "user", "content": result},
            ]
            self._events.append(
                "dialogue_compaction_prompt",
                {
                    "purpose": "reduce oversized dialogue summary",
                    "messages": messages,
                },
            )
            turn = self._model.complete(
                messages=messages,
                tools=(),
                purpose="semantically reduce oversized dialogue summary",
                max_output_tokens=next_tokens,
            )
            result = str(turn.content).strip()
            self._events.append(
                "dialogue_compaction_model_turn",
                {
                    "purpose": "reduce oversized dialogue summary",
                    "content": turn.content,
                    "usage": dict(turn.usage),
                },
            )
            if not result:
                raise RuntimeError("dialogue_compaction_empty_output")
            output_tokens = next_tokens
            if (
                len(result) > _DIALOGUE_SUMMARY_LIMIT_CHARS
                and output_tokens <= _DIALOGUE_MIN_OUTPUT_TOKENS
            ):
                raise RuntimeError(
                    "model_output_limit_not_honored_during_dialogue_reduction"
                )
        return result
