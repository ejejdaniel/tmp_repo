from __future__ import annotations

from typing import Any, Callable, Mapping, Sequence

from .prompt import tool_receipt_projection
from .work_context import WorkContext, exact_work_refs


def resolve_work_context(
    work: WorkContext, *, explicit_refs: Sequence[str],
    read_ref: Callable[[str], Mapping[str, Any]], projects: Any = None,
) -> dict[str, Any]:
    """One version-resolution path for planning, execution, and child recovery.

    Original entry order, immutable snapshots, and mutable project receipts are
    separate identities. An import position never makes an old run newer.
    """
    entries = sorted((entry for _, entry in work.entries()), key=lambda e: e["sequence"])
    refs = list(explicit_refs)
    project_ids: list[str] = []
    tool_receipts: list[dict[str, Any]] = []
    for entry in entries:
        if entry["entry_kind"] != "tool_result":
            continue
        payload = entry["payload"]
        result, arguments = payload["result"], payload["executed_arguments"]
        refs.extend(exact_work_refs(result))
        refs.extend(exact_work_refs(arguments))
        if payload["tool_name"].startswith("development_project_"):
            project_id = str(result.get("project_id") or arguments.get("project_id") or "")
            if project_id:
                project_ids.append(project_id)
        tool_receipts.append({"tool": payload["tool_name"], "call_id": payload["call_id"],
                              "result": tool_receipt_projection(result, has_owned_presentation=True)})

    # Keep prompt work bounded while all records remain searchable. Explicit
    # current inputs survive the window, regardless of their historical age.
    visible_refs = list(dict.fromkeys(reversed(refs)))[:24]
    visible_refs.reverse()
    visible_refs = list(dict.fromkeys((*visible_refs, *explicit_refs)))
    stored: dict[str, Mapping[str, Any]] = {}
    snapshots: dict[str, list[str]] = {}
    unresolved: list[str] = []
    for ref in visible_refs:
        if not ref.startswith(("artifact:", "execution_observation:", "code_artifact:")):
            continue
        if not work.allows((ref,)):
            continue
        try:
            item = read_ref(ref)
        except (KeyError, OSError, PermissionError, ValueError):
            unresolved.append(ref)
            continue
        stored[ref] = item
        if item.get("artifact_kind") == "development_project_snapshot":
            project_id = str((item.get("machine_payload") or {}).get("project_id") or "")
            if project_id:
                project_ids.append(project_id)
                snapshots.setdefault(project_id, []).append(ref)

    project_receipts: list[dict[str, Any]] = []
    if projects is not None:
        current_project_ids = list(dict.fromkeys(reversed(project_ids)))[:8]
        for project_id in reversed(current_project_ids):
            try:
                receipt = projects.project_receipt(project_id)
            except (KeyError, OSError, RuntimeError, ValueError):
                continue
            # A shared mutable project does not grant a new formal snapshot.
            # Keep the historical receipt visible until its new refs are allowed.
            if not work.allows(exact_work_refs(receipt)):
                continue
            project_receipts.append(dict(receipt))
            tool_receipts.append({"tool": "development_project_open", "result": receipt})
            for ref in snapshots.get(project_id, ())[-2:]:
                try:
                    difference = projects.diff(project_id, ref, max_chars=1000)
                except (KeyError, OSError, RuntimeError, ValueError):
                    continue
                tool_receipts.append({"tool": "development_project_diff", "result": difference})

    return {
        "work_context_ref": work.state.read()["c1"]["active_work_context_ref"],
        "summary": work.checkpoint()["markdown"],
        "work_entry_refs": [entry["entry_ref"] for entry in entries[-20:]],
        "project_receipts": project_receipts,
        "tool_receipts": tool_receipts[-12:],
        "operational_refs": [ref for ref in stored if ref.startswith("execution_observation:")],
        "snapshot_refs": list(dict.fromkeys(ref for refs in snapshots.values() for ref in refs)),
        "unresolved_refs": unresolved,
    }
