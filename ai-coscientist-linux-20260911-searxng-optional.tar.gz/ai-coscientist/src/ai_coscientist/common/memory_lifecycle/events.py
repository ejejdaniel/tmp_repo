from __future__ import annotations

import copy
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Mapping


class EventLog:
    """Append-only raw diagnostic log; never a semantic workflow source."""

    def __init__(self, path: Path) -> None:
        self.path = path.resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._sequence = 0
        self._sequence_floor = 0
        self._events: list[dict[str, Any]] = []
        self._file_signature: tuple[int, int] | None = None
        self._reload()

    def append(self, event_type: str, payload: Mapping[str, Any]) -> int:
        if self._current_file_signature() != self._file_signature:
            self._reload()
        self._sequence += 1
        event = {
            "event_sequence": self._sequence,
            "timestamp": datetime.now(UTC).isoformat(),
            "event_type": event_type,
            **dict(payload),
        }
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(event, ensure_ascii=False) + "\n")
        self._events.append(event)
        self._file_signature = self._current_file_signature()
        return self._sequence

    def read(self) -> list[Mapping[str, Any]]:
        if self._current_file_signature() != self._file_signature:
            self._reload()
        return copy.deepcopy(self._events)

    def continue_after(self, sequence: int) -> None:
        self._sequence_floor = max(self._sequence_floor, sequence)
        self._sequence = max(self._sequence, self._sequence_floor)

    def _reload(self) -> None:
        self._sequence = self._sequence_floor
        events: list[Mapping[str, Any]] = []
        if self.path.exists():
            with self.path.open("r", encoding="utf-8") as stream:
                for line_number, line in enumerate(stream, start=1):
                    if not line.strip():
                        continue
                    self._sequence = max(self._sequence, line_number)
                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if isinstance(event, Mapping):
                        self._sequence = max(self._sequence, int(event.get("event_sequence") or 0))
                        events.append(dict(event))
        self._events = [dict(event) for event in events]
        self._file_signature = self._current_file_signature()

    def _current_file_signature(self) -> tuple[int, int] | None:
        if not self.path.exists():
            return None
        stat = self.path.stat()
        return stat.st_size, stat.st_mtime_ns
