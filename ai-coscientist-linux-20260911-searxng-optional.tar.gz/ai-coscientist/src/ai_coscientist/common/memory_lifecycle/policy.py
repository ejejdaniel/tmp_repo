from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence


ArtifactReader = Callable[[str], Mapping[str, Any]]


def related_observation_refs(
    candidates: Sequence[str], *, input_refs: Sequence[str], read: ArtifactReader,
    identity: Callable[[Mapping[str, Any]], tuple[str, tuple[str, ...]] | None],
) -> tuple[str, ...]:
    """Carry only observations whose exact parents belong to selected inputs."""
    available = set(input_refs)
    selected: list[str] = []
    while True:
        added = []
        for ref in candidates:
            if ref in available:
                continue
            key = identity(read(ref))
            if key is not None and key[1] and set(key[1]).issubset(available):
                added.append(ref)
        if not added:
            return tuple(selected)
        selected.extend(added)
        available.update(added)


def current_observation_refs(
    ordered_refs: Sequence[str],
    *,
    read: ArtifactReader,
    identity: Callable[[Mapping[str, Any]], tuple[str, tuple[str, ...]] | None],
    creation_order: Callable[[Sequence[str]], Sequence[str]],
) -> tuple[str, ...]:
    """Select operational state by creation order; retire dependent inspections."""
    related = set(ordered_refs)
    pending = list(ordered_refs)
    while pending:
        key = identity(read(pending.pop()))
        for ref in key[1] if key is not None else ():
            if ref.startswith("execution_observation:") and ref not in related:
                related.add(ref)
                pending.append(ref)
    ordered_refs = creation_order(tuple(related))
    latest: dict[tuple[str, tuple[str, ...]], str] = {}
    identities = {}
    for ref in ordered_refs:
        key = identity(read(ref))
        identities[ref] = key
        if key is not None:
            latest[key] = ref
    retired = {
        ref for ref, key in identities.items()
        if key is not None and latest[key] != ref
    }
    # An inspection of a superseded execution is not current operational state.
    while True:
        dependents = {
            ref for ref, key in identities.items()
            if key is not None and set(key[1]).intersection(retired)
        } - retired
        if not dependents:
            break
        retired.update(dependents)
    return tuple(ref for ref in ordered_refs if ref not in retired)


@dataclass(frozen=True)
class PromptSource:
    """One authoritative input projected into a single model call."""

    memory_class: str
    name: str
    value: Any


class PromptBudgetExceeded(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        receipt: Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.receipt = dict(receipt or {})


DEFAULT_ARTIFACT_CATALOG_BUDGET_BYTES = 24_000
MINIMAL_ARTIFACT_CATALOG_BUDGET_BYTES = 8_000
ARTIFACT_CATALOG_PAGE_LIMIT = 8

_ARTIFACT_SUMMARY_LIMIT = 600
_ARTIFACT_DEPENDENCY_LIMIT = 8
_ARTIFACT_KIND_COUNT_LIMIT = 32


def active_artifact_receipts(
    receipts: Sequence[Mapping[str, Any]],
    *,
    read_artifact: ArtifactReader,
    explicit_refs: Sequence[str] = (),
) -> tuple[dict[str, Any], ...]:
    """Project latest C2 revisions plus explicitly needed dependency history."""
    ordered = [dict(receipt) for receipt in receipts]
    receipt_by_ref = {
        str(receipt.get("artifact_ref") or ""): receipt
        for receipt in ordered
        if str(receipt.get("artifact_ref") or "")
    }
    latest_by_artifact_id: dict[str, str] = {}
    for receipt in ordered:
        artifact_ref = str(receipt.get("artifact_ref") or "")
        if not artifact_ref:
            continue
        stored = read_artifact(artifact_ref)
        artifact_id = str(stored.get("artifact_id") or artifact_ref)
        latest_by_artifact_id[artifact_id] = artifact_ref

    active_refs = set(latest_by_artifact_id.values())
    active_refs.update(ref for ref in explicit_refs if ref in receipt_by_ref)
    pending = list(active_refs)
    while pending:
        artifact_ref = pending.pop()
        receipt = receipt_by_ref.get(artifact_ref)
        if receipt is None:
            continue
        for dependency_ref in receipt.get("depends_on") or ():
            dependency = str(dependency_ref)
            if dependency in receipt_by_ref and dependency not in active_refs:
                active_refs.add(dependency)
                pending.append(dependency)

    return tuple(
        receipt
        for receipt in ordered
        if str(receipt.get("artifact_ref") or "") in active_refs
    )


def artifact_prompt_catalog(
    receipts: Sequence[Mapping[str, Any]],
    *,
    priority_refs: Sequence[str] = (),
    budget_bytes: int = DEFAULT_ARTIFACT_CATALOG_BUDGET_BYTES,
) -> dict[str, Any]:
    """Build a bounded C2 navigation window without changing C2 storage.

    Priority refs are considered first. Remaining space is filled newest first.
    Omitted artifacts remain discoverable through ``artifact_catalog_page``.
    """
    if budget_bytes <= 0:
        raise ValueError("artifact_catalog_budget_bytes_must_be_positive")
    ordered = [dict(receipt) for receipt in receipts]
    by_ref = {
        str(receipt.get("artifact_ref") or "").strip(): receipt
        for receipt in ordered
        if str(receipt.get("artifact_ref") or "").strip()
    }
    prioritized = [
        ref
        for ref in dict.fromkeys(
            str(raw_ref).strip() for raw_ref in priority_refs
        )
        if ref in by_ref
    ]
    candidate_refs = list(
        dict.fromkeys(
            [
                *prioritized,
                *reversed(list(by_ref)),
            ]
        )
    )
    priority_set = set(prioritized)
    items: list[dict[str, Any]] = []
    used_bytes = 2
    omitted_priority_refs: list[str] = []
    for artifact_ref in candidate_refs:
        projected = artifact_receipt_prompt_projection(by_ref[artifact_ref])
        projected_bytes = _json_bytes(projected) + (1 if items else 0)
        if used_bytes + projected_bytes <= budget_bytes:
            items.append(projected)
            used_bytes += projected_bytes
            continue
        if artifact_ref in priority_set:
            reference_only = {
                "artifact_ref": artifact_ref,
                "artifact_kind": str(
                    by_ref[artifact_ref].get("artifact_kind") or ""
                ),
                "status": str(by_ref[artifact_ref].get("status") or ""),
                "projection": "ref_only",
            }
            reference_bytes = _json_bytes(reference_only) + (1 if items else 0)
            if used_bytes + reference_bytes <= budget_bytes:
                items.append(reference_only)
                used_bytes += reference_bytes
                continue
            omitted_priority_refs.append(artifact_ref)

    visible_refs = {
        str(item.get("artifact_ref") or "") for item in items
    }
    kind_counts = Counter(
        str(receipt.get("artifact_kind") or "unknown") for receipt in ordered
    )
    ordered_kind_counts = sorted(
        kind_counts.items(), key=lambda item: (-item[1], item[0])
    )
    return {
        "total_active_count": len(ordered),
        "visible_count": len(items),
        "omitted_count": max(0, len(ordered) - len(visible_refs)),
        "priority_ref_count": len(prioritized),
        "omitted_priority_ref_count": len(omitted_priority_refs),
        "artifact_kind_counts": [
            {"artifact_kind": kind, "count": count}
            for kind, count in ordered_kind_counts[:_ARTIFACT_KIND_COUNT_LIMIT]
        ],
        "omitted_artifact_kind_count": max(
            0, len(ordered_kind_counts) - _ARTIFACT_KIND_COUNT_LIMIT
        ),
        "items": items,
        "retrieval": (
            "Use artifact_list filters and cursor pagination to discover "
            "omitted C2 receipts, then read_ref the exact returned ref."
        ),
    }


def artifact_catalog_page(
    receipts: Sequence[Mapping[str, Any]],
    *,
    artifact_kind: str = "",
    status: str = "",
    query: str = "",
    cursor: int = 0,
    limit: int = ARTIFACT_CATALOG_PAGE_LIMIT,
) -> dict[str, Any]:
    """Return one bounded, mechanically filtered page of C2 receipts."""
    if cursor < 0:
        raise ValueError("artifact_catalog_cursor_must_not_be_negative")
    if not 1 <= limit <= ARTIFACT_CATALOG_PAGE_LIMIT:
        raise ValueError(
            "artifact_catalog_limit_must_be_1_to_"
            f"{ARTIFACT_CATALOG_PAGE_LIMIT}"
        )
    kind_filter = str(artifact_kind).strip()
    status_filter = str(status).strip()
    query_filter = str(query).strip().casefold()
    matches: list[dict[str, Any]] = []
    for receipt in reversed([dict(item) for item in receipts]):
        if kind_filter and str(receipt.get("artifact_kind") or "") != kind_filter:
            continue
        if status_filter and str(receipt.get("status") or "") != status_filter:
            continue
        if query_filter:
            haystack = " ".join(
                str(receipt.get(key) or "")
                for key in ("artifact_ref", "artifact_kind", "status", "summary")
            ).casefold()
            if query_filter not in haystack:
                continue
        matches.append(artifact_receipt_prompt_projection(receipt))
    page = matches[cursor : cursor + limit]
    next_cursor = cursor + len(page)
    return {
        "status": "artifact_catalog_page",
        "artifact_kind_filter": kind_filter,
        "status_filter": status_filter,
        "query_filter": str(query).strip(),
        "total_matching": len(matches),
        "cursor": cursor,
        "items": page,
        "next_cursor": next_cursor if next_cursor < len(matches) else None,
    }


def artifact_receipt_prompt_projection(
    receipt: Mapping[str, Any],
) -> dict[str, Any]:
    dependencies = [
        str(ref).strip()
        for ref in receipt.get("depends_on") or ()
        if str(ref).strip()
    ]
    summary = str(receipt.get("summary") or "")
    if len(summary) > _ARTIFACT_SUMMARY_LIMIT:
        summary = (
            summary[:_ARTIFACT_SUMMARY_LIMIT]
            + f"...[{len(summary) - _ARTIFACT_SUMMARY_LIMIT} chars omitted]"
        )
    return {
        "artifact_ref": str(receipt.get("artifact_ref") or ""),
        "artifact_kind": str(receipt.get("artifact_kind") or ""),
        "status": str(receipt.get("status") or ""),
        "summary": summary,
        "depends_on": dependencies[:_ARTIFACT_DEPENDENCY_LIMIT],
        "dependency_count": len(dependencies),
        "omitted_dependency_count": max(
            0, len(dependencies) - _ARTIFACT_DEPENDENCY_LIMIT
        ),
        "projection": "summary",
    }


def artifact_dependency_closure_refs(
    receipts: Sequence[Mapping[str, Any]],
    *,
    read_artifact: ArtifactReader,
    explicit_refs: Sequence[str],
) -> tuple[str, ...]:
    """Return only explicit artifact refs and their stored dependency closure."""
    available_refs = {
        str(receipt.get("artifact_ref") or "").strip()
        for receipt in receipts
        if str(receipt.get("artifact_ref") or "").strip()
    }
    ordered = list(
        dict.fromkeys(str(ref).strip() for ref in explicit_refs if str(ref).strip())
    )
    seen = set(ordered)
    pending = [ref for ref in ordered if ref in available_refs]
    while pending:
        artifact_ref = pending.pop(0)
        stored = read_artifact(artifact_ref)
        for raw_dependency in stored.get("depends_on") or ():
            dependency_ref = str(raw_dependency).strip()
            if (
                dependency_ref not in available_refs
                or dependency_ref in seen
            ):
                continue
            seen.add(dependency_ref)
            ordered.append(dependency_ref)
            pending.append(dependency_ref)
    return tuple(ordered)


def prompt_projection_receipt(
    *,
    call_site: str,
    messages: Sequence[Mapping[str, Any]],
    tools: Sequence[Mapping[str, Any]],
    sources: Sequence[PromptSource],
    budget_bytes: int,
    budget_tier: str,
) -> dict[str, Any]:
    if budget_bytes <= 0:
        raise ValueError("prompt_budget_bytes_must_be_positive")
    total_bytes = _json_bytes({"messages": list(messages), "tools": list(tools)})
    source_receipts = [
        {
            "memory_class": source.memory_class,
            "name": source.name,
            "bytes": _json_bytes(source.value),
        }
        for source in sources
    ]
    return {
        "call_site": str(call_site),
        "budget_tier": str(budget_tier),
        "budget_bytes": int(budget_bytes),
        "total_bytes": total_bytes,
        "status": "within_budget" if total_bytes <= budget_bytes else "over_budget",
        "sources": source_receipts,
    }


def _json_bytes(value: Any) -> int:
    return len(
        json.dumps(
            value,
            ensure_ascii=False,
            separators=(",", ":"),
            default=str,
        ).encode("utf-8")
    )
