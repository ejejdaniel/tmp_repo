from __future__ import annotations

from typing import Any, Mapping, Sequence

from .work_context import exact_work_refs
from .work_resolution import resolve_work_context


class WorkMemoryRuntimeMixin:
    """Runtime adapter; all durable work reads use this same resolver."""

    def _work_view_policy(self) -> Mapping[str, Any]:
        state = self._state.read()
        return {
            "mission": ({"artifact_refs": self._mission.artifact_refs,
                         "workspace_refs": self._mission.workspace_refs,
                         "allow_workspace_discovery": self._mission.allow_workspace_discovery}
                        if self._mission else None),
            "mounted_artifacts": self._artifacts.mounted_refs(),
            "task_spec_ref": state["c1"]["task_contract_state"]["task_spec_ref"],
            "source_routes": [
                {"name": route.name, "skill_ids": route.skill_ids}
                for route in self._routes.all() if route.name in {"source_read", "workspace_terminal"}
            ],
            "workspace_root": str(self._workspace_root),
            "workspace_exclusions": self._workspace_excluded_relative_paths,
        }

    def _work_source_visible(self, ref: str) -> bool:
        try:
            if ref.startswith(("source_file:", "source_probe:", "workspace_terminal:")):
                route = next(route for route in self._routes.all() if route.name == "source_read")
                arguments = {"source_ref": ref, "line_limit": 1}
                if route.contextual_handler:
                    route.contextual_handler(arguments, self._state.read()["c1"]["active_skill_id"])
                else:
                    # Existing source handler enforces workspace/file grants.
                    # Tool availability is not a grant to historical content.
                    route.handler(arguments)
            elif ref.startswith("materializer_execution_workspace:"):
                self._ensure_child_external_ref_visible(ref)
            else:
                self._read_exact_ref(ref)
            return True
        except (KeyError, OSError, RuntimeError, ValueError, StopIteration):
            return False

    def _current_work_projection(
        self,
        *,
        consumer: str | None = None,
        explicit_refs: Sequence[str] = (),
    ) -> dict[str, Any]:
        if consumer:
            self._work.consumer = consumer
        state = self._state.read()
        return resolve_work_context(
            self._work,
            explicit_refs=tuple(
                dict.fromkeys(
                    (*state["c1"]["resolved_artifact_refs"], *explicit_refs)
                )
            ),
            read_ref=self._read_exact_ref, projects=self._development_projects,
        )

    def _record_work_tool(
        self, *, call_id: str, name: str, arguments: Mapping[str, Any],
        result: Mapping[str, Any], event_sequence: int,
        context_ref: str | None = None, input_refs: tuple[str, ...] = (),
    ) -> None:
        self._work.record_tool(
            event_id=f"{self.agent_id}:{event_sequence}:tool", call_id=call_id,
            tool_name=name, arguments=arguments, result=result,
            context_ref=context_ref, source_refs=input_refs,
        )

    def _recover_owned_work_refs(self) -> None:
        """Restore ownership from committed operation records, never C6."""
        for entry in self._work.store.owned_entries(agent_id=self.agent_id):
            received_from_child = False
            while entry["entry_kind"] == "import":
                entry = self._work.store.read_entry(entry["payload"]["entry_ref"], agent_id=self.agent_id)
                owner = self._work.store.entry_owner(entry["entry_ref"], agent_id=self.agent_id)
                received_from_child = owner.startswith(self.agent_id + ".child.")
            if self._work.store.entry_owner(entry["entry_ref"], agent_id=self.agent_id) != self.agent_id and not received_from_child:
                continue
            if entry["entry_kind"] != "tool_result":
                continue
            payload = entry["payload"]
            if payload["tool_name"] in {"read_ref", "artifact_read", "source_read"}:
                continue
            result = payload["result"]
            refs = exact_work_refs({key: result.get(key) for key in (
                "observation_ref", "code_artifact_ref", "stdout_ref", "stderr_ref", "diff_ref",
                "execution_workspace_ref",
            )})
            target = self._mounted_external_refs if received_from_child else self._owned_external_refs
            target.update(ref for ref in refs if not ref.startswith(("artifact:", "work_entry:")))
            if not received_from_child and payload["tool_name"] == "development_project_checkpoint":
                snapshot = str(result.get("snapshot_ref") or "")
                if snapshot.startswith("artifact:"):
                    self._artifacts.register_produced_refs((snapshot,))

    def _bind_node_work(self, active: Mapping[str, Any], *, attempt_index: int, requested_ref: str = "") -> None:
        state = self._state.read()
        current = state["c1"]["active_work_context_ref"]
        if attempt_index > 1 and current:
            if requested_ref and requested_ref != current:
                raise ValueError("node_retry_must_keep_bound_work_context")
            self._work.select(current)
        elif requested_ref:
            self._work.select(requested_ref)
        else:
            self._state.bind_work_context(None)
            self._work.ensure(title=str(active["outcome"]), input_refs=self._active_node_input_refs(state))

    def _validate_child_work_refs(self, mission: Any) -> None:
        for ref in mission.work_entry_refs:
            entry = self._work.store.read_entry(ref, agent_id=self.agent_id)
            if not self._work.allows(entry["source_refs"]):
                raise PermissionError(f"child_work_entry_sources_not_visible:{ref}")

    def _import_child_work(self, child_agent_id: str) -> tuple[str, ...]:
        # The parent may read child operations, but formal child outputs still
        # require the existing artifact review boundary.
        allowed: list[str] = []
        entries = self._work.store.owned_entries(agent_id=child_agent_id)
        for entry in entries:
            if entry["entry_kind"] == "import":
                continue
            if not self._work.allows(entry["source_refs"]):
                continue
            allowed.append(entry["entry_ref"])
            self._work.store.import_entries(
                self._work.ensure(), agent_id=self.agent_id,
                entry_refs=[entry["entry_ref"]], authorized_refs=[entry["entry_ref"]],
            )
        return tuple(allowed)
