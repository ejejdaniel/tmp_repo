from __future__ import annotations

import copy
import json
import os
from pathlib import Path
from typing import Any, Mapping, Sequence

from ..capabilities import normalize_meta_capabilities
from ..planning.graph import (
    FRAME_GOAL_NODE_ID,
    empty_plan_graph,
    ensure_plan_graph_start_node,
    render_plan_summary,
    validate_plan_graph,
)


_RECENT_RECEIPT_LIMIT = 6
_STATE_VERSION = 17
_TASK_CONTRACT_PHASES = frozenset(
    {
        "task_formulation",
        "evaluation_build",
        "ready",
        "contract_reconciliation",
    }
)


class AgentStateError(RuntimeError):
    pass


class AgentStateStore:
    """Persistent prompt state with explicit, non-overlapping lifecycles.

    C0: immutable objective and evaluation anchor.
    C1: evaluation progress, active plan, selected skill, refs, bounded
        receipts, and the current issue.
    C3: persistent work and dialogue summaries live in WorkMemoryStore.
    C2: formal artifacts live in ArtifactStore.
    C4: large workspace bodies live in their dedicated stores.
    C5: skill-stage transport is in-memory and never persisted here.
    C6: raw audit events live in EventLog and never persist here.
    """

    def __init__(self, path: Path) -> None:
        self.path = path.resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def initialize(
        self,
        *,
        objective: str,
        evaluation_summary: str,
        plan_summary: str,
        plan_graph: Mapping[str, Any] | None = None,
        evaluation_state: Mapping[str, Any] | None = None,
        global_evaluation_state: Mapping[str, Any] | None = None,
        frame_evaluation_state: Mapping[str, Any] | None = None,
        task_contract_state: Mapping[str, Any] | None = None,
        enabled_meta_capabilities: Sequence[str] = (),
    ) -> None:
        normalized_meta_capabilities = normalize_meta_capabilities(
            enabled_meta_capabilities
        )
        if self.path.exists():
            state = self.read()
            c0 = state["c0"]
            if c0["objective"] != objective:
                raise AgentStateError("objective_conflicts_with_persisted_c0")
            if c0["evaluation_summary"] != evaluation_summary:
                raise AgentStateError("evaluation_conflicts_with_persisted_c0")
            if tuple(c0["enabled_meta_capabilities"]) != (
                normalized_meta_capabilities
            ):
                raise AgentStateError(
                    "meta_capabilities_conflict_with_persisted_c0"
                )
            return
        if plan_graph is None:
            if plan_summary.strip():
                raise AgentStateError(
                    "plan_graph_required_when_initial_plan_summary_is_nonempty"
                )
            normalized_plan_graph = empty_plan_graph()
        else:
            normalized_plan_graph = copy.deepcopy(dict(plan_graph))
            try:
                validate_plan_graph(normalized_plan_graph, allow_empty=True)
            except ValueError as exc:
                raise AgentStateError(
                    f"agent_state_plan_graph_invalid:{exc}"
                ) from exc
            rendered = render_plan_summary(normalized_plan_graph)
            if plan_summary.strip() and plan_summary.strip() != rendered:
                raise AgentStateError("plan_summary_conflicts_with_plan_graph")
        if global_evaluation_state is not None and evaluation_state is not None:
            raise AgentStateError("global_evaluation_state_declared_twice")
        raw_global_evaluation_state = (
            global_evaluation_state
            if global_evaluation_state is not None
            else evaluation_state
        )
        normalized_global_evaluation_state = (
            None
            if raw_global_evaluation_state is None
            else copy.deepcopy(dict(raw_global_evaluation_state))
        )
        if normalized_global_evaluation_state is not None:
            _validate_evaluation_state(normalized_global_evaluation_state)
        normalized_frame_evaluation_state = (
            None
            if frame_evaluation_state is None
            else copy.deepcopy(dict(frame_evaluation_state))
        )
        if normalized_frame_evaluation_state is not None:
            _validate_evaluation_state(normalized_frame_evaluation_state)
        normalized_task_contract_state = (
            copy.deepcopy(dict(task_contract_state))
            if task_contract_state is not None
            else (
                {
                    "phase": "ready",
                    "task_spec_ref": "",
                    "input_refs": [],
                }
                if normalized_global_evaluation_state is not None
                else empty_task_contract_state()
            )
        )
        _validate_task_contract_state(normalized_task_contract_state)
        self._write(
            {
                "version": _STATE_VERSION,
                "c0": {
                    "objective": objective,
                    "evaluation_summary": evaluation_summary,
                    "enabled_meta_capabilities": list(
                        normalized_meta_capabilities
                    ),
                },
                "c1": {
                    "task_contract_state": normalized_task_contract_state,
                    "global_evaluation_state": (
                        normalized_global_evaluation_state
                    ),
                    "frame_evaluation_state": (
                        normalized_frame_evaluation_state
                    ),
                    "plan_graph": normalized_plan_graph,
                    "plan_summary": render_plan_summary(normalized_plan_graph),
                    "active_skill_id": None,
                    "resolved_artifact_refs": [],
                    "recent_bounded_receipts": [],
                    "current_issue": "",
                    "node_loop_state": _empty_node_loop_state(),
                    "human_interaction_state": empty_human_interaction_state(),
                    "dialogue_turn_state": empty_dialogue_turn_state(),
                    "active_work_context_ref": None,
                },
                "c3": {},
            }
        )

    def read(self) -> dict[str, Any]:
        try:
            state = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise AgentStateError(f"agent_state_unreadable:{exc}") from exc
        if isinstance(state, Mapping) and state.get("version") != _STATE_VERSION:
            raise AgentStateError(
                "agent_state_requires_explicit_work_memory_migration:"
                f"version={state.get('version')}:use=migrate_work_memory_checkpoint.py"
            )
        self._validate_state(state)
        return state

    def start_skill(
        self,
        skill_id: str,
        *,
        resolved_artifact_refs: Sequence[str] | None = None,
    ) -> None:
        state = self.read()
        refs = (
            list(dict.fromkeys(str(ref).strip() for ref in resolved_artifact_refs))
            if resolved_artifact_refs is not None
            else list(state["c1"]["resolved_artifact_refs"])
        )
        if any(not ref for ref in refs):
            raise AgentStateError("agent_state_resolved_refs_invalid")
        state["c1"].update(
            {
                "active_skill_id": skill_id,
                "resolved_artifact_refs": refs,
                "recent_bounded_receipts": [],
                "current_issue": "",
            }
        )
        self._write(state)

    def release_skill_context(self) -> None:
        state = self.read()
        state["c1"].update(
            {
                "active_skill_id": None,
                "resolved_artifact_refs": [],
                "recent_bounded_receipts": [],
            }
        )
        self._write(state)

    def set_plan_graph(self, plan_graph: Mapping[str, Any]) -> None:
        normalized = copy.deepcopy(dict(plan_graph))
        try:
            validate_plan_graph(normalized)
        except ValueError as exc:
            raise AgentStateError(f"agent_state_plan_graph_invalid:{exc}") from exc
        state = self.read()
        previous_graph = state["c1"]["plan_graph"]
        previous_active = _active_node_id(previous_graph)
        next_active = _active_node_id(normalized)
        state["c1"]["plan_graph"] = normalized
        state["c1"]["plan_summary"] = render_plan_summary(normalized)
        if (
            int(previous_graph["revision"]) != int(normalized["revision"])
            or previous_active != next_active
        ):
            state["c1"]["node_loop_state"] = _empty_node_loop_state()
            state["c1"]["active_work_context_ref"] = None
        self._write(state)

    def set_node_loop_state(self, node_loop_state: Mapping[str, Any]) -> None:
        normalized = copy.deepcopy(dict(node_loop_state))
        _ensure_node_loop_research_mode_fields(normalized)
        _validate_node_loop_state(normalized)
        state = self.read()
        state["c1"]["node_loop_state"] = normalized
        self._write(state)

    def clear_node_loop_state(self) -> None:
        self.set_node_loop_state(_empty_node_loop_state())

    def set_global_evaluation_state(
        self,
        evaluation_state: Mapping[str, Any] | None,
    ) -> None:
        normalized = (
            None
            if evaluation_state is None
            else copy.deepcopy(dict(evaluation_state))
        )
        if normalized is not None:
            _validate_evaluation_state(normalized)
        state = self.read()
        state["c1"]["global_evaluation_state"] = normalized
        self._write(state)

    def set_task_contract_state(
        self,
        task_contract_state: Mapping[str, Any],
    ) -> None:
        normalized = copy.deepcopy(dict(task_contract_state))
        _validate_task_contract_state(normalized)
        state = self.read()
        state["c1"]["task_contract_state"] = normalized
        self._write(state)

    def activate_task_contract(
        self,
        *,
        task_spec_ref: str,
        input_refs: Sequence[str],
        global_evaluation_state: Mapping[str, Any],
    ) -> None:
        """Atomically activate one task specification and its matching gate."""
        contract = {
            "phase": "ready",
            "task_spec_ref": str(task_spec_ref).strip(),
            "input_refs": list(
                dict.fromkeys(str(ref).strip() for ref in input_refs)
            ),
        }
        evaluation = copy.deepcopy(dict(global_evaluation_state))
        _validate_task_contract_state(contract)
        if not contract["task_spec_ref"]:
            raise AgentStateError("agent_state_task_spec_ref_required")
        _validate_evaluation_state(evaluation)
        state = self.read()
        state["c1"]["task_contract_state"] = contract
        state["c1"]["global_evaluation_state"] = evaluation
        active_refs = list(state["c1"]["resolved_artifact_refs"])
        for ref in (*contract["input_refs"], contract["task_spec_ref"]):
            if ref not in active_refs:
                active_refs.append(ref)
        state["c1"]["resolved_artifact_refs"] = active_refs
        self._write(state)

    def set_frame_evaluation_state(
        self,
        evaluation_state: Mapping[str, Any] | None,
    ) -> None:
        normalized = (
            None
            if evaluation_state is None
            else copy.deepcopy(dict(evaluation_state))
        )
        if normalized is not None:
            _validate_evaluation_state(normalized)
        state = self.read()
        state["c1"]["frame_evaluation_state"] = normalized
        self._write(state)

    def set_evaluation_state(self, evaluation_state: Mapping[str, Any]) -> None:
        """Compatibility alias for pre-v11 callers; Global is authoritative."""
        self.set_global_evaluation_state(evaluation_state)

    def add_resolved_artifact_ref(self, artifact_ref: str) -> None:
        state = self.read()
        refs = state["c1"]["resolved_artifact_refs"]
        if artifact_ref not in refs:
            refs.append(artifact_ref)
        self._write(state)

    def remove_resolved_artifact_refs(
        self,
        artifact_refs: Sequence[str],
    ) -> None:
        retired = {
            str(ref).strip()
            for ref in artifact_refs
            if str(ref).strip()
        }
        if not retired:
            return
        state = self.read()
        state["c1"]["resolved_artifact_refs"] = [
            ref
            for ref in state["c1"]["resolved_artifact_refs"]
            if ref not in retired
        ]
        self._write(state)

    def activate_resolved_artifact_ref(
        self,
        artifact_ref: str,
        *,
        superseded_refs: tuple[str, ...] = (),
    ) -> None:
        """Make one exact ref current while retiring prior C1 versions."""
        active_ref = str(artifact_ref).strip()
        if not active_ref:
            raise AgentStateError("active_resolved_artifact_ref_required")
        superseded = {
            str(ref).strip()
            for ref in superseded_refs
            if str(ref).strip() and str(ref).strip() != active_ref
        }
        state = self.read()
        refs = [
            ref
            for ref in state["c1"]["resolved_artifact_refs"]
            if ref not in superseded and ref != active_ref
        ]
        refs.append(active_ref)
        state["c1"]["resolved_artifact_refs"] = refs
        self._write(state)

    def record_receipt(self, receipt: Mapping[str, Any]) -> None:
        state = self.read()
        receipts = state["c1"]["recent_bounded_receipts"]
        receipts.append(dict(receipt))
        state["c1"]["recent_bounded_receipts"] = _current_receipts(receipts)
        self._write(state)

    def set_issue(self, issue: str) -> None:
        state = self.read()
        state["c1"]["current_issue"] = issue
        self._write(state)

    def bind_work_context(self, context_ref: str | None) -> None:
        """Select a work scope; ownership is checked by WorkMemoryStore."""
        state = self.read()
        state["c1"]["active_work_context_ref"] = context_ref
        self._write(state)

    def set_human_interaction_state(
        self,
        human_interaction_state: Mapping[str, Any],
    ) -> None:
        normalized = copy.deepcopy(dict(human_interaction_state))
        _validate_human_interaction_state(normalized)
        state = self.read()
        state["c1"]["human_interaction_state"] = normalized
        self._write(state)

    def clear_human_interaction_state(self) -> None:
        self.set_human_interaction_state(empty_human_interaction_state())

    def set_dialogue_turn_state(
        self,
        dialogue_turn_state: Mapping[str, Any],
    ) -> None:
        normalized = copy.deepcopy(dict(dialogue_turn_state))
        _validate_dialogue_turn_state(normalized)
        state = self.read()
        state["c1"]["dialogue_turn_state"] = normalized
        self._write(state)

    def clear_dialogue_turn_state(self) -> None:
        self.set_dialogue_turn_state(empty_dialogue_turn_state())

    def _write(self, state: Mapping[str, Any]) -> None:
        self._validate_state(state)
        temporary = self.path.with_suffix(f"{self.path.suffix}.tmp")
        temporary.write_text(
            json.dumps(state, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, self.path)

    @staticmethod
    def _validate_state(state: Any) -> None:
        if not isinstance(state, Mapping) or state.get("version") != _STATE_VERSION:
            raise AgentStateError("agent_state_version_invalid")
        _require_exact_keys(state, {"version", "c0", "c1", "c3"}, "root")

        c0 = state.get("c0")
        c1 = state.get("c1")
        c3 = state.get("c3")
        if not isinstance(c0, Mapping):
            raise AgentStateError("agent_state_c0_invalid")
        if not isinstance(c1, Mapping):
            raise AgentStateError("agent_state_c1_invalid")
        if not isinstance(c3, Mapping):
            raise AgentStateError("agent_state_c3_invalid")

        _require_exact_keys(
            c0,
            {
                "objective",
                "evaluation_summary",
                "enabled_meta_capabilities",
            },
            "c0",
        )
        _require_exact_keys(
            c1,
            {
                "task_contract_state",
                "global_evaluation_state",
                "frame_evaluation_state",
                "plan_graph",
                "plan_summary",
                "active_skill_id",
                "resolved_artifact_refs",
                "recent_bounded_receipts",
                "current_issue",
                "node_loop_state",
                "human_interaction_state",
                "dialogue_turn_state",
                "active_work_context_ref",
            },
            "c1",
        )
        _require_exact_keys(
            c3,
            set(),
            "c3",
        )

        if not isinstance(c0["objective"], str) or not isinstance(
            c0["evaluation_summary"], str
        ):
            raise AgentStateError("agent_state_c0_value_invalid")
        try:
            normalized_meta_capabilities = normalize_meta_capabilities(
                c0["enabled_meta_capabilities"]
            )
        except ValueError as exc:
            raise AgentStateError(
                f"agent_state_meta_capabilities_invalid:{exc}"
            ) from exc
        if list(normalized_meta_capabilities) != c0["enabled_meta_capabilities"]:
            raise AgentStateError(
                "agent_state_meta_capabilities_not_normalized"
            )
        _validate_task_contract_state(c1["task_contract_state"])
        if c1["global_evaluation_state"] is not None:
            _validate_evaluation_state(c1["global_evaluation_state"])
        if c1["frame_evaluation_state"] is not None:
            _validate_evaluation_state(c1["frame_evaluation_state"])
        try:
            validate_plan_graph(c1["plan_graph"], allow_empty=True)
        except ValueError as exc:
            raise AgentStateError(f"agent_state_plan_graph_invalid:{exc}") from exc
        if not isinstance(c1["plan_summary"], str):
            raise AgentStateError("agent_state_plan_summary_invalid")
        if c1["plan_summary"] != render_plan_summary(c1["plan_graph"]):
            raise AgentStateError("agent_state_plan_summary_not_derived_from_graph")
        if c1["active_skill_id"] is not None and not isinstance(
            c1["active_skill_id"], str
        ):
            raise AgentStateError("agent_state_active_skill_invalid")
        refs = c1["resolved_artifact_refs"]
        if (
            not isinstance(refs, list)
            or not all(isinstance(ref, str) and ref for ref in refs)
            or len(refs) != len(set(refs))
        ):
            raise AgentStateError("agent_state_resolved_refs_invalid")
        receipts = c1["recent_bounded_receipts"]
        if (
            not isinstance(receipts, list)
            or len(receipts) > _RECENT_RECEIPT_LIMIT
            or not all(isinstance(receipt, Mapping) for receipt in receipts)
        ):
            raise AgentStateError("agent_state_receipts_invalid")
        if not isinstance(c1["current_issue"], str):
            raise AgentStateError("agent_state_current_issue_invalid")
        _validate_node_loop_state(c1["node_loop_state"])
        _validate_human_interaction_state(c1["human_interaction_state"])
        _validate_dialogue_turn_state(c1["dialogue_turn_state"])
        work_ref = c1["active_work_context_ref"]
        if work_ref is not None and (
            not isinstance(work_ref, str) or not work_ref.startswith("work_context:")
            or not work_ref.removeprefix("work_context:")
        ):
            raise AgentStateError("agent_state_work_context_ref_invalid")


def _require_exact_keys(
    value: Mapping[str, Any], expected: set[str], location: str
) -> None:
    actual = set(value)
    if actual != expected:
        missing = sorted(expected - actual)
        unexpected = sorted(actual - expected)
        raise AgentStateError(
            f"agent_state_{location}_keys_invalid:"
            f"missing={missing}:unexpected={unexpected}"
        )


def _validate_evaluation_state(value: Any) -> None:
    if not isinstance(value, Mapping):
        raise AgentStateError("agent_state_evaluation_state_invalid")
    _require_exact_keys(
        value,
        {
            "gate_ref",
            "terminal",
            "success",
            "criterion_results",
            "triggered_stop_id",
        },
        "evaluation_state",
    )
    if not isinstance(value["gate_ref"], str) or not value["gate_ref"]:
        raise AgentStateError("agent_state_evaluation_gate_ref_invalid")
    if not isinstance(value["terminal"], bool) or not isinstance(
        value["success"], bool
    ):
        raise AgentStateError("agent_state_evaluation_flags_invalid")
    results = value["criterion_results"]
    if not isinstance(results, list) or not results:
        raise AgentStateError("agent_state_evaluation_results_invalid")
    criterion_ids: list[str] = []
    for result in results:
        if not isinstance(result, Mapping):
            raise AgentStateError("agent_state_evaluation_result_invalid")
        _require_exact_keys(
            result,
            {"criterion_id", "status", "evidence_refs", "reason"},
            "evaluation_result",
        )
        criterion_id = result["criterion_id"]
        if not isinstance(criterion_id, str) or not criterion_id:
            raise AgentStateError("agent_state_evaluation_criterion_id_invalid")
        if result["status"] not in {"met", "unmet", "indeterminate"}:
            raise AgentStateError("agent_state_evaluation_status_invalid")
        refs = result["evidence_refs"]
        if (
            not isinstance(refs, list)
            or not all(isinstance(ref, str) and ref for ref in refs)
            or len(refs) != len(set(refs))
        ):
            raise AgentStateError("agent_state_evaluation_evidence_refs_invalid")
        if result["status"] == "met" and not refs:
            raise AgentStateError("agent_state_evaluation_met_without_evidence")
        if not isinstance(result["reason"], str) or not result["reason"]:
            raise AgentStateError("agent_state_evaluation_reason_invalid")
        criterion_ids.append(criterion_id)
    if len(criterion_ids) != len(set(criterion_ids)):
        raise AgentStateError("agent_state_evaluation_criterion_ids_duplicate")
    all_met = all(result["status"] == "met" for result in results)
    if value["success"] != all_met:
        raise AgentStateError("agent_state_evaluation_success_invalid")
    stop_id = value["triggered_stop_id"]
    if not isinstance(stop_id, str):
        raise AgentStateError("agent_state_evaluation_stop_id_invalid")
    if value["terminal"] != (value["success"] or bool(stop_id)):
        raise AgentStateError("agent_state_evaluation_terminal_invalid")


def empty_task_contract_state() -> dict[str, Any]:
    return {
        "phase": "task_formulation",
        "task_spec_ref": "",
        "input_refs": [],
    }


def _validate_task_contract_state(value: Any) -> None:
    if not isinstance(value, Mapping):
        raise AgentStateError("agent_state_task_contract_invalid")
    _require_exact_keys(
        value,
        {"phase", "task_spec_ref", "input_refs"},
        "task_contract",
    )
    if value["phase"] not in _TASK_CONTRACT_PHASES:
        raise AgentStateError("agent_state_task_contract_phase_invalid")
    if not isinstance(value["task_spec_ref"], str):
        raise AgentStateError("agent_state_task_spec_ref_invalid")
    refs = value["input_refs"]
    if (
        not isinstance(refs, list)
        or not all(isinstance(ref, str) and ref for ref in refs)
        or len(refs) != len(set(refs))
    ):
        raise AgentStateError("agent_state_task_contract_input_refs_invalid")
    if value["phase"] == "evaluation_build" and not value["task_spec_ref"]:
        raise AgentStateError("agent_state_task_spec_ref_required_for_evaluation")


def _empty_node_loop_state() -> dict[str, Any]:
    return {
        "node_id": "",
        "attempt_index": 0,
        "steps": [],
        "produced_refs": [],
        "next_step_index": 0,
        "awaiting_transition": False,
    }


def empty_human_interaction_state() -> dict[str, Any]:
    return {
        "status": "idle",
        "request_id": "",
        "scope": "",
        "requester": "",
        "question": "",
        "reason": "",
        "expected_response_role": "",
        "context_refs": [],
        "resume_anchor": {
            "control_phase": "",
            "graph_revision": 0,
            "node_id": "",
            "attempt_index": 0,
            "step_index": 0,
        },
        "response_ref": "",
    }


def empty_dialogue_turn_state() -> dict[str, Any]:
    return {
        "phase": "idle",
        "turn_id": "",
        "user_message_id": "",
    }


def _validate_dialogue_turn_state(value: Any) -> None:
    if not isinstance(value, Mapping):
        raise AgentStateError("agent_state_dialogue_turn_invalid")
    _require_exact_keys(
        value,
        {"phase", "turn_id", "user_message_id"},
        "dialogue_turn",
    )
    if value["phase"] not in {"idle", "intake", "research"}:
        raise AgentStateError("agent_state_dialogue_turn_phase_invalid")
    if not isinstance(value["turn_id"], str) or not isinstance(
        value["user_message_id"], str
    ):
        raise AgentStateError("agent_state_dialogue_turn_identity_invalid")
    if value["phase"] == "idle":
        if value != empty_dialogue_turn_state():
            raise AgentStateError("agent_state_dialogue_turn_idle_invalid")
        return
    if not value["turn_id"].strip() or not value["user_message_id"].strip():
        raise AgentStateError("agent_state_dialogue_turn_active_identity_required")


def _validate_human_interaction_state(value: Any) -> None:
    if not isinstance(value, Mapping):
        raise AgentStateError("agent_state_human_interaction_invalid")
    _require_exact_keys(
        value,
        {
            "status",
            "request_id",
            "scope",
            "requester",
            "question",
            "reason",
            "expected_response_role",
            "context_refs",
            "resume_anchor",
            "response_ref",
        },
        "human_interaction",
    )
    status = value["status"]
    if status not in {"idle", "pending", "answered"}:
        raise AgentStateError("agent_state_human_interaction_status_invalid")
    string_fields = (
        "request_id",
        "scope",
        "requester",
        "question",
        "reason",
        "expected_response_role",
        "response_ref",
    )
    if not all(isinstance(value[field], str) for field in string_fields):
        raise AgentStateError("agent_state_human_interaction_text_invalid")
    refs = value["context_refs"]
    if (
        not isinstance(refs, list)
        or not all(isinstance(ref, str) and ref for ref in refs)
        or len(refs) != len(set(refs))
    ):
        raise AgentStateError("agent_state_human_interaction_refs_invalid")
    anchor = value["resume_anchor"]
    if not isinstance(anchor, Mapping):
        raise AgentStateError("agent_state_human_interaction_anchor_invalid")
    _require_exact_keys(
        anchor,
        {
            "control_phase",
            "graph_revision",
            "node_id",
            "attempt_index",
            "step_index",
        },
        "human_interaction_anchor",
    )
    if (
        not isinstance(anchor["control_phase"], str)
        or not isinstance(anchor["graph_revision"], int)
        or anchor["graph_revision"] < 0
        or not isinstance(anchor["node_id"], str)
        or not isinstance(anchor["attempt_index"], int)
        or anchor["attempt_index"] < 0
        or not isinstance(anchor["step_index"], int)
        or anchor["step_index"] < 0
    ):
        raise AgentStateError("agent_state_human_interaction_anchor_invalid")

    if status == "idle":
        if value != empty_human_interaction_state():
            raise AgentStateError("agent_state_human_interaction_idle_invalid")
        return
    if value["scope"] not in {
        "step",
        "attempt",
        "graph_replan",
        "frame",
        "task_formulation",
        "evaluation_build",
        "evaluation_judgment",
    }:
        raise AgentStateError("agent_state_human_interaction_scope_invalid")
    if value["expected_response_role"] not in {
        "feedback",
        "scientific_input",
        "task_contract_change",
    }:
        raise AgentStateError("agent_state_human_interaction_role_invalid")
    if not all(
        value[field].strip()
        for field in ("request_id", "requester", "question", "reason")
    ):
        raise AgentStateError("agent_state_human_interaction_required_text_missing")
    if status == "pending" and value["response_ref"]:
        raise AgentStateError("agent_state_human_interaction_pending_response_forbidden")
    if status == "answered" and not value["response_ref"].startswith("artifact:"):
        raise AgentStateError("agent_state_human_interaction_response_ref_invalid")


def _validate_node_loop_state(value: Any) -> None:
    if not isinstance(value, Mapping):
        raise AgentStateError("agent_state_node_loop_invalid")
    _require_exact_keys(
        value,
        {
            "node_id",
            "attempt_index",
            "steps",
            "produced_refs",
            "next_step_index",
            "awaiting_transition",
        },
        "node_loop",
    )
    node_id = value["node_id"]
    attempt_index = value["attempt_index"]
    steps = value["steps"]
    produced_refs = value["produced_refs"]
    next_step_index = value["next_step_index"]
    awaiting_transition = value["awaiting_transition"]
    if not isinstance(node_id, str):
        raise AgentStateError("agent_state_node_loop_node_id_invalid")
    if not isinstance(attempt_index, int) or not 0 <= attempt_index <= 2:
        raise AgentStateError("agent_state_node_loop_attempt_invalid")
    if not isinstance(steps, list):
        raise AgentStateError("agent_state_node_loop_steps_invalid")
    for step in steps:
        if not isinstance(step, Mapping):
            raise AgentStateError("agent_state_node_loop_step_invalid")
        _require_exact_keys(
            step,
            {
                "skill_id",
                "purpose",
                "cost",
                "input_refs",
                "research_mode",
            },
            "node_loop_step",
        )
        if not isinstance(step["skill_id"], str) or not step["skill_id"]:
            raise AgentStateError("agent_state_node_loop_skill_invalid")
        if not isinstance(step["purpose"], str) or not step["purpose"]:
            raise AgentStateError("agent_state_node_loop_purpose_invalid")
        if step["cost"] not in {1, 3, 6}:
            raise AgentStateError("agent_state_node_loop_cost_invalid")
        input_refs = step["input_refs"]
        if (
            not isinstance(input_refs, list)
            or not all(isinstance(ref, str) and ref for ref in input_refs)
            or len(input_refs) != len(set(input_refs))
        ):
            raise AgentStateError("agent_state_node_loop_input_refs_invalid")
        _validate_node_loop_research_mode(
            step["research_mode"],
            input_refs=frozenset(input_refs),
        )
    if (
        not isinstance(produced_refs, list)
        or not all(isinstance(ref, str) and ref for ref in produced_refs)
        or len(produced_refs) != len(set(produced_refs))
    ):
        raise AgentStateError("agent_state_node_loop_produced_refs_invalid")
    if (
        not isinstance(next_step_index, int)
        or next_step_index < 0
        or next_step_index > len(steps)
    ):
        raise AgentStateError("agent_state_node_loop_next_step_invalid")
    if not isinstance(awaiting_transition, bool):
        raise AgentStateError("agent_state_node_loop_transition_flag_invalid")
    if not node_id:
        if (
            attempt_index
            or steps
            or produced_refs
            or next_step_index
            or awaiting_transition
        ):
            raise AgentStateError("agent_state_node_loop_empty_state_invalid")
        return
    if attempt_index < 1:
        raise AgentStateError("agent_state_node_loop_active_attempt_required")
    if steps and sum(int(step["cost"]) for step in steps) > 10:
        raise AgentStateError("agent_state_node_loop_cost_limit_exceeded")
    if awaiting_transition and next_step_index != len(steps):
        raise AgentStateError("agent_state_node_loop_transition_not_at_end")




def _ensure_node_loop_research_mode_fields(value: Mapping[str, Any]) -> None:
    steps = value.get("steps")
    if not isinstance(steps, list):
        return
    for step in steps:
        if isinstance(step, dict):
            step.setdefault("research_mode", None)


def _validate_node_loop_research_mode(
    raw: Any,
    *,
    input_refs: frozenset[str],
) -> None:
    if raw is None:
        return
    if not isinstance(raw, Mapping):
        raise AgentStateError("agent_state_node_loop_research_mode_invalid")
    _require_exact_keys(
        raw,
        {
            "task_source",
            "research_strategy",
            "commissioned_input_refs",
        },
        "node_loop_research_mode",
    )
    task_source = raw["task_source"]
    strategy = raw["research_strategy"]
    commissioned_refs = raw["commissioned_input_refs"]
    if task_source not in {"autonomous", "commissioned"}:
        raise AgentStateError("agent_state_node_loop_task_source_invalid")
    if strategy not in {"deepen", "explore"}:
        raise AgentStateError("agent_state_node_loop_strategy_invalid")
    if (
        not isinstance(commissioned_refs, list)
        or not all(isinstance(ref, str) and ref for ref in commissioned_refs)
        or len(commissioned_refs) != len(set(commissioned_refs))
        or not set(commissioned_refs).issubset(input_refs)
        or (task_source == "autonomous" and commissioned_refs)
    ):
        raise AgentStateError("agent_state_node_loop_commissioned_refs_invalid")


def _active_node_id(graph: Mapping[str, Any]) -> str:
    raw_nodes = graph.get("nodes")
    if not isinstance(raw_nodes, list):
        return ""
    return next(
        (
            str(node.get("node_id") or "")
            for node in raw_nodes
            if isinstance(node, Mapping) and node.get("status") == "in_progress"
        ),
        "",
    )


def _current_receipts(
    receipts: list[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Keep active source and development lifecycles in the bounded C1 window."""
    normalized = [dict(receipt) for receipt in receipts]
    if len(normalized) <= _RECENT_RECEIPT_LIMIT:
        return normalized

    project_anchor_index = -1
    project_id = ""
    for index, receipt in enumerate(normalized):
        tool = str(receipt.get("tool") or "")
        if tool not in {
            "development_project_open",
            "development_project_configure",
        }:
            continue
        result = receipt.get("result")
        if not isinstance(result, Mapping):
            continue
        if str(result.get("status") or "") != "development_project_ready":
            continue
        candidate_id = str(result.get("project_id") or "")
        if not candidate_id:
            continue
        project_anchor_index = index
        project_id = candidate_id

    # A continued node attempt reuses the mutable project without reopening it.
    # In that case the current-revision lifecycle receipts are the authority for
    # project identity and must not be treated as unrelated generic history.
    if not project_id:
        for receipt in reversed(normalized):
            tool = str(receipt.get("tool") or "")
            if not (
                tool.startswith("development_project_")
                or tool == "scientific_materializer_run_project"
            ):
                continue
            result = receipt.get("result")
            if not isinstance(result, Mapping):
                continue
            candidate_id = str(result.get("project_id") or "")
            if candidate_id:
                project_id = candidate_id
                break

    project_priority_indexes: list[int] = []
    if project_id:
        latest_binding_index = -1
        latest_mutation_index = -1
        latest_validation_index = -1
        latest_diff_index = -1
        latest_checkpoint_index = -1
        latest_code_query_index = -1
        latest_execution_index = -1
        mutation_statuses = {
            "development_project_file_written",
            "development_project_files_imported",
            "development_project_file_edited",
            "development_project_path_moved",
            "development_project_path_deleted",
            "development_project_snapshot_restored",
        }
        lifecycle_start = project_anchor_index + 1 if project_anchor_index >= 0 else 0
        for index in range(lifecycle_start, len(normalized)):
            receipt = normalized[index]
            tool = str(receipt.get("tool") or "")
            result = receipt.get("result")
            if not isinstance(result, Mapping):
                continue
            status = str(result.get("status") or "")
            result_project_id = str(result.get("project_id") or "")
            if result_project_id and result_project_id != project_id:
                continue
            if not result_project_id and project_anchor_index < 0:
                continue
            if (
                tool == "development_project_bind_managed_routes"
                and status == "managed_route_broker_ready"
            ):
                latest_binding_index = index
            if status in mutation_statuses:
                latest_mutation_index = index
            if status in {
                "development_syntax_passed",
                "development_syntax_failed",
            }:
                latest_validation_index = index
            if status == "development_project_diff_ready":
                latest_diff_index = index
            if status == "development_project_checkpoint_created":
                latest_checkpoint_index = index
            if status in {
                "development_code_query_ready",
                "development_code_query_unsupported",
            }:
                latest_code_query_index = index
            if tool == "scientific_materializer_run_project":
                latest_execution_index = index
        # Once execution has been attempted, its exact result is more useful
        # for repair than the last structural query that preceded it.
        if latest_execution_index >= 0:
            latest_code_query_index = -1
        project_priority_indexes.extend(
            index
            for index in (
                latest_validation_index,
                latest_diff_index,
                latest_checkpoint_index,
                project_anchor_index,
                latest_mutation_index,
                latest_execution_index,
                latest_binding_index,
                latest_code_query_index,
            )
            if index >= 0
        )

    inventory_index = -1
    latest_source_read_indexes: dict[str, int] = {}
    source_execution_index = -1
    source_execution_refs: set[str] = set()
    for index, receipt in enumerate(normalized):
        tool = str(receipt.get("tool") or "")
        result = receipt.get("result")
        if not isinstance(result, Mapping):
            continue
        status = str(result.get("status") or "")
        if tool == "source_inventory" and status == "source_inventory_ready":
            inventory_index = index
            continue
        if tool in {"read_ref", "source_read"} and status == "source_page_ready":
            source_ref = str(result.get("source_ref") or "")
            if source_ref.startswith("source_file:"):
                latest_source_read_indexes[source_ref] = index
            continue
        if tool not in {"source_probe", "workspace_terminal"}:
            continue
        ref_prefix = (
            "source_probe:"
            if tool == "source_probe"
            else "workspace_terminal:"
        )
        ref_keys = (
            ("code_ref", "stdout_ref", "stderr_ref", "manifest_ref")
            if tool == "source_probe"
            else ("command_ref", "stdout_ref", "stderr_ref", "manifest_ref")
        )
        refs = {
            str(result.get(key) or "")
            for key in ref_keys
            if str(result.get(key) or "").startswith(ref_prefix)
        }
        if not refs:
            continue
        source_execution_index = index
        source_execution_refs = refs

    priority_indexes: list[int] = []
    latest_step_call_budget_index = next(
        (
            index
            for index in range(len(normalized) - 1, -1, -1)
            if str(normalized[index].get("receipt_kind") or "")
            == "node_loop_step_model_call_budget"
        ),
        -1,
    )
    if latest_step_call_budget_index >= 0:
        priority_indexes.append(latest_step_call_budget_index)
    priority_indexes.append(len(normalized) - 1)
    priority_indexes.extend(project_priority_indexes)
    if source_execution_index >= 0:
        priority_indexes.append(source_execution_index)
        latest_read_indexes: dict[str, int] = {}
        for index in range(source_execution_index + 1, len(normalized)):
            receipt = normalized[index]
            if str(receipt.get("tool") or "") not in {"read_ref", "source_read"}:
                continue
            result = receipt.get("result")
            if not isinstance(result, Mapping):
                continue
            source_ref = str(result.get("source_ref") or "")
            if source_ref in source_execution_refs:
                latest_read_indexes[source_ref] = index
        priority_indexes.extend(
            sorted(latest_read_indexes.values(), reverse=True)
        )
    if inventory_index >= 0:
        priority_indexes.append(inventory_index)
    if source_execution_index < 0:
        priority_indexes.extend(
            sorted(latest_source_read_indexes.values(), reverse=True)
        )

    selected: set[int] = set()
    for index in priority_indexes:
        if len(selected) >= _RECENT_RECEIPT_LIMIT:
            break
        selected.add(index)
    for index in range(len(normalized) - 1, -1, -1):
        if len(selected) >= _RECENT_RECEIPT_LIMIT:
            break
        selected.add(index)
    return [normalized[index] for index in sorted(selected)]
