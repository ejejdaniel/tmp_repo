from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Iterator, Mapping, Sequence
from uuid import uuid4


class WorkMemoryError(ValueError):
    pass


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _refs(values: Sequence[str]) -> list[str]:
    if isinstance(values, (str, bytes)):
        raise WorkMemoryError("work_source_refs_must_be_array")
    refs = list(dict.fromkeys(str(value).strip() for value in values))
    if any(not value for value in refs):
        raise WorkMemoryError("work_source_ref_empty")
    return refs


class WorkMemoryStore:
    """Project-local C3 notes and C4 operation receipts, never a second plan."""

    def __init__(self, path: Path) -> None:
        self.path = path.resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            version = db.execute("PRAGMA user_version").fetchone()[0]
            if version not in (0, 1, 2):
                raise WorkMemoryError(f"work_memory_version_unsupported:{version}")
            db.executescript(
                """
                CREATE TABLE IF NOT EXISTS contexts (
                    context_ref TEXT PRIMARY KEY,
                    owner_agent_id TEXT NOT NULL,
                    title TEXT NOT NULL,
                    input_refs TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS entries (
                    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                    entry_ref TEXT NOT NULL UNIQUE,
                    context_ref TEXT NOT NULL REFERENCES contexts(context_ref),
                    source_event_id TEXT NOT NULL,
                    entry_kind TEXT NOT NULL CHECK(entry_kind IN ('note','tool_result','import')),
                    source_refs TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    UNIQUE(context_ref, source_event_id)
                );
                CREATE INDEX IF NOT EXISTS work_entries_context
                    ON entries(context_ref, sequence);
                CREATE TABLE IF NOT EXISTS summaries (
                    context_ref TEXT NOT NULL REFERENCES contexts(context_ref),
                    view_key TEXT NOT NULL,
                    through_sequence INTEGER NOT NULL,
                    markdown TEXT NOT NULL,
                    source_refs TEXT NOT NULL,
                    PRIMARY KEY(context_ref, view_key)
                );
                CREATE TABLE IF NOT EXISTS dialogue_memory (
                    dialogue_id TEXT PRIMARY KEY,
                    summary_markdown TEXT NOT NULL,
                    through_message_count INTEGER NOT NULL
                        CHECK(through_message_count >= 0)
                );
                PRAGMA user_version=2;
                """
            )

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        db = sqlite3.connect(self.path, timeout=30)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        try:
            with db:
                yield db
        finally:
            db.close()

    def create_context(
        self, *, owner_agent_id: str, title: str, input_refs: Sequence[str] = ()
    ) -> str:
        if not owner_agent_id.strip() or not title.strip():
            raise WorkMemoryError("work_context_owner_and_title_required")
        ref = f"work_context:{uuid4().hex}"
        with self._connect() as db:
            db.execute(
                "INSERT INTO contexts VALUES (?,?,?,?)",
                (ref, owner_agent_id, title, _json(_refs(input_refs))),
            )
        return ref

    def context(self, ref: str, *, agent_id: str) -> dict[str, Any]:
        with self._connect() as db:
            return self._context(db, ref, agent_id)

    @staticmethod
    def _context(db: sqlite3.Connection, ref: str, agent_id: str) -> dict[str, Any]:
        row = db.execute("SELECT * FROM contexts WHERE context_ref=?", (ref,)).fetchone()
        if row is None:
            raise WorkMemoryError(f"work_context_not_found:{ref}")
        if row["owner_agent_id"] != agent_id:
            raise WorkMemoryError(f"work_context_not_owned:{ref}")
        result = dict(row)
        result["input_refs"] = json.loads(result["input_refs"])
        return result

    @staticmethod
    def _entry(db: sqlite3.Connection, ref: str) -> dict[str, Any]:
        row = db.execute("SELECT * FROM entries WHERE entry_ref=?", (ref,)).fetchone()
        if row is None:
            raise WorkMemoryError(f"work_entry_not_found:{ref}")
        result = dict(row)
        result["source_refs"] = json.loads(result["source_refs"])
        result["payload"] = json.loads(result["payload"])
        return result

    @staticmethod
    def _visible(db: sqlite3.Connection, ref: str, agent_id: str) -> bool:
        # Imports point only to existing immutable rows, so their graph is acyclic.
        pending = [ref]
        seen: set[str] = set()
        while pending:
            target = pending.pop()
            if target in seen:
                continue
            seen.add(target)
            row = db.execute(
                "SELECT c.owner_agent_id FROM entries e JOIN contexts c "
                "ON c.context_ref=e.context_ref WHERE e.entry_ref=?", (target,)
            ).fetchone()
            if row is None:
                return False
            if row[0] == agent_id:
                return True
            pending.extend(
                item[0] for item in db.execute(
                    "SELECT entry_ref FROM entries WHERE entry_kind='import' "
                    "AND json_extract(payload, '$.entry_ref')=?", (target,)
                )
            )
        return False

    def can_read(self, ref: str, *, agent_id: str) -> bool:
        with self._connect() as db:
            if ref.startswith("work_context:"):
                row = db.execute(
                    "SELECT owner_agent_id FROM contexts WHERE context_ref=?", (ref,)
                ).fetchone()
                return row is not None and row[0] == agent_id
            return self._visible(db, ref, agent_id)

    def read_entry(self, ref: str, *, agent_id: str) -> dict[str, Any]:
        with self._connect() as db:
            if not self._visible(db, ref, agent_id):
                raise WorkMemoryError(f"work_entry_not_visible:{ref}")
            return self._entry(db, ref)

    def entry_owner(self, ref: str, *, agent_id: str) -> str:
        with self._connect() as db:
            if not self._visible(db, ref, agent_id):
                raise WorkMemoryError(f"work_entry_not_visible:{ref}")
            return db.execute(
                "SELECT c.owner_agent_id FROM contexts c JOIN entries e "
                "ON c.context_ref=e.context_ref WHERE e.entry_ref=?", (ref,)
            ).fetchone()[0]

    def append(
        self,
        context_ref: str,
        *,
        agent_id: str,
        source_event_id: str,
        entry_kind: str,
        payload: Mapping[str, Any],
        source_refs: Sequence[str] = (),
    ) -> dict[str, Any]:
        if not source_event_id.strip():
            raise WorkMemoryError("work_source_event_id_required")
        expected = {
            "note": {"markdown"},
            "tool_result": {"call_id", "tool_name", "executed_arguments", "result"},
        }.get(entry_kind)
        if expected is None or set(payload) != expected:
            raise WorkMemoryError("work_entry_payload_invalid")
        if entry_kind == "note" and (
            not isinstance(payload["markdown"], str) or not payload["markdown"].strip()
        ):
            raise WorkMemoryError("work_note_empty")
        if entry_kind == "tool_result" and (
            not isinstance(payload["call_id"], str)
            or not isinstance(payload["tool_name"], str)
            or not isinstance(payload["executed_arguments"], Mapping)
            or not isinstance(payload["result"], Mapping)
        ):
            raise WorkMemoryError("work_operation_invalid")
        with self._connect() as db:
            self._context(db, context_ref, agent_id)
            return self._append(
                db, context_ref, source_event_id, entry_kind, dict(payload), _refs(source_refs)
            )

    def _append(
        self, db: sqlite3.Connection, context_ref: str, event_id: str,
        kind: str, payload: Mapping[str, Any], refs: Sequence[str],
    ) -> dict[str, Any]:
        previous = db.execute(
            "SELECT entry_ref FROM entries WHERE context_ref=? AND source_event_id=?",
            (context_ref, event_id),
        ).fetchone()
        if previous:
            entry = self._entry(db, previous[0])
            if (entry["entry_kind"], entry["payload"], entry["source_refs"]) != (
                kind, dict(payload), list(refs)
            ):
                raise WorkMemoryError("work_event_identity_conflict")
            return entry
        ref = f"work_entry:{uuid4().hex}"
        db.execute(
            "INSERT INTO entries(entry_ref,context_ref,source_event_id,entry_kind,source_refs,payload) "
            "VALUES (?,?,?,?,?,?)",
            (ref, context_ref, event_id, kind, _json(refs), _json(payload)),
        )
        return self._entry(db, ref)

    def import_entries(
        self, context_ref: str, *, agent_id: str, entry_refs: Sequence[str],
        authorized_refs: Sequence[str],
    ) -> tuple[str, ...]:
        requested = _refs(entry_refs)
        if not set(requested).issubset(authorized_refs):
            raise WorkMemoryError("work_import_not_explicitly_authorized")
        with self._connect() as db:
            self._context(db, context_ref, agent_id)
            for ref in requested:
                self._entry(db, ref)
            imported = [
                self._append(
                    db, context_ref, f"import:{ref}", "import", {"entry_ref": ref}, [ref]
                )["entry_ref"] for ref in requested
            ]
        return tuple(imported)

    def entries(
        self, context_ref: str, *, agent_id: str, after_sequence: int = 0
    ) -> list[dict[str, Any]]:
        with self._connect() as db:
            self._context(db, context_ref, agent_id)
            refs = db.execute(
                "SELECT entry_ref FROM entries WHERE context_ref=? AND sequence>? ORDER BY sequence",
                (context_ref, after_sequence),
            ).fetchall()
            return [self._entry(db, row[0]) for row in refs]

    def materialized_entries(
        self, context_ref: str, *, agent_id: str, after_sequence: int = 0,
        allow_sources: Callable[[Sequence[str]], bool] | None = None,
    ) -> list[tuple[int, dict[str, Any]]]:
        """Return local coverage positions separately from original source order."""
        with self._connect() as db:
            self._context(db, context_ref, agent_id)
            rows = db.execute(
                "SELECT entry_ref,sequence FROM entries WHERE context_ref=? AND sequence>? "
                "ORDER BY sequence", (context_ref, after_sequence)
            ).fetchall()
            seen: set[str] = set()
            result: list[tuple[int, dict[str, Any]]] = []
            for row in rows:
                entry = self._entry(db, row["entry_ref"])
                while entry["entry_kind"] == "import":
                    entry = self._entry(db, entry["payload"]["entry_ref"])
                ref = entry["entry_ref"]
                if ref in seen or (allow_sources and not allow_sources(entry["source_refs"])):
                    continue
                seen.add(ref)
                result.append((int(row["sequence"]), entry))
            return result

    def summary(self, context_ref: str, *, agent_id: str, view_key: str) -> dict[str, Any]:
        with self._connect() as db:
            self._context(db, context_ref, agent_id)
            row = db.execute(
                "SELECT * FROM summaries WHERE context_ref=? AND view_key=?",
                (context_ref, view_key),
            ).fetchone()
            if row is None:
                return {"context_ref": context_ref, "view_key": view_key,
                        "through_sequence": 0, "markdown": "", "source_refs": []}
            result = dict(row)
            result["source_refs"] = json.loads(result["source_refs"])
            return result

    def commit_summary(
        self, context_ref: str, *, agent_id: str, view_key: str,
        through_sequence: int, markdown: str, source_refs: Sequence[str],
        rebuild_view: bool = False,
    ) -> None:
        if not view_key or not isinstance(markdown, str) or not markdown.strip():
            raise WorkMemoryError("work_summary_empty")
        if isinstance(through_sequence, bool) or not isinstance(through_sequence, int):
            raise WorkMemoryError("work_summary_cursor_invalid")
        with self._connect() as db:
            self._context(db, context_ref, agent_id)
            upper = db.execute(
                "SELECT COALESCE(MAX(sequence),0) FROM entries WHERE context_ref=?", (context_ref,)
            ).fetchone()[0]
            previous = db.execute(
                "SELECT through_sequence FROM summaries WHERE context_ref=? AND view_key=?",
                (context_ref, view_key),
            ).fetchone()
            if not 0 <= through_sequence <= upper or (previous and through_sequence < previous[0] and not rebuild_view):
                raise WorkMemoryError("work_summary_cursor_invalid")
            db.execute(
                "INSERT INTO summaries VALUES (?,?,?,?,?) ON CONFLICT(context_ref,view_key) "
                "DO UPDATE SET through_sequence=excluded.through_sequence, "
                "markdown=excluded.markdown,source_refs=excluded.source_refs",
                (context_ref, view_key, through_sequence, markdown, _json(_refs(source_refs))),
            )

    def last_source_event_sequence(self, *, agent_id: str) -> int:
        prefix = agent_id + ":"
        with self._connect() as db:
            rows = db.execute(
                "SELECT e.source_event_id FROM entries e JOIN contexts c USING(context_ref) "
                "WHERE c.owner_agent_id=?", (agent_id,),
            )
            positions = (row[0][len(prefix):].split(":", 1)[0]
                         for row in rows if row[0].startswith(prefix))
            return max((int(value) for value in positions if value.isdigit()), default=0)

    def dialogue_memory(self, dialogue_id: str) -> dict[str, Any]:
        """Read one run-scoped C3 dialogue navigation summary."""
        normalized = str(dialogue_id).strip()
        if not normalized:
            raise WorkMemoryError("dialogue_memory_id_required")
        with self._connect() as db:
            row = db.execute(
                "SELECT dialogue_id,summary_markdown,through_message_count "
                "FROM dialogue_memory WHERE dialogue_id=?",
                (normalized,),
            ).fetchone()
        if row is None:
            return {
                "dialogue_id": normalized,
                "summary_markdown": "",
                "through_message_count": 0,
            }
        return dict(row)

    def commit_dialogue_memory(
        self,
        dialogue_id: str,
        *,
        summary_markdown: str,
        through_message_count: int,
    ) -> None:
        """Atomically replace a dialogue summary and its exact C4 cursor."""
        normalized = str(dialogue_id).strip()
        if not normalized:
            raise WorkMemoryError("dialogue_memory_id_required")
        if not isinstance(summary_markdown, str):
            raise WorkMemoryError("dialogue_memory_summary_invalid")
        if (
            isinstance(through_message_count, bool)
            or not isinstance(through_message_count, int)
            or through_message_count < 0
        ):
            raise WorkMemoryError("dialogue_memory_cursor_invalid")
        if through_message_count and not summary_markdown.strip():
            raise WorkMemoryError("dialogue_memory_summary_required")
        with self._connect() as db:
            previous = db.execute(
                "SELECT through_message_count FROM dialogue_memory "
                "WHERE dialogue_id=?",
                (normalized,),
            ).fetchone()
            if previous is not None and through_message_count < int(previous[0]):
                raise WorkMemoryError("dialogue_memory_cursor_cannot_move_backward")
            db.execute(
                "INSERT INTO dialogue_memory("
                "dialogue_id,summary_markdown,through_message_count) "
                "VALUES (?,?,?) ON CONFLICT(dialogue_id) DO UPDATE SET "
                "summary_markdown=excluded.summary_markdown,"
                "through_message_count=excluded.through_message_count",
                (normalized, summary_markdown, through_message_count),
            )

    def list(
        self, *, agent_id: str, context_ref: str | None = None,
        query: str = "", cursor: int = 0, limit: int = 8,
        allow_sources: Callable[[Sequence[str]], bool] | None = None,
    ) -> dict[str, Any]:
        if cursor < 0 or not 1 <= limit <= 20:
            raise WorkMemoryError("work_memory_page_invalid")
        with self._connect() as db:
            if context_ref:
                self._context(db, context_ref, agent_id)
                rows = db.execute(
                    "SELECT * FROM entries WHERE context_ref=? ORDER BY sequence DESC", (context_ref,)
                ).fetchall()
                items = []
                for row in rows:
                    entry = self._entry(db, row["entry_ref"])
                    original = entry
                    while original["entry_kind"] == "import":
                        original = self._entry(db, original["payload"]["entry_ref"])
                    if allow_sources and not allow_sources(original["source_refs"]):
                        continue
                    payload = original["payload"]
                    if query and query.casefold() not in _json(original).casefold():
                        continue
                    text = str(payload.get("markdown") or payload.get("tool_name") or payload.get("entry_ref"))
                    items.append({"ref": entry["entry_ref"], "kind": entry["entry_kind"],
                                  "title": text.splitlines()[0][:160], "excerpt": _json(payload)[:600],
                                  "source_refs": entry["source_refs"]})
            else:
                rows = db.execute(
                    "SELECT * FROM contexts WHERE owner_agent_id=? ORDER BY rowid DESC", (agent_id,)
                ).fetchall()
                items = [{"ref": row["context_ref"], "kind": "context", "title": row["title"],
                          "excerpt": row["title"], "source_refs": json.loads(row["input_refs"])}
                         for row in rows]
        if allow_sources and not context_ref:
            items = [item for item in items if allow_sources(item["source_refs"])]
        if query and not context_ref:
            needle = query.casefold()
            items = [item for item in items if needle in _json(item).casefold()]
        total = len(items)
        return {"items": items[cursor:cursor + limit], "total": total,
                "next_cursor": cursor + limit if cursor + limit < total else None}

    def owned_entries(self, *, agent_id: str) -> list[dict[str, Any]]:
        with self._connect() as db:
            rows = db.execute(
                "SELECT e.entry_ref FROM entries e JOIN contexts c ON e.context_ref=c.context_ref "
                "WHERE c.owner_agent_id=? ORDER BY e.sequence", (agent_id,)
            ).fetchall()
            return [self._entry(db, row[0]) for row in rows]
