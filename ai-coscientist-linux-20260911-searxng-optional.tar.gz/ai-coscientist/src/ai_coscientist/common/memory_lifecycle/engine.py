from __future__ import annotations

import copy
import json
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from .events import EventLog
from ..model import ChatModel, ModelTurn, complete_model_turn
from ..openai_compatible import ModelProtocolError, visible_tool_protocol_issue
from .prompt import (
    bounded_projection,
    bounded_text,
    tool_call_prompt_projection,
    tool_result_prompt_projection,
)
from .policy import (
    PromptBudgetExceeded,
    PromptSource,
    prompt_projection_receipt,
)
from .state import AgentStateStore
from .work_context import WorkContext
from .work_store import WorkMemoryStore


_C3_REDUCTION_THRESHOLD = 8_000
_C3_SUMMARY_TARGET = 6_000
_C3_DELTA_PURPOSE = "extract C3 semantic memory delta"
_C3_CURATE_PURPOSE = "curate C3 continuity memory"
_C3_RECOMPACTION_PURPOSE = "semantically reduce oversized C3 memory"


class _CompactionOutputRejected(RuntimeError):
    def __init__(self, reason: str, *, candidate: str = "") -> None:
        super().__init__(reason)
        self.reason = reason
        self.candidate = candidate


def _bounded_failed_tool_arguments(
    arguments: Mapping[str, Any],
    *,
    result_event: Mapping[str, Any],
    prompt_budget_bytes: int,
) -> dict[str, Any] | None:
    """Keep a rejected authored payload available for the immediate repair."""
    raw_result = result_event.get("raw_result")
    if not isinstance(raw_result, Mapping) or raw_result.get("status") != "tool_error":
        return None
    try:
        encoded = json.dumps(
            arguments,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
    except (TypeError, ValueError):
        return None
    recovery_budget = max(8_000, int(prompt_budget_bytes) // 4)
    if len(encoded) > recovery_budget:
        return None
    return copy.deepcopy(dict(arguments))


def _json_bytes(value: Any) -> int:
    return len(
        json.dumps(
            value,
            ensure_ascii=False,
            separators=(",", ":"),
            default=str,
        ).encode("utf-8")
    )


def _deduplicate_page_bodies(
    events: Sequence[Mapping[str, Any]],
) -> list[Mapping[str, Any]]:
    """Elide only byte-identical page reads; retain every call and receipt."""
    seen: dict[str, str] = {}
    replacements: dict[int, Mapping[str, Any]] = {}
    for index in sorted(range(len(events)), key=lambda i: int(
        events[i].get("source_sequence", events[i].get("event_sequence", 0))
    ), reverse=True):
        event = events[index]
        result = event.get("raw_result")
        projection = event.get("prompt_projection")
        if (event.get("event_type") != "tool_result"
                or not isinstance(result, Mapping)
                or not isinstance(projection, Mapping)
                or result.get("status") == "tool_error"
                or not isinstance(result.get("content"), str)
                or not result["content"]
                or not {"line_offset", "line_count", "next_line_offset"} <= result.keys()
                or projection.get("content") != result["content"]):
            continue
        identity = json.dumps(
            [event.get("tool"), event.get("executed_arguments"), result],
            ensure_ascii=False, sort_keys=True, separators=(",", ":"),
        )
        if identity in seen:
            replacements[index] = {
                **event,
                "prompt_projection": {
                    **projection,
                    "content": (
                        "[Duplicate page body omitted from this prompt; the identical "
                        "page is retained below in completed tool call " + seen[identity] + ".]"
                    ),
                },
            }
        else:
            seen[identity] = str(event.get("call_id") or "")
    return [replacements.get(index, event) for index, event in enumerate(events)]


class SkillStageMemory:
    """Owns one skill-local C5 stage and clears it at the stage boundary."""

    def __init__(
        self,
        *,
        events: EventLog,
        skill_id: str,
        round_number: int,
    ) -> None:
        self._events = events
        self._skill_id = skill_id
        self._round_number = round_number
        self._state: dict[str, Any] = {}

    def start(
        self,
        *,
        stage_index: int,
        purpose: str,
        output_schema: Mapping[str, Any],
    ) -> None:
        if self._state:
            raise RuntimeError("skill_workflow_c5_stage_already_active")
        properties = output_schema.get("properties")
        required = output_schema.get("required")
        self._state = {
            "stage_index": stage_index,
            "purpose": purpose,
            "attempt": 0,
            "field_names": (
                sorted(properties) if isinstance(properties, Mapping) else []
            ),
            "required_fields": (
                list(required) if isinstance(required, list) else []
            ),
            "issues": [],
            "repair_projection": {},
        }
        self._events.append(
            "skill_workflow_c5_stage_started",
            {
                "round": self._round_number,
                "skill_id": self._skill_id,
                "stage_index": self._state["stage_index"],
                "purpose": self._state["purpose"],
                "attempt": self._state["attempt"],
                "field_names": self._state["field_names"],
                "required_fields": self._state["required_fields"],
            },
        )

    def request_repair(self, issues: list[str]) -> None:
        self._require_active()
        self._state["attempt"] = 1
        self._state["issues"] = [
            bounded_text(str(issue), 1_000) for issue in issues[:12]
        ]
        self._events.append(
            "skill_workflow_c5_stage_repair",
            {
                "round": self._round_number,
                "skill_id": self._skill_id,
                "stage_index": self._state["stage_index"],
                "purpose": self._state["purpose"],
                "attempt": self._state["attempt"],
                "issues": list(self._state["issues"]),
            },
        )

    def set_repair_projection(
        self,
        previous_attempt: Mapping[str, Any],
    ) -> None:
        self._require_active()
        self._state["repair_projection"] = copy.deepcopy(
            bounded_projection(
                dict(previous_attempt),
                max_depth=8,
                max_items=12,
                max_mapping_items=48,
                max_text_chars=8_000,
            )
        )

    def repair_projection(self) -> dict[str, Any]:
        self._require_active()
        return copy.deepcopy(dict(self._state["repair_projection"]))

    def clear(self, *, status: str) -> None:
        if not self._state:
            return
        released = self._state
        self._state = {}
        self._events.append(
            "skill_workflow_c5_stage_cleared",
            {
                "round": self._round_number,
                "skill_id": self._skill_id,
                "status": status,
                "stage_index": released["stage_index"],
                "purpose": released["purpose"],
            },
        )

    def ensure_cleared(self) -> None:
        if self._state:
            raise RuntimeError("skill_workflow_c5_stage_not_cleared")

    def _require_active(self) -> None:
        if not self._state:
            raise RuntimeError("skill_workflow_c5_stage_missing")


@dataclass
class MemoryStore:
    """Keep persistent work notes and compact their source-filtered view."""

    state: AgentStateStore
    events: EventLog
    model: ChatModel
    compact_after_chars: int = 16_000
    preserve_recent_events: int | None = None
    prompt_budget_bytes: int = 192_000
    work: WorkContext | None = None
    project_result: Callable[[str, Mapping[str, Any], Mapping[str, Any]], Mapping[str, Any]] | None = None

    def __post_init__(self) -> None:
        if self.work is None:
            self.work = WorkContext(
                WorkMemoryStore(self.state.path.parent / "work-memory.sqlite3"),
                self.state, str(self.state.path),
            )

    def summary(self) -> str:
        return self.work.checkpoint()["markdown"]

    def focused_formal_read_ref(self) -> str:
        """Resolve the latest uncompacted formal read from visible work receipts."""
        refs = self.formal_read_refs()
        return refs[0] if refs else ""

    def formal_read_refs(self) -> tuple[str, ...]:
        """Return visible, uncompacted formal reads, newest first, without bodies."""
        entries = self.work.entries(
            after_sequence=self.work.checkpoint()["through_sequence"],
        )
        refs: list[str] = []
        for _, entry in reversed(entries):
            payload = entry["payload"]
            if (
                entry["entry_kind"] == "tool_result"
                and payload["tool_name"] in {"read_ref", "artifact_read"}
                and payload["result"].get("status") == "artifact_resolved"
            ):
                ref = str(payload["result"].get("artifact_ref") or "")
                if ref and ref not in refs:
                    refs.append(ref)
        return tuple(refs)

    def _work_events(self) -> list[Mapping[str, Any]]:
        events: list[Mapping[str, Any]] = []
        for position, entry in self.work.entries():
            payload = entry["payload"]
            base = {"event_sequence": position, "round": position,
                    "entry_ref": entry["entry_ref"], "source_sequence": entry["sequence"],
                    "source_refs": entry["source_refs"]}
            if entry["entry_kind"] == "note":
                # Old immutable records remain readable for diagnosis, not as
                # ordinary work notes or semantic compaction input.
                if visible_tool_protocol_issue(payload["markdown"]):
                    continue
                events.append({**base, "event_type": "model_turn",
                               "content": payload["markdown"], "tool_calls": []})
                continue
            result = payload["result"]
            projection = (
                self.project_result(payload["tool_name"], payload["executed_arguments"], result)
                if self.project_result else tool_result_prompt_projection(result)
            )
            events.append({**base, "event_type": "model_turn", "content": "",
                           "tool_calls": [{"call_id": payload["call_id"],
                                           "name": payload["tool_name"],
                                           "arguments": payload["executed_arguments"]}]})
            events.append({**base, "event_type": "tool_result", "tool": payload["tool_name"],
                           "call_id": payload["call_id"], "raw_result": result,
                           "executed_arguments": payload["executed_arguments"],
                           "prompt_projection": projection})
        return events

    def prepare_for_model_call(self, *, call_site: str, consumer: str | None = None) -> None:
        """Validate lifecycle partitions and compact before a non-compaction call."""
        site = str(call_site).strip()
        if not site:
            raise ValueError("memory_lifecycle_call_site_required")
        self.work.consumer = consumer or str(self.state.read()["c1"]["active_skill_id"] or site)
        self.state.read()
        self.maintain()
        persisted = self.state.read()
        self.events.append(
            "memory_lifecycle_check",
            {
                "call_site": site,
                "active_skill_id": persisted["c1"]["active_skill_id"],
                "resolved_ref_count": len(
                    persisted["c1"]["resolved_artifact_refs"]
                ),
                "wiki_summary_chars": len(self.summary()),
            },
        )

    def prepare_inspection_prompt(
        self,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
    ) -> list[Mapping[str, Any]]:
        """Keep an oversized new read out of C5, without changing its source."""
        projected = list(messages)
        actual = _json_bytes({"messages": projected, "tools": list(tools)})
        if actual <= self.prompt_budget_bytes or len(projected) < 2:
            return projected
        previous, response = projected[-2:]
        calls = previous.get("tool_calls") or ()
        if response.get("role") != "tool" or len(calls) != 1:
            return projected
        call = calls[0]
        if (call.get("id") != response.get("tool_call_id")
                or call.get("function", {}).get("name") != "read_ref"):
            return projected
        function = call["function"]
        arguments = json.loads(function["arguments"])
        deferred = {
            "error": (
                "inspection_body_not_loaded: the exact read would exceed this prompt's "
                f"budget ({actual} > {self.prompt_budget_bytes} UTF-8 bytes). "
                f"Source: {arguments.get('ref')}. No content from this read is visible. "
                "The source remains unchanged and readable. Use create_reference_link "
                "with a focused field_path or range, then read_ref on that link; "
                "for a paged reference, reduce line_limit. Do not claim to have read "
                "the omitted body."
            )
        }
        projected[-1] = {**response, "content": json.dumps(deferred, ensure_ascii=False)}
        if _json_bytes({"messages": projected, "tools": list(tools)}) >= actual:
            return list(messages)
        self.events.append("skill_inspection_body_deferred", {
            "tool_call": call, "raw_response": response,
            "projection": projected[-1], "actual_bytes": actual,
            "budget_bytes": self.prompt_budget_bytes,
        })
        return projected

    def record_prompt_projection(
        self,
        *,
        call_site: str,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
        sources: Sequence[PromptSource],
        budget_tier: str,
    ) -> Mapping[str, Any]:
        budget_bytes = self._budget_for(budget_tier)
        receipt = prompt_projection_receipt(
            call_site=call_site,
            messages=messages,
            tools=tools,
            sources=sources,
            budget_bytes=budget_bytes,
            budget_tier=budget_tier,
        )
        self.events.append("prompt_projection_receipt", receipt)
        if receipt["status"] == "over_budget":
            largest = sorted(
                receipt["sources"],
                key=lambda source: int(source["bytes"]),
                reverse=True,
            )[:5]
            breakdown = ",".join(
                f"{source['memory_class']}/{source['name']}={source['bytes']}"
                for source in largest
            )
            raise PromptBudgetExceeded(
                "prompt_projection_over_budget:"
                f"call_site={call_site}:actual={receipt['total_bytes']}:"
                f"budget={budget_bytes}:largest_sources={breakdown}",
                receipt=receipt,
            )
        return receipt

    def maintain(self, *, recent_budget_bytes: int | None = None) -> bool:
        all_events = self._work_events()
        pending = self._uncompacted_events(all_events)
        if recent_budget_bytes is None and len(self._serialize(pending)) <= self.compact_after_chars:
            return False
        recent = self._recent_events(
            pending,
            all_events=all_events,
            max_bytes=recent_budget_bytes,
        )
        boundary = len(pending) - len(recent)
        if recent_budget_bytes is not None and pending and pending[-1]["event_type"] == "tool_result":
            # Pressure may summarize the latest note, but not the observation
            # just returned to the model. Preserve its native call/result pair.
            latest = pending[-1]["event_sequence"]
            boundary = min(boundary, next(index for index, event in enumerate(pending)
                                          if event["event_sequence"] == latest))
        compactable = pending[:boundary]
        if not compactable:
            return False
        checkpoint = self.work.checkpoint()
        previous = checkpoint["markdown"]
        compactable, delta_messages = self._fit_compaction_batch(
            compactable,
        )
        try:
            delta = self._complete_compaction_draft(
                call_site="memory-compaction-delta",
                purpose=_C3_DELTA_PURPOSE,
                messages=delta_messages,
                sources=(
                    PromptSource(
                        "instruction",
                        "memory_delta_instruction",
                        delta_messages[0]["content"],
                    ),
                    PromptSource(
                        "C3",
                        "bounded_runtime_event_projection",
                        [
                            self._compaction_event_projection(event)
                            for event in compactable
                        ],
                    ),
                ),
            )
        except _CompactionOutputRejected as exc:
            self._reject_compaction(
                stage="delta",
                candidate=exc.candidate,
                reason=exc.reason,
            )
            return False
        curate_messages = self._curation_messages(
            previous_summary=previous,
            semantic_delta=delta,
        )
        try:
            summary_candidate = self._complete_compaction_draft(
                call_site="memory-compaction-curation",
                purpose=_C3_CURATE_PURPOSE,
                messages=curate_messages,
                sources=(
                    PromptSource(
                        "instruction",
                        "memory_curation_instruction",
                        curate_messages[0]["content"],
                    ),
                    PromptSource("C3", "previous_wiki_summary", previous),
                    PromptSource("C3", "semantic_delta", delta),
                ),
            )
        except PromptBudgetExceeded:
            self._reject_compaction(
                stage="curation",
                candidate="",
                reason="prompt_projection_over_budget",
            )
            return False
        except _CompactionOutputRejected as exc:
            self._reject_compaction(
                stage="curation",
                candidate=exc.candidate,
                reason=exc.reason,
            )
            return False
        summary_candidate = self._reduce_compaction_candidate_once(summary_candidate)
        through_sequence = int(compactable[-1]["event_sequence"])
        stored_checkpoint = self.work.store.summary(
            self.work.ensure(), agent_id=self.work.agent_id, view_key=self.work.view_key,
        )
        self.work.store.commit_summary(
            self.work.ensure(), agent_id=self.work.agent_id, view_key=self.work.view_key,
            markdown=summary_candidate,
            through_sequence=through_sequence,
            rebuild_view=not self.work.allows(stored_checkpoint["source_refs"]),
            source_refs=list(dict.fromkeys([
                *checkpoint["source_refs"],
                *(ref for event in compactable
                  for ref in (event["entry_ref"], *event["source_refs"])),
            ])),
        )
        self.events.append(
            "memory_compaction",
            {
                "through_sequence": through_sequence,
                "summary_chars": len(summary_candidate),
                "version": "c3-v2",
            },
        )
        return True

    def _complete_compaction_draft(
        self,
        *,
        call_site: str,
        purpose: str,
        messages: Sequence[Mapping[str, Any]],
        sources: Sequence[PromptSource],
    ) -> str:
        turn = self._complete_compaction_stage(
            call_site=call_site, purpose=purpose, messages=messages,
            sources=sources, max_output_tokens=None,
        )
        candidate = turn.content.strip()
        if turn.finish_reason == "length":
            raise _CompactionOutputRejected("truncated_output", candidate=candidate)
        if not candidate:
            raise _CompactionOutputRejected("empty_output")
        return candidate

    def _reduce_compaction_candidate_once(self, candidate: str) -> str:
        if len(candidate) <= _C3_REDUCTION_THRESHOLD:
            return candidate
        messages = self._semantic_reduction_messages(candidate)
        try:
            turn = self._complete_compaction_stage(
                call_site="memory-compaction-curation-semantic-reduction",
                purpose=_C3_RECOMPACTION_PURPOSE, messages=messages,
                sources=(
                    PromptSource("instruction", "semantic_reduction_instruction", messages[0]["content"]),
                    PromptSource("C3", "complete_summary_candidate", candidate),
                ),
                max_output_tokens=None, repair=True,
            )
        except PromptBudgetExceeded:
            return candidate
        shorter = turn.content.strip()
        if turn.finish_reason != "length" and shorter and len(shorter) < len(candidate):
            return shorter
        return candidate

    def _complete_compaction_stage(
        self,
        *,
        call_site: str,
        purpose: str,
        messages: Sequence[Mapping[str, Any]],
        sources: Sequence[PromptSource],
        max_output_tokens: int | None,
        repair: bool = False,
    ) -> ModelTurn:
        persisted = self.state.read()
        self.events.append(
            "memory_lifecycle_check",
            {
                "call_site": call_site,
                "active_skill_id": persisted["c1"]["active_skill_id"],
                "resolved_ref_count": len(
                    persisted["c1"]["resolved_artifact_refs"]
                ),
                "wiki_summary_chars": len(self.summary()),
            },
        )
        self.events.append(
            "memory_compaction_prompt_snapshot",
            {"messages": list(messages), "purpose": purpose},
        )
        self.record_prompt_projection(
            call_site=call_site,
            messages=messages,
            tools=(),
            sources=sources,
            budget_tier="compact",
        )
        try:
            turn = complete_model_turn(
                self.model,
                messages=messages,
                tools=(),
                purpose=purpose,
                repair=repair,
                without_reasoning=not repair,
                max_output_tokens=max_output_tokens,
            )
        except ModelProtocolError as exc:
            if str(exc) not in {"model_output_limit_without_answer", "empty_model_turn_after_retry"}:
                raise
            turn = ModelTurn(finish_reason=(
                "length" if str(exc) == "model_output_limit_without_answer" else "stop"
            ))
        self._record_compaction_model_turn(
            turn,
            purpose=purpose,
            max_output_tokens=max_output_tokens,
        )
        return turn

    def _reject_compaction(
        self,
        *,
        stage: str,
        candidate: str,
        reason: str = "empty_output",
    ) -> None:
        self.events.append(
            "memory_compaction_rejected",
            {
                "stage": stage,
                "reason": reason,
                "candidate_chars": len(candidate),
            },
        )

    @staticmethod
    def _semantic_reduction_messages(
        candidate: str,
    ) -> list[Mapping[str, Any]]:
        return [
            {
                "role": "system",
                "content": (
                    "You write concise work-continuity memory. Select information "
                    "under the supplied priorities; preserve the meaning and "
                    "qualifications of retained claims without inventing facts. Return ordinary "
                    "Markdown; no fixed headings are required."
                ),
            },
            {
                "role": "user",
                "content": _C3_RECOMPACTION_PROMPT.format(
                    summary=candidate,
                    target_chars=_C3_SUMMARY_TARGET,
                    selection_rules=_C3_CONTINUITY_SELECTION_RULES,
                ),
            },
        ]

    def _record_compaction_model_turn(
        self,
        turn: ModelTurn,
        *,
        purpose: str,
        max_output_tokens: int | None,
    ) -> None:
        self.events.append(
            "memory_compaction_model_turn",
            {
                "purpose": purpose,
                "content": turn.content,
                "tool_calls": [
                    {
                        "call_id": call.call_id,
                        "name": call.name,
                        "arguments": dict(call.arguments),
                    }
                    for call in turn.tool_calls
                ],
                "usage": dict(turn.usage),
                "finish_reason": turn.finish_reason or None,
                "max_output_tokens": (
                    int(max_output_tokens)
                    if max_output_tokens is not None
                    else None
                ),
            },
        )

    def _fit_compaction_batch(
        self,
        compactable: list[Mapping[str, Any]],
    ) -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]]]:
        batch = list(compactable)
        while batch:
            messages = self._compaction_messages(
                batch,
            )
            receipt = prompt_projection_receipt(
                call_site="memory-compaction",
                messages=messages,
                tools=(),
                sources=(),
                budget_bytes=self._budget_for("compact"),
                budget_tier="compact",
            )
            if receipt["status"] == "within_budget":
                return batch, messages
            if len({event["event_sequence"] for event in batch}) == 1:
                return batch, messages
            end = max(1, len(batch) // 2)
            while end < len(batch) and batch[end]["event_sequence"] == batch[end - 1]["event_sequence"]:
                end += 1
            batch = batch[:end]
        raise AssertionError("compaction_batch_required")

    def _compaction_messages(
        self,
        events: list[Mapping[str, Any]],
    ) -> list[Mapping[str, Any]]:
        prompt = _C3_DELTA_PROMPT.format(
            history=self._serialize(events),
            target_chars=_C3_SUMMARY_TARGET,
            selection_rules=_C3_CONTINUITY_SELECTION_RULES,
        )
        return [
            {
                "role": "system",
                "content": (
                    "You extract a semantic change set for continuity memory. "
                    "Do not answer the task and do not invent scientific facts."
                ),
            },
            {"role": "user", "content": prompt},
        ]

    @staticmethod
    def _curation_messages(
        *,
        previous_summary: str,
        semantic_delta: str,
    ) -> list[Mapping[str, Any]]:
        return [
            {
                "role": "system",
                "content": (
                    "You curate continuity memory from an old summary and an "
                    "explicit semantic change set. Do not answer the task or "
                    "invent scientific facts."
                ),
            },
            {
                "role": "user",
                "content": _C3_CURATION_PROMPT.format(
                    previous_summary=previous_summary or "(none)",
                    semantic_delta=semantic_delta,
                    target_chars=_C3_SUMMARY_TARGET,
                    selection_rules=_C3_CONTINUITY_SELECTION_RULES,
                ),
            },
        ]

    def _budget_for(self, budget_tier: str) -> int:
        if budget_tier == "full":
            return self.prompt_budget_bytes
        if budget_tier == "compact":
            return max(1, self.prompt_budget_bytes // 2)
        raise ValueError(f"unknown_prompt_budget_tier:{budget_tier}")

    def recent_projection(self) -> list[Mapping[str, Any]]:
        return [
            self._continuity_event_projection(event)
            for event in self._recent_events(self._uncompacted_events())
        ]

    def remaining_history_budget(
        self, *, messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]], budget_tier: str,
    ) -> int:
        """Allocate history after the actual fixed prompt and tool schemas."""
        fixed_bytes = _json_bytes({"messages": list(messages), "tools": list(tools)})
        return max(0, self._budget_for(budget_tier) - fixed_bytes)

    def recent_messages(
        self,
        *,
        max_bytes: int | None = None,
    ) -> list[Mapping[str, Any]]:
        """Reconstruct recent completed turns with native chat/tool roles."""
        all_events = self._work_events()
        invocation_events = self._uncompacted_events(all_events)
        required_events = self._active_issue_events(all_events)
        # A budget may omit older history, never the just-completed observation
        # or latest explicit work note before the model can use it.
        for kind in ("tool_result", "model_turn"):
            candidates = [event for event in invocation_events
                          if event["event_type"] == kind
                          and (kind == "tool_result" or event.get("content"))]
            if candidates:
                latest = max(candidates, key=lambda event: int(event["source_sequence"]))
                required_events.extend(event for event in invocation_events
                                       if event["event_sequence"] == latest["event_sequence"])
        if max_bytes is None and self.preserve_recent_events is not None:
            recent = self._recent_events(invocation_events)
        else:
            effective_budget = (
                max(0, int(max_bytes))
                if max_bytes is not None
                else max(1, self.prompt_budget_bytes // 2)
            )
            required_sequences = {
                int(event.get("event_sequence", 0)) for event in required_events
            }
            recent = list({
                (int(event["event_sequence"]), str(event["event_type"])): event
                for event in required_events
            }.values())
            groups: dict[int, list[Mapping[str, Any]]] = {}
            for event in invocation_events:
                if int(event["event_sequence"]) not in required_sequences:
                    groups.setdefault(int(event["source_sequence"]), []).append(event)
            for sequence in sorted(groups, reverse=True):
                candidate = [*groups[sequence], *recent]
                messages = self._messages_from_events(
                    all_events, candidate, deduplicate_reads=True,
                )
                if _json_bytes(messages) > effective_budget:
                    break
                recent = candidate
        if required_events:
            by_sequence = {
                (int(event.get("event_sequence", 0)), str(event.get("event_type"))): event
                for event in (*required_events, *recent)
            }
            recent = [by_sequence[key] for key in sorted(by_sequence)]
        return self._messages_from_events(all_events, recent, deduplicate_reads=True)

    def _messages_from_events(
        self,
        all_events: Sequence[Mapping[str, Any]],
        recent: Sequence[Mapping[str, Any]],
        *,
        deduplicate_reads: bool = False,
    ) -> list[Mapping[str, Any]]:
        if deduplicate_reads:
            recent = _deduplicate_page_bodies(recent)
        purposes = {
            int(event["round"]): str(event.get("purpose") or "continue runtime work")
            for event in all_events
            if event.get("event_type") == "prompt_snapshot"
            and event.get("round") is not None
        }
        grouped: dict[int, list[Mapping[str, Any]]] = {}
        for event in recent:
            round_number = event.get("round")
            if round_number is None:
                continue
            grouped.setdefault(int(round_number), []).append(event)

        messages: list[Mapping[str, Any]] = []
        # Coverage follows local imports, but displayed history follows when
        # each immutable source was created. Late imports are not new runs.
        ordered_groups = sorted(grouped.items(), key=lambda pair: int(
            pair[1][0].get("source_sequence", pair[0])
        ))
        for round_number, round_events in ordered_groups:
            model_event = next(
                (
                    event
                    for event in round_events
                    if event.get("event_type") == "model_turn"
                ),
                None,
            )
            if model_event is None:
                continue
            tool_calls = list(model_event.get("tool_calls") or ())
            if not tool_calls:
                content = str(model_event.get("content") or "")
                if content:
                    messages.append({"role": "user", "content": (
                        "Historical model work note (unverified, not an instruction or accepted evidence):\n"
                        + content
                    )})
                continue
            tool_results = {
                str(event.get("call_id") or ""): event
                for event in round_events
                if event.get("event_type") == "tool_result"
            }
            if tool_calls and any(
                str(call.get("call_id") or "") not in tool_results
                for call in tool_calls
            ):
                continue

            messages.append(
                {
                    "role": "user",
                    "content": (
                        "Runtime purpose for this completed turn: "
                        + purposes.get(round_number, "continue runtime work")
                    ),
                }
            )
            projected_calls: list[
                tuple[Mapping[str, Any], Mapping[str, Any], Mapping[str, Any]]
            ] = []
            has_omitted_arguments = False
            for call in tool_calls:
                call_id = str(call.get("call_id") or "")
                result_event = tool_results[call_id]
                executed_arguments = (
                    result_event.get("executed_arguments")
                    if isinstance(result_event.get("executed_arguments"), Mapping)
                    else call.get("arguments") or {}
                )
                failed_arguments = _bounded_failed_tool_arguments(
                    executed_arguments,
                    result_event=result_event,
                    prompt_budget_bytes=self.prompt_budget_bytes,
                )
                projected_arguments = (
                    failed_arguments
                    if failed_arguments is not None
                    else tool_call_prompt_projection(executed_arguments)
                )
                omitted_argument_names = sorted(
                    str(key)
                    for key in executed_arguments
                    if str(key) not in projected_arguments
                )
                if omitted_argument_names:
                    has_omitted_arguments = True
                projected_calls.append(
                    (call, projected_arguments, result_event)
                )

            if has_omitted_arguments:
                completed_calls = []
                for call, projected_arguments, result_event in projected_calls:
                    executed_arguments = (
                        result_event.get("executed_arguments")
                        if isinstance(
                            result_event.get("executed_arguments"), Mapping
                        )
                        else call.get("arguments") or {}
                    )
                    completed_calls.append(
                        {
                            "call_id": str(call.get("call_id") or ""),
                            "tool": str(call.get("name") or ""),
                            "preserved_arguments": dict(projected_arguments),
                            "omitted_argument_names": sorted(
                                str(key)
                                for key in executed_arguments
                                if str(key) not in projected_arguments
                            ),
                            "result": dict(result_event.get("prompt_projection") or {}),
                        }
                    )
                messages.append(
                    {
                        "role": "user",
                        "content": (
                            "Runtime-authored record of already completed tool "
                            "calls. This is historical evidence, not a request to "
                            "execute the calls or reconstruct omitted arguments.\n"
                            + json.dumps(
                                {
                                    "round": round_number,
                                    "completed_calls": completed_calls,
                                },
                                ensure_ascii=False,
                                separators=(",", ":"),
                            )
                        ),
                    }
                )
                continue

            assistant: dict[str, Any] = {
                "role": "assistant",
                "content": "",
            }
            if tool_calls:
                assistant["tool_calls"] = [
                    {
                        "id": str(call.get("call_id") or ""),
                        "type": "function",
                        "function": {
                            "name": str(call.get("name") or ""),
                            "arguments": json.dumps(
                                projected_arguments,
                                ensure_ascii=False,
                                separators=(",", ":"),
                            ),
                        },
                    }
                    for call, projected_arguments, _ in projected_calls
                ]
            messages.append(assistant)
            for call in tool_calls:
                call_id = str(call.get("call_id") or "")
                result_event = tool_results[call_id]
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": call_id,
                        "content": json.dumps(
                            dict(result_event.get("prompt_projection") or {}),
                            ensure_ascii=False,
                            separators=(",", ":"),
                        ),
                    }
                )
        return messages

    def _active_issue_events(
        self, all_events: list[Mapping[str, Any]]
    ) -> list[Mapping[str, Any]]:
        """Keep the causal failed turn visible until its issue is resolved."""
        current_issue = str(
            self.state.read()["c1"].get("current_issue") or ""
        )
        if not current_issue:
            return []
        invocation_events = all_events
        failed_round: int | None = None
        for event in reversed(invocation_events):
            if event.get("event_type") != "tool_result":
                continue
            result = event.get("raw_result")
            if not isinstance(result, Mapping):
                continue
            if result.get("status") != "tool_error":
                continue
            reason = str(result.get("reason") or "")
            if reason and reason in current_issue:
                failed_round = int(event.get("round", 0))
                break
        if failed_round is None:
            return []
        return [
            event
            for event in invocation_events
            if int(event.get("round", -1)) == failed_round
        ]

    def _uncompacted_events(
        self, events: list[Mapping[str, Any]] | None = None
    ) -> list[Mapping[str, Any]]:
        events = self._work_events() if events is None else events
        through_sequence = self.work.checkpoint()["through_sequence"]
        return [
            event
            for event in events
            if int(event.get("event_sequence", 0)) > through_sequence
            and event.get("event_type")
            in {"model_turn", "tool_result", "closure_evaluation"}
        ]

    def _recent_events(
        self,
        events: list[Mapping[str, Any]],
        *,
        all_events: Sequence[Mapping[str, Any]] | None = None,
        max_bytes: int | None = None,
    ) -> list[Mapping[str, Any]]:
        if max_bytes is None and self.preserve_recent_events is not None:
            preserve_count = max(0, int(self.preserve_recent_events))
            if preserve_count == 0:
                return []
            if len(events) <= preserve_count:
                return events
            start = len(events) - preserve_count
            boundary_round = events[start].get("round")
            while start > 0 and events[start - 1].get("round") == boundary_round:
                start -= 1
            return events[start:]

        byte_budget = (
            max(0, int(max_bytes))
            if max_bytes is not None
            else max(1, self.prompt_budget_bytes // 2)
        )
        if byte_budget == 0 or not events:
            return []
        complete_history = all_events if all_events is not None else events
        grouped: dict[int, list[Mapping[str, Any]]] = {}
        for event in events:
            round_number = event.get("round")
            if round_number is None:
                continue
            grouped.setdefault(int(round_number), []).append(event)

        selected: list[Mapping[str, Any]] = []
        for round_number in reversed(tuple(grouped)):
            candidate = [*grouped[round_number], *selected]
            messages = self._messages_from_events(complete_history, candidate)
            if _json_bytes(messages) > byte_budget:
                break
            selected = candidate
        return selected

    def _serialize(self, events: list[Mapping[str, Any]]) -> str:
        return json.dumps(
            [self._compaction_event_projection(event) for event in events],
            ensure_ascii=False,
            separators=(",", ":"),
        )

    @staticmethod
    def _compaction_event_projection(
        event: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        event_type = str(event.get("event_type", ""))
        base: dict[str, Any] = {
            "event_sequence": event.get("event_sequence"),
            "entry_ref": event.get("entry_ref"),
            "source_sequence": event.get("source_sequence"),
            "event_type": event_type,
            "round": event.get("round"),
        }
        if event_type == "model_turn":
            base["unverified_work_note"] = event.get("content", "")
            base["tool_calls"] = bounded_projection(
                event.get("tool_calls", []), max_depth=3, max_items=4
            )
        elif event_type == "tool_result":
            base["tool"] = event.get("tool")
            base["executed_arguments"] = tool_call_prompt_projection(
                event.get("executed_arguments", {})
            )
            base["result"] = bounded_projection(
                event.get("prompt_projection", {}),
                max_depth=3,
                max_items=4,
            )
        else:
            base["result"] = bounded_projection(
                event.get("result", {}), max_depth=3, max_items=4
            )
        return base

    @staticmethod
    def _continuity_event_projection(
        event: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        """Project persistent work, never import C6 diagnostic prose."""
        event_type = str(event.get("event_type", ""))
        base: dict[str, Any] = {
            "event_sequence": event.get("event_sequence"),
            "source_sequence": event.get("source_sequence"),
            "event_type": event_type,
            "round": event.get("round"),
        }
        if event_type == "model_turn":
            base["unverified_work_note"] = event.get("content", "")
            base["tool_calls"] = bounded_projection(
                event.get("tool_calls", []), max_depth=3, max_items=4
            )
        elif event_type == "tool_result":
            base["tool"] = event.get("tool")
            base["result"] = bounded_projection(
                event.get("prompt_projection", {}),
                max_depth=3,
                max_items=4,
            )
        else:
            base["result"] = bounded_projection(
                event.get("result", {}), max_depth=3, max_items=4
            )
        return base


_C3_CONTINUITY_SELECTION_RULES = """\
Information selection for work continuity:
- Preserve still-useful decisions and their recorded reasons, ruled-out causes,
  unresolved work, uncertainty, and continuation pointers. Silence in a newer
  batch does not resolve older work. Do not invent reasons or next actions.
- The summary is not a lossless copy of the log. Detailed numeric traces,
  software inventories, file listings, and repeated readings stay in exact work
  records. Omit their enumeration when it is not needed to understand an active
  decision, distinguish a failure, or resume the work; retain supplied source
  pointers for rereading. Copy retained identifiers as supplied, not invented
  or newly abbreviated locations.
- Retain specific values, constraints, errors, and causal details when they
  determine those decisions or the unresolved problem. Do not remove all
  numbers or errors merely to shorten the text. Select by recorded relevance.
- Group repeated discussion of the same issue once, with its current qualified
  status and still-relevant history. Do not merge different workspaces,
  executions, versions, or search scopes into one observation.
- Omission of detail is not a claim that work is resolved. Preserve the meaning,
  uncertainty, and unverified status of retained statements; do not strengthen
  them into diagnoses or completion claims.
"""

_C3_DELTA_PROMPT = """\
Extract the semantic changes from this persistent work's notes and operations.
Model notes are unverified working judgments, not accepted scientific evidence.
Hidden reasoning and raw C6 prompts are excluded. The previous summary is not
supplied in this extraction stage.

Rules:
- Base every item only on the supplied new event projection.
- source_sequence is original creation order; event_sequence is local coverage.
  A late import does not make an old observation a newer execution.
- Preserve stated decisions, their reasons, ruled-out causes, unresolved work,
  and intended next checks as unverified notes, never as execution authority.
- Do not invent claims, reasons, evidence, intentions, or workflow decisions.
- Preserve the scope of observations: a search with no matches only establishes
  no matches in its stated scope, not global absence or an eliminated cause.
  Keep control enum labels literal; do not reinterpret them as domain settings.
- Report what the source says, not a new interpretation of what it proves.
  Completion of one operation does not establish completion of the surrounding
  stage or task. If a status has unclear scope, quote it with its source rather
  than assigning a broader meaning.
- Keep each observation attached to its project/workspace, execution, version,
  and read/search range when supplied. Different scopes are not conflicting
  observations unless the records explicitly establish that relationship.
{selection_rules}
- Omit decisions, reasons, or next checks that were not explicitly recorded.
  Do not fill missing sections with plausible advice or general knowledge.
- Return concise ordinary Markdown. No fixed headings are required.
- Keep the entire response at or below {target_chars:,} characters.
  Runtime measures length; return one finished answer, not repeated drafts or
  character-count estimates.

Bounded older records from this work scope:
{history}
"""


_C3_CURATION_PROMPT = """\
Rewrite the previous C3 continuity summary by applying the supplied semantic
change set. This is a full semantic rewrite, not mechanical text concatenation.

Rules:
- Integrate the new semantic delta; do not append it verbatim.
- Preserve continuity needed to resume the same work across skill calls and
  attempts: decisions and reasons, eliminated causes, outstanding issues, and
  intended checks. Keep their unverified status and any recorded corrections.
- Keep: carry forward still-useful prior decisions and reasons, ruled-out causes,
  unresolved work, and uncertainty even when this delta does not repeat them.
  Silence in a new batch is not evidence that earlier work is resolved or obsolete.
- Update or remove earlier content when new evidence corrects, supersedes, or
  resolves it, or it no longer helps continuation. Shorten completed or stale
  detail without erasing rationale still needed to avoid repeating failed work.
  Keep is a relevance principle, not a requirement to retain every old sentence.
- Do not invent facts, evidence, plans, intentions, or terminal decisions.
- Keep qualifications and search scope; do not turn "not observed" into
  "ruled out" or add advice to fill an absent next-check section.
- Do not strengthen source statements into diagnoses or completion claims.
  A completed operation is not automatically a completed stage or task. Keep
  ambiguous status wording quoted and attributed rather than interpreting it.
  Keep different projects, workspaces, executions, versions, and search ranges
  separate; do not invent contradictions between unrelated observations.
{selection_rules}
- Current C0/C1 controls execution; historical intentions do not grant authority.
- Keep exact refs and exact errors when they remain relevant.
- Return concise ordinary Markdown. No fixed headings are required.
- Keep the entire response at or below {target_chars:,} characters.
  Runtime measures length; return one finished answer, not repeated drafts or
  character-count estimates.

Previous C3 summary:
{previous_summary}

Semantic change set:
{semantic_delta}
"""


_C3_RECOMPACTION_PROMPT = """\
Rewrite the continuity summary below toward {target_chars:,} characters.
Return one finished, concise answer. Do not repeatedly draft or estimate
character counts.

{selection_rules}

Remove repetition and stale detail while retaining still-useful decisions and
reasons, ruled-out causes, unresolved work, and uncertainty. Preserve their
qualifications and unverified status; shortening must not turn them into facts
or silently treat them as resolved. Do not add new facts, pending work, next
actions, scientific conclusions, or workflow decisions. Return concise ordinary
Markdown. No fixed headings are required. Finish naturally; compact more
aggressively instead of relying on output truncation.

Candidate summary:
{summary}
"""
