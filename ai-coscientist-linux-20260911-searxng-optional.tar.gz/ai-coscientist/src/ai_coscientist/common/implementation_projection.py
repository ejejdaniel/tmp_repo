from __future__ import annotations

import json
from typing import Any, Mapping, Sequence

from .json_schema import json_schema_issues


_SHORT_SOURCE_CHARACTER_LIMIT = 12_000
_SHORT_SOURCE_LINE_LIMIT = 300
_MAX_SNIPPETS = 8
_MAX_SELECTED_LINES = 320


def implementation_projection_schema() -> dict[str, Any]:
    """Return the private report projection contract for one implementation."""
    return {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "implementation_ref",
            "overview_zh_tw",
            "execution_flow",
            "key_decisions",
            "snippets",
            "omitted_files_summary",
        ],
        "properties": {
            "implementation_ref": {"type": "string", "minLength": 1},
            "overview_zh_tw": {"type": "string", "minLength": 1},
            "execution_flow": {
                "type": "array",
                "minItems": 1,
                "items": {"type": "string", "minLength": 1},
            },
            "key_decisions": {
                "type": "array",
                "minItems": 1,
                "items": {"type": "string", "minLength": 1},
            },
            "snippets": {
                "type": "array",
                "minItems": 1,
                "maxItems": _MAX_SNIPPETS,
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": [
                        "path",
                        "start_line",
                        "end_line",
                        "purpose_zh_tw",
                    ],
                    "properties": {
                        "path": {"type": "string", "minLength": 1},
                        "start_line": {"type": "integer", "minimum": 1},
                        "end_line": {"type": "integer", "minimum": 1},
                        "purpose_zh_tw": {
                            "type": "string",
                            "minLength": 1,
                        },
                    },
                },
            },
            "omitted_files_summary": {"type": "string", "minLength": 1},
        },
    }


def automatic_short_file_projection(
    implementation: Mapping[str, Any],
) -> dict[str, Any] | None:
    """Project one short source file completely without an LLM call."""
    source_files = _source_files(implementation)
    if len(source_files) != 1:
        return None
    source_file = source_files[0]
    source = source_file["source"]
    line_count = len(source.splitlines())
    if (
        not source
        or len(source) > _SHORT_SOURCE_CHARACTER_LIMIT
        or line_count > _SHORT_SOURCE_LINE_LIMIT
    ):
        return None
    command = " ".join(
        str(value) for value in implementation.get("entry_command") or ()
    ).strip()
    return {
        "implementation_ref": _implementation_ref(implementation),
        "overview_zh_tw": (
            str(implementation.get("purpose") or "").strip()
            or "此實作由單一短檔案構成，報告完整呈現其原始程式。"
        ),
        "execution_flow": [
            (
                f"依入口命令 `{command}` 執行此實作。"
                if command
                else "依正式實作引用載入並執行此單一檔案。"
            )
        ],
        "key_decisions": ["單一短檔案不節錄，直接呈現完整原始程式。"],
        "snippets": [
            {
                "path": source_file["path"],
                "start_line": 1,
                "end_line": max(1, line_count),
                "purpose_zh_tw": "完整實作程式",
            }
        ],
        "omitted_files_summary": "未省略任何檔案。",
    }


def implementation_projection_issues(
    projection: Any,
    implementation: Mapping[str, Any],
) -> list[str]:
    issues = list(json_schema_issues(projection, implementation_projection_schema()))
    if not isinstance(projection, Mapping):
        return issues
    expected_ref = _implementation_ref(implementation)
    if str(projection.get("implementation_ref") or "") != expected_ref:
        issues.append(
            "implementation_projection_ref_mismatch:"
            f"{projection.get('implementation_ref')}!={expected_ref}"
        )

    sources = {item["path"]: item for item in _source_files(implementation)}
    snippets = projection.get("snippets")
    if not isinstance(snippets, list):
        return issues
    seen: set[tuple[str, int, int]] = set()
    selected_lines = 0
    for index, raw in enumerate(snippets):
        if not isinstance(raw, Mapping):
            continue
        path = str(raw.get("path") or "")
        source_file = sources.get(path)
        if source_file is None:
            issues.append(
                f"implementation_projection_path_unknown:snippets[{index}]:{path}"
            )
            continue
        start = raw.get("start_line")
        end = raw.get("end_line")
        if not isinstance(start, int) or isinstance(start, bool):
            continue
        if not isinstance(end, int) or isinstance(end, bool):
            continue
        line_count = max(1, len(source_file["source"].splitlines()))
        if end < start:
            issues.append(
                f"implementation_projection_range_reversed:snippets[{index}]"
            )
            continue
        if end > line_count:
            issues.append(
                "implementation_projection_range_out_of_bounds:"
                f"snippets[{index}]:{end}>{line_count}"
            )
            continue
        identity = (path, start, end)
        if identity in seen:
            issues.append(
                f"implementation_projection_duplicate_snippet:snippets[{index}]"
            )
            continue
        seen.add(identity)
        selected_lines += end - start + 1
    if selected_lines > _MAX_SELECTED_LINES:
        issues.append(
            "implementation_projection_selected_lines_exceeded:"
            f"{selected_lines}>{_MAX_SELECTED_LINES}"
        )
    return issues


def materialize_implementation_projection(
    projection: Mapping[str, Any],
    implementation: Mapping[str, Any],
) -> dict[str, Any]:
    """Slice exact source text after validating model-selected line ranges."""
    issues = implementation_projection_issues(projection, implementation)
    if issues:
        raise ValueError("implementation_projection_invalid:" + ";".join(issues[:24]))
    sources = {item["path"]: item for item in _source_files(implementation)}
    snippets: list[dict[str, Any]] = []
    for raw in projection["snippets"]:
        path = str(raw["path"])
        start = int(raw["start_line"])
        end = int(raw["end_line"])
        source_file = sources[path]
        lines = source_file["source"].splitlines(keepends=True)
        snippets.append(
            {
                "path": path,
                "start_line": start,
                "end_line": end,
                "purpose_zh_tw": str(raw["purpose_zh_tw"]),
                "language": source_file["language"],
                "sha256": source_file["sha256"],
                "source": "".join(lines[start - 1 : end]),
            }
        )
    return {
        "implementation_ref": _implementation_ref(implementation),
        "implementation_kind": str(
            implementation.get("implementation_kind") or ""
        ),
        "purpose": str(implementation.get("purpose") or ""),
        "environment_ref": str(implementation.get("environment_ref") or ""),
        "entry_command": [
            str(value) for value in implementation.get("entry_command") or ()
        ],
        "working_directory": str(implementation.get("working_directory") or ""),
        "overview_zh_tw": str(projection["overview_zh_tw"]),
        "execution_flow": [str(value) for value in projection["execution_flow"]],
        "key_decisions": [str(value) for value in projection["key_decisions"]],
        "snippets": snippets,
        "file_manifest": [
            {
                "path": item["path"],
                "language": item["language"],
                "sha256": item["sha256"],
                "line_count": len(item["source"].splitlines()),
            }
            for item in _source_files(implementation)
        ],
        "omitted_files_summary": str(projection["omitted_files_summary"]),
    }


def implementation_projection_context(
    implementation: Mapping[str, Any],
) -> dict[str, Any]:
    """Expose immutable source with stable line numbers for range selection."""
    return {
        "implementation_ref": _implementation_ref(implementation),
        "implementation_kind": str(
            implementation.get("implementation_kind") or ""
        ),
        "purpose": str(implementation.get("purpose") or ""),
        "environment_ref": str(implementation.get("environment_ref") or ""),
        "entry_command": [
            str(value) for value in implementation.get("entry_command") or ()
        ],
        "working_directory": str(implementation.get("working_directory") or ""),
        "source_files": [
            {
                "path": item["path"],
                "sha256": item["sha256"],
                "numbered_source": _numbered_source(item["source"]),
            }
            for item in _source_files(implementation)
        ],
    }


def projection_for_ref(
    projections: Any,
    implementation_ref: str,
) -> Mapping[str, Any] | None:
    if projections is None:
        return None
    if isinstance(projections, Mapping):
        raw = projections.get("implementation_projections", projections)
    else:
        raw = projections
    items = raw if isinstance(raw, list) else [raw]
    matches = [
        item
        for item in items
        if isinstance(item, Mapping)
        and str(item.get("implementation_ref") or "") == implementation_ref
    ]
    if len(matches) > 1:
        raise ValueError(
            f"implementation_projection_duplicate_ref:{implementation_ref}"
        )
    return matches[0] if matches else None


def raw_projection(projection: Mapping[str, Any]) -> dict[str, Any]:
    """Remove materialized source fields before persisting a private sidecar."""
    return {
        "implementation_ref": str(projection["implementation_ref"]),
        "overview_zh_tw": str(projection["overview_zh_tw"]),
        "execution_flow": [str(value) for value in projection["execution_flow"]],
        "key_decisions": [str(value) for value in projection["key_decisions"]],
        "snippets": [
            {
                "path": str(item["path"]),
                "start_line": int(item["start_line"]),
                "end_line": int(item["end_line"]),
                "purpose_zh_tw": str(item["purpose_zh_tw"]),
            }
            for item in projection["snippets"]
        ],
        "omitted_files_summary": str(projection["omitted_files_summary"]),
    }


def _source_files(implementation: Mapping[str, Any]) -> list[dict[str, str]]:
    raw_files = implementation.get("source_files")
    if not isinstance(raw_files, list) or not raw_files:
        raise ValueError("implementation_projection_source_files_required")
    result: list[dict[str, str]] = []
    seen: set[str] = set()
    for raw in raw_files:
        if not isinstance(raw, Mapping):
            raise ValueError("implementation_projection_source_file_invalid")
        path = str(raw.get("path") or "").strip()
        if not path or path in seen:
            raise ValueError(
                f"implementation_projection_source_path_invalid:{path or 'missing'}"
            )
        source = raw.get("source")
        if source is None:
            source = raw.get("content")
        if not isinstance(source, str):
            raise ValueError(
                f"implementation_projection_source_text_required:{path}"
            )
        seen.add(path)
        result.append(
            {
                "path": path,
                "language": str(raw.get("language") or path.rsplit(".", 1)[-1]),
                "source": source,
                "sha256": str(raw.get("sha256") or ""),
            }
        )
    return result


def _implementation_ref(implementation: Mapping[str, Any]) -> str:
    ref = str(implementation.get("implementation_ref") or "").strip()
    if not ref:
        raise ValueError("implementation_projection_ref_required")
    return ref


def _numbered_source(source: str) -> str:
    return "\n".join(
        f"{index:05d}: {line}"
        for index, line in enumerate(source.splitlines(), start=1)
    )


def projection_debug_json(value: Mapping[str, Any]) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2)
