from __future__ import annotations

import copy

from pathlib import PurePosixPath
from typing import Any, Mapping, Sequence


class DraftFileWorkbench:
    """Invocation-local exact file operations over one unsealed draft."""

    def __init__(self, files: Sequence[Mapping[str, Any]]) -> None:
        self._order: list[str] = []
        self._files: dict[str, dict[str, Any]] = {}
        self._revisions: dict[str, int] = {}
        for index, raw_file in enumerate(files):
            if not isinstance(raw_file, Mapping):
                raise TypeError(f"draft_file_invalid:{index}")
            item = copy.deepcopy(dict(raw_file))
            path = _normalize_path(item.get("path"))
            if path in self._files:
                raise ValueError(f"draft_file_duplicate:{path}")
            source_kind = str(item.get("source_kind") or "")
            if source_kind not in {"inline", "path"}:
                raise ValueError(f"draft_file_source_kind_invalid:{path}")
            content = item.get("content")
            source_path = str(item.get("source_path") or "")
            if source_kind == "inline":
                if not isinstance(content, str) or source_path:
                    raise ValueError(f"draft_inline_file_invalid:{path}")
            elif content not in {None, ""} or not source_path:
                raise ValueError(f"draft_path_file_invalid:{path}")
            item["path"] = path
            self._order.append(path)
            self._files[path] = item
            self._revisions[path] = 0

    def catalog(self) -> list[dict[str, Any]]:
        return [
            {
                "path": path,
                "source_kind": self._files[path]["source_kind"],
                "editable": self._files[path]["source_kind"] == "inline",
                "revision": self._revisions[path],
                "characters": (
                    len(str(self._files[path].get("content") or ""))
                    if self._files[path]["source_kind"] == "inline"
                    else None
                ),
            }
            for path in self._order
        ]

    def read_file(
        self,
        path: str,
        *,
        line_offset: int,
        line_limit: int,
    ) -> dict[str, Any]:
        normalized = _normalize_path(path)
        item = self._require_inline(normalized)
        if (
            isinstance(line_offset, bool)
            or not isinstance(line_offset, int)
            or line_offset < 0
        ):
            raise ValueError("draft_read_line_offset_invalid")
        if (
            isinstance(line_limit, bool)
            or not isinstance(line_limit, int)
            or not 1 <= line_limit <= 2_000
        ):
            raise ValueError("draft_read_line_limit_invalid")
        lines = str(item["content"]).splitlines(keepends=True)
        page = lines[line_offset : line_offset + line_limit]
        text = "".join(page)
        next_offset = line_offset + len(page)
        return {
            "path": normalized,
            "revision": self._revisions[normalized],
            "line_offset": line_offset,
            "text": text,
            "next_line_offset": (
                next_offset if next_offset < len(lines) else None
            ),
            "total_lines": len(lines),
        }

    def write_file(self, path: str, content: str) -> dict[str, Any]:
        normalized = _normalize_path(path)
        if normalized in self._files:
            raise ValueError(f"draft_write_file_already_exists:{normalized}")
        if not isinstance(content, str):
            raise TypeError("draft_write_content_must_be_text")
        if len(content) > 120_000:
            raise ValueError("draft_write_content_too_large")
        self._order.append(normalized)
        self._files[normalized] = {
            "path": normalized,
            "source_kind": "inline",
            "content": content,
            "source_path": "",
        }
        self._revisions[normalized] = 0
        return {
            "path": normalized,
            "revision": self._revisions[normalized],
            "characters": len(content),
        }

    def edit_file(
        self,
        path: str,
        *,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> dict[str, Any]:
        normalized = _normalize_path(path)
        item = self._require_inline(normalized)
        if not old_string:
            raise ValueError("draft_edit_old_string_required")
        if old_string == new_string:
            raise ValueError("draft_edit_requires_changed_text")
        source = str(item["content"])
        occurrences = source.count(old_string)
        if not occurrences:
            raise ValueError("draft_edit_old_string_not_found")
        if occurrences > 1 and not replace_all:
            raise ValueError(
                f"draft_edit_old_string_not_unique:occurrences={occurrences}"
            )
        item["content"] = source.replace(
            old_string,
            new_string,
            -1 if replace_all else 1,
        )
        self._revisions[normalized] += 1
        return {
            "path": normalized,
            "revision": self._revisions[normalized],
            "replacement_count": occurrences if replace_all else 1,
            "characters": len(str(item["content"])),
        }

    def snapshot(self) -> list[dict[str, Any]]:
        return [copy.deepcopy(self._files[path]) for path in self._order]

    def _require_inline(self, path: str) -> dict[str, Any]:
        item = self._files.get(path)
        if item is None:
            raise KeyError(f"draft_file_not_found:{path}")
        if item["source_kind"] != "inline":
            raise PermissionError(f"draft_path_file_not_editable:{path}")
        return item


def _normalize_path(value: Any) -> str:
    raw = str(value or "").strip().replace("\\", "/")
    path = PurePosixPath(raw)
    if (
        not raw
        or path.is_absolute()
        or raw.startswith("/")
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise ValueError(f"draft_file_path_invalid:{raw or 'empty'}")
    return path.as_posix()
