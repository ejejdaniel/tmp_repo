from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Mapping


@dataclass(frozen=True)
class BoundedRepairLimits:
    """Science-neutral upper bounds for one skill-local repair loop."""

    max_inspections: int = 2
    max_edits: int = 2
    max_actions: int = 4
    max_rejections: int = 2

    def __post_init__(self) -> None:
        values = (
            self.max_inspections,
            self.max_edits,
            self.max_actions,
            self.max_rejections,
        )
        if any(
            isinstance(value, bool) or not isinstance(value, int) or value < 0
            for value in values
        ):
            raise ValueError("bounded_repair_limits_must_be_non_negative")
        if self.max_actions < max(self.max_inspections, self.max_edits):
            raise ValueError("bounded_repair_total_limit_too_small")


@dataclass
class BoundedRepairController:
    """Admit distinct inspect/edit actions without choosing repair semantics."""

    limits: BoundedRepairLimits = field(default_factory=BoundedRepairLimits)
    inspection_actions: frozenset[str] = field(
        default_factory=lambda: frozenset({"inspect_environment"})
    )
    edit_actions: frozenset[str] = field(
        default_factory=lambda: frozenset({"edit_python_file"})
    )
    stop_actions: frozenset[str] = field(
        default_factory=lambda: frozenset({"stop_bounded_gap"})
    )
    _inspection_count: int = 0
    _edit_count: int = 0
    _action_count: int = 0
    _rejection_count: int = 0
    _action_fingerprints: set[str] = field(default_factory=set)

    def admit(self, action: Mapping[str, Any]) -> str:
        """Return an empty reason when admitted, otherwise a terminal reason."""
        action_name = str(action.get("action") or "")
        if action_name in self.stop_actions:
            return "model_requested_bounded_gap"
        if action_name not in self.inspection_actions | self.edit_actions:
            return f"bounded_repair_action_unknown:{action_name or 'missing'}"
        if self._action_count >= self.limits.max_actions:
            return "bounded_repair_total_action_quota_exhausted"
        if (
            action_name in self.inspection_actions
            and self._inspection_count >= self.limits.max_inspections
        ):
            return "bounded_repair_inspection_quota_exhausted"
        if (
            action_name in self.edit_actions
            and self._edit_count >= self.limits.max_edits
        ):
            return "bounded_repair_edit_quota_exhausted"

        fingerprint = _fingerprint(action)
        if fingerprint in self._action_fingerprints:
            return "bounded_repair_repeated_equivalent_action"

        self._action_fingerprints.add(fingerprint)
        self._action_count += 1
        if action_name in self.inspection_actions:
            self._inspection_count += 1
        else:
            self._edit_count += 1
        return ""

    def record_rejection(self, reason: str) -> str:
        """Bound invalid selections without charging an executable action."""
        self._rejection_count += 1
        if self._rejection_count >= self.limits.max_rejections:
            return f"bounded_repair_rejection_quota_exhausted:{reason}"
        return ""

    def can_continue(self) -> bool:
        return (
            self._rejection_count < self.limits.max_rejections
            and self._action_count < self.limits.max_actions
            and (
                self._inspection_count < self.limits.max_inspections
                or self._edit_count < self.limits.max_edits
            )
        )

    def projection(self) -> dict[str, int]:
        return {
            "actions_used": self._action_count,
            "actions_remaining": max(
                0, self.limits.max_actions - self._action_count
            ),
            "inspections_used": self._inspection_count,
            "inspections_remaining": max(
                0, self.limits.max_inspections - self._inspection_count
            ),
            "edits_used": self._edit_count,
            "edits_remaining": max(
                0, self.limits.max_edits - self._edit_count
            ),
            "rejections_used": self._rejection_count,
            "rejections_remaining": max(
                0, self.limits.max_rejections - self._rejection_count
            ),
        }


def _fingerprint(action: Mapping[str, Any]) -> str:
    normalized = {
        str(key): value
        for key, value in action.items()
        if str(key) != "reason"
    }
    return hashlib.sha256(
        json.dumps(
            normalized,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
