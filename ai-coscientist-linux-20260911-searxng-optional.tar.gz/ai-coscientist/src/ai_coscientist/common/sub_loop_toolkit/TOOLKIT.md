# Common Sub-loop Toolkit

This directory owns bounded control loops that are smaller than one Graph node
attempt. It does not choose scientific meaning and does not alter the immutable
Node LOOP plan. Each service has a separate state and lifecycle contract.

## Human interruption

This is common control infrastructure, not a production scientific skill. It
owns one global human interruption transaction: request, durable pause, answer
publication, and return to the saved control boundary. It never decides the
scientific answer or the post-answer route.

The authoritative request state is C1. The human response body is one immutable
C2 `human_interaction_response` artifact. C6 retains raw audit events only.

When `human_in_loop_enabled` is false, the request tool is absent and no pending
interaction may be created. The agent must continue autonomously or use its
ordinary bounded-gap, attempt, and Graph-rebuild behavior without fabricating a
human answer.

Scope-specific insertion contracts are disclosed in `references/`:

- `step-interrupt.md`
- `attempt-interrupt.md`
- `graph-replan-interrupt.md`
- `frame-interrupt.md`

## Bounded machine repair

`bounded_repair.py` admits a fixed number of distinct inspect/edit actions for
one skill-local repair workflow. It owns execution quotas, duplicate-action
rejection, and a separate bounded allowance for correcting invalid action
selections; rejected selections do not execute or consume an action. It does
not own prompts, code semantics, tests, or scientific routing. The consuming
Skill defines its private action schema, supplies exact current evidence,
executes the admitted action through existing common Routes, and decides
whether the result satisfies that Skill's existing contract.

Repair state is invocation-local C5 working state. Immutable code revisions and
formal final artifacts retain their normal C4/C2 storage, while prompts, tool
calls, and execution receipts remain C6 audit data. Mid-action crash recovery
is deliberately not a new persisted schema: a later Skill invocation restarts
from the latest exact pending candidate and formal evidence.

`draft_files.py` supplies the same repair pattern for an unsealed invocation-
local file set. Its operations list, read, create, and exact-edit ordinary UTF-8
files without interpreting whether their contents are Python, Markdown, JSON,
or another text format. The owning workflow supplies the validator and decides
when a valid draft is sealed. Host paths and `source_kind=path` inputs remain
immutable; this is not a general host-filesystem mutation API.

All file actions in one repair invocation retain one ordered model conversation:
the selected action is followed by its exact host result, current file revision,
validator result, and remaining quota. A read of an already visible range on the
same revision returns the exact text as a cache hit; it is not a package failure
and does not consume another file-operation slot. A separate decision-turn limit
still stops a model that never advances from repeated reads.
