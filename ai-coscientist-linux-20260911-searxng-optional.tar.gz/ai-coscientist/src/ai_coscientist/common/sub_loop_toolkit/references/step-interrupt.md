# Step interruption

Pause inside the current sealed Node LOOP step. Waiting consumes no additional
cost. Feedback returns to the same step. If the response invalidates the sealed
remaining sequence, the main agent must end the attempt through the existing
attempt restart control; the toolkit does not mutate the suffix.
