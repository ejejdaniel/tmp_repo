# Attempt interruption

Pause at the active Graph node's bounded-attempt boundary. The saved anchor
contains the Graph revision, node id, attempt index, and current step index.
Waiting consumes no attempt. The main agent decides whether the answer supports
continuation or requires a new attempt.
