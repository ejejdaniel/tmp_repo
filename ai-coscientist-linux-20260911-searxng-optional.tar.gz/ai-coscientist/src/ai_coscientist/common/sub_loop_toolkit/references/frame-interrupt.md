# Frame interruption

Pause when the current Graph has exhausted reachable work while the evaluator
still reports unmet criteria. This is the boundary before opening another
research frame. A task-contract-changing answer does not rewrite C0 in place;
the host receives `new_frame_required` and must start an explicitly revised
task.
