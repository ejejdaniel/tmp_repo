# Graph-replan interruption

Pause after the immutable `graph_revision_outcome` exists and before a
replacement Graph is committed. The old Graph remains authoritative. The
outcome ref is included in the request context so the resumed planner sees the
same failure evidence plus the human response.
