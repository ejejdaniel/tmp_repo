from __future__ import annotations

import copy
import uuid
from typing import Any, Callable, Mapping, Sequence

from .._runtime_support import function_tool
from ..memory_lifecycle.state import AgentStateStore


HUMAN_SCOPES = frozenset(
    {
        "step",
        "attempt",
        "graph_replan",
        "frame",
        "task_formulation",
        "evaluation_build",
        "evaluation_judgment",
    }
)
HUMAN_RESPONSE_ROLES = frozenset(
    {"feedback", "scientific_input", "task_contract_change"}
)

ExactRefValidator = Callable[[str], None]
ArtifactPublisher = Callable[..., Mapping[str, Any]]


class HumanInteractionPause(RuntimeError):
    """Stop the current execution stack after a request becomes durable."""


def human_input_tool(
    *,
    scopes: Sequence[str],
    visible_context_refs: Sequence[str],
) -> dict[str, Any]:
    allowed_scopes = tuple(dict.fromkeys(str(scope) for scope in scopes))
    if not allowed_scopes or not set(allowed_scopes).issubset(HUMAN_SCOPES):
        raise ValueError("human_input_tool_scopes_invalid")
    context_ref_schema: dict[str, Any] = {"type": "string"}
    visible_refs = tuple(
        dict.fromkeys(str(ref).strip() for ref in visible_context_refs if str(ref).strip())
    )
    if visible_refs:
        context_ref_schema["enum"] = list(visible_refs)
    return function_tool(
        "request_human_input",
        (
            "Pause all execution and ask one necessary human question at the "
            "current control boundary. Use only when available evidence and "
            "autonomous skills cannot responsibly supply the missing input. "
            "The request does not consume another node step or attempt while "
            "waiting."
        ),
        {
            "type": "object",
            "properties": {
                "scope": {"type": "string", "enum": list(allowed_scopes)},
                "question": {"type": "string", "minLength": 1, "maxLength": 4_000},
                "reason": {"type": "string", "minLength": 1, "maxLength": 2_000},
                "expected_response_role": {
                    "type": "string",
                    "enum": sorted(HUMAN_RESPONSE_ROLES),
                    "description": (
                        "Classify the answer's authority. Use feedback for "
                        "review comments or preferences that do not supply "
                        "scientific task input; scientific_input for missing "
                        "facts, measurements, domain choices, or bounded "
                        "preferences needed inside the existing objective; "
                        "task_contract_change only when the answer may revise "
                        "the objective, success criteria, or stop criteria and "
                        "therefore requires a new frame."
                    ),
                },
                "context_refs": {
                    "type": "array",
                    "items": context_ref_schema,
                    "uniqueItems": True,
                },
            },
            "required": [
                "scope",
                "question",
                "reason",
                "expected_response_role",
                "context_refs",
            ],
            "additionalProperties": False,
        },
    )


class SubLoopToolkit:
    """Persist one global human interruption without owning what happens next."""

    def __init__(
        self,
        *,
        enabled: bool,
        state: AgentStateStore,
        publish_artifact: ArtifactPublisher,
        validate_ref: ExactRefValidator,
        events: Any,
    ) -> None:
        self.enabled = bool(enabled)
        self._state = state
        self._publish_artifact = publish_artifact
        self._validate_ref = validate_ref
        self._events = events

    def pending(self) -> dict[str, Any] | None:
        if not self._state.path.exists():
            return None
        current = self._state.read()["c1"]["human_interaction_state"]
        if current["status"] != "pending":
            return None
        return copy.deepcopy(dict(current))

    def current(self) -> dict[str, Any] | None:
        if not self._state.path.exists():
            return None
        return copy.deepcopy(
            dict(self._state.read()["c1"]["human_interaction_state"])
        )

    def request(
        self,
        *,
        scope: str,
        requester: str,
        question: str,
        reason: str,
        expected_response_role: str,
        context_refs: Sequence[str],
        resume_anchor: Mapping[str, Any],
        allowed_scopes: Sequence[str],
        allowed_context_refs: Sequence[str],
    ) -> dict[str, Any]:
        if not self.enabled:
            raise RuntimeError("human_in_loop_disabled")
        normalized_scope = str(scope).strip()
        normalized_allowed_scopes = {
            str(item).strip() for item in allowed_scopes if str(item).strip()
        }
        if (
            normalized_scope not in HUMAN_SCOPES
            or normalized_scope not in normalized_allowed_scopes
        ):
            raise ValueError(
                "human_interaction_scope_not_available_at_current_boundary:"
                f"{normalized_scope}"
            )
        normalized_role = str(expected_response_role).strip()
        if normalized_role not in HUMAN_RESPONSE_ROLES:
            raise ValueError("human_interaction_expected_response_role_invalid")
        normalized_question = str(question).strip()
        normalized_reason = str(reason).strip()
        normalized_requester = str(requester).strip()
        if not normalized_question:
            raise ValueError("human_interaction_question_required")
        if not normalized_reason:
            raise ValueError("human_interaction_reason_required")
        if not normalized_requester:
            raise ValueError("human_interaction_requester_required")

        visible = {
            str(ref).strip()
            for ref in allowed_context_refs
            if str(ref).strip()
        }
        normalized_refs = tuple(
            dict.fromkeys(str(ref).strip() for ref in context_refs if str(ref).strip())
        )
        unauthorized = [ref for ref in normalized_refs if ref not in visible]
        if unauthorized:
            raise PermissionError(
                "human_interaction_context_ref_not_visible:" + ",".join(unauthorized)
            )
        for ref in normalized_refs:
            self._validate_ref(ref)

        previous = self.current()
        if previous is not None and previous["status"] == "pending":
            raise RuntimeError(
                "human_interaction_already_pending:"
                f"{previous['request_id']}"
            )
        if previous is not None and previous["status"] == "answered":
            response_ref = str(previous["response_ref"])
            if response_ref not in normalized_refs:
                normalized_refs = (*normalized_refs, response_ref)

        request_id = f"hitl-{uuid.uuid4().hex}"
        interaction = {
            "status": "pending",
            "request_id": request_id,
            "scope": normalized_scope,
            "requester": normalized_requester,
            "question": normalized_question,
            "reason": normalized_reason,
            "expected_response_role": normalized_role,
            "context_refs": list(normalized_refs),
            "resume_anchor": copy.deepcopy(dict(resume_anchor)),
            "response_ref": "",
        }
        self._state.set_human_interaction_state(interaction)
        self._events.append(
            "human_interaction_requested",
            {
                "request_id": request_id,
                "scope": normalized_scope,
                "requester": normalized_requester,
                "expected_response_role": normalized_role,
                "context_refs": list(normalized_refs),
                "resume_anchor": dict(resume_anchor),
            },
        )
        return {
            "status": "human_input_requested",
            "request_id": request_id,
            "scope": normalized_scope,
            "question": normalized_question,
        }

    def submit_response(
        self,
        *,
        request_id: str,
        response_text: str,
        declared_response_role: str | None = None,
        attachment_refs: Sequence[str] = (),
    ) -> dict[str, Any]:
        pending = self.pending()
        if pending is None:
            raise RuntimeError("human_interaction_pending_request_required")
        normalized_request_id = str(request_id).strip()
        if normalized_request_id != pending["request_id"]:
            raise ValueError(
                "human_interaction_request_id_mismatch:"
                f"expected={pending['request_id']}:actual={normalized_request_id}"
            )
        markdown = str(response_text).strip()
        if not markdown:
            raise ValueError("human_interaction_response_text_required")
        role = str(declared_response_role or pending["expected_response_role"]).strip()
        if role not in HUMAN_RESPONSE_ROLES:
            raise ValueError("human_interaction_declared_response_role_invalid")
        attachments = tuple(
            dict.fromkeys(
                str(ref).strip() for ref in attachment_refs if str(ref).strip()
            )
        )
        for ref in attachments:
            self._validate_ref(ref)
        dependencies = tuple(
            dict.fromkeys([*pending["context_refs"], *attachments])
        )
        receipt = self._publish_artifact(
            artifact_kind="human_interaction_response",
            artifact_id=f"human-response-{normalized_request_id}",
            title=f"Human response for {normalized_request_id}",
            markdown=markdown,
            summary=(
                f"Human supplied {role} for a {pending['scope']} interruption."
            ),
            status="accepted",
            machine_payload={
                "request_id": normalized_request_id,
                "scope": pending["scope"],
                "declared_response_role": role,
                "attachment_refs": list(attachments),
            },
            depends_on=dependencies,
            trace_refs=dependencies,
            verified_external_dependencies=tuple(
                ref for ref in dependencies if not ref.startswith("artifact:")
            ),
        )
        response_ref = str(receipt["artifact_ref"])
        answered = {
            **pending,
            "status": "answered",
            "response_ref": response_ref,
        }
        self._state.set_human_interaction_state(answered)
        self._state.add_resolved_artifact_ref(response_ref)
        self._events.append(
            "human_interaction_answered",
            {
                "request_id": normalized_request_id,
                "scope": pending["scope"],
                "declared_response_role": role,
                "response_ref": response_ref,
                "attachment_refs": list(attachments),
            },
        )
        return copy.deepcopy(dict(receipt))

    def mark_answer_consumed(self, *, consumer: str) -> None:
        current = self.current()
        if current is None or current["status"] != "answered":
            return
        self._state.clear_human_interaction_state()
        self._events.append(
            "human_interaction_answer_consumed",
            {
                "request_id": current["request_id"],
                "scope": current["scope"],
                "response_ref": current["response_ref"],
                "consumer": str(consumer),
            },
        )
