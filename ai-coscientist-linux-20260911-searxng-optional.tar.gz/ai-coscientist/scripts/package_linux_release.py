from __future__ import annotations

import argparse
import configparser
import hashlib
import io
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TREES = ("src", "skills", "docker", ".agents/skills")
ROOT_FILES = ("AGENTS.md", "README.md", "pyproject.toml", ".gitattributes")
DOCUMENTS = (
    "linux_deployment_zh-TW.md", "preparation_source_fidelity_20260911.md",
    "linux_release_verification_20260911.md",
    "memory_governance_long_running_work_schema_plan_zh-TW.md",
    "pending_security_label_design_zh-TW.md",
)
SCRIPTS = (
    "run_scientific_chat_linux.sh", "run_scientific_workflow_linux.sh",
    "run_scientific_workflow.py", "package_linux_release.py",
    "check_linux_deployment.py",
)
EXCLUDED_PARTS = {"__pycache__", ".pytest_cache", ".runtime", ".venv", "node_modules"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".ps1", ".cmd", ".bat", ".exe", ".dll"}


def release_files(root: Path) -> dict[str, Path]:
    candidates = [root / name for name in ROOT_FILES]
    candidates.extend(root / "scripts" / name for name in SCRIPTS)
    candidates.extend(root / "docs" / name for name in DOCUMENTS)
    candidates.extend((root / "docs").glob("*constitution*.md"))
    for tree in TREES:
        candidates.extend((root / tree).rglob("*"))
    registry = root / "managed_capabilities"
    candidates.extend(registry / name for name in
                      ("active.json", "CAPABILITY_CATALOG.md", "README.md"))
    for tree in ("routes/approved", "routes/pending", "skills/approved",
                 "skills/pending", "approvals", "reviews"):
        candidates.extend((registry / tree).rglob("*"))
    result = {}
    for path in candidates:
        relative = path.relative_to(root)
        if EXCLUDED_PARTS.intersection(relative.parts) or path.suffix.lower() in EXCLUDED_SUFFIXES:
            continue
        if path.is_symlink():
            raise ValueError(f"release_symlink_requires_explicit_review:{relative}")
        if not path.is_file():
            continue
        if not path.resolve().is_relative_to(root.resolve()):
            raise ValueError(f"release_path_outside_project:{relative}")
        result[relative.as_posix()] = path
    for required in (*ROOT_FILES, *(f"scripts/{name}" for name in SCRIPTS),
                     *(f"docs/{name}" for name in DOCUMENTS),
                     "src/ai_coscientist/cli/__main__.py",
                     "skills/scientific-report-writer/scripts/render_report.py"):
        if required not in result:
            raise FileNotFoundError(f"release_required_file_missing:{required}")
    return dict(sorted(result.items()))


def config_bytes(path: Path) -> bytes:
    source = configparser.ConfigParser(interpolation=None)
    source.read(path, encoding="utf-8")
    if not source.has_section("LLM"):
        raise ValueError("release_llm_config_missing")
    output = configparser.ConfigParser(interpolation=None)
    # Never include a working credential or unrelated configuration sections.
    keys = ("provider", "model_name", "api_base", "temperature", "max_tokens",
            "timeout", "reasoning_effort", "scientific_reasoning_effort",
            "repair_reasoning_effort", "planning_reasoning_effort")
    output["LLM"] = {key: source["LLM"][key] for key in keys if key in source["LLM"]}
    output["LLM"]["api_key"] = "no-key"
    stream = io.StringIO()
    output.write(stream)
    return stream.getvalue().encode("utf-8")


def git_value(root: Path, *arguments: str) -> str:
    process = subprocess.run(["git", "-C", str(root), *arguments], capture_output=True)
    if process.returncode:
        return "unavailable"
    return process.stdout.decode("utf-8", errors="replace").strip()


def write_bundle(root: Path, destination: Path, config: Path) -> dict[str, str]:
    if destination.exists():
        raise FileExistsError(destination)
    files = release_files(root)
    bodies = {name: path.read_bytes() for name, path in files.items()}
    # Package bytes are immutable; only standalone shell entry points need LF.
    for name in tuple(bodies):
        if name.startswith("scripts/") and name.endswith(".sh"):
            bodies[name] = bodies[name].replace(b"\r\n", b"\n")
    bodies["config_deepseek_v4_flash.cfg"] = config_bytes(config)
    provenance = (
        "AI Co-scientist Linux source release\n"
        f"created_utc={datetime.now(timezone.utc).isoformat()}\n"
        f"git_head={git_value(root, 'rev-parse', 'HEAD')}\n"
        "Source: current filesystem, including untracked production files.\n"
        "SHA256SUMS is the exact released content authority, not git HEAD alone.\n"
        "No prior task artifacts, runs, dialogue, caches or host environment included.\n"
        "Managed package bytes and approvals are retained unchanged.\n"
        "Docker images are separate; see docs/linux_deployment_zh-TW.md.\n"
    )
    bodies["RELEASE.txt"] = provenance.encode("utf-8")
    hashes = {name: hashlib.sha256(body).hexdigest() for name, body in bodies.items()}
    bodies["SHA256SUMS"] = "".join(f"{digest}  {name}\n" for name, digest in sorted(hashes.items())).encode()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("xb") as stream:
        with tarfile.open(fileobj=stream, mode="w:gz", format=tarfile.PAX_FORMAT) as archive:
            for name, body in sorted(bodies.items()):
                info = tarfile.TarInfo(f"ai-coscientist/{name}")
                info.size = len(body)
                info.mode = 0o755 if name.startswith("scripts/") and name.endswith(".sh") else 0o644
                archive.addfile(info, io.BytesIO(body))
    with tarfile.open(destination, "r:gz") as archive:
        for name, digest in hashes.items():
            content = archive.extractfile(f"ai-coscientist/{name}").read()
            if hashlib.sha256(content).hexdigest() != digest:
                raise ValueError(f"release_archive_hash_mismatch:{name}")
    return hashes


def main() -> int:
    parser = argparse.ArgumentParser(description="Package the current production tree without old task state.")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=ROOT / "config_deepseek_v4_flash.cfg")
    args = parser.parse_args()
    hashes = write_bundle(ROOT, args.output.resolve(), args.config.resolve())
    digest = hashlib.sha256(args.output.read_bytes()).hexdigest()
    print(f"Archive: {args.output.resolve()}\nFiles: {len(hashes)}\nSHA256: {digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
