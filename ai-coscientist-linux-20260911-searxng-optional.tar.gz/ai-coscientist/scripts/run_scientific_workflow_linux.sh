#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "${SCRIPT_DIR}/.." && pwd)"

PYTHON_BIN="${PYTHON_BIN:-python3.12}"
CONFIG_PATH="${PROJECT_ROOT}/config_deepseek_v4_flash.cfg"
SOURCE_ROOT=""
GOAL_RELATIVE_PATH=""
HISTORICAL_RELATIVE_PATH=""
OUTPUT_ROOT=""
EXPECTED_RECORD_COUNT=""
MAX_ROUNDS="120"
MAX_TOKENS=""
TIMEOUT_SECONDS=""
HUMAN_IN_LOOP=0
HUMAN_RESPONSE_FILE=""
HUMAN_RESPONSE_ROLE=""
RESUME=0
CHECK_ONLY=0
BUILD_NATIVE_RUNTIME=0
NATIVE_RUNTIME_TAG="ai-coscientist-native-science:py312-v1"
ADDITIONAL_RUNTIMES=()
FORWARDED_ARGS=()

usage() {
    cat <<'EOF'
Run the dynamic scientific workflow from a clean Linux runtime directory.

Required:
  --source-root PATH       Directory containing the task source files.
  --goal PATH              Goal file path relative to --source-root.
  --historical PATH        Historical JSON path relative to --source-root.

Common options:
  --config PATH            LLM config (default: config_deepseek_v4_flash.cfg).
  --output PATH            Run directory (default: runs/linux-<UTC timestamp>).
  --expected-record-count N
                           Override automatic top-level records[] counting.
  --max-rounds N           Common-agent round limit (default: 120).
  --max-tokens N           Override config max_tokens.
  --timeout SECONDS        Override config timeout.
  --human-in-loop          Enable human interaction tools.
  --human-response-file PATH
                           Submit a response while resuming an existing run.
  --human-response-role ROLE
                           feedback, scientific_input, or task_contract_change.
  --resume                 Reuse --output instead of requiring a clean path.
  --check-only             Validate deployment and print the resolved command
                           without creating a run or calling the LLM.

Docker options:
  --build-native-runtime   Build docker/native-science-py312 and use its
                           immutable local image ID as the default environment.
  --native-runtime-tag TAG Mutable build tag used only to obtain the image ID.
  --additional-runtime REF Register another repository@sha256 or sha256 image.

Environment:
  PYTHON_BIN               Python executable (default: python3.12).

Use -- to forward additional arguments to run_scientific_workflow.py.
EOF
}

die() {
    printf 'error: %s\n' "$*" >&2
    exit 2
}

absolute_path() {
    local value="$1"
    if [[ "${value}" == /* ]]; then
        printf '%s\n' "${value}"
    else
        printf '%s\n' "$(pwd)/${value}"
    fi
}

while (($#)); do
    case "$1" in
        --source-root)
            (($# >= 2)) || die "--source-root requires a value"
            SOURCE_ROOT="$2"
            shift 2
            ;;
        --goal)
            (($# >= 2)) || die "--goal requires a value"
            GOAL_RELATIVE_PATH="$2"
            shift 2
            ;;
        --historical)
            (($# >= 2)) || die "--historical requires a value"
            HISTORICAL_RELATIVE_PATH="$2"
            shift 2
            ;;
        --config)
            (($# >= 2)) || die "--config requires a value"
            CONFIG_PATH="$2"
            shift 2
            ;;
        --output)
            (($# >= 2)) || die "--output requires a value"
            OUTPUT_ROOT="$2"
            shift 2
            ;;
        --expected-record-count)
            (($# >= 2)) || die "--expected-record-count requires a value"
            EXPECTED_RECORD_COUNT="$2"
            shift 2
            ;;
        --max-rounds)
            (($# >= 2)) || die "--max-rounds requires a value"
            MAX_ROUNDS="$2"
            shift 2
            ;;
        --max-tokens)
            (($# >= 2)) || die "--max-tokens requires a value"
            MAX_TOKENS="$2"
            shift 2
            ;;
        --timeout)
            (($# >= 2)) || die "--timeout requires a value"
            TIMEOUT_SECONDS="$2"
            shift 2
            ;;
        --human-in-loop)
            HUMAN_IN_LOOP=1
            shift
            ;;
        --human-response-file)
            (($# >= 2)) || die "--human-response-file requires a value"
            HUMAN_RESPONSE_FILE="$2"
            shift 2
            ;;
        --human-response-role)
            (($# >= 2)) || die "--human-response-role requires a value"
            HUMAN_RESPONSE_ROLE="$2"
            shift 2
            ;;
        --resume)
            RESUME=1
            shift
            ;;
        --check-only)
            CHECK_ONLY=1
            shift
            ;;
        --build-native-runtime)
            BUILD_NATIVE_RUNTIME=1
            shift
            ;;
        --native-runtime-tag)
            (($# >= 2)) || die "--native-runtime-tag requires a value"
            NATIVE_RUNTIME_TAG="$2"
            shift 2
            ;;
        --additional-runtime)
            (($# >= 2)) || die "--additional-runtime requires a value"
            ADDITIONAL_RUNTIMES+=("$2")
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        --)
            shift
            FORWARDED_ARGS+=("$@")
            break
            ;;
        *)
            die "unknown option: $1"
            ;;
    esac
done

[[ -n "${SOURCE_ROOT}" ]] || die "--source-root is required"
[[ -n "${GOAL_RELATIVE_PATH}" ]] || die "--goal is required"
[[ -n "${HISTORICAL_RELATIVE_PATH}" ]] || die "--historical is required"
[[ "${GOAL_RELATIVE_PATH}" != /* ]] || die "--goal must be relative"
[[ "${HISTORICAL_RELATIVE_PATH}" != /* ]] || die "--historical must be relative"

SOURCE_ROOT="$(absolute_path "${SOURCE_ROOT}")"
CONFIG_PATH="$(absolute_path "${CONFIG_PATH}")"
if [[ -z "${OUTPUT_ROOT}" ]]; then
    OUTPUT_ROOT="${PROJECT_ROOT}/runs/linux-$(date -u +%Y%m%dT%H%M%SZ)"
else
    OUTPUT_ROOT="$(absolute_path "${OUTPUT_ROOT}")"
fi

GOAL_PATH="${SOURCE_ROOT}/${GOAL_RELATIVE_PATH}"
HISTORICAL_PATH="${SOURCE_ROOT}/${HISTORICAL_RELATIVE_PATH}"

command -v "${PYTHON_BIN}" >/dev/null 2>&1 || \
    die "Python executable not found: ${PYTHON_BIN}"
"${PYTHON_BIN}" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)' || \
    die "Python 3.12 is required: ${PYTHON_BIN}"
"${PYTHON_BIN}" -c 'import fitz, requests, trafilatura' >/dev/null 2>&1 || \
    die "project dependencies missing; run: ${PYTHON_BIN} -m pip install -e ${PROJECT_ROOT}"

[[ -f "${CONFIG_PATH}" ]] || die "LLM config not found: ${CONFIG_PATH}"
[[ -f "${GOAL_PATH}" ]] || die "goal file not found: ${GOAL_PATH}"
[[ -f "${HISTORICAL_PATH}" ]] || \
    die "historical file not found: ${HISTORICAL_PATH}"

if ((RESUME)); then
    [[ -d "${OUTPUT_ROOT}" ]] || \
        die "--resume requires an existing output directory: ${OUTPUT_ROOT}"
else
    [[ ! -e "${OUTPUT_ROOT}" ]] || \
        die "clean run output already exists: ${OUTPUT_ROOT}"
fi

mapfile -t SOURCE_METADATA < <(
    "${PYTHON_BIN}" - "${GOAL_PATH}" "${HISTORICAL_PATH}" <<'PY'
import hashlib
import json
import sys
from pathlib import Path

goal = Path(sys.argv[1])
historical = Path(sys.argv[2])
print(hashlib.sha256(goal.read_bytes()).hexdigest())
print(hashlib.sha256(historical.read_bytes()).hexdigest())
payload = json.loads(historical.read_text(encoding="utf-8"))
records = payload.get("records") if isinstance(payload, dict) else None
if not isinstance(records, list) or not records:
    raise SystemExit("historical JSON must contain a non-empty records[] array")
print(len(records))
PY
)

((${#SOURCE_METADATA[@]} == 3)) || die "failed to inspect task source files"
GOAL_SHA256="${SOURCE_METADATA[0]%$'\r'}"
HISTORICAL_SHA256="${SOURCE_METADATA[1]%$'\r'}"
if [[ -z "${EXPECTED_RECORD_COUNT}" ]]; then
    EXPECTED_RECORD_COUNT="${SOURCE_METADATA[2]%$'\r'}"
fi

[[ "${EXPECTED_RECORD_COUNT}" =~ ^[1-9][0-9]*$ ]] || \
    die "expected record count must be a positive integer"
[[ "${MAX_ROUNDS}" =~ ^[1-9][0-9]*$ ]] || \
    die "max rounds must be a positive integer"

command -v docker >/dev/null 2>&1 || die "Docker CLI is required"
docker info >/dev/null 2>&1 || die "Docker daemon is not available"

if ((BUILD_NATIVE_RUNTIME)); then
    docker build \
        --pull=false \
        --tag "${NATIVE_RUNTIME_TAG}" \
        "${PROJECT_ROOT}/docker/native-science-py312"
    NATIVE_IMAGE_ID="$(docker image inspect "${NATIVE_RUNTIME_TAG}" --format '{{.Id}}')"
    [[ "${NATIVE_IMAGE_ID}" =~ ^sha256:[0-9a-f]{64}$ ]] || \
        die "native runtime did not produce an immutable image ID"
fi

if ((!RESUME && !CHECK_ONLY)); then
    mkdir -p "${OUTPUT_ROOT}"
fi

export PYTHONPATH="${PROJECT_ROOT}/src${PYTHONPATH:+:${PYTHONPATH}}"

COMMAND=(
    "${PYTHON_BIN}"
    "${PROJECT_ROOT}/scripts/run_scientific_workflow.py"
    --config "${CONFIG_PATH}"
    --source-root "${SOURCE_ROOT}"
    --goal-relative-path "${GOAL_RELATIVE_PATH}"
    --historical-relative-path "${HISTORICAL_RELATIVE_PATH}"
    --goal-sha256 "${GOAL_SHA256}"
    --historical-sha256 "${HISTORICAL_SHA256}"
    --expected-record-count "${EXPECTED_RECORD_COUNT}"
    --output "${OUTPUT_ROOT}"
    --capability-registry "${PROJECT_ROOT}/managed_capabilities"
    --max-rounds "${MAX_ROUNDS}"
)

[[ -z "${MAX_TOKENS}" ]] || COMMAND+=(--max-tokens "${MAX_TOKENS}")
[[ -z "${TIMEOUT_SECONDS}" ]] || COMMAND+=(--timeout "${TIMEOUT_SECONDS}")
((HUMAN_IN_LOOP == 0)) || COMMAND+=(--human-in-loop)
[[ -z "${HUMAN_RESPONSE_FILE}" ]] || \
    COMMAND+=(--human-response-file "$(absolute_path "${HUMAN_RESPONSE_FILE}")")
[[ -z "${HUMAN_RESPONSE_ROLE}" ]] || \
    COMMAND+=(--human-response-role "${HUMAN_RESPONSE_ROLE}")

if ((BUILD_NATIVE_RUNTIME)); then
    COMMAND+=(
        --capability-docker-base-image "ai-coscientist-native-science"
        --capability-docker-base-image-digest "${NATIVE_IMAGE_ID}"
        --capability-docker-base-image-reference "${NATIVE_IMAGE_ID}"
    )
fi

for runtime in "${ADDITIONAL_RUNTIMES[@]}"; do
    COMMAND+=(--capability-docker-additional-runtime "${runtime}")
done
COMMAND+=("${FORWARDED_ARGS[@]}")

printf 'project_root=%s\n' "${PROJECT_ROOT}"
printf 'run_root=%s\n' "${OUTPUT_ROOT}"
printf 'source_records=%s\n' "${EXPECTED_RECORD_COUNT}"
if ((CHECK_ONLY)); then
    printf 'resolved_command='
    printf '%q ' "${COMMAND[@]}"
    printf '\ncheck_only=complete\n'
    exit 0
fi
printf 'starting clean scientific workflow\n'

exec "${COMMAND[@]}"
