from __future__ import annotations

import argparse
import configparser
import json
import re
import sys
from pathlib import Path
from typing import Any, Mapping

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT_DEFAULT = PROJECT_ROOT.parent / "final-kpi-route-evolver-rewrite"
if str(PROJECT_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "src"))

from ai_coscientist.common.openai_compatible import OpenAICompatibleModel
from ai_coscientist.common.capabilities import (
    CapabilityRegistry,
    DockerPythonExecutor,
    DockerRouteExecutorPool,
    resolve_local_docker_image_id,
)
from ai_coscientist.common.runtime import CommonAgent
from ai_coscientist.domain.session import (
    SCIENTIFIC_EVALUATION_REQUEST,
    create_scientific_session,
    project_workspace_exclusions as _session_workspace_exclusions,
)
from ai_coscientist.domain.source_authority import SourceSpec


DEFAULT_GOAL_RELATIVE_PATH = "goal_ch_new.txt"
DEFAULT_HISTORICAL_RELATIVE_PATH = (
    "dataset/ch_fake_historical_data_no_sam.json"
)
GOAL_SHA256 = (
    "04bf43d6f9bade98e725e956351d8ae5f3799c6bc56caf4de9b86fcc844f9803"
)
HISTORICAL_SHA256 = (
    "1925f884b59fdd20bbb38bce03d730e914ed482758ada33b1c4a39f8809d23c3"
)
DEFAULT_CAPABILITY_REGISTRY = PROJECT_ROOT / "managed_capabilities"
DEFAULT_CAPABILITY_DOCKER_IMAGE = "ai-coscientist-native-science"
DEFAULT_CAPABILITY_DOCKER_LOCAL_TAG = (
    "ai-coscientist-native-science:py312-v2"
)
DEFAULT_CAPABILITY_DOCKER_DIGEST: str | None = None


def main() -> int:
    arguments = _arguments()
    source_root = arguments.source_root.resolve()
    run_root = arguments.output.resolve()
    config = _llm_config(arguments.config.resolve())
    source_spec = _source_spec_from_arguments(arguments, source_root=source_root)
    capability_executor = _capability_route_executor(arguments)
    capability_registry = CapabilityRegistry(
        arguments.capability_registry.resolve(),
        python_executable=sys.executable,
        route_executor=capability_executor,
    )
    model = OpenAICompatibleModel(
        base_url=config["api_base"],
        model=config["model_name"],
        api_key=config["api_key"],
        timeout_seconds=(
            arguments.timeout
            if arguments.timeout is not None
            else float(config["timeout"])
        ),
        max_tokens=(
            arguments.max_tokens
            if arguments.max_tokens is not None
            else int(config["max_tokens"])
        ),
        temperature=float(config["temperature"]),
        reasoning_effort=config["reasoning_effort"],
        scientific_reasoning_effort=config.get(
            "scientific_reasoning_effort", ""
        ),
        repair_reasoning_effort=config.get("repair_reasoning_effort", ""),
        planning_reasoning_effort=config.get("planning_reasoning_effort", ""),
        on_status=_print_status,
        debug_trace_path=run_root / "llm-reasoning-debug.jsonl",
    )
    session = create_scientific_session(
        run_root=run_root,
        source_spec=source_spec,
        model=model,
        project_root=PROJECT_ROOT,
        capability_registry=capability_registry,
        max_rounds=arguments.max_rounds,
        human_in_loop_enabled=arguments.human_in_loop,
        python_executable=sys.executable,
    )
    workflow = session.workflow
    agent = session.agent
    submitted_response = _submit_human_response_if_requested(
        agent,
        response_file=arguments.human_response_file,
        declared_response_role=arguments.human_response_role,
    )
    if submitted_response is not None:
        print(
            "Submitted human response: "
            f"{submitted_response['artifact_ref']}",
            flush=True,
        )
    try:
        result = agent.run(
            objective=session.objective,
            evaluation_summary=SCIENTIFIC_EVALUATION_REQUEST,
        )
    finally:
        capability_executor.close()
    output = {
        "status": result.status,
        "rounds": result.rounds,
        "final_text": result.final_text,
        "closure": dict(result.closure),
        "artifact_index": list(workflow.artifacts.list()),
        "source_manifest": workflow.source_authority.manifest(),
    }
    result_path = run_root / "result.json"
    result_path.write_text(
        json.dumps(output, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"Result: {result_path}")
    print(f"Status: {result.status}")
    print(f"Rounds: {result.rounds}")
    pending = agent.pending_human_interaction()
    if pending is not None:
        print("Pending human interaction:", flush=True)
        print(
            json.dumps(pending, ensure_ascii=False, indent=2),
            flush=True,
        )
    return 0 if result.status in {"complete", "paused_for_human"} else 2


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the pure-Python dynamic scientific coordinator."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=SOURCE_ROOT_DEFAULT / "config_ch.cfg",
    )
    parser.add_argument(
        "--source-root",
        type=Path,
        default=SOURCE_ROOT_DEFAULT,
        help="Root containing the pinned goal and historical files.",
    )
    parser.add_argument(
        "--goal-relative-path",
        default=DEFAULT_GOAL_RELATIVE_PATH,
        help="Goal path relative to --source-root.",
    )
    parser.add_argument(
        "--historical-relative-path",
        default=DEFAULT_HISTORICAL_RELATIVE_PATH,
        help="Prepared historical JSON path relative to --source-root.",
    )
    parser.add_argument(
        "--goal-sha256",
        help="Required pinned SHA256 when a custom goal path is used.",
    )
    parser.add_argument(
        "--historical-sha256",
        help="Required pinned SHA256 when a custom historical path is used.",
    )
    parser.add_argument(
        "--expected-record-count",
        type=int,
        default=5,
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--capability-registry",
        type=Path,
        default=DEFAULT_CAPABILITY_REGISTRY,
        help="Project-level managed Skill and Route registry.",
    )
    parser.add_argument(
        "--capability-docker-base-image",
        default=DEFAULT_CAPABILITY_DOCKER_IMAGE,
    )
    parser.add_argument(
        "--capability-docker-base-image-digest",
        default=DEFAULT_CAPABILITY_DOCKER_DIGEST,
        help=(
            "Immutable default-runtime digest. When omitted with the default "
            "repository, resolve the local native-science tag to its image ID."
        ),
    )
    parser.add_argument(
        "--capability-docker-base-image-reference",
        help=(
            "Optional exact Docker reference for the default runtime. Use the "
            "digest itself for one locally built image; otherwise the default "
            "is repository@digest."
        ),
    )
    parser.add_argument(
        "--capability-docker-additional-runtime",
        action="append",
        default=[],
        metavar="EXACT_IMAGE_REFERENCE",
        help=(
            "Register another execution runtime. Repeat for each exact "
            "repository@sha256 digest or local sha256 image ID."
        ),
    )
    parser.add_argument("--capability-docker-cache-root", type=Path)
    parser.add_argument("--max-rounds", type=int, default=120)
    parser.add_argument("--max-tokens", type=int)
    parser.add_argument("--timeout", type=float)
    parser.add_argument(
        "--human-in-loop",
        action="store_true",
        help=(
            "Expose human-interaction tools and treat a durable human request "
            "as an expected pause boundary."
        ),
    )
    parser.add_argument(
        "--human-response-file",
        type=Path,
        help=(
            "Submit this UTF-8 text to the one pending interaction in the "
            "existing output directory before resuming."
        ),
    )
    parser.add_argument(
        "--human-response-role",
        choices=("feedback", "scientific_input", "task_contract_change"),
        help=(
            "Optional authority override for the submitted response; by "
            "default the pending request's expected role is retained."
        ),
    )
    return parser.parse_args()


def _capability_route_executor(
    arguments: argparse.Namespace,
) -> DockerPythonExecutor | DockerRouteExecutorPool:
    cache_root = (
        arguments.capability_docker_cache_root.resolve()
        if arguments.capability_docker_cache_root is not None
        else PROJECT_ROOT
        / "managed_capabilities"
        / ".runtime"
        / "docker-cache"
    )
    base_digest, base_reference = _default_docker_runtime_identity(arguments)
    default = DockerPythonExecutor(
        cache_root=cache_root,
        base_image_repository=arguments.capability_docker_base_image,
        base_image_digest=base_digest,
        base_image_reference=base_reference,
    )
    additional = [
        _docker_executor_from_exact_reference(value, cache_root=cache_root)
        for value in arguments.capability_docker_additional_runtime
    ]
    if not additional:
        return default
    return DockerRouteExecutorPool(default, additional)


def _default_docker_runtime_identity(
    arguments: argparse.Namespace,
) -> tuple[str, str | None]:
    digest = str(arguments.capability_docker_base_image_digest or "").strip()
    reference = str(arguments.capability_docker_base_image_reference or "").strip()
    if digest:
        return digest, reference or None
    if reference:
        if re.fullmatch(r"sha256:[0-9a-fA-F]{64}", reference):
            return reference.lower(), reference.lower()
        _repository, separator, candidate_digest = reference.rpartition("@")
        if separator and re.fullmatch(
            r"sha256:[0-9a-fA-F]{64}", candidate_digest
        ):
            return candidate_digest.lower(), reference
        raise ValueError("capability_docker_base_image_reference_not_exact")
    if arguments.capability_docker_base_image != DEFAULT_CAPABILITY_DOCKER_IMAGE:
        raise ValueError("custom_docker_base_image_digest_required")
    image_id = resolve_local_docker_image_id(
        DEFAULT_CAPABILITY_DOCKER_LOCAL_TAG
    )
    return image_id, image_id


def _docker_executor_from_exact_reference(
    value: str,
    *,
    cache_root: Path,
) -> DockerPythonExecutor:
    reference = str(value).strip()
    if re.fullmatch(r"sha256:[0-9a-fA-F]{64}", reference):
        digest = reference.lower()
        repository = "local-image"
        exact_reference = digest
    else:
        repository, separator, digest = reference.rpartition("@")
        digest = digest.lower()
        if (
            not separator
            or not repository
            or re.fullmatch(r"sha256:[0-9a-f]{64}", digest) is None
        ):
            raise ValueError(
                f"capability_docker_runtime_reference_invalid:{reference}"
            )
        exact_reference = f"{repository}@{digest}"
    return DockerPythonExecutor(
        cache_root=cache_root,
        base_image_repository=repository,
        base_image_digest=digest,
        base_image_reference=exact_reference,
    )


def _submit_human_response_if_requested(
    agent: CommonAgent,
    *,
    response_file: Path | None,
    declared_response_role: str | None,
) -> Mapping[str, Any] | None:
    if response_file is None:
        return None
    pending = agent.pending_human_interaction()
    if pending is None:
        raise RuntimeError("human_response_requires_pending_interaction")
    resolved = response_file.resolve()
    try:
        response_text = resolved.read_text(encoding="utf-8")
    except OSError as exc:
        raise RuntimeError(
            f"human_response_file_unreadable:{resolved}:{exc}"
        ) from exc
    if not response_text.strip():
        raise ValueError(f"human_response_file_empty:{resolved}")
    return agent.submit_human_response(
        str(pending["request_id"]),
        response_text,
        declared_response_role=declared_response_role,
    )


def _project_workspace_exclusions(
    *,
    project_root: Path,
    source_spec: SourceSpec,
) -> tuple[str, ...]:
    """Hide the exact evaluator-authority source from project exploration."""
    return _session_workspace_exclusions(
        project_root=project_root,
        source_spec=source_spec,
    )


def _source_spec_from_arguments(
    arguments: argparse.Namespace,
    *,
    source_root: Path,
) -> SourceSpec:
    goal_relative_path = str(arguments.goal_relative_path).strip()
    historical_relative_path = str(arguments.historical_relative_path).strip()
    if not goal_relative_path or not historical_relative_path:
        raise ValueError("source_relative_paths_required")
    custom_goal = goal_relative_path != DEFAULT_GOAL_RELATIVE_PATH
    custom_historical = (
        historical_relative_path != DEFAULT_HISTORICAL_RELATIVE_PATH
    )
    goal_sha256 = str(arguments.goal_sha256 or "").strip()
    historical_sha256 = str(arguments.historical_sha256 or "").strip()
    if not goal_sha256:
        if custom_goal:
            raise ValueError("custom_source_goal_sha256_required")
        goal_sha256 = GOAL_SHA256
    if not historical_sha256:
        if custom_historical:
            raise ValueError("custom_source_historical_sha256_required")
        historical_sha256 = HISTORICAL_SHA256
    expected_record_count = arguments.expected_record_count
    if (
        isinstance(expected_record_count, bool)
        or not isinstance(expected_record_count, int)
        or expected_record_count < 1
    ):
        raise ValueError("expected_record_count_must_be_positive_integer")
    return SourceSpec(
        source_root=source_root,
        goal_relative_path=goal_relative_path,
        historical_relative_path=historical_relative_path,
        goal_sha256=goal_sha256.lower(),
        historical_sha256=historical_sha256.lower(),
        expected_record_count=expected_record_count,
    )


def _llm_config(path: Path) -> dict[str, str]:
    parser = configparser.ConfigParser()
    if not parser.read(path, encoding="utf-8"):
        raise FileNotFoundError(f"llm_config_missing:{path}")
    if not parser.has_section("LLM"):
        raise ValueError(f"llm_config_section_missing:{path}:LLM")
    section = parser["LLM"]
    required = ("model_name", "api_base", "api_key", "timeout", "max_tokens")
    missing = [key for key in required if not section.get(key, "").strip()]
    if missing:
        raise ValueError(f"llm_config_keys_missing:{missing}")
    return {
        "model_name": section["model_name"].strip(),
        "api_base": section["api_base"].strip(),
        "api_key": section["api_key"].strip(),
        "timeout": section["timeout"].strip(),
        "max_tokens": section["max_tokens"].strip(),
        "temperature": section.get("temperature", "0.0").strip(),
        "reasoning_effort": section.get("reasoning_effort", "").strip(),
        "scientific_reasoning_effort": section.get(
            "scientific_reasoning_effort", ""
        ).strip(),
        "repair_reasoning_effort": section.get(
            "repair_reasoning_effort", ""
        ).strip(),
        "planning_reasoning_effort": section.get(
            "planning_reasoning_effort", ""
        ).strip(),
    }


def _print_status(event: Mapping[str, Any]) -> None:
    kind = str(event.get("event") or "status")
    purpose = str(event.get("purpose") or "")
    if kind == "delta":
        return
    details = " ".join(
        f"{key}={value}"
        for key, value in event.items()
        if key not in {"event", "purpose", "body"}
    )
    print(f"[llm:{kind}] purpose={purpose} {details}".rstrip(), flush=True)


if __name__ == "__main__":
    raise SystemExit(main())
