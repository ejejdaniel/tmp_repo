from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def verify_files(root: Path) -> None:
    manifest = root / "SHA256SUMS"
    if not manifest.exists():
        print("File hashes: not a packaged release; checking working tree")
        return
    lines = manifest.read_text(encoding="utf-8").splitlines()
    overrides = 0
    for line in lines:
        digest, name = line.split("  ", 1)
        path = (root / name).resolve()
        if not path.is_relative_to(root.resolve()) or not path.is_file():
            raise ValueError(f"release_file_missing_or_outside_root:{name}")
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            if name == "config_deepseek_v4_flash.cfg":
                overrides += 1
                print("LLM config: locally changed; will validate the configured values")
                continue
            raise ValueError(f"release_file_changed:{name}")
    print(f"File hashes: {len(lines) - overrides} verified; local config overrides: {overrides}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Check deployment without creating a task or calling an LLM.")
    parser.add_argument("--config", type=Path, default=ROOT / "config_deepseek_v4_flash.cfg")
    parser.add_argument("--skip-docker", action="store_true")
    parser.add_argument("--skip-pdf", action="store_true")
    args = parser.parse_args()
    if sys.version_info < (3, 12):
        raise RuntimeError("Python 3.12 or later is required")
    verify_files(ROOT)
    for module in ("markdown", "requests", "trafilatura", "fitz"):
        importlib.import_module(module)
    from ai_coscientist.cli.scientific_chat import _llm_config, DEFAULT_DOCKER_LOCAL_TAG
    from ai_coscientist.common.capabilities import CapabilityRegistry
    from ai_coscientist.domain.scientific_reporting import report_renderer
    config = _llm_config(args.config.resolve())
    print(f"Python dependencies: available\nLLM config: {config['api_base']} ({config['model_name']}); no request sent")
    subprocess.run([sys.executable, "-m", "ai_coscientist.cli", "chat", "--help"],
                   cwd=ROOT, check=True, capture_output=True,
                   env={**os.environ, "PYTHONPATH": str(ROOT / "src")})
    print("Production CLI parser: available")
    registry_root = ROOT / "managed_capabilities"
    # Validate in a disposable copy; a deployment check does not mutate approvals.
    with tempfile.TemporaryDirectory(prefix="scientific-registry-check-") as temporary:
        copied = Path(temporary) / "managed_capabilities"
        shutil.copytree(registry_root, copied, ignore=shutil.ignore_patterns(".runtime", "__pycache__"))
        registry = CapabilityRegistry(copied, python_executable=sys.executable)
        packages = []
        for category in ("skills", "routes"):
            for state in ("approved", "pending"):
                packages.extend((copied / category / state).glob("*/*/candidate.json"))
        for package in packages:
            registry._verify_package(package.parent)
        print(f"Managed packages: {len(packages)} exact manifests and payload hashes verified")
    if args.skip_docker:
        print("Docker: SKIPPED, execution availability unverified")
    else:
        if not shutil.which("docker"):
            raise RuntimeError("Docker CLI is required")
        subprocess.run(["docker", "info"], check=True, capture_output=True, timeout=30)
        image = subprocess.run(["docker", "image", "inspect", DEFAULT_DOCKER_LOCAL_TAG],
                               check=True, capture_output=True, text=True, timeout=30)
        entry = json.loads(image.stdout)[0]
        print(f"Default scientific environment: {entry['Id']} ({entry['Os']}/{entry['Architecture']})")
        for lock in sorted((ROOT / "managed_capabilities/routes").glob("*/*/*/payload/runtime.lock.json")):
            digest = json.loads(lock.read_text(encoding="utf-8"))["base_image_digest"]
            print(f"Managed Route requires runtime identity {digest}: {lock.relative_to(ROOT)}")
        print("Route identities above must also be supplied with --capability-docker-additional-runtime when used.")
    if args.skip_pdf:
        print("PDF: SKIPPED, final PDF delivery unverified")
    else:
        with tempfile.TemporaryDirectory(prefix="scientific-release-check-") as temporary:
            folder = Path(temporary)
            html = folder / "check.html"
            html.write_text('<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><body>'
                            '<h1>科研報告部署測試</h1><p>H2 polarizability: units and references.</p>'
                            '</body></html>', encoding="utf-8")
            pdf = folder / "check.pdf"
            report_renderer()._render_pdf(html, pdf)
            import fitz
            with fitz.open(pdf) as document:
                if document.page_count < 1 or "H2 polarizability" not in document[0].get_text():
                    raise RuntimeError("release_pdf_text_missing")
            print("Production PDF renderer: generated a readable PDF (not a research report)")
    print("Deployment checks complete. No scientific task or LLM call was executed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
