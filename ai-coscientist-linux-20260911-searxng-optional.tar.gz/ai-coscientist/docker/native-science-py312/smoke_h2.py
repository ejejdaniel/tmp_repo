from ase import Atoms
from gpaw import GPAW, PW

atoms = Atoms(
    "H2",
    positions=[[0.0, 0.0, 0.0], [0.0, 0.0, 0.74]],
    cell=[6.0, 6.0, 6.0],
    pbc=True,
)
atoms.calc = GPAW(
    mode=PW(150),
    xc="PBE",
    kpts=(1, 1, 1),
    txt=None,
)
energy = atoms.get_potential_energy()
forces = atoms.get_forces()
print(
    {
        "energy_eV": float(energy),
        "max_abs_force": float(abs(forces).max()),
    }
)
