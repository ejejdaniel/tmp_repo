# Native science Python runtime

This project-owned Docker image is the fixed default scientific environment
used by Materializer project authoring, terminal checks, and formal execution.
It extends Python 3.12 slim with a C/C++ compiler, OpenBLAS, LibXC, GPAW, ASE,
PAW datasets, RDKit, NumPy, SciPy, and pandas.

Materializer does not install packages or switch environments. Approved and
pending Routes may still run through the broker as optional APIs in their own
environments, but normal scientific implementation uses the packages baked
into this image directly.

Build it with:

```powershell
& .\scripts\build_native_science_runtime.ps1
```

The script prints the exact local image ID. Pass that `sha256:...` value as an
exact runtime reference; do not bind Route execution to the mutable tag.

`gpaw-smoke-requirements.lock` is the pinned package set installed by the
Dockerfile. `smoke_h2.py` performs a real GPAW energy and force calculation.
It registers PAW data through `gpaw_data.datapath()` so common runtime code
does not contain a package-specific path.

This first profile is serial by design. MPI, ScaLAPACK, FFTW, and GPU support
require separate runtime profiles and separate validation.
