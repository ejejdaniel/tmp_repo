# 長期工作記憶：精確格式與替換計畫

日期：2026-09-02

狀態：專案負責人已核准本文件所列精確變更；隔離工作樹已實作，通過原失敗資料邊界重播、真實 LLM 壓縮與 Materializer 下一步決策驗證。完整執行與端到端仍未通過，詳見 [驗證紀錄](long_running_work_memory_verification_zh-TW.md)。

上位提案：[長期研究與程式開發的記憶治理修訂提案](memory_governance_long_running_work_proposal_zh-TW.md)。

## 一、實作版本與邊界

採用一份由 common 管理的持久工作紀錄，取代單次 Skill 摘要及各處獨立拼接恢復資料的做法。這不是新增 C7，也不是再保留一份競爭權威的交接包。

**工作範圍**是某位代理正在接續的一段工作及其明確輸入。它可以跨 Skill、attempt 或 Frame，但不會自動取得行動權限。child 仍建立自己的範圍，只匯入 mission 明確授權的紀錄。

原碼、snapshot、執行觀察仍放在原有資料庫。新存放位置保存 C3 工作說明、精確操作回條及它們的關聯，不再拷貝整個程式專案。

第一版不新增筆記專用 LLM、不增加審查層、不改封存 LOOP 計畫、不增減 attempt 額度，也不修改科學 artifact 格式。

## 二、AgentState 的精確差異

`src/ai_coscientist/common/memory_lifecycle/state.py` 的工作記憶狀態版本先由 `15` 改為 `16`；後續對話記憶整併再升為 `17`。

| 路徑 | 變更 | 意義 |
|---|---|---|
| `c1.active_work_context_ref` | 新增，`string \| null`，初始 `null` | 目前選定的工作範圍；非空值只能為下節定義的 `work_context:` 引用 |
| `c1.wiki_summary_through_sequence` | 移除 | 不再用一個代理全域游標追蹤不同工作的壓縮 |
| `c3.wiki_summary` | 移除 | 內容與摘要改由持久工作資料庫保存；不保留雙寫 |

版本 `17` 移除 `c3.dialogue_summary` 與 `c1.dialogue_summary_through_count`。CLI 對話摘要改存於同一份 `work-memory.sqlite3` 的 `dialogue_memory` 表，欄位為 `dialogue_id`、`summary_markdown` 與 `through_message_count`；逐則原文仍只存在 `dialogue/transcript.jsonl`。首次載入版本 `16` 狀態時，runtime 會將舊摘要與游標交易式遷移；新舊內容衝突時明確失敗，不靜默選邊。

當前工作引用是 C1 控制指標；工作內容的唯一權威在工作資料庫。切換指標不會刪除原工作。初始化、恢復、Skill 載入與釋放不得再清空持久工作內容。

## 三、唯一存放位置與引用

新增 `WorkMemoryStore`，實作放在 `common/memory_lifecycle/`。實體使用目前任務共用儲存根目錄下的 `work-memory.sqlite3`，由 Python 標準庫 `sqlite3` 操作，不引入伺服器或外部套件。

選擇 SQLite 是為了讓工作紀錄、索引與摘要游標可以交易式更新，並能按工作分頁讀取；不另外自行設計 JSONL 位移索引。它是儲存實作，不是新記憶類別。

資料庫初版 `user_version=1`，三張資料表分別對應下列工作範圍、工作紀錄、摘要 checkpoint；對話記憶整併後升為 `user_version=2`，新增 `dialogue_memory` 導航摘要表，不另建平行的 JSON 正本。

新增兩種引用命名空間：

- `work_context:<uuid>`：可持續追加內容的工作範圍，只是導航與選擇入口，不冒充不可變 artifact。
- `work_entry:<uuid>`：不可變的單筆工作紀錄。匯入、引用與重讀都以此精確版本為準。

UUID 與序號一律由 runtime 生成，不交給模型填寫。資料庫供本次任務及其 child 共用實體儲存，但查詢必須經授權解析；不因此開放整個資料庫給模型或 child workspace。

### 3.1 工作範圍

每份工作範圍保存下列完整欄位：

| 欄位 | 型別 | 來源與用途 |
|---|---|---|
| `context_ref` | string | runtime 生成的唯一工作引用 |
| `owner_agent_id` | string | 沿用既有代理身分，界定本地可寫範圍 |
| `title` | string | 從建立時的工作單元名稱取得；只是導航文字，不是新的任務契約 |
| `input_refs` | string[] | 建立時明確提供的輸入，作為來源紀錄；不是授權擴張 |

不新增 `next_action`、成功狀態或額度欄位，避免把工作範圍變成另一張計畫。是否可執行及是否完成仍由 C0/C1 管理。

### 3.2 工作紀錄

每筆紀錄都有以下欄位：

| 欄位 | 型別 | 意義 |
|---|---|---|
| `entry_ref` | string | runtime 生成的精確引用 |
| `context_ref` | string | 所屬工作範圍 |
| `sequence` | integer | 資料庫內遞增的寫入序號；不拿匯入時間改寫來源先後 |
| `source_event_id` | string | runtime 以既有代理身分、事件序號與同事件內位置產生，用於同一次回傳重送時避免重複入庫；不以輸出相同判重複 |
| `entry_kind` | `note \| tool_result \| import` | 由寫入入口機械決定，不用文字猜內容類別 |
| `source_refs` | string[] | 已知的精確來源與相關物件引用；不是完整科學推導的證明 |
| `payload` | object | 嚴格依下列三種形狀之一 |

三種 `payload` 的完整欄位：

```text
note:
  markdown: string

tool_result:
  call_id: string
  tool_name: string
  executed_arguments: object
  result: object

import:
  entry_ref: string
```

- `note` 是 C3，永久標示為模型工作說明，沒有「已證實」狀態。
- `tool_result` 是 C4 的精確操作回條，不是科學證據的接受決定。若結果指向已有觀察、檔案或 snapshot，正文仍以那些資料庫為權威；回條只證明該次操作回了什麼。
- `import` 只掛入一筆已授權的不可變紀錄，不複製或重寫正文。它沒有授予其他內容或未來紀錄的效果。重複掛入同一筆不會產生兩份有效來源。
- 操作參數與結果沿用既有工具契約；`object` 不是允許模型自行發明新的工具格式。

第一版不建立修改舊 note 的工具。更正寫成新紀錄，LLM 摘要時保留更正關係；Python 不判斷哪一段科學意見被推翻。

### 3.3 摘要 checkpoint

每個工作範圍依消費者的可見範圍保存摘要 checkpoint，完整欄位為：

| 欄位 | 型別 | 意義 |
|---|---|---|
| `context_ref` | string | 所屬工作範圍 |
| `view_key` | string | runtime 依消費者身分及既有有效權限規則生成的視圖識別；不是 LLM 填寫的新授權 |
| `through_sequence` | integer | 已整理至此範圍的哪個紀錄位置；初始 `0` |
| `markdown` | string | LLM 產生的 C3 摘要；初始空字串 |
| `source_refs` | string[] | 本份摘要所用紀錄與已知來源的引用聯集，供可見性核對 |

摘要正文與游標在同一筆交易提交。工作紀錄不被摘要刪除。摘要後新增的 `import` 也算新紀錄，因此即使它指向較早產生的 child 紀錄，也不會被舊游標跳過。

`context_ref + view_key` 下只保留一份當前摘要。摘要是可重新產生的視圖，不是多份工作權威。新工具結果增加工作紀錄，不會只因新增資料就改變 `view_key`；消費者或授權規則改變才改變視圖。

`view_key` 由明確的代理身分、呼叫者識別及有效來源政策做規範化雜湊。呼叫者識別由程式傳入，例如 Skill id 或 Node 規劃入口；不得從 prompt 用詞猜角色。雜湊不是安全檢查的替代，來源仍須經既有權限解析。

不同代理或不同權限的 Skill 不能直接沿用另一份摘要 checkpoint；child 從明確匯入的紀錄建立自己的摘要。使用前也要核對來源可見性；新授權讓過去不可見內容變得可見時，必須建立新視圖，不能帶著舊游標跳過那些內容。此規則也納入回歸測試。

## 四、工作說明如何進來

不新增 `write_work_note` 工具或要求每支開發工具多填一套理由。

1. 一般主迴圈的 `ModelTurn.content` 若非空，由已知呼叫位置保存為 `note`，明確視為未驗證的工作說明。這是 C3 寫入入口，不是把任意 C6 正文重新匯入。
2. 工具完成後，保存實際執行參數與精確回傳結果為 `tool_result`。參數中已明寫的理由自然保留，不另外抽取猜測。
3. `reasoning_content` 不納入；內部格式修復、評分或壓縮模型的原始回應也不自動混入主代理工作紀錄。
4. 既有 `development_project_write`／`development_project_edit` 仍可保存長篇 Markdown 筆記。工作紀錄會保存那次檔案操作與精確來源，不以檔名猜哪個 Markdown 是「特別重要的記憶」。
5. 提示要求在重要修改或改變判斷時，用一般回應簡短交代理由與預期觀察。沒有明寫就承認沒有，不能事後請另一個模型補造；也不新增「沒寫理由就禁止工具」的審查關卡。

原始提示、token 用量、隱藏推理與診斷細節仍只進 C6。工作紀錄不保存全量 prompt，也不把舊系統指令當成接續工作的指令。

## 五、公開操作介面的精確差異

| 介面 | 精確變更 |
|---|---|
| `execute_node_locally` | 新增選填 `work_context_ref: string`，只能選擇目前可見、由本代理擁有的工作範圍 |
| `spawn_child`／`ChildMission` | 新增選填 `work_entry_refs: string[]`，預設空陣列，只能指定目前可讀且允許交棒的精確紀錄 |
| child 回傳的操作紀錄 | 新增 `work_entry_refs: string[]`，只列本 mission 產生、對 parent 可交棒的紀錄，不替代 `accepted_artifact_refs` |
| `read_ref` | 參數名稱不變，新增支援 `work_context:` 與 `work_entry:`，沿用有界分頁；擴充 namespace 的語意列入本次核准 |
| `work_memory_list` | 新增一個 common 記憶查詢工具，規格如下 |

`work_memory_list` 參數：

```text
context_ref?: string
query?: string
cursor?: integer >= 0
limit?: integer, 1..20, default 8
```

未帶 `context_ref` 時列可見工作；帶入時列該範圍可見紀錄。`query` 只是文字查詢，不判定科學相關性或挑「最好」的結果。

回傳欄位固定為 `items`、`total`、`next_cursor`。每列只有 `ref`、`kind`、`title`、`excerpt`、`source_refs`；`kind` 為 `context` 或上述紀錄類別。正文用 `read_ref` 讀取。這些是即時導航投影，不再持久保存第二份內容。

之所以不直接塞入 `artifact_list`，是因為該工具的契約明確是正式 C2 目錄。不能為了少一個工具就把工作筆記偽裝成正式成果。

記錄工作是 runtime 的狀態登記，不額外呼叫 LLM；模型主動查詢或讀取仍計入既有呼叫額度，不新增配額豁免。

### 節點讀取的追加核准

2026-09-02 追加核准：尚未載入 Skill、正在選擇節點執行方式時，既有 `read_ref.ref` 除了工作引用，也接受目前節點已授權的正式成果引用。正式成果依既有儲存介面包含 `artifact:`、`code_artifact:` 與 `execution_observation:`；不因此開放任意來源檔、終端輸出或整份成果板。

可讀清單由既有 `_active_node_input_refs` 決定，繼續受到明確輸入、依賴閉包及代理／child 來源可見性約束。沒有正式輸入時，只保留工作引用讀取，不退化成不限範圍的字串。正文仍在提示時依精確儲存投影，不在工具回傳或工作摘要建立第二份權威。

參數名稱、分頁欄位、回傳格式與持久狀態均不增加；無需資料遷移。此核准不改 child 掛載權限、節點完成判定、LOOP 規劃、嘗試額度或下一個技能的選擇。已有正文仍在提示時沿用既有防重複，壓縮移出後允許重讀。

## 六、工作綁定與 child 行為

### 6.1 本地執行

- 啟動時為啟動作業建立本地範圍；執行新 Node 時，未提供 `work_context_ref` 就建立新範圍，提供則接續指定工作。
- 同一 Node 的下一次 attempt 沿用已綁定工作，額度與 LOOP 計畫照原制度重建。不能因參數省略又建立空記憶。
- Node 切換或換圖時解除當前綁定，但保留工作。主代理可在執行新節點時明確選擇接續哪份工作，runtime 不以名稱相似或相同資料夾代選。
- Node LOOP 的 `input_refs` 仍為正式輸入；工作記憶由共用解析入口另外投影，不把 C3 引用冒充 C2 輸入，也不讓 Graph 變成記憶工具操作清單。

### 6.2 child 交棒

child 建立自己的工作範圍，匯入 `work_entry_refs` 指定紀錄；每筆為不可變引用。這不是掛上 parent 的整個工作範圍，更不包含 parent 的後續紀錄、摘要或計畫。

紀錄引用不自動授予其所有 `source_refs` 的讀取權。跨代理讀取仍需通過既有來源可見性規則；無法安全掛入的整筆紀錄不交棒，不能用 LLM 靜默刪減敏感句子代替授權。

child 自己的新紀錄直接進自己的範圍，因此出生時的匯入紀錄不可能成為永久「現在狀態」。回傳時，允許交棒的工作紀錄以引用掛回 parent 當前工作。它們即使描述失敗，也可用於接續；科學成果是否接受仍由 C2 review 決定。

同一專案的可變原碼仍只有原 DevelopmentProjectStore 一份，不因 child 建立新記憶範圍就複製出競爭版本。第一版不開放父子並行寫同一專案。

## 七、恢復入口與舊路徑撤除

新增單一內部解析入口，放在 `memory_lifecycle/`：輸入為當前 C1、明確輸入引用及目前代理權限；輸出為一次性提示資料，不持久保存另一份「現在真相」。

它負責工作紀錄、目前 project revision、明確 snapshot、各次執行身分及仍可接續檔案的關聯解析。沿用現有工具與物件契約的精確身分，不以關鍵字推論科學語意，也不把所有不同執行一律縮成全域最新一筆。

| 位置 | 替換要求 |
|---|---|
| `memory_lifecycle/state.py` | 移除 C3 清空及舊全域壓縮游標；管理當前工作指標 |
| `memory_lifecycle/engine.py` | 壓縮、近期對話及恢復來源改讀工作紀錄，不再以最近 `load_skill` 截斷完整開發記憶 |
| `_runtime_loop.py`／`_runtime_tools.py` | 在一般回應及實際工具回傳時寫入紀錄；不從歷史 log 猜補狀態 |
| `_runtime_prompting.py` | 移除 `_prior_attempt_handoff`、`_enrich_prior_attempt_handoff` 作為恢復來源；使用共用解析結果 |
| `_runtime_planning.py` | 不再另外挑一份 `latest_prior_node_attempt_handoff` 供規劃，與執行使用相同工作解析 |
| `_runtime_children.py` | 不再組裝會覆蓋目前狀態的 receipts 包；改用明確匯入與回傳紀錄引用 |
| `runtime.py` | 可恢復的工作所擁有操作引用由工作紀錄還原，不再依靠掃描 `node_attempt_handoff` 恢復目前工作 |
| `attempt_handoffs.py` | 留下 Graph 所需失敗紀錄功能，移除作為開發恢復與 transport ref 抽取權威的用途 |

新產生的 `node_attempt_handoff` 移除 `project_receipts`、`tool_receipts`，新增 `work_context_ref: string \| null`；保留 `node_id`、`attempt_index`、`executor`、`child_id`、`status`、`operational_refs`、`formal_result_refs`。此為既有內部持久事件的精確變更，亦須核准。歷史 C6 不原地改寫。

`mission_context.prior_attempt_handoff` 不再新建或讀取為目前執行背景。失敗原因仍可從正式重建資料與工作紀錄引用取得，不能以撤除交接包為由丟掉失敗證據。

目前精確 ref 解析及引用權限檢查不刪除；只是把重複的「該用哪個版本」集中。C1 近期 receipt 視窗仍可存在，但只作有界提示投影，不再承擔唯一恢復功能。

## 八、交易與壓縮規則

1. 工具輸出與物件先完成既有存放，再提交工作紀錄，最後回報已完成。C1 視窗更新失敗時仍能從已提交紀錄恢復。
2. `source_event_id` 讓同一次回傳重送不重複建立紀錄；不同執行即使輸出相同也各自保留。
3. 若程序在外部工具已動作、回傳尚未持久保存之間中斷，不能保證憑記憶知道結果。必須查詢該工具既有程序／執行紀錄；不明就保留不明，不能宣稱達成恰好執行一次。
4. 壓縮從該工作已提交的 note、操作投影與匯入紀錄取得輸入，不讀原始隱藏 reasoning。摘要與游標原子提交；失敗保留舊 checkpoint 及完整未整理尾段。
5. C3 摘要是工作判斷，不決定目前可變原碼或執行版本。精確版本仍從原資料庫解析，筆記不能覆寫它。
6. 壓縮觸發及提示預算沿用目前配置，先不順便改成另一個演算法。摘要來源改正後再評估成本及內容品質。

## 九、遷移、回退與驗證

本案核准後，先保存完整回退點，再在隔離副本實作。原測試資料與程式不做破壞性轉換。

建立明確的 v15 → v16 轉換程序，不在一般 `read()` 中默默替整段舊歷史重新分類。轉換會：

- 保留原 C0/C1 控制內容、配額、C2/C4 物件及 C6。
- 將存在的舊 C3 摘要轉為來源註明的 note，不補造未記下的理由。
- 依已保存的精確呼叫、回傳及已知 Node／代理身分轉入操作紀錄；無法判定歸屬時列出需要處理的歧義，不靠文字相似猜工作。
- 建立工作引用後才切換 AgentState；不完整轉換不提交新版狀態。
- 舊 raw events 可保留診斷，但不能成為新版找不到資料時的第二條靜默恢復路徑。

最先驗的不是新一輪 DFT，而是同一個失敗 checkpoint：child 的新執行已存在時，Node 規劃與 Materializer 是否看到一致的工作來源。同時驗證新版原碼、舊 snapshot、舊執行沒有被錯誤合成。

再驗跨 attempt、壓縮、程序恢復、Node 失敗後重建、parent／child 交棒及權限隔離。這些確定性邊界通過，才續跑原水／銅真實 LLM 案例及既有 Formula → Materializer → Sample 回歸片段。

端到端仍須另外通過才能宣稱完成；實作這份記憶制度不等於已解決水／銅的科學或數值收斂問題。

## 十、本輪核准範圍

已核准的完整變更為：AgentState v16 差異、工作資料庫三類紀錄與摘要格式、兩種引用命名空間、第五節工具與 child 介面差異，以及第七節內部交接事件差異。

實作位於隔離工作樹 `long-running-work-memory`；完整程式基線為 `d226cb4`。原工作目錄與原測試成果不改寫。本文件定義核准範圍，不代表已完成所有驗證；測試結果另行記錄。
