﻿# 資料安全標籤與受限資料流：待議設計紀錄

## 文件地位

本文件保存 2026-08-02 對資料權限、child agent、skill、route 與 evaluator 的設計討論，供未來重新啟動相關開發時使用。

目前裁定為 **pending，暫不實裝**。因此本文件：

- 不是現行 runtime 規格。
- 不授權新增安全 schema、state、artifact 欄位或 public action。
- 不改變 `docs/common_memory_constitution_zh-TW.md` 對 C0-C6 的現行規範。
- 不代表目前已有真正的存取隔離、降密、機密儲存或作業系統沙箱。
- 未來若要實作，仍須重新檢查現況、提出精確介面差異並取得使用者核准。

2026-09-09 的已核准政策見 [Materializer 權責憲法](materializer_responsibility_constitution_zh-TW.md#任務量測的讀取與使用)：本任務一般量測不因計分用途而禁止讀取；保留用途綁定、明確來源限制與任務範圍。不新增本文件的安全標籤制度。下文保留原始待議設計，不能把它當成阻擋目前研究驗證的新增門檻。

## 問題與現階段判斷

科研任務可能包含兩種資料：

```text
data X：供研究 agent 使用的題目資料、自變量與公開觀察
data Y：答案、held-out KPI 或只應由 evaluator 使用的參考資料
```

目前案例希望先由 white-room child 處理原始資料，產生 data X 與 data Y。後續 Mind map、假說、Outer、Materializer 與 Sample Evolver 不應以 data Y 作弊。

本專案目前定位為可科學審計的科研 agent：主要輸出是公式、程式、圖、數值表與文字論證。這些成果可由人或 evaluator 追查其來源與合理性。因此現階段接受 workflow discipline，而不急著加入高風險的完整資料權限系統。

## 已討論的兩種方向

### 方向一：新增 C7

原構想是新增「受限語意資料」C7，集中保存 data Y、私有評估資料與其他限制內容。

主要問題是 C0-C6 回答內容如何存放、代謝、壓縮及投影；安全限制回答誰可讀寫。兩者是不同維度。同一份受限資料仍可能分別是 C2 正式成果、C4 大型資料、C5 暫存或 C6 稽核紀錄。全部塞入 C7 會失去原本生命週期資訊，也容易把 C7 變成混合區。

因此長期不建議以 C7 表達安全等級。

### 方向二：C0-C6 加獨立安全標籤

長期較合理的方向是保留 C0-C6，另為可定位的資料物件標示安全等級，例如：

```text
Normal < Security-C < Security-B < Security-A
```

兩個維度各自回答：

```text
C0-C6：放在哪裡、活多久、如何代謝與如何進入提示
安全標籤：哪些執行主體可以讀寫
```

例子：

| 內容 | 記憶類別 | 可能安全等級 |
|---|---|---|
| 清理後的 data X | C4 或 C2 | Normal |
| 原始或切分後的 data Y | C4 | Security-A |
| evaluator 私有中間結果 | C5 | Security-A |
| evaluator 完整稽核紀錄 | C6 | Security-A |
| 經核准公開的彙總評估 | C2 | Normal |

此方向獲得原則性同意，但目前不實裝。

## Child、skill 與權限主體

討論中一度考慮「每個 skill 有自己的最高安全權限」，再與 child 權限取交集。模擬後發現這可能造成能力死鎖：child 已獲授權處理受限資料，卻因 common coding skill 或其他必要 skill 未個別升權而無法完成任務。

較合理的長期模型是：

```text
安全授權主體 = agent／child 的本次 mission
skill = 同一 agent 在任務內使用的工作方法
```

若 child 的 mission 被授予 Security-A，child 生命週期內掛載的 skills 原則上都能在該上限內工作。但實際可見內容仍受以下條件限制：

```text
agent／child 的 mission 權限上限
∩ mission 明確掛載或可發現的資料範圍
∩ 本次 prompt template 或 tool 實際需要的內容
```

「有權讀」不代表「每個 skill call 都把資料正文塞入 prompt」。Prompt template 仍須因材施教，只投影本次工作需要的內容。

未來若載入不可信任的第三方 skill，可以另行討論明確的低權限限制；不應在第一版讓所有 skill 各自維護一套容易卡死的權限表。

## Route 與 PrivateProxyEvaluator

目前程式中的角色應區分為：

```text
RouteRegistry
= route 分派器

scientific_private_proxy_evaluate
= 一條可呼叫的 route

PrivateProxyEvaluator
= 實作該 route 的受信任領域服務

PrivateProxyEvaluator.evaluate
= 實際 handler
```

`PrivateProxyEvaluator` 不是 agent、skill 或 router，而是 route 背後的受信任私有評估服務。

長期若實作安全層，route 至少需要區分兩種行為：

### 一般 route

- 沿用當前 agent／child mission 的權限。
- 不自行升權。
- 普通輸出繼承實際輸入的最高安全等級。

### 受信任服務 route

- 服務本身可在 caller 看不到的情況下讀取受限資料。
- Caller 不因呼叫 route 而取得服務的私有權限。
- 只接受約定輸入並只公開預先限制的結果。

`scientific_private_proxy_evaluate` 屬於第二種。Outer 可以呼叫它，但只能看見彙總統計，不得看見逐筆 KPI、data Y 或私有中間推理。

## 輸出安全等級與降密

長期若實作方案二，普通輸出原則上應繼承本次實際輸入的最高安全等級。具有讀取權，不代表自然具有把高安全內容發布為低安全內容的權力。

允許降低安全等級的典型情況包括：

1. 可機械驗證的資料清理，例如明確移除答案欄位並核對輸出。
2. 受信任 evaluator 依預先約定的公開契約只輸出彙總狀態或統計量。

較穩健的資料形狀是：

```text
完整私有結果：維持較高安全等級
公開投影結果：經受控程序建立的新 artifact
```

不應直接把同一份完整 artifact 改標成較低安全等級。

尚未解決的問題包括公開自由文字是否安全、如何驗證大型輸出、如何記錄降密依據，以及 route 的公開契約如何表示。這些問題是目前裁定 pending 的主要原因。

## 模擬的長期資料流

```text
Parent
  - 擁有可轉授的最高上限
  - Planner 平常不直接看 data Y
  - 將原始資料 ref、切分任務與 child mission 交給 child

Child
  - white-room 啟動
  - 使用 source observation、coding、execution 等能力
  - 產生 data X 與 data Y
  - data X 經受控清理後可供一般科研流程使用
  - data Y 維持受限，只交給 evaluator 能力

Outer / Materializer / Sample Evolver
  - 只取得 data X 與公開任務語意
  - 產生可審計的公式、程式、數值與樣本成果

PrivateProxyEvaluator
  - 私下取得 data Y
  - 比較 materialized proxy 與 held-out KPI
  - 只發布預先允許的彙總評估
```

Parent runtime 長期還需要支援「可搬運受限 ref，但不把正文投影給 Parent LLM」。這屬於資料流授權，不等於讓 Parent 讀取答案。

## 現行暫行做法

在安全層 pending 期間，採以下簡化流程：

1. Parent 正常建立 white-room child，交付「從原始資料產生 data X 與 data Y」的 child-owned 任務。
2. Child 依既有 C0-C6 管理提示、暫存、正式成果、大型檔案與稽核紀錄。
3. Data X 與 data Y 不新增安全欄位，也不新增 C7。
4. Data X 以普通 workspace／artifact dataflow 供後續科研 skills 使用。
5. Data Y 同樣以既有 C0-C6 保存，但不主動放入 Mind map、假說、Outer、Materializer 或 Sample Evolver 的 mission、prompt 或 formal input refs。
6. Private evaluator 可透過現有領域服務取得 data Y，並只向一般 workflow 回傳彙總結果。
7. 目前依靠 white-room mission scoping、明確 refs、prompt template 與可審計輸出降低誤用風險；不宣稱這是安全隔離。

目前接受的風險是：若 agent 能直接遍歷完整 workspace，或 prompt／route 錯誤地把 data Y 傳給後續 skill，系統沒有獨立權限層阻止。現階段透過資料流審查、raw log 與公式／程式／圖表／文字成果的科學審計發現問題。

## 未來重新啟動開發前必須回答

1. 安全標籤應附著於哪些對象：C2 artifact、C4 檔案、code、observation、C5、C6 或全部可定位物件。
2. 是否只需要 Normal／Security-A，或確實需要 C／B／A 多級。
3. Agent mission 權限、可轉授上限與 planner 可見內容是否需要分離。
4. Parent 如何接受並轉交自己不能讀取正文的 child artifact ref。
5. 普通 route 與受信任服務 route 的機械接口如何表示。
6. 哪些程序可以建立低安全等級的公開投影；誰驗證其沒有洩漏。
7. Prompt、skill-local memory、compaction 與 C6 raw log 如何繼承安全等級。
8. Generic shell、Python 執行與 workspace discovery 如何避免繞過 ref 檢查。
9. 是否需要物理隔離的受限 store，而非只在 metadata 上貼標籤。
10. 需要修改哪些 private／public schema；如何遷移既有 artifacts 與 checkpoints。

## 重新啟動條件

出現下列情況時，應優先重新評估方案二：

- 開始處理真正敏感、受法規或合約限制的資料。
- 導入外部使用者或不可信任第三方 skill。
- 產生不容易科學審計的黑盒成果。
- Generic shell 或 child workspace 能穩定繞過現有資料流邊界。
- Data Y 曾實際洩漏至 Mind map、假說、Outer、Materializer 或 Sample Evolver。
- Evaluator 的公開結果開始包含自由長文、逐筆資料或其他難以機械限制的內容。

在上述條件發生前，優先把 common agent、child dataflow、skill-local workflow 與可審計科研成果跑通，不提前建立完整安全基礎設施。
