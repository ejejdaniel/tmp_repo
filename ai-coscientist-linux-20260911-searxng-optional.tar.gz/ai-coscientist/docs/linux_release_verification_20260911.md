# Linux 候選版驗證：2026-09-11

## 邊界

本輪以可部署候選版為目標，不修改 Graph、LOOP、C0-C6、正式技能提示或科學 schema。
新增部署入口、乾淨打包與部署檢查腳本。模型品質問題保留為已知風險，
不因單次 gate 回放通過就宣稱語意已穩定。

## 科研續跑

- 保留 `outputs/lit_cli_full_e2e_20260911_v1` 原始中止紀錄。
- 用既有 checkpoint 複製工具建立 `outputs/lit_cli_deploy_resume_20260911_v1`。
- 零模型邊界檢查確認控制狀態未變、未新增成果、未注入引用，原 checkpoint 未變。
- 正式 `python -m ai_coscientist.cli chat` 自動接續原 turn，沒有新輸入解答、技能順序或人工 gate。
- 起初誤用無 Docker 權限的執行環境，因此只停止已核對的 PID 45228；此時尚未產生新 gate。
  正式權限命令兩次被工具審查拒絕，使用者再次回覆「允許」後，才開始可使用 Docker 的接續。
  這是操作員啟動／授權中斷，不是模型或框架自行失敗，也不算不中斷端到端。
- 本輪正式 gate 為 `artifact:scientific-coordinator:agent-global-evaluation-gate-dc27f848b5`。
  它允許「優於既有最佳樣本，或三輪有效演化」，沒有另列一項無條件必須勝出。
- Frame 1 由模型自行選為來源觀察，完成後建立 Frame 2：資料製備、心智圖。
- Frame 2 的資料製備已發布，但第二筆組成被錯寫。操作員於心智圖執行初期停止
  精確核對的 PID 22512；未產生新的正式心智圖、假說、公式、樣本或報告。
  系統沒有自行發現這個錯誤。本輪不算端到端通過，不可直接沿錯誤資料接續。

## 最早失敗邊界

原始 CSV 與來源觀察均正確：第二筆是 `PHS/R17/C2AA2=35/50/15, Mw=9k`。
`events.jsonl` 的事件 275、281 保留設計階段完整提示；除了正確的背景與 CSV 摘錄，
模型還主動讀回完整三行 CSV，`truncated=false`，其中第二筆仍明確是 R17。
這裡沒有來源漏傳、ref 失配或壓縮把 R17 移掉的證據。

第一個錯誤出現在事件 282，`design-prepared-source-outputs` 的輸出。
第二筆 acceptance check 的材料字串仍寫 R17，組成條件卻寫 `R12=0.50`。
這是模型把來源重新表述成驗收條件時出錯，不是 Python 在儲存時改了資料。

後續完整因果鏈：

1. `source-observation-ee74577aa8` 正確描述兩筆資料。
2. 資料製備設計把第二筆組成錯寫為 R12。
3. 產碼程式讀原始 CSV，卻將組成鍵固定為 PHS、R12、C2-AA2。
4. 驗證程式也照設計建立固定 expected 表，第二筆同樣寫 R12，未獨立從該列來源推導組成。
5. 驗證回傳 `accepted=true`、`issues=[]`、`repair_used=false`。
6. `prepared-source-data-6dfb104cf9` 原樣引用錯誤 stdout；後續節點判定接受，開始心智圖。

完整引用：

- 來源觀察：`artifact:scientific-coordinator:source-observation-ee74577aa8`。
- 正式資料：`artifact:scientific-coordinator:prepared-source-data-6dfb104cf9`。
- 產碼與正文：`source_probe:040f51737b844c6e:code`、`source_probe:040f51737b844c6e:stdout`。
- 驗證程式與裁定：`source_probe:456a81e634e04c7c:code`、`source_probe:456a81e634e04c7c:stdout`。

## 分層診斷與後續界線

| 層次 | 本輪已查證情況 |
| --- | --- |
| Common 傳輸、引用、記憶 | 原始內容及正確 ref 已抵達設計；產出正文被原樣保存，未發現此邊界的漏傳或篡改。 |
| 領域來源選擇與解讀 | 選中正確兩筆 CSV；設計模型把第二筆組成 R17 改成 R12。 |
| 技能內流程與驗證 | 產碼、驗證共同依賴錯誤設計；驗證提示把輸出契約稱為唯一語意權威，沒有在這次保住來源事實。 |
| Planner、Graph、LOOP | 來源觀察及製備由模型自行安排；沒有外部固定技能順序。製備回報合格後沿既有圖前進。 |
| Evaluator、審查 | 節點判定採納已發布的製備成果，未偵測正文中的矛盾；整體目標尚未完成，未錯誤結案。 |
| CLI 與 runner | 正常接續原對話；停止為操作員診斷，不是系統自行修復。尚未抵達報告及回覆使用者階段。 |

不能把兩支程式同意同一份設計當成獨立驗證。根因的改進方向應是區分
「製備設計決定輸出範圍及轉換」與「原始來源決定事實」，讓驗證從原始來源計算
應保留的內容，而不是抄模型重述的答案。這仍需連同設計、產碼、驗證及修復入口
一起檢討；本次沒有新增審核層、化學專用攔截、schema 或臨時修改資料。

本輪停在最早已確認的錯誤，沒有再消耗一輪相同端到端測試。
既有邊界測試與 Linux 工具鏈檢查不證明模型能正確轉述每筆來源；此次部署候選版
明確保留這項已知風險。原 checkpoint、提示、錯誤程式、驗證裁定與成果保持原樣。

## 已完成的 Linux 驗證

用既有 Linux/amd64 科研映像建立用完即移除的容器，沒有重建／修改映像：

1. 解開 `dist/linux-20260911/ai-coscientist-linux-preflight.tar.gz`，335 個檔案雜湊全數相符。
2. 依 pyproject.toml 在容器內安裝 Python 依賴，正式 CLI parser 可載入。
3. 新 Linux 入口在零對話、未定題狀態啟動，`/status` 和 `/exit` 正常。
   沒有建立 agent-state.json，沒有模型請求。
4. 安裝 Chromium 和 Noto CJK，以正式 scientific-report renderer 產生測試 PDF。
   繁體中文文字抽取正確，第一頁圖片經人工視覺確認無缺字或重疊。
5. 此 PDF 測試為一次性 root 容器使用 `--no-sandbox` 包裝，未更改正式 renderer。
   目的 Linux 主機應以一般使用者執行瀏覽器。本次沒有在容器內掛入 Docker socket。
6. 原碼目錄的 14 份受管理能力 manifest、payload 及 package hash 以既有驗證器檢查相符。
7. 正式候選包再次在 Linux 解開、核對雜湊、compileall 與 bash 語法檢查。
   14 個公開技能的詳細指引皆可載入；有 workflow 者驗證 callable，Materializer
   維持動態執行，不錯把缺少固定 workflow 當成故障。

證據在 `outputs/linux_release_validation_20260911/`。這是安裝、空白 CLI 及 PDF
工具鏈驗證，不是科研任務通過，也不是目的機器的 Docker 權限／LLM 連線驗證。

## Docker 留存

`dist/linux-20260911/ai-coscientist-docker-images.tar`：1,248,951,296 bytes。

SHA256：`52aa826fcafadb9f80833cf6334ecaeb3f4ab1347405d25ae66b19c4281bb971`。

封存三個映像，已從封存 manifest 核對 config digest 和 tags：

- `ai-coscientist-native-science:py312-v2`：71b5dd7483fb8aa1bc9c027fb117fa2e5cb36f78537beb9f2d47fa3f91b04752。
- `ai-coscientist-native-science-probe:py312-gpaw-v1`：401f9b88924c102a45911925b18defddcb9b4ab114d780c68df6d4497417c212。
- `python:3.12-slim`：613c5454f914638dc2bfcab71c8630de0089f7ebff0a7239b54f34866c4b6051。

最後一個映像的 registry digest 與 image ID 不同；既有 DFT Route 使用 registry digest
2c941e860699f878900b0edc2403613c234d4b32eda3cc9fa7036991a2a63c4a。
不改 runtime.lock；部署說明保留精確 pull 和 additional-runtime 參數。

供傳輸的壓縮版為 `dist/linux-20260911/ai-coscientist-docker-images.tar.gz`，
459,278,840 bytes，SHA256：
`b911a5443ed527be8edfb067c9c3636b40fc9510d730781e43995a37241cd405`。

## 尚未證明

- 本輪科研主線已因資料錯誤停止，沒有完整交付；目的 Linux 主機的端到端亦未驗證。
- 目的主機的 CPU 架構、Docker 權限、套件下載與 LLM 網路可達性。
- Linux 上每一份受管理 Route 的數值執行；本輪先驗證原封套件及所需映像留存。
- 新增部署檢查中，略過 Docker 或 PDF 的部分不可視為通過。
