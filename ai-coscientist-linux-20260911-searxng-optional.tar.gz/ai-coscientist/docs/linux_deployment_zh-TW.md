# Linux 部署

## 範圍

部署包保留現在的正式程式、技能、已核准及待核准能力、核准紀錄、Docker 建置定義。
不包含舊研究成果、對話、outputs、runs、Python 環境、Docker cache、暫存候選或 PowerShell。
待核准能力不會因打包而升格。套件內容與 hash 不變。

### 2026-09-11 候選版狀態

這是供部署與實驗的候選版，不是已證明能無人監督完成 LIT 的穩定版。
先前已在 Linux/amd64 容器驗證安裝、空白 CLI 的 `/status` 與 `/exit`、技能載入
及正式 HTML 轉 PDF 工具；這些不等於科研端到端通過。

目前保留跨表 ID 配對、精確引用與續接修正，以及 SearXNG 停用開關。
製備仍可能漏做題目要求的比例正規化，例如輸出 35/50/15，而非 0.35/0.50/0.15，
模型生成的驗證器也可能錯誤放行。這是已知的資料表示與契約不一致風險，未宣稱修好。
最後一次提示實驗產生互相矛盾的檢查而拒收成果，已撤回該次正式程式與提示變更；
撤回後以原模型程式重播，確認兩筆正文、目標 ID 配對及正式引用讀取仍可運作。
這不是新的 LLM 端到端驗證，也不保證下次模型產碼一定成功。

公式 P2 曾使用另一份已核對的製備成果完成真實模型生成與公式發布，但該次是
開發者明示替換輸入的分段測試，不是系統自主修復。本版未重新驗通 Materializer、
Sample、報告與 CLI 最終交付。相關確定性回歸通過；另有既存的排行榜與技能文字
斷言測試失敗，不將本次檢查稱為全套測試通過。
詳細紀錄見 [製備來源忠實度紀錄](preparation_source_fidelity_20260911.md)。
部署包不攜帶任何本機測試成果，文中 `outputs/` 路徑只供來源機器追查。

`scripts/package_linux_release.py` 從實際檔案打包，包含尚未納入 Git 的正式程式；
`SHA256SUMS` 記錄每個交付檔案。`RELEASE.txt` 的 Git HEAD 只是來源紀錄，
未提交版本必須搭配檔案雜湊，不可宣稱它等於該 commit。

## 主機條件

- Python 3.12，依 pyproject.toml 安裝專案依賴。
- 可使用的 Docker daemon，使用者必須有操作權限。
- Chromium 或 Google Chrome；PDF 不是只靠 Python 套件產生。
- 繁體中文字型，例如 Noto CJK。瀏覽器建議以一般使用者執行，不使用 root。
- 可連線至 config 中的 LLM 端點。部署包會將 api_key 換成 no-key，真正的金鑰請在目標主機設定。
- 本次本機 Docker 映像為 Linux/amd64；ARM 機器須另行驗證，不能當作已支援。

## 打包

```bash
python scripts/package_linux_release.py --output dist/ai-coscientist-linux.tar.gz
```

在目的機器解開後：

```bash
tar -xzf ai-coscientist-linux.tar.gz
cd ai-coscientist
sha256sum -c SHA256SUMS
python3.12 -m pip install -e .
```

先核對 SHA256SUMS，再依新主機需求修改 config。部署檢查允許修改這份 LLM config，
會標示它已被本機設定覆蓋；正式程式或能力套件改變仍會拒絕，不能混稱原封版本。

## Docker

Dockerfile 位於 `docker/native-science-py312/`。
只重建 Dockerfile 不保證得到舊 Route 鎖定的 image ID。
完整搬移既有能力時，應在來源機器用 `docker image save` 匯出所需映像，
目的機器用 `docker image load` 匯入；不可為了遷移而改 Route 的 runtime.lock.json 或核准 hash。

本次依賴：

| 用途 | 映像 |
| --- | --- |
| Materializer 通用科研環境 | ai-coscientist-native-science:py312-v2，image ID sha256:71b5dd7483fb8aa1bc9c027fb117fa2e5cb36f78537beb9f2d47fa3f91b04752 |
| 已有 GPAW Route 基底 | ai-coscientist-native-science-probe:py312-gpaw-v1，image ID sha256:401f9b88924c102a45911925b18defddcb9b4ab114d780c68df6d4497417c212 |
| 已核准 DFT Route 基底 | python:3.12-slim@sha256:2c941e860699f878900b0edc2403613c234d4b32eda3cc9fa7036991a2a63c4a |

`docker save/load` 不保證恢復 registry 的 RepoDigest 名稱；第三項可使用精確 digest pull，
既有 layers 可重用。Route 自己的 Python 依賴會依原鎖定檔在目的機器建立，
不搬移原機器的可變 venv cache，故第一次使用可能需要套件下載連線。

來源機器的匯出指令（與程式包分開，約 1.25 GB 未壓縮）：

```bash
docker image save --output ai-coscientist-docker-images.tar \
  ai-coscientist-native-science:py312-v2 \
  ai-coscientist-native-science-probe:py312-gpaw-v1 \
  python:3.12-slim
```

```bash
# Both downloaded archives were placed beside the extracted ai-coscientist directory.
docker image load -i ../ai-coscientist-docker-images.tar.gz
docker pull python:3.12-slim@sha256:2c941e860699f878900b0edc2403613c234d4b32eda3cc9fa7036991a2a63c4a
python3.12 scripts/check_linux_deployment.py
```

`--skip-docker` 或 `--skip-pdf` 只用於部分環境診斷；略過的部分不算通過。
檢查不發 LLM request、不建立研究任務，也不代表科學端到端通過。

## 文獻來源設定

SearXNG 是選用服務，不是 Linux 的必要依賴。沿用既有環境變數作為開關：

- `AI_COSCIENTIST_SEARXNG_URL` 未設定或留空：停用，不註冊公開搜尋工具，也不讓文獻研究者選擇它，不消耗查詢次數。
- 設為非空網址：啟用該 SearXNG 服務。連線失敗會如實回報，不會偷偷替換成其他搜尋服務。
- custom 資料中心獨立設定；停用 SearXNG 不影響其查詢、原文保存與證據引用。

只有 custom 資料中心的 Linux，請在啟動 CLI 的同一個終端先設定：

```bash
export AI_COSCIENTIST_SEARXNG_URL=''
export AI_COSCIENTIST_PRIVATE_KNOWLEDGE_URL='https://your-knowledge-center/query'
# Set the real token locally only if your API requires Bearer authentication.
export AI_COSCIENTIST_PRIVATE_KNOWLEDGE_TOKEN='your-token'
unset AI_COSCIENTIST_PRIVATE_KNOWLEDGE_MOCK
```

請將網址及金鑰換成目的機器的設定；不使用驗證金鑰時可不設定 TOKEN。
目前 adapter 用 HTTP POST 傳送 `question`、`why`、`resource_url`、`permission_hint`，
接收 `markdown` 與 `metadata`。API 格式若不同，需調整
`src/ai_coscientist/domain/private_knowledge_center_adapter.py`；回應整理獨立於其中的
`normalize_private_knowledge_response()`，不是任意 API 都能直接接上。
`PRIVATE_KNOWLEDGE_MOCK` 僅供明確指定的測試，真實 API 部署不要設定它。

日後啟用 SearXNG，設定網址後重新啟動 CLI 即可，例如：

```bash
export AI_COSCIENTIST_SEARXNG_URL='http://localhost:8081'
```

這些是程序環境變數，不是 LLM 的 `.cfg` 欄位；變更不會即時套用到已執行中的工作階段。

## 進入 CLI

```bash
PYTHON_BIN=python3.12 bash scripts/run_scientific_chat_linux.sh \
  --output "$PWD/runs/my-first-chat" \
  --source-root /data/my-research \
  --config "$PWD/config_deepseek_v4_flash.cfg" \
  --capability-docker-additional-runtime python:3.12-slim@sha256:2c941e860699f878900b0edc2403613c234d4b32eda3cc9fa7036991a2a63c4a \
  --capability-docker-additional-runtime sha256:401f9b88924c102a45911925b18defddcb9b4ab114d780c68df6d4497417c212
```

不必預先指定題目檔或歷史資料檔。在 CLI 內多輪討論，需要研究時由系統定題。
human-in-loop 預設開啟；無人在場可加 `--no-human-in-loop`。
使用新的 --output 開新對話，使用相同 --output 接續原對話。

舊 `run_scientific_workflow_linux.sh` 保留給已定題、已指定歷史 JSON 的批次入口，
不是一般 CLI 的入口，也不能拿其預先綁定參數代替對話定題。
