﻿# Common Agent 記憶與提示憲法

## 地位與適用範圍

本文件是此工作樹的憲法級設計規範，約束 common agent、domain skill、skill-local workflow、child agent、prompt renderer、memory compactor、artifact/workspace store 與診斷紀錄。

本文件描述的是必須逐步達成的規範行為，不代表目前程式已全部實作。現行程式若與本文件衝突，該衝突是待修缺口，不得反過來修改本文件以迎合現況。

除非使用者明確核准：

- 不得另建平行的記憶制度。
- 不得重新定義 C0-C6 的意義。
- 不得新增 C7 或其他類別。
- 不得改變某類別的唯一正式位置、代謝方式或可見性。
- 不得藉 prompt、skill、validator、測試或 runtime 補丁繞過本規範。
- 若既有類別不足，必須先說明缺少的存放行為、生命週期、壓縮方式、可見性與遷移影響，再取得核准。

## 約法三章

### 一、全系統只使用一套記憶分類

Common、skill 與 child agent 都使用相同的 C0-C6 管理辦法。Skill 可以擁有自己的局部 workflow，但不能擁有另一套保存或代謝制度。

每一項具名內容只有一個權威存放位置。Ref、索引、hash、manifest、receipt、短摘要及 prompt projection 只是指向權威內容的投影，不是第二份權威內容。

### 二、保存分類不等於提示組合

C0-C6 決定內容放在哪裡、活多久、如何代謝及誰能讀取。

每一次 LLM 呼叫的 prompt template 則依任務選擇需要的內容子集。Planner、selected skill、skill 內部步驟、局部修復與壓縮呼叫可以使用不同模板，不得因共用記憶制度而退化成單一死板提示。

Prompt 是即時投影，不得回存成新的資料副本或與正式成果競爭權威。

### 三、不足時先討論，不以補丁擴張制度

若某項資訊無法合理歸入現有類別，或其生命週期與現有類別衝突，必須停止並向使用者提出精確缺口。不得用檔名、內容大小、domain 關鍵字或臨時 gate 猜測新的管理方式。

## C0-C6 定義

| 類別 | 意義 | 唯一正式位置 | 主要代謝方式 |
|---|---|---|---|
| C0 | 固定核心 | agent core state | 任務期間不壓縮、不任意改寫；只做完整性與版本檢查 |
| C1 | 當代控制狀態 | current-generation state store | 狀態轉移時立即更新；舊代退成摘要或引用 |
| C2 | 正式成果 | artifact board/store | 正文不壓縮、不原地覆寫；以新版本與明確 ref 傳遞 |
| C3 | 可壓縮的非正式工作說明 | common 持久工作資料庫 | 依工作與可見範圍用 LLM 摘要；跨 Skill 與嘗試保留，不因行動額度到期而清空 |
| C4 | 精確工作資料與操作回條 | workspace/object/file store；回條在 common 工作資料庫 | 權威正文不交給 LLM 改寫；按精確 ref 讀取；回條不取代原碼、snapshot 或執行觀察 |
| C5 | Skill 內部暫存 | skill-local workflow state | 階段轉移時淘汰不再需要的項目；skill 結束時清空 |
| C6 | 原始稽核紀錄 | append-only external event store | 運行中不改寫；checkpoint 或結案後輪替與封存；不得作為語意工作輸入 |

### C0 固定核心

典型內容包括 objective、使用者硬限制與明確決策、task contract，以及 evaluation gate 的必要精確內容。

C0 在啟動、恢復及每次 prompt 前檢查完整性。修改 C0 必須來自明確的任務重定義或已授權流程，不能由局部修復、skill 或 compaction 改寫。

### C1 當代控制狀態

典型內容包括 current plan、active work unit、目前 blocker、pending mission/child review、最新有效 receipt 與最近一次可行的修復狀態。

C1 以事件驅動代謝。Plan advance、replan、child 狀態改變、artifact 接受或 blocker 解決後，舊狀態立即退場，不等到提示超限才處理。

評估控制狀態分成兩個互不取代的尺度，但仍同屬 C1，並使用相同的 evaluation-state 結構：

- `global_evaluation_state` 是整體任務的評估狀態。它跨 Frame 延續，記錄使用者題目所定義的整體成功條件與合法停止條件；Frame 結束或換圖時不得重設。只有明確的人類確認流程可以修訂其權威 gate。
- `frame_evaluation_state` 是目前 Frame 的評估狀態。每張控制圖建立後，依該圖唯一的 `frame-goal` 機械建立；Frame 結算或換圖時淘汰，下一個 Frame 另建新狀態。

Frame 評估只回答「本局是否已走完或應停止」，Global 評估才回答「整體任務是否完成」。Frame 結算但 Global 尚未完成時，主代理必須保留已接受成果，並針對未滿足的 Global 條件建立下一個 Frame。兩者在 prompt 中可同時投影，但不得合併成同一份狀態或互相覆寫。

### C2 正式成果

C2 是跨 skill、跨 agent、審查與結案的語意權威。Planner 通常只看索引、種類、摘要與 ref；selected skill 必須透過明確 ref 取得需要的精確內容。

Receipt、inline 重述、wiki 摘要與舊 wrapper 不能覆寫 stored artifact。

### C3 可壓縮知識與觀察

C3 保存仍有推理價值、但不具正式成果權威的工作說明、決策理由、待驗證判斷與歷史問題摘要。一般主迴圈的非空 `ModelTurn.content` 由明確入口保存為未驗證 note；不包含隱藏 reasoning，也不自動收入私有審查、修復或壓縮模型的原文。

工具協定的裸露控制文字不是普通工作說明。主迴圈遇到普通正文夾帶 DSML／Harmony 工具協定時，先保存完整原始回覆至 C6，執行工具前至多做一次格式修復；原生 `tool_calls` 若存在，修復不得改變其名稱、參數、順序或數量，不得從正文推導額外動作。修復占用既有步驟呼叫額度，修復說明仍只作診斷。程式碼區塊或行內程式碼中的協定範例不視為裸露控制文字。既存的異常工作紀錄不原地刪改，但不自動當成工作筆記或 C3 摘要來源。

C3 是唯一允許 LLM 自動摘要的正式類別。壓縮結果不能創造新事實、plan、accepted evidence 或科學結論，也不能改寫 C0/C1/C2/C4。

C3 仍由 LLM 先整理語意變更，再完整重寫摘要；來源改為持久工作資料庫中可見的 note、操作回條投影及明確匯入紀錄，不再掃描 C6。正文不得由 Python 機械合併，亦不以科學語意規則判定是否保留。摘要與游標原子提交；空輸出或交易檢查失敗不前移游標。觸發、目標大小及超限處理沿用既有壓縮配置。

CLI 對話沿用同一分類，但有獨立範圍：逐則精確人類與代理訊息只存在 C4 `dialogue/transcript.jsonl`；C3 導航摘要與摘要游標交易式保存在共用 `work-memory.sqlite3` 的 `dialogue_memory`。前置對話與任務啟動後對話必須共用同一個 `DialogueMemory` 服務。每次對話判斷只投影有界近期原文與 C3 導航摘要；摘要只能協助定位，主代理必須以 `message_id` 重讀 C4 原文後，才能選入定題來源。摘要、交接理由、未被人類接受的代理建議均不得成為任務權威或科學證據。

第一段只整理新增紀錄，不讀取舊摘要。第二段整併採用 `Keep` 原則：仍有接續價值的既有決策及理由、已排除原因、未完成工作與不確定性，不因新增紀錄未重述而消失；新證據更正、取代或解決時應更新，已失去接續價值的內容可以刪減。這不是永久保留每句舊摘要，亦不把舊判斷升格為事實。超限縮寫沿用相同保留原則。不恢復固定標題驗證，不增設語意審查模型，也不宣稱 LLM 摘要可以保證逐輪無失真。

2026-09-02 最新核准：保留兩段式 C3 v2。第一段抽取與第二段整併各呼叫一次，明確使用 `reasoning_effort=none`，先取得完整候選摘要 x2。此設定只作用於這兩次呼叫，不改變其他科研、規劃或修復的推理配置。

觸發門檻沿用現有配置，正式預設仍為 16,000 字元；API 的 `max_tokens=12000` 是輸出額度，不是觸發門檻。提示只要求朝 6,000 字元整理，不揭露可超標或 8,000 門檻。完整 x2 不超過 8,000 字元時直接採用；超過時只追加一次語意縮寫，以 x2 為輸入、相同取捨法則及 6,000 字元目標，使用既有 `repair_reasoning_effort`（目前為 `medium`）產生 x3。

若 x3 完整、非空且比 x2 短，採用 x3，即使仍超過 8,000 字元；若 x3 原樣重送、更長、空白、被截斷，或其提示超出預算，保留完整 x2。8,000 是觸發追加縮寫的門檻，不是拒絕提交的硬上限。不再逐輪要求更短，也不以 Python 截尾、正文拼接或語意判斷取代摘要。第一份完整 x2 尚未形成時，空輸出或截斷不能被宣稱為完成；保留舊摘要、游標與原始工作紀錄。隱藏推理及截斷正文不作摘要來源。

抽取與整併須保留觀察的來源、範圍及未驗證性質，不將局部完成改述為整體完成，也不自行合併不同專案、目錄、執行或版本的觀察為矛盾。保留決策理由、未完成工作與接續線索優先於複製數值紀錄及檔案清單；詳細資料維持 C4 權威、以精確引用重新讀取。此為 LLM 提示責任，不新增 Python 科學語意檢查。

抽取、整併、縮寫共用同一份資訊取捨指引。摘要不是逐項轉錄，LLM 可以省略不影響接續判斷的詳細紀錄；涉及當前決策、失敗區辨或重啟的數值、限制、理由及必要引用仍須保留，不把省略寫成問題已解決。不增加語意審查、公開欄位或 Python 正文刪減，也不改用 `high` 或提高輸出額度。

本次核准的格式與生命週期以 [長期工作記憶精確變更](memory_governance_long_running_work_schema_plan_zh-TW.md) 為準。`c1.active_work_context_ref` 只選擇工作；內容唯一存於共用 `work-memory.sqlite3`。不新增 C7，不保留 `c3.wiki_summary` 或舊全域壓縮游標的雙寫。

### C4 大型工作資料

典型內容包括 dataset、code、完整表格與大型陣列、長文件及大型 machine result。

一般 prompt 只取得 path/ref、格式、hash、大小與必要短預覽。Selected skill 需要時才按精確 ref 讀取正文。C4 不因壓縮而改變內容形狀。

C4 讀取防重複只在同一份當前 prompt 仍含上次讀取的精確或有界正文時生效。若該正文已被 compaction 移出 prompt，只剩 ref、C1 receipt 或 C3 歷史提及，系統必須允許重新讀取。

### C5 Skill 內部暫存

典型內容包括內部草稿、上一階段輸出、bounded retry payload、validator 的精確問題，以及下一個內部步驟必要的局部狀態。

即使 skill 內呼叫 LLM 超過兩次，仍使用 C0-C6。Skill 決定下一次呼叫在語意上需要哪些 C5 項目；common 管理機制負責保存、淘汰、大小檢查與投影。

大型中間內容必須進 C4，C5 只保留 ref。需跨多個內部階段保留且可摘要的知識可進具 skill scope 的 C3。Skill 結束後 C5 必須清空。

### C6 原始稽核紀錄

C6 保存完整模型回應、工具呼叫、執行紀錄、prompt snapshot 與錯誤鏈，供人類或診斷工具追查。

C6 不得直接餵給 planner、skill、child 或 evaluator，也不得成為科學證據。新版正常恢復不得掃描 C6 補工作記憶。舊 checkpoint 僅允許透過明確離線遷移，在副本中按已保存身分、參數及結果轉換；原始內容不改寫。

C3 compactor 只能取得當前工作與有效來源政策允許的有界紀錄投影。已由主迴圈寫入 C3 的普通工作說明可以參與摘要，但不因此成為事實。Runtime 自動完成的 `runtime-readback-*` 保存精確 C4 回條，下一份 prompt 仍投影 C1 完成 receipt；C1 的移除不刪除持久操作紀錄。

## 代謝檢查與執行時機

### 每次狀態改變後

Common 執行便宜的機械檢查：

- 新內容是否已分到唯一類別。
- 先前版本是否已被取代。
- Ref、版本、visibility 與 ownership 是否仍有效。
- C1/C5 是否存在應立即淘汰的舊狀態。
- C2/C4 的依賴與可達性是否完整。

這個檢查不得呼叫 LLM 判斷科學語意。

### 每次 LLM 呼叫前

所有 LLM 呼叫都必須經過共同的 context preparation，包括 planner、selected skill、skill-local 後續階段、局部格式修復、replan 與 memory compaction。

```text
呼叫者宣告本次需要的資訊
→ common 依 C0-C6 解析權威來源
→ 檢查版本、生命週期、可見性與本次提示預算
→ 執行必要代謝
→ 由本次 prompt template 組裝投影
→ 呼叫 LLM
→ 將輸出依 C0-C6 入庫
```

機械檢查每次都做；只有符合類別條件時才真正代謝。不得每次都額外呼叫壓縮 LLM。

### 生命週期事件發生時

- plan advance/replan：處理 C1 舊代。
- skill 內部階段完成：處理 C5。
- skill 成功、失敗或交還控制：清空 C5，整理 C1；不清空該工作的 C3/C4。
- 同一 Node 重試：保留工作綁定，重建 LOOP 計畫並重新計算行動額度。Node 或圖切換：解除綁定但不刪工作；新 Node 可明確選擇接續。
- child：建立自己的工作範圍，只匯入 mission 明定且來源可見的不可變 `work_entry`；不繼承父摘要、整個工作範圍或未來紀錄。回傳工作不替代 C2 審查。
- artifact 發布、接受、取代或 review：更新 C2 索引與依賴可達性。
- child spawn、return、accept/reject：更新 C1，僅放行已接受的 C2 dependency closure。
- task checkpoint/closure：封存可封存的 C4/C6，保留結案所需 C0/C2 refs。

### 提示預算壓力出現時

不得只使用全系統固定字元數。每個 prompt template 應有自己的可用輸入預算。

若投影超過預算：

1. 移除不屬於本次模板的內容。
2. 將 C4 正文改為 ref/manifest 並按需讀取。
3. 淘汰過期 C1/C5。
4. 對符合條件的 C3 使用 LLM 壓縮。
5. C0 與必要 C2 refs 仍不得遺失。

## 長時間研究的 active projection 規範

完整保存與 active projection 必須分離。完整保存回答「系統擁有什麼」；active projection 回答「這一次 LLM call 必須看到什麼」。降低 active projection 不得刪除、覆寫或摘要 C2/C4 的權威正文。

### C1 只展開當前控制面

- 一般執行提示只展開當前 Frame、active node、當前 node LOOP、current issue 與未滿足或無法判定的 evaluation criteria。
- 已滿足 criterion 的完整 reason 不在每次一般提示重播；只保留完成數量與有限 evidence refs。Evaluator 仍從權威 C1 state 讀取完整 criterion 狀態。
- Graph 替換後，舊 Graph 與失敗鏈由正式 revision artifact／audit 保存；一般 node 執行提示不得重播完整歷史圖。
- C1 的 current issue prompt projection 與 bounded receipts 必須有明確大小或數量上限。C1 可保留當前問題的權威原文，C6 保留原始事件鏈；一般提示不得無界重播任一者。

### C2 使用三級揭露

每次提示中的 C2 分為：

1. `exact_or_bounded_content`：本次明確讀取、目前 transition 判斷或 selected skill 確實需要的內容。
2. `summary`：目前 graph、evaluation、LOOP 或依賴鏈需要導航的 receipt 摘要。
3. `ref_only`／catalog omission：正文不進 prompt，只保留可搜尋與按 ref 讀取的能力。

`formal_artifact_index` 永遠只是有預算上限的導航視窗，不代表完整 C2 board。提示必須同時說明 active artifact 總數、顯示數、省略數及種類計數。省略不得被解讀為不存在。

Common 必須提供機械式 artifact catalog 查詢與 cursor 分頁。查詢只依 exact kind/status、文字 query、順序與 cursor 運作，不判斷科學語意。查到 exact ref 後，才由 `read_ref` 取得正文。

預設視窗優先保留：

- C1 明確 resolved refs。
- active node／LOOP 的精確 context refs。
- 未滿足 evaluation criterion 已引用的 evidence refs。
- 最近成功 action 的正式 refs。

剩餘空間才按最近 active revision 補入。C2 正文及舊版本仍留在唯一 ArtifactStore，不因 prompt 省略而改變。

### C3、C4、C5 的 active 上限

- C3 以持久工作範圍為生命週期，按消費者及既有有效權限產生摘要視圖；不是單次 Skill 呼叫範圍。壓縮與組裝必須使用同一消費者視圖。摘要已取代其涵蓋的原文時，精簡提示仍保留摘要，不可讓原文與摘要同時退場；摘要不能轉成 C2 權威，精確紀錄仍能分頁重讀。
- C4 預設顯示 manifest、shape、有限 scalar／key／sample 與 ref。巢狀 mapping、sequence、文字與 dependency refs 都必須有投影上限；精確全文由 focused read 取得。
- C5 只攜帶當前 stage 的上一版必要內容、精確 validation issue 與 result schema。Repair projection 的 mapping、collection、issue 與長文字必須有上限；不得累積歷代 repair payload。

### 工作提示的單一投影與近期對話

- 同一份工作摘要只從 `work_context.summary` 呈現一次，診斷歸類為 C3；不再另投影 `runtime_wiki_summary`，也不將摘要計入 C1 控制狀態。
- 一般執行提示先計算固定內容及工具規格的實際大小，剩餘空間才分配給近期對話；不固定先分配一半總預算。最後仍檢查完整 messages 與實際工具規格。
- 最近已完成的工具回傳、最新明寫的工作說明及目前錯誤的因果回條，不因舊歷史擠占預算而直接消失。正常與精簡投影仍超限、調低可選歷史額度也無法解決時，允許最新普通工作說明進入既有 C3 壓縮，依本次實際剩餘提示額度選擇保留的近期內容；剛完成的工具呼叫與回傳保持成對原文。每次組裝至多觸發一次這種額外壓縮，提交後重新計算總大小。不得提高上限、截尾正文或反覆呼叫壓縮器來掩蓋仍然超額的必要內容。
- 既有分頁讀取的工具、實際參數及完整回傳內容全部一致時，可以在當次提示只保留最新一份正文；其他呼叫與回條仍成對保留，明示正文省略且指出保留的呼叫。不同來源、範圍、版本或內容不合併，權威紀錄不改寫。
- 模型在重要修改、昂貴執行或續跑、改變路線及交棒時，應在同次普通回應簡短說明依據、決定與預期觀察。常規讀取不必逐次敘述；沒有說明時不能補造或阻止工具。串流傳輸須保存完整普通正文與工具呼叫，不以工具參數恰好可解析為訊息結束。

本節為 2026-09-02 核准的提示組裝與決策說明修正。C3 v2 的兩段式語意壓縮及後續核准的超限處理，以本文件 C3 節為準；不得由提示組裝另設壓縮制度。

### 兩段式提示降級

Common runtime 對一般 agent call 採兩段式組裝：

```text
normal projection
→ 若實際 messages + tools 超出該 call 預算
→ minimal projection
→ 再計算一次完整提示大小
→ 調整可選歷史額度；仍有普通筆記造成壓力時，至多呼叫一次既有 C3 流程
→ 重新組裝並計算完整提示大小
→ 仍超額才明確失敗
```

`minimal projection` 只能做下列調整：

- 縮小 C2 navigation window。
- 將非 focused 的 resolved C2/C4 內容降為 reference projection。
- 保留 C3 工作摘要，不能因降級而失去已摘要的工作連續性。
- 保留 C0、active node、未滿足 criteria、目前必要 refs、selected skill 指令及必要工具 schema。

不得靜默截斷 C0、改寫科學內容、刪除必要 ref、假裝 criterion 已滿足，或把超額當作任務失敗。每次 normal → minimal 的轉換與最終 byte breakdown 都必須寫入 C6 診斷紀錄。

## Prompt Template 權限

Prompt template 可以決定：

- 本次需要的 C0 subset。
- 本次 active C1。
- 哪些 C2 refs 只顯示索引，哪些需要精確內容。
- 哪些 C3 頁面或摘要相關。
- 哪些 C4 refs 需要 manifest、預覽或按需正文。
- 哪些 C5 局部狀態需要傳到下一個內部步驟。

Prompt template 不可以改變內容的正式分類、複製正式內容成第二份權威、讀取 C6 作為一般工作上下文、壓掉必要 C0/C1/C2 refs，或讓 skill 建立平行記憶 store。

## 大型成果與小型描述檔

內容分類依權威、存放方式與生命週期決定，不依檔案間關聯性決定。

典型正式成果採：

```text
C2：小型正式描述或 manifest
    - 成果身分、語意摘要、provenance
    - 指向大型內容的 ref/hash

C4：大型實體內容
    - code/dataset/長文件/大型結果
```

兩者可以構成同一個邏輯成果，但 group 只是關聯，不是新的 C 類別。通常由 C2 描述檔擔任整組成果的正式身分，C4 保存大型正文。

若小型描述檔只是沒有獨立語意權威的 sidecar，它可以與大型內容同屬 C4 bundle；若它會被 planner、下游、review 或 closure 當成正式成果，則它必須是 C2。

在 skill 發布前，可由 C5 保存描述草稿並引用 C4 大型內容；發布後建立 C2 正式描述，C5 消失，C4 不複製。

只要任一有效 C1、C2 或 C5 仍引用 C4，大型內容就必須保留。沒有有效引用且不受稽核保留要求約束時，才可封存或清理。

邏輯 grouping 不構成新增 C 類別的理由。只有出現全新的唯一存放位置、代謝週期或可見性，且 C0-C6 均無法表達時，才可提議新增類別。

## 變更程序

任何修改本文件或其實作的提案，都必須先回答：

1. 哪一類資訊受到影響。
2. 現在唯一權威位置在哪裡。
3. 修改後如何存放、代謝與投影。
4. 是否造成內容重複或 source of truth 競爭。
5. 對 planner、skill-local workflow、child white-room、compaction 與 closure 的影響。
6. 是否涉及 schema、state、artifact 或 public contract 變更。

若答案顯示現有分類不足，必須取得使用者明確核准後才能新增或改類別。
