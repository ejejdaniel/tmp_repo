from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from ai_coscientist.domain.sample_evidence import read_sample_parameters, render_sample_parameters

from ai_coscientist.domain.scientific_review import (
    validate_scientific_method_review,
)


_ANCHOR_INPUT_KINDS = (
    "task_spec",
    "hypothesis_mind_map",
    "hypothesis",
    "proxy_formula_leaderboard",
    "sample_evolution_result",
)

_REQUIRED_INPUT_KINDS = (
    "task_spec",
    "hypothesis_mind_map",
    "hypothesis",
    "proxy_formula_leaderboard",
    "proxy_formula_candidate",
    "quantitative_proxy_materialization_result",
    "sample_evolution_result",
)

_JUDGMENT_SCHEMA = {
    "type": "object",
    "properties": {
        "outcome": {
            "type": "string",
            "enum": ["released", "bounded_reject", "hard_block"],
        },
        "rationale": {"type": "string", "minLength": 1},
        "claim_verdicts": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "claim_text": {
                        "type": "string",
                        "minLength": 1,
                    },
                    "verdict": {
                        "type": "string",
                        "enum": ["supported", "conditional", "blocked"],
                    },
                    "rationale": {
                        "type": "string",
                        "minLength": 1,
                    },
                    "claim_scope": {
                        "type": "string",
                        "enum": [
                            "sample_level",
                            "family_level",
                            "mechanism_level",
                            "task_level",
                            "unknown",
                        ],
                    },
                    "support_strength": {
                        "type": "string",
                        "enum": ["strong", "conditional", "weak", "unsupported"],
                    },
                },
                "required": [
                    "claim_text",
                    "verdict",
                    "rationale",
                    "claim_scope",
                    "support_strength",
                ],
                "additionalProperties": False,
            },
        },
        "blocking_findings": {
            "type": "array",
            "items": {"type": "string"},
        },
        "logic_consistency_status": {
            "type": "string",
            "minLength": 1,
        },
        "claim_budget_guard_status": {
            "type": "string",
            "minLength": 1,
        },
    },
    "required": [
        "outcome",
        "rationale",
        "claim_verdicts",
        "blocking_findings",
        "logic_consistency_status",
        "claim_budget_guard_status",
    ],
    "additionalProperties": False,
}

_SYSTEM_PROMPT = """\
Perform one independent final scientific release audit over the exact stored
evidence chain supplied below. Judge claims, not workflow effort. Separate a
plausible mechanism, an executed low-cost proxy, sample ranking, and actual
support for the final scientific claim. Successful code execution, correlation,
ranking, novelty, or a complete artifact chain is not by itself causal proof.

Use released only when the bounded claim is supported within its stated scope
and no release-blocking contradiction remains. Use bounded_reject when the
available evidence is honest but insufficient or incomplete. Use hard_block
only for a direct contradiction, private-data leakage, fabricated evidence, or
another red-line defect that makes release unsafe. Preserve conditional and
blocked claims as explicit claim verdicts instead of erasing them.

Return only the existing FinalLCAJudgment fields. Do not repair upstream work,
invent evidence, choose a recovery route, expose private KPI values, or add
transport fields.
"""


def run(payload: dict[str, Any], runtime: Any) -> dict[str, Any]:
    """Publish and mechanically close one exact final scientific judgment."""
    inputs = _resolved_inputs(runtime, payload.get("resolved_inputs"))
    selected = _resolve_selected_evidence(runtime, inputs)
    evidence_refs = [str(selected[kind]["artifact_ref"]) for kind in _REQUIRED_INPUT_KINDS]
    selected_formula_ref = str(selected["proxy_formula_candidate"]["artifact_ref"])
    selected_hypothesis_ref = str(selected["hypothesis"]["artifact_ref"])
    hypothesis_review = _latest_explicit_method_review(
        inputs,
        method_ref=selected_hypothesis_ref,
    )
    optional = [
        item
        for item in inputs
        if (
            item.get("artifact_kind") == "scientific_method_review"
            and selected_formula_ref in _artifact_dependency_refs(item)
        )
        or (
            item.get("artifact_kind") == "final_lca_judgment"
            and selected_hypothesis_ref in _artifact_dependency_refs(item)
        )
    ]
    if hypothesis_review is not None:
        optional.append(hypothesis_review)
    optional = _deduplicated_artifacts(optional)
    evidence = [selected[kind] for kind in _REQUIRED_INPUT_KINDS] + optional
    all_evidence_refs = [
        *evidence_refs,
        *(
            str(item["artifact_ref"])
            for item in optional
            if str(item.get("artifact_ref") or "").startswith("artifact:")
        ),
    ]

    sample_parameters = render_sample_parameters(read_sample_parameters(
        runtime, [selected["sample_evolution_result"]]
    ))
    context = json.loads(_judgment_context(payload=payload, evidence=evidence))
    if sample_parameters:
        context["exact_sample_parameters"] = sample_parameters
    judgment = runtime.generate_json(
        _SYSTEM_PROMPT + "\n\n" + (
            Path(__file__).parent / "references" / "evidence-use.md"
        ).read_text(encoding="utf-8"),
        json.dumps(context, ensure_ascii=False, indent=2),
        purpose="judge-final-scientific-release",
        schema=_JUDGMENT_SCHEMA,
        inspection_routes=("read_ref",),
        scientific_call=True,
    )
    machine_payload = {
        "artifact_kind": "final_lca_judgment",
        "final_lca_judgment": dict(judgment),
    }
    receipt = runtime.publish_artifact(
        artifact_kind="final_lca_judgment",
        artifact_id="final-lca-judgment",
        title="Final LCA judgment",
        markdown=_render_markdown(judgment) + ("\n" + sample_parameters if sample_parameters else ""),
        summary=str(judgment["rationale"])[:500],
        status="proposed",
        machine_payload=machine_payload,
        depends_on=all_evidence_refs,
        self_review={"outcome": str(judgment["outcome"])},
    )
    artifact_ref = str(receipt["artifact_ref"])
    stored = runtime.read_artifact(artifact_ref)
    _validate_readback(
        stored,
        judgment=judgment,
        evidence_refs=set(all_evidence_refs),
    )

    closure = runtime.call_route("scientific_validate_closure", {})
    if not isinstance(closure, Mapping):
        raise ValueError("final_lca_closure_result_invalid")
    complete = closure.get("complete") is True
    status = "complete" if complete else "blocked"
    summary = str(judgment["rationale"])
    if not complete:
        summary = (
            "Final scientific judgment was published, but the mechanical "
            "evidence-chain audit remains incomplete: "
            + _closure_issue_summary(closure)
        )
    return {
        "status": status,
        "artifact_ref": artifact_ref,
        "summary": summary[:1800],
        "final_lca_outcome": str(judgment["outcome"]),
        "closure": dict(closure),
    }


def _resolved_inputs(runtime: Any, raw_inputs: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_inputs, list):
        raise ValueError("final_lca_resolved_inputs_invalid")
    inputs: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in raw_inputs:
        if not isinstance(raw, Mapping):
            continue
        artifact_ref = str(raw.get("artifact_ref") or "").strip()
        if not artifact_ref.startswith("artifact:") or artifact_ref in seen:
            continue
        artifact = dict(raw)
        if not isinstance(artifact.get("machine_payload"), Mapping):
            artifact = dict(runtime.read_artifact(artifact_ref))
        if artifact.get("artifact_ref") != artifact_ref:
            raise ValueError("final_lca_input_ref_mismatch")
        if not isinstance(artifact.get("machine_payload"), Mapping):
            raise ValueError(f"final_lca_input_payload_required:{artifact_ref}")
        seen.add(artifact_ref)
        inputs.append(artifact)
    return inputs


def _resolve_selected_evidence(
    runtime: Any,
    inputs: Sequence[Mapping[str, Any]],
) -> dict[str, dict[str, Any]]:
    selected: dict[str, dict[str, Any]] = {}
    for kind in _ANCHOR_INPUT_KINDS:
        matches = [dict(item) for item in inputs if item.get("artifact_kind") == kind]
        if len(matches) != 1:
            raise ValueError(
                f"final_lca_exact_input_required:{kind}:actual={len(matches)}"
            )
        selected[kind] = matches[0]

    sample_refs = _artifact_dependency_refs(selected["sample_evolution_result"])
    leaderboard_payload = selected["proxy_formula_leaderboard"].get("machine_payload")
    ranked_entries = (
        leaderboard_payload.get("ranked_entries")
        if isinstance(leaderboard_payload, Mapping)
        else None
    )
    if not isinstance(ranked_entries, list):
        raise ValueError("final_lca_leaderboard_ranked_entries_required")

    selected_pairs: list[tuple[str, str]] = []
    for raw_entry in ranked_entries:
        if not isinstance(raw_entry, Mapping):
            continue
        formula_ref = str(raw_entry.get("formula_artifact_ref") or "").strip()
        materialization_ref = str(
            raw_entry.get("materialization_artifact_ref") or ""
        ).strip()
        if formula_ref in sample_refs and materialization_ref in sample_refs:
            selected_pairs.append((formula_ref, materialization_ref))
    selected_pairs = list(dict.fromkeys(selected_pairs))
    if len(selected_pairs) != 1:
        raise ValueError(
            "final_lca_selected_method_lineage_required:"
            f"actual={len(selected_pairs)}"
        )

    formula_ref, materialization_ref = selected_pairs[0]
    selected["proxy_formula_candidate"] = _artifact_for_ref(
        runtime,
        inputs,
        formula_ref,
        expected_kind="proxy_formula_candidate",
    )
    selected["quantitative_proxy_materialization_result"] = _artifact_for_ref(
        runtime,
        inputs,
        materialization_ref,
        expected_kind="quantitative_proxy_materialization_result",
    )
    return selected


def _artifact_for_ref(
    runtime: Any,
    inputs: Sequence[Mapping[str, Any]],
    artifact_ref: str,
    *,
    expected_kind: str,
) -> dict[str, Any]:
    matches = [dict(item) for item in inputs if item.get("artifact_ref") == artifact_ref]
    if len(matches) > 1:
        raise ValueError(f"final_lca_duplicate_input_ref:{artifact_ref}")
    artifact = matches[0] if matches else dict(runtime.read_artifact(artifact_ref))
    if artifact.get("artifact_ref") != artifact_ref:
        raise ValueError("final_lca_selected_input_ref_mismatch")
    if artifact.get("artifact_kind") != expected_kind:
        raise ValueError(
            "final_lca_selected_input_kind_mismatch:"
            f"expected={expected_kind}:actual={artifact.get('artifact_kind')}"
        )
    if not isinstance(artifact.get("machine_payload"), Mapping):
        raise ValueError(f"final_lca_input_payload_required:{artifact_ref}")
    return artifact


def _artifact_dependency_refs(artifact: Mapping[str, Any]) -> set[str]:
    raw_refs = artifact.get("depends_on")
    if not isinstance(raw_refs, Sequence) or isinstance(raw_refs, (str, bytes)):
        return set()
    return {
        str(ref).strip()
        for ref in raw_refs
        if str(ref).strip().startswith("artifact:")
    }


def _latest_explicit_method_review(
    inputs: Sequence[Mapping[str, Any]],
    *,
    method_ref: str,
) -> dict[str, Any] | None:
    matches: list[tuple[int, dict[str, Any]]] = []
    for item in inputs:
        if item.get("artifact_kind") != "scientific_method_review":
            continue
        try:
            payload = validate_scientific_method_review(
                item,
                expected_method_ref=method_ref,
            )
        except ValueError as exc:
            if "method_ref_mismatch" in str(exc):
                continue
            raise
        matches.append((int(payload["version"]), dict(item)))
    if not matches:
        return None
    latest_version = max(version for version, _item in matches)
    latest = [item for version, item in matches if version == latest_version]
    if len(latest) != 1:
        raise ValueError(
            "final_lca_hypothesis_review_latest_version_ambiguous:"
            f"method_ref={method_ref}:version={latest_version}"
        )
    return latest[0]


def _deduplicated_artifacts(
    artifacts: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in artifacts:
        artifact_ref = str(item.get("artifact_ref") or "")
        if not artifact_ref or artifact_ref in seen:
            continue
        result.append(dict(item))
        seen.add(artifact_ref)
    return result


def _judgment_context(
    *,
    payload: Mapping[str, Any],
    evidence: Sequence[Mapping[str, Any]],
) -> str:
    projection = {
        "objective": str(payload.get("objective") or ""),
        "evaluation_summary": str(payload.get("evaluation_summary") or ""),
        "active_work_unit": str(payload.get("plan_summary") or ""),
        "exact_stored_evidence": _bounded_artifact_batch(evidence),
    }
    return json.dumps(projection, ensure_ascii=False, indent=2, default=str)


def _bounded_artifact_batch(
    artifacts: Sequence[Mapping[str, Any]],
    *,
    total_limit: int = 72_000,
) -> list[dict[str, Any]]:
    per_item = max(2_000, total_limit // max(len(artifacts), 1))
    return [_bounded_artifact(item, limit=per_item) for item in artifacts]


def _bounded_artifact(artifact: Mapping[str, Any], *, limit: int) -> dict[str, Any]:
    # Navigation is retained; exact bodies are present whole or read on demand.
    fields = ("artifact_ref", "artifact_kind", "title", "summary", "depends_on", "trace_refs")
    projection = {key: artifact[key] for key in fields if key in artifact}
    remaining = limit - len(json.dumps(projection, ensure_ascii=False, default=str))
    for key in ("machine_payload", "markdown"):
        if key not in artifact:
            continue
        value = artifact[key]
        size = len(json.dumps({key: value}, ensure_ascii=False, default=str))
        if size <= remaining:
            projection[key] = value
            remaining -= size
    return projection


def _render_markdown(judgment: Mapping[str, Any]) -> str:
    lines = [
        "# Final LCA judgment",
        "",
        f"Outcome: {judgment['outcome']}",
        "",
        str(judgment["rationale"]),
        "",
        "## Claim verdicts",
    ]
    for item in judgment["claim_verdicts"]:
        lines.append(
            f"- [{item['verdict']}] {item['claim_text']} "
            f"({item['claim_scope']}, {item['support_strength']}): "
            f"{item['rationale']}"
        )
    if judgment["blocking_findings"]:
        lines.extend(["", "## Blocking findings"])
        lines.extend(f"- {item}" for item in judgment["blocking_findings"])
    lines.extend(
        [
            "",
            f"Logic consistency: {judgment['logic_consistency_status']}",
            f"Claim budget guard: {judgment['claim_budget_guard_status']}",
        ]
    )
    return "\n".join(lines)


def _validate_readback(
    stored: Mapping[str, Any],
    *,
    judgment: Mapping[str, Any],
    evidence_refs: set[str],
) -> None:
    if stored.get("artifact_kind") != "final_lca_judgment":
        raise ValueError("final_lca_readback_kind_invalid")
    payload = stored.get("machine_payload")
    if not isinstance(payload, Mapping):
        raise ValueError("final_lca_readback_payload_required")
    if payload.get("artifact_kind") != "final_lca_judgment":
        raise ValueError("final_lca_readback_payload_kind_invalid")
    if payload.get("final_lca_judgment") != judgment:
        raise ValueError("final_lca_readback_judgment_mismatch")
    dependencies = {str(ref) for ref in stored.get("depends_on", [])}
    if not evidence_refs.issubset(dependencies):
        raise ValueError("final_lca_readback_dependencies_incomplete")


def _closure_issue_summary(closure: Mapping[str, Any]) -> str:
    issue_parts: list[str] = []
    for key in (
        "missing_artifact_kinds",
        "unreachable_required_artifact_kinds",
        "dangling_artifact_dependencies",
        "forbidden_private_key_paths",
        "evidence_issues",
    ):
        value = closure.get(key)
        if value:
            issue_parts.append(f"{key}={value}")
    return "; ".join(issue_parts) or str(closure.get("status") or "unknown gap")
