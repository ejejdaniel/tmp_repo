# Evidence Use In The Final Judgment

This page owns the evidence-use instructions for the existing final judgment
call and its same-stage format repair. It does not change release criteria or
the FinalLCAJudgment format.

## Inspect the claim's sources

Input bodies are projected as complete fields or omitted, never as text
prefixes posing as complete structured data. An absent machine_payload or
markdown means it was not loaded, not that the stored field is empty. Use
read_ref on the exact ref for needed content. A stored result's linked body
can then be read within the same existing visibility and source-access limits.
Follow pagination when needed; a page is not the whole dataset.

For the selected best sample, the host reads the candidate bundle linked by
that exact Sample artifact and joins by sample_id. exact_sample_parameters is
the resulting original input excerpt, not a model summary. Its native keys and
values own parameter statements; input_description explains design intent but
does not replace this record. The host also retains this excerpt in the published
Markdown, so evaluate the sample and cite its identity without rebuilding its
parameter list. The excerpt proves what was supplied, not scientific validity.

Use the selected evidence chain, not a global latest result. A dataset owns
its recorded values; an execution and its bound inputs own computed values;
a review owns its judgment. A dependency records origin, not endorsement of
every ancestor statement. Summaries and prior reviews do not replace the
source of a value. Check the relevant source when accounts disagree; identify
the specific conflict rather than assuming that newer prose is correct.

An upstream limitation belongs to its originating stage and consumer. A target
withheld from a hypothesis or implementation input is not necessarily absent
from an evaluator's inputs. Use the actual evaluation observation to judge
whether evaluation occurred; its public aggregates can support dataset-specific
agreement without disclosing raw targets or proving independent validation.
Distinguish remaining scientific uncertainty from a historical lack of access
or work that was not yet executed. Describe superseded or conflicting accounts
in the existing rationale, without rewriting the stored artifacts or verdicts.

## Judge, do not recreate the results

claim_text should identify the result or method and the scientific assertion
being judged, with enough conditions to make its scope clear. Do not append a
complete parameter list or duplicate a results table when it is irrelevant to
that judgment. Keep the exact supporting artifact ref in the existing rationale
when it helps locate the assertion or a conflict; do not invent a citation field.

If a value is consequential to a verdict, preserve its name, value, unit and
record identity together as supplied. Do not separately reorder labels and
values into positional lists or infer an unstated unit. The task is to evaluate
support, not to paraphrase every numerical detail into another data authority.
The downstream report needs your verdict and reasoning; it still obtains its
data from the original result.

Inspect suspected contradictions and describe unresolved ones in the existing
findings/rationale. Do not rewrite upstream evidence or choose a repair route.
All existing released / bounded_reject / hard_block rules remain unchanged.

## Validation boundary

Python checks the existing format, refs, publication/readback and dependency
closure only. Scientific interpretation belongs to this judgment call. No extra
model reviewer, semantic keyword check or mandatory extra pass is introduced.
