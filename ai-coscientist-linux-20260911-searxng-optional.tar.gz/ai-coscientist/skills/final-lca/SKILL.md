---
name: final-lca
description: Produces final_lca_judgment. Requires exactly one task_spec, hypothesis_mind_map, hypothesis, proxy_formula_leaderboard, and sample_evolution_result; follows the sample and leaderboard refs to the selected proxy and matching materialization instead of accepting unrelated alternatives. Boundary: audits release without repairing upstream work or inventing missing support.
estimated_complexity: medium
---

# Final LCA

## Responsibility and boundary

Publish one independent `final_lca_judgment` from formal structured evidence. This skill owns final scientific release auditing. When the mission explicitly supplies a prior `final_lca_judgment` from the same hypothesis lineage, treat its findings as review context and preserve its ref in provenance; do not silently select a global prior judgment. This skill does not repair upstream artifacts, alter the mind map, choose a recovery route, expose hidden evaluator data, or confuse workflow closure with scientific support.

When explicit public reviews for the selected hypothesis accompany the evidence
closure, use only the unique highest review version for that exact hypothesis
and record it in `depends_on`. A review of another method cannot substitute for
the selected hypothesis review.

## Entry conditions and authority

- Resolve exact `task_spec`, `hypothesis_mind_map`, provisional `hypothesis`, `proxy_formula_leaderboard`, and `sample_evolution_result` from `resolved_inputs_for_active_skill`. Follow the sample dependency refs through the leaderboard to its one selected `proxy_formula_candidate` and matching `quantitative_proxy_materialization_result`; unrelated alternative formulas or materializations may coexist in the invocation but are not part of the selected method. Include relevant `scientific_method_review` only when explicitly supplied in that selected lineage.
- Read each missing exact ref before reasoning. Formal-index summaries, runtime wiki, and `depends_on` text do not substitute for stored content.
- Follow stored dependency lineage. Receipts, raw execution logs, chat summaries, planned artifact names, and unresolved refs are not scientific evidence.
- Judge the exact stored evidence first. After publishing and reading back the judgment, call no-argument `scientific_validate_closure` to verify the completed dependency chain mechanically. This post-publication check cannot replace the scientific judgment.

Use [evidence-use.md](references/evidence-use.md) for reading omitted fields,
preserving source/value correspondence and keeping verdicts distinct from
data transcription. The judgment prompt and its same-stage format repair load
this same page. `read_ref` is available during the judgment; source inspection
does not add a second scientific review or change the release standard.

## Trigger examples

### Should select

- Exact task, mind-map, hypothesis, proxy, materialization, and evolved-sample artifacts form one reviewed lineage, and a final release judgment is now required.
- The complete accepted evidence chain may support either release or bounded rejection, and the current work is an independent claim-level final audit.

### Should not select

- Materializer code failed deterministic replay and the current work is to repair that implementation before any release audit.
- The accepted lineage lacks proxy materialization or sample evidence required by the declared final evaluation, so upstream evidence work remains unfinished.

## Prompt and memory projection

- **C0:** task objective, explicit release criteria, claim boundary, visibility rules, and evaluator authority.
- **C1:** the active final-audit work unit and exact evidence chain.
- **C2:** every exact formal input and the final `final_lca_judgment`.
- **C3:** bounded closure-audit findings and processed uncertainty/conflict notes used for the current judgment.
- **C4:** code, datasets, long execution bodies, and large artifacts remain behind refs; inspect only what the claim audit requires.
- **C5:** claim-by-claim verdict draft, blocking findings, consistency review, and readback issue live only for this invocation.
- **C6:** raw prompts, model turns, route receipts, and execution logs remain audit-only.

### LLM call contracts

`judge-final-scientific-release` uses the configured scientific reasoning profile.
Same-stage format repair keeps the configured repair reasoning profile.

| Purpose | Authoritative prompt sources | Output and validation | Local repair and consumer |
|---|---|---|---|
| `judge-final-scientific-release` | C0 objective and release criteria; C1 active work unit; exact C2 task, mind map, hypothesis, formula leaderboard, selected formula, materialization, and sample artifacts; explicitly supplied background/review artifacts | Existing `FinalLCAJudgment` fields only. Common structured-output validation enforces the existing outcome and claim-verdict values; this skill verifies exact readback and dependencies. | Common performs one same-stage format repair with the rejected result and exact issues. It may not add evidence or alter upstream work. The stored judgment is consumed by the mechanical closure route and later report writer. |

## Skill-local workflow

1. Resolve and read the exact formal evidence chain. For its selected best sample,
   read the C4 candidate bundle named in the Sample's trace_refs using
   `scientific_sample_candidate_bundle_read` and match sample_id exactly.
   Project only that original record's inputs, not the full cohort or reconstructed
   prose. Inline sample representations remain in their original formal payload.
2. Audit each claim against task constraints, claim boundary, source support, materialization facts, sample evidence, unresolved issues, and falsification conditions. Read needed omitted bodies through `read_ref`; retain whole fields and exact refs, not truncated payload text.
3. Separate workflow closure from scientific release.
4. Use only existing outcomes: `released` for a bounded claim whose required evidence passes, `bounded_reject` for incomplete or insufficient audit evidence, and `hard_block` for a release-blocking contradiction.
5. Preserve conditional and blocked claims. Proxy ranking, novelty, or small-sample aggregate agreement alone does not establish final-KPI validation.
6. Publish one judgment and immediately read back its exact ref.
7. Run `scientific_validate_closure`; complete only when the published judgment closes the same exact evidence chain.

## Formal output and handoff

Publish `final_lca_judgment` through `artifact_publish` with the existing minimal machine payload: `artifact_kind: final_lca_judgment` and one complete `final_lca_judgment` object. Markdown alone is not a machine payload. Do not recreate a legacy FinalProjection package inside this judgment.

Within `final_lca_judgment`, retain only `outcome`, `rationale`, `claim_verdicts`, `blocking_findings`, `logic_consistency_status`, and `claim_budget_guard_status`. Each claim verdict uses the existing `claim_text`, `verdict`, `rationale`, `claim_scope`, and `support_strength` fields.

Record exact evidence refs and closure findings in existing audit content and Markdown. Set `depends_on` to every formal ref used. The next call must be `read_ref` on the exact returned ref. Return that ref and judgment; do not prescribe another skill.

The host appends the same exact candidate-input excerpt and its source identities
to Markdown without asking the judgment model to transcribe it. This is a C4
presentation projection, not an additional machine-payload field or verdict.

## Failure and repair

A missing, unreadable, unreviewed, or lineage-incomplete prerequisite blocks a release judgment and must be named exactly. Repair only malformed judgment payload or failed readback inside this invocation. Upstream scientific or execution defects remain findings for the coordinator; Final LCA does not fix them.

## Validation evidence

Completion requires exact input readback, a stored closure audit, claim-level verdicts, consistent use of the existing outcome set, explicit blocking findings where applicable, complete formal dependencies, and exact readback of `machine_payload.final_lca_judgment`. A complete artifact chain alone is insufficient for `released`.
