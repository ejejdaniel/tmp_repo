---
name: materializer
description: Produces quantitative_proxy_materialization_result or computational_property_result. Requires an exact specification and direct inputs; Specialist is optional. Formula execution explicitly selects prepared_source_ref; later scoring needs its paired evaluation_binding. A compatible Formula can run on another dataset without rewriting it. Boundary: implements and self-checks, never changes the target.
estimated_complexity: high
---

# Materializer

## Responsibility and boundary

Follow `docs/materializer_responsibility_constitution_zh-TW.md`. Materializer
owns faithful operationalization; it never changes or evaluates its scientific
meaning as a research claim. It must still check that its specification
normalization, algorithm, units and result interpretation agree; it does not
redefine the scientific target or judge its research merit.
Task and human constraints remain highest
authority. Formula freezes its relation; Protocol freezes its declared
quantity, inputs, arithmetic, unit, and interpretation. Materializer owns the
dataflow, open settings, code, tests, execution, and repair in Runtime's fixed
environment. It cannot alter that environment; Routes are optional. Do not invent values.

In Formula mode, `quantitative_proxy_materialization_result` establishes the
computed component and proxy values for each executed input, linked to its code
and execution. Those values are inputs to later comparisons; by themselves they
do not establish agreement with measured targets or a public method-review score.
Its `execution_input_paths` declares the current implementation's native record
inputs. Runtime preserves this declaration from executed code; downstream Sample
uses it, not the Formula's research-source paths. See the implementation stage
for the result contract. Old results without this declaration need a new
execution and publication, never retrospective rebinding.
In Protocol mode, `computational_property_result` establishes the quantity and
interpretation declared by that specification. A new node title, request to
score, or publication label cannot change what an existing computation measured.

## Entry conditions and authority

`resolved_inputs_for_active_skill` contains the smallest coherent set of exact
formal inputs commissioning one result. Formula or Protocol may anchor it; a
clear task or human requirement may suffice without a Specialist.
Stored content and refs are authoritative; do not relist the board. `depends_on` records provenance, not input
authority, and does not grant input visibility.

With no Formula or Protocol but a clear direct computation, publish and read one
existing `computational_property_protocol` as an internal checkpoint depending
on every mounted spec ref, then continue. Do not create a new target.
Specialist is optional guidance (`specialist_assessment`), never a prerequisite;
read exact advice only for a specific choice.

In Formula mode, select an exact visible `prepared_source_data` for this
execution through `prepared_source_ref`. The Formula's dependencies retain its
research provenance, not a permanent dataset restriction. Check that the
selected inputs support the frozen relation; do not redefine missing quantities
or invent values. For a scoring commission, select a preparation with paired
inputs and targets in `evaluation_binding`. Runtime resolves only its public
record body and records the selection in execution metadata. Downstream ranking
and Sample use that exact execution source. A different dataset requires a new
execution, not a new Formula when its science remains applicable. Omission is
only for the legacy configured SourceSpec path. Protocol keeps `input_bindings`.

## Progressive disclosure

`disclosure.py` reveals only the current scientific and project stage. A
checkpoint freezes one executable version, not the ability to repair the same
project. Stage pages guide the next work; they do not revoke local repair.

## Output and repair

Formula mode publishes one finite `quantitative_proxy_materialization_result`
covering every authoritative record; Protocol mode publishes one matching
`computational_property_result`; required internal calculations stay inside that result.
Markdown is not a substitute for its machine
payload. Preserve exact lineage.

Repair source, payload, code, execution, and readback defects locally. Restart
only for a proven missing input or capability. Missing software is a Runtime
capability gap, not permission to alter the environment or science. Require
executable code, formal execution, inspected output, exact lineage, publication,
and exact-ref readback.
