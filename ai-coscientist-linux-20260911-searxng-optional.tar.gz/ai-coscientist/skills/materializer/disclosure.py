from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from ai_coscientist.common.evaluation.evaluator import evidence_completeness_instruction
from ai_coscientist.domain.materialization_inputs import validate_execution_input_paths
from ai_coscientist.domain.computational_property_protocol import (
    computational_property_protocol_schema,
    validate_computational_property_protocol,
)


_FORMULA_KIND = "proxy_formula_candidate"
_PROTOCOL_KIND = "computational_property_protocol"
_MATERIALIZATION_KIND = "quantitative_proxy_materialization_result"
_PROPERTY_RESULT_KIND = "computational_property_result"
_PROJECT_SNAPSHOT_KIND = "development_project_snapshot"
_PREPARED_SOURCE_KIND = "prepared_source_data"
_ROUTE_REVISION_TOOLS = frozenset(
    {
        "capability_route_project_checkout",
        "capability_route_revision_submit",
    }
)
_LEGACY_CODE_TOOLS = frozenset(
    {
        "write_code_artifact",
        "edit_code_artifact",
        "inspect_python_environment",
        "scientific_materializer_execute",
        "scientific_protocol_materializer_execute",
    }
)
_EXECUTED_SOURCE_PROBE_STATUSES = frozenset(
    {
        "source_probe_succeeded",
        "source_probe_failed",
        "source_probe_timed_out",
    }
)
_ROOT = Path(__file__).resolve().parent
_STAGE_PAGE_BY_STAGE = {
    "completion": "completion-stage.md",
    "execution": "execution-stage.md",
    "implementation": "implementation-stage.md",
    "inspection": "inspection-stage.md",
    "publication": "publication-stage.md",
}
_PROJECT_WORK_TOOLS = frozenset(
    {
        "development_project_configure",
        "development_project_tree",
        "development_project_read",
        "development_project_search",
        "development_project_write",
        "development_project_edit",
        "development_project_move",
        "development_project_delete",
        "development_project_validate_syntax",
        "development_project_query_code",
        "development_project_terminal_start",
        "development_project_terminal_poll",
        "development_project_terminal_stop",
        "development_project_checkpoint",
        "development_project_diff",
        "development_project_restore",
        "development_project_bind_managed_routes",
    }
)
_PROJECT_MUTATION_STATUSES = frozenset(
    {
        "development_project_file_written",
        "development_project_files_imported",
        "development_project_file_edited",
        "development_project_path_moved",
        "development_project_path_deleted",
        "development_project_snapshot_restored",
    }
)
_SOURCE_TOOLS = frozenset(
    {
        "scientific_source_manifest",
        "source_inventory",
        "source_search",
        "source_read",
        "source_probe",
    }
)
_SOURCE_READ_TOOLS = _SOURCE_TOOLS - {"source_probe"}
_EXECUTION_WORKSPACE_TOOLS = frozenset(
    {
        "development_project_tree",
        "development_project_read",
        "development_project_search",
        "development_project_terminal_start",
    }
)
_COMMON_CONTROL_TOOLS = frozenset(
    {
        "read_ref",
        "artifact_read",
        "restart_node_attempt",
    }
)


def render(root_detail: str, context: Mapping[str, Any]) -> str:
    """Reveal only the bound target and the current materialization page."""
    formula = _bound_formula(context)
    protocol = _bound_protocol_only(context) if formula is None else None
    specification_refs = (
        _bound_specification_bundle_refs(context)
        if formula is None and protocol is None
        else ()
    )
    primary = formula or protocol
    if primary or specification_refs:
        root_detail += "\n\n" + _page("source-access.md")
        if primary:
            primary_ref = _stored_ref(primary)
            implementation_ref = (
                _latest_implementation_ref(context, primary_ref) if formula else
                _latest_protocol_implementation_ref(context, primary_ref)
            )
            retained = _readable_project_executions(context, implementation_ref)
            resumable = _retained_project_executions(context, implementation_ref)
            if retained:
                root_detail += "\n\n" + _page("retained-execution-stage.md")
                root_detail += "\n\nVisible retained executions (not completion claims):\n"
                for workspace_ref, stored in retained.items():
                    root_detail += (
                        f"- workspace `{workspace_ref}`; observation `{stored.get('observation_ref')}`; "
                        f"implementation `{_mapping(stored.get('metadata')).get('implementation_ref')}`; "
                        f"resume_from eligible: `{workspace_ref in resumable}`\n"
                    )
    if formula is None:
        if protocol is not None:
            return _render_protocol_only(root_detail, context, protocol)
        if specification_refs:
            return _render_specification_intake(
                root_detail,
                context,
                specification_refs,
            )
        binding = (
            "## Current invocation\n\n"
            "No unambiguous implementation specification was mounted at the "
            "skill-selection boundary. Materializer accepts one exact Formula, "
            "one exact Protocol, or one coherent bundle of exact formal inputs "
            "that defines a direct computational result. Do not write code. Call "
            "restart_node_attempt and state which exact authority is missing or "
            "ambiguous."
        )
        return "\n\n".join(
            (
                root_detail.strip(),
                binding,
                _page("protocol-only-binding-stage.md"),
            )
        )

    formula_ref = _stored_ref(formula)
    protocols = _bound_protocols(context, formula_ref)
    source_observation_required = _source_observation_required(
        context,
        protocols,
    )
    payload = _mapping(formula.get("machine_payload"))
    target_kind = str(payload.get("target_kind") or "unspecified")
    target_id = str(payload.get("target_id") or "unspecified")
    stage = _stage(context, formula_ref)
    target_page = {
        "final_kpi": "final-kpi-target.md",
        "auxiliary_condition": "auxiliary-condition-target.md",
    }.get(target_kind)
    pages = [root_detail.strip()]
    lineage_refs = {
        kind: _latest_lineage_ref(context, formula_ref, kind)
        for kind in (
            "code_artifact",
            _PROJECT_SNAPSHOT_KIND,
            "execution_observation",
            _MATERIALIZATION_KIND,
        )
    }
    implementation_ref = _latest_implementation_ref(context, formula_ref)
    probe = _latest_source_probe(context)
    probe_requires_reconciliation = _probe_postdates_inspection(context, probe)
    execution_failure = _current_code_execution_failure(
        context,
        code_ref=lineage_refs["code_artifact"],
    )
    if not execution_failure:
        execution_failure = _current_project_execution_failure(
            context,
            implementation_ref=implementation_ref,
        )
    project_progress = _project_progress(context)
    execution_interruption = _current_project_execution_interruption(
        context,
        implementation_ref=implementation_ref,
    )
    repair_required = bool(
        (
            str(context.get("current_issue") or "").strip()
            or probe_requires_reconciliation
            or execution_failure
        )
        and (implementation_ref or lineage_refs["execution_observation"])
    )
    invocation_lines = [
        "## Current invocation",
        "",
        f"- exact formula ref: `{formula_ref}`",
        f"- target kind: `{target_kind}`",
        f"- target id: `{target_id}`",
        "- current implementation stage: `"
        + ("repair" if repair_required else stage)
        + "`",
        "- source observation before implementation: `"
        + ("required" if source_observation_required else "not required")
        + "`",
        "- implementation environment: Runtime-managed and fixed for this run; "
        "derive package availability from that exact environment rather than "
        "guessing. Do not select, install, or replace the environment.",
    ]
    if project_progress["project_id"]:
        invocation_lines.extend(
            (
                "- active development project: `"
                + str(project_progress["project_id"])
                + "`",
                "- active project environment: Runtime-managed (provenance `"
                + str(project_progress["environment_ref"] or "unknown")
                + "`)",
                "- project operation stage: `"
                + _project_operation_stage(context)
                + "`",
                "- active project revision: `"
                + str(project_progress["revision"])
                + "`",
            )
        )
        invocation_lines.extend(_project_validation_progress_lines(project_progress))
        if project_progress["bound_route_refs"]:
            invocation_lines.append(
                "- project-bound managed Routes: "
                + ", ".join(
                    f"`{ref}`" for ref in project_progress["bound_route_refs"]
                )
            )
    if project_progress["pending_snapshot_ref"]:
        invocation_lines.append(
            "- pending immutable checkpoint readback: `"
            + str(project_progress["pending_snapshot_ref"])
            + "`"
        )
    if execution_interruption:
        invocation_lines.extend(
            (
                "- formal execution status: `interrupted before completion`",
                f"- last execution duration (seconds): `{execution_interruption.get('duration_seconds', 'unknown')}`",
                "- retained execution workspace: `"
                + str(execution_interruption.get("execution_workspace_ref") or "")
                + "`",
                "- inspect retained runtime state before deciding whether the "
                "same immutable project is worth continuing",
            )
        )
    specialist_refs = _specialist_assessment_refs(context)
    if specialist_refs:
        invocation_lines.append(
            "- optional Specialist guidance available: "
            + ", ".join(f"`{ref}`" for ref in specialist_refs)
        )
        invocation_lines.append(
            "  Use it as advisory evidence for open implementation choices; "
            "Materializer still owns and tests the execution strategy."
        )
    else:
        invocation_lines.append(
            "- optional Specialist guidance: `absent`; continue by forming "
            "and testing a defensible execution strategy from the bound "
            "specification and available evidence."
        )
    if not source_observation_required:
        invocation_lines.append(
            "  Every Protocol required input id is already satisfied by a "
            "mounted formal artifact (or the Protocol declares no external "
            "input). Proceed from those artifacts; do not call source_inventory "
            "for generic confirmation."
        )
    for protocol in protocols:
        protocol_payload = _mapping(protocol.get("machine_payload"))
        invocation_lines.extend(
            (
                f"- exact computational protocol ref: `{_stored_ref(protocol)}`",
                "  - quantity id: `"
                + str(protocol_payload.get("quantity_id") or "")
                + "`",
            )
        )
    for label, kind in (
        ("current code ref", "code_artifact"),
        ("current project snapshot ref", _PROJECT_SNAPSHOT_KIND),
        ("current observation ref", "execution_observation"),
        ("current materialization ref", _MATERIALIZATION_KIND),
    ):
        ref = lineage_refs[kind]
        if ref:
            invocation_lines.append(f"- {label}: `{ref}`")
    if probe is not None:
        probe_result = probe[1]
        probe_code_ref = str(probe_result.get("code_ref") or "")
        probe_stdout_ref = str(probe_result.get("stdout_ref") or "")
        probe_stderr_ref = str(probe_result.get("stderr_ref") or "")
        probe_error_preview = _compact_probe_error(probe_result.get("stderr_preview"))
        invocation_lines.extend(
            (
                "- latest executed source probe status: "
                f"`{probe_result.get('status')}`",
                "- latest executed source probe code ref: "
                f"`{probe_code_ref or 'none'}`",
                f"- latest source probe stdout ref: `{probe_stdout_ref or 'none'}`",
                f"- latest source probe stderr ref: `{probe_stderr_ref or 'none'}`",
                "- latest source probe produced observations: "
                + ("yes" if _probe_has_output(probe_result) else "no"),
                "- latest source probe output read back: "
                + ("yes" if _probe_stdout_was_read(context, probe) else "no"),
            )
        )
        if str(probe_result.get("status") or "") in {
            "source_probe_failed",
            "source_probe_timed_out",
        }:
            invocation_lines.extend(
                (
                    "- latest source probe code read back: "
                    + (
                        "yes"
                        if _probe_ref_was_read(
                            context,
                            probe,
                            probe_code_ref,
                        )
                        else "no"
                    ),
                    "- latest source probe error read back: "
                    + (
                        "yes"
                        if _probe_ref_was_read(
                            context,
                            probe,
                            probe_stderr_ref,
                        )
                        else "no"
                    ),
                )
            )
        if probe_error_preview:
            invocation_lines.append(
                f"- latest source probe error preview: `{probe_error_preview}`"
            )
        if _probe_stdout_was_read(context, probe):
            probe_observation = _compact_probe_observation(
                probe_result.get("stdout_preview")
            )
            if probe_observation:
                invocation_lines.append(
                    f"- latest source probe observation: `{probe_observation}`"
                )
        if probe_requires_reconciliation:
            invocation_lines.append(
                "- The latest focused probe was produced after the current "
                "observation was inspected. Reconcile that exact finding with "
                "the current code before publication."
            )
    if execution_failure:
        invocation_lines.append(
            "- unresolved execution failure for current code: "
            f"`{_compact_probe_error(execution_failure)}`"
        )
    latest_edit = _latest_tool_result(context, "edit_code_artifact")
    if latest_edit:
        edited_ref = str(latest_edit.get("code_artifact_ref") or "")
        previous_ref = str(latest_edit.get("previous_code_artifact_ref") or "")
        replacement_count = latest_edit.get("replacement_count")
        if edited_ref:
            invocation_lines.append(
                "- latest completed code edit: "
                f"`{previous_ref or 'unknown'}` -> `{edited_ref}`; "
                f"replacement count `{replacement_count}`"
            )
    source_observations = _source_observation_ledger(context)
    if source_observations:
        invocation_lines.append(
            "- recent source observations (continue from these; do not restart):"
        )
        invocation_lines.extend(f"  - {item}" for item in source_observations)
    prepared_content_refs = _prepared_source_content_refs(context)
    if prepared_content_refs:
        invocation_lines.append("- exact prepared source body refs:")
        invocation_lines.extend(f"  - `{ref}`" for ref in prepared_content_refs)
    invocation_lines.extend(
        _managed_route_projection(context, implementation_stage=stage)
    )
    invocation_lines.extend(
        (
            "- Only this formula's implementation lineage is visible and valid.",
            "- The formula's `depends_on` refs are provenance only; do not read "
            "them unless they were separately resolved for this invocation.",
        )
    )
    pages.append("\n".join(invocation_lines))
    if target_page:
        pages.append(_page(target_page))
    if protocols:
        pages.append(_page("computational-protocol-stage.md"))
    if stage == "publication":
        pages.append(_page("code-review-stage.md"))
    if repair_required and stage == "execution":
        pages.append(_page("implementation-stage.md"))
    if stage == "source-observation":
        pages.append(_page(_source_observation_page(context, probe)))
    elif stage == "publication" and repair_required:
        pages.append(_page("repair-stage.md"))
    elif stage == "execution" and project_progress["snapshot_stale"]:
        pages.append(_page("project-authoring-stage.md"))
    else:
        pages.append(_page(_STAGE_PAGE_BY_STAGE[stage]))
    if stage == "completion":
        pages.append(_page("publication-stage.md"))
    if stage == "implementation":
        pages.append(_page(_project_operation_page(context)))
    if repair_required and stage not in {"publication", "source-observation"}:
        pages.append(_page("repair-stage.md"))
    if stage in {"implementation", "execution", "inspection", "publication", "completion"}:
        pages.append(_execution_strategy(stage, repair_required=repair_required))
    if stage in {"inspection", "publication", "completion"}:
        pages.append(evidence_completeness_instruction())
        pages.append(_page("result-account.md"))
    if execution_interruption:
        pages.append(_page("execution-interruption-stage.md"))
    return "\n\n".join(page for page in pages if page.strip())


def visible_refs(context: Mapping[str, Any]) -> Sequence[str]:
    """Project boundary inputs plus only the current formula-lineage tips."""
    artifacts = _artifact_map(context)
    formula = _bound_formula(context)
    if formula is None:
        protocol = _bound_protocol_only(context)
        if protocol is not None:
            return _protocol_visible_refs(context, protocol)
        specification_refs = _bound_specification_bundle_refs(context)
        if specification_refs:
            return _specification_intake_visible_refs(
                context,
                specification_refs,
            )
    formula_ref = _stored_ref(formula) if formula is not None else ""
    current_lineage_refs = {formula_ref} if formula_ref else set()
    if formula_ref:
        current_lineage_refs.update(
            ref
            for ref in (
                _latest_lineage_ref(context, formula_ref, "code_artifact"),
                _latest_lineage_ref(context, formula_ref, _PROJECT_SNAPSHOT_KIND),
                _latest_lineage_ref(context, formula_ref, "execution_observation"),
                _latest_lineage_ref(context, formula_ref, _MATERIALIZATION_KIND),
            )
            if ref
        )
        current_lineage_refs.update(
            _stored_ref(protocol) for protocol in _bound_protocols(context, formula_ref)
        )

    visible: list[str] = []
    for ref in _string_sequence(context.get("invocation_seed_refs")):
        stored = artifacts.get(ref)
        if (
            stored is not None
            and stored.get("artifact_kind") == _FORMULA_KIND
            and ref != formula_ref
        ):
            continue
        _append_unique(visible, ref)
    for stored in _mapping_sequence(context.get("resolved_artifacts")):
        ref = _stored_ref(stored)
        if ref in current_lineage_refs:
            _append_unique(visible, ref)
    for ref in _prepared_source_content_refs(context):
        _append_unique(visible, ref)
    for ref in _managed_route_candidate_refs(context):
        _append_unique(visible, ref)
    pending_snapshot_ref = _latest_project_snapshot_receipt_ref(context)
    if pending_snapshot_ref:
        _append_unique(visible, pending_snapshot_ref)
    for ref in _development_output_refs(context):
        _append_unique(visible, ref)
    return tuple(visible)


def validate_tool_call(
    tool_name: str,
    arguments: Mapping[str, Any],
    context: Mapping[str, Any],
) -> None:
    """Reject cross-invocation reads and lineage changes without judging science."""
    formula = _bound_formula(context)
    if formula is None:
        protocol = _bound_protocol_only(context)
        if protocol is not None:
            _validate_protocol_tool_call(
                tool_name,
                arguments,
                context,
                protocol,
            )
            return
        specification_refs = _bound_specification_bundle_refs(context)
        if specification_refs:
            _validate_specification_intake_tool_call(
                tool_name,
                arguments,
                context,
                specification_refs,
            )
            return
        raise ValueError(
            "materializer_primary_spec_binding_required:"
            "mount_one_exact_formula_protocol_or_coherent_formal_"
            "implementation_specification_bundle_before_loading_materializer"
        )
    formula_ref = _stored_ref(formula)
    protocols = _bound_protocols(context, formula_ref)
    allowed = set(visible_refs(context))
    formula_refs = _formula_refs(context)
    probe = _latest_source_probe(context)
    source_focus = _source_observation_focus(context, probe)

    if source_focus in {"inventory", "reading", "probe"}:
        _validate_preprobe_source_call(
            tool_name,
            arguments,
            context,
            formula_ref=formula_ref,
        )
    elif source_focus == "diagnosis":
        _validate_probe_diagnosis_call(tool_name, arguments, context, probe)
    elif source_focus == "repair":
        _validate_probe_repair_call(tool_name, arguments)
    elif source_focus == "readback":
        _validate_probe_readback_call(tool_name, arguments, probe)

    if tool_name in {"read_ref", "artifact_read"}:
        ref = str(arguments.get("ref") or arguments.get("artifact_ref") or "")
        if tool_name == "read_ref" and ref.startswith(
            ("source_file:", "source_probe:")
        ):
            return
        if ref not in allowed:
            raise ValueError(
                "materializer_ref_outside_current_invocation:"
                f"requested={ref}:bound_formula_ref={formula_ref}"
            )
        return

    if tool_name == "write_code_artifact":
        if _source_observation_required(
            context, protocols
        ) and not _minimum_source_observation_available(context):
            raise ValueError(
                "materializer_source_observation_required:"
                "read_at_least_one_exact_source_page_before_writing_code;"
                "if_direct_read_does_not_establish_the_needed_shape_or_"
                "relationship_run_a_bounded_probe_and_read_its_stdout"
            )
        code = str(arguments.get("python_code") or "")
        _reject_placeholder_code(code)
        _require_materializer_entrypoint(code)
        dependencies = _string_sequence(arguments.get("depends_on"))
        _require_bound_formula_dependency(
            dependencies,
            formula_ref=formula_ref,
            formula_refs=formula_refs,
        )
        protocol_refs = {_stored_ref(protocol) for protocol in protocols}
        missing_protocol_refs = sorted(protocol_refs - set(dependencies))
        if missing_protocol_refs:
            raise ValueError(
                "materializer_protocol_code_dependency_required:"
                f"protocol_refs={missing_protocol_refs}"
            )
        _validate_managed_route_source_binding(
            code,
            dependencies=dependencies,
            context=context,
        )
        previous_code_ref = _latest_lineage_ref(
            context,
            formula_ref,
            "code_artifact",
        )
        if previous_code_ref and previous_code_ref not in dependencies:
            raise ValueError(
                "materializer_repair_previous_code_dependency_required:"
                f"previous_code_ref={previous_code_ref}:"
                "preserve_the_exact_previous_revision_in_depends_on"
            )
        return

    if tool_name == "development_project_configure":
        return

    if tool_name in _EXECUTION_WORKSPACE_TOOLS and "execution_workspace_ref" in arguments:
        _validate_execution_workspace_tool_call(
            tool_name,
            arguments,
            context,
            implementation_ref=_latest_implementation_ref(context, formula_ref),
        )
        return

    if tool_name == "development_project_open":
        if _source_observation_required(
            context, protocols
        ) and not _minimum_source_observation_available(context):
            raise ValueError(
                "materializer_source_observation_required:"
                "read_at_least_one_exact_source_page_before_opening_project"
            )
        dependencies = _string_sequence(arguments.get("depends_on"))
        _require_bound_formula_dependency(
            dependencies,
            formula_ref=formula_ref,
            formula_refs=formula_refs,
        )
        protocol_refs = {_stored_ref(protocol) for protocol in protocols}
        missing_protocol_refs = sorted(protocol_refs - set(dependencies))
        if missing_protocol_refs:
            raise ValueError(
                "materializer_protocol_project_dependency_required:"
                f"protocol_refs={missing_protocol_refs}"
            )
        previous_implementation_ref = _latest_implementation_ref(context, formula_ref)
        if (
            previous_implementation_ref
            and previous_implementation_ref not in dependencies
        ):
            raise ValueError(
                "materializer_repair_previous_implementation_dependency_required:"
                f"implementation_ref={previous_implementation_ref}"
            )
        return

    if tool_name == "development_project_bind_managed_routes":
        requested = set(_string_sequence(arguments.get("route_refs")))
        allowed_routes = {
            str(item.get("route_ref") or "")
            for item in _managed_code_route_summaries(context)
        }
        if not requested or not requested.issubset(allowed_routes):
            raise ValueError(
                "materializer_project_route_binding_outside_invocation:"
                f"requested={sorted(requested)}:allowed={sorted(allowed_routes)}"
            )
        return

    if tool_name == "edit_code_artifact":
        code_ref = str(arguments.get("code_artifact_ref") or "")
        current_code_ref = _latest_lineage_ref(
            context,
            formula_ref,
            "code_artifact",
        )
        if not current_code_ref or code_ref != current_code_ref:
            raise ValueError(
                "materializer_edit_requires_current_formula_code:"
                f"code_artifact_ref={code_ref}:"
                f"current_code_artifact_ref={current_code_ref or 'none'}:"
                f"bound_formula_ref={formula_ref}"
            )
        return

    if tool_name == "scientific_materializer_execute":
        requested_formula = str(arguments.get("formula_artifact_ref") or "")
        if requested_formula != formula_ref:
            raise ValueError(
                "materializer_execute_formula_mismatch:"
                f"requested={requested_formula}:bound={formula_ref}"
            )
        code_ref = str(arguments.get("code_artifact_ref") or "")
        current_code_ref = _latest_lineage_ref(
            context,
            formula_ref,
            "code_artifact",
        )
        if not current_code_ref or code_ref != current_code_ref:
            raise ValueError(
                "materializer_execute_code_outside_current_lineage:"
                f"code_artifact_ref={code_ref}:"
                f"allowed_current_code_ref={current_code_ref or 'none'}:"
                f"bound_formula_ref={formula_ref}"
            )
        stored_code = _artifact_map(context).get(code_ref)
        route_dependencies = {
            ref
            for ref in _string_sequence(_mapping(stored_code).get("depends_on"))
            if ref.startswith(("approved_route:", "pending_route:"))
        }
        max_route_calls = arguments.get("max_route_calls", 0)
        if route_dependencies:
            if (
                isinstance(max_route_calls, bool)
                or not isinstance(max_route_calls, int)
                or max_route_calls < 1
            ):
                raise ValueError(
                    "materializer_approved_route_call_quota_required:"
                    f"route_refs={sorted(route_dependencies)}"
                )
        elif max_route_calls not in {None, 0}:
            raise ValueError("materializer_route_call_quota_without_route_dependency")
        return

    if tool_name == "scientific_materializer_run_project":
        requested_formula = str(arguments.get("spec_artifact_ref") or "")
        if requested_formula != formula_ref:
            raise ValueError(
                "materializer_project_formula_mismatch:"
                f"requested={requested_formula}:bound={formula_ref}"
            )
        implementation_ref = str(arguments.get("project_snapshot_ref") or "")
        current_implementation_ref = _latest_implementation_ref(context, formula_ref)
        if (
            not implementation_ref
            or implementation_ref != current_implementation_ref
            or not implementation_ref.startswith("artifact:")
        ):
            raise ValueError(
                "materializer_project_execute_outside_current_lineage:"
                f"requested={implementation_ref}:"
                f"current={current_implementation_ref or 'none'}"
            )
        if arguments.get("input_bindings"):
            raise ValueError(
                "formula_materializer_project_input_bindings_must_be_empty"
            )
        _validate_resume_from(arguments, context, implementation_ref)
        _require_execution_inventory_before_resume(
            context,
            implementation_ref=implementation_ref,
        )
        return

    if tool_name == "scientific_observation_inspect":
        observation_ref = str(arguments.get("observation_ref") or "")
        current_observation_ref = _latest_lineage_ref(
            context,
            formula_ref,
            "execution_observation",
        )
        if not current_observation_ref or observation_ref != current_observation_ref:
            raise ValueError(
                "materializer_inspect_observation_outside_current_lineage:"
                f"observation_ref={observation_ref}:"
                f"current_observation_ref={current_observation_ref or 'none'}:"
                f"bound_formula_ref={formula_ref}"
            )
        return

    if tool_name == "artifact_publish":
        _validate_publication(
            arguments,
            context=context,
            formula_ref=formula_ref,
            formula_refs=formula_refs,
            allowed=allowed,
        )


def _render_protocol_only(
    root_detail: str,
    context: Mapping[str, Any],
    protocol: Mapping[str, Any],
) -> str:
    protocol_ref = _stored_ref(protocol)
    payload = _mapping(protocol.get("machine_payload"))
    validate_computational_property_protocol(payload)
    stage = _protocol_stage(context, protocol_ref)
    lineage_refs = {
        kind: _latest_protocol_lineage_ref(context, protocol_ref, kind)
        for kind in (
            "code_artifact",
            _PROJECT_SNAPSHOT_KIND,
            "execution_observation",
            _PROPERTY_RESULT_KIND,
        )
    }
    implementation_ref = _latest_protocol_implementation_ref(context, protocol_ref)
    execution_failure = _current_protocol_code_execution_failure(
        context,
        code_ref=lineage_refs["code_artifact"],
    )
    if not execution_failure:
        execution_failure = _current_project_execution_failure(
            context,
            implementation_ref=implementation_ref,
        )
    project_progress = _project_progress(context)
    execution_interruption = _current_project_execution_interruption(
        context,
        implementation_ref=implementation_ref,
    )
    repair_required = bool(
        (
            str(context.get("current_issue") or "").strip()
            or execution_failure
        )
        and (implementation_ref or lineage_refs["execution_observation"])
    )
    result_contract = _mapping(payload.get("result_contract"))
    lines = [
        "## Current invocation",
        "",
        "- execution mode: `protocol-only`",
        f"- exact protocol ref: `{protocol_ref}`",
        f"- quantity id: `{payload.get('quantity_id')}`",
        "- scientific definition: `"
        + str(payload.get("scientific_definition") or "")
        + "`",
        "- required result: `"
        + str(result_contract.get("output_id") or "")
        + "` in `"
        + str(result_contract.get("unit") or "")
        + "`",
        "- result arithmetic: `"
        + str(result_contract.get("calculation_expression") or "")
        + "`",
        "- interpretation boundary: `"
        + str(result_contract.get("interpretation") or "")
        + "`",
        "- implementation environment: Runtime-managed and fixed for this run; "
        "derive package availability from that exact environment rather than "
        "guessing. Do not select, install, or replace the environment.",
        "- current implementation stage: `"
        + ("repair" if repair_required else stage)
        + "`",
        "- declared required inputs:",
    ]
    if project_progress["project_id"]:
        lines.extend(
            (
                "- active development project: `"
                + str(project_progress["project_id"])
                + "`",
                "- active project environment: Runtime-managed (provenance `"
                + str(project_progress["environment_ref"] or "unknown")
                + "`)",
                "- project operation stage: `"
                + _project_operation_stage(context)
                + "`",
                "- active project revision: `"
                + str(project_progress["revision"])
                + "`",
            )
        )
        lines.extend(_project_validation_progress_lines(project_progress))
        if project_progress["bound_route_refs"]:
            lines.append(
                "- project-bound managed Routes: "
                + ", ".join(
                    f"`{ref}`" for ref in project_progress["bound_route_refs"]
                )
            )
    if project_progress["pending_snapshot_ref"]:
        lines.append(
            "- pending immutable checkpoint readback: `"
            + str(project_progress["pending_snapshot_ref"])
            + "`"
        )
    if execution_interruption:
        lines.extend(
            (
                "- formal execution status: `interrupted before completion`",
                f"- last execution duration (seconds): `{execution_interruption.get('duration_seconds', 'unknown')}`",
                "- retained execution workspace: `"
                + str(execution_interruption.get("execution_workspace_ref") or "")
                + "`",
                "- inspect retained runtime state before deciding whether the "
                "same immutable project is worth continuing",
            )
        )
    specialist_refs = _specialist_assessment_refs(context)
    if specialist_refs:
        lines.append(
            "- optional Specialist guidance available: "
            + ", ".join(f"`{ref}`" for ref in specialist_refs)
        )
        lines.append(
            "  Use it as advisory evidence for open implementation choices; "
            "Materializer still owns and tests the execution strategy."
        )
    else:
        lines.append(
            "- optional Specialist guidance: `absent`; continue by forming "
            "and testing a defensible execution strategy from the bound "
            "Protocol and available evidence."
        )
    for item in _mapping_sequence(payload.get("required_inputs")):
        lines.append(
            "  - `"
            + str(item.get("input_id") or "")
            + "` | "
            + str(item.get("requirements") or "")
        )
    if not _mapping_sequence(payload.get("required_inputs")):
        lines.append("  - none; the implementation may construct task-defined inputs")
    lines.extend(
        (
            "- Protocol authority split:",
            "  - immutable: quantity definition, required external inputs, "
            "reference arithmetic, result id, unit, and interpretation boundary",
            "  - advisory: Protocol Markdown and specialist assessment "
            "recommendations, possible Routes, initial settings, exploration "
            "axes, convergence targets, alternatives, and uncertainties",
            "  - Materializer-owned: Route selection, executable dataflow, "
            "operational parameters, implementation, testing, and repair",
        )
    )
    for label, kind in (
        ("current code ref", "code_artifact"),
        ("current project snapshot ref", _PROJECT_SNAPSHOT_KIND),
        ("current observation ref", "execution_observation"),
        ("current property result ref", _PROPERTY_RESULT_KIND),
    ):
        ref = lineage_refs[kind]
        if ref:
            lines.append(f"- {label}: `{ref}`")
    if execution_failure:
        lines.append(
            "- unresolved execution failure for current code: `"
            + _compact_probe_error(execution_failure)
            + "`"
        )
    lines.extend(_managed_route_projection(context, implementation_stage=stage))

    pages = [root_detail.strip(), "\n".join(lines)]
    if stage == "implementation":
        pages.append(_page("protocol-only-implementation-stage.md"))
        pages.append(_page(_project_operation_page(context)))
    elif stage == "execution" and project_progress["snapshot_stale"]:
        pages.append(_page("protocol-only-implementation-stage.md"))
        pages.append(_page("project-authoring-stage.md"))
    elif stage in {"execution", "inspection"}:
        pages.append(_page("protocol-only-execution-stage.md"))
    elif stage == "publication":
        pages.append(_page("protocol-only-publication-stage.md"))
    else:
        pages.append(_page("protocol-only-publication-stage.md"))
        pages.append(
            "# Protocol-only Completion\n\n"
            "Read back the exact published `computational_property_result`, "
            "confirm its Protocol, Code and Observation provenance, then end "
            "this Materializer invocation."
        )
    if repair_required:
        pages.append(_page("protocol-only-repair-stage.md"))
    if stage in {"implementation", "execution", "inspection", "publication", "completion"}:
        pages.append(_execution_strategy(stage, repair_required=repair_required))
    if stage in {"inspection", "publication", "completion"}:
        pages.append(evidence_completeness_instruction())
        pages.append(_page("result-account.md"))
    if execution_interruption:
        pages.append(_page("execution-interruption-stage.md"))
    return "\n\n".join(page for page in pages if page.strip())


def _render_specification_intake(
    root_detail: str,
    context: Mapping[str, Any],
    specification_refs: Sequence[str],
) -> str:
    artifacts = _artifact_map(context)
    lines = [
        "## Current invocation",
        "",
        "- execution mode: `specification-intake`",
        "- exact implementation specification bundle:",
    ]
    for ref in specification_refs:
        stored = artifacts[ref]
        kind = str(stored.get("artifact_kind") or "unknown")
        label = str(stored.get("title") or stored.get("summary") or "").strip()
        suffix = f" | {label}" if label else ""
        lines.append(f"  - `{ref}` | `{kind}`{suffix}")
    lines.extend(
        (
            "- next formal checkpoint: one existing "
            "`computational_property_protocol` derived from every ref above",
            "- this checkpoint preserves the commission and establishes the "
            "existing result schema; it is not a separate Graph outcome",
            "- no implementation tool is available until that Protocol is "
            "published and read back",
        )
    )
    return "\n\n".join(
        (
            root_detail.strip(),
            "\n".join(lines),
            _page("specification-intake-stage.md"),
            "## Protocol machine_payload schema\n\n"
            "Use this exact registered shape for machine_payload. Publication "
            "and local repair validate against the same schema. Artifact envelope "
            "fields such as depends_on remain outside machine_payload. "
            "Each required_inputs input_id must be unique.\n\n```json\n"
            + json.dumps(computational_property_protocol_schema(), indent=2)
            + "\n```",
        )
    )


def _specification_intake_visible_refs(
    context: Mapping[str, Any],
    specification_refs: Sequence[str],
) -> tuple[str, ...]:
    artifacts = _artifact_map(context)
    return tuple(ref for ref in specification_refs if ref in artifacts)


def _validate_specification_intake_tool_call(
    tool_name: str,
    arguments: Mapping[str, Any],
    context: Mapping[str, Any],
    specification_refs: Sequence[str],
) -> None:
    allowed = set(
        _specification_intake_visible_refs(context, specification_refs)
    )
    if tool_name in _SOURCE_READ_TOOLS or tool_name == "restart_node_attempt":
        return
    if tool_name in {"read_ref", "artifact_read"}:
        ref = str(arguments.get("ref") or arguments.get("artifact_ref") or "")
        if tool_name == "read_ref" and ref.startswith("source_file:"):
            return
        if ref not in allowed:
            raise ValueError(
                "materializer_specification_ref_outside_current_invocation:"
                f"requested={ref}:allowed={sorted(allowed)}"
            )
        return
    if tool_name != "artifact_publish":
        raise ValueError(
            "materializer_specification_intake_protocol_required_before_"
            f"implementation:tool={tool_name}"
        )
    if str(arguments.get("artifact_kind") or "") != _PROTOCOL_KIND:
        raise ValueError(
            "materializer_specification_intake_publication_kind_mismatch:"
            f"expected={_PROTOCOL_KIND}"
        )
    if str(arguments.get("machine_payload_observation_ref") or "").strip():
        raise ValueError(
            "materializer_specification_intake_authored_payload_required:"
            "do_not_copy_a_protocol_from_an_execution_observation"
        )
    validate_computational_property_protocol(arguments.get("machine_payload"))
    dependencies = set(_string_sequence(arguments.get("depends_on")))
    missing = sorted(allowed - dependencies)
    unrelated = sorted(dependencies - allowed)
    if missing or unrelated:
        raise ValueError(
            "materializer_specification_intake_exact_lineage_required:"
            f"missing={missing}:unrelated={unrelated}"
        )
    if not str(arguments.get("summary") or "").strip():
        raise ValueError(
            "materializer_specification_intake_summary_required:"
            "summarize_the_quantity_result_contract_and_hard_conditions"
        )


def _protocol_visible_refs(
    context: Mapping[str, Any],
    protocol: Mapping[str, Any],
) -> tuple[str, ...]:
    artifacts = _artifact_map(context)
    protocol_ref = _stored_ref(protocol)
    lineage = _protocol_lineage_refs(context, protocol_ref)
    visible: list[str] = []
    for ref in _string_sequence(context.get("invocation_seed_refs")):
        if ref in artifacts:
            _append_unique(visible, ref)
    for stored in _mapping_sequence(context.get("resolved_artifacts")):
        ref = _stored_ref(stored)
        if ref in lineage:
            _append_unique(visible, ref)
    for ref in _managed_route_candidate_refs(context):
        _append_unique(visible, ref)
    pending_snapshot_ref = _latest_project_snapshot_receipt_ref(context)
    if pending_snapshot_ref:
        _append_unique(visible, pending_snapshot_ref)
    for ref in _development_output_refs(context):
        _append_unique(visible, ref)
    return tuple(visible)


def _validate_protocol_tool_call(
    tool_name: str,
    arguments: Mapping[str, Any],
    context: Mapping[str, Any],
    protocol: Mapping[str, Any],
) -> None:
    protocol_ref = _stored_ref(protocol)
    payload = _mapping(protocol.get("machine_payload"))
    validate_computational_property_protocol(payload)
    allowed = set(_protocol_visible_refs(context, protocol))

    if tool_name in _SOURCE_READ_TOOLS:
        # The registered source authority enforces the mission path policy.
        return
    if tool_name == "source_probe":
        raise ValueError(
            "protocol_materializer_source_exploration_outside_responsibility:"
            "use_the_bound_protocol_and_exact_invocation_inputs_or_return_a_"
            "bounded_gap"
        )

    if tool_name in {"read_ref", "artifact_read"}:
        ref = str(arguments.get("ref") or arguments.get("artifact_ref") or "")
        if tool_name == "read_ref" and ref.startswith(("source_file:", "source_probe:")):
            return
        if ref not in allowed:
            raise ValueError(
                "protocol_materializer_ref_outside_current_invocation:"
                f"requested={ref}:bound_protocol_ref={protocol_ref}"
            )
        return

    if tool_name == "write_code_artifact":
        code = str(arguments.get("python_code") or "")
        _reject_placeholder_code(code)
        _require_protocol_materializer_entrypoint(code)
        dependencies = _string_sequence(arguments.get("depends_on"))
        if protocol_ref not in dependencies:
            raise ValueError(
                "protocol_materializer_exact_protocol_dependency_required:"
                f"protocol_ref={protocol_ref}"
            )
        unrelated_protocols = sorted(
            ref
            for ref in dependencies
            if ref in _protocol_refs(context) and ref != protocol_ref
        )
        if unrelated_protocols:
            raise ValueError(
                "protocol_materializer_unrelated_protocol_dependency_rejected:"
                f"refs={unrelated_protocols}"
            )
        _validate_managed_route_source_binding(
            code,
            dependencies=dependencies,
            context=context,
        )
        previous_code_ref = _latest_protocol_lineage_ref(
            context,
            protocol_ref,
            "code_artifact",
        )
        if previous_code_ref and previous_code_ref not in dependencies:
            raise ValueError(
                "protocol_materializer_repair_previous_code_dependency_required:"
                f"previous_code_ref={previous_code_ref}"
            )
        return

    if tool_name == "development_project_configure":
        return

    if tool_name == "development_project_open":
        dependencies = _string_sequence(arguments.get("depends_on"))
        if protocol_ref not in dependencies:
            raise ValueError(
                "protocol_materializer_exact_protocol_dependency_required:"
                f"protocol_ref={protocol_ref}"
            )
        previous_implementation_ref = _latest_protocol_implementation_ref(
            context, protocol_ref
        )
        if (
            previous_implementation_ref
            and previous_implementation_ref not in dependencies
        ):
            raise ValueError(
                "protocol_materializer_repair_previous_implementation_"
                "dependency_required:"
                f"implementation_ref={previous_implementation_ref}"
            )
        return

    if tool_name == "development_project_bind_managed_routes":
        requested = set(_string_sequence(arguments.get("route_refs")))
        allowed = {
            str(item.get("route_ref") or "")
            for item in _managed_code_route_summaries(context)
        }
        if not requested or not requested.issubset(allowed):
            raise ValueError(
                "protocol_materializer_project_route_binding_outside_invocation:"
                f"requested={sorted(requested)}:allowed={sorted(allowed)}"
            )
        return

    if tool_name == "edit_code_artifact":
        code_ref = str(arguments.get("code_artifact_ref") or "")
        current_code_ref = _latest_protocol_lineage_ref(
            context,
            protocol_ref,
            "code_artifact",
        )
        if not current_code_ref or code_ref != current_code_ref:
            raise ValueError(
                "protocol_materializer_edit_requires_current_code:"
                f"requested={code_ref}:current={current_code_ref or 'none'}"
            )
        return

    if tool_name == "scientific_protocol_materializer_execute":
        requested_protocol = str(arguments.get("protocol_artifact_ref") or "")
        if requested_protocol != protocol_ref:
            raise ValueError(
                "protocol_materializer_execute_protocol_mismatch:"
                f"requested={requested_protocol}:bound={protocol_ref}"
            )
        code_ref = str(arguments.get("code_artifact_ref") or "")
        current_code_ref = _latest_protocol_lineage_ref(
            context,
            protocol_ref,
            "code_artifact",
        )
        if not current_code_ref or code_ref != current_code_ref:
            raise ValueError(
                "protocol_materializer_execute_code_outside_current_lineage:"
                f"requested={code_ref}:current={current_code_ref or 'none'}"
            )
        declared_input_ids = {
            str(item.get("input_id") or "")
            for item in _mapping_sequence(payload.get("required_inputs"))
        }
        seen_input_ids: set[str] = set()
        _validate_resume_from(arguments, context, implementation_ref)
        for binding in _mapping_sequence(arguments.get("input_bindings")):
            input_id = str(binding.get("input_id") or "")
            artifact_ref = str(binding.get("artifact_ref") or "")
            if input_id not in declared_input_ids or input_id in seen_input_ids:
                raise ValueError(
                    f"protocol_materializer_input_binding_invalid:input_id={input_id}"
                )
            if artifact_ref not in allowed:
                raise ValueError(
                    "protocol_materializer_input_artifact_outside_invocation:"
                    f"artifact_ref={artifact_ref}"
                )
            seen_input_ids.add(input_id)
        stored_code = _mapping(_artifact_map(context).get(code_ref))
        route_dependencies = {
            ref
            for ref in _string_sequence(stored_code.get("depends_on"))
            if ref.startswith(("approved_route:", "pending_route:"))
        }
        max_route_calls = arguments.get("max_route_calls")
        if route_dependencies:
            if (
                isinstance(max_route_calls, bool)
                or not isinstance(max_route_calls, int)
                or max_route_calls < 1
            ):
                raise ValueError(
                    "protocol_materializer_route_call_quota_required:"
                    f"route_refs={sorted(route_dependencies)}"
                )
        elif max_route_calls != 0:
            raise ValueError(
                "protocol_materializer_route_call_quota_without_route_dependency:"
                "bind_each_selected_exact_route_ref_to_the_development_project_"
                "then_checkpoint_and_execute_the_new_snapshot"
            )
        return

    if tool_name == "scientific_materializer_run_project":
        requested_protocol = str(arguments.get("spec_artifact_ref") or "")
        if requested_protocol != protocol_ref:
            raise ValueError(
                "protocol_materializer_project_protocol_mismatch:"
                f"requested={requested_protocol}:bound={protocol_ref}"
            )
        implementation_ref = str(arguments.get("project_snapshot_ref") or "")
        current_implementation_ref = _latest_protocol_implementation_ref(
            context, protocol_ref
        )
        if (
            not implementation_ref
            or implementation_ref != current_implementation_ref
            or not implementation_ref.startswith("artifact:")
        ):
            raise ValueError(
                "protocol_materializer_project_execute_outside_lineage:"
                f"requested={implementation_ref}:"
                f"current={current_implementation_ref or 'none'}"
            )
        declared_input_ids = {
            str(item.get("input_id") or "")
            for item in _mapping_sequence(payload.get("required_inputs"))
        }
        seen_input_ids = {
            str(item.get("input_id") or "")
            for item in _mapping_sequence(arguments.get("input_bindings"))
        }
        if seen_input_ids != declared_input_ids:
            raise ValueError(
                "protocol_materializer_project_input_ids_mismatch:"
                f"required={sorted(declared_input_ids)}:"
                f"actual={sorted(seen_input_ids)}"
            )
        for binding in _mapping_sequence(arguments.get("input_bindings")):
            artifact_ref = str(binding.get("artifact_ref") or "")
            if artifact_ref not in allowed:
                raise ValueError(
                    "protocol_materializer_input_artifact_outside_invocation:"
                    f"artifact_ref={artifact_ref}"
                )
        _require_execution_inventory_before_resume(
            context,
            implementation_ref=implementation_ref,
        )
        return

    if tool_name in _EXECUTION_WORKSPACE_TOOLS and "execution_workspace_ref" in arguments:
        _validate_execution_workspace_tool_call(
            tool_name,
            arguments,
            context,
            implementation_ref=_latest_protocol_implementation_ref(
                context,
                protocol_ref,
            ),
        )
        return

    if tool_name == "scientific_observation_inspect":
        observation_ref = str(arguments.get("observation_ref") or "")
        current_observation_ref = _latest_protocol_lineage_ref(
            context,
            protocol_ref,
            "execution_observation",
        )
        if not current_observation_ref or observation_ref != current_observation_ref:
            raise ValueError(
                "protocol_materializer_inspect_observation_outside_lineage:"
                f"requested={observation_ref}:"
                f"current={current_observation_ref or 'none'}"
            )
        return

    if tool_name == "artifact_publish":
        _validate_protocol_publication(
            arguments,
            context=context,
            protocol_ref=protocol_ref,
            allowed=allowed,
        )


def _validate_protocol_publication(
    arguments: Mapping[str, Any],
    *,
    context: Mapping[str, Any],
    protocol_ref: str,
    allowed: set[str],
) -> None:
    if str(arguments.get("artifact_kind") or "") != _PROPERTY_RESULT_KIND:
        raise ValueError(
            "protocol_materializer_publication_kind_mismatch:"
            f"expected={_PROPERTY_RESULT_KIND}"
        )
    observation_ref = str(arguments.get("machine_payload_observation_ref") or "")
    current_observation_ref = _latest_protocol_lineage_ref(
        context,
        protocol_ref,
        "execution_observation",
    )
    if not observation_ref or observation_ref != current_observation_ref:
        raise ValueError(
            "protocol_materializer_publication_requires_current_observation:"
            f"requested={observation_ref}:"
            f"current={current_observation_ref or 'none'}"
        )
    observation = _artifact_map(context).get(observation_ref)
    if observation is None or not bool(observation.get("_inspected")):
        raise ValueError(
            "protocol_materializer_publication_requires_inspected_observation:"
            f"observation_ref={observation_ref}"
        )
    metadata = _mapping(observation.get("metadata"))
    if str(metadata.get("protocol_artifact_ref") or "") != protocol_ref:
        raise ValueError(
            "protocol_materializer_publication_observation_protocol_mismatch"
        )
    implementation_ref = str(metadata.get("implementation_ref") or "")
    current_implementation_ref = _latest_protocol_implementation_ref(
        context, protocol_ref
    )
    if not implementation_ref or implementation_ref != current_implementation_ref:
        raise ValueError(
            "protocol_materializer_publication_requires_current_implementation:"
            f"implementation_ref={implementation_ref}:"
            f"current={current_implementation_ref or 'none'}"
        )
    input_refs = {
        str(item.get("artifact_ref") or "")
        for item in _mapping_sequence(metadata.get("input_bindings"))
    }
    allowed_dependencies = {protocol_ref, *input_refs}
    dependencies = set(_string_sequence(arguments.get("depends_on")))
    rejected_dependencies = sorted(dependencies - allowed_dependencies)
    if rejected_dependencies:
        raise ValueError(
            "protocol_materializer_publication_dependency_rejected:"
            f"refs={rejected_dependencies}:"
            "code_and_observation_belong_in_trace_refs"
        )
    trace_refs = set(_string_sequence(arguments.get("trace_refs")))
    # Common supplies implementation/observation traces from the selected
    # stored observation. Only model-supplied additional traces need checking.
    for ref in trace_refs:
        if ref.startswith(
            ("artifact:", "code_artifact:", "execution_observation:")
        ) and (ref not in allowed):
            raise ValueError(
                "protocol_materializer_publication_trace_outside_lineage:"
                f"trace_ref={ref}"
            )
    if not str(arguments.get("summary") or "").strip():
        raise ValueError(
            "protocol_materializer_publication_summary_required:"
            "state_the_exact_quantity_output_and_unit"
        )


def _validate_publication(
    arguments: Mapping[str, Any],
    *,
    context: Mapping[str, Any],
    formula_ref: str,
    formula_refs: set[str],
    allowed: set[str],
) -> None:
    if str(arguments.get("artifact_kind") or "") != _MATERIALIZATION_KIND:
        raise ValueError(
            f"materializer_publication_kind_mismatch:expected={_MATERIALIZATION_KIND}"
        )
    dependencies = _string_sequence(arguments.get("depends_on"))
    nonformal_dependencies = sorted(
        ref for ref in dependencies if not ref.startswith("artifact:")
    )
    if nonformal_dependencies:
        raise ValueError(
            "materializer_publication_nonformal_dependency_rejected:"
            f"refs={nonformal_dependencies}:"
            "remove_nonformal_refs_from_depends_on;"
            "depends_on_may_contain_only_bound_formula;"
            "keep_code_and_execution_refs_in_trace_refs"
        )
    observation_ref = str(arguments.get("machine_payload_observation_ref") or "")
    current_observation_ref = _latest_lineage_ref(
        context,
        formula_ref,
        "execution_observation",
    )
    if not observation_ref or observation_ref != current_observation_ref:
        raise ValueError(
            "materializer_publication_requires_current_observation:"
            f"observation_ref={observation_ref}:"
            f"current_observation_ref={current_observation_ref or 'none'}:"
            f"bound_formula_ref={formula_ref}"
        )
    observation = _artifact_map(context).get(observation_ref)
    if observation is None or not bool(observation.get("_inspected")):
        raise ValueError(
            "materializer_publication_requires_inspected_current_observation:"
            f"observation_ref={observation_ref}"
        )
    validate_execution_input_paths(_mapping(observation.get("result")).get("execution_input_paths"))
    metadata = _mapping(observation.get("metadata"))
    observed_formula_ref = str(metadata.get("formula_artifact_ref") or "")
    if observed_formula_ref != formula_ref:
        raise ValueError(
            "materializer_publication_observation_formula_mismatch:"
            f"observation_ref={observation_ref}:bound_formula_ref={formula_ref}"
        )
    effective_dependencies = list(dependencies)
    if observed_formula_ref not in effective_dependencies:
        effective_dependencies.append(observed_formula_ref)
    _require_bound_formula_dependency(
        effective_dependencies,
        formula_ref=formula_ref,
        formula_refs=formula_refs,
    )
    implementation_ref = str(metadata.get("implementation_ref") or "")
    current_implementation_ref = _latest_implementation_ref(context, formula_ref)
    if not implementation_ref or implementation_ref != current_implementation_ref:
        raise ValueError(
            "materializer_publication_requires_current_implementation:"
            f"implementation_ref={implementation_ref}:"
            "current_implementation_ref="
            f"{current_implementation_ref or 'none'}:"
            f"bound_formula_ref={formula_ref}"
        )
    trace_refs = set(_string_sequence(arguments.get("trace_refs")))
    for ref in trace_refs:
        if (
            ref.startswith(("artifact:", "code_artifact:", "execution_observation:"))
            and ref not in allowed
        ):
            raise ValueError(
                "materializer_publication_trace_outside_current_lineage:"
                f"trace_ref={ref}:bound_formula_ref={formula_ref}"
            )
    if not str(arguments.get("summary") or "").strip():
        raise ValueError(
            "materializer_publication_summary_required:"
            "state_completion_status_record_coverage_and_unresolved_count"
        )


def _require_bound_formula_dependency(
    dependencies: Sequence[str],
    *,
    formula_ref: str,
    formula_refs: set[str],
) -> None:
    if formula_ref not in dependencies:
        raise ValueError(
            "materializer_exact_formula_dependency_required:"
            f"bound_formula_ref={formula_ref}"
        )
    unrelated = sorted(
        ref for ref in dependencies if ref in formula_refs and ref != formula_ref
    )
    if unrelated:
        raise ValueError(
            "materializer_unrelated_formula_dependency_rejected:"
            f"bound_formula_ref={formula_ref}:unrelated={unrelated}"
        )


def _bound_formula(context: Mapping[str, Any]) -> Mapping[str, Any] | None:
    artifacts = _artifact_map(context)
    for ref in reversed(_string_sequence(context.get("invocation_seed_refs"))):
        stored = artifacts.get(ref)
        if stored is not None and stored.get("artifact_kind") == _FORMULA_KIND:
            return stored
    resolved_formulas = [
        stored
        for stored in _mapping_sequence(context.get("resolved_artifacts"))
        if stored.get("artifact_kind") == _FORMULA_KIND
    ]
    if len(resolved_formulas) == 1:
        return resolved_formulas[0]
    return None


def _bound_protocol_only(
    context: Mapping[str, Any],
) -> Mapping[str, Any] | None:
    artifacts = _artifact_map(context)
    seeded = [
        artifacts[ref]
        for ref in _string_sequence(context.get("invocation_seed_refs"))
        if ref in artifacts and artifacts[ref].get("artifact_kind") == _PROTOCOL_KIND
    ]
    if len(seeded) == 1:
        return seeded[0]
    if len(seeded) > 1:
        return None
    outputs = [
        artifacts[ref]
        for ref in _string_sequence(context.get("invocation_output_refs"))
        if ref in artifacts and artifacts[ref].get("artifact_kind") == _PROTOCOL_KIND
    ]
    if len(outputs) == 1:
        return outputs[0]
    if len(outputs) > 1:
        return None
    resolved = [
        stored
        for stored in _mapping_sequence(context.get("resolved_artifacts"))
        if stored.get("artifact_kind") == _PROTOCOL_KIND
    ]
    if len(resolved) == 1:
        return resolved[0]
    return None


def _bound_specification_bundle_refs(
    context: Mapping[str, Any],
) -> tuple[str, ...]:
    """Return exact mounted inputs without assigning them scientific meaning."""
    artifacts = _artifact_map(context)
    refs = tuple(
        dict.fromkeys(
            ref
            for ref in _string_sequence(context.get("invocation_seed_refs"))
            if ref in artifacts
        )
    )
    if not refs:
        return ()
    if any(
        artifacts[ref].get("artifact_kind") in {_FORMULA_KIND, _PROTOCOL_KIND}
        for ref in refs
    ):
        return ()
    return refs


def _protocol_refs(context: Mapping[str, Any]) -> set[str]:
    refs = {
        _stored_ref(stored)
        for stored in _mapping_sequence(context.get("resolved_artifacts"))
        if stored.get("artifact_kind") == _PROTOCOL_KIND
    }
    refs.update(
        str(receipt.get("artifact_ref") or "")
        for receipt in _mapping_sequence(context.get("formal_artifact_index"))
        if receipt.get("artifact_kind") == _PROTOCOL_KIND
    )
    refs.discard("")
    return refs


def _specialist_assessment_refs(
    context: Mapping[str, Any],
) -> tuple[str, ...]:
    return tuple(
        dict.fromkeys(
            ref
            for stored in _mapping_sequence(context.get("resolved_artifacts"))
            if stored.get("artifact_kind") == "specialist_assessment"
            and (ref := _stored_ref(stored))
        )
    )


def _protocol_lineage_refs(
    context: Mapping[str, Any],
    protocol_ref: str,
) -> set[str]:
    if not protocol_ref:
        return set()
    artifacts = _artifact_map(context)
    lineage = {protocol_ref}
    changed = True
    while changed:
        changed = False
        for ref, stored in artifacts.items():
            if ref in lineage:
                continue
            kind = str(stored.get("artifact_kind") or "")
            dependencies = set(_string_sequence(stored.get("depends_on")))
            belongs = False
            if kind == "code_artifact":
                belongs = protocol_ref in dependencies or bool(dependencies & lineage)
            elif kind == _PROJECT_SNAPSHOT_KIND:
                project_dependencies = set(
                    _string_sequence(
                        _mapping(stored.get("machine_payload")).get("dependency_refs")
                    )
                )
                belongs = protocol_ref in project_dependencies or bool(
                    project_dependencies & lineage
                )
            elif kind == "execution_observation":
                metadata = _mapping(stored.get("metadata"))
                belongs = (
                    str(metadata.get("protocol_artifact_ref") or "") == protocol_ref
                    or str(metadata.get("implementation_ref") or "") in lineage
                )
            elif kind == _PROPERTY_RESULT_KIND:
                payload = _mapping(stored.get("machine_payload"))
                belongs = (
                    protocol_ref in dependencies
                    or bool(dependencies & lineage)
                    or str(payload.get("protocol_artifact_ref") or "") == protocol_ref
                )
            if belongs:
                lineage.add(ref)
                changed = True
    return lineage


def _latest_protocol_lineage_ref(
    context: Mapping[str, Any],
    protocol_ref: str,
    artifact_kind: str,
) -> str:
    artifacts = _artifact_map(context)
    lineage = _protocol_lineage_refs(context, protocol_ref)
    candidates = [
        ref
        for ref, stored in artifacts.items()
        if ref in lineage and stored.get("artifact_kind") == artifact_kind
    ]
    if not candidates:
        return ""
    if artifact_kind in {"code_artifact", _PROJECT_SNAPSHOT_KIND}:
        candidates = _current_implementation_candidates(context, candidates)
    elif artifact_kind == "execution_observation":
        current_implementation_ref = _latest_protocol_implementation_ref(
            context, protocol_ref
        )
        candidates = [
            ref
            for ref in candidates
            if str(
                _mapping(artifacts[ref].get("metadata")).get("implementation_ref") or ""
            )
            == current_implementation_ref
            and str(
                _mapping(artifacts[ref].get("metadata")).get("protocol_artifact_ref")
                or ""
            )
            == protocol_ref
            and artifacts[ref].get("status") == "code_artifact_executed"
        ]
        receipt_ref = _latest_observation_receipt_ref(context, candidates)
        if receipt_ref:
            return receipt_ref
    elif artifact_kind == _PROPERTY_RESULT_KIND:
        output_refs = [
            ref
            for ref in _string_sequence(context.get("invocation_output_refs"))
            if ref in candidates
        ]
        if output_refs:
            published = _latest_publication_receipt_ref(context, output_refs)
            if published:
                return published
            candidates = output_refs
    return _require_unique_lineage_tip(
        candidates,
        artifact_kind=artifact_kind,
        formula_ref=protocol_ref,
    )


def _protocol_stage(context: Mapping[str, Any], protocol_ref: str) -> str:
    artifacts = _artifact_map(context)
    if _latest_protocol_lineage_ref(
        context,
        protocol_ref,
        _PROPERTY_RESULT_KIND,
    ):
        return "completion"
    implementation_ref = _latest_protocol_implementation_ref(context, protocol_ref)
    observation_ref = _latest_protocol_lineage_ref(
        context,
        protocol_ref,
        "execution_observation",
    )
    observation = artifacts.get(observation_ref)
    if observation is not None and bool(observation.get("_inspected")):
        return "publication"
    if observation is not None:
        return "inspection"
    if implementation_ref:
        return "execution"
    return "implementation"


def _current_protocol_code_execution_failure(
    context: Mapping[str, Any],
    *,
    code_ref: str,
) -> str:
    if not code_ref:
        return ""
    marker = f"protocol_materializer_code_attempt_failed:code_artifact_ref={code_ref}:"
    for receipt in reversed(_mapping_sequence(context.get("recent_receipts"))):
        if str(receipt.get("tool") or "") != (
            "scientific_protocol_materializer_execute"
        ):
            continue
        result = _mapping(receipt.get("result"))
        if (
            str(result.get("status") or "")
            == "protocol_materializer_execution_complete"
            and str(result.get("code_artifact_ref") or "") == code_ref
        ):
            return ""
        reason = str(result.get("reason") or "")
        if str(result.get("status") or "") == "tool_error" and marker in reason:
            return reason
    return ""


def _formula_refs(context: Mapping[str, Any]) -> set[str]:
    refs = {
        _stored_ref(stored)
        for stored in _mapping_sequence(context.get("resolved_artifacts"))
        if stored.get("artifact_kind") == _FORMULA_KIND
    }
    refs.update(
        str(receipt.get("artifact_ref") or "")
        for receipt in _mapping_sequence(context.get("formal_artifact_index"))
        if receipt.get("artifact_kind") == _FORMULA_KIND
    )
    refs.discard("")
    return refs


def _lineage_refs(context: Mapping[str, Any], formula_ref: str) -> set[str]:
    if not formula_ref:
        return set()
    artifacts = _artifact_map(context)
    lineage = {formula_ref}
    changed = True
    while changed:
        changed = False
        for ref, stored in artifacts.items():
            if ref in lineage:
                continue
            kind = str(stored.get("artifact_kind") or "")
            dependencies = set(_string_sequence(stored.get("depends_on")))
            belongs = False
            if kind == "code_artifact":
                belongs = bool(dependencies & lineage)
            elif kind == _PROJECT_SNAPSHOT_KIND:
                project_dependencies = set(
                    _string_sequence(
                        _mapping(stored.get("machine_payload")).get("dependency_refs")
                    )
                )
                belongs = bool(project_dependencies & lineage)
            elif kind == "execution_observation":
                metadata = _mapping(stored.get("metadata"))
                belongs = (
                    str(metadata.get("formula_artifact_ref") or "") == formula_ref
                    or str(metadata.get("implementation_ref") or "") in lineage
                )
            elif kind == _MATERIALIZATION_KIND:
                belongs = formula_ref in dependencies or bool(dependencies & lineage)
            if belongs:
                lineage.add(ref)
                changed = True
    return lineage


def _latest_lineage_ref(
    context: Mapping[str, Any],
    formula_ref: str,
    artifact_kind: str,
) -> str:
    artifacts = _artifact_map(context)
    lineage = _lineage_refs(context, formula_ref)
    candidates = [
        ref
        for ref, stored in artifacts.items()
        if ref in lineage and stored.get("artifact_kind") == artifact_kind
    ]
    if not candidates:
        return ""

    if artifact_kind in {"code_artifact", _PROJECT_SNAPSHOT_KIND}:
        return _require_unique_lineage_tip(
            _current_implementation_candidates(context, candidates),
            artifact_kind=artifact_kind,
            formula_ref=formula_ref,
        )

    if artifact_kind == "execution_observation":
        current_implementation_ref = _latest_implementation_ref(context, formula_ref)
        candidates = [
            ref
            for ref in candidates
            if (
                str(
                    _mapping(artifacts[ref].get("metadata")).get("implementation_ref")
                    or ""
                )
                == current_implementation_ref
                and str(
                    _mapping(artifacts[ref].get("metadata")).get("formula_artifact_ref")
                    or ""
                )
                == formula_ref
                and artifacts[ref].get("status") == "code_artifact_executed"
            )
        ]
        receipt_ref = _latest_observation_receipt_ref(context, candidates)
        if receipt_ref:
            return receipt_ref

    if artifact_kind == _MATERIALIZATION_KIND:
        output_refs = [
            ref
            for ref in _string_sequence(context.get("invocation_output_refs"))
            if ref in candidates
        ]
        if output_refs:
            published = _latest_publication_receipt_ref(context, output_refs)
            if published:
                return published
            return _require_unique_lineage_tip(
                output_refs,
                artifact_kind=artifact_kind,
                formula_ref=formula_ref,
            )

    return _require_unique_lineage_tip(
        candidates,
        artifact_kind=artifact_kind,
        formula_ref=formula_ref,
    )


def _latest_observation_receipt_ref(
    context: Mapping[str, Any],
    candidates: Sequence[str],
) -> str:
    candidate_set = set(candidates)
    for receipt in reversed(_mapping_sequence(context.get("recent_receipts"))):
        if str(receipt.get("tool") or "") not in {
            "scientific_materializer_execute",
            "scientific_protocol_materializer_execute",
            "scientific_materializer_run_project",
            "scientific_observation_inspect",
        }:
            continue
        result = _mapping(receipt.get("result"))
        ref = str(result.get("observation_ref") or "")
        if ref in candidate_set:
            return ref
    return ""


def _latest_implementation_ref(
    context: Mapping[str, Any],
    formula_ref: str,
) -> str:
    return _latest_implementation_tip(
        context,
        lineage=_lineage_refs(context, formula_ref),
        owner_ref=formula_ref,
    )


def _latest_protocol_implementation_ref(
    context: Mapping[str, Any],
    protocol_ref: str,
) -> str:
    return _latest_implementation_tip(
        context,
        lineage=_protocol_lineage_refs(context, protocol_ref),
        owner_ref=protocol_ref,
    )


def _latest_implementation_tip(
    context: Mapping[str, Any],
    *,
    lineage: set[str],
    owner_ref: str,
) -> str:
    artifacts = _artifact_map(context)
    candidates = [
        ref
        for ref, stored in artifacts.items()
        if ref in lineage
        and stored.get("artifact_kind") in {"code_artifact", _PROJECT_SNAPSHOT_KIND}
    ]
    return _require_unique_lineage_tip(
        _current_implementation_candidates(context, candidates),
        artifact_kind="implementation",
        formula_ref=owner_ref,
    )


def _current_implementation_candidates(
    context: Mapping[str, Any], candidates: Sequence[str],
) -> list[str]:
    artifacts = _artifact_map(context)
    candidate_set = set(candidates)
    superseded = {
        dependency
        for ref in candidates
        for dependency in _implementation_dependencies(artifacts[ref])
        if dependency in candidate_set
    }
    # Runtime resolves snapshot ancestry against storage, not the partial
    # prompt. Keep historical bodies available for execution-workspace recovery.
    if "current_project_snapshot_refs" in context:
        current = set(_string_sequence(context["current_project_snapshot_refs"]))
        superseded.update(
            ref for ref in candidates
            if artifacts[ref].get("artifact_kind") == _PROJECT_SNAPSHOT_KIND
            and ref not in current
        )
    return [ref for ref in candidates if ref not in superseded]


def _implementation_dependencies(
    stored: Mapping[str, Any],
) -> tuple[str, ...]:
    dependencies = list(_string_sequence(stored.get("depends_on")))
    if stored.get("artifact_kind") == _PROJECT_SNAPSHOT_KIND:
        for ref in _string_sequence(
            _mapping(stored.get("machine_payload")).get("dependency_refs")
        ):
            _append_unique(dependencies, ref)
    return tuple(dependencies)


def _latest_project_snapshot_receipt_ref(
    context: Mapping[str, Any],
) -> str:
    for receipt in reversed(_mapping_sequence(context.get("recent_receipts"))):
        if str(receipt.get("tool") or "") != "development_project_checkpoint":
            continue
        result = _mapping(receipt.get("result"))
        if result.get("status") != "development_project_checkpoint_created":
            continue
        ref = str(result.get("snapshot_ref") or "")
        if ref.startswith("artifact:"):
            return ref
    return ""


def _current_project_execution_failure(
    context: Mapping[str, Any],
    *,
    implementation_ref: str,
) -> str:
    current = _current_project_execution_observation(context, implementation_ref)
    if current.get("status") == "tool_error":
        return str(_mapping(current.get("result")).get("reason") or "")
    return ""


def _current_project_execution_observation(
    context: Mapping[str, Any], implementation_ref: str,
) -> Mapping[str, Any]:
    # Common supplies exact visible observations in immutable creation order.
    for stored in reversed(_mapping_sequence(context.get("resolved_artifacts"))):
        if stored.get("artifact_kind") != "execution_observation":
            continue
        if stored.get("namespace") not in {
            "materializer-project", "materializer-protocol-project",
        }:
            continue
        if _mapping(stored.get("metadata")).get("implementation_ref") == implementation_ref:
            return stored
    return {}


def _current_project_execution_interruption(
    context: Mapping[str, Any],
    *,
    implementation_ref: str,
) -> Mapping[str, Any]:
    current = _current_project_execution_observation(context, implementation_ref)
    if current.get("status") == "materializer_project_execution_interrupted":
        return _mapping(current.get("result"))
    return {}


def _execution_inventory_after_interruption(
    context: Mapping[str, Any],
    *,
    implementation_ref: str,
    workspace_ref: str,
) -> Mapping[str, Any]:
    execution = _current_project_execution_observation(context, implementation_ref)
    if execution.get("status") != "materializer_project_execution_interrupted":
        return {}
    return _execution_inventory_for_observation(context, workspace_ref, execution)


def _execution_inventory_for_observation(
    context: Mapping[str, Any], workspace_ref: str, execution: Mapping[str, Any],
) -> Mapping[str, Any]:
    for stored in reversed(_mapping_sequence(context.get("resolved_artifacts"))):
        if stored.get("namespace") != "materializer-execution-inventory":
            continue
        result = _mapping(stored.get("result"))
        if (
            result.get("status")
            == "materializer_execution_workspace_inventory_ready"
            and result.get("execution_workspace_ref") == workspace_ref
            and result.get("execution_observation_ref") == execution.get("observation_ref")
        ):
            return result
    return {}


def _readable_project_executions(
    context: Mapping[str, Any], implementation_ref: str,
) -> dict[str, Mapping[str, Any]]:
    artifacts = _artifact_map(context)
    implementation = _mapping(artifacts.get(implementation_ref))
    project_id = _mapping(implementation.get("machine_payload")).get("project_id")
    if not project_id:
        return {}
    retained = {}
    seen = set()
    for stored in reversed(_mapping_sequence(context.get("resolved_artifacts"))):
        if stored.get("namespace") not in {"materializer-project", "materializer-protocol-project"}:
            continue
        metadata = _mapping(stored.get("metadata"))
        snapshot_ref = str(metadata.get("implementation_ref") or "")
        snapshot = _mapping(artifacts.get(snapshot_ref))
        if _mapping(snapshot.get("machine_payload")).get("project_id") != project_id:
            continue
        workspace_ref = str(_mapping(stored.get("result")).get("execution_workspace_ref") or "")
        if not workspace_ref and metadata.get("execution_workspace"):
            name = str(metadata["execution_workspace"]).replace("\\", "/").rstrip("/").rsplit("/", 1)[-1]
            workspace_ref = "materializer_execution_workspace:" + name
        if not workspace_ref or workspace_ref in seen:
            continue
        seen.add(workspace_ref)
        retained[workspace_ref] = stored
    return retained


def _retained_project_executions(
    context: Mapping[str, Any], implementation_ref: str,
) -> dict[str, Mapping[str, Any]]:
    """Keep resume eligibility separate from read-only evidence visibility."""
    return {
        ref: stored
        for ref, stored in _readable_project_executions(context, implementation_ref).items()
        if _current_project_execution_observation(
            context, str(_mapping(stored.get("metadata")).get("implementation_ref") or ""),
        ).get("status") in {"materializer_project_execution_interrupted", "tool_error"}
    }


def _validate_resume_from(
    arguments: Mapping[str, Any], context: Mapping[str, Any], implementation_ref: str,
) -> None:
    resume = arguments.get("resume_from")
    if not isinstance(resume, Mapping):
        return
    requested_ref = str(resume.get("execution_workspace_ref") or "")
    retained = _retained_project_executions(context, implementation_ref)
    if requested_ref not in retained:
        raise ValueError(
            "materializer_execution_workspace_not_resumable:"
            f"requested={requested_ref}:available={list(retained)}"
        )
    for relative in _string_sequence(resume.get("relative_paths")):
        _validate_execution_workspace_tool_call(
            "development_project_read",
            {"execution_workspace_ref": resume.get("execution_workspace_ref"), "path": relative},
            context, implementation_ref=implementation_ref,
        )


def _validate_execution_workspace_tool_call(
    tool_name: str,
    arguments: Mapping[str, Any],
    context: Mapping[str, Any],
    *,
    implementation_ref: str,
) -> None:
    requested_ref = str(arguments.get("execution_workspace_ref") or "")
    retained = _readable_project_executions(context, implementation_ref)
    execution = retained.get(requested_ref)
    if execution is None:
        raise ValueError(
            "materializer_execution_workspace_outside_visible_project:"
            f"requested={requested_ref}:available={list(retained)}"
        )
    if tool_name != "development_project_read":
        return
    inventory = _execution_inventory_for_observation(context, requested_ref, execution)
    if not inventory:
        raise ValueError(
            "materializer_execution_inventory_required_before_read:"
            f"execution_workspace_ref={requested_ref}"
        )
    requested_path = str(arguments.get("path") or "")
    inventory_entries, _sample_only = _inventory_entries(inventory)
    listed_paths = {
        str(item.get("path") or "") for item in inventory_entries
    }
    if requested_path not in listed_paths:
        raise ValueError(
            "materializer_execution_read_requires_inventory_path:"
            f"requested={requested_path}"
        )


def _require_execution_inventory_before_resume(
    context: Mapping[str, Any],
    *,
    implementation_ref: str,
) -> None:
    interruption = _current_project_execution_interruption(
        context,
        implementation_ref=implementation_ref,
    )
    if not interruption:
        return
    workspace_ref = str(interruption.get("execution_workspace_ref") or "")
    if _execution_inventory_after_interruption(
        context,
        implementation_ref=implementation_ref,
        workspace_ref=workspace_ref,
    ):
        return
    raise ValueError(
        "materializer_execution_inventory_required_before_resume:"
        f"execution_workspace_ref={workspace_ref}"
    )


def _route_revision_evidence_available(context: Mapping[str, Any]) -> bool:
    """Reveal Route authoring only after an exact managed Route path has failed."""
    route_refs = {
        str(item.get("route_ref") or "").strip()
        for item in _managed_code_route_summaries(context)
        if str(item.get("route_ref") or "").strip()
    }
    route_names = {
        route_ref.split(":", 2)[1]
        for route_ref in route_refs
        if route_ref.startswith(("approved_route:", "pending_route:"))
        and route_ref.count(":") >= 2
    }
    for receipt in reversed(_mapping_sequence(context.get("recent_receipts"))):
        tool = str(receipt.get("tool") or "")
        result = _mapping(receipt.get("result"))
        if tool in route_names and result.get("status") == "tool_error":
            return True

    for artifact in _artifact_map(context).values():
        if artifact.get("artifact_kind") != _PROJECT_SNAPSHOT_KIND:
            continue
        implementation_ref = _stored_ref(artifact)
        if not implementation_ref:
            continue
        if not route_refs.intersection(_implementation_dependencies(artifact)):
            continue
        if _current_project_execution_failure(
            context,
            implementation_ref=implementation_ref,
        ):
            return True
    return False


def _legacy_code_lineage_available(context: Mapping[str, Any]) -> bool:
    """Keep old single-file implementations repairable without creating new ones."""
    formula = _bound_formula(context)
    implementation_ref = ""
    if formula is not None:
        implementation_ref = _latest_implementation_ref(
            context,
            _stored_ref(formula),
        )
    else:
        protocol = _bound_protocol_only(context)
        if protocol is not None:
            implementation_ref = _latest_protocol_implementation_ref(
                context,
                _stored_ref(protocol),
            )
    if not implementation_ref:
        return False
    implementation = _artifact_map(context).get(implementation_ref)
    return bool(
        implementation is not None
        and implementation.get("artifact_kind") == "code_artifact"
    )


def _current_code_execution_failure(
    context: Mapping[str, Any],
    *,
    code_ref: str,
) -> str:
    """Return the unresolved execution error for the current code revision."""
    if not code_ref:
        return ""
    failure_marker = f"materializer_code_attempt_failed:code_artifact_ref={code_ref}:"
    for receipt in reversed(_mapping_sequence(context.get("recent_receipts"))):
        if str(receipt.get("tool") or "") != "scientific_materializer_execute":
            continue
        result = _mapping(receipt.get("result"))
        status = str(result.get("status") or "")
        if (
            status == "materializer_execution_complete"
            and str(result.get("code_artifact_ref") or "") == code_ref
        ):
            return ""
        reason = str(result.get("reason") or "")
        if status == "tool_error" and failure_marker in reason:
            return reason
    return ""


def _latest_publication_receipt_ref(context: Mapping[str, Any], candidates: Sequence[str]) -> str:
    """An account correction is identified by its completed publish receipt."""
    allowed = set(candidates)
    for receipt in reversed(_mapping_sequence(context.get("recent_receipts"))):
        if receipt.get("tool") != "artifact_publish":
            continue
        ref = str(_mapping(receipt.get("result")).get("artifact_ref") or "")
        if ref in allowed:
            return ref
    return ""


def _require_unique_lineage_tip(
    refs: Sequence[str],
    *,
    artifact_kind: str,
    formula_ref: str,
) -> str:
    unique = list(dict.fromkeys(str(ref) for ref in refs if str(ref)))
    if not unique:
        return ""
    if len(unique) != 1:
        raise ValueError(
            "materializer_current_lineage_ambiguous:"
            f"artifact_kind={artifact_kind}:"
            f"formula_ref={formula_ref}:refs={unique}"
        )
    return unique[0]


def _has_execution_input_declaration(payload: Mapping[str, Any]) -> bool:
    try:
        validate_execution_input_paths(payload.get("execution_input_paths"))
    except ValueError:
        return False
    return True


def _stage(context: Mapping[str, Any], formula_ref: str) -> str:
    artifacts = _artifact_map(context)
    materialization_ref = _latest_lineage_ref(context, formula_ref, _MATERIALIZATION_KIND)
    if materialization_ref:
        materialization = _mapping(artifacts.get(materialization_ref))
        if _has_execution_input_declaration(_mapping(materialization.get("machine_payload"))):
            return "completion"
    current_implementation_ref = _latest_implementation_ref(context, formula_ref)
    current_observation_ref = _latest_lineage_ref(
        context,
        formula_ref,
        "execution_observation",
    )
    current_observation = artifacts.get(current_observation_ref)
    if current_observation is not None and not _has_execution_input_declaration(
        _mapping(current_observation.get("result"))
    ):
        return "implementation"
    if current_observation is not None and bool(current_observation.get("_inspected")):
        return "publication"
    if current_observation is not None:
        return "inspection"
    if current_implementation_ref:
        return "execution"
    # Opening a project already passed the source-observation precondition.
    # Do not regress when its earlier C4 read receipts leave the bounded window.
    if _project_progress(context)["project_id"]:
        return "implementation"
    protocols = _bound_protocols(context, formula_ref)
    if not _source_observation_required(
        context, protocols
    ) or _minimum_source_observation_available(context):
        return "implementation"
    return "source-observation"


def _project_progress(context: Mapping[str, Any]) -> dict[str, Any]:
    """Derive the mutable project lifecycle from receipts and stored snapshots."""
    receipts = _mapping_sequence(context.get("recent_receipts"))
    current_snapshot_ref = ""
    formula = _bound_formula(context)
    if formula is not None:
        current_snapshot_ref = _latest_implementation_ref(
            context,
            _stored_ref(formula),
        )
    else:
        protocol = _bound_protocol_only(context)
        if protocol is not None:
            current_snapshot_ref = _latest_protocol_implementation_ref(
                context,
                _stored_ref(protocol),
            )
    candidate_snapshot = _mapping(_artifact_map(context).get(current_snapshot_ref))
    project_id = ""
    environment_ref = ""
    if candidate_snapshot.get("artifact_kind") == _PROJECT_SNAPSHOT_KIND:
        snapshot_payload = _mapping(candidate_snapshot.get("machine_payload"))
        project_id = str(snapshot_payload.get("project_id") or "")
        environment_ref = str(snapshot_payload.get("environment_ref") or "")

    if not project_id:
        for receipt in reversed(receipts):
            tool = str(receipt.get("tool") or "")
            if not tool.startswith("development_project_"):
                continue
            result = _mapping(receipt.get("result"))
            candidate_id = str(result.get("project_id") or "")
            if not candidate_id:
                continue
            project_id = candidate_id
            break

    revision = 0
    open_index = -1
    if project_id:
        matching_indexes: list[int] = []
        for index, receipt in enumerate(receipts):
            result = _mapping(receipt.get("result"))
            if str(result.get("project_id") or "") != project_id:
                continue
            matching_indexes.append(index)
            if str(receipt.get("tool") or "") not in {
                "development_project_open",
                "development_project_configure",
            }:
                continue
            if str(result.get("status") or "") != "development_project_ready":
                continue
            environment_ref = str(result.get("environment_ref") or "")
            candidate_revision = result.get("revision")
            if isinstance(candidate_revision, int) and not isinstance(
                candidate_revision, bool
            ):
                revision = max(revision, candidate_revision)
        if matching_indexes:
            open_index = matching_indexes[0]

    snapshot_stale = False
    snapshot_changed_paths: tuple[str, ...] = ()
    if current_snapshot_ref:
        for receipt in reversed(receipts):
            if str(receipt.get("tool") or "") != "development_project_diff":
                continue
            result = _mapping(receipt.get("result"))
            if str(result.get("status") or "") != "development_project_diff_ready":
                continue
            if str(result.get("snapshot_ref") or "") != current_snapshot_ref:
                continue
            result_project_id = str(result.get("project_id") or "")
            if result_project_id and project_id and result_project_id != project_id:
                continue
            snapshot_changed_paths = _string_sequence(result.get("changed_paths"))
            snapshot_stale = bool(snapshot_changed_paths)
            break

    latest_mutation_index = -1
    latest_validation_index = -1
    latest_validation_status = ""
    bound_route_refs: tuple[str, ...] = ()
    pending_snapshot_ref = ""
    code_queries: list[tuple[int, str]] = []
    terminal_diagnostics: list[tuple[int, str]] = []
    for index, receipt in enumerate(receipts):
        if index < open_index:
            continue
        result = _mapping(receipt.get("result"))
        result_project_id = str(result.get("project_id") or "")
        status = str(result.get("status") or "")
        if result_project_id and project_id and result_project_id != project_id:
            continue
        candidate_revision = result.get("revision")
        if isinstance(candidate_revision, int) and not isinstance(
            candidate_revision, bool
        ):
            revision = max(revision, candidate_revision)
        if status in _PROJECT_MUTATION_STATUSES:
            latest_mutation_index = index
        if status in {"development_syntax_passed", "development_syntax_failed"}:
            latest_validation_index = index
            latest_validation_status = status
        if status in {
            "development_code_query_ready",
            "development_code_query_unsupported",
        }:
            path = str(result.get("path") or "project")
            kind = str(result.get("query_kind") or "structure")
            code_queries.append((index, f"{path}:{kind}"))
        if (
            str(receipt.get("tool") or "")
            == "development_project_terminal_start"
            and status == "development_terminal_succeeded"
        ):
            purpose = str(
                receipt.get("purpose") or result.get("purpose") or ""
            ).strip()
            if purpose:
                terminal_diagnostics.append((index, purpose))
        if (
            str(receipt.get("tool") or "")
            == "development_project_bind_managed_routes"
            and status == "managed_route_broker_ready"
        ):
            bound_route_refs = _string_sequence(result.get("route_refs"))
        if status == "development_project_checkpoint_created":
            snapshot_ref = str(result.get("snapshot_ref") or "")
            if snapshot_ref.startswith("artifact:"):
                pending_snapshot_ref = snapshot_ref

    if pending_snapshot_ref in _artifact_map(context):
        pending_snapshot_ref = ""
    return {
        "project_id": project_id,
        "environment_ref": environment_ref,
        "revision": revision,
        "syntax_current": (
            latest_validation_status == "development_syntax_passed"
            and latest_validation_index >= latest_mutation_index
        ),
        "bound_route_refs": bound_route_refs,
        "completed_code_queries": tuple(
            label
            for index, label in code_queries
            if index >= latest_mutation_index
        ),
        "completed_terminal_diagnostics": tuple(
            purpose
            for index, purpose in terminal_diagnostics
            if index >= latest_mutation_index
        ),
        "pending_snapshot_ref": pending_snapshot_ref,
        "current_snapshot_ref": current_snapshot_ref,
        "snapshot_stale": snapshot_stale,
        "snapshot_changed_paths": snapshot_changed_paths,
    }


def _development_output_refs(context: Mapping[str, Any]) -> tuple[str, ...]:
    """Return exact readable outputs emitted by the active mutable project."""
    project_id = str(_project_progress(context).get("project_id") or "")
    if not project_id:
        return ()
    prefix = f"development_output:{project_id}:"
    refs: list[str] = []
    for receipt in _mapping_sequence(context.get("recent_receipts")):
        result = _mapping(receipt.get("result"))
        if str(result.get("project_id") or "") != project_id:
            continue
        for key in ("stdout_ref", "stderr_ref", "diff_ref"):
            ref = str(result.get(key) or "").strip()
            if ref.startswith(prefix):
                _append_unique(refs, ref)
    return tuple(refs)


def _project_validation_progress_lines(
    progress: Mapping[str, Any],
) -> tuple[str, ...]:
    lines: list[str] = []
    if bool(progress.get("snapshot_stale")):
        changed_paths = _string_sequence(progress.get("snapshot_changed_paths"))
        lines.append(
            "- current immutable snapshot is stale relative to mutable project "
            "revision; formal execution of that snapshot is forbidden"
        )
        if changed_paths:
            lines.append(
                "- mutable paths changed after that checkpoint: "
                + ", ".join(f"`{path}`" for path in changed_paths)
            )
        lines.append(
            "  Validate the current mutable revision, then create and read back "
            "a new immutable checkpoint before formal execution."
        )
    if bool(progress.get("syntax_current")):
        lines.append(
            "- current-revision syntax validation: `passed`; do not repeat "
            "the same syntax check unless the project revision changes"
        )
    queries = _string_sequence(progress.get("completed_code_queries"))
    if queries:
        lines.append(
            "- current-revision completed structure checks: "
            + ", ".join(f"`{item}`" for item in queries)
        )
        lines.append(
            "  Do not repeat an identical structure check while the project "
            "revision is unchanged. Perform only a different check tied to one "
            "remaining implementation risk, or checkpoint the current project."
        )
    diagnostics = _string_sequence(
        progress.get("completed_terminal_diagnostics")
    )
    if diagnostics:
        lines.append(
            "- current-revision completed terminal diagnostics: "
            + ", ".join(f"`{item}`" for item in diagnostics)
        )
        lines.append(
            "  Do not repeat an identical terminal diagnostic while the project "
            "revision is unchanged. Use it as completed operational evidence."
        )
    return tuple(lines)


def _project_operation_stage(context: Mapping[str, Any]) -> str:
    progress = _project_progress(context)
    if not progress["project_id"]:
        return "project-setup"
    if progress["pending_snapshot_ref"]:
        return "checkpoint-readback"
    # A mutable project may need one file or many. Only checkpointing marks the
    # end of project work; the presence of an arbitrary first file does not.
    return "project-authoring"


def _project_operation_page(context: Mapping[str, Any]) -> str:
    return {
        "project-setup": "project-setup-stage.md",
        "project-authoring": "project-authoring-stage.md",
        "checkpoint-readback": "project-checkpoint-readback-stage.md",
    }[_project_operation_stage(context)]


def _managed_route_projection(
    context: Mapping[str, Any],
    *,
    implementation_stage: str,
) -> tuple[str, ...]:
    routes = _managed_code_route_summaries(context)
    if not routes:
        return ()
    progress = _project_progress(context)
    operation_stage = _project_operation_stage(context)
    bound_refs = set(_string_sequence(progress.get("bound_route_refs")))
    lines: list[str] = []
    if implementation_stage != "implementation":
        refs = sorted(
            bound_refs
            or {
                ref
                for ref in _implementation_dependencies(
                    _mapping(
                        _artifact_map(context).get(
                            str(progress.get("current_snapshot_ref") or "")
                        )
                    )
                )
                if ref.startswith(("approved_route:", "pending_route:"))
            }
        )
        if refs:
            lines.append("- managed Routes bound to the current implementation:")
            lines.extend(f"  - `{ref}`" for ref in refs)
        return tuple(lines)

    if operation_stage == "project-setup":
        lines.extend(
            (
                "- optional managed Routes available for explicit broker calls:",
                "  Runtime has already assigned the fixed project environment. "
                "These Routes are optional callable APIs, not alternative "
                "environments; do not select one merely because it exists.",
            )
        )
        selected_routes = routes
        include_schema = False
    elif bound_refs:
        lines.extend(
            (
                "- exact managed Route contracts bound to this project:",
                "  Generated code calls them through the injected JSON command "
                "prefix. Only these bound contracts are callable.",
            )
        )
        selected_routes = tuple(
            route
            for route in routes
            if str(route.get("route_ref") or "") in bound_refs
        )
        include_schema = True
    else:
        lines.extend(
            (
                "- optional managed Routes not yet bound to this project:",
                "  Choose exact Route refs from these summaries. Bind a Route "
                "before writing code that invokes it; after binding, its exact "
                "input and output schemas will be disclosed.",
            )
        )
        selected_routes = routes
        include_schema = False

    for route in selected_routes:
        route_ref = str(route.get("route_ref") or "")
        candidate_ref = str(route.get("candidate_artifact_ref") or "")
        description = (
            f"  - `{route_ref}` | complexity "
            f"`{route.get('estimated_complexity')}` | {route.get('description')}"
        )
        if candidate_ref:
            description += f" | pending candidate artifact `{candidate_ref}`"
        if include_schema:
            description += (
                " | input schema `"
                + repr(route.get("input_schema"))
                + "` | output schema `"
                + repr(route.get("output_schema"))
                + "`"
            )
        lines.append(description)
    return tuple(lines)


def _source_observation_required(
    context: Mapping[str, Any],
    protocols: Sequence[Mapping[str, Any]],
) -> bool:
    """Require files unless Protocol inputs are exact mounted artifacts."""
    if not protocols:
        return True

    available_ids: set[str] = set()
    for artifact in _mapping_sequence(context.get("resolved_artifacts")):
        ref = _stored_ref(artifact)
        if ref:
            available_ids.add(ref)
        payload = _mapping(artifact.get("machine_payload"))
        for key in (
            "id",
            "formula_id",
            "quantity_id",
            "candidate_id",
        ):
            value = str(payload.get(key) or "").strip()
            if value:
                available_ids.add(value)

    for protocol in protocols:
        payload = _mapping(protocol.get("machine_payload"))
        for required_input in _mapping_sequence(payload.get("required_inputs")):
            input_id = str(required_input.get("input_id") or "").strip()
            if not input_id or input_id not in available_ids:
                return True
    return False


def _minimum_source_observation_available(context: Mapping[str, Any]) -> bool:
    prepared_refs = set(_prepared_source_content_refs(context))
    if prepared_refs & _fully_read_prepared_source_refs(context):
        return True
    if _fully_read_source_refs(context):
        return True
    probe = _latest_source_probe(context)
    return (
        probe is not None
        and _probe_has_output(probe[1])
        and _probe_stdout_was_read(context, probe)
    )


def _latest_source_probe(
    context: Mapping[str, Any],
) -> tuple[int, Mapping[str, Any]] | None:
    receipts = _mapping_sequence(context.get("recent_receipts"))
    for index in range(len(receipts) - 1, -1, -1):
        receipt = receipts[index]
        if str(receipt.get("tool") or "") != "source_probe":
            continue
        result = _mapping(receipt.get("result"))
        if (
            str(result.get("status") or "") not in _EXECUTED_SOURCE_PROBE_STATUSES
            or not str(result.get("code_ref") or "").strip()
        ):
            continue
        return index, result
    return None


def _compact_probe_error(value: Any, *, limit: int = 800) -> str:
    compact = " ".join(str(value or "").replace("`", "'").split())
    return compact if len(compact) <= limit else "..." + compact[-(limit - 3) :]


def _compact_probe_observation(value: Any, *, limit: int = 2400) -> str:
    compact = " ".join(str(value or "").replace("`", "'").split())
    if len(compact) <= limit:
        return compact
    tail_length = min(500, limit // 4)
    head_length = limit - tail_length - 5
    return compact[:head_length] + " ... " + compact[-tail_length:]


def _probe_has_output(result: Mapping[str, Any]) -> bool:
    return (
        str(result.get("status") or "") == "source_probe_succeeded"
        and bool(str(result.get("stdout_ref") or "").strip())
        and bool(str(result.get("stdout_preview") or "").strip())
    )


def _probe_stdout_was_read(
    context: Mapping[str, Any],
    probe: tuple[int, Mapping[str, Any]],
) -> bool:
    return _probe_ref_was_read(
        context,
        probe,
        str(probe[1].get("stdout_ref") or ""),
    )


def _probe_ref_was_read(
    context: Mapping[str, Any],
    probe: tuple[int, Mapping[str, Any]],
    expected_ref: str,
) -> bool:
    probe_index, _ = probe
    if not expected_ref:
        return False
    receipts = _mapping_sequence(context.get("recent_receipts"))
    for receipt in receipts[probe_index + 1 :]:
        if str(receipt.get("tool") or "") not in {"read_ref", "source_read"}:
            continue
        result = _mapping(receipt.get("result"))
        if (
            str(result.get("status") or "") == "source_page_ready"
            and str(result.get("source_ref") or "") == expected_ref
        ):
            return True
    return False


def _source_observation_page(
    context: Mapping[str, Any],
    probe: tuple[int, Mapping[str, Any]] | None,
) -> str:
    focus = _source_observation_focus(context, probe)
    if focus == "repair":
        return "source-probe-repair-stage.md"
    if focus == "diagnosis":
        return "source-probe-diagnosis-stage.md"
    if focus == "readback":
        return "source-probe-readback-stage.md"
    if focus == "probe":
        return "source-probe-construction-stage.md"
    if focus == "reading":
        return "source-reading-stage.md"
    return "source-inventory-stage.md"


def _source_observation_focus(
    context: Mapping[str, Any],
    probe: tuple[int, Mapping[str, Any]] | None,
) -> str:
    if probe is None:
        prepared_refs = set(_prepared_source_content_refs(context))
        if prepared_refs:
            return (
                "observed"
                if prepared_refs & _fully_read_prepared_source_refs(context)
                else "reading"
            )
        inventory = _latest_source_inventory(context)
        if inventory is None:
            return "inventory"
        required_reads = min(2, max(1, _inventory_entry_count(inventory)))
        if len(_read_source_refs(context)) >= required_reads:
            return "probe"
        return "reading"
    result = probe[1]
    status = str(result.get("status") or "")
    if status == "source_probe_succeeded" and _probe_has_output(result):
        return "observed" if _probe_stdout_was_read(context, probe) else "readback"
    if status not in {"source_probe_failed", "source_probe_timed_out"}:
        return "probe"
    code_read = _probe_ref_was_read(
        context,
        probe,
        str(result.get("code_ref") or ""),
    )
    error_read = _probe_ref_was_read(
        context,
        probe,
        str(result.get("stderr_ref") or ""),
    )
    return "repair" if code_read and error_read else "diagnosis"


def _validate_preprobe_source_call(
    tool_name: str,
    arguments: Mapping[str, Any],
    context: Mapping[str, Any],
    *,
    formula_ref: str,
) -> None:
    if tool_name not in {"read_ref", "source_read", "artifact_read"}:
        return
    requested_ref = str(
        arguments.get("ref")
        or arguments.get("source_ref")
        or arguments.get("artifact_ref")
        or ""
    )
    if not requested_ref.startswith("source_file:"):
        return
    requested_offset = int(arguments.get("line_offset") or 0)
    for receipt in _mapping_sequence(context.get("recent_receipts")):
        if str(receipt.get("tool") or "") not in {"read_ref", "source_read"}:
            continue
        result = _mapping(receipt.get("result"))
        if (
            str(result.get("status") or "") != "source_page_ready"
            or str(result.get("source_ref") or "") != requested_ref
        ):
            continue
        previous_offset = int(result.get("line_offset") or 0)
        if requested_offset < previous_offset:
            continue
        next_offset = result.get("next_line_offset")
        read_to_end = next_offset in (None, "")
        if not read_to_end and requested_offset >= int(next_offset):
            continue
        suffix = (
            ":source_already_read_to_end"
            if read_to_end
            else f":covered_range={previous_offset}:{next_offset}"
        )
        raise ValueError(
            "materializer_source_page_already_read:"
            f"source_ref={requested_ref}:line_offset={requested_offset}{suffix}"
        )


def _latest_source_inventory(
    context: Mapping[str, Any],
) -> Mapping[str, Any] | None:
    for receipt in reversed(_mapping_sequence(context.get("recent_receipts"))):
        if str(receipt.get("tool") or "") != "source_inventory":
            continue
        result = _mapping(receipt.get("result"))
        if str(result.get("status") or "") == "source_inventory_ready":
            return result
    return None


def _bound_protocols(
    context: Mapping[str, Any], formula_ref: str
) -> tuple[Mapping[str, Any], ...]:
    if not formula_ref:
        return ()
    artifacts = _artifact_map(context)
    bound: list[Mapping[str, Any]] = []
    seen_quantities: set[str] = set()
    for ref in _string_sequence(context.get("invocation_seed_refs")):
        stored = artifacts.get(ref)
        if (
            stored is None
            or stored.get("artifact_kind") != _PROTOCOL_KIND
            or formula_ref not in _string_sequence(stored.get("depends_on"))
        ):
            continue
        quantity_id = str(
            _mapping(stored.get("machine_payload")).get("quantity_id") or ""
        )
        validate_computational_property_protocol(stored.get("machine_payload"))
        if not quantity_id:
            raise ValueError(f"materializer_protocol_quantity_id_required:{ref}")
        if quantity_id in seen_quantities:
            raise ValueError(
                f"materializer_protocol_quantity_ambiguous:quantity_id={quantity_id}"
            )
        seen_quantities.add(quantity_id)
        bound.append(stored)
    return tuple(bound)


def _probe_postdates_inspection(
    context: Mapping[str, Any],
    probe: tuple[int, Mapping[str, Any]] | None,
) -> bool:
    if probe is None:
        return False
    latest_inspection_index = -1
    for index, receipt in enumerate(_mapping_sequence(context.get("recent_receipts"))):
        if str(receipt.get("tool") or "") == "scientific_observation_inspect":
            latest_inspection_index = index
    return latest_inspection_index >= 0 and probe[0] > latest_inspection_index


def _latest_tool_result(
    context: Mapping[str, Any], tool_name: str
) -> Mapping[str, Any]:
    for receipt in reversed(_mapping_sequence(context.get("recent_receipts"))):
        if str(receipt.get("tool") or "") == tool_name:
            return _mapping(receipt.get("result"))
    return {}


def _inventory_entry_count(inventory: Mapping[str, Any]) -> int:
    entries, _ = _inventory_entries(inventory)
    if entries:
        return len(entries)
    try:
        return max(0, int(inventory.get("entry_count") or 0))
    except (TypeError, ValueError):
        return 0


def _inventory_entries(
    inventory: Mapping[str, Any],
) -> tuple[tuple[Mapping[str, Any], ...], bool]:
    raw_entries = inventory.get("entries")
    if isinstance(raw_entries, Mapping):
        sample = _mapping_sequence(raw_entries.get("sample"))
        try:
            count = int(raw_entries.get("count") or 0)
        except (TypeError, ValueError):
            count = len(sample)
        return sample, count > len(sample)
    return _mapping_sequence(raw_entries), False


def _normalized_inventory_path(value: Any) -> str:
    normalized = str(value or "").strip().replace("\\", "/").strip("/")
    return "" if normalized in {"", "."} else normalized


def _read_source_refs(context: Mapping[str, Any]) -> set[str]:
    refs: set[str] = set()
    for receipt in _mapping_sequence(context.get("recent_receipts")):
        if str(receipt.get("tool") or "") not in {"read_ref", "source_read"}:
            continue
        result = _mapping(receipt.get("result"))
        if str(result.get("status") or "") != "source_page_ready":
            continue
        source_ref = str(result.get("source_ref") or "")
        if source_ref.startswith("source_file:"):
            refs.add(source_ref)
    return refs


def _fully_read_source_refs(context: Mapping[str, Any]) -> set[str]:
    refs: set[str] = set()
    for receipt in _mapping_sequence(context.get("recent_receipts")):
        if str(receipt.get("tool") or "") not in {"read_ref", "source_read"}:
            continue
        result = _mapping(receipt.get("result"))
        if str(result.get("status") or "") != "source_page_ready" or result.get(
            "next_line_offset"
        ) not in (None, ""):
            continue
        source_ref = str(result.get("source_ref") or "")
        if source_ref.startswith("source_file:"):
            refs.add(source_ref)
    return refs


def _prepared_source_content_refs(
    context: Mapping[str, Any],
) -> tuple[str, ...]:
    artifacts = _artifact_map(context)
    refs: list[str] = []
    for artifact_ref in _string_sequence(context.get("invocation_seed_refs")):
        artifact = artifacts.get(artifact_ref)
        if artifact is None or artifact.get("artifact_kind") != _PREPARED_SOURCE_KIND:
            continue
        payload = _mapping(artifact.get("machine_payload"))
        for output in _mapping_sequence(payload.get("prepared_outputs")):
            content_ref = str(output.get("content_ref") or "").strip()
            if content_ref.startswith("source_probe:"):
                _append_unique(refs, content_ref)
    return tuple(refs)


def visible_route_names(
    route_names: Sequence[str],
    context: Mapping[str, Any],
) -> Sequence[str]:
    """Reveal tools for the exact scientific and project lifecycle stage."""
    registered = tuple(dict.fromkeys(str(name) for name in route_names if str(name)))
    formula = _bound_formula(context)
    protocol = _bound_protocol_only(context) if formula is None else None
    if formula is None and protocol is None:
        allowed = set(_COMMON_CONTROL_TOOLS)
        if _bound_specification_bundle_refs(context):
            allowed.update(_SOURCE_READ_TOOLS)
            allowed.add("artifact_publish")
    else:
        if formula is not None:
            primary_ref = _stored_ref(formula)
            stage = _stage(context, primary_ref)
            implementation_ref = _latest_implementation_ref(context, primary_ref)
        else:
            primary_ref = _stored_ref(protocol)
            stage = _protocol_stage(context, primary_ref)
            implementation_ref = _latest_protocol_implementation_ref(
                context,
                primary_ref,
            )

        allowed = set(_COMMON_CONTROL_TOOLS)
        # Inspection remains useful during repair; it is not a new prerequisite.
        allowed.update(_SOURCE_READ_TOOLS)
        if stage == "source-observation":
            allowed.update(_SOURCE_TOOLS)
        elif stage == "implementation":
            operation_stage = _project_operation_stage(context)
            if _legacy_code_lineage_available(context):
                allowed.update(_LEGACY_CODE_TOOLS)
            elif operation_stage == "project-setup":
                allowed.add("development_project_open")
            elif operation_stage == "checkpoint-readback":
                pass
            else:
                allowed.update(_PROJECT_WORK_TOOLS)
        elif stage == "execution":
            implementation = _mapping(
                _artifact_map(context).get(implementation_ref)
            )
            if implementation.get("artifact_kind") == _PROJECT_SNAPSHOT_KIND:
                # A checkpoint freezes an executable version, not the ability
                # to repair its mutable project. Pre-execution failures have no
                # execution observation and must not remove repair tools.
                allowed.update(_PROJECT_WORK_TOOLS)
                project_progress = _project_progress(context)
                interruption = _current_project_execution_interruption(
                    context, implementation_ref=implementation_ref,
                )
                inventory_ready = not interruption or bool(
                    _execution_inventory_after_interruption(
                        context,
                        implementation_ref=implementation_ref,
                        workspace_ref=str(interruption.get("execution_workspace_ref") or ""),
                    )
                )
                if not project_progress["snapshot_stale"] and inventory_ready:
                    allowed.add("scientific_materializer_run_project")
            elif _legacy_code_lineage_available(context):
                allowed.update(_LEGACY_CODE_TOOLS)
        elif stage == "inspection":
            allowed.add("scientific_observation_inspect")
            if _mapping(_artifact_map(context).get(implementation_ref)).get(
                "artifact_kind"
            ) == _PROJECT_SNAPSHOT_KIND:
                allowed.update(_PROJECT_WORK_TOOLS)
        elif stage == "publication":
            allowed.add("artifact_publish")
            allowed.add("scientific_observation_inspect")
            implementation = _mapping(
                _artifact_map(context).get(implementation_ref)
            )
            if implementation.get("artifact_kind") == _PROJECT_SNAPSHOT_KIND:
                allowed.update(_PROJECT_WORK_TOOLS)
            elif _legacy_code_lineage_available(context):
                allowed.update(_LEGACY_CODE_TOOLS)
        elif stage == "completion":
            allowed.add("artifact_publish")

        retained = _readable_project_executions(context, implementation_ref)
        if retained:
            allowed.add("development_project_tree")
            if any(_execution_inventory_for_observation(context, ref, stored)
                   for ref, stored in retained.items()):
                allowed.add("development_project_read")

    managed_route_tool_names = {
        str(item.get("route_ref") or "").split(":", 2)[1]
        for item in _managed_code_route_summaries(context)
        if str(item.get("route_ref") or "").count(":") >= 2
    }
    allowed.difference_update(managed_route_tool_names)
    if _route_revision_evidence_available(context):
        allowed.update(_ROUTE_REVISION_TOOLS)
    else:
        allowed.difference_update(_ROUTE_REVISION_TOOLS)
    if not _legacy_code_lineage_available(context):
        allowed.difference_update(_LEGACY_CODE_TOOLS)
    return tuple(name for name in registered if name in allowed)


def _fully_read_prepared_source_refs(
    context: Mapping[str, Any],
) -> set[str]:
    prepared_refs = set(_prepared_source_content_refs(context))
    refs: set[str] = set()
    for receipt in _mapping_sequence(context.get("recent_receipts")):
        if str(receipt.get("tool") or "") not in {"read_ref", "source_read"}:
            continue
        result = _mapping(receipt.get("result"))
        if str(result.get("status") or "") != "source_page_ready" or result.get(
            "next_line_offset"
        ) not in (None, ""):
            continue
        source_ref = str(result.get("source_ref") or "")
        if source_ref in prepared_refs:
            refs.add(source_ref)
    return refs


def _validate_probe_diagnosis_call(
    tool_name: str,
    arguments: Mapping[str, Any],
    context: Mapping[str, Any],
    probe: tuple[int, Mapping[str, Any]] | None,
) -> None:
    if probe is None:
        return
    result = probe[1]
    missing_refs = {
        ref
        for ref in (
            str(result.get("code_ref") or ""),
            str(result.get("stderr_ref") or ""),
        )
        if ref and not _probe_ref_was_read(context, probe, ref)
    }
    if tool_name in {"read_ref", "source_read"}:
        requested = str(arguments.get("ref") or "")
        if requested in missing_refs:
            return
    raise ValueError(
        "materializer_source_probe_diagnosis_required:"
        f"read_only_missing_refs={sorted(missing_refs)}"
    )


def _validate_probe_repair_call(
    tool_name: str,
    arguments: Mapping[str, Any],
) -> None:
    del arguments
    if tool_name == "source_probe":
        return
    raise ValueError(
        "materializer_source_probe_repair_ready:"
        "submit_one_complete_corrected_source_probe;"
        "do_not_restart_reread_or_write_production_code"
    )


def _validate_probe_readback_call(
    tool_name: str,
    arguments: Mapping[str, Any],
    probe: tuple[int, Mapping[str, Any]] | None,
) -> None:
    if probe is None:
        return
    stdout_ref = str(probe[1].get("stdout_ref") or "")
    if tool_name in {"read_ref", "source_read"}:
        if str(arguments.get("ref") or "") == stdout_ref:
            return
    raise ValueError(
        "materializer_source_probe_readback_required:"
        f"read_exact_stdout_ref={stdout_ref}"
    )


def _reject_placeholder_code(code: str) -> None:
    if not code.strip():
        return
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return
    if any(isinstance(node, ast.Pass) for node in ast.walk(tree)):
        raise ValueError(
            "materializer_placeholder_code_rejected:"
            "replace_pass_with_complete_behavior_or_report_the_exact_gap"
        )


def _require_materializer_entrypoint(code: str) -> None:
    if not code.strip():
        raise ValueError(
            "materializer_complete_python_code_required:"
            "submit_the_complete_source_body_in_python_code"
        )
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return
    run_functions = [
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "run"
    ]
    if (
        not run_functions
        or not run_functions[0].args.args
        or run_functions[0].args.args[0].arg != "records"
    ):
        raise ValueError(
            "materializer_run_entrypoint_required:"
            "submit_complete_source_with_top_level_def_run_records"
        )


def _require_protocol_materializer_entrypoint(code: str) -> None:
    if not code.strip():
        raise ValueError(
            "protocol_materializer_complete_python_code_required:"
            "submit_the_complete_source_body_in_python_code"
        )
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return
    run_functions = [
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "run"
    ]
    if len(run_functions) != 1 or [
        argument.arg for argument in run_functions[0].args.args
    ] != ["protocol", "inputs"]:
        raise ValueError(
            "protocol_materializer_run_entrypoint_required:"
            "submit_complete_source_with_top_level_def_run_protocol_inputs"
        )


def _artifact_map(context: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    artifacts: dict[str, Mapping[str, Any]] = {}
    for stored in _mapping_sequence(context.get("resolved_artifacts")):
        ref = _stored_ref(stored)
        if ref:
            artifacts[ref] = stored
    return artifacts


def _managed_code_route_summaries(
    context: Mapping[str, Any],
) -> tuple[Mapping[str, Any], ...]:
    return tuple(
        item
        for item in _mapping_sequence(context.get("managed_route_summaries"))
        if item.get("code_callable") is True
    )


def _managed_route_candidate_refs(context: Mapping[str, Any]) -> tuple[str, ...]:
    refs: list[str] = []
    for item in _managed_code_route_summaries(context):
        ref = str(item.get("candidate_artifact_ref") or "").strip()
        if ref:
            _append_unique(refs, ref)
    return tuple(refs)


def _validate_managed_route_source_binding(
    code: str,
    *,
    dependencies: Sequence[str],
    context: Mapping[str, Any],
) -> None:
    source_refs = _managed_route_refs_from_source(code)
    dependency_refs = {
        ref
        for ref in dependencies
        if ref.startswith(("approved_route:", "pending_route:"))
    }
    if source_refs != dependency_refs:
        raise ValueError(
            "materializer_managed_route_source_dependency_mismatch:"
            f"source_refs={sorted(source_refs)}:"
            f"dependency_refs={sorted(dependency_refs)}"
        )
    visible_refs = {
        str(item["route_ref"]) for item in _managed_code_route_summaries(context)
    }
    unavailable = sorted(source_refs - visible_refs)
    if unavailable:
        raise ValueError(
            f"materializer_managed_route_not_bound_or_visible:route_refs={unavailable}"
        )
    summaries = {
        str(item["route_ref"]): item for item in _managed_code_route_summaries(context)
    }
    for route_ref in sorted(source_refs):
        if not route_ref.startswith("pending_route:"):
            continue
        candidate_ref = str(summaries[route_ref].get("candidate_artifact_ref") or "")
        if not candidate_ref or candidate_ref not in dependencies:
            raise ValueError(
                "materializer_pending_route_candidate_dependency_required:"
                f"route_ref={route_ref}:"
                f"candidate_ref={candidate_ref or 'missing'}"
            )


def _managed_route_refs_from_source(code: str) -> set[str]:
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return set()
    static_refs = _statically_bound_route_refs(tree)
    refs: set[str] = set()
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id in {"invoke_approved_route", "invoke_managed_route"}
        ):
            continue
        raw_ref = _validate_managed_route_call_contract(
            node,
            static_refs=static_refs,
        )
        ref = str(raw_ref or "")
        if not ref.startswith(("approved_route:", "pending_route:")):
            raise ValueError(
                "materializer_managed_route_ref_must_be_static_literal:"
                "use_an_inline_literal_or_one_plain_variable_assigned_once"
            )
        refs.add(ref)
    return refs


def _statically_bound_route_refs(tree: ast.AST) -> dict[str, str]:
    binding_counts: dict[str, int] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and not isinstance(node.ctx, ast.Load):
            binding_counts[node.id] = binding_counts.get(node.id, 0) + 1
        elif isinstance(node, ast.arg):
            binding_counts[node.arg] = binding_counts.get(node.arg, 0) + 1
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            binding_counts[node.name] = binding_counts.get(node.name, 0) + 1
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in node.names:
                bound_name = alias.asname or alias.name.split(".", 1)[0]
                binding_counts[bound_name] = binding_counts.get(bound_name, 0) + 1
        elif isinstance(node, ast.ExceptHandler) and node.name:
            binding_counts[node.name] = binding_counts.get(node.name, 0) + 1

    candidates: dict[str, str] = {}
    for node in ast.walk(tree):
        target: ast.expr | None = None
        value: ast.expr | None = None
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
        ):
            target = node.targets[0]
            value = node.value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            target = node.target
            value = node.value
        if (
            isinstance(target, ast.Name)
            and isinstance(value, ast.Constant)
            and isinstance(value.value, str)
            and binding_counts.get(target.id) == 1
        ):
            candidates[target.id] = value.value
    return candidates


def _validate_managed_route_call_contract(
    node: ast.Call,
    *,
    static_refs: Mapping[str, str] | None = None,
) -> str:
    if any(keyword.arg is None for keyword in node.keywords):
        raise _managed_route_call_contract_error()
    keyword_values = {str(keyword.arg): keyword.value for keyword in node.keywords}
    if (
        len(node.args) > 2
        or set(keyword_values) - {"route_ref", "payload"}
        or (node.args and "route_ref" in keyword_values)
        or (len(node.args) > 1 and "payload" in keyword_values)
    ):
        raise _managed_route_call_contract_error()
    route_node = node.args[0] if node.args else keyword_values.get("route_ref")
    payload_node = node.args[1] if len(node.args) > 1 else keyword_values.get("payload")
    if route_node is None or payload_node is None:
        raise _managed_route_call_contract_error()
    if not (isinstance(route_node, ast.Constant) and isinstance(route_node.value, str)):
        if isinstance(route_node, ast.Name):
            return str((static_refs or {}).get(route_node.id) or "")
        return ""
    return route_node.value


def _managed_route_call_contract_error() -> ValueError:
    return ValueError(
        "materializer_managed_route_call_contract_invalid:"
        "expected=invoke_managed_route(route_ref,payload_mapping):"
        "put_every_route_input_field_inside_the_single_payload_mapping"
    )


def _stored_ref(stored: Mapping[str, Any] | None) -> str:
    if stored is None:
        return ""
    return str(
        stored.get("artifact_ref")
        or stored.get("code_artifact_ref")
        or stored.get("observation_ref")
        or ""
    )


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _mapping_sequence(value: Any) -> tuple[Mapping[str, Any], ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return ()
    return tuple(item for item in value if isinstance(item, Mapping))


def _string_sequence(value: Any) -> tuple[str, ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return ()
    return tuple(str(item) for item in value if str(item))


def _append_unique(values: list[str], value: str) -> None:
    if value and value not in values:
        values.append(value)


def _execution_strategy(stage: str, *, repair_required: bool) -> str:
    sections = _page("execution-strategy.md").split("\n## ")
    indexed = {part.split("\n", 1)[0]: "## " + part for part in sections[1:]}
    selected = [sections[0]]
    if stage in {"implementation", "execution"}:
        selected.extend(indexed[key] for key in ("Implementation checks", "Cost and saved progress"))
    if repair_required:
        selected.append(indexed["Repair and continuation"])
    if stage in {"inspection", "publication", "completion"}:
        selected.append(indexed["Result inspection"])
    return "\n\n".join(selected)


def _page(name: str) -> str:
    path = (_ROOT / "references" / name).resolve()
    if not path.is_relative_to(_ROOT):
        raise ValueError(f"materializer_disclosure_page_outside_skill:{name}")
    return path.read_text(encoding="utf-8").strip()


def _source_observation_ledger(context: Mapping[str, Any]) -> tuple[str, ...]:
    observations: list[str] = []
    for receipt in _mapping_sequence(context.get("recent_receipts")):
        tool = str(receipt.get("tool") or "")
        result = _mapping(receipt.get("result"))
        status = str(result.get("status") or "")
        item = ""
        if tool == "source_inventory" and status == "source_inventory_ready":
            entries = []
            projected_entries, sample_only = _inventory_entries(result)
            for entry in projected_entries:
                label = str(
                    entry.get("relative_path") or entry.get("label") or ""
                ).strip()
                source_ref = str(
                    entry.get("source_ref") or entry.get("ref") or ""
                ).strip()
                if not label and not source_ref:
                    continue
                entries.append(
                    f"`{label or 'source'}` -> `{source_ref}`"
                    if source_ref
                    else f"`{label}`"
                )
            shown = ", ".join(entries[:8])
            if len(entries) > 8:
                shown += f", and {len(entries) - 8} more"
            item = f"inventory: {result.get('entry_count', 'unknown')} entries"
            if shown:
                item += f" ({shown})"
            if sample_only:
                item += (
                    "; current prompt contains a bounded sample only, so use "
                    "one different narrower relative_path if the required "
                    "task source is absent"
                )
        elif tool == "source_search" and status == "source_search_ready":
            query = " ".join(str(result.get("query") or "").split())
            item = f"search `{query}`: {result.get('match_count', 'unknown')} matches"
        elif tool in {"read_ref", "source_read"} and status == "source_page_ready":
            label = str(result.get("label") or "source")
            offset = result.get("line_offset", "unknown")
            next_offset = result.get("next_line_offset")
            if next_offset in (None, ""):
                item = (
                    f"complete read: `{label}` lines {offset} to end "
                    "(no continuation remains)"
                )
            else:
                item = f"partial read: `{label}` lines {offset} to {next_offset}"
        elif tool == "source_probe" and status in _EXECUTED_SOURCE_PROBE_STATUSES:
            item = f"probe: {status}"
        if item and item not in observations:
            observations.append(item)
    return tuple(observations[-6:])
