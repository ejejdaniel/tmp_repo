# Execution Strategy And Cost

Materializer owns proportionate implementation checks, method choice and
recovery whether or not Specialist advice exists. Follow the task and frozen
specification using available evidence, libraries, optional Routes and focused
diagnostics. These are work instructions for this Materializer, not additional
approval gates, required output fields or a universal scientific pipeline.

Keep implementation faithful to the specification, not to target scores.
Task-scoped measurements, including paired targets, may be read through the
existing source tools for inspection. Their availability grants no authority
to change the specification or calibrate against them. Explicit source and
mission restrictions still apply. Implement explicitly specified fitting
as declared; do not silently tune constants, change formulas or use sample-ID
lookups to reproduce answers. Task-consistent approximation and method choice
remain your responsibility. This is not a guarantee of blind implementation.

## Implementation checks

Checkpointing records the code to test; it does not certify a completed
calculation. Once the entry point is implemented and focused checks address the
known risks, checkpoint it and use formal execution for its FIRST full run.
That run is also the end-to-end implementation test. A defect there can be
repaired in the same project. Do not prove the full calculation in the terminal
as a prerequisite for checkpointing, even if it appears to fit the budget.

Identify unresolved API use, unit conversions and assumptions that could change
the answer. Use existing project-terminal and code-query tools to check the
relevant interfaces before expensive execution. Distinguish a public wrapper
or factory from the actual returned object and defining class; inspect the
installed implementation, signature or a minimal instance as appropriate.
Syntax checks alone do not establish API correctness.

For added constants, calibration, branches or lookups, identify the specification
or implementation rationale. A better target score alone is not that rationale.

Trace units from raw library values through conversions and reductions to the
promised quantity. Derive the conversion direction from dimensions, not a
constant's name. Use cheap checks with independently known transformations or
invariants where useful; a check repeating the same expression can reproduce
the same error. Keep generated method descriptions consistent with the code.

Before substantial computation, identify dominant cost and open implementation
choices. Use existing timings or a small representative calculation to estimate
cost per useful progress. Consider screening, approximate starting points, warm
starts or staged refinement when faithful to the task. Verify the final result
with the required method; never relabel a coarse result as a validated one.
Cheap deterministic work needs no preliminary optimization exercise.

## Cost and saved progress

Build saving, loading and budget accounting into the FIRST implementation of
expensive multi-stage work, before the numerical loop, not after a failure.
Choose useful recovery units from the calculation itself. For each completed
unit, immediately save its values and effective inputs/settings in a
project-local file, before starting the next unit or final serialization.
Write updates atomically so a failed write cannot destroy the previous state.
A source checkpoint preserves code, not numerical progress.

When the task specifies a cumulative numerical budget, keep elapsed computation
time separately from reusable values. Load that total on startup; measure each
unit with a monotonic timer and save its elapsed time even when the unit raises
an exception. Add already measured numerical probes or earlier executions from
their actual receipts exactly once. Exclude LLM waiting time. An end-of-program
timer or a fresh timer on each run is NOT cumulative budget management.
Invalidating values must not reset their spent time. Inspect prior execution
evidence to reconcile an interrupted unit whose timing was not saved; unknown
cost is not zero. Before another unit, compare remaining budget with measured
cost. Estimates are not guarantees; save progress and report incompleteness at
exhaustion without emitting a partial final result.

During the existing pre-execution source inspection, locate the save/load path,
the compatibility check, and the budget check in your code. If required by the
work but absent, implement them before running; prose promises are not code.
Use a cheap focused save/load/failure check without repeating the full science.
File names and formats are project-owned, not new public output requirements.
Cheap atomic work need not be split. Runtime's per-process timeout remains a
safety ceiling, not a shared cross-tool cumulative budget.

## Repair and continuation

Trace the earliest exception to the actual object, module and definition before
editing. If a source search is empty, check what object and file were inspected;
do not merely repeat similar keywords against the same unverified wrapper.
Use the traceback, installed source and existing receipts to narrow the next
probe. Preserve valid work and repair the bounded defect.

After any execution interruption, determine what advanced, what was saved, what
the next run will reuse and why another run is worthwhile. A changed snapshot
needs the existing resume_from mechanism to receive selected prior runtime
files. Ensure code loads and validates those files against current inputs and
settings. Reuse compatible results; recompute incompatible ones without erasing
their cost. Verify the restart path with a focused check when uncertain.
Slow or unknown progress calls for diagnosis or an implementation-owned strategy
change, not just a longer timeout. Keep choices and unresolved issues in existing
project notes/logs; Node/step quota exhaustion is not proof of scientific impossibility.

## Result inspection

Compare the exact specification, executed source, raw outputs, transformations
and reported interpretation. Confirm which quantity or components were actually
computed, that any aggregation matches the promise, and that conversions produce
the stated units. Normal exit, symmetry or internal agreement alone cannot prove
correctness: shared scaling errors and missing components may preserve all three.
Inspect the relevant code and raw values, then choose proportionate checks for
the identified risks. `scientific_observation_inspect` remains available during
publication; its schema lists the roots for normalized values, execution metadata
and raw project output. Use the existing successful execution for inspection and
publication; require another numerical run only when the implementation or
scientific inputs need correction, or the task explicitly requires replication.
During this same inspection, check that the code has not introduced undeclared
answer-dependent fitting or answer substitution. In the existing implementation
account, explain the method and parameter sources with exact code references;
distinguish declared fitting from implementation choices. These checks do not
certify absence of overfitting or independent validation and require no extra
review stage or repeated full calculation.
If a numerical budget was specified, compare the project's recorded total with
all known numerical executions and probes, not just the last process duration.
Report any missing accounting truthfully; do not claim budget enforcement from
the fact that the final run was short.
