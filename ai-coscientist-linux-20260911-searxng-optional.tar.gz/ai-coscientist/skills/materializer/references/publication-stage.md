# Publication Stage

Apply the accompanying inspection criteria to the exact returned observation
and current implementation. Publish only when that review supports faithful
implementation. If it exposes an implementation defect, repair and re-execute.

Publish `quantitative_proxy_materialization_result` from the exact inspected `machine_payload_observation_ref`. Markdown is not a substitute for stored execution content.

Use this field separation:

```text
title = identify the exact frozen formula materialization
markdown = concise human-readable completion account
summary = one sentence stating completion status, record coverage, and unresolved count
machine_payload_observation_ref = current observation ref
depends_on = [exact bound formula ref]  # or omit this optional field
trace_refs = optional additional trace refs within this invocation
```

The human-readable fields must describe what the inspected observation actually
established. They do not replace the stored machine result and must not invent
values, but they may not be blank. State whether materialization is complete,
how many records were covered, and whether any formula components remain unresolved.

Never put a `code_artifact:` or `execution_observation:` ref in the
model-supplied `depends_on`. Runtime adds the verified implementation and
observation dependencies and trace refs after validation. Do not reconstruct
the implementation or observation identity already recorded in the selected
stored observation.

If publication is rejected, change only the rejected publication arguments and retry once. Do not edit or re-execute already inspected code, and do not repeat an identical rejected call.
