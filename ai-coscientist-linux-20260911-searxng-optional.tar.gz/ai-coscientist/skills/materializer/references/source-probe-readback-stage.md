# Source Probe Readback

The latest source probe succeeded and produced observations, but its output has not
yet been read back. The next action is `read_ref` on the exact latest `stdout_ref`
shown in the current invocation.

Do not restart source discovery, rerun the probe, or write final implementation
code before this readback. Once read, the implementation stage can consume the
observed source model.
