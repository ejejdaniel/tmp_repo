# Inspection Stage

Call `scientific_observation_inspect` on the exact current execution observation.
Use the tool schema's dot-path roots to select normalized results, execution
metadata, or original project output. Raw-output paths follow the actual JSON
written by the program, including any wrapper objects. Select the fields needed
for the implementation check; do not substitute a prior observation. Raw output
is diagnostic evidence, not the normalized payload to publish.

Verify one completed formal execution or an exact persisted completion receipt, opaque-ID and row-order authority, finite values for every record, and complete formula components. Treat execution success as provisional evidence, not proof that the implementation matches the formula. Require a full independent rerun only when the task or evaluator explicitly asks for it.

After this observation is inspected, the next disclosure includes both code-and-result review criteria and publication instructions. Inspection remains available there: one read is not a declaration that all checks are complete. Repair the implementation if the comparison exposes a defect; otherwise publish the verified result.
