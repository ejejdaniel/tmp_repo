# Bound Computational Protocol

The exact `computational_property_protocol` is the specialist-authored
specification for its `quantity_id`, but it does not freeze every implementation
choice.

Treat these machine-payload elements as immutable authority:

- scientific definition and reference-state arithmetic;
- result output id, unit, expression, and interpretation boundary;
- formal external inputs, when any are required.

Treat the Protocol Markdown and specialist assessment as expert guidance:
recommended Routes, initial settings, exploration axes, convergence targets,
alternatives, uncertainties, and requests for more information. Follow that
guidance when defensible, but select and revise the executable dataflow and
operational choices from execution evidence.

- Do not substitute a different quantity, reference arithmetic, required input,
  unit, or interpretation boundary.
- Do not invoke another Skill from generated code. The Graph already obtained
  the protocol; Materializer performs implementation work with its own tools and
  currently visible code-callable Routes.
- Include the protocol artifact ref, every selected exact Route ref, and each
  selected pending Route's exact `capability_candidate` artifact ref in
  implementation lineage.
- A conflict between the frozen Formula and immutable Protocol authority is a
  precise upstream gap. An unspecified operational setting is Materializer work,
  not such a conflict.
