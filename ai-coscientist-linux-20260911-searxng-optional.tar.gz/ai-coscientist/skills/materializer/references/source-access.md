# Source Access During Implementation and Repair

Task source files and active development-project files are separate namespaces.
Use `source_*` only for authorized task inputs and source data. Use
`development_project_tree`, `development_project_read`,
`development_project_search`, or `development_project_query_code` for code and
support files inside the active development project. Never use `source_*` to
locate or read project files such as `main.py`.

Read-only source tools remain available after initial inspection. Use them for
a concrete input or path question; do not restart a broad source survey merely
because a prior execution failed. They are optional diagnostics, not required
steps before execution. Formula and Protocol have the same read-only access to
explicitly authorized sources; reading does not change their scientific meaning.

`scientific_source_manifest` reports the current pinned input identity and row
count, not computed results. Distinguish a new runtime verification receipt from
an older failure. A successful source check does not prove execution succeeded.

`workspace:` entries in the mission packet are navigation locations, not
`read_ref` handles. Pass the entry's `relative_path` to `source_inventory`;
then pass the returned exact `source_file:` ref to `read_ref` as `ref`.
Continue with `next_line_offset` when needed. Do not guess an encoded source ref
or send a filesystem path to `read_ref`.

Source tools enforce the existing mission scope. Files and indexes are navigation
or working data, not accepted scientific artifacts. Consume formal artifacts
through their exact authorized artifact refs; do not bypass the artifact store
by treating an on-disk JSON file as accepted evidence.
