# Specification Intake

The exact invocation inputs are the implementation commission. They may come
from a task contract, an explicit human requirement, a Formula, a Specialist,
or another formal producer. Their artifact kinds do not make them equal
authority: obey task and human constraints, preserve any frozen scientific
relationship, use Specialist content as advice unless the task made it binding,
and treat data or observations as inputs rather than objectives.

This invocation has no existing Formula or Protocol that can anchor the result
schema. Do not reject a clear direct-computation commission for that reason.
First normalize the mounted specification bundle into one existing
`computational_property_protocol` artifact, then read it back and continue the
same Materializer invocation through project implementation and execution.
This is an internal execution checkpoint, not a separate Graph node and not a
new scientific research claim.

The Protocol must:

- preserve the requested quantity, conditions, output unit, interpretation,
  and every explicit hard constraint without silently narrowing or changing
  the task;
- write `result_contract.unit` as one exact machine-comparable unit string.
  Put alternate units, conversion factors, reporting options, and explanatory
  prose in `interpretation` or Markdown, never in `unit`;
- describe the reference arithmetic needed to calculate the requested result;
- list only genuine external artifact inputs in `required_inputs`; geometry,
  numerical settings, convergence strategy, and other implementation-owned
  choices that Materializer can construct do not need invented artifact refs.
  Task specifications, human requirements, Formulas, and Specialist advice
  define or constrain the Protocol and belong in `depends_on`; do not repeat
  them in `required_inputs` unless the execution program must consume that
  artifact's machine payload as runtime data;
- depend on every exact invocation input shown in the specification bundle;
- explain in Markdown which constraints were inherited and which choices
  remain for Materializer to implement and test.

Publish only the existing `computational_property_protocol` shape. Do not write
code before its mandatory exact-ref readback. Before publication, compare the
quantity definition with its arithmetic, unit and interpretation: distinguish a
component, a collection of components and an aggregate when relevant. Do not
label a partial measurement as the whole requested quantity. These are your
checks on faithful normalization, not a separate reviewer or new output fields.
If the mounted inputs conflict on
the requested quantity, conditions, or result contract, or do not identify a
direct computational result at all, call `restart_node_attempt` with that exact
bounded gap instead of inventing a target.
