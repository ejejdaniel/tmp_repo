# Code And Result Review Criteria

The execution observation has been inspected. Compare it with the exact current
implementation and frozen Formula. For a project snapshot, inspect its exact
readback and only the relevant files or symbols. For a legacy code artifact,
the complete stored source is normally already visible; call `read_ref` only
when it is absent or truncated. When complete source is already present,
rereading is not required.

After readback, compare the frozen formula, observed source shape, complete
relevant implementation, component values, proxy values, and process evidence:

- Every per-item contribution must come from that item or from an explicit observed join or correspondence; a collection-level fact must not be broadcast as a per-item value.
- Every formula variable must follow its declared source binding and method. Equal collection lengths alone do not prove correspondence.
- The output record-ID set and count must exactly match the authoritative input records in both component and proxy mappings.
- Recompute the frozen formula for each record from the reported component values and compare it with the reported proxy value.
- All reported component and proxy values must be finite, and a successful result must not retain unresolved components.
- `pass`, TODOs, placeholder branches, swallowed exceptions, and numeric defaults for unresolved scientific inputs are implementation defects.
- A declared-varying quantity that becomes constant requires investigation against the source observation and the exact code path that produced it.
- Inspect process stderr in context. A nonzero execution or an error that affected results is a defect; harmless package diagnostics alone do not redefine an otherwise verified result.

If any defect exists, edit the current project and checkpoint a new snapshot,
or edit or replace the current legacy code revision. Execute the new exact
implementation and inspect its new observation. If the source observation proves a required
relationship or input genuinely absent, call `restart_node_attempt` and name that
exact missing authority in `reason`.

If the discrepancy is known but its code location is not, run one focused
`source_probe`. If that probe identifies the exact defective construct, the next
step is a precise edit of the current implementation, followed by execution and inspection;
do not restart broad source exploration.
