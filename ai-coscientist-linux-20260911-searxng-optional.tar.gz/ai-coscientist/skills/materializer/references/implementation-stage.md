# Implementation Stage: Formula Contract

Implement the frozen formula already present in
`resolved_inputs_for_active_skill` and every related Protocol projected in the
current invocation. Do not reread them merely because a large Markdown body is
collapsed. Their structured payloads and successful read receipts remain
authoritative.

Choosing a faithful computation method is part of Materializer's responsibility.
Materializer chooses the simplest auditable implementation that preserves the
target, formula expression, variable concepts, expected direction, and claim
boundary. It may choose libraries, parsing, numerical methods, defensible
approximations, model settings, discretization, batching, solver strategy, and
reference scales that the specification does not uniquely fix. Record material
implementation choices and remaining uncertainty; never present an
approximation as the unique physical law.

The accompanying execution-strategy page governs cost, method selection and
restart decisions. Specialist advice informs those choices but is optional.

Algorithm ambiguity alone is not a gap. It is normally Materializer work, not
an upstream gap. When
several plausible methods could materially change the result, compare them or
run a bounded sensitivity check when the Node budget permits. Call
`restart_node_attempt` only after focused investigation proves that every
faithful implementation requires missing authority or capability, or would
change the frozen scientific meaning. Name the methods attempted and the exact
gap.

A missing numeric column is not a gap when it is derivable from an encoded
scientific representation. Establish explicit joins or justified correspondence
before combining collections. Equal lengths alone do not establish positional
alignment. Use an appropriate parser or scientific library. Do not infer
scientific meaning from field-name spelling. Never replace a missing value,
parse failure, undefined quantity, or failed scientific operation with a
default, sentinel, clipping bound, invented epsilon, or partial success.

`AI_COSCIENTIST_MATERIALIZER_JOB` and
`AI_COSCIENTIST_MATERIALIZER_RESULT` contain filesystem paths, not inline JSON.
The project entry program must read the JSON file named by the first path and
write exactly `{"result": result_object}` to the file named by the second path.
Do not pass either environment-variable value directly to a JSON parser. For
Python, the mechanical boundary is:

```python
job = json.loads(
    Path(os.environ["AI_COSCIENTIST_MATERIALIZER_JOB"]).read_text(encoding="utf-8")
)
Path(os.environ["AI_COSCIENTIST_MATERIALIZER_RESULT"]).write_text(
    json.dumps({"result": result_object}),
    encoding="utf-8",
)
```

The Formula job provides the exact specification and authoritative records;
`record["id"]` is the guaranteed opaque identity field. The result object keeps
this shape and covers every record exactly once:

```python
{
    "execution_input_paths": ["record.example_input"],
    "resolved_components": ["formula_variable_name"],
    "unresolved_components": [],
    "component_values_by_sample": {
        "sample_id": {"formula_variable_name": finite_number}
    },
    "proxy_values_by_sample": {"sample_id": finite_number},
}
```

Replace the illustrative path with the exact native paths this implementation
reads as scientific inputs, including inputs used by called Routes. Declare a
non-empty list of non-empty `record` paths; each path must exist with a non-null
value in every executed record. Declare leaf paths or a complete input object
when its whole contents are inputs. Opaque `id` is supplied separately. Do not
list an entire row, measurements, descriptions or provenance merely because
they are present. Do not fabricate a value to satisfy a path.

This declaration follows the selected execution data, not the Formula's original
research layout. It does not change the scientific formula. Sample will create
new records using these inputs and run this exact implementation, so keep the
declaration stable across historical and candidate batches. Runtime validates
paths and preserves them in the formal materialization result; it does not infer
input meaning or extract paths from code. If an old result lacks this declaration,
repair the same project and publish a new executed version rather than rewriting
the Formula or mutating the old result.

This is one result object, not per-record rows. Recompute each proxy value from
that record's component values using the exact frozen expression. Produce
complete finite values for every authoritative record. A successful
implementation may not contain TODO branches, swallowed exceptions, unresolved
components, or fabricated fallback values; no exception, missing value, parse
failure, or unresolved relation may be hidden.

Managed Route invocation is optional and distinct from selecting a project
environment. Bind only Routes that generated code actually calls. A pending
Route also retains its exact capability-candidate lineage. The accompanying
project-operation page discloses only the tools and Route detail needed for the
current lifecycle step.

Legacy `code_artifact` tools appear only when this Formula already has a legacy
single-file lineage. They remain repair-compatible but do not start new work.
