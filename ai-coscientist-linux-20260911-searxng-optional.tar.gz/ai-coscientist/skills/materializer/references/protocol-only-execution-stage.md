# Protocol-only Execution And Inspection

The active development project and the task source workspace are different
namespaces. Inspect implementation files such as `main.py` with
`development_project_tree`, `development_project_read`,
`development_project_search`, or `development_project_query_code`. Use
`source_*` tools only for authorized task inputs and source data; they cannot
read files inside the active development project.

When no current execution observation exists, bind only the Routes actually
selected by the implementation, create a new checkpoint after that binding,
then call
`scientific_materializer_run_project` for a project snapshot with the exact
Protocol as `spec_artifact_ref`, exact snapshot ref, explicit `input_bindings`,
and one execution-wide `max_route_calls`. Use
`scientific_protocol_materializer_execute` only for a legacy single-file Code
artifact. An empty input-binding array is valid when the implementation can
construct every task-defined input without another formal Artifact.

Execution code must return at least `output_id`, `value`, and `unit`.
`output_id` and `unit` must be copied from and exactly match the Protocol result
contract. `value` may be a scalar, vector, or structured finite JSON value.
Additional diagnostic fields are allowed in the raw result and remain in the
execution workspace; Runtime publishes only the three required fields in the
formal `computational_property_result`.

When the current observation exists, call `scientific_observation_inspect` on
that exact ref and inspect `result`. Confirm one completed formal execution or a
cryptographically matched reuse receipt, matching Protocol ref, matching output
id and unit, finite serializable value, exact execution environment and
implementation provenance, exact input bindings, and recorded managed-Route
calls.
Execution success is provisional until this inspection completes.
