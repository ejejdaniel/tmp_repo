# Retained Execution Files

The exact visible executions below belong to this development project. They
remain inspectable while editing or checkpointing a newer implementation.
Historical execution evidence does not set the status of the current snapshot.
Successful, failed and interrupted executions can all be read. The list marks
which executions are eligible for `resume_from`; read access does not authorize
resuming or publishing an old result.
List a workspace with `development_project_tree` using its `project_id` and
`execution_workspace_ref`. Read listed files with `development_project_read`
using the same identifiers, the listed `path`, `line_offset`, and `line_limit`.
Omitting the execution ref selects the mutable project instead. Binary files
remain in the workspace; do not transcribe or recreate them through code tools.

A changed snapshot starts in a different execution directory. To reuse eligible prior
runtime files, pass `resume_from` to `scientific_materializer_run_project` with
that exact `execution_workspace_ref` and selected `relative_paths` from its
inventory. Runtime copies the selected bytes at those same relative paths and
records their source and hashes. It never copies the old source snapshot,
control/result files, or completion receipt. Without `resume_from`, a new
snapshot does not inherit old runtime files. Repeating an identical snapshot,
job and resume seed continues its existing execution directory.

Assess compatibility with the new code and bound scientific inputs. Read saved
progress before deciding whether to resume, revise the strategy, or restart.
Choose the checkpoint and related state files the code actually consumes, not
every file. Ensure the new program loads them; copying a file alone does not
resume a calculation. A partial checkpoint or cached intermediate value is not
a completed scientific result. Execute and inspect the required final output.
