# Source Probe Repair

The source inventory, relevant source pages, failed probe code, and exact error are
already visible. Do not restart discovery and do not reread them.

The focused probe and `scientific_materializer_execute` use the same configured
Python executable. A missing import or runtime capability observed here will
also be missing during production execution. The correction must therefore use
an available faithful method; do not retry the known-unavailable dependency on
the assumption that production has a different environment.

The next action is one corrected `source_probe` call. Submit the complete corrected
`python_code`, because each probe is independent and no prior script is reused.
Preserve the original scientific purpose and source refs; fix the diagnosed
implementation or source-access defect only. Use the exact relative source paths
already reported by the inventory, joined beneath the runtime-provided
`SOURCE_ROOT`.

After the corrected probe succeeds, read its exact `stdout_ref`. If it fails, read
the new probe's code and error before another repair.
