# Protocol-only Publication

Publish `computational_property_result` only from the exact inspected
`machine_payload_observation_ref`. The stored observation owns the result
payload; Markdown must not restate invented values.

Use:

```text
artifact_kind = computational_property_result
machine_payload_observation_ref = current observation ref
depends_on = optional additional formal dependencies within this invocation
trace_refs = optional additional trace refs within this invocation
summary = one sentence naming the completed quantity, output id, and unit
```

Do not place legacy Code or Observation refs in model-authored `depends_on`.
Runtime adds verified implementation, Observation, input, Route-capability and
pending-governance lineage, including implementation and Observation trace refs.
Do not reconstruct those stored links. If publication is rejected, correct only
the publication arguments; retain the inspected result and do not recompute it.
After publication, read back the exact result and
end this invocation.

Ending this invocation returns control for the active node's evidence assessment;
it does not declare the node or task complete. Reuse an exact result already
produced by this node when it satisfies the specification. Do not republish or
recompute it just to make it new in this invocation. If it does not satisfy the
specification, report the precise discrepancy rather than claiming completion.
