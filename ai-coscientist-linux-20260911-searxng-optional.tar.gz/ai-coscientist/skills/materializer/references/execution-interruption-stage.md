# Inspect Interrupted Execution

`materializer_project_execution_interrupted` is not completed scientific
evidence. First call `development_project_tree` with the current `project_id`
and exact returned `execution_workspace_ref`. Use optional `path` and
`max_entries` to focus the inventory. Runtime file labels are mechanical:
`snapshot_unchanged`, `runtime_created`, and `runtime_modified`. Read relevant
text state or log files with `development_project_read`, using the same two
identifiers plus the listed `path`, `line_offset`, and `line_limit`; binary
files expose metadata only. The inventory must come after the latest run,
because rerunning can change files without changing the workspace ref.
Without `execution_workspace_ref`, tree/read operate on the mutable development
project, not the retained execution. Execution pages identify `relative_path`
and `runtime_state`; development pages identify `project_id` and `path`.

For long logs, use `development_project_search` with `project_id` and the exact
`execution_workspace_ref` to find relevant lines in the retained execution.
Without that optional ref, search examines authoring files, not runtime logs.
For counts, trends or binary state inspection, use
`development_project_terminal_start` with the same two identifiers. Its command
runs in the development project with the execution files mounted read-only at
the `AI_COSCIENTIST_EXECUTION_DIR` environment variable. Use a focused command or
write an analysis script with the existing authoring tools; print the evidence
needed for the decision instead of paging through unrelated log sections.
Save derived notes in the development project, never in the original execution.
Terminal polling retains the execution ref, and stdout/stderr refs support full
readback. This is diagnostic evidence, not completed scientific output.

Use the accompanying execution-strategy guidance to decide whether to continue
the same immutable snapshot, repair and checkpoint the development project, or
report an evidenced gap. Reading a diagnostic does not resolve an interruption.
Authoring and diagnostic tools remain available after inventory. A retained
runtime file is not a published scientific result.
