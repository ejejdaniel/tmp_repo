# Project Authoring And Validation

The mutable project exists. Build, inspect, validate, and repair the smallest
project that faithfully implements the frozen specification. A one-file
program is the smallest multi-file project, not a separate implementation
mode. One written support file does not mean authoring is complete. A checkpoint
freezes one executable version; it does not end your ability to edit and
checkpoint the same project when execution or delivery exposes a defect.

Each `development_project_write` call must contain one coherent file that can be
completed in that single tool response. If the faithful implementation would
make one file too large to submit reliably, split it first by implementation
responsibility and write the modules one at a time. Keep the entry file small;
do not duplicate generated data, schemas, or helper logic merely to force the
whole project into one call.

`development_project_write` creates a new path only. To revise an existing
file, use `development_project_edit`. Prefer the smallest unique replacement,
but a coherent whole-file rewrite is valid when a local patch would leave the
program internally inconsistent: read the complete current file, pass that
exact body as `old_string`, and pass the complete intended replacement as
`new_string`. If a write was rejected because the path exists, preserve and
reuse its complete submitted content; do not reconstruct only fragments of it.

If generated code will call managed Routes, first select and bind only the exact
Route refs it needs with `development_project_bind_managed_routes`. Binding is
optional. A missing convenience Route does not block direct implementation with
libraries already installed in the fixed scientific environment. After
binding, only the bound Routes' exact schemas are disclosed.

Write the entry file and any supporting files directly, using any language
available in the fixed environment. Use the project terminal for bounded API,
compiler, or runtime diagnostics. The terminal and formal execution use the
same environment. Do not install packages, inspect broker files, or inspect
host-private paths.

Before choosing a third-party Python backend, if no package inventory from the
active project environment is already visible, run exactly one complete,
read-only inventory with `python -m pip list --format=json` through the project
terminal. Do not infer availability from a hand-picked list of imports. After
the inventory, use focused import or API probes only for the backend actually
being considered. Do not repeat the complete inventory while its exact result
remains visible.

Read tools return complete lines and `next_line_offset`; continue with that
offset when more text is needed. Terminal output is a tail preview. Read the
returned `stdout_ref` or `stderr_ref` with `read_ref` for earlier output. A
truncated project diff has `diff_ref` for the same full-output readback. Use
these returned refs as-is; do not guess filesystem paths or reconstruct refs.

The accompanying execution-strategy sections own scientific implementation
checks, saved computational progress and task-budget handling. Apply them while
authoring, not only after a timeout. This page owns project-tool mechanics.

Implement hard task and Protocol constraints in the actual calculation. A
post-processing rewrite, restored output value, relabelled result, or textual
claim does not satisfy a constraint that had to remain active while an
optimizer, solver, simulation, or measurement ran. If an optional Route's
schema cannot express a required operation, do not approximate around the
missing control. Use the selected managed environment's underlying packages
directly when they can implement it, or return a bounded capability gap after
focused diagnostics prove the fixed environment lacks the required capability.
Prefer a maintained scientific-library constructor or constraint API over
hand-building a canonical scientific object when that API is available.

During formal execution, `AI_COSCIENTIST_ROUTE_BROKER_COMMAND_JSON` contains a
JSON argv array. A Route call sends one JSON request on standard input and reads
one JSON response from standard output:

```python
command = json.loads(os.environ["AI_COSCIENTIST_ROUTE_BROKER_COMMAND_JSON"])
completed = subprocess.run(
    command,
    input=json.dumps({"route_ref": route_ref, "payload": payload}),
    text=True,
    capture_output=True,
    check=True,
)
route_result = json.loads(completed.stdout)["result"]
```

The broker variable is deliberately absent from the authoring terminal. Verify
broker integration through the formal immutable-project execution, not by
inventing local broker paths.

## Project Validation And Checkpoint

Prepare an executable version with focused checks, not a preliminary full run:

- parse or compile the relevant files with
  `development_project_validate_syntax`;
- use bounded structure queries for imports, symbols, calls, and exact refs;
- run bounded local commands for API signatures, serialization, and cheap
  implementation checks;
- confirm every generated Route request matches a currently bound exact schema.

Before checkpointing, inspect the source path that enforces every explicit hard
constraint. Confirm the constraint acts during the relevant computation rather
than being asserted or restored only after the computation. Also confirm that
canonical scientific objects are constructed by a validated library API when
one is available, or that a hand-built replacement has an explicit focused
check for the required geometry, topology, units, or invariants.

`development_project_terminal_*` runs in the same Runtime-managed scientific
environment as formal project execution, with a project-relative working
directory. It does not inject the Materializer job/result files or the optional
Route broker. Use it for bounded implementation diagnostics, not for package
installation. Follow the accompanying execution strategy to checkpoint and
perform the first full calculation, including its implementation test, through
formal execution. The checkpoint tool does not require a successful full run.

These tools check implementation mechanics; they do not decide whether the
scientific approximation is valid. Materializer remains responsible for that
judgment.

The current invocation lists completed checks for the current project revision.
Do not repeat the same syntax or structure check while that revision is
unchanged. Either run one different check tied to a remaining implementation
risk, edit the project and validate the new revision, or checkpoint it.

When source, dependencies, entry command, and optional Route bindings form one
executable version, call `development_project_checkpoint`.
Checkpoint only after the latest Route binding or project edit. Do not execute
the mutable worktree directly as the formal scientific result.
If execution rejects only input binding or dependency bookkeeping, correct that
binding or checkpoint metadata without changing the scientific program. An
already completed formal execution is reused for the same snapshot and job;
publication repair must use that observation, not initiate a new calculation.
