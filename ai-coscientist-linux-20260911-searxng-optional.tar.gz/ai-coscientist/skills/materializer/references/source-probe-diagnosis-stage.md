# Source Probe Diagnosis

The latest source probe failed or timed out. The source inventory and required
source pages have already been observed; do not restart source discovery.

Read only the exact failed probe refs that the current invocation still marks as
not read back:

- read the latest `code_ref` when its code has not been read back;
- read the latest `stderr_ref` when its error has not been read back.

These reads diagnose the existing probe. Do not reread the task definition,
historical source, or an already-read probe ref. Do not submit another probe until
both the failed code and error are visible.
