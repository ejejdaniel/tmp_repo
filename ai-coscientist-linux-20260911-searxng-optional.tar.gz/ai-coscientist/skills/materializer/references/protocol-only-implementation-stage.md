# Protocol-only Implementation Stage

The exact Protocol owns the quantity definition, required external inputs,
reference arithmetic, output id, unit, and interpretation boundary. Its
Markdown and any Specialist assessment are scientific guidance, not a finished
algorithm or prerequisite. Materializer owns Route selection, executable
dataflow, operational parameters, convergence work, implementation, testing,
and repair even when no Specialist assessment exists.

The accompanying execution-strategy page governs cost, method selection and
restart decisions. Specialist advice informs those choices but is optional.

Do not treat an absent default, initial value, discretization, search policy, or
convergence schedule as an upstream gap. Choose a defensible starting point,
test choices that can materially change the answer, and disclose uncertainty.
Return a bounded gap only when implementation evidence proves an indispensable
input, hard constraint, or capability genuinely absent or contradictory.

`AI_COSCIENTIST_MATERIALIZER_JOB` and
`AI_COSCIENTIST_MATERIALIZER_RESULT` contain filesystem paths, not inline JSON.
The entry program reads the JSON file named by the first path and writes
`{"result": result_object}` to the file named by the second path. Do not pass
either environment-variable value directly to a JSON parser. For Python, use
`Path(os.environ[...]).read_text(...)` and `Path(os.environ[...]).write_text(...)`.
Read the authoritative output identity directly from the mounted contract:

```python
contract = job["specification"]["machine_payload"]["result_contract"]
```

Do not retype or paraphrase `output_id` or `unit`. Copy both values from
`contract` into the result so packaging changes cannot invalidate an otherwise
completed calculation. Its result must contain the existing Protocol fields:

```json
{
  "output_id": "the Protocol result output_id",
  "value": "a finite JSON value",
  "unit": "the Protocol result unit"
}
```

The raw result may also contain diagnostic fields needed to inspect the
calculation, such as convergence traces, method details, alternate-unit values,
or stability checks. Runtime projects only `output_id`, `value`, and `unit`
into the public `computational_property_result`; the extra fields remain in the
execution workspace as diagnostic evidence.

The job supplies the exact Protocol under `specification`, formal
`input_bindings`, resolved `inputs`, `mode="computational_protocol"`, and any
records. An empty input-binding array is valid when the implementation can
construct task-defined inputs without a separate formal artifact.

Use one development project for new work. It may contain structure generation,
candidate enumeration, caching, parameter exploration, sensitivity analysis,
convergence checks, reduction, and reporting needed by the commissioned
quantity. A one-file program is simply the smallest project. The accompanying
project-operation page controls only authoring mechanics and does not prescribe
the scientific pipeline.

Managed Route invocation is optional and separate from the project environment.
Bind only exact Routes called by generated code, obey their disclosed schemas,
and preserve their receipts. Syntax, API usage, payload shape, serialization,
algorithm design, and local repair remain Materializer responsibility.
