# Completion Stage

Read back the exact published materialization artifact. Confirm it preserves the bound formula dependency and current code and observation provenance. Then return a short factual completion message; do not begin another formula inside this skill invocation.

