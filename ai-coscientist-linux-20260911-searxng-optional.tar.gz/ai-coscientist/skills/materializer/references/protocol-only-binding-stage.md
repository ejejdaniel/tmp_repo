# Primary Specification Binding

Materializer requires one unambiguous implementation commission. Bind one exact
`proxy_formula_candidate`, one exact `computational_property_protocol`, or a
coherent bundle of exact formal inputs that identifies one direct computational
result. Multiple unrelated Formula or Protocol candidates are not permission to
choose among research directions. An empty bundle or conflicting scientific
authorities is a bounded gap; name the missing or ambiguous exact ref.
