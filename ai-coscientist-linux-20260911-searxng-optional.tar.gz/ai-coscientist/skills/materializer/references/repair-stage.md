# Repair Stage

The normal page for the current implementation stage remains authoritative.
Repair the exact `current_issue`; do not replace the stage contract or repeat an
unchanged rejected call.

Use the frozen implementation specification, exact current implementation, failed
observation, and latest source-probe observation together. First decide whether
the failure comes from a wrong input model or from a local syntax, API, build,
serialization, or algorithm defect. If current evidence already identifies the
defective construct, edit that construct next. Probe again only when one
specific required fact is still absent.

For a timeout, resource limit, non-convergence, or unstable numerical path,
compare the failed implementation against the exact bound specification before
declaring a capability gap. Settings introduced only by the implementation are
not frozen scientific authority. Revise implementation-owned model size,
initialization, discretization, batching, solver strategy, or another auditable
choice within the specification's claim boundary, then execute the revision.
If completed expensive stages were not persisted, repair the project to save
and validate restartable stage state before retrying. If they were persisted,
resume from those exact states and do not repeat completed stages merely because
the prior formal command timed out.
Restart the node attempt only when the exact specification itself fixes every
material cost driver or all faithful implementation choices have been tried and
the required capability is genuinely absent.

For a `development_project_snapshot`, continue in the same mission-local
project. Inspect only the relevant tree, files, symbols, syntax evidence, and
terminal output. Edit the smallest responsible file set, run syntax or compiler
validation, and run the bounded command that reproduces the failure. Then
checkpoint a new immutable snapshot whose dependencies include the previous
snapshot and the same frozen scientific authorities. Execute that exact new
snapshot. Do not flatten a multi-file or non-Python project into a
`code_artifact` merely to enter repair.

If `development_project_write` is rejected because the path already exists,
the rejected call's complete `content` remains the authoritative intended
replacement for that repair. Use `development_project_edit`, not another
write. When the intended change is a coherent whole-file rewrite, read the
complete current file once and replace that exact body with the preserved
complete content in one edit. Do not reduce an already complete replacement to
a few helper definitions or recreate it from memory.

If formal execution proves that the fixed scientific environment lacks a
required package, executable, or native capability, preserve the failed
snapshot and return a bounded Runtime capability gap with the exact missing
dependency and observation. Do not install dependencies, switch environments,
open a duplicate project, or reinterpret the missing capability as a scientific
input gap. An optional managed Route may be used only when it is already visible
and faithfully implements the required operation; its absence does not prevent
direct use of installed libraries.

For a local defect in a legacy code artifact, use the complete current source
already shown in the focused stored-source block. Read it again only when that
block is absent or explicitly marked as a prefix. Call `edit_code_artifact` with the smallest unique `old_string` and its corrected `new_string`. One edit call
should repair one bounded construct. If several edits are needed, continue from
the newest immutable code ref. If an exact replacement cannot safely express
the correction, use `write_code_artifact` with the complete corrected source in `python_code`. Preserve the exact specification and previous code ref in
`depends_on`. A purpose description without edited code is not a repair.

An execution error tied to the current implementation, including a package import,
native-library, or scientific-API failure, remains a local
implementation defect unless exact environment inspection proves a required
capability absent. First replace the failing import or API with a supported
equivalent that preserves the frozen scientific concept, then repair and
re-execute the new immutable implementation. Do not respond to such an error by rereading completed source pages or relisting the source inventory.

Do not call `inspect_python_environment` for a development project. The project
terminal already observes the same fixed environment used by formal execution.
A `code_artifact:` or project snapshot ref is never an environment ref. Repair
the current implementation with project tools; report a bounded Runtime
capability gap only after a focused terminal diagnostic proves the dependency
is absent.

When an observation identifies a subset of record IDs with bad values or
unmatched members but not the source location, run one targeted `source_probe`
that compares failing and successful records and tests the suspected
correspondence. Once it localizes the defect, stop probing and repair. Replacing
an exception with an unresolved-results list does not repair the input model.

The legacy Python helper has the exact contract
`invoke_managed_route(route_ref, payload_mapping)`. A development project uses
the language-neutral command prefix in
`AI_COSCIENTIST_ROUTE_BROKER_COMMAND_JSON`. In either path, send one exact Route
ref and one payload matching its input schema. Do not inspect or reimplement the
broker. Route refs must remain auditable rather than being invented at runtime.
If a legacy execution error reports an unexpected keyword argument for the
helper, the defect is already localized: edit that call directly. Do not
write diagnostic production code or inspect the injected helper.

After a successful edit or project checkpoint, that ref is the current
implementation. Execute it next and inspect only its new observation. Call
`restart_node_attempt` only when focused evidence proves that faithful
implementation requires genuinely absent authoritative input or capability.
Put that exact evidence in `reason`; a repairable defect stays in the current
materialization work unit.

Each `source_probe` call is stateless. A retry must include complete corrected
probe code and exact source refs.
