# Source Probe Construction

The source inventory and the required definition/data pages have already been
read. The next action is one bounded `source_probe`; do not restart inventory,
reread the bound formula, or reread completed source pages.

The probe is a standalone Python script. Runtime prepends `SOURCE_ROOT` as an
existing `pathlib.Path` pointing at the copied-input directory. Use exact relative
paths from the source inventory; it is not an environment variable. Never assign, redefine, delete, or shadow
`SOURCE_ROOT`. Let source-access and parsing exceptions fail the probe rather than
printing an error object as successful output.

Print one compact JSON observation containing only facts needed to implement the
frozen formula:

- actual container types and paths, record count, relevant keys, collection
  lengths, and missingness;
- complete distinct keys, labels, or categorical values used by formula-bound
  fields, with compact frequencies;
- positional, key-based, or join correspondence evidence, including per-record
  length checks for parallel collections;
- unmatched members, conflicts, and a few counterexamples when correspondence is
  incomplete.

Use operations appropriate to observed containers: mappings may be enumerated
with `.items()`, sequences by position, and tables by grouped counts. Do not infer
scientific meaning from field spelling. Do not prove collection-wide coverage by
manually paging through the whole source.

Every `source_probe` call is independent and must contain complete `python_code`.
After a successful probe, read its exact `stdout_ref`. After a failed probe, read
its exact `code_ref` and `stderr_ref`; the repair page will then request one
complete corrected probe.
