# Source Inventory

The current invocation does not yet have authoritative source refs. Call
`source_inventory` once. Its result starts the file map for the rest of this
Materializer invocation.

Do not write implementation code or reread the bound formula at this stage.
After the inventory returns, continue from its exact refs. A broad inventory may
appear in the prompt as a bounded sample. If the required task source is not in
that sample, use the visible mission-workspace directory names to call
`source_inventory` with one narrower `relative_path`. Re-inventorying the same
path is allowed when contents changed or the earlier listing is unavailable.
