# Auxiliary-Condition Formula Target

This invocation materializes one exact auxiliary-condition formula. It uses the same numerical output contract as a final-KPI formula, but its target identity is distinct. Do not reuse a final-KPI formula, code result, observation, or materialization merely because the records are the same.

