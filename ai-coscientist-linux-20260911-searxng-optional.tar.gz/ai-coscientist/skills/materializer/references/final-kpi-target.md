# Final-KPI Formula Target

Implement the exact frozen formula only. The execution interface selects the
bound calculation table, while other task-scoped bodies, including scoring
targets, remain readable. Follow the accompanying execution-strategy guidance for faithful
implementation and self-checks. Do not estimate agreement, direction quality, or
scientific merit here. Success is a faithful per-record numerical materialization
with exact formula, code, and observation provenance.

Select `prepared_source_ref` explicitly on the execution tool. The Formula's
research source is not the runtime selection. For trend scoring, the selected
preparation must pair calculation records with separate comparison targets
through `evaluation_binding`; a public research table alone is insufficient.
If those bodies are absent, report the exact missing input to the main agent.
Re-executing a compatible Formula on prepared scoring data preserves the Formula
ref and creates a new result; never attach new targets to an old execution.

