# Source Evidence Reading

Use the exact refs shown in the current invocation and read only the missing
evidence needed to understand:

- what the formula-bound fields mean and how related collections correspond;
- the actual historical container shape and one complete record.

The task, goal, specification, or format source defines meaning. The sanitized
historical source establishes actual representation. The bound formula is already
resolved and must not be reread as a substitute for either authority.

Continue from the source-observation ledger. If it says the prompt contains only
a bounded inventory sample and the required source is absent, call
`source_inventory` once with a different, narrower `relative_path` selected from
the mission-workspace manifest. This is navigation, not a restart. Never search
the workspace for this skill's own `SKILL.md`; the loaded skill detail above is
already authoritative. A directory may be inventoried again when its contents
changed or the earlier listing is no longer available. Do not reread an
already-read page. If a page has a `next_line_offset`, use that exact
offset only when more of that source is necessary. When the frozen formula and
the source pages already read establish the needed meaning, shape, and
correspondence, proceed directly to implementation. Read a second source only
when one specific missing fact requires it. Use one
bounded `source_probe` only when a large or paged source, a collection-wide fact,
or an unresolved correspondence still prevents faithful implementation.
