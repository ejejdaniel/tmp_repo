# Project Setup

No mutable development project exists for this implementation yet.

Runtime has already assigned this run one fixed scientific environment. Call
`development_project_open` exactly once; do not select, install, or replace the
environment. The tool may resume one non-empty mutable project that
already covers every requested top-level formal specification. Supporting
evidence can differ between attempts and is merged into the resumed project's
dependencies. In that case, trust the returned project id, revision, entry
command, and latest checkpoint; do not create or overwrite its entry file. A
checkpoint is a recovery point, not a declaration that the mutable project is
finished. The returned environment ref is provenance recorded mechanically by
Runtime, not a model-authored setting.

An actually new project is empty. Use `working_directory="."` unless the
intended source layout genuinely needs a subdirectory. Use a portable entry command such
as `python main.py`.

Put the exact bound implementation specification, required input artifacts, pending capability
candidate artifacts, and previous implementation when repairing in
`depends_on`. Runtime records the fixed environment provenance automatically;
do not duplicate it merely for bookkeeping.

Do not list the new empty tree or reopen another project after a successful
receipt. Continue with the returned `project_id`.
