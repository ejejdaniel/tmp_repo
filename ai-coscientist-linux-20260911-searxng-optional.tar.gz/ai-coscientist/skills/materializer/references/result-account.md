# Result Account

Apply the accompanying Task Delivery And Evidence instruction to the task's requested
deliverables and actual inspected outputs. In Markdown, explain the result,
identify the exact evidence refs for supporting details, and distinguish measured
results, implemented constraints, and checks not performed. Keep the account
useful to its consumer without transcribing the entire execution record.

Before completing the invocation, read back the published result and verify that
its content and linked evidence meet the requested deliverable. If a requested
self-contained account or an exact evidence link is missing, correct the
publication from the same stored evidence. Do not repeat the calculation or
claim unperformed checks.
For an account-only correction, reuse the published artifact_id and the same
inspected execution observation. Publish a new immutable version, then read it
back; do not change the numerical payload or start another calculation.
