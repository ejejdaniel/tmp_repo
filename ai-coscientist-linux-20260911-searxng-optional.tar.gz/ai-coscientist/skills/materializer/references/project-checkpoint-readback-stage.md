# Project Checkpoint Readback

An immutable project checkpoint was created and its exact ref is shown in the
current invocation. Call `read_ref` on that ref now.

Do not edit, re-checkpoint, execute, or reopen a project before this readback.
The readback commits the exact files, environment, entry command, dependencies,
and snapshot identity into the current Materializer lineage. Formal execution
is disclosed after that transaction completes.
