# Protocol-only Repair

Repair only the current implementation defect. Preserve the exact Protocol,
input artifacts, previous implementation, Route refs, and pending candidate
refs in the new immutable implementation dependency chain.

For a development project, continue in the same project: inspect the relevant
files and symbols, edit the bounded defect, validate syntax or compilation, run
the focused terminal check, and checkpoint a new snapshot depending on the
previous snapshot. Execute that exact snapshot and inspect only its new
observation.

The accompanying execution strategy owns diagnosis, saved progress and
continuation after failure. Apply it before choosing another execution.

For the legacy single-file path, use `edit_code_artifact` for one localized correction. Use
`write_code_artifact` only when the correction cannot be represented safely as
one bounded edit. Then execute the new Code ref and inspect only its new
observation.

Preserve the Protocol's scientific definition, formal inputs, explicit hard
parameters, result expression, unit, and Route set. Repair implementation-owned
parameter choices, search strategy, convergence procedure, structure handling,
API use, and project code when they caused the failure. A poor initial choice is
not upstream failure. If execution evidence shows that immutable authority or an
indispensable capability is genuinely absent or contradictory, return a bounded
upstream gap instead of generating observations or a different property.
