# Binding Stage

Materializer automatically binds the only resolved proxy formula. If several proxy formulas are current, it instead requires one exact formula read immediately before skill selection. Without either unambiguous binding, do not inspect unrelated formulas or write code. Call `restart_node_attempt` and name the missing exact formula selection. This records the gap for the next bounded attempt or Graph rebuild.
