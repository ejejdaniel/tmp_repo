# Execution Stage

The active development project and the task source workspace are different
namespaces. Inspect implementation files such as `main.py` with
`development_project_tree`, `development_project_read`,
`development_project_search`, or `development_project_query_code`. Use
`source_*` tools only for authorized task inputs and source data; they cannot
read files inside the active development project.

For a project snapshot, call `scientific_materializer_run_project` with the
exact current `project_snapshot_ref`, bound Formula as `spec_artifact_ref`, an
empty `input_bindings` array, and the exact execution-wide
`max_route_calls`. For a legacy single-file implementation, call
`scientific_materializer_execute` with the exact current `code_artifact_ref` and
bound Formula as `formula_artifact_ref`. Never execute an implementation from
another Formula lineage. Both execution tools select this run's prepared data
through `prepared_source_ref`; choose the exact visible preparation, rather
than relying on the Formula's research dependencies. For project Formula mode,
the tool's `input_bindings` remains empty; Runtime projects the selected source
into the existing job input-binding list and `records`. Omit the source ref only
when using the legacy configured SourceSpec, not for autonomous prepared data.
Execution success is provisional until its exact observation passes inspection.

After an interruption, the accompanying interrupted-execution page governs
workspace inspection; the execution-strategy page governs the continuation
decision.

When the current code invokes a managed Route, also pass `max_route_calls` as
an explicit upper bound for the total planned Route calls across all records.
This is one execution-wide quota, not a per-Route or per-record value. Code that
does not invoke a managed Route must not request a Route-call quota.

The exact Route ref in `invoke_managed_route(route_ref, payload_mapping)` must
remain statically auditable. Write it directly as a string literal, or assign it
once to one plain variable and use that variable. Do not compute, reassign, or
receive the Route ref dynamically.

