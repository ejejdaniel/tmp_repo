from __future__ import annotations

from typing import Any, Mapping

from ai_coscientist.domain.proxy_formula_ranking import (
    terminal_proxy_formula_leaderboard,
    update_proxy_formula_leaderboard,
)


def run(payload: dict[str, Any], runtime: Any) -> dict[str, Any]:
    """Rank an exact execution while retaining the caller's existing review."""
    raw_inputs = payload.get("resolved_inputs", [])
    if not isinstance(raw_inputs, list):
        raise ValueError("rank_proxy_formula_resolved_inputs_invalid")
    resolved: dict[str, Mapping[str, Any]] = {}
    for raw in raw_inputs:
        if not isinstance(raw, Mapping):
            continue
        ref = str(raw.get("artifact_ref") or "")
        if not ref.startswith("artifact:") or ref in resolved:
            continue
        stored = runtime.read_artifact(ref)
        if stored.get("artifact_ref") != ref:
            raise ValueError(f"rank_proxy_formula_readback_ref_mismatch:{ref}")
        resolved[ref] = stored

    selected = {}
    for kind in (
        "proxy_formula_candidate",
        "quantitative_proxy_materialization_result",
        "scientific_method_review",
    ):
        matches = [item for item in resolved.values() if item.get("artifact_kind") == kind]
        if len(matches) != 1:
            return {
                "status": "bounded_gap",
                "reason": (
                    f"rank_proxy_formula_exact_input_required:{kind}:"
                    f"actual={len(matches)}:refs={[item['artifact_ref'] for item in matches]}"
                ),
            }
        selected[kind] = matches[0]
    formula = selected["proxy_formula_candidate"]
    if formula.get("machine_payload", {}).get("target_kind") != "final_kpi":
        raise ValueError(f"rank_proxy_formula_final_kpi_required:{formula['artifact_ref']}")

    board_ref = update_proxy_formula_leaderboard(
        runtime,
        formula=formula,
        materialization=selected["quantitative_proxy_materialization_result"],
        review=selected["scientific_method_review"],
        prior_leaderboard=terminal_proxy_formula_leaderboard(list(resolved.values())),
    )
    if not board_ref:
        raise RuntimeError("rank_proxy_formula_leaderboard_not_produced")
    runtime.read_artifact(board_ref)
    return {
        "status": "complete",
        "artifact_ref": board_ref,
        "summary": (
            f"Ranked {formula['artifact_ref']} using existing review "
            f"{selected['scientific_method_review']['artifact_ref']}; "
            f"leaderboard {board_ref}. No new scientific review."
        ),
    }
