---
name: rank-proxy-formula
description: Produces a FIRST or updated proxy_formula_leaderboard, keeping the supplied scientific_method_review unchanged. Requires one exact final-KPI formula, complete materialization and matching review; prior board is optional. Computes trend agreement without reassessing method quality. Boundary: no new review, implementation, source rebinding or workflow routing.
estimated_complexity: low

---

# Rank Proxy Formula

## Responsibility and boundary

Compute historical proxy-versus-target trend agreement and update the formula
leaderboard using an explicitly chosen, already published scientific review.
Do not reconsider that review's score, reason, or version. Reassessment of method
quality belongs to `review-scientific-method`; execution belongs to Materializer.
The coordinator decides whether either operation is needed, in the same Graph
node or separate nodes. This skill never prescribes the next action.

This is fit on an execution-selected dataset, not independent validation. The
public `review_score`, dataset-level `trend_alignment_score`, and per-record
`proxy_values_by_sample` remain distinct. The shared ranking implementation owns
the existing score calculation, Pareto tiers, and first-place selection.

## Entry conditions and authority

Use `resolved_inputs` to supply exactly one of each existing formal artifact:

- `proxy_formula_candidate` with `target_kind=final_kpi`;
- its complete `quantitative_proxy_materialization_result`;
- the chosen `scientific_method_review` of that exact Formula.

An explicit prior `proxy_formula_leaderboard` may accompany them to continue its
ranking history. Dependencies are readable evidence, not additional selected
methods, executions, or reviews. Do not search globally for a newer review or
infer selection from timestamps, titles, summaries, or scores. Multiple explicit
reviews are ambiguous, even if one has a larger version number. Missing selection
returns `bounded_gap`; it does not trigger another review.

Always read stored bodies through their exact refs. The materialization's exact
execution observation selects the prepared source and its `evaluation_binding`.
This binding joins calculation records to comparison targets; a separately passed
source cannot rebind previous calculations. New materialization identity requires
its own comparison observation. An unchanged exact pair on an explicit prior
board may reuse its comparison observation; existing shared validation still
checks identities, scope, and evidence before publishing any new board.

## Trigger examples

### Should select

- Update the formula leaderboard for exact Formula F and its new complete materialization M2, preserving the explicitly supplied method review R3. The execution-selected prepared data has a valid evaluation_binding, and the previous board is supplied. Do not reassess scientific quality.
- Establish trend agreement and a first leaderboard entry for one executed final-KPI formula using its supplied scientific_method_review and matching complete materialization. The execution's scoring data is ready; only scoring and ranking are needed.

### Should not select

- Reassess an existing formula's scientific quality against newly available public evidence and publish a new review score and reason.
- Calculate trend agreement for a formula that has no complete materialization and no scientific_method_review yet.

## Prompt and memory projection

- **C0:** the task and source restrictions orient the selected work; no target changes.
- **C1:** the active work unit and LOOP select this skill and its exact input refs.
- **C2:** Formula, materialization, selected review, prepared-data descriptor, and
  leaderboard remain immutable formal authorities; the new board cites them.
- **C3:** no private knowledge summary is maintained by this workflow. Common
  retains ordinary work continuity; summaries never replace the selected review.
- **C4:** source bodies and execution/comparison observations stay in their stores.
  The private evaluator returns aggregates, not raw target values to a model.
- **C5:** resolved inputs, comparison aggregates, and optional first-place choice
  are invocation-local values; discard after publication/readback.
- **C6:** Common records tool calls, optional model selection, and failures for
  diagnosis only; these logs are not normal skill inputs.

### LLM call contracts

No method-review model is called. With one Pareto-tier-one formula, this workflow
has no model call. Multiple nondominated formulas retain the existing shared
first-place selection; it chooses a ref without changing either score.

| Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
|---|---|---|---|---|---|---|---|
| `domain/proxy_formula_ranking.py` | `select-pareto-tier-one-proxy-formula`, only for multiple tier-one entries | Exact C2 formulas and reviews plus bounded C5 comparison aggregates; no raw KPI values or C6 | Choose the current first-place Formula within the existing Pareto front | Existing `{formula_artifact_ref, reason}` | Existing schema restricts ref to supplied candidates | Existing same-stage structured-output repair | Shared leaderboard ordering and publication |

## Skill-local workflow

1. Read selected formal inputs and verify exactly one Formula, execution result,
   and review. Retain the supplied review unchanged.
2. Call the shared `update_proxy_formula_leaderboard` operation. It invokes
   `scientific_private_proxy_evaluate` with `formula_artifact_ref` and
   `materialization_artifact_ref` only when a new comparison is needed.
3. Inspect new comparison evidence using `scientific_observation_inspect` with
   `observation_ref` and `selected_paths=["result"]`. Existing shared validation
   owns the exact formula/execution binding and aggregate consistency.
4. Retain the existing scoring and Pareto selection rules, publish the new board,
   and read it back. If the explicit board already contains the same exact pair
   and review, return/read that board instead of fabricating another result.

## Formal output and handoff

Return the existing workflow `{status, artifact_ref, summary}` result pointing to
`proxy_formula_leaderboard`. Its existing machine payload and `depends_on` record
the exact Formula, materialization, chosen review, comparison observation, and
prior board when supplied. Do not publish `scientific_method_review` or overwrite
old boards. Sample, Final LCA, reporting, and node evaluation consume the same
existing leaderboard format. Ranking does not itself prove any node or task done.

## Failure and repair

Missing or multiple required selections return `bounded_gap` with the kind and
actual refs. Wrong-method reviews, incomplete or mismatched executions, invalid
scoring bindings, and ambiguous board lineages use the shared exact validation
failures. Do not substitute another review, recreate a source, install a package,
rerun Materializer, or edit a graph. The main agent retains recovery authority.
Optional first-place selection uses only the existing local format repair.

## Validation evidence

- `tests/test_rank_proxy_formula.py`: exact existing review reuse, stored-body
  authority, absence of review calls, missing/ambiguous selection, execution
  replacement, unchanged comparison reuse, and shared Pareto behavior.
- Existing review tests and paginated workflow-host tests: new reviews still
  increment versions correctly after more than one catalog page.
- Route visibility tests: only the approved ranking and review skills gain
  private comparison access; researchers do not gain it.
- Real checkpoint replay: exercise production storage, scoped reads, comparison,
  publication, and downstream Sample input selection without hand-editing a board.
- Summary-only real-model selection and normal parent continuation test discovery
  and use. A replay or one completed node is not full end-to-end proof.
