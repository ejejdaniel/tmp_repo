from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from ai_coscientist.domain.scientific_content_deepening import (
    deepen_hypothesis_content,
)
from ai_coscientist.domain.data_use_authorization import (
    AuthorizedPreparedData,
    resolve_task_authorized_prepared_data,
)
from ai_coscientist.domain.prepared_sources import (
    PreparedSourceData,
    resolve_prepared_source_data,
)
from ai_coscientist.domain.research_modes import (
    ResearchMode,
    initial_research_inputs,
    reconciliation_projection,
    resolve_research_mode,
)


_PUBLIC_INPUT_KINDS = {
    "task_spec",
    "hypothesis_mind_map",
    "hypothesis",
    "proxy_formula_candidate",
    "proxy_formula_leaderboard",
    "hypothesis_leaderboard",
    "scientific_method_review",
}
_VISIBLE_INPUT_KINDS = _PUBLIC_INPUT_KINDS | {"prepared_source_data"}

_STAGE_REFERENCE_DIR = Path(__file__).with_name("references")
_EVIDENCE_AUTHORITY_PROMPT_FILE = "evidence-authority-contract.md"
_STAGE_PROMPT_FILES = {
    "authoring": "authoring-stage.md",
    "exploration_reconciliation": "exploration-reconciliation-stage.md",
    "premise_consistency": "premise-consistency-stage.md",
    "mechanism_verification": "mechanism-verification-stage.md",
    "private_redline_review": "private-redline-review-stage.md",
    "redline_repair": "redline-repair-stage.md",
    "identity_repair": "identity-repair-stage.md",
}

_PUBLIC_ASSET_AUTHORITY_RULES = {
    "hypothesis": {
        "authority_class": "provisional_scientific_method",
        "permitted_use": "occupied method, comparison target, or idea source",
        "claim_limit": "not empirical proof and not executed validation",
    },
    "proxy_formula_candidate": {
        "authority_class": "provisional_quantitative_proxy",
        "permitted_use": "quantitative clue, comparison target, or idea source",
        "claim_limit": "association or formula structure is not causal proof",
    },
    "proxy_formula_leaderboard": {
        "authority_class": "proxy_comparison_summary",
        "permitted_use": "compare already evaluated proxy candidates",
        "claim_limit": "ranking is not causal proof",
    },
    "hypothesis_leaderboard": {
        "authority_class": "method_comparison_summary",
        "permitted_use": "compare reviewed methods and identify occupied space",
        "claim_limit": "ranking is not empirical proof",
    },
    "scientific_method_review": {
        "authority_class": "review_opinion_and_gap_report",
        "permitted_use": "identify reviewer findings and evidence gaps",
        "claim_limit": "review judgment is not independent empirical evidence",
    },
}


def run(payload: dict[str, Any], runtime: Any) -> dict[str, Any]:
    """Author, assemble, publish, and read back one provisional hypothesis."""
    inputs = _visible_public_inputs(runtime, payload.get("resolved_inputs", []))
    research_mode = resolve_research_mode(
        payload,
        runtime,
        inputs,
        skill_id="hypothesis-gen",
    )
    task, mind_map = _coherent_required_inputs(inputs, runtime)
    authorized_data = resolve_task_authorized_prepared_data(
        runtime,
        task=task,
        resolved_inputs=inputs,
        consumer_skill_id="hypothesis-gen",
        require_grant=False,
    )
    prepared_source = (
        resolve_prepared_source_data(runtime, inputs, consumer="hypothesis")
        if authorized_data is None
        else None
    )
    family_ids = _family_ids(mind_map)
    task_id = str(task.get("machine_payload", {}).get("id") or "").strip()
    if not task_id:
        raise ValueError("hypothesis_task_id_missing")

    coherent_refs = {
        str(task["artifact_ref"]),
        str(mind_map["artifact_ref"]),
    }
    public_inputs = [
        item
        for item in inputs
        if str(item.get("artifact_kind") or "") in _PUBLIC_INPUT_KINDS
        and (
            str(item.get("artifact_kind") or "")
            not in {"task_spec", "hypothesis_mind_map"}
            or str(item.get("artifact_ref") or "") in coherent_refs
        )
    ]
    initial_public_inputs = initial_research_inputs(
        research_mode,
        public_inputs,
        shared_artifact_kinds=(
            "hypothesis",
            "proxy_formula_candidate",
            "proxy_formula_leaderboard",
            "hypothesis_leaderboard",
            "scientific_method_review",
        ),
        always_visible_artifact_kinds=("task_spec", "hypothesis_mind_map"),
    )
    source_refs = _unique_refs(public_inputs)
    if (
        authorized_data is not None
        and authorized_data.artifact_ref not in source_refs
    ):
        source_refs.append(authorized_data.artifact_ref)
    if prepared_source is not None:
        source_refs.append(prepared_source.artifact_ref)
    required_refs = set(coherent_refs)
    if prepared_source is not None:
        required_refs.add(prepared_source.artifact_ref)
    if authorized_data is not None:
        required_refs.add(authorized_data.artifact_ref)
    if not required_refs.issubset(source_refs):
        raise ValueError("hypothesis_required_source_refs_missing")

    authoring_schema = _authoring_schema(family_ids=family_ids)
    scientific = runtime.generate_json(
        _stage_prompt("authoring"),
        _authoring_context(
            payload=payload,
            task=task,
            mind_map=mind_map,
            public_inputs=initial_public_inputs,
            required_refs=required_refs,
            authorized_data=authorized_data,
            prepared_source=prepared_source,
            research_mode=research_mode,
        ),
        purpose="author-provisional-hypothesis",
        schema=authoring_schema,
    )
    scientific = _reconcile_explore_candidate(
        runtime,
        scientific=scientific,
        research_mode=research_mode,
        task=task,
        mind_map=mind_map,
        public_inputs=public_inputs,
        authorized_data=authorized_data,
        prepared_source=prepared_source,
        authoring_schema=authoring_schema,
    )
    scientific = deepen_hypothesis_content(
        runtime,
        draft=scientific,
        shared_research_assets=_deepening_research_assets(
            task=task,
            mind_map=mind_map,
            public_inputs=public_inputs,
            family_id=_hypothesis_family_id(scientific),
            authorized_data=authorized_data,
            prepared_source=prepared_source,
            research_mode=research_mode,
        ),
        schema=authoring_schema,
        purpose_prefix="hypothesis",
        consistency_prompt=_stage_prompt("premise_consistency"),
        deepening_prompt=_stage_prompt("mechanism_verification"),
    )
    scientific = _review_and_repair_hypothesis(
        runtime,
        scientific=scientific,
        task=task,
        mind_map=mind_map,
        public_inputs=public_inputs,
        authorized_data=authorized_data,
        prepared_source=prepared_source,
        authoring_schema=authoring_schema,
    )
    reviewed_id = _hypothesis_id(scientific, task_id=task_id)
    scientific = _repair_exact_identity_collision(
        runtime,
        scientific=scientific,
        task_id=task_id,
        task=task,
        mind_map=mind_map,
        public_inputs=public_inputs,
        authorized_data=authorized_data,
        prepared_source=prepared_source,
        authoring_schema=authoring_schema,
    )
    if _hypothesis_id(scientific, task_id=task_id) != reviewed_id:
        scientific = deepen_hypothesis_content(
            runtime,
            draft=scientific,
            shared_research_assets=_deepening_research_assets(
                task=task,
                mind_map=mind_map,
                public_inputs=public_inputs,
                family_id=_hypothesis_family_id(scientific),
                authorized_data=authorized_data,
                prepared_source=prepared_source,
                research_mode=research_mode,
            ),
            schema=authoring_schema,
            purpose_prefix="hypothesis-identity-repair",
            consistency_prompt=_stage_prompt("premise_consistency"),
            deepening_prompt=_stage_prompt("mechanism_verification"),
        )
        scientific = _review_and_repair_hypothesis(
            runtime,
            scientific=scientific,
            task=task,
            mind_map=mind_map,
            public_inputs=public_inputs,
            authorized_data=authorized_data,
            prepared_source=prepared_source,
            authoring_schema=authoring_schema,
        )
    _assert_exact_identity_available(
        scientific,
        task_id=task_id,
        public_inputs=public_inputs,
    )
    machine_payload = {
        "artifact_kind": "hypothesis",
        "id": _hypothesis_id(scientific, task_id=task_id),
        "task_id": task_id,
        "title": str(scientific["title"]),
        "description": str(scientific["description"]),
        "mechanism": str(scientific["mechanism"]),
        "core_claim": str(scientific["core_claim"]),
        "risks": list(scientific["risks"]),
        "verification_plan": list(scientific["verification_plan"]),
        "source_refs": source_refs,
        "direction_card": dict(scientific["direction_card"]),
    }
    markdown = _render_markdown(machine_payload)
    summary = str(machine_payload["description"])[:500]

    receipt = runtime.publish_artifact(
        artifact_kind="hypothesis",
        artifact_id=str(machine_payload["id"]),
        title=str(machine_payload["title"]),
        markdown=markdown,
        summary=summary,
        status="proposed",
        machine_payload=machine_payload,
        depends_on=source_refs,
    )
    artifact_ref = str(receipt["artifact_ref"])
    stored = runtime.read_artifact(artifact_ref)
    _validate_readback(
        stored,
        required_refs=required_refs,
        family_ids=set(family_ids),
    )
    return {
        "status": "complete",
        "artifact_ref": artifact_ref,
        "summary": summary,
    }


_PRIVATE_REVIEW_CARD_SCHEMA = {
    "type": "object",
    "properties": {
        "score": {"type": "integer", "enum": [0, 1, 2, 3, 4]},
        "reason": {"type": "string", "minLength": 1, "maxLength": 1200},
    },
    "required": ["score", "reason"],
    "additionalProperties": False,
}

_PRIVATE_REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "mechanism": _PRIVATE_REVIEW_CARD_SCHEMA,
        "evidence_boundary": _PRIVATE_REVIEW_CARD_SCHEMA,
        "testability": _PRIVATE_REVIEW_CARD_SCHEMA,
    },
    "required": ["mechanism", "evidence_boundary", "testability"],
    "additionalProperties": False,
}


def _stage_prompt(stage: str) -> str:
    filename = _STAGE_PROMPT_FILES.get(stage)
    if filename is None:
        raise KeyError(f"hypothesis_stage_prompt_unknown:{stage}")
    contract_path = _STAGE_REFERENCE_DIR / _EVIDENCE_AUTHORITY_PROMPT_FILE
    contract = contract_path.read_text(encoding="utf-8").strip()
    path = _STAGE_REFERENCE_DIR / filename
    text = path.read_text(encoding="utf-8").strip()
    if not contract:
        raise ValueError("hypothesis_evidence_authority_prompt_empty")
    if not text:
        raise ValueError(f"hypothesis_stage_prompt_empty:{stage}")
    return f"{contract}\n\n{text}"


def _reconcile_explore_candidate(
    runtime: Any,
    *,
    scientific: Mapping[str, Any],
    research_mode: ResearchMode,
    task: Mapping[str, Any],
    mind_map: Mapping[str, Any],
    public_inputs: Sequence[Mapping[str, Any]],
    authorized_data: AuthorizedPreparedData | None,
    prepared_source: PreparedSourceData | None,
    authoring_schema: Mapping[str, Any],
) -> dict[str, Any]:
    if research_mode.research_strategy != "explore":
        return dict(scientific)
    return dict(
        runtime.generate_json(
            _stage_prompt("exploration_reconciliation"),
            json.dumps(
                {
                    "research_mode": reconciliation_projection(research_mode),
                    "independent_candidate": {
                        "authority_class": "provisional_independent_draft",
                        "content": dict(scientific),
                    },
                    "evidence_authority": _hypothesis_evidence_authority(
                        task=task,
                        mind_map=mind_map,
                        public_inputs=_exploration_occupancy_inputs(
                            public_inputs
                        ),
                        authorized_data=authorized_data,
                        prepared_source=prepared_source,
                    ),
                },
                ensure_ascii=False,
                indent=2,
            ),
            purpose="hypothesis-exploration-reconciliation",
            schema=dict(authoring_schema),
        )
    )


def _review_and_repair_hypothesis(
    runtime: Any,
    *,
    scientific: Mapping[str, Any],
    task: Mapping[str, Any],
    mind_map: Mapping[str, Any],
    public_inputs: Sequence[Mapping[str, Any]],
    authorized_data: AuthorizedPreparedData | None,
    prepared_source: PreparedSourceData | None,
    authoring_schema: Mapping[str, Any],
) -> dict[str, Any]:
    candidate = dict(scientific)
    reviews = _review_hypothesis(
        runtime,
        candidate=candidate,
        task=task,
        mind_map=mind_map,
        public_inputs=public_inputs,
        authorized_data=authorized_data,
        prepared_source=prepared_source,
        purpose_prefix="hypothesis-private",
    )
    redlines = _redline_reasons(reviews)
    if not redlines:
        return candidate

    family_id = _hypothesis_family_id(candidate)
    repaired = runtime.generate_json(
        _stage_prompt("redline_repair"),
        json.dumps(
            {
                "review_findings": redlines,
                "candidate_to_repair": {
                    "authority_class": "provisional_model_output_under_repair",
                    "content": candidate,
                },
                "evidence_authority": _hypothesis_evidence_authority(
                    task=task,
                    mind_map=mind_map,
                    family_id=family_id,
                    public_inputs=public_inputs,
                    authorized_data=authorized_data,
                    prepared_source=prepared_source,
                ),
            },
            ensure_ascii=False,
            indent=2,
        ),
        purpose="repair-hypothesis-private-redline",
        schema=dict(authoring_schema),
        repair_call=True,
    )
    repeated = _review_hypothesis(
        runtime,
        candidate=repaired,
        task=task,
        mind_map=mind_map,
        public_inputs=public_inputs,
        authorized_data=authorized_data,
        prepared_source=prepared_source,
        purpose_prefix="recheck-hypothesis-private",
    )
    remaining = _redline_reasons(repeated)
    if remaining:
        raise ValueError(
            "hypothesis_private_redline_after_local_repair:"
            + "; ".join(remaining)
        )
    return dict(repaired)


def _repair_exact_identity_collision(
    runtime: Any,
    *,
    scientific: Mapping[str, Any],
    task_id: str,
    task: Mapping[str, Any],
    mind_map: Mapping[str, Any],
    public_inputs: Sequence[Mapping[str, Any]],
    authorized_data: AuthorizedPreparedData | None,
    prepared_source: PreparedSourceData | None,
    authoring_schema: Mapping[str, Any],
) -> dict[str, Any]:
    occupied = _occupied_hypothesis_by_id(public_inputs)
    candidate = dict(scientific)
    candidate_id = _hypothesis_id(candidate, task_id=task_id)
    if candidate_id not in occupied:
        return candidate

    repaired = runtime.generate_json(
        _stage_prompt("identity_repair"),
        json.dumps(
            {
                "candidate_to_replace": {
                    "authority_class": "provisional_model_output_with_identity_collision",
                    "content": candidate,
                },
                "occupied_hypothesis": _public_asset_authority_projection(
                    occupied[candidate_id]
                ),
                "evidence_authority": _hypothesis_evidence_authority(
                    task=task,
                    mind_map=mind_map,
                    family_id=_hypothesis_family_id(candidate),
                    public_inputs=public_inputs,
                    authorized_data=authorized_data,
                    prepared_source=prepared_source,
                ),
            },
            ensure_ascii=False,
            indent=2,
        ),
        purpose="repair-hypothesis-exact-identity-collision",
        schema=dict(authoring_schema),
        repair_call=True,
    )
    repaired_id = _hypothesis_id(repaired, task_id=task_id)
    if repaired_id in occupied:
        raise ValueError(
            "hypothesis_exact_identity_collision_after_local_repair:"
            f"{repaired_id}"
        )
    return dict(repaired)


def _occupied_hypothesis_by_id(
    public_inputs: Sequence[Mapping[str, Any]],
) -> dict[str, dict[str, Any]]:
    occupied: dict[str, dict[str, Any]] = {}
    for artifact in public_inputs:
        if artifact.get("artifact_kind") != "hypothesis":
            continue
        payload = artifact.get("machine_payload")
        if not isinstance(payload, Mapping):
            continue
        method_id = str(payload.get("id") or "").strip()
        if method_id:
            occupied.setdefault(method_id, dict(artifact))
    return occupied


def _assert_exact_identity_available(
    scientific: Mapping[str, Any],
    *,
    task_id: str,
    public_inputs: Sequence[Mapping[str, Any]],
) -> None:
    candidate_id = _hypothesis_id(scientific, task_id=task_id)
    if candidate_id in _occupied_hypothesis_by_id(public_inputs):
        raise ValueError(
            "hypothesis_exact_identity_collision_after_review:"
            f"{candidate_id}"
        )


def _review_hypothesis(
    runtime: Any,
    *,
    candidate: Mapping[str, Any],
    task: Mapping[str, Any],
    mind_map: Mapping[str, Any],
    public_inputs: Sequence[Mapping[str, Any]],
    authorized_data: AuthorizedPreparedData | None,
    prepared_source: PreparedSourceData | None,
    purpose_prefix: str,
) -> list[dict[str, Any]]:
    result = runtime.generate_json(
        _stage_prompt("private_redline_review"),
        json.dumps(
            _private_review_context(
                candidate=candidate,
                task=task,
                mind_map=mind_map,
                public_inputs=public_inputs,
                authorized_data=authorized_data,
                prepared_source=prepared_source,
            ),
            ensure_ascii=False,
            indent=2,
        ),
        purpose=f"{purpose_prefix}-redline-review",
        schema=_PRIVATE_REVIEW_SCHEMA,
    )
    return [
        {
            "dimension": dimension,
            "score": int(result[key]["score"]),
            "reason": str(result[key]["reason"]),
        }
        for dimension, key in (
            ("mechanism", "mechanism"),
            ("evidence-boundary", "evidence_boundary"),
            ("testability", "testability"),
        )
    ]


def _redline_reasons(reviews: Sequence[Mapping[str, Any]]) -> list[str]:
    return [
        f"{review.get('dimension')}:{review.get('reason')}"
        for review in reviews
        if review.get("score") == 0
    ]


def _authoring_context(
    *,
    payload: Mapping[str, Any],
    task: Mapping[str, Any],
    mind_map: Mapping[str, Any],
    public_inputs: Sequence[Mapping[str, Any]],
    required_refs: set[str],
    authorized_data: AuthorizedPreparedData | None,
    prepared_source: PreparedSourceData | None,
    research_mode: ResearchMode,
) -> str:
    return json.dumps(
        {
            "research_mode": research_mode.prompt_projection(),
            "work_request": {
                "authority_class": "formal_current_work_request",
                "objective": str(payload.get("objective") or ""),
                "completion_condition": str(
                    payload.get("evaluation_summary") or ""
                ),
            },
            "host_managed_lineage": {
                "authority_class": "transport_only_not_scientific_evidence",
                "required_refs": sorted(required_refs),
            },
            "evidence_authority": _hypothesis_evidence_authority(
                task=task,
                mind_map=mind_map,
                public_inputs=public_inputs,
                authorized_data=authorized_data,
                prepared_source=prepared_source,
            ),
        },
        ensure_ascii=False,
        indent=2,
    )


def _authoring_schema(*, family_ids: Sequence[str]) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "title": {"type": "string", "minLength": 1, "maxLength": 240},
            "description": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2400,
            },
            "mechanism": {
                "type": "string",
                "minLength": 1,
                "maxLength": 4000,
            },
            "core_claim": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000,
            },
            "risks": {
                "type": "array",
                "minItems": 1,
                "maxItems": 6,
                "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 1600,
                },
            },
            "verification_plan": {
                "type": "array",
                "minItems": 1,
                "maxItems": 8,
                "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 3200,
                },
            },
            "direction_card": {
                "type": "object",
                "properties": {
                    "family_id": {
                        "type": "string",
                        "enum": list(family_ids),
                    },
                    "lineage_role": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 700,
                    },
                },
                "required": ["family_id", "lineage_role"],
                "additionalProperties": False,
            },
        },
        "required": [
            "title",
            "description",
            "mechanism",
            "core_claim",
            "risks",
            "verification_plan",
            "direction_card",
        ],
        "additionalProperties": False,
    }


def _render_markdown(payload: Mapping[str, Any]) -> str:
    risks = "\n".join(f"- {item}" for item in payload["risks"])
    verification = "\n".join(
        f"- {item}" for item in payload["verification_plan"]
    )
    return (
        f"# {payload['title']}\n\n"
        "**Status:** Provisional; no unreferenced validation is claimed.\n\n"
        f"## Description\n{payload['description']}\n\n"
        f"## Mechanism\n{payload['mechanism']}\n\n"
        f"## Core claim\n{payload['core_claim']}\n\n"
        f"## Principal risks\n{risks}\n\n"
        f"## Validation intentions\n{verification}\n"
    )


def _hypothesis_id(
    scientific: Mapping[str, Any],
    *,
    task_id: str,
) -> str:
    direction = scientific.get("direction_card")
    family_id = (
        str(direction.get("family_id") or "")
        if isinstance(direction, Mapping)
        else ""
    )
    identity = json.dumps(
        {
            "task_id": task_id,
            "family_id": family_id,
            "title": scientific.get("title"),
            "mechanism": scientific.get("mechanism"),
            "core_claim": scientific.get("core_claim"),
        },
        ensure_ascii=False,
        sort_keys=True,
    )
    digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:12]
    return f"hypothesis-{family_id.lower()}-{digest}"


def _visible_public_inputs(
    runtime: Any,
    raw_inputs: Any,
) -> list[dict[str, Any]]:
    if not isinstance(raw_inputs, list):
        raise ValueError("hypothesis_resolved_inputs_invalid")
    by_ref: dict[str, dict[str, Any]] = {}

    def add(raw: Mapping[str, Any]) -> None:
        kind = str(raw.get("artifact_kind") or "").strip()
        if kind not in _VISIBLE_INPUT_KINDS:
            return
        artifact_ref = str(raw.get("artifact_ref") or "").strip()
        if not artifact_ref.startswith("artifact:"):
            raise ValueError("hypothesis_visible_artifact_ref_invalid")
        if artifact_ref in by_ref:
            return
        artifact = dict(raw)
        if not isinstance(artifact.get("machine_payload"), Mapping):
            artifact = dict(runtime.read_artifact(artifact_ref))
        if artifact.get("artifact_ref") != artifact_ref:
            raise ValueError("hypothesis_visible_artifact_ref_mismatch")
        if artifact.get("artifact_kind") != kind:
            raise ValueError("hypothesis_visible_artifact_kind_mismatch")
        if not isinstance(artifact.get("machine_payload"), Mapping):
            raise ValueError("hypothesis_visible_artifact_payload_required")
        by_ref[artifact_ref] = artifact

    for raw in raw_inputs:
        if isinstance(raw, Mapping):
            add(raw)
    return list(by_ref.values())


def _coherent_required_inputs(
    inputs: Sequence[Mapping[str, Any]],
    runtime: Any,
) -> tuple[dict[str, Any], dict[str, Any]]:
    mind_maps = [
        dict(item)
        for item in inputs
        if item.get("artifact_kind") == "hypothesis_mind_map"
    ]
    tasks = {
        str(item.get("artifact_ref") or ""): dict(item)
        for item in inputs
        if item.get("artifact_kind") == "task_spec"
    }
    matches: list[tuple[dict[str, Any], dict[str, Any]]] = []
    for mind_map in mind_maps:
        for task_ref, task in tasks.items():
            if not _artifact_ancestry_contains(
                runtime,
                artifact=mind_map,
                target_ref=task_ref,
            ):
                continue
            matches.append((task, mind_map))
    if len(matches) > 1:
        matching_mind_map_refs = {
            str(match[1].get("artifact_ref") or "") for match in matches
        }
        superseded_refs = {
            str(ref)
            for _task, mind_map in matches
            for ref in mind_map.get("depends_on", [])
            if str(ref) in matching_mind_map_refs
        }
        matches = [
            match
            for match in matches
            if str(match[1].get("artifact_ref") or "") not in superseded_refs
        ]
    if len(matches) != 1:
        raise ValueError(
            "hypothesis_coherent_input_lineage_required:"
            f"matches={len(matches)}"
        )
    return matches[0]


def _artifact_ancestry_contains(
    runtime: Any,
    *,
    artifact: Mapping[str, Any],
    target_ref: str,
) -> bool:
    """Follow only exact, visible artifact dependencies to one ancestor."""
    pending = [
        str(ref).strip()
        for ref in artifact.get("depends_on", [])
        if str(ref).strip().startswith("artifact:")
    ]
    seen: set[str] = set()
    while pending:
        dependency_ref = pending.pop(0)
        if dependency_ref == target_ref:
            return True
        if dependency_ref in seen:
            continue
        seen.add(dependency_ref)
        is_visible = getattr(runtime, "is_ref_visible", None)
        if callable(is_visible) and not is_visible(dependency_ref):
            continue
        dependency = runtime.read_artifact(dependency_ref)
        pending.extend(
            str(ref).strip()
            for ref in dependency.get("depends_on", [])
            if str(ref).strip().startswith("artifact:")
            and str(ref).strip() not in seen
        )
    return False


def _family_ids(mind_map: Mapping[str, Any]) -> list[str]:
    payload = mind_map.get("machine_payload")
    landscape = (
        payload.get("mechanism_landscape")
        if isinstance(payload, Mapping)
        else None
    )
    families = (
        landscape.get("families")
        if isinstance(landscape, Mapping)
        else None
    )
    ids = [
        str(item.get("family_id") or "").strip()
        for item in (families or [])
        if isinstance(item, Mapping)
        and str(item.get("family_id") or "").strip()
    ]
    unique = list(dict.fromkeys(ids))
    if not unique:
        raise ValueError("hypothesis_mind_map_family_ids_required")
    return unique


def _unique_refs(inputs: Sequence[Mapping[str, Any]]) -> list[str]:
    refs = [
        str(item.get("artifact_ref") or "").strip()
        for item in inputs
        if str(item.get("artifact_ref") or "").startswith("artifact:")
    ]
    return list(dict.fromkeys(refs))


def _hypothesis_family_id(candidate: Mapping[str, Any]) -> str:
    direction = candidate.get("direction_card")
    if not isinstance(direction, Mapping):
        raise ValueError("hypothesis_direction_card_required")
    family_id = str(direction.get("family_id") or "").strip()
    if not family_id:
        raise ValueError("hypothesis_family_id_required")
    return family_id


def _task_science_projection(artifact: Mapping[str, Any]) -> dict[str, Any]:
    payload = artifact.get("machine_payload")
    if not isinstance(payload, Mapping):
        raise ValueError("hypothesis_task_payload_required")
    return {
        "artifact_ref": artifact.get("artifact_ref"),
        "artifact_kind": artifact.get("artifact_kind"),
        "task_contract": _bounded_payload(dict(payload), 18_000),
    }


def _mind_map_landscape(mind_map: Mapping[str, Any]) -> Mapping[str, Any]:
    payload = mind_map.get("machine_payload")
    landscape = (
        payload.get("mechanism_landscape")
        if isinstance(payload, Mapping)
        else None
    )
    if not isinstance(landscape, Mapping):
        raise ValueError("hypothesis_mind_map_landscape_required")
    return landscape


def _mind_map_family_projection(family: Mapping[str, Any]) -> dict[str, Any]:
    identity = {
        key: family[key]
        for key in ("family_id", "title")
        if key in family and family[key] not in (None, "", [], {})
    }
    method_embryo = {
        str(key): value
        for key, value in family.items()
        if key not in {"family_id", "title"}
        and value not in (None, "", [], {})
    }
    return {
        "formal_family_identity": _bounded_payload(identity, 2_000),
        "provisional_method_embryo": _bounded_payload(
            method_embryo,
            12_000,
        ),
    }


def _mind_map_research_projection(
    mind_map: Mapping[str, Any],
    *,
    family_id: str | None = None,
) -> dict[str, Any]:
    landscape = _mind_map_landscape(mind_map)
    families = landscape.get("families")
    selected = [
        dict(item)
        for item in (families or [])
        if isinstance(item, Mapping)
        and (
            family_id is None
            or str(item.get("family_id") or "").strip() == family_id
        )
    ]
    if family_id is not None and len(selected) != 1:
        raise ValueError(
            "hypothesis_selected_family_required:"
            f"family_id={family_id};matches={len(selected)}"
        )
    return {
        "artifact_ref": mind_map.get("artifact_ref"),
        "artifact_kind": mind_map.get("artifact_kind"),
        "authority_class": "accepted_research_map",
        "family_identity_rule": (
            "family_id and title are the formal map identity"
        ),
        "method_content_rule": (
            "method embryos and relationships are research directions, "
            "not empirical proof"
        ),
        "selection_scope": family_id or "all_visible_families",
        "families": [
            _mind_map_family_projection(item) for item in selected
        ],
        "landscape_summary": landscape.get("mechanism_landscape_summary"),
        "supported_relationships": _bounded_payload(
            landscape.get("supported_relationships", []),
            8_000,
        ),
    }


def _mind_map_unknowns_projection(
    mind_map: Mapping[str, Any],
) -> dict[str, Any]:
    landscape = _mind_map_landscape(mind_map)
    return {
        "artifact_ref": mind_map.get("artifact_ref"),
        "authority_class": "accepted_evidence_boundary",
        "permitted_use": (
            "preserve stated gaps and limits until exact public evidence "
            "resolves them"
        ),
        "unresolved_gaps": _bounded_payload(
            landscape.get("unresolved_gaps", []),
            8_000,
        ),
        "evidence_boundary_summary": landscape.get(
            "evidence_boundary_summary"
        ),
    }


def _public_asset_authority_projection(
    artifact: Mapping[str, Any],
) -> dict[str, Any]:
    kind = str(artifact.get("artifact_kind") or "")
    rule = _PUBLIC_ASSET_AUTHORITY_RULES.get(kind)
    if rule is None:
        raise ValueError(
            f"hypothesis_public_asset_authority_unknown:{kind}"
        )
    return {
        **dict(rule),
        "content": _bounded_artifact(artifact),
    }


def _other_public_research_assets(
    public_inputs: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    artifacts = [
        item
        for item in public_inputs
        if item.get("artifact_kind")
        not in {"task_spec", "hypothesis_mind_map"}
    ]
    if not artifacts:
        return []
    per_item = max(1_500, 36_000 // len(artifacts))
    return [
        _bounded_payload(
            _public_asset_authority_projection(item),
            per_item,
        )
        for item in artifacts
    ]


def _exploration_occupancy_inputs(
    public_inputs: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Project only artifacts that define occupied hypothesis space."""
    return [
        dict(item)
        for item in public_inputs
        if str(item.get("artifact_kind") or "")
        in {"hypothesis", "hypothesis_leaderboard"}
    ]


def _authorized_task_data_projection(
    authorized_data: AuthorizedPreparedData | None,
) -> dict[str, Any]:
    if authorized_data is None:
        return {
            "authority_class": "not_authorized",
            "permitted_use": "none",
            "claim_limit": (
                "Dedicated evaluation-target bodies are unavailable without a task grant. "
                "This does not withhold ordinary prepared research data."
            ),
            "content": None,
        }
    return authorized_data.prompt_projection()


def _hypothesis_evidence_authority(
    *,
    task: Mapping[str, Any],
    mind_map: Mapping[str, Any],
    public_inputs: Sequence[Mapping[str, Any]],
    authorized_data: AuthorizedPreparedData | None,
    prepared_source: PreparedSourceData | None,
    family_id: str | None = None,
) -> dict[str, Any]:
    return {
        "formal_task_contract": {
            "authority_class": "formal_scientific_contract",
            "permitted_use": (
                "define the objective, constraints, visibility boundary, "
                "and requested result"
            ),
            "claim_limit": "the task statement is not empirical proof",
            "content": _task_science_projection(task),
        },
        "mind_map_research_space": _mind_map_research_projection(
            mind_map,
            family_id=family_id,
        ),
        "known_unknowns": _mind_map_unknowns_projection(mind_map),
        "ordinary_prepared_data": (
            {
                "authority_class": "prepared_source_observations",
                "permitted_use": "data-informed research within the task boundary",
                "claim_limit": (
                    "Observed association is not causal proof or independent validation. "
                    "Paired scoring targets are readable task data, not automatically private."
                ),
                "content": prepared_source.prompt_projection(),
            }
            if prepared_source is not None
            else None
        ),
        "authorized_task_data": _authorized_task_data_projection(
            authorized_data
        ),
        "other_public_research_assets": _other_public_research_assets(
            public_inputs
        ),
    }


def _deepening_research_assets(
    *,
    task: Mapping[str, Any],
    mind_map: Mapping[str, Any],
    public_inputs: Sequence[Mapping[str, Any]],
    family_id: str,
    authorized_data: AuthorizedPreparedData | None,
    prepared_source: PreparedSourceData | None,
    research_mode: ResearchMode,
) -> list[dict[str, Any]]:
    return [
        {
            "research_mode": reconciliation_projection(research_mode),
            "evidence_authority": _hypothesis_evidence_authority(
                task=task,
                mind_map=mind_map,
                public_inputs=public_inputs,
                family_id=family_id,
                authorized_data=authorized_data,
                prepared_source=prepared_source,
            )
        }
    ]


def _private_review_context(
    *,
    candidate: Mapping[str, Any],
    task: Mapping[str, Any],
    mind_map: Mapping[str, Any],
    public_inputs: Sequence[Mapping[str, Any]],
    authorized_data: AuthorizedPreparedData | None,
    prepared_source: PreparedSourceData | None,
) -> dict[str, Any]:
    family_id = _hypothesis_family_id(candidate)
    return {
        "evidence_authority": _hypothesis_evidence_authority(
            task=task,
            mind_map=mind_map,
            public_inputs=public_inputs,
            family_id=family_id,
            authorized_data=authorized_data,
            prepared_source=prepared_source,
        ),
        "candidate_draft": {
            "authority_class": "provisional_model_output_under_review",
            "content": dict(candidate),
        },
    }


def _bounded_artifact(artifact: Mapping[str, Any]) -> dict[str, Any]:
    projected = {
        "artifact_ref": artifact.get("artifact_ref"),
        "artifact_kind": artifact.get("artifact_kind"),
        "title": artifact.get("title"),
        "summary": artifact.get("summary"),
        "depends_on": artifact.get("depends_on", []),
        "machine_payload": artifact.get("machine_payload", {}),
    }
    text = json.dumps(projected, ensure_ascii=False)
    if len(text) <= 14_000:
        return projected
    projected["machine_payload"] = _bounded_payload(
        projected["machine_payload"], 11_000
    )
    return projected


def _bounded_artifact_batch(
    artifacts: Sequence[Mapping[str, Any]],
    *,
    total_limit: int = 56_000,
) -> list[dict[str, Any]]:
    if not artifacts:
        return []
    per_item = max(1_500, total_limit // len(artifacts))
    return [
        _bounded_payload(_bounded_artifact(item), per_item)
        for item in artifacts
    ]


def _bounded_payload(value: Any, limit: int) -> Any:
    text = json.dumps(value, ensure_ascii=False)
    if len(text) <= limit:
        return value
    if isinstance(value, Mapping):
        return {
            str(key): _bounded_payload(item, max(300, limit // max(len(value), 1)))
            for key, item in list(value.items())[:20]
        }
    if isinstance(value, list):
        return [
            _bounded_payload(item, max(300, limit // max(len(value), 1)))
            for item in value[:20]
        ]
    return str(value)[:limit]


def _validate_readback(
    stored: Mapping[str, Any],
    *,
    required_refs: set[str],
    family_ids: set[str],
) -> None:
    if stored.get("artifact_kind") != "hypothesis":
        raise ValueError("hypothesis_readback_kind_invalid")
    payload = stored.get("machine_payload")
    if not isinstance(payload, Mapping):
        raise ValueError("hypothesis_readback_payload_missing")
    required_fields = {
        "artifact_kind",
        "id",
        "task_id",
        "title",
        "description",
        "mechanism",
        "core_claim",
        "risks",
        "verification_plan",
        "source_refs",
        "direction_card",
    }
    if not required_fields.issubset(payload):
        raise ValueError("hypothesis_readback_payload_incomplete")
    if payload.get("artifact_kind") != "hypothesis":
        raise ValueError("hypothesis_readback_payload_kind_invalid")
    dependencies = {str(ref) for ref in stored.get("depends_on", [])}
    source_refs = {str(ref) for ref in payload.get("source_refs", [])}
    if not required_refs.issubset(dependencies):
        raise ValueError("hypothesis_readback_dependencies_incomplete")
    if not required_refs.issubset(source_refs):
        raise ValueError("hypothesis_readback_source_refs_incomplete")
    direction = payload.get("direction_card")
    if (
        not isinstance(direction, Mapping)
        or str(direction.get("family_id") or "") not in family_ids
    ):
        raise ValueError("hypothesis_readback_family_invalid")
