---
name: hypothesis-gen
description: "Produces one formal `hypothesis` with an actionable design preference, mechanism, falsifiable claim, risks, and validation observations. Multiple hypotheses can collectively supply required hypothesis and guidance content when no separate guidance result is required. Requires exact task_spec and hypothesis_mind_map. Boundary: hypothesis_mind_map is an idea source, not a hypothesis."
estimated_complexity: high
accepts_research_mode: true
---

# Hypothesis generation

## Responsibility and boundary

Publish one compact, source-grounded provisional `hypothesis`. This skill owns one candidate design from one established family, states an actionable scientific design preference, and recommends how future researchers could validate it. Several separately published hypotheses may collectively provide a task-requested set of hypotheses and its guidance content when the task does not require a separate guidance result. One invocation does not build that portfolio, execute validation, materialize a proxy, or claim that requested evidence already exists.

The formal-result boundary is strict: the mind map supplies possible method directions, but this skill turns exactly one selected direction into a separate, testable scientific candidate. Only a readable stored artifact whose `artifact_kind` is `hypothesis` and whose content meets the validation evidence below is a formal hypothesis result. A mind-map family, a proxy formula, a scientific review, or a sample-evolution result may inform the candidate but cannot substitute for it.

## Research modes

`task_source` selects autonomous candidate choice versus a commissioned exact
question or gap. `research_strategy` independently selects deepen versus
explore. Deepen exposes relevant public hypotheses, formulas, rankings, and
reviews during authoring. Explore authors one independent draft from the task,
required mind-map structure, source authority, and any exact commissioned refs;
a separate reconciliation stage then restores all selected public research
assets and may preserve or replace that draft before consistency, deepening,
private review, and publication.
Before invocation, common classifies the node-scoped candidate refs and derives
the final exact inputs. The task and mind-map structure remain visible in an
explore draft; this skill does not reinterpret caller-owned ref roles.

## Entry conditions and authority

- Use exact stored `task_spec` and `hypothesis_mind_map` from `resolved_inputs_for_active_skill`.
- Read an exact missing ref before authoring. Index summaries, runtime memory, and dependency labels do not substitute for stored content.
- Before authoring, verify that the selected mind map depends on the same exact task.
- An explicitly selected `prepared_source_data` supplies ordinary research observations, including paired targets, without a target-data grant. The shared resolver reads exact bodies; scoring roles do not restrict access. A matching `data_use_authorizations` grant instead selects its named bodies; preserve `allowed_use` and `claim_limit` in every stage. Invalid explicit grants fail, not fall back. Source and mission restrictions remain binding. Do not request a new task solely to read ordinary measurements.
- Select one `family_id` already defined by the mind map and preserve it with one `lineage_role`.
- Final-KPI Proxy Discovery is a parallel research route, not a prerequisite. Existing hypotheses, exact formula candidates, and proxy leaderboards are public scientific assets that this skill may inspect for inspiration, diversification, or contradiction. Cite every artifact actually used, and treat a quantitative association as a clue rather than causal proof.

## Trigger examples

### Should select

- Exact task_spec and hypothesis_mind_map are visible, and one compact testable candidate is needed from an existing family.
- Exact task_spec and hypothesis_mind_map are visible; the current work is to deepen one declared mechanism family into a bounded design with risks and validation intentions, not to execute those tests.
- An exact formula or leaderboard exposes a quantitative pattern that may inspire a causal explanation, while the same task and mind-map lineage remain available.

### Should not select

- A provisional hypothesis already exists and the current work is to implement a frozen quantitative proxy over sanitized records.
- No hypothesis_mind_map with a stable family_id exists, so an individual candidate cannot preserve the required family lineage.

## Prompt and memory projection

- **C0:** task objective, explicit constraints, claim boundary, and evidence/visibility rules.
- **C1:** the current single-candidate work unit and exact prerequisite refs.
- **C2:** exact public task, mind-map, optional background, prior hypothesis, formula, leaderboard, and review artifacts actually used, plus the final provisional `hypothesis`. Explicit task/source restrictions and any supplied bounded data-use grant remain authoritative. Prompt assembly projects these exact artifacts into mechanically declared authority classes without changing their stored content.
- **C3:** only bounded processed observations that clarify an explicit evidence gap; they do not become executed support.
- **C4:** exact task-scoped prepared bodies, including paired targets, enter `ordinary_prepared_data`. When a task grant matches, its named bodies enter `authorized_task_data`. Neither path changes stored content or its exact source ref.
- **C5:** the skill-local copy of the caller-owned research-mode card, candidate draft, exact occupied-method evidence, one private three-card red-line result, bounded local repairs, and validation issues live only for this invocation. The authoritative card remains on the active C1 LOOP step; only the C5 copy is cleared on exit.
- **C6:** raw prompts, model turns, receipts, and errors remain audit-only.

### LLM call contracts

| Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
|---|---|---|---|---|---|---|---|
| `hypothesis-gen` | `resolve-research-mode` | Exact C1 structured research-mode card plus exact resolved C2 refs | Mechanically validate and copy the caller-owned mode card; old checkpoints alone use the compatibility classifier | Private C5 `{task_source, research_strategy, commissioned_input_refs}` mode card | Existing closed three-field schema and exact-ref subset | No semantic repair for a structured card | Remaining hypothesis stages |
| `hypothesis-gen` | `author-provisional-hypothesis` | C0 task boundary; C1 current candidate work; exact C2 inputs projected as formal task contract, map identity, provisional method embryos, known unknowns, and artifact-kind-labelled public research assets | Author one candidate's scientific content only | Existing title, description, mechanism, core claim, risks, verification plan, and direction card | Structured schema, task/map lineage, family identity, source refs, and later red-line review | Common same-stage format repair only | Explore reconciliation or premise consistency |
| `hypothesis-gen` | `hypothesis-exploration-reconciliation` | C5 independent draft, all formal mind-map families, and only C2 hypotheses/leaderboards that define occupied method space | Compare scientific method meaning; preserve a distinct draft or replace an occupied intervention/primary causal transformation, preferring viable unoccupied families or gaps | Complete existing candidate-content shape | Existing authoring schema and valid formal family id | Common same-stage format repair only | Premise consistency, where the remaining public assets return |
| `hypothesis-gen` | `hypothesis-premise-consistency` | C5 provisional draft plus the same authority-separated C2 projection restricted to its selected family | Preserve candidate title and family while correcting control-role, scale, normalization, direction, and evidence-authority inconsistencies | Complete existing candidate-content shape | Existing authoring schema plus exact title and family identity | One exact same-stage repair | Mechanism-and-verification deepening |
| `hypothesis-gen` | `hypothesis-mechanism-verification-deepening` | Accepted C5 consistency revision plus the same selected-family authority projection | Deepen the same candidate's preference, causal chain, scope, risks, falsifiable claim, and recommended validation observations | Complete existing candidate-content shape | Existing authoring schema plus exact title and family identity | One exact same-stage repair | Producer-owned private reviews |
| `hypothesis-gen` | `hypothesis-private-redline-review` | Authority-separated exact C2 projection and the explicitly labelled C5 candidate under review | Return independent mechanism, evidence-boundary, and testability cards in one call; detect only hard red lines | Three existing `{score, reason}` cards inside one private result | Exact 0-4 scale and non-empty reasons | One complete candidate repair only when any card is 0, followed by one complete re-review | Stable-identity check and publication |
| `hypothesis-gen` | `repair-hypothesis-private-redline` | Rejected C5 candidate, exact score-0 reasons, and the unchanged authority-separated C2 projection | Repair listed red lines without adding transport or executed evidence | Complete existing candidate-content shape | Same authoring schema and one repeated three-card review | No second red-line repair | Stable-identity check |
| `hypothesis-gen` | `repair-hypothesis-exact-identity-collision` | Reviewed C5 candidate, exact occupied C2 hypothesis labelled as an occupied provisional method, and the unchanged C2 authority projection | Change the scientific method, not its wording alone | Complete existing candidate-content shape | Stable host identity must differ; repaired content reruns one three-card review | One identity repair; any final collision fails locally | Stored `hypothesis` |

## Skill-local workflow

1. Resolve the exact artifacts selected for this invocation and verify one coherent task/mind-map lineage. Mechanically project the task as formal constraints, the map's family identity separately from its provisional method content, its unresolved gaps as known unknowns, and each optional public artifact according to its formal kind. Read selected prepared data under the entry conditions above. Carry the same ordinary or granted data projection through authoring, deepening, review, and repair, and include its exact source ref in publication lineage. This changes prompt visibility only; exact stored artifacts remain the authority.
2. Make one focused model call to choose a family and author one bounded mechanism, testable core claim, principal risks, and recommended validation methods. Every proposed method names an explicit physical quantity or observable, the supporting result expected under the hypothesis, and a refuting result. Prefer scientifically suitable calculation or simulation over an expensive physical experiment; this is general scientific advice, so do not write code or limit it to currently installed capabilities.
   If prior hypotheses are supplied, treat their stable method identities and scientific content as already occupied. The new hypothesis must add a different mechanism or core claim, not merely paraphrase an existing method.
3. In explore mode only, restore the mind map and artifacts that define occupied hypothesis methods. Preserve a materially distinct draft; replace a draft that reuses an occupied intervention and primary causal transformation, preferably from a viable unoccupied family or gap. Formula and review detail returns only after this method-selection boundary. This stage returns the same hypothesis-content shape and does not emit a score or verdict.
4. Run one premise-consistency pass over the reconciled candidate. Preserve its title and family while correcting contradictions in control roles, scientific scale, normalization, direction, and evidence authority.
5. Run one mechanism-and-verification pass over the accepted consistency revision. Preserve candidate identity while making the preference, causal chain, scope, risks, falsifying outcome, and recommended observations precise.
6. In one private call, review three independent hard-red-line dimensions: mechanism coherence, evidence/claim boundary, and falsifiability. Score 0 alone blocks; scores 1-4 are concerns that may continue.
7. If any card scores 0, make one complete-result repair inside this skill and rerun the one three-card review. Do not publish the private review as the shared ranking review.
8. Compute the host-owned stable method identity before publication. If the same identity already exists in a visible prior hypothesis, make one narrow skill-local novelty repair from the rejected draft and exact occupied method evidence, deepen that replacement through the same two passes, then rerun the three-card review. A second exact collision is a truthful local failure; do not publish another ref for the same method.
9. Validate the accepted complete scientific content. Malformed structured output uses the common bounded same-stage repair.
10. Mechanically assemble the existing artifact kind, stable id, task identity, exact selected source refs, dependency lineage, summary, and Markdown view from that content; do not ask the model to reconstruct transport identity or duplicate prose.
11. Publish one compact artifact and immediately read back its exact ref before returning control.

A later invocation may explore another family. One invocation does not create a portfolio.

## Progressive disclosure references

- [Design brief](references/design-brief.md)
- [Shared evidence-authority contract](references/evidence-authority-contract.md)
- [Authorized prepared-data route](references/authorized-task-data.md)
- [Authoring stage](references/authoring-stage.md)
- [Exploration reconciliation stage](references/exploration-reconciliation-stage.md)
- [Premise consistency stage](references/premise-consistency-stage.md)
- [Mechanism and verification stage](references/mechanism-verification-stage.md)
- [Private red-line review stage](references/private-redline-review-stage.md)
- [Red-line repair stage](references/redline-repair-stage.md)
- [Exact-identity repair stage](references/identity-repair-stage.md)

## Formal output and handoff

Publish `hypothesis` with `artifact_publish`. The model authors only `title`, `description`, `mechanism`, `core_claim`, `risks`, `verification_plan`, and `direction_card`; the workflow renders Markdown and assembles the existing `machine_payload` so these are not separate competing truths.

The final stored payload keeps the existing core keys: `artifact_kind`, `id`, `task_id`, `title`, `description`, `mechanism`, `core_claim`, `risks`, `verification_plan`, `source_refs`, and `direction_card` with `family_id` and `lineage_role`. Each `verification_plan` string is a self-contained recommendation containing the method, explicit physical quantity or observable, expected supporting result, and refuting result. Use other existing Hypothesis keys only when they hold non-duplicated candidate information.

The exact task and mind-map refs, any matching background refs, every public hypothesis, formula, or leaderboard ref actually used, and any task-authorized prepared-source ref belong in both `source_refs` and the artifact envelope's `depends_on`. Immediately `read_ref` the returned ref.

## Failure and repair

If an input artifact or family identity is missing, the mind map does not cite the selected task ref, or an explicitly supplied grant is invalid, report that precise gap. Ordinary prepared measurements do not require a grant. Repair malformed payload, lineage mismatch, failed readback, or one exact stable-identity collision locally. A score-0 producer red line receives exactly one complete repair and full re-review. A repeated exact identity collision is not publishable. Do not compensate for absent background or permission by inventing literature, data, or validation.

## Validation evidence

Completion requires a readable stored `hypothesis` with a bounded mechanism, testable core claim, valid existing family identity, exact source refs and dependencies, a mind map whose lineage names the same task ref, explicit risks, at least one actionable recommended validation path with a named physical quantity and expected supporting/refuting outcomes, and no fabricated literature or execution claim. Missing core content, machine payload, or readback is incomplete.
