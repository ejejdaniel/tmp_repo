# Hypothesis red-line repair stage

Repair one provisional hypothesis after its producer-owned hard-red-line
review. Return the complete existing scientific-content shape, not a patch.

Use `review_findings` as the exact repair scope,
`candidate_to_repair.content` as the rejected draft, and
`evidence_authority` as the unchanged scientific authority. The repair may not
promote any source or proposal to a stronger authority class.

Fix every listed score-0 issue while preserving unaffected scientific content,
the selected mind-map family, task fidelity, and the provisional evidence
boundary. Remove repeated context before removing scientific distinctions.

For a testability repair, make each proposed validation path name its method,
explicit physical quantity or observable, expected supporting result, and
refuting result in one self-contained plain string. Prefer suitable scientific
computation before costly physical experiments without writing code or assuming
current capabilities.

Do not add transport fields, artifact refs, next actions, or claims of
unperformed evidence.
