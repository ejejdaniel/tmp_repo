# Hypothesis generation design brief

## Responsibility

Own one provisional scientific hypothesis selected from one exact mind-map
family. The skill may deepen and privately review that same candidate, but it
does not execute validation, rank a portfolio, create a proxy formula, evolve a
sample, or choose the next production skill.

## Authority and handoff

- Required C2 authority: one exact `task_spec` and one exact terminal
  `hypothesis_mind_map` that depends on that task.
- Optional C2 authority: explicitly resolved prior hypotheses, formula
  candidates, leaderboards, and scientific reviews.
- Optional C4 input: ordinary bodies of one explicitly selected exact
  `prepared_source_data`, including ordinary paired scoring targets. A matching
  task grant instead restricts reading to its named bodies and declared use.
  The scoring role is not a privacy rule; explicit source restrictions remain.
- Formal output: one immutable `hypothesis` C2 artifact.
- Downstream consumers: shared method review, leaderboard assembly, proxy
  evidence work selected by the coordinator, Sample Evolver, Final LCA, and
  report rendering.
- A revised hypothesis is a new immutable identity. Evidence bound to an older
  ref does not silently transfer.

## C0-C6 mapping

| Class | Content | Storage and metabolism | Prompt exposure |
| --- | --- | --- | --- |
| C0 | Objective, completion condition, scientific constraints, evidence boundary | Common fixed core; unchanged by this skill | Authoring and bounded task projections only |
| C1 | Active single-hypothesis work unit and exact prerequisite refs | Common current control state | Authoring identity and completion context |
| C2 | Exact task, terminal mind map, optional public research assets, final hypothesis | Artifact store; immutable refs | Stage-specific projections from exact stored artifacts |
| C3 | Optional processed observations explicitly supplied by the parent | Common compressible knowledge store | Only when selected into resolved public evidence |
| C4 | Large source bodies and datasets | Workspace; retained by reachable refs | Exact ordinary bodies enter `ordinary_prepared_data`; a matching task grant instead supplies only its named bodies in `authorized_task_data` |
| C5 | Draft, optional explore reconciliation, consistency revision, deepened candidate, one three-card red-line review, repair issues | Skill-local state; replaced at each stage and cleared on exit | Only the next owning stage |
| C6 | Prompt snapshots, raw model turns, tool receipts, errors | Append-only event log | Never semantic input |

## Normal call contracts

| Stage | Sole purpose | Inputs | Output | Validation and repair | Consumer |
| --- | --- | --- | --- | --- | --- |
| Authoring | Select one visible family and author one candidate | C0/C1 request plus exact C2 inputs projected as formal task contract, map family identity, provisional map content, known unknowns, artifact-kind-labelled public assets, and any explicitly authorized C4 task data | Existing complete hypothesis-content shape | Common schema/format repair | Explore reconciliation or premise consistency |
| Explore reconciliation | Reconcile an independent draft with occupied hypothesis space; preserve a distinct method or replace an occupied intervention/primary causal transformation | C5 independent draft, all formal map families, and only C2 hypotheses/leaderboards that define method occupancy | Same complete content shape | Existing schema and formal family enum | Premise consistency, where other public assets return |
| Premise consistency | Correct role, scale, normalization, direction, and evidence-authority contradictions without replacing the method | C5 draft plus the same C2 authority projection restricted to the selected family | Same complete content shape | Existing schema plus exact title/family; one same-stage repair | Mechanism deepening |
| Mechanism and verification | Deepen the accepted candidate's causal chain, scope, falsifiability, risks, and validation observations | C5 consistency revision plus the same selected-family authority projection | Same complete content shape | Existing schema plus exact title/family; one same-stage repair | Private red-line review |
| Private red-line review | Independently score mechanism coherence, evidence boundary, and testability in one call | C5 candidate explicitly labelled as the object under review plus the same C2 authority projection | Three existing private `{score, reason}` cards | Common schema/format repair; score 0 alone triggers one scientific repair | Publication or red-line repair |

The review cards are C5 only. They are not the shared scientific-method review
and do not enter a leaderboard.

## Exceptional calls

- One red-line repair may return the complete existing content shape. It sees
  only the rejected candidate, exact score-0 reasons, and the same compact
  authority used by the review. It must preserve unaffected scientific content.
- One exact-identity repair may replace the scientific method when its
  host-computed identity collides with an explicit prior hypothesis. The
  replacement repeats premise consistency, mechanism deepening, and the private
  review.
- Format repair remains inside the rejected stage and receives the schema,
  rejected value, and exact structural issues from the common runtime.

## Projection rules

- Required task and mind-map content comes from exact stored C2 artifacts.
- Ordinary prepared data uses the shared resolver's exact body lookup, without
  excluding a body solely for its scoring role. Granted data requires exact consumer, source
  ref, output names, task lineage, allowed use, and claim limit; unlisted bodies
  are not opened. A malformed grant is not a reason to bypass authorization.
- One shared prompt authority contract defines the meaning of every projection category. Stage pages consume that contract instead of independently redefining evidence strength.
- Python assigns authority labels only from formal artifact kind and mind-map structure. It does not infer scientific truth from titles, field names, or prose.
- Markdown rendering is never repeated when the machine payload already owns the
  same semantic content.
- Authoring may see the full mind-map landscape so it can choose a family.
- Later stages see only the selected family, task boundary, candidate state, and
  optional public evidence needed for their judgment.
- In explore mode, the reconciliation stage is the only normal stage allowed to
  replace the independent draft before candidate identity is frozen.
- Formula candidates and scientific reviews remain stored and return during
  consistency/deepening, but do not enter explore method selection as occupancy
  evidence.
- The mechanism-deepening stage receives the consistency revision, not both the
  original and revised drafts.
- Every finite string limit comes from the active output schema through the
  runtime. Stage prose does not maintain a second numeric limit.

## Validation ladder

1. Project skill structure validator.
2. Focused workflow tests for transport, lineage, review cards, red-line repair,
   and identity repair.
3. Producer-to-consumer replay using exact task and mind-map refs.
4. Small real-model hypothesis boundary from the same prepared-source lineage.
5. Broader Graph/LOOP execution only after the isolated boundary passes.
