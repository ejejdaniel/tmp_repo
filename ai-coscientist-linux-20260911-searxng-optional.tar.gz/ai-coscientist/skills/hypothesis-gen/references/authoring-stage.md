# Hypothesis authoring stage

Write one compact provisional hypothesis from the supplied JSON. The current
work request controls this invocation, while `evidence_authority` controls the
scientific meaning and claim strength. Choose one family already defined by the
mind map. State a bounded mechanism, falsifiable core claim, principal risks,
and recommended verification plan for future researchers.

Honor `research_mode` as a caller-owned context policy. In explore mode, prior
hypotheses, formulas, rankings, and reviews absent from `evidence_authority` are
deliberately withheld for an independent first draft; do not reconstruct them.
The required task, mind-map family structure, and permitted prepared data remain
visible because they define the work rather than an occupied answer.

Use the description for the candidate idea, mechanism for the causal chain,
core_claim for the falsifiable relation, and lineage_role only for a short
statement of how this candidate advances its selected family. Do not repeat the
task, mind map, composition, or process context in multiple fields.

The verification plan is a list of plain strings. Every item is one
self-contained natural-language recommendation that names a scientifically
appropriate method, the explicit physical quantity or observable to obtain,
the result expected if the claim is supported, and the result that would refute
it. Prefer a scientific calculation or simulation over an expensive physical
experiment when it can genuinely distinguish the claim. This is advice, not
execution: do not write code, restrict the advice to installed capabilities, or
claim that proposed work has already run.

Use the formal family identities to choose lineage and the provisional method
embryos only as idea seeds. Prior hypotheses mark occupied methods. Produce a
genuinely different mechanism or core claim rather than a paraphrase or renamed
parameter relation. Staying in the same family is allowed when the scientific
method advances beyond occupied methods. Formula candidates, rankings, and
reviews may inspire or contradict the proposal only within their declared
authority class.

When `authorized_task_data` contains task-granted prepared observations, use
them only within the stated allowed use and claim limit. Distinguish a
retrospective data-informed hypothesis from independent validation. When the
section is `not_authorized`, dedicated target bodies remain unavailable; use
ordinary research observations only as supplied in `ordinary_prepared_data`.

Return only the existing scientific-content shape. The host owns artifact and
task identity, exact source refs, dependency lineage, summary, and Markdown.
