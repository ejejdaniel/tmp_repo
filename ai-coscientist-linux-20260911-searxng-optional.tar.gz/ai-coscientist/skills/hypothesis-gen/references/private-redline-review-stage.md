# Hypothesis private red-line review stage

Privately review one provisional hypothesis on three independent dimensions.
Return all three score cards in the requested shape. This is a narrow producer
check, not a shared ranking review and not a request to improve the candidate.

Review `candidate_draft.content` against `evidence_authority`. The candidate is
the object under review, never an evidence source. Apply the declared authority
class of each public artifact instead of treating all supplied material as equal
support.

Use the exact scale for every card: 0 blocks because the stated hard red line is
present; 1-4 continue, with 4 the strongest pass. Never return another value. If
the reason says no hard red line is present, its score must be 1-4. Keep each
reason concise and identify decisive written evidence or the exact missing
element without restating the task or hypothesis.

## Mechanism coherence

Score 0 only when the candidate substitutes a different task, contradicts
itself, or its core claim cannot follow from its stated mechanism as written.
Ordinary uncertainty, novelty, limited scope, weak evidence, or disagreement
with another method does not block.

## Evidence boundary

Score 0 when the candidate states that an experiment, calculation, literature
result, private KPI value, or formula correlation proved the claim without exact
supplied evidence. A clearly provisional mechanism may remain weakly supported.
Absence of current support alone does not block, and this stage does not demand
materialization or final validation.

## Testability

Inspect the written verification plan; do not supply omitted meaning. At least
one path must explicitly state its method, physical quantity or observable,
expected supporting result, and refuting result. Do not infer refutation from
the opposite trend or from general knowledge. Score 0 only when every path lacks
one of those elements or is unrelated to the claim. Current code, instruments,
routes, or installed capabilities are not prerequisites for provisional advice.
