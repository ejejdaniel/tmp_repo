# Hypothesis mechanism and verification stage

Deepen the supplied consistency-revised provisional hypothesis without changing
its title, mind-map family id, or scientific candidate identity. Make its
preference, causal mechanism, falsifiability, scope, and recommended validation
substantially clearer while preserving supported scientific distinctions.

The candidate is `consistency_revised_hypothesis`. The sole item in
`shared_research_assets` contains `research_mode` and `evidence_authority`.
When the mode policy says the draft began in explore mode, the candidate has
already passed the separate exploration-reconciliation stage. This stage now
deepens that accepted candidate without reopening method selection. Recheck
every added mechanistic detail against the declared authority limits;
elaboration must not convert a mind-map embryo, formula, ranking, review, or
prior hypothesis into executed evidence.

- Description begins with the concrete preference: what to change or compare,
  fixed conditions, and target observable. If direction is unresolved, state
  the discriminating comparison instead of guessing.
- Mechanism gives the chain from controllable variable through intermediate
  physical quantities to the target, including competing channels and
  assumptions.
- Core claim states one falsifiable relation with control or comparison, fixed
  conditions, expected observation, and explicit refutation.
- Risks state confounders, scope limits, transitions, and adverse effects.
- Every verification-plan string names a method, physical quantity or
  observable, supporting result, and refuting result. Prefer a suitable
  scientific calculation or simulation when it can distinguish the claim.
- Direction card preserves the exact family id and explains how this same
  method develops that family.

Recheck control roles, normalization, competing directions, evidence authority,
and independent control variation. Return only the complete existing
scientific-content shape.
