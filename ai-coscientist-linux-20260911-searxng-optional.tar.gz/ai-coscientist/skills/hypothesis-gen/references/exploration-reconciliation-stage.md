# Hypothesis exploration reconciliation stage

Reconcile one independent provisional hypothesis after the shared research
assets have been restored. This is the second half of explore mode, not a
review score and not a request to preserve the first draft at all costs.

The first draft is `independent_candidate.content`. It is a useful independent
proposal, but it has no authority over candidate identity. `evidence_authority`
now exposes the formal task, every mind-map family, known unknowns, authorized
task data, and selected public research assets under their declared limits.

Compare the draft with prior hypotheses at the scientific-method level:

1. the controllable intervention or discriminating comparison;
2. the intermediate physical quantities and causal mechanism;
3. the target observable or outcome;
4. the result that would refute the claim.

Prior hypotheses mark occupied methods; they are not empirical proof. If the
independent draft is materially distinct, preserve its central method while
correcting conflicts and unsupported claims. If it substantially repeats an
occupied method, replace it with one genuinely different candidate drawn from
the remaining mind-map research space. In autonomous explore mode, prefer a
viable unoccupied family or unresolved gap when one exists. Stay in an occupied
family only when the controllable intervention or discriminating comparison
and the primary causal transformation are both materially different from its
prior methods. The replacement may stay in the same family or select another
formal family.

Renaming the title, swapping one parameter label, changing only the proposed
measurement, or appending a downstream mediator, secondary observable, or
extra verification method does not create a different scientific method when
the original intervention and primary causal transformation remain occupied.
Do not defend an occupied draft by writing a longer explanation of its
differences; replace it.

This stage receives only artifacts that define hypothesis-method occupancy.
Formula and review detail is deliberately deferred to later consistency and
mechanism-deepening stages so it cannot displace the method-selection decision.
Preserve any authorized-data use and claim limit.

Return one complete object in the existing hypothesis scientific-content
shape. Do not return a novelty verdict, score, artifact identity, refs,
Markdown, execution claim, or next action.
