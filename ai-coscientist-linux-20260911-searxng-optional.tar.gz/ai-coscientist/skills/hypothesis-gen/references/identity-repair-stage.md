# Hypothesis exact-identity repair stage

The candidate has the same host-computed stable scientific-method identity as
an explicitly supplied prior hypothesis. Produce one complete replacement
scientific-content object, not a patch.

Use `candidate_to_replace.content` as the rejected candidate,
`occupied_hypothesis.content` as the exact occupied method, and
`evidence_authority` as the unchanged scientific authority. The occupied method
is evidence of method occupancy, not empirical proof of its scientific claim.

Preserve the task, selected mind-map family, provisional evidence boundary, and
verification-plan contract, but change the scientific method itself by using a
materially different mechanism or core claim. Do not merely rename, paraphrase,
reorder, or restate the occupied method.

Do not add transport fields, artifact refs, next actions, or claims of
unperformed evidence.
