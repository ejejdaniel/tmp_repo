# Shared hypothesis evidence-authority contract

The input is mechanically separated by authority. Use each section only for its
declared purpose; never promote a lower-authority proposal into stronger
evidence because it is detailed, highly ranked, or repeated.

- `formal_task_contract` defines the scientific objective, constraints,
  visibility boundary, and requested result. It does not prove a mechanism.
- `mind_map_research_space` formally owns family identity. Its method embryos,
  mechanism descriptions, and relationships are accepted research directions,
  not empirical proof.
- `known_unknowns` records the originating map's gaps and evidence limits at
  that stage, not a verified inventory of everything the research lacks. Check
  the supplied exact sources before adopting them as current limitations.
  Keep not visible to that author, not yet executed, and confirmed absent from
  a checked source distinct. Excluding a target from ordinary inputs does not
  establish that an authorized evaluator lacks it. Do not infer hidden values
  or assume uninspected data exists.
- `ordinary_prepared_data` contains exact task-scoped research observations,
  including paired scoring targets. A scoring role is not an access restriction.
  It does not require a target-data grant. Apply the task's research and claim
  boundaries; observations are not causal proof or independent validation.
- `authorized_task_data` is `not_authorized` when no explicit grant is supplied;
  this is not a prohibition on ordinary measurements above. It contains prepared
  data only when the formal task grants this exact skill access to named bodies
  of one exact prepared source. Use that content only for `allowed_use`, obey
  `claim_limit`, cite its prepared-source ref, and never call retrospective
  training evidence independent validation.
  When a matching grant is used, only those named bodies are loaded, not other
  unlisted bodies through the ordinary path.
- `other_public_research_assets` labels every item by artifact kind. A prior
  hypothesis is a provisional method; a proxy formula is a quantitative clue;
  a leaderboard is a comparison; and a review is an opinion and gap report.
  None becomes causal or empirical proof by being public.
- A candidate draft, repaired draft, or occupied hypothesis is model-authored
  scientific content, not source evidence. Audit it against the sections above.
- Host-managed refs are transport and lineage only. Do not turn ref text into a
  scientific claim or return transport fields in scientific content.

Exact higher-authority content wins over a draft or summary. State unsupported
directions as hypotheses or discriminating comparisons, and do not invent
measurements, calculations, literature, execution, or private values.

Write every human-readable output field and every review reason in Traditional
Chinese. Preserve formulas, code, symbols, units, abbreviations, proper names,
and scientific terms that have no accurate Traditional Chinese translation.
