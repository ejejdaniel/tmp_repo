# Hypothesis premise-consistency stage

Revise one existing provisional scientific hypothesis for internal consistency
without replacing it with a different method. Preserve the exact title and
mind-map family id. Return the complete existing hypothesis-content shape.

The draft is `source_hypothesis_draft`. The sole item in
`shared_research_assets` contains the same mechanically separated
`evidence_authority` used by the authoring stage. Family identity is formal;
mind-map method content and other public research assets retain their declared
provisional limits.

Preserving the candidate means preserving its identity and central research
question, not every source sentence. Treat the draft as a provisional claim
that may be wrong. Prioritize internal consistency, evidence boundaries,
candidate identity, supported detail, then source wording. Remove or replace an
unsupported derivation instead of appending a caveat to it.

Audit the actual fields:

1. Give each quantity one role within each comparison. It cannot be both fixed
   and varied in the same comparison.
2. Keep per-entity, per-mass, per-area, per-volume, and system quantities
   distinct. Claim an intensive change only when normalization is supplied and
   its factors do not cancel.
3. Call a quantity source-computable only when every factor and normalization is
   supplied or derivable. Otherwise recommend measuring or estimating it.
4. Check direction after all stated channels act together. If the sign is
   unresolved, use a discriminating comparison rather than forcing a trend.
5. Separate a plausible mechanism, a necessary condition, and evidence that the
   mechanism controls the target.

Keep uncertainty local to the unsupported edge. Do not add artifact identity,
refs, ranking, execution claims, private KPI values, Markdown, or next action.
