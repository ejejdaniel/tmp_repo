# Authorized prepared-data route

This optional route does not create a general security system. It enforces one
explicit positive task grant at the skill boundary. Without an explicit grant,
ordinary task-scoped prepared data follows the normal readable-data path defined
in SKILL.md; absence of a grant is not an authorization error on that path.

The route activates only when all of the following are true:

1. The current formal `task_spec` contains one `data_use_authorizations` entry
   whose `consumer_skill_id` is exactly `hypothesis-gen`.
2. The entry's `prepared_source_ref` is an exact dependency of that task and is
   selected as an exact input for this invocation.
3. Every `prepared_output_names` entry exists in that prepared-source manifest.

The host reads only those named bodies. Other bodies from the same prepared
source are not read into skill memory or any model prompt. The selected content
appears under `authorized_task_data` together with its `allowed_use` and
`claim_limit`.

The hypothesis must cite the prepared-source artifact when this route is used.
Retrospective observations may guide a hypothesis but do not become independent
validation merely because access was authorized. Malformed, ambiguous, or
out-of-lineage explicit grants fail before the authoring model is called.
