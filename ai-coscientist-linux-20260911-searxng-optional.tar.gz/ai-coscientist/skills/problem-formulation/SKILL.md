---
name: problem-formulation
description: Produces one task_spec that defines downstream completion. Requires one configured parent task source, exact dialogue-launch objective, or child mission. Boundary: task_spec is task authority, not completion evidence; dialogue launches do not inherit configured task goals, and children do not inherit parent source manifests.
estimated_complexity: medium
---

# Problem formulation

## Responsibility and boundary

Create one authoritative `task_spec` from the stated task. This skill owns faithful task formulation, not literature review, scientific design, validation, or workflow routing. It must not add unstated requirements, thresholds, evidence, or scientific claims. The resulting `task_spec` defines the task's downstream result; creating it does not satisfy that result unless the user explicitly requested a task specification as the deliverable.

Commands to begin, start, or launch research request execution; they do not make `task_spec` a deliverable. A stated run, Frame, attempt, bootstrap, or graph-creation limit controls how far the current execution may proceed, but does not replace the task's named scientific outputs or become a scientific success criterion.

## Entry conditions and authority

- For a configured-source parent, read the available-source inventory through `scientific_source_manifest`.
- For a dialogue-launched parent, use the exact C0 launch objective plus only the deliberately selected dialogue context and bounded inquiry observation. Do not read the configured goal or source manifest as task authority; configured sources remain downstream data adapters.
- For a child, use its exact mission objective and evaluation guidance; do not request or reconstruct the parent's source manifest.
- For a configured-source parent with one exact `prepared_source_data` in `resolved_inputs_for_active_skill`, inspect its output metadata. If it contains one `text/*` body, resolve only that body through `source_probe` and `source_read` and use it as the authoritative public task source. If it contains no text body, use the C0 task from `scientific_source_goal` while retaining the prepared artifact and output metadata as formal context. For a dialogue-launched parent or child, a prepared source may remain bounded context but never replaces the exact C0 launch objective or child mission. Other prepared bodies disclose only name, media type, and description so explicit grants can name existing outputs. Their content is not visible to this skill. Multiple candidate text bodies are an explicit ambiguity only when configured-source formulation is selecting task text from preparation.
- When no prepared source is supplied to a configured-source parent, read the task directly through `scientific_source_goal`. Dialogue-launched parents and children instead use their exact C0 objective.
- When repairing an existing task specification, use its exact formal artifact ref.
- Goal text and explicit user constraints are authoritative. Receipts, summaries, raw logs, and planned artifact names are not task authority.
- `graph_revision_outcome` is runtime control and diagnostic evidence for later Graph planning. It never becomes a task requirement, task dependency, or task-formulation prompt source merely because it is mounted in a child mission.
- Record a `data_use_authorizations` entry only when the authoritative goal explicitly grants a named skill a bounded use of named outputs from the exact prepared source. Ordinary data availability is not permission. The model names the consumer, output names, allowed use, and claim limit; the host supplies the exact prepared-source ref.
- Missing task information is a gap; it is never permission to create a default or demo task.

## Trigger examples

### Should select

- The authoritative user goal and source manifest are available, no task_spec exists, and the current work needs a faithful observable task definition.
- An exact task_spec has a concrete omission relative to the authoritative goal and must be repaired without adding unstated requirements.

### Should not select

- An accepted task_spec already exists and the current work is to gather literature and historical background evidence.
- No authoritative goal or source is available, so a task specification cannot be formed without inventing the assignment.

## Prompt and memory projection

- **C0:** configured authoritative goal, exact dialogue-launch objective, or exact child mission; user constraints, visibility limits, and execution-level evaluation boundary.
- **C1:** the current formulation work unit and, for repair, the exact rejected artifact or issue.
- **C2:** the exact prior `task_spec` when repairing and the final published `task_spec`.
- **C3:** no prior narrative is included by default; only a bounded, explicitly relevant processed observation may be used.
- **C4:** source bodies remain in their source or workspace store; the prompt receives only the manifest and content explicitly read for this task.
- **C5:** the current draft, validation issues, and readback issue live only for this invocation and are cleared on exit.
- **C6:** full prompts, model turns, tool receipts, and raw errors remain audit-only and are never semantic input.

### LLM call contracts

| Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
|---|---|---|---|---|---|---|---|
| `problem-formulation` | `formulate-task-spec-content` | Exact C0 authoritative goal or child mission, execution-level evaluation guidance, visibility limits, parent source manifest when applicable, and the one explicit prepared-source projection when supplied; no C3/C6 narrative | Extract only stated constraints, evaluation priority, downstream observable output boundary, and explicit bounded data-use grants; prepared data availability alone grants nothing; never treat this bootstrap contract as task completion | `constraints`, `evaluation_priority`, `output_format`, and optional authorization intents | Structured schema, exact prepared-output names, and deterministic source-fidelity checks | Common same-stage format repair only | Fidelity review |
| `problem-formulation` | `review-task-spec-fidelity` / `recheck-task-spec-fidelity` | Exact C0 authoritative goal or child mission, execution-level evaluation guidance, the same explicit prepared-source projection when supplied, and the complete C5 candidate | Identify omissions, alterations, inventions, corrupted units, or confusion between the contract and downstream result; do not add requirements | Existing `{accepted, issues}` verdict | Exact verdict schema; `accepted=false` is a valid review result | No repair of the reviewer for a valid rejection | Publication or task-spec repair |
| `problem-formulation` | `repair-task-spec-fidelity` | Rejected C5 candidate, exact review issues, and the same C0 source | Repair only listed fidelity defects while preserving valid content | Complete existing authoring shape | Same deterministic checks and a fresh fidelity review | One bounded repair; a second rejection fails locally | Host-owned `task_spec` assembly and publication |

## Skill-local workflow

The private `workflow.py` completes formulation in one selected-skill action:

1. For a configured-source parent, read the source manifest and use the sole prepared public text body as the authoritative goal when one exists; otherwise read the configured C0 goal. For a dialogue-launched parent, use the exact C0 launch objective and selected context without reading configured source-goal routes. For a child, use its exact mission objective and evaluation guidance without reading parent source routes. A prepared artifact containing only structured data remains a dependency and metadata source, not a reason to duplicate the task text.
2. Ask the model only for the structured content needed by downstream consumers. `output_format` names the downstream result, never this bootstrap artifact by default. If the user names required outputs, state those outputs directly. Keep any explicit run/Frame/attempt/bootstrap boundary as a control constraint rather than redefining completion. The host preserves the authoritative goal verbatim and owns artifact identity, timestamps, empty registries, Markdown rendering, dependency bookkeeping, and the exact prepared-source ref in every authorized grant.
3. Compare the draft against the authoritative goal in a separate fidelity review. The review checks omitted or altered scientific conditions, every independently actionable item in named or bulleted condition lists, target direction or tolerance, hard/soft status, visibility and evidence boundaries, completion output, confusion between launch/control language and deliverables, invented requirements, and corrupted text. A category summary does not count as preserving the listed conditions.
4. If rejected, perform one bounded local repair from the complete draft plus exact issues, then repeat the fidelity review. A second rejection fails inside this skill rather than consuming main-agent rounds.
5. Publish only the accepted complete payload, then immediately read and verify the exact stored artifact.

The existing `constraints` field is an array of complete natural-language strings. Preserve independently actionable conditions, thresholds, directions, and soft/hard status; do not replace them with nested objects. `constraint_registry` and `mind_map_taxonomy` remain existing empty host-owned objects until their owning downstream skills populate separate artifacts. The optional `data_use_authorizations` array is not a general security label: it grants one named skill only the listed bodies of one exact prepared source for the stated use and claim limit.

`evaluation_priority` is a compact routing summary, not a duplicate constraint list. Keep the full actionable conditions in `constraints`; use `evaluation_priority` only for the primary objective, target or direction, the relationship to auxiliary conditions, and an explicit newly accepted priority-changing requirement. Do not repeat every threshold, process detail, or privacy rule in that field.

## Formal output and handoff

Publish `task_spec` with `artifact_publish`. Pass the complete TaskSpec object through `machine_payload`; Markdown alone is not a machine payload. Set `depends_on` to the exact `prepared_source_data` ref when consumed, and preserve only the exact public task-body content/projection refs actually read by this skill in `trace_refs`.

Use the TaskSpec machine-payload keys `artifact_kind`, `id`, `goal`, `constraints`, `constraint_registry`, `evaluation_priority`, `output_format`, `iteration_limit`, `created_at`, and `mind_map_taxonomy`, plus the approved optional `data_use_authorizations`. Each authorization contains exactly `consumer_skill_id`, `prepared_source_ref`, `prepared_output_names`, `allowed_use`, and `claim_limit`. Omit the optional array when the source grants no bounded data use.

The next tool call after publication must be `read_ref` on the exact returned ref. Return that ref and any unresolved gaps. Do not prescribe another skill.

## Failure and repair

If a required source is absent, report the precise missing source. If publication or readback reveals missing or altered content, repair the complete payload within this skill and republish; do not leave a receipt as the result. If the task cannot define an observable completion boundary, return that task-definition gap instead of fabricating one.

## Validation evidence

Completion requires a readable stored `task_spec` whose machine payload contains a self-contained goal, preserves every stated constraint and visibility limit, has exact lineage for any formal input used, and contains no invented requirement or data permission. Every authorization must name existing prepared outputs and the exact prepared source in task lineage. A tool receipt or Markdown-only artifact is incomplete.
