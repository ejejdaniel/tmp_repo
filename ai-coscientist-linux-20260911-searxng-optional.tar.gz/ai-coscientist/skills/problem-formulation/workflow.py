from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Mapping, Sequence

from ai_coscientist.domain.prepared_sources import (
    PreparedSourceData,
    resolve_prepared_source_data,
)


_NON_TASK_CONTRACT_ARTIFACT_KINDS = frozenset(
    {
        "graph_revision_outcome",
    }
)


_AUTHORING_SCHEMA = {
    "type": "object",
    "properties": {
        "goal": {
            "type": "string",
            "minLength": 1,
            "maxLength": 12000,
        },
        "constraints": {
            "type": "array",
            "items": {"type": "string", "minLength": 1, "maxLength": 1800},
            "maxItems": 80,
        },
        "evaluation_priority": {
            "type": "string",
            "minLength": 1,
            "maxLength": 2400,
        },
        "output_format": {
            "type": "string",
            "minLength": 1,
            "maxLength": 2400,
        },
        "data_use_authorizations": {
            "type": "array",
            "maxItems": 16,
            "items": {
                "type": "object",
                "properties": {
                    "consumer_skill_id": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 120,
                    },
                    "prepared_output_names": {
                        "type": "array",
                        "minItems": 1,
                        "maxItems": 8,
                        "items": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 240,
                        },
                    },
                    "allowed_use": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 1200,
                    },
                    "claim_limit": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 1200,
                    },
                },
                "required": [
                    "consumer_skill_id",
                    "prepared_output_names",
                    "allowed_use",
                    "claim_limit",
                ],
                "additionalProperties": False,
            },
        },
    },
    "required": [
        "goal",
        "constraints",
        "evaluation_priority",
        "output_format",
    ],
    "additionalProperties": False,
}

_REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "accepted": {"type": "boolean"},
        "issues": {
            "type": "array",
            "items": {"type": "string", "minLength": 1, "maxLength": 1200},
            "maxItems": 20,
        },
    },
    "required": ["accepted", "issues"],
    "additionalProperties": False,
}

_AUTHORING_PROMPT = """\
Formulate the structured content of one scientific task specification from the
latest task_request and the exact contract_input_sources deliberately selected
by common control. This task_spec is internal bootstrap authority:
it defines what downstream work must accomplish, but creating the task_spec is
not itself evidence that the task has been completed. Only treat a task_spec as
the requested completion product when the authoritative goal explicitly asks
the agent to author a task specification as the actual task.
"Begin", "start", or "launch" a task is an execution command, not a request to
deliver a task_spec. When the source says that a task has named required outputs,
`output_format` must name those outputs directly. A limit on what this run,
Frame, attempt, or bootstrap phase may execute is an execution boundary; preserve
it as a constraint when explicit, but do not turn it into the downstream product
or a scientific success criterion.

Return only:
- goal: one complete, self-contained statement of what the formal research must
  accomplish. Resolve references such as "the earlier plan" or "start now"
  through exact selected human messages. Preserve the latest human decision and
  exclude superseded requests. Do not copy assistant suggestions into the goal
  unless an exact human message accepts them.
- constraints: complete natural-language strings for every explicit scientific
  performance, feasibility, composition, process, or design condition. Preserve
  numeric thresholds, direction, tolerance, and whether a condition is soft or
  hard. Keep independently actionable conditions distinct. Do not use nested
  objects. When the source contains a named or bulleted list of primary,
  auxiliary, soft, or hard conditions, preserve every independently actionable
  item as its own constraint. Mentioning only the list's category names in
  evaluation_priority does not preserve those conditions. Execution, evidence,
  privacy, and implementation restrictions may also remain constraints, but
  they never replace the scientific conditions on the studied subject.
 - evaluation_priority: write a compact routing summary, not a second copy of
   the task. State only the primary measured objective, its target or direction,
   how auxiliary conditions relate to it, and any explicit newly accepted task
   requirement that changes priority. The complete list of conditions belongs
   in constraints; do not repeat every auxiliary threshold, process detail, or
   privacy rule here. Stay clearly below the schema limit.
- output_format: state the downstream observable completion product and evidence
  boundary requested by the source. Never describe this bootstrap task_spec as
  the completion product merely because this skill is currently authoring it.
- data_use_authorizations: return an empty array unless the task request or an
  exact selected human message
  explicitly permits a named consuming skill to use one or more named prepared
  outputs. For each explicit permission, copy the consumer skill id, select only
  prepared output names actually listed in prepared_source_data, state the
  allowed analytical use, and preserve the claim limit. The host adds the exact
  prepared-source artifact ref; do not return or reconstruct that ref.

Do not invent missing structures, measurements, thresholds, evidence, workflow
stages, or validation claims. Preserve source wording for units and symbols.
The supplied task_request is the immediate task source selected by the host.
For a child agent it is the exact child mission objective and source_manifest is
null; do not ask for or reconstruct the parent's source manifest. A parent may
instead be launched from dialogue: task_request is the latest exact human
message and source_manifest is null, while configured sources remain downstream
data adapters. Otherwise task_request is the configured source authority and
source_manifest records that authority.
`contract_input_sources` contains exact supporting artifacts deliberately
selected for this formulation. A human_interaction_response or exact
human_conversation_input may clarify task authority. Selected assistant dialogue
is context only, except that an explicit user acceptance may use it to resolve
what the user accepted. Other artifacts are evidence or context: use them to
resolve what the task refers to, but do not silently turn their scientific claims
into new user requirements.
Any `reason` inside a pre-task conclusion records why the router handed work off;
it is audit context only and must never become a task requirement, constraint,
or goal clause.
`task_evaluation_request` is caller-supplied completion guidance. Preserve its
concrete statements about what result must exist or be observable when they
clarify the mission. Do not turn evaluator procedure, judging instructions, or
the act of building this task_spec into downstream work products.
Prepared outputs are disclosed only by name, media type, and description so
that explicit data-use permissions can name existing outputs. Their body content
is not available to this skill; never infer or reconstruct it from metadata.
"""

_REVIEW_PROMPT = """\
Audit one task-specification draft only for fidelity to its task request and
exact selected contract input sources.
Accept it only when:
- goal is complete and self-contained, resolves references in the latest task
  request from exact selected human messages, follows the latest human decision,
  and excludes superseded requests or unaccepted assistant suggestions;
- every explicit scientific condition is represented in constraints without
  losing thresholds, direction, tolerance, or soft/hard status;
- every independently actionable item in a named or bulleted condition list is
  present as a constraint; a category summary in evaluation_priority is not a
  substitute for the individual items;
- evaluation_priority faithfully identifies the primary measured objective and
  its relationship to auxiliary conditions;
- output_format preserves the requested observable completion product and
  evidence or visibility boundary;
- the draft describes the downstream mission result rather than mistaking this
  bootstrap task_spec for proof of task completion, unless authoring a task
  specification is explicitly the task;
- a command to begin, start, or launch research is not misread as a request to
  deliver a task_spec, and named required outputs are stated directly;
- a run, Frame, attempt, bootstrap, or graph-creation execution boundary remains
  a control constraint and is not recast as the downstream completion product;
- concrete completion requirements in task_evaluation_request are preserved,
  without converting evaluator procedure into a requested work product;
- every data-use authorization is explicitly stated by the authoritative goal,
  names only prepared outputs that exist, preserves the allowed use and claim
  limit, and does not turn ordinary data availability into permission;
- no requirement, measurement, structure, evidence, or scientific claim was
  invented; and
- wording is readable and no unit or symbol was corrupted.

The drafted goal is under review and the host must not replace it with the final
utterance. The task_request is either the sole prepared public text body, the
exact child mission, or the latest dialogue request. Exact
`contract_input_sources` selected by common control may clarify what that goal
refers to; human_task_clarification is task authority, while ordinary supporting
evidence must not silently become a new user requirement. Prepared output
metadata is not a second task statement and its body values may not enter public
task fields. `task_evaluation_request` is execution-level completion guidance,
not a completed result and not permission to invent scientific requirements.
Routing `reason` text is audit context and cannot define the task.
Do not reject for style, ordering, or harmless wording differences. On rejection,
list precise omissions or alterations that the author can repair.
"""

_REPAIR_PROMPT = """\
Repair the structured content of a scientific task specification after a strict
source-fidelity review. Return the complete existing authoring shape, not a
patch. Fix every listed issue while preserving valid content. Use only facts and
requirements present in the authoritative source. Keep constraints as an array
of natural-language strings and preserve source wording for units and symbols.
Restore every omitted item from named or bulleted condition lists individually;
do not replace them with a category summary.
Treat `constraints` as the complete list of independently actionable
conditions. Keep `evaluation_priority` as a compact routing summary only: state
the primary objective, target or direction, auxiliary-condition relationship,
and any explicit newly accepted task requirement. Never copy the full goal,
constraint list, or process/privacy details into `evaluation_priority`; its
schema limit is strict.
Keep data_use_authorizations empty unless the source grants permission
explicitly. Return only consumer_skill_id, prepared_output_names, allowed_use,
and claim_limit for each authorization; the host owns the exact source ref.
Return a complete self-contained `goal` derived from task_request and exact
selected human sources. Preserve the latest human decision, remove superseded
requests, and never promote an unaccepted assistant suggestion or routing reason
into task authority.
Non-task prepared bodies are metadata-only and their unprojected content must
not be inferred or introduced into the repaired draft. Preserve valid
clarifications from the supplied contract_input_sources under the same authority
rules as the initial authoring stage. Preserve concrete completion requirements
from task_evaluation_request, but do not describe the bootstrap task_spec itself
as the downstream result unless the authoritative goal explicitly requests that
deliverable. Evaluator procedure and judging instructions are not work products.
Treat a request to begin, start, or launch research as an execution command, not
as a request to deliver a task_spec. When named required outputs exist, state
those outputs directly in `output_format`. Preserve an explicit run, Frame,
attempt, bootstrap, or graph-creation limit as an execution constraint without
turning that limit into the mission result or a scientific success criterion.
"""


def run(payload: dict[str, Any], runtime: Any) -> dict[str, Any]:
    """Formulate, review, publish, and read back one faithful task spec."""
    is_child_agent = bool(payload.get("is_child_agent"))
    task_authority_mode = str(
        payload.get("task_authority_mode") or "configured_source"
    ).strip()
    if task_authority_mode not in {"configured_source", "dialogue_launch"}:
        raise ValueError(
            "problem_formulation_task_authority_mode_invalid:"
            f"{task_authority_mode}"
        )
    is_dialogue_launch = (
        not is_child_agent and task_authority_mode == "dialogue_launch"
    )
    task_evaluation_request = str(
        payload.get("evaluation_summary") or ""
    ).strip()
    manifest: Mapping[str, Any] | None
    if is_child_agent or is_dialogue_launch:
        manifest = None
    else:
        manifest = runtime.call_route("scientific_source_manifest", {})
        _validate_manifest(manifest)
    resolved_inputs = [
        item
        for item in payload.get("resolved_inputs") or []
        if isinstance(item, Mapping)
    ]
    # A child mission already has its own task authority. Its prepared inputs are
    # supporting evidence, not competing candidates for a canonical task source.
    prepared_metadata = (
        None
        if is_child_agent
        else _prepared_source_metadata(
            runtime,
            resolved_inputs,
            select_task_text=not is_dialogue_launch,
        )
    )
    task_output_name = (
        str(prepared_metadata["task_output_name"])
        if prepared_metadata is not None
        else ""
    )
    prepared_source = (
        resolve_prepared_source_data(
            runtime,
            resolved_inputs,
            consumer="problem_formulation",
            output_names=[task_output_name],
        )
        if task_output_name
        else None
    )
    prepared_source_ref = (
        str(prepared_metadata["artifact_ref"])
        if prepared_metadata is not None
        else ""
    )
    if (
        prepared_source is not None
        and not is_child_agent
        and not is_dialogue_launch
    ):
        task_request, prepared_context = _prepared_goal_and_context(
            prepared_source,
            prepared_outputs=prepared_metadata["prepared_outputs"],
        )
    elif is_child_agent or is_dialogue_launch:
        task_request = str(payload.get("task_request") or "").strip()
        if not task_request:
            raise ValueError("problem_formulation_task_request_required")
        prepared_context = (
            {
                "artifact_ref": prepared_source_ref,
                "artifact_kind": "prepared_source_data",
                "prepared_outputs": [
                    dict(output)
                    for output in prepared_metadata["prepared_outputs"]
                ],
            }
            if prepared_metadata is not None
            else None
        )
    else:
        goal_result = runtime.call_route("scientific_source_goal", {})
        task_request = _authoritative_goal(goal_result)
        prepared_context = (
            {
                "artifact_ref": prepared_source_ref,
                "artifact_kind": "prepared_source_data",
                "prepared_outputs": [
                    dict(output)
                    for output in prepared_metadata["prepared_outputs"]
                ],
            }
            if prepared_metadata is not None
            else None
        )
    available_output_names = (
        set(prepared_metadata["available_output_names"])
        if prepared_metadata is not None
        else set()
    )
    contract_input_sources = _contract_input_sources(
        resolved_inputs,
        reference_only=is_child_agent,
    )

    authored = runtime.generate_json(
        _AUTHORING_PROMPT,
        _authoring_context(
            task_request,
            manifest,
            prepared_source=prepared_context,
            contract_input_sources=contract_input_sources,
            task_evaluation_request=task_evaluation_request,
        ),
        purpose="formulate-task-spec-content",
        schema=_AUTHORING_SCHEMA,
        human_input_scope=(
            "task_formulation"
            if (
                payload.get("task_contract_state") or {}
            ).get("phase") == "task_formulation"
            else None
        ),
    )
    candidate = _normalize_authored(
        authored,
        prepared_source_ref=prepared_source_ref,
    )
    issues = _candidate_issues(
        candidate,
        source=task_request,
        prepared_source_ref=prepared_source_ref,
        available_output_names=available_output_names,
    )
    review = _review(
        runtime,
        source=task_request,
        candidate=candidate,
        prepared_source=prepared_context,
        contract_input_sources=contract_input_sources,
        task_evaluation_request=task_evaluation_request,
        purpose="review-task-spec-fidelity",
    )
    issues.extend(_review_issues(review))

    if issues:
        candidate = _normalize_authored(
            runtime.generate_json(
                _REPAIR_PROMPT,
                json.dumps(
                    {
                        "task_request": task_request,
                        "prepared_source_data": prepared_context,
                        "contract_input_sources": contract_input_sources,
                        "task_evaluation_request": task_evaluation_request,
                        "rejected_draft": candidate,
                        "review_issues": _deduplicated(issues),
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
                purpose="repair-task-spec-fidelity",
                schema=_AUTHORING_SCHEMA,
            ),
            prepared_source_ref=prepared_source_ref,
        )
        issues = _candidate_issues(
            candidate,
            source=task_request,
            prepared_source_ref=prepared_source_ref,
            available_output_names=available_output_names,
        )
        repeated = _review(
            runtime,
            source=task_request,
            candidate=candidate,
            prepared_source=prepared_context,
            contract_input_sources=contract_input_sources,
            task_evaluation_request=task_evaluation_request,
            purpose="recheck-task-spec-fidelity",
        )
        issues.extend(_review_issues(repeated))
        if issues:
            raise ValueError(
                "task_spec_fidelity_rejected_after_local_repair:"
                + "; ".join(_deduplicated(issues)[:20])
            )

    task_id = "task-spec-" + hashlib.sha256(
        str(candidate["goal"]).encode("utf-8")
    ).hexdigest()[:12]
    machine_payload = {
        "artifact_kind": "task_spec",
        "id": task_id,
        "goal": candidate["goal"],
        "constraints": list(candidate["constraints"]),
        "constraint_registry": {},
        "evaluation_priority": candidate["evaluation_priority"],
        "output_format": candidate["output_format"],
        "created_at": _utc_now(),
        "mind_map_taxonomy": {},
    }
    if candidate["data_use_authorizations"]:
        machine_payload["data_use_authorizations"] = [
            dict(item) for item in candidate["data_use_authorizations"]
        ]
    markdown = _render_markdown(machine_payload)
    receipt = runtime.publish_artifact(
        artifact_kind="task_spec",
        artifact_id=task_id,
        title="Scientific task specification",
        markdown=markdown,
        summary=str(candidate["evaluation_priority"])[:500],
        status="proposed",
        machine_payload=machine_payload,
        depends_on=tuple(
            dict.fromkeys(
                [
                    *(
                        [prepared_source_ref]
                        if prepared_source_ref
                        else []
                    ),
                    *(
                        str(item.get("artifact_ref") or "").strip()
                        for item in contract_input_sources
                        if str(item.get("artifact_ref") or "").startswith(
                            "artifact:"
                        )
                    ),
                ]
            )
        ),
        trace_refs=tuple(
            dict.fromkeys(
                [
                    *(
                        prepared_source.trace_refs
                        if prepared_source is not None
                        else ()
                    ),
                    *(
                        str(item.get("artifact_ref") or "").strip()
                        for item in contract_input_sources
                        if str(item.get("artifact_ref") or "")
                        and not str(
                            item.get("artifact_ref") or ""
                        ).startswith("artifact:")
                    ),
                ]
            )
        ),
    )
    artifact_ref = str(receipt["artifact_ref"])
    stored = runtime.read_artifact(artifact_ref)
    _validate_readback(
        stored,
        artifact_ref=artifact_ref,
        machine_payload=machine_payload,
        markdown=markdown,
    )
    return {
        "status": "complete",
        "artifact_ref": artifact_ref,
        "summary": "Published and read back one source-faithful task specification.",
    }


def _review(
    runtime: Any,
    *,
    source: str,
    candidate: Mapping[str, Any],
    prepared_source: Mapping[str, Any] | None,
    contract_input_sources: Sequence[Mapping[str, Any]],
    task_evaluation_request: str,
    purpose: str,
) -> dict[str, Any]:
    return runtime.generate_json(
        _REVIEW_PROMPT,
        json.dumps(
            {
                "task_request": source,
                "prepared_source_data": prepared_source,
                "contract_input_sources": [
                    dict(item) for item in contract_input_sources
                ],
                "task_evaluation_request": task_evaluation_request,
                "task_spec_structured_content": candidate,
            },
            ensure_ascii=False,
            indent=2,
        ),
        purpose=purpose,
        schema=_REVIEW_SCHEMA,
    )


def _authoring_context(
    task_request: str,
    manifest: Mapping[str, Any] | None,
    *,
    prepared_source: Mapping[str, Any] | None,
    contract_input_sources: Sequence[Mapping[str, Any]],
    task_evaluation_request: str,
) -> str:
    return json.dumps(
        {
            "task_request": task_request,
            "source_manifest": manifest,
            "prepared_source_data": prepared_source,
            "contract_input_sources": [
                dict(item) for item in contract_input_sources
            ],
            "task_evaluation_request": task_evaluation_request,
        },
        ensure_ascii=False,
        indent=2,
    )


def _contract_input_sources(
    resolved_inputs: Sequence[Mapping[str, Any]],
    *,
    reference_only: bool = False,
) -> list[dict[str, Any]]:
    sources: list[dict[str, Any]] = []
    for raw in resolved_inputs:
        artifact_ref = str(
            raw.get("artifact_ref")
            or raw.get("observation_ref")
            or ""
        ).strip()
        artifact_kind = str(raw.get("artifact_kind") or "").strip()
        if (
            not artifact_ref
            or (
                artifact_kind == "prepared_source_data"
                and not reference_only
            )
            or artifact_kind in _NON_TASK_CONTRACT_ARTIFACT_KINDS
        ):
            continue
        markdown = str(raw.get("markdown") or "")
        machine_payload = raw.get("machine_payload")
        if machine_payload is None and artifact_kind == "execution_observation":
            machine_payload = {
                "status": raw.get("status"),
                "namespace": raw.get("namespace"),
                "result": raw.get("result"),
                "metadata": raw.get("metadata"),
            }
        serialized_payload = json.dumps(
            machine_payload,
            ensure_ascii=False,
            default=str,
        )
        source_role = (
            "human_task_clarification"
            if artifact_kind
            in {
                "human_interaction_response",
                "human_conversation_input",
            }
            else "selected_supporting_evidence"
        )
        source = {
            "artifact_ref": artifact_ref,
            "artifact_kind": artifact_kind,
            "source_role": source_role,
            "summary": str(raw.get("summary") or "")[:2_000],
        }
        if not reference_only or source_role == "human_task_clarification":
            exact_human_source = source_role == "human_task_clarification"
            source.update(
                {
                    "markdown": (
                        markdown if exact_human_source else markdown[:8_000]
                    ),
                    "machine_payload_json": (
                        serialized_payload
                        if exact_human_source
                        else serialized_payload[:8_000]
                    ),
                    "content_truncated": (
                        not exact_human_source
                        and (
                            len(markdown) > 8_000
                            or len(serialized_payload) > 8_000
                        )
                    ),
                }
            )
        sources.append(source)
    return sources


def _prepared_goal_and_context(
    prepared_source: PreparedSourceData,
    *,
    prepared_outputs: Sequence[Mapping[str, Any]],
) -> tuple[str, dict[str, Any]]:
    text_outputs = [
        output
        for output in prepared_source.outputs
        if output.media_type.lower().split(";", 1)[0].strip().startswith("text/")
        and isinstance(output.content, str)
        and output.content.strip()
    ]
    if len(text_outputs) != 1:
        raise ValueError(
            "problem_formulation_prepared_task_text_ambiguous:"
            f"count={len(text_outputs)}"
        )
    authority = text_outputs[0]
    projection = {
        "artifact_ref": prepared_source.artifact_ref,
        "artifact_kind": "prepared_source_data",
        "prepared_outputs": [dict(output) for output in prepared_outputs],
    }
    return authority.content.strip(), projection


def _prepared_source_metadata(
    runtime: Any,
    resolved_inputs: Sequence[Mapping[str, Any]],
    *,
    select_task_text: bool = True,
) -> dict[str, Any] | None:
    prepared_by_ref: dict[str, dict[str, Any]] = {}
    for raw in resolved_inputs:
        if raw.get("artifact_kind") != "prepared_source_data":
            continue
        artifact_ref = str(raw.get("artifact_ref") or "").strip()
        if not artifact_ref.startswith("artifact:"):
            raise ValueError("problem_formulation_prepared_source_artifact_ref_invalid")
        artifact = dict(raw)
        if not isinstance(artifact.get("machine_payload"), Mapping):
            artifact = dict(runtime.read_artifact(artifact_ref))
        prepared_by_ref[artifact_ref] = artifact
    if not prepared_by_ref:
        return None
    if len(prepared_by_ref) != 1:
        raise ValueError(
            "problem_formulation_prepared_source_selection_ambiguous:refs="
            + repr(sorted(prepared_by_ref))
        )

    artifact_ref, artifact = next(iter(prepared_by_ref.items()))
    machine_payload = artifact.get("machine_payload")
    if not isinstance(machine_payload, Mapping):
        raise ValueError("problem_formulation_prepared_source_payload_required")
    raw_outputs = machine_payload.get("prepared_outputs")
    if not isinstance(raw_outputs, list) or not raw_outputs:
        raise ValueError("problem_formulation_prepared_source_outputs_required")

    prepared_outputs: list[dict[str, str]] = []
    names: set[str] = set()
    text_names: list[str] = []
    for index, raw_output in enumerate(raw_outputs):
        if not isinstance(raw_output, Mapping):
            raise ValueError(
                f"problem_formulation_prepared_source_output_invalid:index={index}"
            )
        name = str(raw_output.get("name") or "").strip()
        media_type = str(raw_output.get("media_type") or "").strip()
        description = str(raw_output.get("description") or "").strip()
        if not name or name in names or not media_type or not description:
            raise ValueError(
                f"problem_formulation_prepared_source_output_metadata_invalid:index={index}"
            )
        names.add(name)
        prepared_outputs.append(
            {
                "name": name,
                "media_type": media_type,
                "description": description,
            }
        )
        if media_type.lower().split(";", 1)[0].strip().startswith("text/"):
            text_names.append(name)
    if select_task_text and len(text_names) > 1:
        raise ValueError(
            "problem_formulation_prepared_task_text_ambiguous:"
            f"count={len(text_names)}"
        )
    return {
        "artifact_ref": artifact_ref,
        "task_output_name": (
            text_names[0] if select_task_text and text_names else ""
        ),
        "available_output_names": sorted(names),
        "prepared_outputs": prepared_outputs,
    }


def _authoritative_goal(result: Any) -> str:
    if not isinstance(result, Mapping):
        raise ValueError("problem_formulation_goal_result_invalid")
    goal = str(result.get("goal") or "").strip()
    if not goal:
        raise ValueError("problem_formulation_authoritative_goal_required")
    return goal


def _validate_manifest(manifest: Any) -> None:
    if not isinstance(manifest, Mapping):
        raise ValueError("problem_formulation_source_manifest_invalid")
    goal = manifest.get("goal")
    historical = manifest.get("historical_data")
    if not isinstance(goal, Mapping) or not str(goal.get("sha256") or ""):
        raise ValueError("problem_formulation_goal_manifest_required")
    if not isinstance(historical, Mapping):
        raise ValueError("problem_formulation_historical_manifest_required")
    if not str(historical.get("sha256") or ""):
        raise ValueError("problem_formulation_historical_hash_required")
    count = historical.get("record_count")
    if isinstance(count, bool) or not isinstance(count, int) or count < 0:
        raise ValueError("problem_formulation_historical_count_invalid")


def _normalize_authored(
    value: Mapping[str, Any],
    *,
    prepared_source_ref: str,
) -> dict[str, Any]:
    goal = " ".join(str(value.get("goal") or "").split())
    constraints = value.get("constraints")
    if not isinstance(constraints, list):
        raise TypeError("task_spec_constraints_must_be_array")
    raw_authorizations = value.get("data_use_authorizations", [])
    if not isinstance(raw_authorizations, list):
        raise TypeError("task_spec_data_use_authorizations_must_be_array")
    authorizations: list[dict[str, Any]] = []
    for raw in raw_authorizations:
        if not isinstance(raw, Mapping):
            raise TypeError("task_spec_data_use_authorization_must_be_object")
        raw_names = raw.get("prepared_output_names")
        if not isinstance(raw_names, list):
            raise TypeError(
                "task_spec_data_use_authorization_output_names_must_be_array"
            )
        authorizations.append(
            {
                "consumer_skill_id": str(
                    raw.get("consumer_skill_id") or ""
                ).strip(),
                "prepared_source_ref": prepared_source_ref,
                "prepared_output_names": [
                    str(item).strip() for item in raw_names
                ],
                "allowed_use": " ".join(
                    str(raw.get("allowed_use") or "").split()
                ),
                "claim_limit": " ".join(
                    str(raw.get("claim_limit") or "").split()
                ),
            }
        )
    return {
        "goal": goal,
        "constraints": [
            " ".join(str(item).split()) for item in constraints if str(item).strip()
        ],
        "evaluation_priority": " ".join(
            str(value.get("evaluation_priority") or "").split()
        ),
        "output_format": " ".join(
            str(value.get("output_format") or "").split()
        ),
        "data_use_authorizations": authorizations,
    }


def _candidate_issues(
    candidate: Mapping[str, Any],
    *,
    source: str,
    prepared_source_ref: str,
    available_output_names: set[str],
) -> list[str]:
    issues: list[str] = []
    if not str(candidate.get("goal") or "").strip():
        issues.append("goal is empty")
    constraints = candidate.get("constraints")
    if not isinstance(constraints, list):
        return ["constraints must be an array of strings"]
    if len(constraints) != len(set(constraints)):
        issues.append("constraints contain exact duplicates")
    if not str(candidate.get("evaluation_priority") or "").strip():
        issues.append("evaluation_priority is empty")
    if not str(candidate.get("output_format") or "").strip():
        issues.append("output_format is empty")
    authorizations = candidate.get("data_use_authorizations")
    if not isinstance(authorizations, list):
        issues.append("data_use_authorizations must be an array")
    else:
        available_names = available_output_names
        identities: list[tuple[str, str]] = []
        for index, authorization in enumerate(authorizations):
            if not isinstance(authorization, Mapping):
                issues.append(
                    f"data_use_authorizations[{index}] must be an object"
                )
                continue
            consumer = str(
                authorization.get("consumer_skill_id") or ""
            ).strip()
            source_ref = str(
                authorization.get("prepared_source_ref") or ""
            ).strip()
            output_names = authorization.get("prepared_output_names")
            allowed_use = str(authorization.get("allowed_use") or "").strip()
            claim_limit = str(authorization.get("claim_limit") or "").strip()
            if not consumer:
                issues.append(
                    f"data_use_authorizations[{index}].consumer_skill_id is empty"
                )
            if not prepared_source_ref:
                issues.append(
                    f"data_use_authorizations[{index}] has no prepared source"
                )
            elif source_ref != prepared_source_ref:
                issues.append(
                    f"data_use_authorizations[{index}].prepared_source_ref "
                    "does not match the exact prepared source"
                )
            if not isinstance(output_names, list) or not output_names:
                issues.append(
                    f"data_use_authorizations[{index}].prepared_output_names "
                    "must be a non-empty array"
                )
            else:
                normalized_names = [str(item).strip() for item in output_names]
                if (
                    any(not item for item in normalized_names)
                    or len(normalized_names) != len(set(normalized_names))
                ):
                    issues.append(
                        f"data_use_authorizations[{index}].prepared_output_names "
                        "contains an empty or duplicate name"
                    )
                unknown = sorted(set(normalized_names) - available_names)
                if unknown:
                    issues.append(
                        f"data_use_authorizations[{index}] names unknown prepared "
                        f"outputs: {unknown}"
                    )
            if not allowed_use or not claim_limit:
                issues.append(
                    f"data_use_authorizations[{index}] requires allowed_use "
                    "and claim_limit"
                )
            identities.append((consumer, source_ref))
        if len(identities) != len(set(identities)):
            issues.append("data_use_authorizations contains duplicate grants")
    if source.isascii() and not _all_text_is_ascii(candidate):
        issues.append(
            "draft introduced non-ASCII symbols although the authoritative source "
            "is ASCII; preserve the source wording instead"
        )
    return issues


def _review_issues(review: Mapping[str, Any]) -> list[str]:
    raw_issues = review.get("issues")
    issues = (
        [str(item).strip() for item in raw_issues if str(item).strip()]
        if isinstance(raw_issues, list)
        else []
    )
    if review.get("accepted") is True and not issues:
        return []
    if not issues:
        return ["fidelity review rejected the draft without a usable reason"]
    return issues


def _all_text_is_ascii(value: Any) -> bool:
    if isinstance(value, Mapping):
        return all(_all_text_is_ascii(item) for item in value.values())
    if isinstance(value, Sequence) and not isinstance(
        value, (str, bytes, bytearray)
    ):
        return all(_all_text_is_ascii(item) for item in value)
    return not isinstance(value, str) or value.isascii()


def _render_markdown(payload: Mapping[str, Any]) -> str:
    constraints = "\n".join(
        f"- {item}" for item in payload.get("constraints", [])
    ) or "- None explicitly stated."
    authorizations = payload.get("data_use_authorizations", [])
    authorization_markdown = ""
    if isinstance(authorizations, list) and authorizations:
        entries = "\n".join(
            "- "
            + str(item.get("consumer_skill_id"))
            + " may use "
            + ", ".join(str(name) for name in item.get("prepared_output_names", []))
            + " from "
            + str(item.get("prepared_source_ref"))
            + ": "
            + str(item.get("allowed_use"))
            + " Claim limit: "
            + str(item.get("claim_limit"))
            for item in authorizations
            if isinstance(item, Mapping)
        )
        authorization_markdown = "\n\n## Data-use authorizations\n\n" + entries
    return (
        "# Scientific task specification\n\n"
        "## Authoritative goal\n\n"
        + str(payload["goal"])
        + "\n\n## Structured scientific conditions\n\n"
        + constraints
        + "\n\n## Evaluation priority\n\n"
        + str(payload["evaluation_priority"])
        + "\n\n## Required output\n\n"
        + str(payload["output_format"])
        + authorization_markdown
    )


def _validate_readback(
    stored: Mapping[str, Any],
    *,
    artifact_ref: str,
    machine_payload: Mapping[str, Any],
    markdown: str,
) -> None:
    if str(stored.get("artifact_ref") or "") != artifact_ref:
        raise ValueError("task_spec_readback_ref_mismatch")
    if stored.get("artifact_kind") != "task_spec":
        raise ValueError("task_spec_readback_kind_mismatch")
    if stored.get("machine_payload") != machine_payload:
        raise ValueError("task_spec_readback_machine_payload_mismatch")
    if str(stored.get("markdown") or "") != markdown:
        raise ValueError("task_spec_readback_markdown_mismatch")


def _deduplicated(values: Sequence[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        text = str(value).strip()
        if text and text not in result:
            result.append(text)
    return result


def _utc_now() -> str:
    return (
        datetime.now(timezone.utc)
        .replace(microsecond=0)
        .isoformat()
        .replace("+00:00", "Z")
    )
