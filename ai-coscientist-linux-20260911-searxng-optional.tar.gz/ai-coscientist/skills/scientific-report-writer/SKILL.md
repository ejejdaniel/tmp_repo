---
name: scientific-report-writer
description: "Produces a formal scientific_report with HTML/PDF delivery. Requires an exact task_spec and accepted evidence, or one exact existing report for presentation-only retry; Final LCA is not an entry prerequisite. Boundary: presentation only; does not compute or repair research, grant release, or replace missing review."
estimated_complexity: high
---

# Scientific Report Writer

## Responsibility and boundary

Assemble one coherent Markdown report from exact accepted artifacts, then
project that same formal report into deterministic human-facing HTML and PDF.
Explain the research proposition, the mechanism and quantitative research
routes, the evidence chain, the current result, and remaining uncertainty in
plain language.

Report scope follows the task and evaluation requirements, not the number of
available report sections. A stage-results report does not require Sample
evolution or Final LCA. Report publication is not research completion or release.
The scope and missing-stage rules in
[evidence-authority.md](references/evidence-authority.md) govern composition
and integration, including their same-stage repair.

This skill owns communication and evidence assembly. It does not create or
repair hypotheses, formulas, samples, reviews, or Final LCA judgments. It does
not recalculate scientific values, promote raw logs into evidence, expose
private KPI values, or claim more than the supplied artifacts support.

The formal `scientific_report` remains the only narrative authority. HTML and
PDF are C4 presentation projections produced without another LLM call. They
must include the exact sample content and complete cited implementation code,
not only artifact identifiers. Read
[human-presentation.md](references/human-presentation.md) when producing these
human deliverables.

## Entry conditions and authority

Use only exact refs in `resolved_inputs_for_active_skill` and their stored
content. Prefer the current reviewed dependency closure; never choose a global
latest artifact. Identify the available task, evidence context, mind map,
hypothesis, proxy formula, implementation, execution, leaderboard, sample
evolution, scientific review, and Final LCA judgment.

When an expected section has no authoritative source, state `資料不足` or
`證據不足` and name the missing ref. A plan, stale artifact, raw receipt, or
plausible sentence cannot fill that gap.

Use [evidence-and-claim-audit.md](references/evidence-and-claim-audit.md) when
checking whether report statements exceed their cited evidence.
For source selection and conflicting observations, use
[evidence-authority.md](references/evidence-authority.md). The composition and
repair prompts load this same authority; dependency history is not automatically
the current data source. Use `read_ref` within the current section stage when
the exact data body or an omitted artifact field is needed. Return exact display
locations together with the report; the host invokes `create_reference_link`
for focused excerpts. Chapter-only reading and display instructions are in
[report-composition.md](references/report-composition.md); they are not loaded
into integration.
Detailed values remain bound to their original
fields; prose explains them rather than recreating another results table.
Task contracts stay exact in the initial prompt. Other bodies, including prepared
manifests, selected results and historical result bodies, are read through the catalog and exact links,
not admitted by their size or input order. The evidence authority page governs whether
an upstream gap still applies at the report's stage and visibility scope.

## Trigger examples

### Should select

- A reviewed scientific run has exact task, hypothesis, quantitative, ranking, reviewer, and Final LCA refs, and the user requests a readable final report.
- Accepted mechanism and proxy routes must be explained together with their evidence, disagreements, limitations, and release judgment.
- The task requests only an implementation-and-scoring report; exact task, implementation and leaderboard artifacts exist, without Sample evolution or Final LCA.

### Should not select

- A proxy implementation has failed and the requested work is to repair or rerun its program.
- The request is to report computed results, but no readable accepted result or task_spec is available; a plan alone is not computation evidence.

## Prompt and memory projection

- **C0:** objective, report boundary, visibility rules, and completion condition.
- **C1:** active report work unit and current claim-audit question.
- **C2:** exact accepted artifact refs and, once an existing contract is supplied, the final report ref.
- **C3:** bounded summaries of evidence, conflicts, limitations, and ranking.
- **C4:** full documents, code, datasets, logs, and large tables behind refs.
- **C5:** unpublished source selections, host-generated links, current section draft and local citation repair.
- **C6:** raw prompts, model turns, receipts, and execution traces for audit only.

C2 remains authoritative and C4 remains ref-backed. Do not copy large C4 bodies
into every prompt. C3 may summarize them, but formal claims still cite exact
refs.

### LLM call contracts

Section drafting and `compose-scientific-conference-report` use the scientific
reasoning profile. Each section group has its own reading context. Local
repairs use the repair reasoning profile, with the same remaining read allowance.
The workflow allocates reading calls across the entire existing step allowance,
after reserving an initial result and one repair for every drafting, integration
and necessary long-code presentation call. These are not independent full quotas
per chapter. Read only what the assigned chapters need; do not recreate the other
chapters. Common remains the authority that enforces the sealed step limit.

| Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
|---|---|---|---|---|---|---|---|
| `scientific-report-writer` | `compose-scientific-report-sections-1/2/3`: explain assigned sections and select their display evidence | C0 requested scope; exact task_spec; C2 navigation; C4 fields read as needed | Explain existing work; choose exact original excerpts; no new research | Existing private title/markdown/evidence_index/selections | Assigned headings and exact refs; native locator readback; no scientific semantic check | Same-stage `.repair` once, with its reading context and remaining allowance | Section drafts and verified links for assembly |
| `scientific-report-writer` | `compose-scientific-conference-report`: reconcile the whole draft, then conclude | Exact C0 task; C5 drafts labelled as editable input; C2/C4 refs, dependencies and field catalog, without competing source summaries or raw read transcripts | Correct private chapter prose and index uses against the task and sources first; write abstract and answer from that reconciled account, without changing formal evidence | Existing private title/markdown/evidence_index; markdown includes required integration chapters and any revised existing chapters | Required headings, only existing optional chapter headings and still-missing refs; full validation after assembly | Same-stage `.repair` once | Host retains unreturned chapters and refs, applies returned chapter/use text, attaches unchanged source excerpts, publishes and reads back |

The existing optional implementation projection calls remain separate: they select
code ranges for human presentation, not scientific conclusions. They use the same
immutable implementation input and existing private projection schema;
`project-implementation-for-human-report` uses scientific reasoning and its
existing same-stage `.repair` corrects only paths and structure. It does not open
a second independently retryable projection stage.
Their code projection is supplied only to the quantitative section stage.

## Skill-local workflow

1. Read explicitly selected Samples' best-record parameters through the existing
   `scientific_sample_candidate_bundle_read`, using each Sample's exact trace_refs
   and sample_id. Share this original-input projection with Final LCA; do not
   reconstruct parameters from prose or load the full sample cohort into prompts.
2. Write the existing chapter groups in separate contexts: task and mechanisms;
   quantitative work and samples; reviews and evidence limits. In each group,
   read_ref/create_reference_link supplies exact fields for the claims and display
   selections. Return only the assigned chapters and their refs. A new group
   does not inherit previous raw read responses. No separate source-selection
   model is added.
3. Validate each private draft and native locations. Same-stage structural repair
   retains that group's reading context. Oversized reads can return a Common
   budget error instead of loading the body; choose focused fields or pages.
   Exact original sources remain readable and are never summarized or truncated.
4. First reconcile the whole private draft with the task and evidence, then
   write the abstract and answer from that account. This is editorial work,
   not a new reviewer or merely continuing previous assistant answers.
   Integration receives the original drafts as labelled input, followed by the
   editing request; task contracts and all source lookup fields remain exact.
   Return only chapters requiring correction in addition
   to the two required integration chapters; retain supported content within
   each replacement. The host preserves unreturned chapter text and index entries,
   and applies explicitly returned index descriptions. Distinguish correcting
   this skill's private interpretation from changing formal evidence, following
   the shared evidence authority page. Use focused source reads when needed,
   within the same step allowance. Add still-missing required refs without
   retyping the complete index. The host adds verified
   original excerpts and best-sample parameters, then publishes and reads back
   one report. The renderer expands selected sources beside
   their paragraphs, in addition to the existing full-artifact appendices.
5. Invoke `render_scientific_report` after exact readback. Its required input is
   `report_ref`; optional `implementation_projections` uses the existing private
   code projection contract. The domain host chooses output paths. Return the
   HTML and PDF paths in the existing completion summary only after both files
   are produced. A published report alone is not successful file delivery.

When an exact existing `scientific_report` is explicitly selected, skip composition
and publication and resume step 5. Do not choose a global latest report. Multiple
explicit reports are ambiguous. Presentation failure preserves the formal report;
retry its exact ref instead of rerunning research or rewriting report prose.

## Writing rules

- Use natural, complete Chinese by default. Explain project terms on first use.
- Distinguish source fact, computed observation, interpretation, hypothesis,
  reviewer judgment, and release decision.
- Keep formula and sample ranking spaces separate. Formula trend scores, method
  review scores, and formula Pareto tiers describe formula ranking only; sample
  ranking must come from the exact `sample_evolution_result` indices and their
  supplying formulas.
- Describe concrete observed changes and evidence instead of generic praise.
- Never treat correlation, ranking, novelty, or successful code execution as
  proof of the final scientific claim.
- Preserve negative results, ties, regressions, unscorable samples, missing
  evidence, and executor inconsistencies.
- Report public aggregate evaluator findings only when present in a public
  artifact. Never reproduce private KPI values.

## Report shape

Use the exact headings supplied by the composition call and its locator schema.
They cover the abstract, task boundary, mind map, hypothesis, quantitative work,
samples, scientific review, answer to the original question, and evidence index.
Do not create a competing heading list here.

A short code excerpt may appear in the report, but the complete program remains
behind its exact code artifact ref.

## Formal output and handoff

Publish exactly one formal `scientific_report` artifact and immediately read it
back. Its top-level envelope carries `title`, `markdown`, `summary`, and
`depends_on`. Its `machine_payload` contains exactly:

```text
artifact_kind: scientific_report
evidence_index:
  - evidence_ref
    evidence_kind
    use
```

`depends_on` contains the artifact refs cited by the report. Code refs may be
listed in `evidence_index`, but remain in the code store and are not artifact
dependencies. Do not add another public field, duplicate the Markdown inside
`machine_payload`, or use a separate workspace file as the formal authority.

The private `selections` list is not stored as a new public field. Its validated
links are attached to Markdown before publication. After successful readback, the workflow
must call `render_scientific_report`, which uses this skill's existing
`scripts/render_report.py` to produce `scientific-report.html` and
`scientific-report.pdf` under the task's exact-report directory. This projection is successful only when every cited
mind map and hypothesis is rendered from its exact structured content, every
cited code ref resolves to hash-verified source, and every cited sample result
is shown with its stored content. These files do not change the artifact schema
and do not replace the formal artifact.

Use `create_reference_link` to cite exact fields, snapshot file lines or PDF
pages in Markdown; retain the original `source_ref` in the existing evidence
index. The renderer embeds verified excerpts or original PDF pages at internal
anchors. It cannot infer source roots from a link. When rendering workspace
sources, the host passes its existing authorized reference resolver; standalone
rendering can resolve stored artifacts, snapshots and development outputs only.
Missing or changed sources fail visibly rather than silently linking new content.

## Failure and repair

If a required source ref is missing, unreadable, unreviewed, or outside the
accepted dependency closure, name that ref and return a bounded gap. A local
repair may correct report structure or unsupported citations, but it may not
invent scientific evidence, rerun upstream research, or weaken Final LCA.

## Validation evidence

The report is complete only when every formal claim cites a readable exact ref,
missing stages are explicit, mechanism plausibility is separated from proxy
performance, ranking history preserves failures and ties, private data remains
private, and the final paragraph answers the original question within the
evidence boundary. Structural validation alone does not prove the report has an
approved persistence contract or has been exercised by a real model.
