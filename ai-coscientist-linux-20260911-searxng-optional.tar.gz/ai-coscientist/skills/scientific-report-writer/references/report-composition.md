# Chapter Composition and Display Selection

This page applies only to chapter drafting and its local repair. Shared evidence
authority remains in evidence-authority.md. Integration does not select new
display excerpts or repeat chapter-writing operations.

Read the necessary exact prepared manifests and result fields for each section.
Composition reads with read_ref and create_reference_link, sharing that reading
with display selection in the same stage. Display selection is neither an
exclusive reading permission nor a proof-of-coverage checklist.

For explicitly selected Sample results, the host resolves each best sample from
its own trace_refs candidate bundle and exact sample_id before source selection.
exact_sample_parameters contains those original inputs and their source identities,
not a new scientific result. Use the native named values rather than reconstructing
them from input_description or a review. The host inserts this same excerpt in
the sample section after composition and repair. Do not select the workspace
bundle as a create_reference_link locator (that namespace is not supported),
or transcribe its parameter list; cite its owning Sample artifact in evidence_index.
The combined composition result selects other focused evidence.

Display-source selection accompanies each section draft in that section's reading
context. It selects what the human report displays, not everything the writer
must read. The combined private result includes selections:
each item contains an existing report section heading in section and an exact
source ref in ref. Optional path, field_path and range use the existing
create_reference_link input definitions, projected from that tool's schema.
Use the field catalog first; inspect fields with read_ref and create_reference_link
when a location is unclear. Within selections return locations only, not copied
source values, prose, encoded links or content hashes. Return the assigned draft itself
in the sibling title, markdown and evidence_index fields.
For key data, computed results and ranking details, select a focused original
field or passage. The host calls create_reference_link and reads back the exact
selected content for integrity verification, without copying all bodies into the
composition prompt. It verifies these links and retains
them in those sections after composition and repair; the renderer displays the
verified source excerpt beside the paragraph. During composition, keep every
selected source ref in evidence_index with a use text explaining
what it supports. Do not hand-build the link or its hash. Prefer a focused
field/record over embedding an entire large artifact. A link to a review
supports that review's verdict, not a replacement dataset or execution result.

Each chapter group has a fresh reading context; prior raw reads are not inherited.
Composition uses scientific reasoning; local repair uses the existing
repair reasoning setting. Native location errors and report structural errors enter
the same stage's existing bounded repair, preserving its prior inspection
messages and remaining inspection allowance. A repair may inspect again; it
must not invent sources or change the task. Sizes in the catalog guide focused
reading and presentation, not acceptance of a valid citation. The existing
Common check of complete messages and tools owns the prompt budget; there is
no separate combined-excerpt publication limit.

The private selections and generated links are unpublished C5 working data for
this invocation, not accepted evidence or persisted memory fields. Section
drafting returns title, markdown, evidence_index and selections together.
The public payload remains artifact_kind and evidence_index; selections become
verified Markdown links, not a new persisted field.
