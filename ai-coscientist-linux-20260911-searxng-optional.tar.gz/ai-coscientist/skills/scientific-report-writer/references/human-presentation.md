# Human presentation projection

The formal `scientific_report` artifact remains the only scientific narrative
authority. Human-facing HTML and PDF are deterministic C4 presentation files,
not additional formal artifacts and not a second scientific report.

The production workflow invokes `render_scientific_report` after publication and
readback, not an external test runner after the task completes. The route returns
the existing renderer receipt with exact HTML/PDF locations and evidence counts.
The workflow passes both locations in its existing completion summary. On error,
the report stays published; selecting its exact ref retries presentation only.
Neither file paths nor browser options are model-authored route arguments.

The renderer must:

- read one exact stored `scientific_report` ref;
- render the report's top-level Markdown without asking an LLM to rewrite it;
- resolve every cited artifact and code ref from the same artifact root;
- project every cited `hypothesis_mind_map` from its exact structured mechanism
  landscape, including all families, causal chains, relationships, unresolved
  gaps, and evidence boundaries;
- project every cited `hypothesis` from its exact structured content, including
  its full claim, mechanism, risks, verification plan, direction card, and
  source refs;
- include complete implementation source after verifying its stored SHA-256;
- include actual sample content from each cited `sample_evolution_result`, not
  only its ref or sample id;
- preserve exact refs and Final-LCA outcome;
- escape model-authored raw HTML before Markdown rendering;
- produce printable HTML and, when requested, PDF from that same HTML.

The renderer must not select a better formula or sample, alter scientific
claims, localize prose, infer missing semantics, or hide negative evidence. A
rendering failure does not authorize mutating the formal report.
