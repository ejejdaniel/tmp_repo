# Evidence And Claim Audit

Use this reference when deciding how strongly the report may phrase a statement.

| Source level | What it can support | What it cannot support |
| --- | --- | --- |
| Task specification | The research question, constraints, target metric, and required outputs | A scientific result or material performance |
| Background or literature artifact | Reported context, cited prior knowledge, and explicit literature gaps | Proof that the current candidate works |
| Mind map | Candidate families, mechanisms, tensions, and search gaps | Selection of the best family or validation of a mechanism |
| Hypothesis | A bounded proposed mechanism, expected causal chain, risks, and verification plan | Executed experiments or confirmed causality |
| Formula artifact | Formula expression, inputs, direction, source bindings, and claim boundary | Correctness of the implementation or final KPI agreement |
| Code artifact and execution observation | What was implemented, which inputs were processed, outputs produced, and execution errors | Scientific validity beyond the declared computation |
| Ranking or private evaluator summary | Relative ordering, aggregate agreement, ties, and evaluator status | Raw private KPI values or universal predictive validity |
| Sample evolution result | Generated candidates, mutation lineage, scores, rank history, and progress or regression | Final KPI validation or experimental success |
| Reviewer or Final LCA judgment | Bounded claim verdict, blocking findings, and release state | Repair of upstream defects or proof outside its stated claim budget |

## Wording ladder

- **Source fact:** “資料記錄了……”
- **Computed observation:** “程式算出……”
- **Supported interpretation:** “在這批資料中，結果顯示……”
- **Hypothesis:** “我們提出……” or “可能是……”
- **Unresolved:** “目前無法判定……”
- **Negative result:** “本次沒有改善……”
- **Release decision:** Use only the exact outcome and rationale from the Final LCA artifact.

## Mandatory checks

1. Do not use a planned artifact ref as evidence.
2. Do not turn a child receipt or raw log into a scientific claim.
3. Do not use a single high score to call a sample best without the declared ranking cohort.
4. Do not hide a tie, regression, unscorable candidate, or execution inconsistency.
5. Do not infer a mechanism from a formula name or field name.
6. Respect explicitly restricted sources; ordinary task measurements may be reported with exact provenance. Separate them from transformed targets, aggregate scores and unmeasured predictions.
