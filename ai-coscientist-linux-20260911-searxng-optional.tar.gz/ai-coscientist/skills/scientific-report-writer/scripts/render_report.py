from __future__ import annotations

import argparse
import hashlib
import html
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

import markdown as markdown_library


PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "src"))

from ai_coscientist.common.artifacts import ArtifactStore
from ai_coscientist.common.code_artifacts import CodeArtifactStore
from ai_coscientist.common.development import DevelopmentProjectStore
from ai_coscientist.common.observations import ObservationStore
from ai_coscientist.common._runtime_support import stored_ref_strings
from ai_coscientist.common.reference_links import ReferenceResolver
from ai_coscientist.common.reference_rendering import render_reference_links
from ai_coscientist.common.implementation_projection import (
    automatic_short_file_projection,
    materialize_implementation_projection,
    projection_for_ref,
)


_MINDMAP_RENDERER: Any | None = None


def build_report_view(
    *,
    artifact_root: Path,
    report_ref: str,
    implementation_projections: Any = None,
    reference_resolver: ReferenceResolver | None = None,
) -> dict[str, Any]:
    """Resolve one formal report and its exact human-facing evidence."""
    root = artifact_root.resolve()
    store = ArtifactStore(
        root,
        agent_id="scientific-report-renderer",
        run_id=root.name,
    )
    report = store.read(report_ref)
    if report.get("artifact_kind") != "scientific_report":
        raise ValueError("scientific_report_renderer_kind_invalid")
    report_markdown = str(report.get("markdown") or "").strip()
    if not report_markdown:
        raise ValueError("scientific_report_renderer_markdown_required")

    payload = _mapping(
        report.get("machine_payload"),
        "scientific_report_renderer_payload",
    )
    evidence_index = payload.get("evidence_index")
    if not isinstance(evidence_index, list) or not evidence_index:
        raise ValueError("scientific_report_renderer_evidence_index_required")

    artifacts: list[dict[str, Any]] = []
    code_refs: list[str] = []
    seen_refs: set[str] = set()
    for raw_entry in evidence_index:
        entry = _mapping(raw_entry, "scientific_report_renderer_evidence_entry")
        evidence_ref = str(entry.get("evidence_ref") or "").strip()
        evidence_kind = str(entry.get("evidence_kind") or "").strip()
        if not evidence_ref or evidence_ref in seen_refs:
            raise ValueError(
                "scientific_report_renderer_evidence_ref_invalid:"
                f"{evidence_ref or 'missing'}"
            )
        seen_refs.add(evidence_ref)
        if evidence_ref.startswith("artifact:"):
            artifact = store.read(evidence_ref)
            if str(artifact.get("artifact_kind") or "") != evidence_kind:
                raise ValueError(
                    "scientific_report_renderer_evidence_kind_mismatch:"
                    f"{evidence_ref}"
                )
            artifacts.append(artifact)
        elif evidence_ref.startswith("code_artifact:"):
            code_refs.append(evidence_ref)

    sample_artifacts = [
        artifact
        for artifact in artifacts
        if artifact.get("artifact_kind") == "sample_evolution_result"
    ]
    mind_map_artifacts = [
        artifact
        for artifact in artifacts
        if artifact.get("artifact_kind") == "hypothesis_mind_map"
    ]
    hypothesis_artifacts = [
        artifact
        for artifact in artifacts
        if artifact.get("artifact_kind") == "hypothesis"
    ]
    final_lca = next(
        (
            artifact
            for artifact in artifacts
            if artifact.get("artifact_kind") == "final_lca_judgment"
        ),
        None,
    )
    code_artifacts = _load_code_artifacts(root, code_refs)
    implementation_evidence = [
        _code_implementation_evidence(item) for item in code_artifacts
    ]
    implementation_evidence.extend(
        _project_implementation_evidence(
            root,
            store=store,
            artifact=artifact,
        )
        for artifact in artifacts
        if artifact.get("artifact_kind") == "development_project_snapshot"
    )
    implementations: list[dict[str, Any]] = []
    for implementation in implementation_evidence:
        implementation_ref = str(implementation["implementation_ref"])
        projection = projection_for_ref(
            implementation_projections,
            implementation_ref,
        )
        if projection is None:
            projection = automatic_short_file_projection(implementation)
        if projection is None:
            raise ValueError(
                "scientific_report_implementation_projection_required:"
                f"{implementation_ref}"
            )
        implementations.append(
            materialize_implementation_projection(
                projection,
                implementation,
            )
        )

    return {
        "projection_kind": "scientific_report_human_projection_v1",
        "report": {
            "artifact_ref": str(report["artifact_ref"]),
            "title": str(report.get("title") or "科學研究報告"),
            "summary": str(report.get("summary") or "").strip(),
            "status": str(report.get("status") or ""),
            "markdown": report_markdown,
        },
        "evidence_index": [dict(_mapping(item, "evidence_entry")) for item in evidence_index],
        "code_artifacts": code_artifacts,
        "implementations": implementations,
        "sample_artifacts": sample_artifacts,
        "mind_map_artifacts": mind_map_artifacts,
        "hypothesis_artifacts": hypothesis_artifacts,
        "final_lca": final_lca,
        "_reference_resolver": _report_reference_resolver(root, store, report, reference_resolver),
    }


def render_report_html(
    view: Mapping[str, Any],
    *,
    pdf_download_name: str | None = None,
) -> str:
    report = _mapping(view.get("report"), "scientific_report_renderer_report")
    report_markdown = str(report.get("markdown") or "")
    rendered_markdown, toc = _render_markdown(report_markdown)
    title = str(report.get("title") or "科學研究報告")
    summary = str(report.get("summary") or "").strip() or _abstract(report_markdown)
    report_ref = str(report.get("artifact_ref") or "")
    evidence_index = _sequence(view.get("evidence_index"), "evidence_index")
    implementations = _sequence(view.get("implementations"), "implementations")
    sample_artifacts = _sequence(view.get("sample_artifacts"), "sample_artifacts")
    mind_map_artifacts = _sequence(
        view.get("mind_map_artifacts"),
        "mind_map_artifacts",
    )
    hypothesis_artifacts = _sequence(
        view.get("hypothesis_artifacts"),
        "hypothesis_artifacts",
    )
    final_lca = view.get("final_lca")
    final_outcome = _final_lca_outcome(final_lca)

    pdf_link = ""
    if pdf_download_name:
        safe_name = Path(pdf_download_name).name
        pdf_link = (
            f'<a class="tool-button" href="{_e(safe_name)}" '
            f'download="{_e(safe_name)}">下載 PDF</a>'
        )

    toc_html = "".join(
        f'<a href="#{_e(item["id"])}">{_e(item["name"])}</a>' for item in toc
    )
    implementation_html = "".join(
        _render_implementation_projection(item) for item in implementations
    )
    sample_html = "".join(_render_sample_artifact(item) for item in sample_artifacts)
    mind_map_html = "".join(
        _render_mind_map_artifact(item) for item in mind_map_artifacts
    )
    hypothesis_html = "".join(
        _render_hypothesis_artifact(item) for item in hypothesis_artifacts
    )
    evidence_rows = "".join(
        "<tr>"
        f"<td><code>{_e(item.get('evidence_kind'))}</code></td>"
        f"<td class=\"ref-cell\">{_e(item.get('evidence_ref'))}</td>"
        f"<td>{_e(item.get('use'))}</td>"
        "</tr>"
        for item in evidence_index
        if isinstance(item, Mapping)
    )
    outcome_class = _outcome_class(final_outcome)

    rendered = f"""<!doctype html>
<html lang="zh-Hant" data-theme="light">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{_e(title)}</title>
  <style>{_stylesheet()}</style>
</head>
<body data-report-ref="{_e(report_ref)}">
  <div class="toolbar" aria-label="報告工具列">
    <button class="tool-button" id="theme-toggle" type="button">深色／淺色</button>
    {pdf_link}
    <button class="tool-button" type="button" onclick="window.print()">列印</button>
  </div>
  <main class="page">
    <header class="hero">
      <p class="eyebrow">SCIENTIFIC REPORT / HUMAN PROJECTION</p>
      <h1>{_e(title)}</h1>
      <div class="meta">
        <span>正式報告：{_e(report_ref)}</span>
        <span>artifact 狀態：{_e(report.get('status') or '未標示')}</span>
      </div>
    </header>

    <section class="summary-band" aria-label="報告摘要">
      <p class="summary-label">研究摘要</p>
      <p>{_e(summary)}</p>
    </section>

    <section class="overview" aria-label="報告速覽">
      <article><small>Final LCA</small><strong class="{outcome_class}">{_e(final_outcome)}</strong></article>
      <article><small>正式證據</small><strong>{len(evidence_index)}</strong></article>
      <article><small>正式實作</small><strong>{len(implementations)}</strong></article>
      <article><small>樣本成果</small><strong>{len(sample_artifacts)}</strong></article>
    </section>

    <nav class="toc" aria-label="目錄">
      <p>報告目錄</p>
      <a href="#formal-report">正式科學報告</a>
      <a href="#mind-map-appendix">完整心智圖</a>
      <a href="#hypothesis-appendix">完整假說</a>
      <a href="#sample-appendix">完整樣本</a>
      <a href="#code-appendix">實作摘要</a>
      <a href="#evidence-appendix">證據索引</a>
      {toc_html}
    </nav>

    <section class="section report-shell" id="formal-report">
      {_section_heading('01', '正式科學報告', '以正式 scientific_report artifact 為敘事權威。')}
      <article class="markdown-body">{rendered_markdown}</article>
    </section>

    <section class="section" id="mind-map-appendix">
      {_section_heading('02', '完整機制研究心智圖', '直接投影 exact hypothesis_mind_map；不以報告摘要取代 family 與關係。')}
      {mind_map_html or '<div class="empty">本報告未引用 hypothesis_mind_map。</div>'}
    </section>

    <section class="section" id="hypothesis-appendix">
      {_section_heading('03', '完整科學假說', '直接投影 exact hypothesis 的意圖、主張、機制、風險與驗證手段。')}
      {hypothesis_html or '<div class="empty">本報告未引用 hypothesis。</div>'}
    </section>

    <section class="section" id="sample-appendix">
      {_section_heading('04', '完整樣本資料', '直接呈現正式 sample artifact 的內容，不以編號代替樣本。')}
      {sample_html or '<div class="empty">本報告未引用 sample_evolution_result。</div>'}
    </section>

    <section class="section" id="code-appendix">
      {_section_heading('05', '實作摘要與關鍵程式', '完整專案保留為稽核證據；此處只呈現經驗證的實作說明與 exact source ranges。')}
      {implementation_html or '<div class="empty">本報告未引用正式實作。</div>'}
    </section>

    <section class="section" id="evidence-appendix">
      {_section_heading('06', '精確證據索引', '正式報告所列的完整 ref 與用途。')}
      <div class="table-wrap"><table><thead><tr><th>種類</th><th>精確 ref</th><th>用途</th></tr></thead><tbody>{evidence_rows}</tbody></table></div>
    </section>

    <footer>
      此 HTML／PDF 是 formal scientific_report 的確定性人類呈現投影。
      科學敘事以正式 report artifact 為權威；renderer 不新增、修訂或評分科學主張。
    </footer>
  </main>
  <script>
    const root = document.documentElement;
    document.getElementById('theme-toggle').addEventListener('click', () => {{
      root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
    }});
  </script>
</body>
</html>
"""
    resolver = view.get("_reference_resolver")
    return render_reference_links(rendered, resolver, inline=True) if resolver is not None else rendered


def _report_reference_resolver(
    root: Path, store: ArtifactStore, report: Mapping[str, Any],
    authorized_resolver: ReferenceResolver | None = None,
) -> ReferenceResolver:
    projects = DevelopmentProjectStore(root, artifacts=store)
    observations = ObservationStore(root)
    codes = CodeArtifactStore(root)
    allowed = set(stored_ref_strings(report))
    allowed.update(str(item["evidence_ref"]) for item in
        report.get("machine_payload", {}).get("evidence_index", ()) if item.get("evidence_ref"))
    visited: set[str] = set()

    def record(ref: str) -> Any:
        if ref.startswith("artifact:"):
            return store.read(ref)
        if ref.startswith("execution_observation:"):
            return observations.read(ref)
        if ref.startswith("code_artifact:"):
            return codes.read(ref)
        if ref.startswith("development_output:"):
            return projects.output_bytes(ref)
        raise ValueError(f"report_reference_source_unavailable:{ref}")

    pending = list(allowed)
    while pending:
        ref = pending.pop()
        if ref in visited:
            continue
        visited.add(ref)
        try:
            linked = set(stored_ref_strings(record(ref)))
        except (KeyError, ValueError, OSError):
            continue
        pending.extend(linked - allowed)
        allowed.update(linked)

    def load(ref: str, path: str | None) -> Any:
        if ref not in allowed:
            raise PermissionError(f"report_reference_not_in_evidence_lineage:{ref}")
        if authorized_resolver is not None:
            # Preserve the caller's source scopes; a report URI grants no filesystem access.
            return authorized_resolver.load_source(ref, path)
        value = record(ref)
        if path is not None:
            if value.get("artifact_kind") != "development_project_snapshot":
                raise ValueError("reference_path_requires_snapshot")
            return projects.snapshot_file_bytes(ref, path)
        return value

    return ReferenceResolver(load)


def verify_report_html(rendered: str, view: Mapping[str, Any]) -> None:
    report = _mapping(view.get("report"), "scientific_report_renderer_report")
    report_ref = str(report.get("artifact_ref") or "")
    issues: list[str] = []
    for required in (
        "id=\"formal-report\"",
        "完整機制研究心智圖",
        "完整科學假說",
        "完整樣本資料",
        "實作摘要與關鍵程式",
        "精確證據索引",
        report_ref,
    ):
        if required not in rendered:
            issues.append(f"required_content_missing:{required}")

    for item in _sequence(view.get("implementations"), "implementations"):
        implementation = _mapping(item, "implementation_projection")
        implementation_ref = str(implementation.get("implementation_ref") or "")
        if implementation_ref not in rendered:
            issues.append(f"implementation_ref_missing:{implementation_ref}")
        for value in (
            implementation.get("overview_zh_tw"),
            implementation.get("omitted_files_summary"),
        ):
            if _e(value) not in rendered:
                issues.append(
                    f"implementation_projection_text_missing:{implementation_ref}"
                )
        for snippet in _sequence(
            implementation.get("snippets"),
            "implementation_snippets",
        ):
            exact = _mapping(snippet, "implementation_snippet")
            for value in (
                exact.get("path"),
                exact.get("purpose_zh_tw"),
                exact.get("source"),
            ):
                if _e(value) not in rendered:
                    issues.append(
                        f"implementation_snippet_missing:{implementation_ref}"
                    )

    for item in _sequence(view.get("sample_artifacts"), "sample_artifacts"):
        sample = _mapping(item, "sample_artifact")
        sample_ref = str(sample.get("artifact_ref") or "")
        if sample_ref not in rendered:
            issues.append(f"sample_ref_missing:{sample_ref}")
        payload = json.dumps(
            sample.get("machine_payload"),
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        marker = html.escape(payload[: min(len(payload), 160)], quote=True)
        if marker and marker not in rendered:
            issues.append(f"sample_payload_missing:{sample_ref}")

    for item in _sequence(view.get("mind_map_artifacts"), "mind_map_artifacts"):
        artifact = _mapping(item, "mind_map_artifact")
        artifact_ref = str(artifact.get("artifact_ref") or "")
        if artifact_ref not in rendered:
            issues.append(f"mind_map_ref_missing:{artifact_ref}")
        for value in _mind_map_projection_texts(artifact):
            if _e(value) not in rendered:
                issues.append(
                    "mind_map_content_missing:"
                    f"{artifact_ref}:{value[:80]}"
                )

    for item in _sequence(view.get("hypothesis_artifacts"), "hypothesis_artifacts"):
        artifact = _mapping(item, "hypothesis_artifact")
        artifact_ref = str(artifact.get("artifact_ref") or "")
        if artifact_ref not in rendered:
            issues.append(f"hypothesis_ref_missing:{artifact_ref}")
        for value in _hypothesis_projection_texts(artifact):
            if _e(value) not in rendered:
                issues.append(
                    "hypothesis_content_missing:"
                    f"{artifact_ref}:{value[:80]}"
                )

    if issues:
        raise ValueError("scientific_report_html_invalid:" + ";".join(issues))


def write_report_projection(
    *,
    artifact_root: Path,
    report_ref: str,
    html_output: Path,
    pdf_output: Path | None = None,
    browser_executable: Path | None = None,
    implementation_projections: Any = None,
    reference_resolver: ReferenceResolver | None = None,
    force: bool = False,
) -> dict[str, Any]:
    html_path = html_output.resolve()
    pdf_path = pdf_output.resolve() if pdf_output is not None else None
    for path in (html_path, pdf_path):
        if path is not None and path.exists() and not force:
            raise FileExistsError(f"scientific_report_projection_exists:{path}")

    view = build_report_view(
        artifact_root=artifact_root,
        report_ref=report_ref,
        implementation_projections=implementation_projections,
        reference_resolver=reference_resolver,
    )
    rendered = render_report_html(
        view,
        pdf_download_name=(pdf_path.name if pdf_path is not None else None),
    )
    verify_report_html(rendered, view)
    html_path.parent.mkdir(parents=True, exist_ok=True)
    html_path.write_text(rendered, encoding="utf-8")
    if pdf_path is not None:
        _render_pdf(
            html_path,
            pdf_path,
            browser_executable=browser_executable,
        )
    return {
        "status": "complete",
        "report_ref": report_ref,
        "html_path": str(html_path),
        "pdf_path": str(pdf_path) if pdf_path is not None else "",
        "evidence_count": len(view["evidence_index"]),
        "implementation_count": len(view["implementations"]),
        "code_artifact_count": len(view["code_artifacts"]),
        "sample_artifact_count": len(view["sample_artifacts"]),
        "mind_map_artifact_count": len(view["mind_map_artifacts"]),
        "hypothesis_artifact_count": len(view["hypothesis_artifacts"]),
    }


def _load_code_artifacts(root: Path, code_refs: Sequence[str]) -> list[dict[str, Any]]:
    if not code_refs:
        return []
    code_store = CodeArtifactStore(root)
    result: list[dict[str, Any]] = []
    for code_ref in code_refs:
        try:
            entry = code_store.read(code_ref)
        except (FileNotFoundError, KeyError, ValueError) as exc:
            raise ValueError(
                f"scientific_report_renderer_code_invalid:{code_ref}:{exc}"
            ) from exc
        result.append(
            {
                "code_artifact_ref": code_ref,
                "language": str(entry.get("language") or "text"),
                "purpose": str(entry.get("purpose") or ""),
                "sha256": str(entry.get("sha256") or ""),
                "source": str(entry.get("code") or ""),
            }
        )
    return result


def _code_implementation_evidence(
    code_artifact: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "implementation_ref": str(code_artifact["code_artifact_ref"]),
        "implementation_kind": "code_artifact",
        "purpose": str(code_artifact.get("purpose") or ""),
        "environment_ref": "legacy-python",
        "entry_command": [],
        "working_directory": "",
        "source_files": [
            {
                "path": "implementation.py",
                "language": str(code_artifact.get("language") or "text"),
                "source": str(code_artifact.get("source") or ""),
                "sha256": str(code_artifact.get("sha256") or ""),
            }
        ],
    }


def _project_implementation_evidence(
    root: Path,
    *,
    store: ArtifactStore,
    artifact: Mapping[str, Any],
) -> dict[str, Any]:
    implementation_ref = str(artifact.get("artifact_ref") or "").strip()
    projects = DevelopmentProjectStore(root, artifacts=store)
    payload = projects.snapshot_payload(implementation_ref)
    files = projects.snapshot_files(implementation_ref)
    source_files: list[dict[str, Any]] = []
    for relative_path, body in sorted(files.items()):
        try:
            source = body.decode("utf-8")
        except UnicodeDecodeError:
            continue
        source_files.append(
            {
                "path": relative_path,
                "language": Path(relative_path).suffix.lstrip(".") or "text",
                "source": source,
                "sha256": hashlib.sha256(body).hexdigest(),
            }
        )
    if not source_files:
        raise ValueError(
            f"scientific_report_project_source_missing:{implementation_ref}"
        )
    return {
        "implementation_ref": implementation_ref,
        "implementation_kind": "development_project_snapshot",
        "purpose": str(
            payload.get("purpose")
            or artifact.get("summary")
            or artifact.get("title")
            or ""
        ),
        "environment_ref": str(payload.get("environment_ref") or ""),
        "entry_command": [
            str(value) for value in payload.get("entry_command") or ()
        ],
        "working_directory": str(payload.get("working_directory") or ""),
        "source_files": source_files,
    }


def _render_markdown(source: str) -> tuple[str, list[dict[str, str]]]:
    # Escaping first keeps model-authored HTML inert while retaining Markdown syntax.
    renderer = markdown_library.Markdown(
        extensions=["extra", "sane_lists", "toc"],
        output_format="html5",
    )
    rendered = renderer.convert(html.escape(source, quote=False))
    toc = _flatten_toc(renderer.toc_tokens)
    return rendered, toc


def _flatten_toc(items: Sequence[Mapping[str, Any]]) -> list[dict[str, str]]:
    result: list[dict[str, str]] = []
    for item in items:
        item_id = str(item.get("id") or "").strip()
        name = str(item.get("name") or "").strip()
        if item_id and name:
            result.append({"id": item_id, "name": name})
        children = item.get("children")
        if isinstance(children, list):
            result.extend(_flatten_toc(children))
    return result


def _section_heading(index: str, title: str, note: str) -> str:
    return (
        '<div class="section-heading">'
        f'<p class="section-index">{_e(index)}</p>'
        '<div>'
        f'<h2>{_e(title)}</h2>'
        f'<p>{_e(note)}</p>'
        '</div></div>'
    )


def _render_mind_map_artifact(raw: Any) -> str:
    artifact = _mapping(raw, "mind_map_artifact")
    machine_payload = _mapping(
        artifact.get("machine_payload"),
        "mind_map_machine_payload",
    )
    landscape_value = machine_payload.get("mechanism_landscape")
    landscape = (
        _mapping(landscape_value, "mechanism_landscape")
        if isinstance(landscape_value, Mapping)
        else machine_payload
    )
    renderer = _mindmap_renderer()
    families = renderer._validated_families(landscape)
    family_ids = {str(item["family_id"]) for item in families}
    relationships = renderer._string_list(landscape.get("supported_relationships"))
    unresolved_gaps = renderer._string_list(landscape.get("unresolved_gaps"))
    title = str(artifact.get("title") or "機制研究心智圖")
    summary = str(
        landscape.get("mechanism_landscape_summary")
        or landscape.get("landscape_summary")
        or "未提供整體研究景觀摘要。"
    )
    evidence_boundary = str(
        landscape.get("evidence_boundary_summary")
        or "未提供證據邊界摘要。"
    )
    causal_map = renderer._render_causal_map_svg(
        families,
        title=title,
        evidence_summary=evidence_boundary,
        relationships=relationships,
    )
    family_cards = "".join(
        renderer._render_family(family, index=index)
        for index, family in enumerate(families)
    )
    relationship_rows = renderer._render_relationships(
        relationships,
        family_ids=family_ids,
    )
    gap_rows = renderer._render_list(
        unresolved_gaps,
        empty_text="目前沒有列出的未解缺口。",
        css_class="gap-list",
    )
    return f"""
<article class="artifact-projection mind-map-projection" data-artifact-ref="{_e(artifact.get('artifact_ref'))}">
  <header class="artifact-head">
    <p class="artifact-kind">HYPOTHESIS MIND MAP</p>
    <h3>{_e(title)}</h3>
    <p class="artifact-ref">{_e(artifact.get('artifact_ref'))}</p>
  </header>
  <div class="projection-summary"><strong>機制研究景觀</strong><p>{_e(summary)}</p></div>
  <div class="map-shell">{causal_map}</div>
  <div class="subsection-head"><h4>方法家族完整定義</h4><span>{len(families)} 個 family</span></div>
  <div class="family-grid">{family_cards}</div>
  <div class="subsection-head"><h4>族群關係</h4><span>保留方向、耦合與解釋</span></div>
  <div class="relations">{relationship_rows}</div>
  <div class="subsection-head"><h4>未解研究缺口</h4><span>不得由報告自行補寫</span></div>
  {gap_rows}
  <aside class="evidence-boundary"><strong>證據邊界</strong><p>{_e(evidence_boundary)}</p></aside>
</article>
"""


def _render_hypothesis_artifact(raw: Any) -> str:
    artifact = _mapping(raw, "hypothesis_artifact")
    payload = _mapping(
        artifact.get("machine_payload"),
        "hypothesis_machine_payload",
    )
    risks = _text_list(payload.get("risks"))
    verification_plan = _text_list(payload.get("verification_plan"))
    source_refs = _text_list(payload.get("source_refs"))
    direction_value = payload.get("direction_card")
    direction = direction_value if isinstance(direction_value, Mapping) else {}
    risk_cards = "".join(
        '<article class="risk-card">'
        f'<span>RISK {index:02d}</span><p>{_e(item)}</p>'
        '</article>'
        for index, item in enumerate(risks, start=1)
    )
    verification_items = "".join(
        '<li><span class="verification-index">'
        f'{index:02d}</span><p>{_e(item)}</p></li>'
        for index, item in enumerate(verification_plan, start=1)
    )
    source_items = "".join(
        f'<li><code>{_e(item)}</code></li>' for item in source_refs
    )
    return f"""
<article class="artifact-projection hypothesis-projection" data-artifact-ref="{_e(artifact.get('artifact_ref'))}">
  <header class="artifact-head">
    <p class="artifact-kind">SCIENTIFIC HYPOTHESIS</p>
    <h3>{_e(payload.get('title') or artifact.get('title') or '科學假說')}</h3>
    <p class="artifact-ref">{_e(artifact.get('artifact_ref'))}</p>
    <div class="meta compact-meta">
      <span>family：{_e(direction.get('family_id') or '未提供')}</span>
      <span>status：{_e(artifact.get('status') or '未標示')}</span>
      <span>hypothesis id：{_e(payload.get('id') or '未提供')}</span>
    </div>
  </header>
  <section class="hypothesis-summary">
    <p class="summary-label">明確意圖</p>
    <p>{_e(payload.get('description') or '未提供')}</p>
  </section>
  <section class="claim-band">
    <h4>可反駁核心主張</h4>
    <p>{_e(payload.get('core_claim') or '未提供')}</p>
  </section>
  <section class="mechanism-panel">
    <p class="panel-label">因果機制</p>
    <p>{_e(payload.get('mechanism') or '未提供')}</p>
  </section>
  <div class="subsection-head"><h4>主要風險與適用邊界</h4><span>{len(risks)} 項</span></div>
  <div class="risk-grid">{risk_cards or '<div class="empty">未提供 risks。</div>'}</div>
  <div class="subsection-head"><h4>建議驗證手段</h4><span>{len(verification_plan)} 項</span></div>
  <ol class="verification-list">{verification_items or '<li><p>未提供 verification_plan。</p></li>'}</ol>
  <section class="direction-panel">
    <p class="panel-label">研究譜系定位</p>
    <p><strong>{_e(direction.get('family_id') or '未提供 family_id')}</strong></p>
    <p>{_e(direction.get('lineage_role') or '未提供 lineage_role')}</p>
  </section>
  <section class="source-trace">
    <p class="panel-label">精確來源</p>
    <ul>{source_items or '<li>未提供 source_refs。</li>'}</ul>
  </section>
</article>
"""


def _mindmap_renderer() -> Any:
    global _MINDMAP_RENDERER
    if _MINDMAP_RENDERER is not None:
        return _MINDMAP_RENDERER
    path = PROJECT_ROOT / "scripts" / "render_mindmap_artifact.py"
    spec = importlib.util.spec_from_file_location(
        "scientific_report_mindmap_renderer",
        path,
    )
    if spec is None or spec.loader is None:
        raise ImportError(f"scientific_report_mindmap_renderer_load_failed:{path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _MINDMAP_RENDERER = module
    return module


def _text_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()]


def _mind_map_projection_texts(artifact: Mapping[str, Any]) -> list[str]:
    machine_payload = _mapping(
        artifact.get("machine_payload"),
        "mind_map_machine_payload",
    )
    landscape_value = machine_payload.get("mechanism_landscape")
    landscape = (
        _mapping(landscape_value, "mechanism_landscape")
        if isinstance(landscape_value, Mapping)
        else machine_payload
    )
    values: list[str] = []
    for key in (
        "mechanism_landscape_summary",
        "landscape_summary",
        "evidence_boundary_summary",
        "unresolved_gaps",
    ):
        values.extend(_string_leaves(landscape.get(key)))
    for family in landscape.get("families") or []:
        if isinstance(family, Mapping):
            values.extend(_string_leaves(family))

    renderer = _mindmap_renderer()
    for relationship in renderer._string_list(
        landscape.get("supported_relationships")
    ):
        match = renderer._RELATION_PATTERN.match(relationship)
        if match is None:
            values.append(relationship)
        else:
            source_id, _, target_id, explanation = match.groups()
            values.extend((source_id, target_id, explanation))
    return _ordered_texts(values)


def _hypothesis_projection_texts(artifact: Mapping[str, Any]) -> list[str]:
    payload = _mapping(
        artifact.get("machine_payload"),
        "hypothesis_machine_payload",
    )
    values: list[str] = []
    for key in (
        "id",
        "title",
        "description",
        "mechanism",
        "core_claim",
        "risks",
        "verification_plan",
        "source_refs",
        "direction_card",
    ):
        values.extend(_string_leaves(payload.get(key)))
    return _ordered_texts(values)


def _string_leaves(value: Any) -> list[str]:
    if isinstance(value, str):
        stripped = value.strip()
        return [stripped] if stripped else []
    if isinstance(value, Mapping):
        result: list[str] = []
        for child in value.values():
            result.extend(_string_leaves(child))
        return result
    if isinstance(value, list):
        result = []
        for child in value:
            result.extend(_string_leaves(child))
        return result
    return []


def _ordered_texts(values: Sequence[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result


def _render_implementation_projection(raw: Any) -> str:
    item = _mapping(raw, "implementation_projection")
    command = " ".join(str(value) for value in item.get("entry_command") or ())
    flow = "".join(
        f"<li>{_e(value)}</li>" for value in item.get("execution_flow") or ()
    )
    decisions = "".join(
        f"<li>{_e(value)}</li>" for value in item.get("key_decisions") or ()
    )
    manifest = "".join(
        '<li><code>'
        f'{_e(_mapping(value, "implementation_manifest_entry").get("path"))}'
        '</code> · '
        f'{_e(_mapping(value, "implementation_manifest_entry").get("line_count"))} 行</li>'
        for value in item.get("file_manifest") or ()
    )
    snippets = "".join(
        '<section class="source-file">'
        f'<h4>{_e(_mapping(value, "implementation_snippet").get("path"))} '
        f'第 {_e(_mapping(value, "implementation_snippet").get("start_line"))}–'
        f'{_e(_mapping(value, "implementation_snippet").get("end_line"))} 行</h4>'
        f'<p>{_e(_mapping(value, "implementation_snippet").get("purpose_zh_tw"))}</p>'
        f'<pre><code>{_e(_mapping(value, "implementation_snippet").get("source"))}</code></pre>'
        '</section>'
        for value in item.get("snippets") or ()
    )
    return (
        '<article class="source-panel">'
        f'<h3>{_e(item.get("purpose") or "正式實作")}</h3>'
        '<div class="source-meta">'
        f'<span>{_e(item.get("implementation_ref"))}</span>'
        f'<span>environment={_e(item.get("environment_ref"))}</span>'
        f'<span>entry={_e(command)}</span>'
        '</div>'
        f'<p>{_e(item.get("overview_zh_tw"))}</p>'
        '<h4>執行流程</h4>'
        f'<ol>{flow}</ol>'
        '<h4>關鍵實作決策</h4>'
        f'<ul>{decisions}</ul>'
        '<h4>專案檔案清單</h4>'
        f'<ul>{manifest}</ul>'
        f'{snippets}'
        f'<p>{_e(item.get("omitted_files_summary"))}</p>'
        '</article>'
    )


def _render_sample_artifact(raw: Any) -> str:
    artifact = _mapping(raw, "sample_artifact")
    payload = _mapping(artifact.get("machine_payload"), "sample_payload")
    best = payload.get("best_sample")
    best_sample = best if isinstance(best, Mapping) else {}
    ranked = payload.get("ranked_samples")
    ranked_samples = ranked if isinstance(ranked, list) else []
    index_values = best_sample.get("index_values")
    index_ranks = best_sample.get("index_ranks")
    best_fields = [
        ("sample_id", best_sample.get("sample_id")),
        ("SMILES", best_sample.get("smiles") or best_sample.get("canonical_smiles")),
        ("proxy_value", best_sample.get("proxy_value")),
        ("Pareto tier", best_sample.get("pareto_tier")),
        ("index_values", _compact_json(index_values)),
        ("index_ranks", _compact_json(index_ranks)),
    ]
    best_rows = "".join(
        f"<tr><th>{_e(label)}</th><td>{_e(value)}</td></tr>"
        for label, value in best_fields
        if value not in (None, "")
    )
    population_rows = "".join(
        "<tr>"
        f"<td>{_e(item.get('sample_id'))}</td>"
        f"<td>{_e(item.get('smiles') or item.get('canonical_smiles') or item.get('input_description'))}</td>"
        f"<td>{_e(item.get('proxy_value'))}</td>"
        f"<td>{_e(_compact_json(item.get('index_ranks')))}</td>"
        f"<td>{_e(item.get('pareto_tier'))}</td>"
        "</tr>"
        for item in ranked_samples
        if isinstance(item, Mapping)
    )
    if not population_rows:
        population_rows = '<tr><td colspan="5">無完整排名族群。</td></tr>'
    description = str(best_sample.get("input_description") or "")
    raw_payload = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
    return f"""
<article class="sample-panel">
  <h3>{_e(artifact.get('title') or artifact.get('artifact_ref'))}</h3>
  <p class="ref-line">{_e(artifact.get('artifact_ref'))}</p>
  <div class="sample-grid">
    <div><h4>本輪最佳生成樣本</h4><table class="kv-table"><tbody>{best_rows}</tbody></table></div>
    <div><h4>完整描述</h4><p>{_e(description or '正式 artifact 未提供 input_description。')}</p></div>
  </div>
  <h4>全體樣本排名</h4>
  <div class="table-wrap"><table class="sample-ranking-table"><thead><tr><th>樣本</th><th>結構／輸入</th><th>代理值</th><th>索引名次</th><th>Pareto</th></tr></thead><tbody>{population_rows}</tbody></table></div>
  <h4>完整 machine payload</h4>
  <pre class="json-source"><code>{_e(raw_payload)}</code></pre>
</article>
"""


def _final_lca_outcome(raw: Any) -> str:
    if not isinstance(raw, Mapping):
        return "未提供"
    payload = raw.get("machine_payload")
    if isinstance(payload, Mapping):
        judgment = payload.get("final_lca_judgment")
        if isinstance(judgment, Mapping):
            outcome = str(judgment.get("outcome") or "").strip()
            if outcome:
                return outcome
    review = raw.get("self_review")
    if isinstance(review, Mapping):
        outcome = str(review.get("outcome") or "").strip()
        if outcome:
            return outcome
    return "未標示"


def _outcome_class(outcome: str) -> str:
    normalized = outcome.strip().lower()
    if normalized in {"released", "accepted", "supported"}:
        return "positive"
    if normalized in {"bounded_reject", "rejected", "blocked"}:
        return "negative"
    return "neutral"


def _abstract(markdown_source: str) -> str:
    lines = markdown_source.splitlines()
    inside = False
    paragraphs: list[str] = []
    for raw in lines:
        line = raw.strip()
        if line == "## 摘要":
            inside = True
            continue
        if inside and line.startswith("## "):
            break
        if inside and line:
            paragraphs.append(line)
    return " ".join(paragraphs[:2]) or "本頁呈現正式科學報告與其精確證據附件。"


def _compact_json(value: Any) -> str:
    if value in (None, ""):
        return ""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _mapping(value: Any, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{name}_must_be_object")
    return value


def _sequence(value: Any, name: str) -> list[Any]:
    if not isinstance(value, list):
        raise ValueError(f"{name}_must_be_array")
    return value


def _e(value: Any) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def _resolve_browser_executable(explicit: Path | None) -> Path:
    if explicit is not None:
        candidate = explicit.resolve()
        if candidate.is_file():
            return candidate
        raise FileNotFoundError(f"scientific_report_pdf_browser_not_found:{candidate}")

    environment_candidates = [
        os.environ.get("CHROME_BIN"),
        os.environ.get("CHROMIUM_BIN"),
    ]
    for value in environment_candidates:
        if value and Path(value).is_file():
            return Path(value).resolve()

    for executable in (
        "msedge",
        "chrome",
        "google-chrome",
        "google-chrome-stable",
        "chromium",
        "chromium-browser",
    ):
        located = shutil.which(executable)
        if located:
            return Path(located).resolve()

    for candidate in (
        Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
        Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
        Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
        Path(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
    ):
        if candidate.is_file():
            return candidate.resolve()
    raise FileNotFoundError("scientific_report_pdf_browser_not_found")


def _render_pdf(
    html_path: Path,
    pdf_path: Path,
    *,
    browser_executable: Path | None = None,
) -> None:
    source = html_path.resolve()
    destination = pdf_path.resolve()
    if not source.is_file():
        raise FileNotFoundError(f"scientific_report_pdf_html_not_found:{source}")
    browser = _resolve_browser_executable(browser_executable)
    destination.parent.mkdir(parents=True, exist_ok=True)

    # Chromium may keep its disposable profile locked briefly after the headless
    # parent exits. That delayed cleanup must not override a signature-verified
    # PDF result on Windows.
    with tempfile.TemporaryDirectory(
        prefix="scientific-report-pdf-",
        ignore_cleanup_errors=True,
    ) as temporary:
        temporary_path = Path(temporary)
        staged_pdf = temporary_path / destination.name
        profile_path = temporary_path / "browser-profile"
        completed = subprocess.run(
            [
                str(browser),
                "--headless=new",
                "--disable-gpu",
                "--disable-extensions",
                "--no-pdf-header-footer",
                "--run-all-compositor-stages-before-draw",
                "--virtual-time-budget=3000",
                f"--user-data-dir={profile_path}",
                f"--print-to-pdf={staged_pdf}",
                source.as_uri(),
            ],
            capture_output=True,
            timeout=120,
            check=False,
        )
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and not staged_pdf.is_file():
            time.sleep(0.1)
        if completed.returncode != 0 or not staged_pdf.is_file():
            detail = (completed.stderr or completed.stdout or b"")
            if isinstance(detail, bytes):
                detail = detail.decode("utf-8", errors="replace")
            raise RuntimeError(
                "scientific_report_pdf_render_failed:"
                f"exit={completed.returncode}:detail={str(detail).strip()[-2000:]}"
            )
        if staged_pdf.stat().st_size < 1024:
            raise RuntimeError("scientific_report_pdf_render_empty")
        with staged_pdf.open("rb") as stream:
            if stream.read(5) != b"%PDF-":
                raise RuntimeError("scientific_report_pdf_render_invalid_signature")
        shutil.copyfile(staged_pdf, destination)


def _stylesheet() -> str:
    return r"""
:root {
  --page: #f3f3ef; --surface: #fffefb; --surface-alt: #f7f6f1;
  --panel: var(--surface); --panel-soft: var(--surface-alt);
  --ink: #242a2d; --muted: #677075; --faint:#929a9b; --line: #cfd0ca; --grid:#e3e1da;
  --teal: #3f7477; --teal-soft: #e7f0ef; --brick: #985a51;
  --brick-soft: #f4e8e5; --gold: #8a6c35; --gold-soft: #f2ecdf;
  --green: #53735e; --green-soft: #e8efe9; --code: #182225;
  --code-ink: #eaf1ed; --shadow: 0 10px 28px rgba(36,42,45,.07);
  --accent-0:#497b88; --soft-0:#e6f0f1; --accent-1:#7a628e; --soft-1:#eee8f2;
  --accent-2:#9b7545; --soft-2:#f3ece0; --accent-3:#526f61; --soft-3:#e7efe9;
  --accent-4:#9a5c59; --soft-4:#f4e9e6; --accent-5:#73808a; --soft-5:#edf0f1;
  --danger:#9a5c59; --danger-soft:#f4e9e6;
}
[data-theme="dark"] {
  --page: #1d2325; --surface: #282f31; --surface-alt: #22292b;
  --panel: var(--surface); --panel-soft: var(--surface-alt);
  --ink: #edf0ec; --muted: #b5bdba; --faint:#7c8788; --line: #4a5556; --grid:#323a3c;
  --teal: #85b7b8; --teal-soft: #2a3d3e; --brick: #d49288;
  --brick-soft: #432f2d; --gold: #cfb16f; --gold-soft: #403827;
  --green: #96b69f; --green-soft: #2b3d31; --code: #111718;
  --code-ink: #edf2ee; --shadow: 0 12px 30px rgba(0,0,0,.22);
  --accent-0:#86b7c0; --soft-0:#2b3c40; --accent-1:#b19ac1; --soft-1:#3a3041;
  --accent-2:#cfaa72; --soft-2:#40372a; --accent-3:#94b8a0; --soft-3:#2d4034;
  --accent-4:#d29590; --soft-4:#432f2f; --accent-5:#aab6bd; --soft-5:#30383b;
  --danger:#d29590; --danger-soft:#432f2f;
}
* { box-sizing: border-box; }
html { background: var(--page); color: var(--ink); scroll-behavior: smooth; }
body { margin: 0; min-width: 320px; background: var(--page); color: var(--ink); font-family: "Noto Sans TC", "Microsoft JhengHei", Arial, sans-serif; line-height: 1.72; }
h1,h2,h3,h4 { margin-top: 0; font-family: "Noto Serif TC", "PMingLiU", Georgia, serif; letter-spacing: 0; }
p,li,td,th,code { overflow-wrap: anywhere; }
.toolbar { display:flex; flex-wrap:wrap; justify-content:flex-end; gap:8px; width:min(1240px,calc(100% - 28px)); margin:0 auto; padding:15px 0 4px; }
.tool-button { border:1px solid var(--line); border-radius:4px; background:var(--surface); color:var(--ink); padding:7px 11px; font:inherit; font-size:12px; text-decoration:none; cursor:pointer; }
.page { width:min(1240px,calc(100% - 28px)); margin:0 auto 46px; }
.hero { position:relative; overflow:hidden; border:1px solid var(--line); border-radius:6px; background:var(--surface); padding:30px 34px 28px; box-shadow:var(--shadow); }
.hero::before { position:absolute; inset:0 auto 0 0; width:7px; background:var(--teal); content:""; }
.eyebrow { margin:0 0 7px; color:var(--teal); font:800 11px/1.4 Consolas,monospace; }
h1 { max-width:1080px; margin:0; font-size:34px; font-weight:600; line-height:1.35; }
.meta { display:flex; flex-wrap:wrap; gap:7px; margin-top:18px; }
.meta span { border:1px solid var(--line); border-radius:999px; background:var(--surface-alt); padding:4px 9px; color:var(--muted); font:11px/1.5 Consolas,monospace; overflow-wrap:anywhere; }
.summary-band { margin-top:18px; border-top:4px solid var(--teal); background:var(--teal-soft); padding:23px 27px 25px; }
.summary-label { margin:0 0 8px; color:var(--teal); font-size:11px; font-weight:800; }
.summary-band > p:last-child { max-width:1100px; margin:0; font-size:17px; line-height:1.8; white-space:pre-wrap; }
.overview { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); margin-top:18px; border:1px solid var(--line); background:var(--surface); }
.overview article { min-width:0; padding:17px 19px; }
.overview article + article { border-left:1px solid var(--line); }
.overview small { display:block; color:var(--muted); font-size:11px; }
.overview strong { display:block; margin-top:4px; color:var(--teal); font-size:18px; }
.overview .positive { color:var(--green); } .overview .negative { color:var(--brick); } .overview .neutral { color:var(--gold); }
.toc { display:flex; flex-wrap:wrap; gap:8px 16px; margin:22px 0; border-left:5px solid var(--gold); background:var(--gold-soft); padding:14px 18px; }
.toc p { width:100%; margin:0; color:var(--gold); font-weight:800; }
.toc a { color:var(--ink); font-size:12px; text-decoration:none; }
.section { padding:30px 4px 4px; }
.section-heading { display:grid; grid-template-columns:46px minmax(0,1fr); gap:14px; align-items:start; margin-bottom:17px; }
.section-index { margin:4px 0 0; border-top:2px solid currentColor; color:var(--teal); font:800 12px/1.6 Consolas,monospace; }
.section-heading h2 { margin:0; font-size:24px; font-weight:600; }
.section-heading div > p { margin:3px 0 0; color:var(--muted); font-size:12px; }
.report-shell { margin-top:0; }
.markdown-body { border-left:3px solid var(--teal); padding:4px 0 4px 22px; }
.markdown-body h1 { font-size:29px; border-bottom:3px solid var(--teal); padding-bottom:10px; }
.markdown-body h2 { margin:38px 0 14px; border-left:5px solid var(--teal); padding-left:13px; font-size:23px; }
.markdown-body h3 { margin:28px 0 10px; color:var(--brick); font-size:18px; }
.markdown-body blockquote { margin:18px 0; border-left:4px solid var(--brick); background:var(--brick-soft); padding:12px 18px; color:var(--muted); }
.markdown-body code { border-radius:3px; background:var(--surface-alt); padding:2px 4px; font-family:Consolas,"JetBrains Mono",monospace; }
.markdown-body pre,.source-panel pre,.json-source { max-width:100%; overflow:visible; border-radius:4px; background:var(--code); color:var(--code-ink); padding:16px; white-space:pre-wrap; word-break:break-word; font:11px/1.55 Consolas,"JetBrains Mono",monospace; }
.markdown-body pre code { background:transparent; color:inherit; padding:0; }
.table-wrap { width:100%; overflow-x:auto; }
table { width:100%; border-collapse:collapse; font-size:12px; }
th,td { border-bottom:1px solid var(--line); padding:9px 8px; text-align:left; vertical-align:top; }
th { color:var(--muted); font-size:11px; font-weight:700; }
.markdown-body table,#evidence-appendix table { table-layout:fixed; }
.markdown-body table td:first-child { font:9px/1.55 Consolas,"JetBrains Mono",monospace; word-break:break-all; }
.appendix-heading { display:grid; grid-template-columns:48px minmax(0,1fr); gap:14px; border-bottom:1px solid var(--line); padding:19px 24px 14px; }
.appendix-heading > span { border-top:3px solid var(--teal); padding-top:4px; color:var(--teal); font:800 13px Consolas,monospace; }
.appendix-heading h2 { margin:0 0 2px; font-size:22px; }
.appendix-heading p { margin:0; color:var(--muted); font-size:12px; }
.sample-panel,.source-panel { margin:22px; border-top:5px solid var(--green); background:var(--surface-alt); padding:20px 22px; }
.source-panel { border-top-color:var(--gold); }
.sample-panel h3,.source-panel h3 { font-size:18px; }
.sample-panel h4 { margin:22px 0 8px; color:var(--green); }
.sample-grid { display:grid; grid-template-columns:minmax(280px,.8fr) minmax(0,1.2fr); gap:15px; }
.sample-grid > div { min-width:0; border:1px solid var(--line); background:var(--surface); padding:15px 17px; }
.sample-grid p { margin:0; color:var(--muted); white-space:pre-wrap; }
.kv-table th { width:120px; }
.sample-ranking-table { table-layout:fixed; font-size:10px; }
.sample-ranking-table th:nth-child(1),.sample-ranking-table td:nth-child(1) { width:12%; overflow-wrap:anywhere; }
.sample-ranking-table th:nth-child(2),.sample-ranking-table td:nth-child(2) { width:50%; }
.sample-ranking-table th:nth-child(3),.sample-ranking-table td:nth-child(3) { width:14%; overflow-wrap:anywhere; }
.sample-ranking-table th:nth-child(4),.sample-ranking-table td:nth-child(4) { width:16%; overflow-wrap:anywhere; }
.sample-ranking-table th:nth-child(5),.sample-ranking-table td:nth-child(5) { width:8%; }
.ref-line,.source-meta { color:var(--muted); font:11px/1.55 Consolas,monospace; }
.source-meta { display:grid; gap:4px; margin-bottom:12px; }
.ref-cell { width:62%; max-width:440px; font:9px/1.55 Consolas,monospace; word-break:break-all; }
.artifact-projection { margin:18px 0 0; border:1px solid var(--line); border-radius:6px; background:var(--surface); box-shadow:0 5px 16px rgba(36,42,45,.04); }
.artifact-head { padding:22px 25px 18px; border-bottom:1px solid var(--line); }
.artifact-head h3 { margin:0; font-size:24px; font-weight:600; }
.artifact-kind { margin:0 0 5px; color:var(--teal); font-size:10px; font-weight:800; letter-spacing:.12em; }
.artifact-ref { margin:8px 0 0; color:var(--muted); font:10px/1.55 Consolas,monospace; overflow-wrap:anywhere; }
.compact-meta { margin-top:11px; }
.projection-summary,.hypothesis-summary { margin:0; border-top:4px solid var(--teal); background:var(--teal-soft); padding:20px 24px; }
.projection-summary strong { display:block; margin-bottom:6px; color:var(--teal); font-size:12px; }
.projection-summary p,.hypothesis-summary p:last-child { margin:0; color:var(--muted); white-space:pre-wrap; }
.subsection-head { display:flex; align-items:baseline; justify-content:space-between; gap:16px; margin:27px 22px 13px; }
.subsection-head h4 { margin:0; font-size:19px; font-weight:600; }
.subsection-head span { color:var(--faint); font-size:11px; }
.map-shell { margin:18px 22px 0; overflow-x:auto; border:1px solid var(--line); border-radius:6px; background:var(--panel); }
.map-shell svg { display:block; width:max(100%,1180px); height:auto; }
.map-grid-line { stroke:var(--grid); stroke-width:1; }
.map-node { fill:var(--panel); stroke:var(--line); stroke-width:1.3; }
.map-node-soft { fill:var(--panel-soft); }
.map-node-target { fill:var(--soft-3); stroke:var(--accent-3); }
.map-lane-0 { --lane:var(--accent-0); --lane-soft:var(--soft-0); }
.map-lane-1 { --lane:var(--accent-1); --lane-soft:var(--soft-1); }
.map-lane-2 { --lane:var(--accent-2); --lane-soft:var(--soft-2); }
.map-lane-3 { --lane:var(--accent-3); --lane-soft:var(--soft-3); }
.map-lane-4 { --lane:var(--accent-4); --lane-soft:var(--soft-4); }
.map-lane-5 { --lane:var(--accent-5); --lane-soft:var(--soft-5); }
.map-family-node { fill:var(--lane-soft); stroke:var(--lane); }
.map-stage-node { fill:var(--panel); stroke:var(--lane); }
.map-stage-target { fill:var(--lane-soft); stroke:var(--lane); }
.map-risk-node { fill:var(--danger-soft); stroke:var(--danger); }
.map-edge { fill:none; stroke:var(--muted); stroke-width:1.6; marker-end:url(#arrow); }
.map-edge-lane { stroke:var(--lane); stroke-width:2; }
.map-edge-shared { stroke:var(--accent-3); stroke-width:2; }
.map-edge-risk,.map-edge-relation { fill:none; stroke:var(--danger); stroke-width:1.4; stroke-dasharray:5 4; marker-end:url(#arrow-relation); }
.map-relation-label-box { fill:var(--panel); stroke:var(--danger); stroke-width:1; }
.map-relation-label { fill:var(--ink); font-size:9.5px; font-weight:600; }
.map-label { fill:var(--muted); font-size:12px; font-weight:700; }
.map-title { fill:var(--ink); font-size:15px; font-weight:700; }
.map-small { fill:var(--muted); font-size:11px; }
.map-tiny { fill:var(--faint); font-size:10px; }
.map-family-label { fill:var(--lane); font-size:11px; font-weight:800; }
.map-risk-label { fill:var(--danger); font-size:10px; font-weight:800; }
.family-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(min(100%,360px),1fr)); gap:15px; align-items:start; margin:0 22px; }
.family { --accent:var(--accent-0); --soft:var(--soft-0); min-width:0; overflow:hidden; border:1px solid var(--line); border-top:4px solid var(--accent); border-radius:5px; background:var(--panel); }
.family[data-color="1"] { --accent:var(--accent-1); --soft:var(--soft-1); }
.family[data-color="2"] { --accent:var(--accent-2); --soft:var(--soft-2); }
.family[data-color="3"] { --accent:var(--accent-3); --soft:var(--soft-3); }
.family[data-color="4"] { --accent:var(--accent-4); --soft:var(--soft-4); }
.family[data-color="5"] { --accent:var(--accent-5); --soft:var(--soft-5); }
.family-head { min-height:112px; padding:17px 18px 15px; background:var(--soft); }
.family-index { margin:0 0 3px; color:var(--accent); font-size:10px; font-weight:800; letter-spacing:.1em; }
.family h3 { margin:0; font-size:18px; font-weight:600; line-height:1.35; }
.family-id { display:block; margin-top:7px; color:var(--accent); font:11px Consolas,monospace; overflow-wrap:anywhere; }
.mechanism { padding:16px 18px 17px; border-bottom:1px solid var(--line); }
.mechanism-label,.field-label,.panel-label { display:block; margin:0 0 5px; color:var(--accent,var(--teal)); font-size:11px; font-weight:800; }
.mechanism p,.field p { margin:0; color:var(--muted); font-size:13px; white-space:pre-wrap; }
.mechanism-chain { display:grid; grid-template-columns:minmax(0,1fr) 24px minmax(0,1fr) 24px minmax(0,1fr); align-items:stretch; gap:6px; margin-bottom:15px; }
.chain-stage { min-width:0; border:1px solid var(--accent); border-radius:4px; background:var(--soft); padding:9px 10px; }
.chain-stage strong { display:block; margin-bottom:4px; color:var(--accent); font-size:10px; }
.chain-stage ul { margin:0; padding-left:15px; color:var(--muted); font-size:11px; }
.chain-stage li+li { margin-top:3px; }
.chain-arrow { align-self:center; color:var(--accent); text-align:center; font-size:18px; font-weight:700; }
.chain-missing { margin-bottom:15px; border:1px dashed var(--danger); border-radius:4px; background:var(--danger-soft); padding:9px 10px; color:var(--danger); font-size:11px; }
.field { padding:13px 18px; border-bottom:1px solid var(--line); }
.field:last-child { border-bottom:0; }
.tensions { display:flex; flex-wrap:wrap; gap:6px; margin-top:8px; }
.tension { border:1px solid var(--accent); border-radius:999px; padding:2px 7px; color:var(--accent); font:10px Consolas,monospace; }
.relations { display:grid; gap:9px; margin:0 22px; }
.relation { display:grid; grid-template-columns:minmax(130px,.75fr) 50px minmax(130px,.75fr) minmax(260px,2fr); align-items:center; gap:10px; border:1px solid var(--line); border-radius:5px; background:var(--panel-soft); padding:10px 12px; }
.relation-id { color:var(--ink); font:11px Consolas,monospace; overflow-wrap:anywhere; }
.relation-arrow { color:var(--accent-3); text-align:center; font-size:18px; font-weight:700; }
.relation-text { min-width:0; color:var(--muted); font-size:12px; overflow-wrap:anywhere; }
.relation.unparsed { display:block; border-style:dashed; color:var(--muted); font-size:12px; white-space:pre-wrap; }
.gap-list { display:grid; grid-template-columns:repeat(auto-fit,minmax(min(100%,310px),1fr)); gap:10px; margin:0 22px; padding:0; list-style:none; }
.gap-list li { border-left:3px solid var(--danger); background:var(--danger-soft); padding:10px 12px; color:var(--muted); font-size:12px; }
.evidence-boundary { margin:20px 22px 22px; border-left:4px solid var(--accent-5); background:var(--soft-5); padding:13px 15px; }
.evidence-boundary strong { color:var(--accent-5); font-size:11px; }
.evidence-boundary p { margin:5px 0 0; color:var(--muted); white-space:pre-wrap; }
.hypothesis-summary { border-top-color:var(--teal); }
.claim-band { display:grid; grid-template-columns:190px minmax(0,1fr); gap:24px; border-bottom:1px solid var(--line); background:var(--brick-soft); padding:23px 27px 25px; }
.claim-band h4 { margin:0; color:var(--brick); font-size:20px; font-weight:600; }
.claim-band p { margin:0; white-space:pre-wrap; }
.mechanism-panel,.direction-panel,.source-trace { margin:22px; border:1px solid var(--line); border-radius:6px; background:var(--surface); padding:21px 23px; }
.mechanism-panel { border-top:4px solid var(--teal); }
.mechanism-panel p:last-child,.direction-panel p,.source-trace li { color:var(--muted); white-space:pre-wrap; }
.direction-panel { border-top:4px solid var(--violet,#6f6182); background:var(--surface-alt); }
.source-trace { border-top:4px solid var(--gold); }
.source-trace ul { margin:6px 0 0; padding-left:19px; }
.source-trace code { font-size:10px; }
.risk-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(min(100%,280px),1fr)); gap:12px; margin:0 22px; }
.risk-card { border-left:4px solid var(--brick); background:var(--brick-soft); padding:13px 15px; }
.risk-card span { color:var(--brick); font-size:10px; font-weight:800; letter-spacing:.08em; }
.risk-card p { margin:5px 0 0; color:var(--muted); white-space:pre-wrap; }
.verification-list { display:grid; gap:10px; margin:0 22px; padding:0; list-style:none; counter-reset:none; }
.verification-list li { display:grid; grid-template-columns:42px minmax(0,1fr); gap:12px; border:1px solid var(--line); background:var(--green-soft); padding:12px 14px; }
.verification-index { border-top:2px solid var(--green); padding-top:3px; color:var(--green); font:800 11px Consolas,monospace; }
.verification-list p { margin:0; color:var(--muted); white-space:pre-wrap; }
.empty { margin:22px; border:1px dashed var(--line); background:var(--surface-alt); padding:20px; color:var(--muted); }
footer { margin-top:18px; color:var(--muted); font-size:11px; }
@media (max-width:900px) { h1{font-size:26px}.hero{padding:23px 20px}.overview{grid-template-columns:repeat(2,1fr)}.overview article:nth-child(3){border-left:0;border-top:1px solid var(--line)}.overview article:nth-child(4){border-top:1px solid var(--line)}.markdown-body{padding-left:16px}.sample-grid{grid-template-columns:1fr}.sample-panel,.source-panel{margin:14px;padding:16px}.relation{grid-template-columns:1fr 34px 1fr}.relation-text{grid-column:1/-1}.mechanism-chain{grid-template-columns:1fr}.chain-arrow{transform:rotate(90deg)}.claim-band{grid-template-columns:1fr}.map-shell,.family-grid,.relations,.gap-list,.risk-grid,.verification-list,.mechanism-panel,.direction-panel,.source-trace{margin-left:14px;margin-right:14px} }
@media print { @page{size:A4;margin:11mm} html,body{background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}.toolbar{display:none}.page{width:100%;margin:0}.hero,.artifact-projection{box-shadow:none}.toc{break-inside:avoid}.section{padding:18px 0}.section:not(#formal-report){break-before:page}.markdown-body{padding:4px 0 4px 15px}.sample-panel,.source-panel{margin:16px 0;break-inside:auto}.sample-grid{grid-template-columns:1fr 1fr}.table-wrap{overflow:visible}tr{break-inside:avoid}.source-panel pre,.json-source{break-inside:auto;font-size:8px}.map-shell{margin:14px 0;overflow:visible}.map-shell svg{width:100%;min-width:0}.family-grid{grid-template-columns:1fr 1fr;margin:0}.family{break-inside:avoid}.relations,.gap-list,.risk-grid,.verification-list{margin-left:0;margin-right:0}.mechanism-panel,.direction-panel,.source-trace{margin-left:0;margin-right:0}.artifact-projection{border:0}.artifact-head{padding-left:0;padding-right:0}.claim-band,.evidence-boundary,.direction-panel,.source-trace{break-inside:avoid}.evidence-boundary p{font-size:10px;line-height:1.6}.risk-card,.verification-list li{break-inside:avoid}footer{margin-top:12px} }
"""


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Render one formal scientific_report as deterministic HTML/PDF.",
    )
    parser.add_argument("--artifact-root", type=Path, required=True)
    parser.add_argument("--report-ref", required=True)
    parser.add_argument("--html-output", type=Path, required=True)
    parser.add_argument("--pdf-output", type=Path)
    parser.add_argument("--browser-executable", type=Path)
    parser.add_argument(
        "--implementation-projection",
        type=Path,
        help="Private implementation projection sidecar produced by the report skill.",
    )
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    arguments = _arguments()
    implementation_projections = None
    if arguments.implementation_projection is not None:
        implementation_projections = json.loads(
            arguments.implementation_projection.read_text(encoding="utf-8")
        )
    result = write_report_projection(
        artifact_root=arguments.artifact_root,
        report_ref=arguments.report_ref,
        html_output=arguments.html_output,
        pdf_output=arguments.pdf_output,
        browser_executable=arguments.browser_executable,
        implementation_projections=implementation_projections,
        force=arguments.force,
    )
    print("Status: complete")
    print(f"HTML: {result['html_path']}")
    if result["pdf_path"]:
        print(f"PDF: {result['pdf_path']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
