---
name: sample
description: Produces one sample_evolution_result iteration for one exact method sponsor. Requires task_spec plus either one hypothesis, or one final-KPI formula with its complete materialization, public review, and current leaderboard. Formula-mode data comes from that exact execution. Boundary: no sponsor mixing, method changes, dataset rebinding, or held-out KPI values.
estimated_complexity: high
---

# Sample

## Responsibility and boundary

Perform one bounded sample-evolution iteration for the exact scientific method named by the current work unit, then publish `sample_evolution_result`. The sponsor is either a frozen hypothesis or a frozen final-KPI proxy formula. The skill owns task-aware mutation, representation route selection, sponsor-specific scoring, cumulative ranking, and honest progress. Multiple iterations remain under common-agent dynamic control.

It never edits a hypothesis, formula, direction, calibration, or Materializer code; never invents physical inputs or hidden KPI values; and never blends hypothesis and final-KPI proxy scores merely because both methods are visible.

In Formula mode, a sample's score comes from executing the frozen formula on
that sample, with its declared direction used for ranking. The formula's
dataset-level trend agreement instead compares historical proxy values with
measured targets; that formula-quality score is not a new sample's score.
An improved sample rank establishes improvement under the selected method,
not a newly measured improvement of the real final KPI. In Hypothesis mode,
the score expresses fidelity to the hypothesis, not measured KPI improvement.

## Entry conditions and authority

- Resolve one exact stored `task_spec` and one exact method sponsor from `resolved_inputs_for_active_skill`. Stored content, not summaries or global latest-of-kind lookup, is authoritative.
- **Hypothesis mode:** requires one exact `hypothesis`. A matching public method review may be preserved as evidence but does not become the sample score. No formula is required.
- **Final-KPI proxy mode:** requires the current exact `proxy_formula_leaderboard`, one explicitly selected formula already present in that leaderboard, its matching complete `quantitative_proxy_materialization_result`, and all selected auxiliary formula/materialization pairs. The selected leaderboard entry must carry a valid private-evaluation observation ref; that observation remains in its observation store and is preserved as provenance rather than being mounted as a second formal artifact input. The formula need not be rank 1; samples belong to their exact method lineage rather than disappearing when another formula ranks higher.
- If the active node requires a Sample derived from a formula, select Final-KPI proxy mode and pass the formula as the only method sponsor. Do not also pass its ancestor hypothesis as a second sponsor: the formula's exact `depends_on` chain already preserves that hypothesis lineage. Materialization, public formula review, and the matching leaderboard are prerequisites for that mode, not optional context.
- The main agent selects the sponsor by resolving exactly one hypothesis or final-KPI formula before loading this skill. Sample validates and serves that choice; it does not choose among visible research methods.
- A prior `sample_evolution_result` is compatible only when its `depends_on` contains the same exact hypothesis ref or the same exact formula/materialization refs.
- Historical rows remain immutable comparison samples. Generated candidates never become historical facts.

## Trigger examples

### Should select

- Evolve one concrete sample that better instantiates exact hypothesis `artifact:...:h1`, compare it with a bounded stable cohort, and rank by hypothesis fidelity.
- Use one exact evaluated formula/materialization entry plus auxiliary scorers to generate and score one new sample without changing any frozen scorer.

### Should not select

- Revise a hypothesis or formula after poor sample performance; the owning research skill must decide that work.
- Run final-KPI-proxy-sponsored evolution when the selected formula is absent from the supplied leaderboard or lacks its exact complete materialization, review, or private evaluation.

## Prompt and memory projection

- **C0:** task boundary, hidden-KPI rule, sponsor ownership, and the meaning of the current primary metric.
- **C1:** current single-iteration purpose, exact sponsor ref, current parent, bounded comparison cohort, and iteration number.
- **C2:** exact task, sponsor, compatible prior result, applicable leaderboard/formula/materialization artifacts, and the compact formal `sample_evolution_result`. Structured candidate metadata is not duplicated here.
- **C3:** inspected formula-execution observation or bounded hypothesis-fidelity evaluation used for the current iteration.
- **C4:** sanitized historical rows, code, large execution bodies, and the immutable full candidate-record bundle remain in their stores. The formal result links the exact candidate bundle through `trace_refs`; prompts receive bounded method-specific projections and refs.
- **C5:** sponsor selection, mutation draft, representation refinement, one representation repair, and hypothesis batch evaluations. C5 clears on skill exit.
- **C6:** raw prompts, reviewer turns, route diagnostics, execution logs, receipts, and errors remain append-only audit evidence.

Each LLM call receives a purpose-built prompt. The representation route sees one `method_sponsor`, task constraints, current purpose, and bounded population references. It does not receive an instruction to compromise between unrelated methods.

### LLM call contracts

| Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
|---|---|---|---|---|---|---|---|
| selected sample-generation route | candidate draft | Exact C0 task boundary, one exact C2 sponsor including a hypothesis verification plan when present, C1 iteration mission, required source paths, and bounded C4/C5 comparison records retaining their actual structured representation | Create one concrete candidate in the selected representation; never score it or alter its sponsor | Existing route-specific candidate shape: SMILES, described sample, or structured record | Structured schema followed by route-specific identity, parseability, shape, required-path, and duplicate checks | Common same-stage format repair only | Route fidelity call |
| selected sample-generation route | representation fidelity refinement | Same exact sponsor and source grammar plus the C5 draft | Correct representation fidelity and unsupported claims without changing method or adding scores | Complete same route-specific candidate shape | Same deterministic route validation | One later route-local repair only if deterministic validation names a repairable candidate defect | Candidate execution or hypothesis scoring |
| selected sample-generation route | candidate repair | Rejected C5 candidate, exact deterministic error, and unchanged sponsor/source context | Repair only identity, representation, shape, required path, or duplicate defect named by validation | Complete same route-specific candidate shape | Same deterministic route validation; no scientific method judgment | At most one route-local repair | Candidate execution or hypothesis scoring |
| `sample` hypothesis mode | `review-hypothesis-sample-batch` | Exact C2 task and frozen hypothesis, C1 iteration mission, and one bounded comparison batch | Score fidelity to that hypothesis only; do not claim final-KPI improvement | Existing complete per-sample `{sample_id, score, reason}` evaluations | Exact sample-id coverage, uniqueness, 0-100 range, and non-empty reasons | Common same-stage format repair only | Global population ranking for the same hypothesis lineage |

Final-KPI proxy mode adds no model-scored value: it executes the frozen stored scorers and parses their exact observations. Ranking, Pareto tiers, lineage checks, and publication are deterministic consumers of those stored results.

## Skill-local workflow

1. Resolve the exact task, compatible prior result, and available method sponsors.
2. Validate the one exact sponsor selected by the main agent at the invocation boundary. A compatible prior result is continuity evidence only after that same sponsor is selected; it never overrides the selected method. Missing or multiple sponsors return a bounded gap rather than a guessed blend.
3. Build a bounded population view and select an installed representation route. A route may represent one molecule with SMILES, one hypothesis-facing described sample, or one formula-facing complete source-shaped record. The SMILES route is one route, not the definition of Sample.
4. Draft and refine one concrete candidate. Formula-facing structured candidates retain `id`, `input_description`, and `metadata`. The selected materializations' explicit `execution_input_paths` select the complete required inputs, not every column in a historical row. Formula `source_binding` remains research provenance, not the current executable layout. The shared Sample input adapter projects reference inputs, validates the candidate, and restores native record paths for execution. Historical rows remain unchanged for replay. One candidate-only failure may receive one route-local repair.
   Generation, fidelity and repair share the candidate-evidence instruction in `sample_generation_routes.py`. At this pre-execution stage, `input_description` contains the proposed design and rationale, not a result receipt. Fidelity checks prose as well as representation; the later execution owns computed values. This uses the existing two model stages, not an additional review.
5. **Hypothesis mode:** score one bounded comparison batch for fidelity to the frozen hypothesis. First iteration includes historical samples; later iterations use the new candidate plus stable top/bottom anchors while retaining prior stored scores.
6. **Final-KPI proxy mode:** execute exact frozen primary and auxiliary scorers, replay accepted historical values, inspect the exact observation, and reject scorer-lineage drift.
7. Rank the complete population with existing `index_values`, `index_ranks`, and `pareto_tier`; preserve regressions and no-progress results.
8. Store the complete generated candidate cohort once as an immutable C4 bundle. Accumulate `rank_history`, increment `iteration_count`, publish one immutable result as a compact projection whose `trace_refs` names that bundle, and immediately read it back.
9. On a later iteration, read the exact prior C4 bundle named by the compatible prior result. Rejoin those full candidate records with public ranking rows by sample id; never reconstruct scorer inputs from prose or choose a global latest bundle.

In final-KPI proxy mode, the selected materialization's exact `execution_observation_refs` own the historical comparison table through execution metadata `prepared_source_ref`; the formula's research dependencies do not select execution data. When `evaluation_binding` exists, `record_output_name` selects the scorer's input records. Its paired target body does not become scorer input or a measured value for a new candidate; access follows explicit task/source restrictions, not the scoring role alone. Candidate generation, scorer replay, and population-size validation use that same execution table. Primary and auxiliary materializations must name the same exact prepared source (or both use SourceSpec-only legacy data) and have matching historical records before their values can share one population; exact ID/value replay remains required. Configured historical data applies only to SourceSpec-only legacy executions. Old prepared observations without an explicit execution binding require a new execution of the same formula, not retrospective rebinding. Invalid explicit data must not trigger a different dataset fallback.

The candidate's `metadata` is a transport container. If all declared data paths
are below `record.metadata`, preserve that nested representation. For top-level
or mixed paths, it contains the projected record fields, retaining a nested
`metadata` object when explicitly required. Identity and description stay in
their existing envelope fields. Generation, fidelity and repair receive the
same input contract and projected examples. No historical measurement is copied
into a new sample merely to satisfy table shape; no field-name heuristic selects
inputs. Exact candidate bundles keep this same envelope across iterations;
native execution rows are transient projections, not a second stored authority.

## Formal output and handoff

If a selected materialization lacks `execution_input_paths`, report its exact
ref and implementation ref for a new Materializer execution; do not infer paths
from the Formula or bind an old result retrospectively. A declared path missing
from its execution data is an input-contract mismatch, not a missing generation
capability. Generation, validation, replay and later iterations use the same
declaration. Replayed code must return the same declared paths.

The existing payload remains `artifact_kind`, `best_sample`, `ranked_samples`, `rank_history`, `iteration_count`, and `residual_issues`. Existing `proxy_value` means the current sponsor's primary evolution metric:

- Final-KPI proxy mode: the frozen final-KPI proxy value.
- Hypothesis mode: hypothesis-fidelity score only, with no claim of KPI improvement.

Every ranked row retains `index_values`, `index_ranks`, and `pareto_tier`. `depends_on` records the exact task, exact sponsor, compatible prior result, and applicable formula/materialization/review/evaluation evidence. Hypothesis and formula sample lineages remain separate; a new formula does not erase or silently migrate samples from an older method.

For structured formula-facing samples, public ranked rows keep only the existing identity, description, scores, ranks, and status fields. Full `metadata` remains authoritative in the C4 candidate bundle. This is one logical result with two storage projections, not two competing copies.

## Failure and repair

Malformed model output is repaired inside its current bounded stage. Invalid or duplicate representation receives at most one route-local repair. Missing exact sponsor, ambiguous method purpose, incompatible prior lineage, missing formula materialization, scorer replay drift, or unavailable representation route returns a precise gap. A hypothesis-fidelity concern is not a formula failure, and a poor formula score is not evidence against an unrelated hypothesis.

Representation routes mechanically validate identity, nonempty representation, parseability where a parser exists, and exact-duplicate avoidance. They do not judge whether a described formulation scientifically realizes the hypothesis; the hypothesis reviewer owns that judgment.

## Validation evidence

Focused tests must prove hypothesis-only operation without a formula, unchanged final-KPI-proxy-mode scoring, exact sponsor selection when both methods are visible, prior-lineage continuity, candidate-only repair, immutable scorer replay, and the approved `proxy_value` semantics. Boundary replay must show that neither mode consumes stale or unreviewed refs. A real-model segment proves only the exercised method lineage, not the entire scientific workflow.
