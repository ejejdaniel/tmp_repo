from __future__ import annotations

import copy
import json
import math
from typing import Any, Mapping, Sequence

from ai_coscientist.domain.multi_index import rank_multi_index_rows
from ai_coscientist.domain.materialization_inputs import materialization_input_paths
from ai_coscientist.domain.prepared_evaluation import resolve_materialization_records
from ai_coscientist.domain.sample_generation_routes import (
    select_generation_route,
)
from ai_coscientist.domain.sample_records import candidate_from_source, candidate_to_source
from ai_coscientist.domain.scientific_review import (
    review_hypothesis_sample_batch,
    validate_scientific_method_review,
)


def run(payload: dict[str, Any], runtime: Any) -> dict[str, Any]:
    resolved = list(payload.get("resolved_inputs") or [])
    sponsor = _resolved_method_sponsor(resolved)
    if sponsor["selection_status"] != "selected":
        return {
            "status": "bounded_gap",
            "reason": (
                "sample_method_sponsor_ambiguous:" + str(sponsor["reason"])
            ),
        }
    explicit = _explicit_sample_inputs(runtime, resolved)
    if sponsor["method_kind"] == "hypothesis":
        return _run_hypothesis_mode(
            payload,
            runtime,
            explicit=explicit,
            hypothesis_ref=str(sponsor["method_artifact_ref"]),
        )
    return _run_formula_mode(
        payload,
        runtime,
        explicit=explicit,
        formula_ref=str(sponsor["method_artifact_ref"]),
    )


def _run_formula_mode(
    payload: dict[str, Any],
    runtime: Any,
    *,
    explicit: Sequence[Mapping[str, Any]],
    formula_ref: str,
) -> dict[str, Any]:
    task = _single(explicit, "task_spec")
    leaderboard = _leaderboard_for_formula(explicit, formula_ref)
    leaderboard_entry = _leaderboard_entry_for_formula(
        leaderboard,
        formula_ref,
    )
    formula = _exact_visible_artifact(
        explicit,
        formula_ref,
        "proxy_formula_candidate",
    )
    materialization = _exact_visible_artifact(
        explicit,
        str(leaderboard_entry["materialization_artifact_ref"]),
        "quantitative_proxy_materialization_result",
    )
    materialization_ref = str(materialization["artifact_ref"])
    review = _exact_visible_artifact(
        explicit,
        str(leaderboard_entry["review_artifact_ref"]),
        "scientific_method_review",
    )
    validate_scientific_method_review(
        review,
        expected_method_ref=formula_ref,
    )
    _validate_selected_proxy_pair(formula, materialization, leaderboard_entry)
    auxiliary_pairs = _resolved_auxiliary_pairs(
        explicit,
        primary_formula_ref=formula_ref,
    )
    expected_target_ids = {
        str(formula["machine_payload"]["target_id"]),
        *[
            str(pair["formula"]["machine_payload"]["target_id"])
            for pair in auxiliary_pairs
        ],
    }
    previous = _optional_lineage_tip(
        [
            item
            for item in explicit
            if item.get("artifact_kind") == "sample_evolution_result"
            and {formula_ref, materialization_ref}.issubset(
                {str(ref) for ref in item.get("depends_on", [])}
            )
        ],
        "sample_evolution_result",
    )
    if previous is not None:
        _validate_previous_population(
            previous,
            formula_ref=formula_ref,
            materialization_ref=materialization_ref,
        )

    prepared_records = resolve_materialization_records(
        runtime, formula, materialization, consumer="sample"
    )
    if prepared_records is not None:
        _prepared, records = prepared_records
        historical = {"records": list(records)}
    else:
        historical = runtime.call_route("scientific_source_visible_historical", {})
    historical_records = historical.get("records")
    if not isinstance(historical_records, list) or not historical_records:
        raise ValueError("sample_historical_references_required")
    required_source_paths = sorted({
        path
        for item in [materialization, *[pair["materialization"] for pair in auxiliary_pairs]]
        for path in materialization_input_paths(item, records=historical_records)
    })
    generation_route = select_generation_route(
        source_records=historical_records, required_source_paths=required_source_paths,
    )
    structured = generation_route.route_id == "structured-record"
    prior_generated = _generated_candidates(runtime, previous, structured=structured)
    context = {
        "current_iteration_mission": _iteration_mission(payload),
        "task": _task_generation_context(task),
        "method_sponsor": {
            "method_kind": "outer",
            "method_artifact_ref": formula_ref,
            "frozen_proxy": _proxy_generation_context(formula),
        },
        "current_population": _population_reference_bundle(
            historical,
            formula=formula,
            materialization=materialization,
            auxiliary_pairs=auxiliary_pairs,
            previous=previous,
            generated_records=prior_generated,
        ),
        "required_source_paths": required_source_paths,
    }
    if auxiliary_pairs:
        context["auxiliary_proxies"] = [
            _proxy_generation_context(pair["formula"])
            for pair in auxiliary_pairs
        ]

    candidate = generation_route.generate(runtime, context)

    reference_samples = [
        *historical_records,
        *[
            candidate_to_source(record, required_source_paths) if structured else record
            for record in prior_generated
        ],
    ]
    try:
        candidate = generation_route.validate_candidate(
            candidate,
            reference_samples=reference_samples,
            required_source_paths=required_source_paths,
        )
        execution = _execute(
            runtime,
            formula_ref,
            materialization_ref,
            auxiliary_pairs,
            [*prior_generated, candidate],
        )
    except (RuntimeError, ValueError) as exc:
        if not generation_route.can_repair(str(exc)):
            raise
        candidate = generation_route.repair(
            runtime,
            context,
            rejected_candidate=candidate,
            execution_error=str(exc),
        )
        candidate = generation_route.validate_candidate(
            candidate,
            reference_samples=reference_samples,
            required_source_paths=required_source_paths,
        )
        execution = _execute(
            runtime,
            formula_ref,
            materialization_ref,
            auxiliary_pairs,
            [*prior_generated, candidate],
        )

    observation_ref = str(execution.get("observation_ref") or "")
    if not observation_ref:
        raise ValueError("sample_execution_observation_ref_required")
    candidate_bundle_ref = str(
        execution.get("candidate_bundle_ref") or ""
    ).strip()
    if not candidate_bundle_ref.startswith(
        "workspace:sample-candidate-bundles/"
    ):
        raise ValueError("sample_candidate_bundle_ref_required")
    inspected = runtime.call_route(
        "scientific_observation_inspect",
        {"observation_ref": observation_ref},
    )
    result = _accumulate_result(_sample_result(inspected), previous)
    previous_iteration = (
        int(previous["machine_payload"]["iteration_count"])
        if previous is not None
        else 0
    )
    expected_iteration = previous_iteration + 1
    expected_count = len(historical_records) + len(prior_generated) + 1
    _validate_result(
        result,
        str(candidate["id"]),
        expected_count,
        expected_iteration,
        expected_target_ids,
    )

    best = result["best_sample"]
    implementation_refs = [
        str(materialization["machine_payload"].get("implementation_ref") or "")
    ]
    dependencies = [
        str(task["artifact_ref"]),
        str(leaderboard["artifact_ref"]),
        formula_ref,
        materialization_ref,
        str(leaderboard_entry["evaluation_observation_ref"]),
        str(review["artifact_ref"]),
    ]
    for pair in auxiliary_pairs:
        dependencies.extend(
            [
                str(pair["formula"]["artifact_ref"]),
                str(pair["materialization"]["artifact_ref"]),
            ]
        )
        implementation_refs.append(
            str(
                pair["materialization"]["machine_payload"].get(
                    "implementation_ref"
                )
                or ""
            )
        )
    if previous is not None:
        dependencies.append(str(previous["artifact_ref"]))
    dependencies.append(observation_ref)
    dependencies = list(dict.fromkeys(dependencies))
    implementation_refs = list(
        dict.fromkeys(ref for ref in implementation_refs if ref)
    )
    receipt = runtime.publish_artifact(
        artifact_kind="sample_evolution_result",
        title=(f"Sample Evolution Result {expected_iteration}: {best['sample_id']}"),
        summary=(
            "One sample-evolution iteration completed with the frozen proxy "
            "and a unified historical-plus-generated population ranking."
        ),
        markdown=(
            "# Sample Evolution Result\n\n"
            f"Current best generated sample: `{best['sample_id']}`. "
            f"Proxy value: `{best['proxy_value']}`. "
            f"Ranked population size: `{len(result['ranked_samples'])}`. "
            f"Cumulative iteration: `{expected_iteration}`."
        ),
        machine_payload=result,
        depends_on=dependencies,
        trace_refs=[
            *implementation_refs,
            str(leaderboard_entry["evaluation_observation_ref"]),
            observation_ref,
            candidate_bundle_ref,
        ],
    )
    artifact_ref = str(receipt["artifact_ref"])
    stored = runtime.read_artifact(artifact_ref)
    if stored.get("artifact_kind") != "sample_evolution_result":
        raise ValueError("sample_readback_kind_mismatch")
    return {
        "status": "completed",
        "artifact_ref": artifact_ref,
        "observation_ref": observation_ref,
        "summary": (
            "Generated one candidate, scored the complete current generated "
            "population, updated the cumulative ranking, published, and read "
            "back one sample evolution result."
        ),
    }





def _explicit_sample_inputs(
    runtime: Any,
    resolved: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    relevant_kinds = {
        "task_spec",
        "hypothesis",
        "scientific_method_review",
        "proxy_formula_candidate",
        "quantitative_proxy_materialization_result",
        "proxy_formula_leaderboard",
        "sample_evolution_result",
    }
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in resolved:
        if not isinstance(raw, Mapping):
            continue
        kind = str(raw.get("artifact_kind") or "")
        if kind not in relevant_kinds:
            continue
        artifact_ref = str(raw.get("artifact_ref") or "")
        if not artifact_ref.startswith("artifact:"):
            raise ValueError("sample_explicit_artifact_ref_invalid")
        if artifact_ref in seen:
            continue
        artifact = dict(raw)
        if not isinstance(artifact.get("machine_payload"), Mapping):
            artifact = dict(runtime.read_artifact(artifact_ref))
        if artifact.get("artifact_kind") != kind:
            raise ValueError("sample_explicit_artifact_kind_mismatch")
        if not isinstance(artifact.get("machine_payload"), Mapping):
            raise ValueError("sample_explicit_artifact_payload_required")
        result.append(artifact)
        seen.add(artifact_ref)
    return result


def _resolved_method_sponsor(
    resolved: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    methods: list[dict[str, str]] = []
    for raw in resolved:
        if not isinstance(raw, Mapping):
            continue
        artifact_ref = str(raw.get("artifact_ref") or "").strip()
        artifact_kind = str(raw.get("artifact_kind") or "").strip()
        if not artifact_ref.startswith("artifact:"):
            continue
        if artifact_kind == "hypothesis":
            methods.append(
                {
                    "method_kind": "hypothesis",
                    "method_artifact_ref": artifact_ref,
                }
            )
            continue
        if artifact_kind != "proxy_formula_candidate":
            continue
        machine_payload = raw.get("machine_payload")
        if (
            isinstance(machine_payload, Mapping)
            and machine_payload.get("target_kind") == "final_kpi"
        ):
            methods.append(
                {
                    "method_kind": "outer",
                    "method_artifact_ref": artifact_ref,
                }
            )

    unique = {
        (item["method_kind"], item["method_artifact_ref"]): item
        for item in methods
    }
    selected = list(unique.values())
    if len(selected) == 1:
        method = selected[0]
        return {
            "selection_status": "selected",
            "method_kind": method["method_kind"],
            "method_artifact_ref": method["method_artifact_ref"],
            "reason": (
                "The main agent resolved exactly one method sponsor before "
                "loading Sample."
            ),
        }
    if not selected:
        reason = (
            "No exact hypothesis or final-KPI formula sponsor was resolved "
            "before Sample was loaded."
        )
    else:
        reason = (
            "Multiple method sponsors were resolved before Sample was loaded: "
            + ", ".join(item["method_artifact_ref"] for item in selected)
        )
    return {
        "selection_status": "ambiguous",
        "method_kind": "hypothesis",
        "method_artifact_ref": "",
        "reason": reason,
    }

def _run_hypothesis_mode(
    payload: Mapping[str, Any],
    runtime: Any,
    *,
    explicit: Sequence[Mapping[str, Any]],
    hypothesis_ref: str,
) -> dict[str, Any]:
    task = _single(explicit, "task_spec")
    hypothesis = _exact_visible_artifact(explicit, hypothesis_ref, "hypothesis")
    target_id = _hypothesis_target_id(hypothesis)
    previous = _optional_lineage_tip(
        [
            item
            for item in explicit
            if item.get("artifact_kind") == "sample_evolution_result"
            and hypothesis_ref in {
                str(ref) for ref in item.get("depends_on", [])
            }
        ],
        "sample_evolution_result",
    )
    if previous is not None:
        _validate_previous_hypothesis_population(
            previous,
            hypothesis_ref=hypothesis_ref,
            target_id=target_id,
        )

    manifest = runtime.call_route("scientific_source_manifest", {})
    historical = runtime.call_route("scientific_source_visible_historical", {})
    records = historical.get("records")
    if not isinstance(records, list) or not records:
        raise ValueError("sample_hypothesis_historical_records_required")
    context = {
        "current_iteration_mission": _iteration_mission(payload),
        "task": _task_generation_context(task),
        "method_sponsor": {
            "method_kind": "hypothesis",
            "method_artifact_ref": hypothesis_ref,
            "frozen_hypothesis": _hypothesis_generation_context(hypothesis),
        },
        "current_population": _hypothesis_population_reference_bundle(
            records,
            previous=previous,
        ),
    }
    generation_route = select_generation_route(source_records=records)
    candidate = generation_route.generate(runtime, context)
    reference_samples = _hypothesis_reference_samples(records, previous)
    try:
        candidate = generation_route.validate_candidate(
            candidate,
            reference_samples=reference_samples,
        )
    except ValueError as exc:
        if not generation_route.can_repair(str(exc)):
            raise
        candidate = generation_route.repair(
            runtime,
            context,
            rejected_candidate=candidate,
            execution_error=str(exc),
        )
        candidate = generation_route.validate_candidate(
            candidate,
            reference_samples=reference_samples,
        )

    comparison_batch = _hypothesis_comparison_batch(
        records,
        previous=previous,
        candidate=candidate,
    )
    evaluations = review_hypothesis_sample_batch(
        runtime,
        hypothesis=hypothesis,
        task=task,
        current_iteration_mission=_iteration_mission(payload),
        samples=comparison_batch,
    )
    current = _hypothesis_iteration_result(
        historical_records=records,
        previous=previous,
        candidate=candidate,
        evaluations=evaluations,
        target_id=target_id,
    )
    result = _accumulate_result(current, previous)
    previous_iteration = (
        int(previous["machine_payload"]["iteration_count"])
        if previous is not None
        else 0
    )
    expected_iteration = previous_iteration + 1
    historical_count = int(manifest["historical_data"]["record_count"])
    prior_generated_count = (
        sum(
            1
            for row in previous["machine_payload"]["ranked_samples"]
            if row.get("is_novel") is True
        )
        if previous is not None
        else 0
    )
    expected_count = historical_count + prior_generated_count + 1
    _validate_result(
        result,
        str(candidate["id"]),
        expected_count,
        expected_iteration,
        {target_id},
    )

    best = result["best_sample"]
    dependencies = [str(task["artifact_ref"]), hypothesis_ref]
    dependencies.extend(
        str(item["artifact_ref"])
        for item in explicit
        if item.get("artifact_kind") == "scientific_method_review"
        and item.get("machine_payload", {}).get("method_artifact_ref")
        == hypothesis_ref
    )
    if previous is not None:
        dependencies.append(str(previous["artifact_ref"]))
    dependencies = list(dict.fromkeys(dependencies))
    receipt = runtime.publish_artifact(
        artifact_kind="sample_evolution_result",
        title=f"Sample Evolution Result {expected_iteration}: {best['sample_id']}",
        summary=(
            "One hypothesis-sponsored sample iteration completed. Scores "
            "represent hypothesis fidelity, not final-KPI improvement."
        ),
        markdown=(
            "# Sample Evolution Result\n\n"
            f"Method sponsor: hypothesis `{hypothesis_ref}`. "
            f"Current best generated sample: `{best['sample_id']}`. "
            f"Hypothesis-fidelity score: `{best['proxy_value']}`. "
            f"Ranked population size: `{len(result['ranked_samples'])}`. "
            f"Cumulative iteration: `{expected_iteration}`.\n\n"
            "These scores compare fidelity to the frozen hypothesis and do "
            "not establish final-KPI improvement.\n"
        ),
        machine_payload=result,
        depends_on=dependencies,
        trace_refs=[],
    )
    artifact_ref = str(receipt["artifact_ref"])
    stored = runtime.read_artifact(artifact_ref)
    if stored.get("machine_payload") != result:
        raise ValueError("sample_hypothesis_readback_mismatch")
    return {
        "status": "completed",
        "artifact_ref": artifact_ref,
        "summary": (
            "Generated one candidate for the exact hypothesis, reviewed one "
            "bounded comparison batch, updated the cumulative ranking, and "
            "published a hypothesis-fidelity result."
        ),
    }


def _hypothesis_target_id(hypothesis: Mapping[str, Any]) -> str:
    payload = hypothesis.get("machine_payload")
    hypothesis_id = (
        str(payload.get("id") or "").strip()
        if isinstance(payload, Mapping)
        else ""
    )
    return f"hypothesis:{hypothesis_id or hypothesis['artifact_ref']}"


def _sample_representation_fields(
    sample: Mapping[str, Any],
) -> dict[str, Any]:
    metadata = sample.get("metadata")
    nested_smiles = (
        metadata.get("smiles")
        if isinstance(metadata, Mapping)
        else None
    )
    smiles = str(sample.get("smiles") or nested_smiles or "").strip()
    description = str(sample.get("input_description") or "").strip()
    result: dict[str, Any] = {}
    if smiles:
        result["smiles"] = smiles
    if description:
        result["input_description"] = description
    if isinstance(metadata, Mapping) and metadata:
        result["metadata"] = copy.deepcopy(dict(metadata))
    return result


def _represented_sample(
    sample: Mapping[str, Any],
    *,
    sample_id: str,
) -> dict[str, Any]:
    return {
        "id": str(sample_id),
        **_sample_representation_fields(sample),
    }


def _hypothesis_review_row(
    sample: Mapping[str, Any],
    *,
    sample_id: str,
    is_novel: bool,
) -> dict[str, Any]:
    return {
        "sample_id": str(sample_id),
        **_sample_representation_fields(sample),
        "is_novel": bool(is_novel),
    }


def _hypothesis_population_reference_bundle(
    historical_records: Sequence[Mapping[str, Any]],
    *,
    previous: Mapping[str, Any] | None,
) -> dict[str, Any]:
    if previous is None:
        references = [
            {
                "sample_id": str(record.get("id") or ""),
                "rank_role": "unscored_reference",
                "origin": "historical",
                "sample": _represented_sample(
                    record,
                    sample_id=str(record.get("id") or ""),
                ),
            }
            for record in historical_records
        ]
        return {
            "iteration_count": 0,
            "population_size": len(references),
            "current_generated_parent": None,
            "reference_samples": references,
            "existing_generated_ids": [],
        }
    ranked = previous["machine_payload"]["ranked_samples"]
    selected = list(dict.fromkeys(
        [
            *[str(row["sample_id"]) for row in ranked[:2]],
            *[str(row["sample_id"]) for row in ranked[-2:]],
        ]
    ))
    by_id = {str(row["sample_id"]): row for row in ranked}
    references = [
        {
            "sample_id": sample_id,
            "proxy_value": by_id[sample_id]["proxy_value"],
            "rank_role": (
                "high_reference"
                if sample_id in {str(row["sample_id"]) for row in ranked[:2]}
                else "low_reference"
            ),
            "origin": (
                "generated" if by_id[sample_id].get("is_novel") else "historical"
            ),
            "sample": _represented_sample(
                by_id[sample_id],
                sample_id=sample_id,
            ),
        }
        for sample_id in selected
    ]
    return {
        "iteration_count": int(previous["machine_payload"]["iteration_count"]),
        "population_size": len(ranked),
        "current_generated_parent": dict(previous["machine_payload"]["best_sample"]),
        "reference_samples": references,
        "existing_generated_ids": [
            str(row["sample_id"])
            for row in ranked
            if row.get("is_novel") is True
        ],
    }


def _hypothesis_reference_samples(
    historical_records: Sequence[Mapping[str, Any]],
    previous: Mapping[str, Any] | None,
) -> list[dict[str, Any]]:
    if previous is not None:
        return [
            _represented_sample(
                row,
                sample_id=str(row.get("sample_id") or ""),
            )
            for row in previous["machine_payload"]["ranked_samples"]
        ]
    return [
        _represented_sample(
            record,
            sample_id=str(record.get("id") or ""),
        )
        for record in historical_records
    ]


def _hypothesis_comparison_batch(
    historical_records: Sequence[Mapping[str, Any]],
    *,
    previous: Mapping[str, Any] | None,
    candidate: Mapping[str, Any],
) -> list[dict[str, Any]]:
    if previous is None:
        batch = [
            _hypothesis_review_row(
                record,
                sample_id=str(record.get("id") or ""),
                is_novel=False,
            )
            for record in historical_records
        ]
    else:
        ranked = previous["machine_payload"]["ranked_samples"]
        selected_ids = list(dict.fromkeys(
            [
                *[str(row["sample_id"]) for row in ranked[:2]],
                *[str(row["sample_id"]) for row in ranked[-2:]],
            ]
        ))
        by_id = {str(row["sample_id"]): row for row in ranked}
        batch = [
            {
                **_hypothesis_review_row(
                    by_id[sample_id],
                    sample_id=sample_id,
                    is_novel=bool(by_id[sample_id].get("is_novel")),
                ),
                "proxy_value": by_id[sample_id].get("proxy_value"),
            }
            for sample_id in selected_ids
        ]
    batch.append(
        _hypothesis_review_row(
            candidate,
            sample_id=str(candidate["id"]),
            is_novel=True,
        )
    )
    return batch


def _hypothesis_iteration_result(
    *,
    historical_records: Sequence[Mapping[str, Any]],
    previous: Mapping[str, Any] | None,
    candidate: Mapping[str, Any],
    evaluations: Sequence[Mapping[str, Any]],
    target_id: str,
) -> dict[str, Any]:
    scores = {
        str(item.get("sample_id") or ""): float(item["score"])
        for item in evaluations
    }
    candidate_id = str(candidate["id"])
    if candidate_id not in scores:
        raise ValueError("sample_hypothesis_candidate_score_missing")
    if previous is None:
        rows = [
            {
                **_hypothesis_review_row(
                    record,
                    sample_id=str(record.get("id") or ""),
                    is_novel=False,
                ),
                "proxy_value": scores[str(record.get("id") or "")],
                "index_values": {
                    target_id: scores[str(record.get("id") or "")]
                },
            }
            for record in historical_records
        ]
    else:
        rows = [
            dict(row)
            for row in previous["machine_payload"]["ranked_samples"]
        ]
    candidate_row = {
        **_hypothesis_review_row(
            candidate,
            sample_id=candidate_id,
            is_novel=True,
        ),
        "proxy_value": scores[candidate_id],
        "index_values": {target_id: scores[candidate_id]},
    }
    ranked = rank_multi_index_rows(
        [*rows, candidate_row],
        index_relations={target_id: "higher_proxy_higher_kpi"},
        primary_target_id=target_id,
    )
    best_generated = next(
        row for row in ranked if row.get("is_novel") is True
    )
    return {
        "artifact_kind": "sample_evolution_result",
        "best_sample": dict(best_generated),
        "ranked_samples": ranked,
        "rank_history": [
            {
                "iteration": 1,
                "ranked_sample_ids": [row["sample_id"] for row in ranked],
            }
        ],
        "iteration_count": 1,
        "residual_issues": [],
    }


def _validate_previous_hypothesis_population(
    previous: Mapping[str, Any],
    *,
    hypothesis_ref: str,
    target_id: str,
) -> None:
    if hypothesis_ref not in {
        str(ref) for ref in previous.get("depends_on", [])
    }:
        raise ValueError("sample_previous_hypothesis_lineage_mismatch")
    payload = previous.get("machine_payload")
    if not isinstance(payload, Mapping):
        raise ValueError("sample_previous_population_payload_required")
    if payload.get("artifact_kind") != "sample_evolution_result":
        raise ValueError("sample_previous_population_kind_mismatch")
    iteration_count = payload.get("iteration_count")
    rank_history = payload.get("rank_history")
    ranked = payload.get("ranked_samples")
    best = payload.get("best_sample")
    if (
        isinstance(iteration_count, bool)
        or not isinstance(iteration_count, int)
        or iteration_count < 1
        or not isinstance(rank_history, list)
        or len(rank_history) != iteration_count
        or not isinstance(ranked, list)
        or not ranked
        or not isinstance(best, Mapping)
        or best.get("is_novel") is not True
    ):
        raise ValueError("sample_previous_population_state_invalid")
    for row in ranked:
        if set(map(str, row.get("index_values", {}))) != {target_id}:
            raise ValueError("sample_previous_hypothesis_index_mismatch")
def _execute(
    runtime: Any,
    formula_ref: str,
    materialization_ref: str,
    auxiliary_pairs: Sequence[Mapping[str, Any]],
    candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    return runtime.call_route(
        "scientific_sample_execute",
        {
            "formula_artifact_ref": formula_ref,
            "materialization_artifact_ref": materialization_ref,
            "auxiliary_scorer_pairs": [
                {
                    "formula_artifact_ref": str(
                        pair["formula"]["artifact_ref"]
                    ),
                    "materialization_artifact_ref": str(
                        pair["materialization"]["artifact_ref"]
                    ),
                }
                for pair in auxiliary_pairs
            ],
            "candidates": [dict(candidate) for candidate in candidates],
        },
    )


def _leaderboard_for_formula(
    artifacts: Sequence[Mapping[str, Any]],
    formula_ref: str,
) -> dict[str, Any]:
    matches: list[dict[str, Any]] = []
    for item in artifacts:
        if item.get("artifact_kind") != "proxy_formula_leaderboard":
            continue
        board = dict(item)
        entries = _leaderboard_entries(board)
        if any(
            str(entry["formula_artifact_ref"]) == formula_ref
            for entry in entries
        ):
            matches.append(board)
    selected = _optional_lineage_tip(matches, "proxy_formula_leaderboard")
    if selected is None:
        raise ValueError(
            "sample_explicit_leaderboard_for_formula_required:"
            f"formula_ref={formula_ref}"
        )
    return selected


def _leaderboard_entries(
    leaderboard: Mapping[str, Any],
) -> list[dict[str, Any]]:
    payload = leaderboard.get("machine_payload")
    if not isinstance(payload, Mapping):
        raise ValueError("sample_proxy_formula_leaderboard_payload_required")
    if set(payload) != {"artifact_kind", "version", "ranked_entries"}:
        raise ValueError("sample_proxy_formula_leaderboard_shape_invalid")
    if payload.get("artifact_kind") != "proxy_formula_leaderboard":
        raise ValueError("sample_proxy_formula_leaderboard_kind_invalid")
    version = payload.get("version")
    if (
        not isinstance(version, int)
        or isinstance(version, bool)
        or version < 1
    ):
        raise ValueError("sample_proxy_formula_leaderboard_version_invalid")
    entries = payload.get("ranked_entries")
    if not isinstance(entries, list) or not entries:
        raise ValueError("sample_proxy_formula_leaderboard_entries_required")
    expected_keys = {
        "rank",
        "formula_artifact_ref",
        "materialization_artifact_ref",
        "evaluation_observation_ref",
        "trend_alignment_score",
        "review_artifact_ref",
        "review_score",
        "pareto_tier",
    }
    seen_formulas: set[str] = set()
    for expected_rank, raw in enumerate(entries, start=1):
        if not isinstance(raw, Mapping) or set(raw) != expected_keys:
            raise ValueError("sample_proxy_formula_leaderboard_entry_shape_invalid")
        if raw.get("rank") != expected_rank:
            raise ValueError("sample_proxy_formula_leaderboard_rank_invalid")
        formula_ref = str(raw.get("formula_artifact_ref") or "")
        materialization_ref = str(
            raw.get("materialization_artifact_ref") or ""
        )
        evaluation_ref = str(raw.get("evaluation_observation_ref") or "")
        review_ref = str(raw.get("review_artifact_ref") or "")
        if not formula_ref.startswith("artifact:"):
            raise ValueError("sample_proxy_formula_leaderboard_formula_ref_invalid")
        if not materialization_ref.startswith("artifact:"):
            raise ValueError(
                "sample_proxy_formula_leaderboard_materialization_ref_invalid"
            )
        if not evaluation_ref.startswith(
            "execution_observation:private-evaluator:"
        ):
            raise ValueError(
                "sample_proxy_formula_leaderboard_evaluation_ref_invalid"
            )
        if not review_ref.startswith("artifact:"):
            raise ValueError("sample_proxy_formula_leaderboard_review_ref_invalid")
        if formula_ref in seen_formulas:
            raise ValueError(
                "sample_proxy_formula_leaderboard_formula_ref_duplicate"
            )
        seen_formulas.add(formula_ref)
        for score_name in ("trend_alignment_score", "review_score"):
            score = raw.get(score_name)
            if (
                not isinstance(score, (int, float))
                or isinstance(score, bool)
                or not math.isfinite(float(score))
                or not 0.0 <= float(score) <= 100.0
            ):
                raise ValueError(
                    f"sample_proxy_formula_leaderboard_score_invalid:{score_name}"
                )
        tier = raw.get("pareto_tier")
        if isinstance(tier, bool) or not isinstance(tier, int) or tier < 1:
            raise ValueError(
                "sample_proxy_formula_leaderboard_pareto_tier_invalid"
            )
    return [dict(entry) for entry in entries]


def _leaderboard_entry_for_formula(
    leaderboard: Mapping[str, Any],
    formula_ref: str,
) -> dict[str, Any]:
    for entry in _leaderboard_entries(leaderboard):
        if str(entry["formula_artifact_ref"]) == formula_ref:
            return dict(entry)
    raise ValueError(
        "sample_proxy_formula_not_ranked:"
        f"formula_ref={formula_ref}"
    )


def _exact_visible_artifact(
    artifacts: Sequence[Mapping[str, Any]],
    artifact_ref: str,
    artifact_kind: str,
) -> dict[str, Any]:
    matches = [
        dict(item)
        for item in artifacts
        if item.get("artifact_ref") == artifact_ref
        and item.get("artifact_kind") == artifact_kind
    ]
    if len(matches) != 1:
        raise ValueError(
            "sample_exact_ranked_artifact_required:"
            f"kind={artifact_kind}:ref={artifact_ref}:actual={len(matches)}"
        )
    if not isinstance(matches[0].get("machine_payload"), Mapping):
        raise ValueError(
            f"sample_exact_ranked_artifact_payload_required:{artifact_ref}"
        )
    return matches[0]


def _resolved_auxiliary_pairs(
    artifacts: Sequence[Mapping[str, Any]],
    *,
    primary_formula_ref: str,
) -> list[dict[str, dict[str, Any]]]:
    formulas: list[dict[str, Any]] = []
    by_target_id: dict[str, str] = {}
    for item in artifacts:
        if item.get("artifact_kind") != "proxy_formula_candidate":
            continue
        formula_ref = str(item.get("artifact_ref") or "")
        payload = item.get("machine_payload")
        if not isinstance(payload, Mapping):
            raise ValueError(
                f"sample_formula_payload_required:{formula_ref}"
            )
        target_kind = str(payload.get("target_kind") or "").strip()
        target_id = str(payload.get("target_id") or "").strip()
        if target_kind not in {"final_kpi", "auxiliary_condition"} or not target_id:
            raise ValueError(
                f"sample_formula_target_identity_required:{formula_ref}"
            )
        if formula_ref == primary_formula_ref:
            if target_kind != "final_kpi":
                raise ValueError("sample_primary_formula_must_target_final_kpi")
            continue
        if target_kind != "auxiliary_condition":
            continue
        prior = by_target_id.get(target_id)
        if prior is not None and prior != formula_ref:
            raise ValueError(
                "sample_auxiliary_formula_target_ambiguous:"
                f"target_id={target_id}:refs={prior},{formula_ref}"
            )
        by_target_id[target_id] = formula_ref
        formulas.append(dict(item))

    pairs: list[dict[str, dict[str, Any]]] = []
    for formula in sorted(
        formulas,
        key=lambda item: str(item["machine_payload"]["target_id"]),
    ):
        formula_ref = str(formula["artifact_ref"])
        matches = [
            dict(item)
            for item in artifacts
            if item.get("artifact_kind")
            == "quantitative_proxy_materialization_result"
            and formula_ref in {
                str(ref) for ref in item.get("depends_on", [])
            }
            and isinstance(item.get("machine_payload"), Mapping)
            and item["machine_payload"].get("materialization_status")
            == "complete"
        ]
        if len(matches) != 1:
            raise ValueError(
                "sample_auxiliary_materialization_required:"
                f"formula_ref={formula_ref}:actual={len(matches)}"
            )
        pairs.append(
            {
                "formula": formula,
                "materialization": matches[0],
            }
        )
    return pairs


def _validate_selected_proxy_pair(
    formula: Mapping[str, Any],
    materialization: Mapping[str, Any],
    leaderboard_entry: Mapping[str, Any],
) -> None:
    formula_ref = str(formula.get("artifact_ref") or "")
    materialization_ref = str(materialization.get("artifact_ref") or "")
    formula_payload = formula.get("machine_payload")
    if (
        not isinstance(formula_payload, Mapping)
        or formula_payload.get("target_kind") != "final_kpi"
        or not str(formula_payload.get("target_id") or "").strip()
    ):
        raise ValueError("sample_primary_formula_target_identity_invalid")
    if leaderboard_entry.get("formula_artifact_ref") != formula_ref:
        raise ValueError("sample_leaderboard_formula_ref_mismatch")
    if leaderboard_entry.get("materialization_artifact_ref") != materialization_ref:
        raise ValueError("sample_leaderboard_materialization_ref_mismatch")
    if formula_ref not in {
        str(ref) for ref in materialization.get("depends_on") or []
    }:
        raise ValueError("sample_materialization_formula_dependency_mismatch")
    payload = materialization.get("machine_payload")
    if (
        not isinstance(payload, Mapping)
        or payload.get("materialization_status") != "complete"
    ):
        raise ValueError("sample_matching_materialization_incomplete")

def _single(
    artifacts: Sequence[Mapping[str, Any]],
    kind: str,
) -> dict[str, Any]:
    matches = [dict(item) for item in artifacts if item.get("artifact_kind") == kind]
    if len(matches) != 1:
        raise ValueError(f"sample_requires_one_{kind}:actual={len(matches)}")
    if not isinstance(matches[0].get("machine_payload"), Mapping):
        raise ValueError(f"sample_machine_payload_required:{kind}")
    return matches[0]


def _optional_lineage_tip(
    artifacts: Sequence[Mapping[str, Any]],
    kind: str,
) -> dict[str, Any] | None:
    matches = [dict(item) for item in artifacts if item.get("artifact_kind") == kind]
    if not matches:
        return None
    if len(matches) == 1:
        return matches[0]
    refs = {str(item.get("artifact_ref") or "") for item in matches}
    referenced = {
        str(ref)
        for item in matches
        for ref in item.get("depends_on", [])
        if str(ref) in refs
    }
    tips = [
        item
        for item in matches
        if str(item.get("artifact_ref") or "") not in referenced
    ]
    if len(tips) != 1:
        raise ValueError(f"sample_{kind}_lineage_ambiguous:{len(tips)}")
    return tips[0]


def _task_generation_context(artifact: Mapping[str, Any]) -> dict[str, Any]:
    payload = artifact["machine_payload"]
    context = {
        "artifact_ref": artifact["artifact_ref"],
        "goal": payload.get("goal", ""),
        "constraints": payload.get("constraints", []),
    }
    if payload.get("constraint_registry"):
        context["constraint_registry"] = payload["constraint_registry"]
    return context


def _hypothesis_generation_context(
    artifact: Mapping[str, Any],
) -> dict[str, Any]:
    payload = artifact["machine_payload"]
    fields = (
        "description",
        "research_question",
        "core_claim",
        "mechanism",
        "design_primitives",
        "expected_causal_chain",
        "verification_plan",
        "risks",
    )
    return {
        "artifact_ref": artifact["artifact_ref"],
        **{
            field: payload[field]
            for field in fields
            if payload.get(field) not in (None, "", [], {})
        },
    }


def _proxy_generation_context(
    artifact: Mapping[str, Any],
) -> dict[str, Any]:
    payload = artifact["machine_payload"]
    fields = (
        "target_kind",
        "target_id",
        "formula_expression",
        "expected_relation",
        "expected_final_kpi_link",
        "source_binding",
        "claim_boundary",
        "side_effect_notes",
    )
    return {
        "artifact_ref": artifact["artifact_ref"],
        **{
            field: payload[field]
            for field in fields
            if payload.get(field) not in (None, "", [], {})
        },
    }


def _iteration_mission(payload: Mapping[str, Any]) -> str:
    """Use the existing plan as this invocation's concise purpose."""
    plan = str(payload.get("plan_summary") or "").strip()
    return plan or str(payload.get("objective") or "").strip()

def _population_reference_bundle(
    historical: Mapping[str, Any],
    *,
    formula: Mapping[str, Any],
    materialization: Mapping[str, Any],
    auxiliary_pairs: Sequence[Mapping[str, Any]],
    previous: Mapping[str, Any] | None,
    generated_records: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    scorer_pairs = [
        {"formula": formula, "materialization": materialization},
        *[dict(pair) for pair in auxiliary_pairs],
    ]
    source_paths = sorted({
        path for pair in scorer_pairs
        for path in materialization_input_paths(pair["materialization"])
    })
    relations: dict[str, str] = {}
    for pair in scorer_pairs:
        formula_payload = pair["formula"].get("machine_payload")
        if not isinstance(formula_payload, Mapping):
            raise ValueError("sample_population_formula_payload_required")
        target_id = str(formula_payload.get("target_id") or "").strip()
        relation = str(
            formula_payload.get("expected_relation") or ""
        ).strip()
        if not target_id or relation not in {
            "higher_proxy_higher_kpi",
            "lower_proxy_higher_kpi",
        }:
            raise ValueError("sample_population_formula_target_invalid")
        if target_id in relations:
            raise ValueError(
                f"sample_population_target_duplicate:{target_id}"
            )
        relations[target_id] = relation
    primary_target_id = str(formula["machine_payload"]["target_id"])

    records = historical.get("records")
    if not isinstance(records, list) or not records:
        raise ValueError("sample_historical_references_required")
    historical_by_id = {
        str(record.get("id")): record for record in records
    }
    generated_by_id = {
        str(record.get("id")): record for record in generated_records
    }

    if previous is None:
        values_by_target: dict[str, Mapping[str, Any]] = {}
        for pair in scorer_pairs:
            formula_payload = pair["formula"]["machine_payload"]
            target_id = str(formula_payload["target_id"])
            values = pair["materialization"]["machine_payload"].get(
                "proxy_values_by_sample"
            )
            if not isinstance(values, Mapping):
                raise ValueError(
                    f"sample_historical_values_required:{target_id}"
                )
            if {str(sample_id) for sample_id in values} != set(
                historical_by_id
            ):
                raise ValueError(
                    f"sample_historical_reference_identity_mismatch:{target_id}"
                )
            values_by_target[target_id] = values
        rows = [
            {
                "sample_id": sample_id,
                **_sample_representation_fields(record),
                "is_novel": False,
                "proxy_value": values_by_target[primary_target_id][sample_id],
                "index_values": {
                    target_id: values[sample_id]
                    for target_id, values in values_by_target.items()
                },
            }
            for sample_id, record in historical_by_id.items()
        ]
        iteration_count = 0
        current_parent = None
    else:
        population = previous["machine_payload"]
        ranked = population.get("ranked_samples")
        if not isinstance(ranked, list) or not ranked:
            raise ValueError("sample_previous_ranked_population_required")
        rows = [dict(row) for row in ranked if isinstance(row, Mapping)]
        if len(rows) != len(ranked):
            raise ValueError("sample_previous_ranked_population_invalid")
        iteration_count = int(population["iteration_count"])
        best_row = dict(population["best_sample"])
        current_parent = {
            **best_row,
            "sample": _record_for_ranked_row(
                best_row,
                historical_by_id=historical_by_id,
                generated_by_id=generated_by_id,
                source_paths=source_paths,
            ),
        }

    ranked_rows = rank_multi_index_rows(
        rows,
        index_relations=relations,
        primary_target_id=primary_target_id,
    )
    high_ids = {str(row["sample_id"]) for row in ranked_rows[:2]}
    selected_by_id = {
        str(row["sample_id"]): row
        for row in [*ranked_rows[:2], *ranked_rows[-2:]]
    }
    references = [
        {
            "sample_id": str(row["sample_id"]),
            "proxy_value": row["proxy_value"],
            "index_values": dict(row["index_values"]),
            "index_ranks": dict(row["index_ranks"]),
            "pareto_tier": row["pareto_tier"],
            "rank_role": (
                "high_reference"
                if str(row["sample_id"]) in high_ids
                else "low_reference"
            ),
            "origin": (
                "generated" if row.get("is_novel") is True else "historical"
            ),
            "sample": {
                **_record_for_ranked_row(
                    row,
                    historical_by_id=historical_by_id,
                    generated_by_id=generated_by_id,
                    source_paths=source_paths,
                )
            },
        }
        for row in selected_by_id.values()
    ]
    return {
        "iteration_count": iteration_count,
        "population_size": len(ranked_rows),
        "current_generated_parent": current_parent,
        "high_low_references": references,
        "existing_generated_ids": [
            str(row["sample_id"])
            for row in ranked_rows
            if row.get("is_novel") is True
        ],
    }

def _generated_candidates(
    runtime: Any,
    previous: Mapping[str, Any] | None,
    *,
    structured: bool = False,
) -> list[dict[str, Any]]:
    if previous is None:
        return []
    ranked = previous["machine_payload"]["ranked_samples"]
    generated_ids = {
        str(row.get("sample_id") or "").strip()
        for row in ranked
        if row.get("is_novel") is True
    }
    bundle_refs = [
        str(ref)
        for ref in previous.get("trace_refs", [])
        if str(ref).startswith("workspace:sample-candidate-bundles/")
    ]
    if len(bundle_refs) > 1:
        raise ValueError("sample_previous_candidate_bundle_ambiguous")
    if bundle_refs:
        bundle = runtime.call_route(
            "scientific_sample_candidate_bundle_read",
            {"candidate_bundle_ref": bundle_refs[0]},
        )
        if str(bundle.get("candidate_bundle_ref") or "") != bundle_refs[0]:
            raise ValueError("sample_candidate_bundle_ref_mismatch")
        records = bundle.get("records")
        if not isinstance(records, list) or not records:
            raise ValueError("sample_previous_candidate_bundle_invalid")
        candidates = [
            _candidate_from_stored_record(record, structured=structured)
            for record in records
            if isinstance(record, Mapping)
        ]
        if len(candidates) != len(records) or {
            str(candidate["id"]) for candidate in candidates
        } != generated_ids:
            raise ValueError("sample_candidate_bundle_population_mismatch")
        return candidates

    candidates: list[dict[str, Any]] = []
    for row in ranked:
        if row.get("is_novel") is not True:
            continue
        sample_id = str(row.get("sample_id") or "").strip()
        smiles = str(row.get("smiles") or "").strip()
        if not sample_id or not smiles:
            raise ValueError("sample_previous_generated_representation_required")
        candidate = {"id": sample_id, "smiles": smiles}
        description = str(row.get("input_description") or "").strip()
        if description:
            candidate["input_description"] = description
        candidates.append(candidate)
    return candidates


def _candidate_from_stored_record(
    record: Mapping[str, Any],
    *,
    structured: bool = False,
) -> dict[str, Any]:
    sample_id = str(record.get("id") or "").strip()
    description = str(record.get("input_description") or "").strip()
    metadata = record.get("metadata")
    if not sample_id or not isinstance(metadata, Mapping) or not metadata:
        raise ValueError("sample_stored_candidate_record_invalid")
    if not structured and set(metadata) == {"smiles"}:
        smiles = str(metadata.get("smiles") or "").strip()
        if not smiles:
            raise ValueError("sample_stored_candidate_record_invalid")
        candidate: dict[str, Any] = {"id": sample_id, "smiles": smiles}
        if description:
            candidate["input_description"] = description
        return candidate
    if not description:
        raise ValueError("sample_stored_candidate_description_required")
    return {
        "id": sample_id,
        "input_description": description,
        "metadata": copy.deepcopy(dict(metadata)),
    }


def _record_for_ranked_row(
    row: Mapping[str, Any],
    *,
    historical_by_id: Mapping[str, Mapping[str, Any]],
    generated_by_id: Mapping[str, Mapping[str, Any]],
    source_paths: Sequence[str],
) -> dict[str, Any]:
    sample_id = str(row.get("sample_id") or "").strip()
    source = (
        generated_by_id.get(sample_id)
        if row.get("is_novel") is True
        else historical_by_id.get(sample_id)
    )
    if not isinstance(source, Mapping):
        raise ValueError(
            f"sample_population_record_missing:{sample_id}"
        )
    if row.get("is_novel") is not True:
        return candidate_from_source(source, source_paths)
    result = {"id": sample_id}
    description = str(source.get("input_description") or "").strip()
    if description:
        result["input_description"] = description
    metadata = source.get("metadata")
    if isinstance(metadata, Mapping) and metadata:
        result["metadata"] = copy.deepcopy(dict(metadata))
    else:
        smiles = str(source.get("smiles") or "").strip()
        if smiles:
            result["metadata"] = {"smiles": smiles}
    if not isinstance(result.get("metadata"), Mapping):
        raise ValueError(
            f"sample_population_representation_missing:{sample_id}"
        )
    return result


def _validate_previous_population(
    previous: Mapping[str, Any],
    *,
    formula_ref: str,
    materialization_ref: str,
) -> None:
    dependencies = {str(ref) for ref in previous.get("depends_on", [])}
    if formula_ref not in dependencies or materialization_ref not in dependencies:
        raise ValueError("sample_previous_population_frozen_lineage_mismatch")
    payload = previous.get("machine_payload")
    if not isinstance(payload, Mapping):
        raise ValueError("sample_previous_population_payload_required")
    if payload.get("artifact_kind") != "sample_evolution_result":
        raise ValueError("sample_previous_population_kind_mismatch")
    iteration_count = payload.get("iteration_count")
    rank_history = payload.get("rank_history")
    ranked = payload.get("ranked_samples")
    best = payload.get("best_sample")
    if (
        not isinstance(iteration_count, int)
        or isinstance(iteration_count, bool)
        or iteration_count < 1
        or not isinstance(rank_history, list)
        or len(rank_history) != iteration_count
        or not isinstance(ranked, list)
        or not ranked
        or not isinstance(best, Mapping)
        or best.get("is_novel") is not True
    ):
        raise ValueError("sample_previous_population_state_invalid")


def _accumulate_result(
    current: Mapping[str, Any],
    previous: Mapping[str, Any] | None,
) -> dict[str, Any]:
    result = dict(current)
    current_history = result.get("rank_history")
    if not isinstance(current_history, list) or len(current_history) != 1:
        raise ValueError("sample_current_iteration_history_required")
    prior_payload = previous.get("machine_payload") if previous is not None else None
    previous_count = (
        int(prior_payload["iteration_count"])
        if isinstance(prior_payload, Mapping)
        else 0
    )
    previous_history = (
        [dict(item) for item in prior_payload["rank_history"]]
        if isinstance(prior_payload, Mapping)
        else []
    )
    next_iteration = previous_count + 1
    current_entry = dict(current_history[0])
    current_entry["iteration"] = next_iteration
    result["rank_history"] = [*previous_history, current_entry]
    result["iteration_count"] = next_iteration
    previous_issues = (
        list(prior_payload.get("residual_issues") or [])
        if isinstance(prior_payload, Mapping)
        else []
    )
    current_issues = list(result.get("residual_issues") or [])
    result["residual_issues"] = list(dict.fromkeys([*previous_issues, *current_issues]))
    return result


def _sample_result(inspected: Mapping[str, Any]) -> dict[str, Any]:
    observation = inspected.get("observation")
    result = observation.get("result") if isinstance(observation, Mapping) else None
    if not isinstance(result, Mapping):
        raise ValueError("sample_inspected_result_required")
    return dict(result)


def _validate_result(
    result: Mapping[str, Any],
    candidate_id: str,
    expected_count: int,
    expected_iteration: int,
    expected_target_ids: set[str],
) -> None:
    if result.get("artifact_kind") != "sample_evolution_result":
        raise ValueError("sample_result_kind_mismatch")
    best = result.get("best_sample")
    if not isinstance(best, Mapping):
        raise ValueError("sample_result_best_generated_required")
    value = best.get("proxy_value")
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not math.isfinite(float(value))
    ):
        raise ValueError("sample_result_proxy_value_invalid")
    if best.get("is_novel") is not True:
        raise ValueError("sample_result_candidate_not_novel")

    ranked = result.get("ranked_samples")
    if not isinstance(ranked, list) or len(ranked) != expected_count:
        raise ValueError("sample_result_population_incomplete")
    ids = [
        str(row.get("sample_id") or "") for row in ranked if isinstance(row, Mapping)
    ]
    if len(ids) != len(ranked) or len(set(ids)) != len(ids):
        raise ValueError("sample_result_population_identity_invalid")
    for row in ranked:
        index_values = row.get("index_values")
        index_ranks = row.get("index_ranks")
        pareto_tier = row.get("pareto_tier")
        if (
            not isinstance(index_values, Mapping)
            or not index_values
            or not isinstance(index_ranks, Mapping)
            or set(map(str, index_values)) != set(map(str, index_ranks))
            or set(map(str, index_values)) != expected_target_ids
        ):
            raise ValueError("sample_result_multi_index_shape_invalid")
        if (
            isinstance(pareto_tier, bool)
            or not isinstance(pareto_tier, int)
            or pareto_tier < 1
            or any(
                isinstance(rank, bool)
                or not isinstance(rank, int)
                or rank < 1
                for rank in index_ranks.values()
            )
        ):
            raise ValueError("sample_result_multi_index_rank_invalid")
    candidate_rows = [
        row
        for row in ranked
        if isinstance(row, Mapping) and str(row.get("sample_id")) == candidate_id
    ]
    if len(candidate_rows) != 1 or candidate_rows[0].get("is_novel") is not True:
        raise ValueError("sample_result_new_candidate_missing")
    candidate_value = candidate_rows[0].get("proxy_value")
    if (
        not isinstance(candidate_value, (int, float))
        or isinstance(candidate_value, bool)
        or not math.isfinite(float(candidate_value))
    ):
        raise ValueError("sample_result_new_candidate_proxy_value_invalid")

    history = result.get("rank_history")
    if (
        result.get("iteration_count") != expected_iteration
        or not isinstance(history, list)
        or len(history) != expected_iteration
        or not isinstance(history[-1], Mapping)
        or history[-1].get("iteration") != expected_iteration
        or history[-1].get("ranked_sample_ids") != ids
    ):
        raise ValueError("sample_result_iteration_history_invalid")
