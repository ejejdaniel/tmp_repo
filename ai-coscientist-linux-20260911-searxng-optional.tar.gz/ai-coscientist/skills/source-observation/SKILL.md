---
name: source-observation
description: Produces one bounded, traceable source_observation C2 artifact from mission-scoped source material. Requires one or more readable source files or directories. Boundary: explores and reports structure, quality, signals, and gaps without changing sources, preparing downstream data, or inventing scientific meaning.
estimated_complexity: high
---

# Source Observation

## Responsibility and boundary

Inspect unfamiliar mission-scoped files, maintain one bounded C3 working
observation, and publish its final immutable C2 snapshot for exact-ref handoff.

This skill observes sources. It does not formulate the scientific task, decide
what a field means scientifically, perform a literature survey, normalize every
format into one schema, alter source files, or prepare downstream data. Its C2
result records what was actually observed; a downstream capability remains
responsible for interpretation and for reading exact source refs when content
authority matters.

## Entry conditions and authority

The mission must mount at least one file or directory through the source
allowlist. The mounted source files are the only content authority. Inventory
rows, search matches, previews, summaries, receipts, and model prose are
projections, never substitute source bodies.

Use only these selected-skill routes:

- `source_inventory`: discover allowed files and obtain exact `source_file:` refs.
- `source_search`: locate text in all or selected exact source refs.
- `source_read`: read one bounded page from a source or probe-output ref inside
  this skill-local workflow; the main-agent projection exposes the same stored
  content through `read_ref`.
- `source_probe`: run short Python against staged copies of selected source refs.
- `workspace_terminal`: run one host-shell command from the mission source root
  for exhaustive inventory, aggregation, or cross-file inspection that the
  bounded routes cannot express efficiently. This route is internal to this
  skill and is not exposed as a main-agent action.

The model chooses readable relative paths. The skill-local workflow resolves
those paths to exact refs mechanically; the model never copies opaque hashes.

`source_probe` starts in the staged-copy root and exposes `SOURCE_ROOT` as a
`pathlib.Path` pointing to the same directory. It stores its code, standard
output, standard error, and manifest in C4 and returns exact `source_probe:`
refs. Use that existing path object directly; never assign, redefine, delete, or
shadow `SOURCE_ROOT`. Let source-access and parsing exceptions fail the probe so
they remain failures with readable diagnostics; do not catch them merely to print
an error object as successful output. The underlying route can also stage an
exact prior probe ref for a later
code-based check; this skill's ordinary probe action still selects mounted source
paths. It cannot make an unsupported format meaningful; report
that limitation instead of inventing content.

If the allowlist is empty, inaccessible, or contains no readable files, return
the precise source gap. Never fall back to demo or synthetic data.

## Trigger examples

### Should select

- A user mounts a large, irregular CSV and asks the agent to understand its
  columns, missingness, ranges, and reliability before defining the task.
- A mission mounts a folder containing Markdown, JSON, and images and asks what
  information is actually available, what remains unreadable, and which exact
  sources should inform later work.

### Should not select

- The source structure is already understood and the user asks for a scientific
  hypothesis; the hypothesis capability owns that result.
- The request asks to inspect `measurements.csv`, but no such file or containing
  directory is mounted; the parent must supply or mount the source first.

## Prompt and memory projection

| Class | Content and unique location | Prompt use and metabolism |
|---|---|---|
| C0 | Objective, user limits, and evaluation summary in agent core state | Every decision receives the objective and completion evidence. They are never rewritten. |
| C1 | Active source-observation work unit and current issue in common state | The local decision sees the active plan as coverage context but does not prescribe another skill. |
| C2 | One immutable `source_observation` artifact in the artifact store | Published only after final synthesis and exact-ref validation; downstream skills receive it only through selected `input_refs`. |
| C3 | Current bounded working observation in common runtime knowledge | Each internal decision replaces it with a verified revision. It exists only during this selected workflow and clears when the skill is released. |
| C4 | Original mounted files plus probe and terminal command/stdout/stderr/manifest files in source/workspace stores | Prompts receive refs, metadata, and one bounded page or preview only. Full bodies remain retrievable through refs. |
| C5 | Current action decision, bounded prior action receipts, action payload, latest bounded route result, and at most one narrow search-syntax repair | Replaced at each internal stage and cleared when the skill returns. |
| C6 | Exact prompts, model responses, route calls, errors, and raw receipts in the append-only event log | Audit only. Never feed C6 back as task evidence. |

The action-decision prompt receives C0 objective and completion evidence, the
active C1 plan and previous common closure feedback, current C3 summary, one
latest bounded C4 observation, a readable path catalog, the small set of actually
inspected evidence, and the action budget. Closure feedback is diagnostic context
for repairing the same observation, not a new instruction. Discovery does not
make a source citable: only a successful read, probe, or terminal action adds it to inspected
evidence. Filenames, directories, search matches, and index pointers are locator
evidence only. A content-level objective must inspect the relevant index or
manifest and the selected source bodies before it can finish. The action-payload prompt receives the
selected action rationale, so it prepares that action instead of choosing a new
target. It also receives only the same relevant projections plus the chosen
route schema. For search, it explicitly distinguishes literal text from regular
expressions, may narrow an operation with exact discovered relative paths that
the workflow resolves to refs, and receives bounded receipts of operations
already attempted. The final synthesis prompt judges the accumulated C3 against
the completion evidence and applies every explicit task visibility or
withholding constraint before producing public C2 prose. Exact refs are
installed mechanically from the successful read/probe/terminal set; the model never
copies opaque identifiers.
No stage receives duplicated inventory entries, the full opaque ref list,
unrelated formal artifacts, parent memory, or full raw logs.

### LLM call contracts

| Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
|---|---|---|---|---|---|---|---|
| `source-observation` | `choose-source-exploration-action-*` | C0 objective/evidence, active C1 plan and issue, current C3 summary, latest bounded C4 result, readable path catalog, inspected refs, and remaining budget | Choose one search/read/probe/terminal/finish action and replace the working summary; do not prepare tool arguments | Existing `{action, reason, working_summary}` shape | Structured schema and action enum | Common same-stage format repair only | Selected action payload call or final synthesis |
| `source-observation` | `prepare-search/read/probe/terminal-payload-*` | The already selected action and rationale plus the same bounded C0/C1/C3/C4 projections, bounded C5 action receipts, and only that route schema | Prepare parameters for the selected route; do not choose a different target or claim evidence | Existing route-specific payload shape | Route-schema checks plus mechanical path/ref, pagination, timeout, duplicate-read-window, and duplicate-search-signature validation | One narrow search-syntax repair; otherwise route or payload failure returns to the same local exploration loop | Exact source route execution |
| `source-observation` | `synthesize-source-observation` | C0 objective/evidence, active C1 context, final C3 summary, latest bounded result, and readable descriptions of successfully inspected evidence | Produce one bounded observation and honest completion status while enforcing explicit task visibility constraints; do not copy opaque refs | Existing complete observation shape; `evidence_refs` is ignored and replaced by runtime | Structured schema, bounded fields, mechanically installed inspected refs, and non-empty evidence | Common same-stage format repair only | C2 publication and exact readback |

## Skill-local workflow

1. Call source_inventory once to establish the mission-visible source set and
   the private relative-path-to-ref mapping. Restore only any existing
   skill-scoped evidence refs that still resolve to the current mount.
2. Enter a bounded loop of at most eight exploration actions.
3. At each iteration, update the C3 working summary and choose exactly one of:
   search, read, probe, terminal, or finish.
4. Pass the selected action rationale into its payload call, reveal only that
   action contract, and resolve selected paths to exact refs before execution.
   A literal search is one substring; alternative terms require a valid regular
   expression. Search matches locate candidate files but are not evidence. The
   same query over a different explicit file scope is a distinct operation.
   For formal project results, prefer machine-readable indexes or manifests,
   resolve the relevant entries, and inspect selected result bodies; directory
   names alone cannot support a content comparison.
5. After every probe or terminal command, read its exact stored output before
   another model decision; a receipt or preview is not evidence. A successful
   terminal command reads stdout. A failed or timed-out terminal command reads
   both stdout and stderr because partial results and diagnostics may be split
   across the two streams.
6. If a search payload uses boolean-looking syntax as literal text, contains an
   invalid regular expression, or repeats a prior search, perform at most one
   narrow payload repair before route execution. A still-invalid or repeated
   payload is not executed.
7. After two consecutive search actions without an intervening content
   inspection, remove search from the next decision's available actions. The
   workflow must read, probe, use the terminal, or finish with an explicit gap
   instead of spending a third action on another locator-only search.
8. Recognize the existing ArtifactStore index and artifact-envelope structures
   by parsing their exact JSON shapes. Reading an index marks one artifact body
   as still required and temporarily removes finish. Reading an actual formal
   artifact envelope clears that transport requirement. This check distinguishes
   locator from body transport only; Python does not interpret artifact science.
9. Other route or payload failures remain inside this loop so the next decision
   can correct the operation. Do not spend another main-agent action on local repair.
10. Record successful read windows. If the model repeats an already-read offset,
   continue from the stored next_line_offset instead of rereading the page.
11. On finish or budget exhaustion, synthesize one concise observation with
   explicit unknowns and apply task-authored output visibility constraints.
12. Ignore model-authored opaque refs and mechanically install the exact set of
    refs successfully read, probed, or produced by terminal actions in this workflow.

The sequence inside this skill is fixed only at its control boundaries. The
choice and number of searches, reads, probes, and terminal actions remain evidence-driven.

## Formal output and handoff

The workflow publishes one formal C2 `source_observation`. Its machine payload
contains exactly:

- `artifact_kind`;
- `completion_status` (`complete`, `partial`, or `blocked`);
- `source_structure`;
- `data_quality`;
- `useful_signals`;
- `unknowns`.

The artifact envelope owns the concise `summary`; `trace_refs` owns the exact
`source_file:`, `source_probe:`, or `workspace_terminal:` evidence refs. These values are not duplicated
inside the machine payload. Complete, partial, and blocked observations map to
`proposed`, `draft`, and `rejected` envelope status respectively. The workflow
must read the exact stored artifact before returning its ref.

C3 remains mutable working knowledge for this selected skill only and clears
when the skill is released. Cross-skill handoff uses the immutable C2 ref, never
the C3 text, prompt prose, or a receipt. A consumer may use the observation as a
navigation aid, but must still read the cited C4 source content before treating
it as content authority.

## Failure and repair

- Malformed model output receives the common one-attempt structured repair.
- Search syntax receives at most one skill-local payload repair. The workflow
  never executes the same normalized query/regex/scope combination twice.
- Invalid route parameters, failed probes, or failed terminal commands remain visible in the local loop;
  another local action may correct them.
- Probe standard output and error remain retrievable through exact refs even on
  failure or timeout.
- Terminal command, standard output, standard error, and manifest remain
  retrievable through exact refs even on failure or timeout. The workflow reads
  both terminal streams after a failed or timed-out command so useful partial
  stdout is not discarded merely because the process returned nonzero.
- Binary or unsupported media without a mounted reader becomes an explicit
  unknown, not guessed content.
- Empty or inaccessible mission sources are an input gap for the parent.
- Report a bounded gap when the source-observation work unit no
  longer contributes to the evaluation path; this skill never chooses the next
  production skill.

## Validation evidence

- Route tests verify allowlist isolation, immutable source refs, paginated reads,
  bounded search, staged-copy probes, source non-mutation, and probe-output
  readback.
- Workflow tests verify dynamic action choice, C3 replacement, exact evidence
  refs, bounded local repair, C2 publication, and exact readback.
- Catalog tests verify the existing scientific workflow still mounts exactly its
  original eight skills.
- The smallest real-model test mounts real project sources, runs one persistent
  common agent, and checks that every reported claim has a readable source or
  probe ref. It proves only this observation skill, not the scientific workflow.
