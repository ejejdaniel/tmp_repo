from __future__ import annotations

import hashlib
import json
import unicodedata
from typing import Any, Mapping, Sequence

from ai_coscientist.domain.proxy_discovery import (
    ProxySourceGroundingGap,
    develop_proxy_formula,
)
from ai_coscientist.domain.proxy_formula_contract import (
    render_formula_markdown,
    validate_formula_candidate,
    validate_formula_core,
)


_SELECTION_SCHEMA = {
    "type": "object",
    "properties": {
        "selection_index": {"type": "integer", "minimum": 1},
        "reason": {"type": "string", "minLength": 1, "maxLength": 2000},
    },
    "required": ["selection_index", "reason"],
    "additionalProperties": False,
}

_SELECTION_PROMPT = """\
Select one uncovered soft scientific condition for which a low-computation,
interpretable quantitative proxy would most help sample search. An eligible
condition describes a desired measured, physical, structural, process, or
performance property of the studied subject or proposed sample. A statement
that only governs proxy quality, evidence, privacy, workflow, implementation
responsibility, or permitted claims is not an auxiliary scientific condition
and must not be selected. Choose only by selection_index. Do not rewrite the
condition, draft a formula, or prefer a condition merely because it is easy to
name. The later route will assess source grounding and implementation
plausibility.
"""

_CONTEXT_KINDS = {
    "task_spec",
    "hypothesis_mind_map",
    "hypothesis",
}


def run(payload: dict[str, Any], runtime: Any) -> dict[str, Any]:
    manifest = runtime.call_route("scientific_source_manifest", {})
    visible_historical = runtime.call_route(
        "scientific_source_visible_historical",
        {},
    )
    _validate_visible_source(manifest, visible_historical)

    formal_context = _resolved_formal_context(
        runtime,
        list(payload.get("resolved_inputs") or []),
    )
    task = _one_task_spec(formal_context)
    constraints = _task_constraints(task)
    existing_targets = _existing_auxiliary_formula_targets(runtime)
    options = [
        {
            "selection_index": index,
            "condition": condition,
            "target_id": _target_id(condition),
        }
        for index, condition in enumerate(constraints, start=1)
        if _target_id(condition) not in existing_targets
    ]
    if not options:
        return {
            "status": "bounded_gap",
            "reason": (
                "Every explicit task condition already has a visible "
                "proxy_formula_candidate target, or the task has no condition."
            ),
        }

    selection = runtime.generate_json(
        _SELECTION_PROMPT,
        json.dumps(
            {
                "task_goal": task["machine_payload"].get("goal"),
                "uncovered_conditions": options,
                "visible_source_shape": _source_shape(visible_historical),
            },
            ensure_ascii=False,
            sort_keys=True,
        ),
        purpose="select-auxiliary-condition",
        schema=_SELECTION_SCHEMA,
    )
    selected = _selected_option(options, selection)
    target_id = str(selected["target_id"])
    try:
        candidate = develop_proxy_formula(
            runtime,
            target_metric={
                "target_kind": "auxiliary_condition",
                "target_id": target_id,
                "name": target_id,
                "scientific_meaning": selected["condition"],
            },
            formal_scientific_context=formal_context,
            source_manifest=manifest,
            sanitized_historical_data=visible_historical,
            validate_formula_core=validate_formula_core,
            validate_formula_candidate=validate_formula_candidate,
            purpose_prefix="draft-auxiliary-proxy",
        )
    except ProxySourceGroundingGap as exc:
        return {"status": "bounded_gap", "reason": str(exc)}
    candidate = dict(candidate)
    candidate["target_kind"] = "auxiliary_condition"
    candidate["target_id"] = target_id
    candidate["formula_id"] = f"aux-proxy-{target_id.removeprefix('aux-')}"
    candidate["version"] = 1

    issues = validate_formula_candidate(candidate)
    if issues:
        raise ValueError(
            "auxiliary_proxy_publication_blocked:" + "; ".join(issues)
        )

    dependencies = [
        str(item["artifact_ref"])
        for item in formal_context
        if str(item.get("artifact_ref") or "").startswith("artifact:")
    ]
    prepared_source_ref = str(
        manifest.get("prepared_source_artifact_ref") or ""
    ).strip()
    if prepared_source_ref:
        if not prepared_source_ref.startswith("artifact:"):
            raise ValueError("auxiliary_proxy_prepared_source_ref_invalid")
        dependencies.append(prepared_source_ref)

    receipt = runtime.publish_artifact(
        artifact_kind="proxy_formula_candidate",
        artifact_id=f"{candidate['formula_id']}-v1",
        title=f"Auxiliary-condition proxy for {selected['condition']}",
        markdown=render_formula_markdown(candidate),
        summary=(
            "Interpretable low-cost proxy formula for one exact task "
            "condition, with source-bound inputs and materialization handoff. "
            "Target: target_kind=auxiliary_condition; "
            f"target_id={target_id}."
        ),
        machine_payload=candidate,
        depends_on=_deduplicated(dependencies),
        self_review={
            "formula_contract_validated": True,
            "target_identity_host_controlled": True,
        },
    )
    stored = runtime.read_artifact(str(receipt["artifact_ref"]))
    if stored.get("machine_payload") != candidate:
        raise ValueError("published_auxiliary_proxy_readback_mismatch")
    return {
        "status": "completed",
        "summary": (
            "Published and read back one validated auxiliary-condition proxy "
            f"for target {target_id}."
        ),
        "artifact_ref": receipt["artifact_ref"],
    }


def _resolved_formal_context(
    runtime: Any,
    resolved: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen_refs: set[str] = set()
    for raw in resolved:
        if not isinstance(raw, Mapping):
            continue
        kind = str(raw.get("artifact_kind") or "")
        if kind not in _CONTEXT_KINDS:
            continue
        artifact_ref = str(raw.get("artifact_ref") or "")
        if not artifact_ref.startswith("artifact:"):
            raise ValueError("auxiliary_proxy_resolved_artifact_ref_invalid")
        if artifact_ref in seen_refs:
            continue
        artifact = dict(raw)
        if not isinstance(artifact.get("machine_payload"), Mapping):
            artifact = dict(runtime.read_artifact(artifact_ref))
        if artifact.get("artifact_kind") != kind:
            raise ValueError("auxiliary_proxy_resolved_artifact_kind_mismatch")
        if not isinstance(artifact.get("machine_payload"), Mapping):
            raise ValueError("auxiliary_proxy_resolved_payload_required")
        result.append(artifact)
        seen_refs.add(artifact_ref)

    task_count = sum(
        item.get("artifact_kind") == "task_spec" for item in result
    )
    if task_count != 1:
        raise ValueError(
            "auxiliary_proxy_requires_one_resolved_task_spec:"
            f"actual={task_count}"
        )
    return result


def _one_task_spec(
    context: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    matches = [
        dict(item) for item in context if item.get("artifact_kind") == "task_spec"
    ]
    if len(matches) != 1:
        raise ValueError(
            f"auxiliary_proxy_requires_one_resolved_task_spec:actual={len(matches)}"
        )
    return matches[0]


def _task_constraints(task: Mapping[str, Any]) -> list[str]:
    payload = task.get("machine_payload")
    raw = payload.get("constraints") if isinstance(payload, Mapping) else None
    if not isinstance(raw, list):
        raise ValueError("auxiliary_proxy_task_constraints_required")
    constraints = [
        str(value).strip()
        for value in raw
        if isinstance(value, str) and str(value).strip()
    ]
    if len(constraints) != len(raw):
        raise ValueError("auxiliary_proxy_task_constraint_invalid")
    return _deduplicated(constraints)


def _existing_auxiliary_formula_targets(runtime: Any) -> dict[str, str]:
    targets: dict[str, str] = {}
    for receipt in runtime.artifact_index():
        if receipt.get("artifact_kind") != "proxy_formula_candidate":
            continue
        artifact_ref = str(receipt.get("artifact_ref") or "")
        artifact = runtime.read_artifact(artifact_ref)
        payload = artifact.get("machine_payload")
        if not isinstance(payload, Mapping):
            raise ValueError(
                f"auxiliary_proxy_formula_payload_required:{artifact_ref}"
            )
        target_id = str(payload.get("target_id") or "").strip()
        target_kind = str(payload.get("target_kind") or "").strip()
        if not target_id or target_kind not in {
            "final_kpi",
            "auxiliary_condition",
        }:
            raise ValueError(
                f"auxiliary_proxy_formula_target_identity_required:{artifact_ref}"
            )
        if target_kind == "final_kpi":
            continue
        prior_ref = targets.get(target_id)
        if prior_ref is not None and prior_ref != artifact_ref:
            raise ValueError(
                "auxiliary_proxy_target_formula_ambiguous:"
                f"target_id={target_id}:refs={prior_ref},{artifact_ref}"
            )
        targets[target_id] = artifact_ref
    return targets


def _selected_option(
    options: Sequence[Mapping[str, Any]],
    selection: Mapping[str, Any],
) -> dict[str, Any]:
    index = selection.get("selection_index")
    if isinstance(index, bool) or not isinstance(index, int):
        raise ValueError("auxiliary_proxy_selection_index_invalid")
    matches = [
        dict(option)
        for option in options
        if option.get("selection_index") == index
    ]
    if len(matches) != 1:
        raise ValueError(
            f"auxiliary_proxy_selection_out_of_range:{index}"
        )
    return matches[0]


def _target_id(condition: str) -> str:
    normalized = unicodedata.normalize(
        "NFKC",
        " ".join(str(condition).strip().split()),
    )
    digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:12]
    return f"aux-{digest}"


def _validate_visible_source(
    manifest: Mapping[str, Any],
    visible_historical: Mapping[str, Any],
) -> None:
    historical_manifest = manifest.get("historical_data")
    records = visible_historical.get("records")
    if not isinstance(historical_manifest, Mapping):
        raise ValueError("scientific_source_historical_manifest_required")
    if not isinstance(records, list) or not records:
        raise ValueError("scientific_source_visible_records_required")
    if historical_manifest.get("record_count") != len(records):
        raise ValueError("scientific_source_visible_record_count_mismatch")
    forbidden = {
        "ground_truth_kpi",
        "ground_truth_description",
        "avg_score",
        "score_MoO3",
        "score_WO3",
        "substrate_scores",
    }
    for record in records:
        if not isinstance(record, Mapping):
            raise ValueError("scientific_source_visible_record_invalid")
        metadata = record.get("metadata")
        metadata = metadata if isinstance(metadata, Mapping) else {}
        leaked = (set(record) | set(metadata)) & forbidden
        if leaked:
            raise ValueError(
                f"scientific_source_private_field_leak:{sorted(leaked)}"
            )


def _source_shape(source: Mapping[str, Any]) -> dict[str, Any]:
    records = source.get("records")
    records = records if isinstance(records, list) else []
    return {
        "record_count": len(records),
        "record_keys": sorted(
            {
                str(key)
                for record in records
                if isinstance(record, Mapping)
                for key in record
            }
        ),
        "metadata_keys": sorted(
            {
                str(key)
                for record in records
                if isinstance(record, Mapping)
                and isinstance(record.get("metadata"), Mapping)
                for key in record["metadata"]
            }
        ),
    }


def _deduplicated(values: Sequence[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        if value not in result:
            result.append(value)
    return result
