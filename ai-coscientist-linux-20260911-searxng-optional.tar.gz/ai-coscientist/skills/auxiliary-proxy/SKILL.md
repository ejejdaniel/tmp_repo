---
name: auxiliary-proxy
description: "Produces one complete frozen auxiliary-condition proxy_formula_candidate. Requires one exact task_spec with an explicitly named non-final soft or auxiliary condition and sanitized sources; target_kind is auxiliary_condition. Boundary: never handles the task's primary or final KPI, formula ranking, or implementation."
estimated_complexity: high
---

# Auxiliary Proxy

## Responsibility and boundary

Produce one interpretable, low-computation proxy_formula_candidate for one explicit soft condition in the accepted task. This skill owns condition selection, stable target identity, reusable P1-P4 proxy discovery, publication, and exact readback. It does not materialize record values, access held-out final-KPI values, privately calibrate against final KPI, rank formulas, revise an existing target, or direct the next production skill.

The reusable P1-P4 reasoning is the domain route ai_coscientist.domain.proxy_discovery.develop_proxy_formula. The route is not a planner-visible stage. `final-kpi-proxy-discovery` uses the same route for the final KPI while retaining separate final-target authority, formula identity, challenger deduplication, and publication responsibility. Later evaluator and reviewer stages own calibration and leaderboard updates.

## Entry conditions and authority

- `resolved_inputs_for_active_skill` must supply one explicitly selected exact `task_spec` ref. The stored constraints list is the only authority for selectable auxiliary conditions; the global artifact board, summaries, and receipts do not substitute for that mission input.
- scientific_source_manifest and scientific_source_visible_historical are the authorities for sanitized source presence and visible record content.
- Explicitly resolved hypothesis_mind_map and hypothesis artifacts are optional public scientific context. Receipts or summaries do not replace stored content.
- Existing visible `auxiliary_condition` proxy formulas establish which stable
  auxiliary `target_id` values are already covered. Multiple final-KPI methods
  may legally share one final target and never participate in this condition
  deduplication.
- Held-out final-KPI values, raw audit logs, private evaluator results, and unpublished prose are not inputs.
- If no explicit condition exists, every condition is already covered, target identity is missing on a visible formula, or sanitized records are unavailable, return a bounded gap without publishing.

## Trigger examples

### Should select

- The accepted task lists thermal stability, removability, and solubility as soft conditions; sanitized records are available, and no auxiliary formula covers thermal stability yet.
- No auxiliary formula exists yet for one explicit uncovered task constraint. The immediate work is to design that source-bound formula for later sample search, while the final-KPI formula remains frozen and separate; per-record calculation is not the current work.

### Should not select

- A final-KPI proxy formula has been implemented and now needs private historical calibration and ranking; that belongs to `final-kpi-proxy-discovery`.
- The active work unit supplies no exact task_spec, or sanitized historical records are unavailable, so no condition can be selected and source-bound responsibly.

## Prompt and memory projection

- **C0:** accepted task goal, exact soft constraints, visibility limits, low-computation proxy boundary, and prohibition on hidden final-KPI values.
- **C1:** the active work unit and currently uncovered condition indices.
- **C2:** exact task and explicitly resolved public scientific context; existing formula refs and target identities; the final published formula.
- **C3:** unused. This skill does not create a durable observation or private evaluation.
- **C4:** sanitized historical records remain source-owned and are revealed only to the historical-grounding stage. Large source bodies remain behind source refs outside that call.
- **C5:** condition-selection result, P1 quantity ideas, P2 grounding, P3 formula core, focused P4 reviews, exact validator issues, and the one bounded local repair chain. C5 is cleared when the skill exits.
- **C6:** full prompts, raw model turns, route receipts, errors, and audit events remain external diagnostics and are never semantic input.

The condition-selection call receives the task goal, numbered uncovered conditions, and only a compact visible-source shape. It selects only a desired scientific property of the studied subject or proposed sample; proxy-quality, evidence, privacy, workflow, implementation-responsibility, and claim-boundary rules are ineligible. It returns selection_index and a bounded reason. Python maps the number back to exact task text and creates target_id; the model cannot rewrite either authority.

The reusable route then uses separate prompt templates:

1. P1 sees target meaning and public scientific context but no historical records.
2. P2 sees P1 output, sanitized records, source shape, and Materializer capability.
3. P3 sees grounded quantities plus target, compact public context, and compact evaluated history when present. It does not receive the raw record table or source-shape catalog again.
4. The shared route deepens only the frozen candidate's physical explanation.
5. P4 runs focused relationship, operationalization, and observability reviews.

### LLM call contracts

| Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
|---|---|---|---|---|---|---|---|
| `auxiliary-proxy` | `select-auxiliary-condition` | Exact C2 task, host-numbered uncovered conditions, and compact visible-source shape | Select one numbered task-authored auxiliary condition; never rewrite its text or identity | Existing `selection_index` and bounded `reason` | Index must resolve to exactly one uncovered condition | Common same-stage format repair only | Host target-id derivation and P1 route |
| shared `develop_proxy_formula` route | P1 first-principles quantity discovery | Exact selected target meaning and field-level public C2 projections; no historical records | Propose low-cost physically meaningful quantity directions, not a formula | Existing P1 candidate-quantity shape | Route JSON schema | One same-stage format repair when needed | P2 grounding |
| shared `develop_proxy_formula` route | P2 historical grounding | Accepted P1 result, sanitized C4 records, exact source shape, and declared Materializer capability | Bind viable quantities to exact visible inputs and plausible low-cost routes; exclude unsupported quantities | Existing grounded-quantity shape | Shape and exact source-path checks; P4 owns scientific route feasibility | One stage-local grounding repair | P3 formula authoring |
| shared `develop_proxy_formula` route | P3 formula authoring | Exact target, public context, and accepted P2 grounded quantities only | Compose one scalar formula without reviving excluded quantities or changing source methods | Existing formula-core shape | Formula syntax, declared-variable, grounding, direction, and shared-contract checks | One stage-local formula repair | Physical-property explanation deepening |
| shared scientific-content deepening route | Physical-property explanation deepening | Complete frozen C5 formula candidate, exact P2 grounding, and supplied public scientific assets | Deepen only existing explanatory fields; never change formula mathematics, target, direction, source binding, implementation contract, or non-text thresholds | Existing explanation fields merged into the same candidate | Existing formula contract plus exact frozen-field checks | One exact same-stage repair | P4 private reviews |
| shared `develop_proxy_formula` route | P4 relationship, operationalization, and observability reviews | Focused C5 candidate projections and the exact authority needed by each review | Detect only hard producer red lines; ordinary uncertainty remains in the reason | Three focused `{score, reason}` verdicts using only 0 or 4 | Exact binary score and non-empty reason | One complete-core repair only for score 0, followed by fresh reviews | Host-owned formula assembly and publication |

## Skill-local workflow

1. Resolve the exact task and optional public context only from the active work unit's explicit refs.
2. Inspect visible formula target identities and remove already-covered conditions from the numbered choices.
3. Ask one bounded model call to select a scientifically useful uncovered condition by number.
4. Mechanically map the number to exact constraint text and derive target_id as a stable hash of normalized exact text.
5. Call develop_proxy_formula with target_kind=auxiliary_condition. The route owns P1-P4, physical-explanation deepening, and their bounded local repairs.
6. Mechanically set formula identity and version 1, then validate the shared formula contract.
7. Publish one immutable proxy_formula_candidate with exact dependencies and immediately read back the returned ref.

No internal result names the next skill. Materialization, sample scoring, and later workflow choices remain dynamic planner decisions.

## Formal output and handoff

Publish the existing proxy_formula_candidate artifact. The approved target identity fields are:

- target_kind: exactly auxiliary_condition
- target_id: stable identifier mechanically derived from the exact selected task condition

All other formula fields use the same contract as `final-kpi-proxy-discovery`: formula identity/version, expression, selected quantities, input variables, source binding, historical variation evidence, scientific link, expected relation, limitations, claim boundary, validation criteria, and mechanical materialization contract.

The formal artifact depends on the exact task and public context refs actually supplied, plus the prepared source ref when the source manifest declares one. Read back the exact published ref before returning it. Materializer and multi-index Sample consume the stored formula, never an inline reconstruction.

For an auxiliary target, higher_proxy_higher_kpi means a larger proxy value better satisfies that auxiliary condition, while lower_proxy_higher_kpi means a smaller value better satisfies it. The legacy field and enum names do not change the target to the final KPI.

## Failure and repair

Selection output format receives the common bounded skill-stage repair. P2 and P3 structural or grounding defects stay inside the reusable route for one local repair. A P4 red-line score receives one complete-core repair and one re-review. Missing authority, exhausted conditions, ambiguous existing target identity, unavailable source data, or a remaining red line returns a precise gap or failure without publication.

This skill never repairs Materializer code, evaluates held-out final KPI, invents task conditions, silently chooses among duplicate target formulas, or changes another formula.

## Validation evidence

Structural validation must confirm summary/detail disclosure, required sections, trigger cases, workflow entrypoint, and absence of next-skill control. Deterministic tests must prove exact task-text selection, stable target identity, host-controlled target fields, P1 historical-data isolation, duplicate-target prevention, publication/readback, and no private evaluator call. A producer-to-consumer replay must show Materializer consuming the exact auxiliary formula ref. The smallest real-model test selects one condition and publishes one formula; it does not prove materialization or multi-index sample improvement.
