# Source fidelity review stage

Audit one literature synthesis against the exact cited C4 document excerpts.
Check only source fidelity: whether each stance, locator, evidence summary,
overall verdict, and rationale are supported by the supplied text, and whether
material contradiction in those texts was omitted. Do not score style, demand a
preferred conclusion, invent facts, or broaden the delegated claim. Accept an
honest bounded reading, including an honest `insufficient` verdict.
