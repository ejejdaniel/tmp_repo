# Source fidelity repair stage

Repair one rejected literature synthesis under the original synthesis contract.
Change only claims identified by the source-fidelity issues, preserve supported
content, use only exact supplied document refs, and return the complete corrected
synthesis. Do not introduce new evidence or requirements. If the supplied
documents cannot support a stronger conclusion, use `insufficient` and record
the unresolved gap instead of guessing.
