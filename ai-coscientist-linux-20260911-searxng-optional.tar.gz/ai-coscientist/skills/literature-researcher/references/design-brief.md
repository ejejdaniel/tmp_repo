# Literature Researcher Design Brief

## Classification

`literature-researcher` is a production skill because the coordinator may
dynamically delegate one scientific evidence question and receive one formal
artifact. Its bounded iterative search is a skill-local workflow. SearXNG,
document retrieval, document paging, and the private knowledge-center adapter
are routes or domain helpers and have no planner authority.

## Responsibility and prohibited behavior

The skill owns source discovery, bounded retrieval, source-grounded claim
assessment, contradiction recording, and publication of one evidence artifact.
It must not create scientific methods, alter an input claim, choose the next
production skill, score the final KPI, or make a Final LCA release decision.

## Input authorities

| Input | Authority | Selection | Missing behavior |
| --- | --- | --- | --- |
| Delegated work | Exact non-persisted `active_work_unit` | Common current graph node | Use explicit objective/input claim or return bounded gap. |
| Claim artifacts | Exact `resolved_inputs_for_active_skill` stored content | Current node input refs and produced refs | Never use global latest. |
| Public leads | SearXNG JSON response | LLM natural-language query and source group | Empty/unset URL disables the route and its action; configured service failures remain observations. |
| Public evidence | Exact C4 document after bounded fetch/extraction | Exact prior `result_id` | Lead remains uncitable. |
| Private evidence | Isolated adapter's normalized markdown and metadata stored in C4 | LLM natural-language question | Missing endpoint/mock is unavailable. |

## Formal output and consumers

The sole formal output is `literature_claim_evidence`. Mind-map, hypothesis,
formula, reviewer, Final LCA, and report skills may consume it only when the main
graph gives them its exact ref. No automatic global injection is performed.

## Identity transition

Every publication is immutable. New retrieval or a revised verdict creates a
new artifact ref even for the same claim. Downstream evidence remains bound to
the exact ref it consumed; no semantic aliasing or latest-of-kind fallback is
allowed.

## C0-C6 memory and metabolism

| Class | Unique content | Prompt exposure and metabolism |
| --- | --- | --- |
| C0 | Objective and evaluation framing supplied by the host | Claim framing sees the required subset; the skill never rewrites it. |
| C1 | Current active work unit and this invocation's fixed quota | Framing and action selection see bounded projections; state expires when control returns. |
| C2 | Exact input claim artifacts and the published `literature_claim_evidence` | Inputs are resolved by explicit ref; output is immutable and read back before completion. |
| C3 | Unused by the current bounded invocation | Temporary searches do not overwrite the shared wiki. Cross-invocation digests are outside this pilot. |
| C4 | Exact fetched source files, normalized text, and metadata | Stays in workspace; synthesis and review receive exact refs plus allocated excerpts. |
| C5 | Claim frame, candidate index, document manifest, action ledger, synthesis, review issues, and one repair | Each stage receives only the subset it needs; all local state disappears when the invocation ends. |
| C6 | Raw search/fetch/model events and prompt snapshots | Append-only diagnostics; never semantic prompt input. |

The workflow itself performs progressive disclosure because common
`disclosure.py` is not involved after a workflow entrypoint has been selected.
Every model stage loads one directly linked instruction page. This is still one
C0-C6 system: stage pages select prompt inputs but do not create storage.

## Prompt projection budgets

- Action selection sees at most the latest 20 candidate leads, 12 fetched
  documents, six recent actions, exact visible refs, and bounded excerpts.
- Synthesis sees every evidence-ready document ref. A shared excerpt budget is
  divided across documents instead of blindly cutting the serialized JSON.
- Fidelity review sees only documents cited by the synthesis.
- Structural and fidelity repair see the complete rejected synthesis, exact
  issues, and the same authoritative evidence projection as the original stage.

If the bounded item projections still exceed their declared stage budget, the
workflow fails explicitly. It does not emit malformed partial JSON or silently
replace stored authority with a truncated copy.

## Route interfaces

`AI_COSCIENTIST_SEARXNG_URL` is the public-search switch: a nonempty URL enables
it, while empty or unset disables it. The workflow checks the host's visible
route registry before offering search actions, without making a probe request.
Private search and C4 document readback remain independent of SearXNG. Source
configuration is read when the workflow host starts; restart the CLI after
changing the environment.

- `literature_public_search(query, why, source_group, limit)` returns bounded
  candidate leads and unresponsive engines. It never returns evidence.
- `literature_document_fetch(result_id, why)` fetches exactly one cached lead,
  rejects private-network targets and unsafe redirects, bounds bytes, extracts
  static HTML/Markdown/text/PDF, rejects short HTML without document-level
  metadata as a non-substantive access/error page, and writes C4. A credible
  indexed scholarly abstract remains the bounded fallback.
- `literature_document_read(document_ref, char_offset, char_limit)` pages one
  exact C4 normalized document.
- `literature_private_search(question, why, resource_url?, permission_hint?)`
  delegates all private API request/normalization behavior to the standalone
  adapter and stores a successful normalized response in C4.

## Failure ownership

Network, parser, access, size, and unavailable-source errors stay in the skill
as retrieval observations. Model shape and action-reference errors receive one
local repair. Source-fidelity rejection receives one local synthesis repair.
Absent evidence is a valid `insufficient` artifact. Missing claim authority is a
bounded gap returned to the coordinator. Only the coordinator may change the
graph or choose another research route.
