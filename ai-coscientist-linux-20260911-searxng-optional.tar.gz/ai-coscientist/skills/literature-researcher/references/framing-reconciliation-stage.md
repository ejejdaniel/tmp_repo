# Exploratory framing reconciliation stage

Reconcile the independent P0 claim framing with the shared research assets that
are now visible. Preserve a useful independent question when it remains valid.
Use exact shared artifacts to clarify the assigned scientific subject, expose a
known contradiction, avoid duplicating an already answered question, or sharpen
the evidence gap. Do not turn prior work into proof and do not replace the
delegated task with a more convenient claim.

Return exactly one claim and one natural-language research question that can
retrieve evidence both for and against it. Select `claim_source_refs` only from
the exact refs below whose stored content actually defines the final reconciled
claim. The host owns search, provenance, later synthesis, and publication.
