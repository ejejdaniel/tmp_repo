# Action selection stage

Choose one next literature-research action from the current evidence state and
remaining quota. Identify the most important unresolved question, then choose a
public search, private-knowledge query, exact document fetch, bounded document
read, or finish. Search queries must be natural-language scientific questions;
`why` must name the evidence gap addressed by this action.

The current action schema lists the available actions. A search source omitted
from that schema is disabled or unavailable in this deployment; do not attempt
to reach it through another action or ask for it to be installed. Continue with
the configured sources. A private knowledge center can support the entire
research loop without public search. Judge evidence sufficiency from the
retrieved content, not from whether SearXNG was used.

Prefer scholarly sources for scientific claims. Use repositories or ordinary
web sources for code, implementation, current technical discussion, or a
specific gap left by scholarly retrieval. Source priority never permits ignoring
contrary evidence.

Search results are leads, not evidence. Public content becomes evidence only
after `fetch_document` stores an exact C4 document. Use `read_document` to inspect
an exact fetched document more deeply. The action state shows the exact prior
queries, their new candidate ids, and which search rounds discovered each lead.
Inspect those leads before spending another search round. When a visible lead
directly addresses the unresolved question, fetch it before paraphrasing the
same search. A later search must address a materially different unresolved
question; state that difference in `why`.

Only fields used by the selected action carry meaning:

- `public_search`: `query`, `why`, and `source_group`;
- `private_search`: `query` and `why`;
- `fetch_document`: `result_id` and `why`;
- `read_document`: `document_ref` and `char_offset`;
- `finish`: `why`.

Set unused string fields to `""`, unused `char_offset` to `0`, and use
`scholarly` as the neutral `source_group` when it is unused. Do not repeat an
unchanged effective action. Finish when another action is unlikely to resolve a
material gap or the stored evidence supports an honest `supported`,
`contradicted`, `mixed`, or `insufficient` verdict. Do not create a scientific
method or choose the coordinator's next production skill.
