# Claim framing stage

Frame exactly one claim for bounded literature research from the active work
unit, objective, and exact resolved artifacts. Preserve the delegated scientific
meaning; do not invent a new hypothesis, formula, task, or release decision.

Write one natural-language research question that could locate evidence both for
and against the claim. Select `claim_source_refs` only from the exact refs
supplied below and only when their stored content defines the delegated claim.
The host owns retrieval, provenance, artifact identity, and later judgment.
