# Synthesis structural repair stage

Repair the rejected synthesis only for the listed structural issues. Preserve
its supported scientific interpretation and use only exact supplied document
refs. Return one complete synthesis under the original synthesis contract. Do
not add evidence, strengthen the verdict, or introduce new requirements. If the
available structure cannot support a non-insufficient verdict, return an honest
`insufficient` result and record the gap.
