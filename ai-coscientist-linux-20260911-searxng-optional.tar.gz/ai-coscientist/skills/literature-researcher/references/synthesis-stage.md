# Evidence synthesis stage

Judge the delegated claim only from the exact evidence-ready C4 document
excerpts supplied below. Internal model knowledge and search-result snippets are
not evidence. Choose `supported`, `contradicted`, `mixed`, or `insufficient`.
`mixed` requires material evidence in more than one direction; `insufficient` is
correct when retrieved material cannot answer the claim.

For each cited document, output only its exact `document_ref`, semantic stance,
a locator usable within the stored text, and a concise evidence summary. The host
projects citation metadata from the stored document. State unresolved gaps and
do not overstate an abstract beyond its scope.
