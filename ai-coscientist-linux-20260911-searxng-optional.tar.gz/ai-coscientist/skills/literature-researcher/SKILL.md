---
name: literature-researcher
description: Produces one literature_claim_evidence through bounded retrieval and fact checking. Requires a research subject plus accessible sources. Boundary: no hypotheses, formulas, plans, or release decisions.
estimated_complexity: high
accepts_research_mode: true
---

# Literature Researcher

## Responsibility and boundary

Own one bounded evidence investigation for one delegated scientific claim. Ask
follow-up questions, retrieve source documents, compare support and contradiction,
and publish an auditable `literature_claim_evidence` result, including an honest
`insufficient` result when evidence remains unavailable.

The skill does not create or revise the main graph, hypothesis, mind map, proxy
formula, materialization, sample, review score, or Final LCA decision. It never
chooses the coordinator's next skill. Search snippets are leads rather than
evidence; only an exact C4 document produced by a retrieval route may be cited.

## Research modes

Autonomous work frames a useful evidence question inside the active node;
commissioned work preserves the assigned claim or gap and its exact refs.
Deepen mode frames the question with all selected public research assets.
Explore mode first frames an independent P0 question without non-commissioned
shared research, then restores those assets in one framing-reconciliation stage
before search begins. Retrieval, synthesis, and source-fidelity review remain
the same bounded workflow in all four combinations.
Before invocation, common classifies the node-scoped candidate refs and derives
the final exact inputs. Task/source authority remains visible in exploration;
this skill preserves the resulting commission refs instead of reclassifying them.

## Entry conditions and authority

- The host supplies the exact current `active_work_unit` as a non-persisted C1
  projection. An explicit objective or exact resolved artifact may additionally
  define the delegated claim.
- `resolved_inputs_for_active_skill` supplies exact C2 stored content. The skill
  uses only these refs as formal `depends_on`; it never looks up a global latest
  artifact.
- `literature_public_search` queries the configured SearXNG instance. An empty
  or unset `AI_COSCIENTIST_SEARXNG_URL` disables it: the host omits this route
  and the workflow omits public search from its action choices. Private-only
  research is supported; disabled public search consumes no search quota and
  is not itself an evidence gap. Scholarly sources are preferred; repositories and ordinary web
  sources remain available for code, implementation, current discussion, and
  specific gaps that scholarly retrieval does not answer.
- `literature_document_fetch` turns one exact prior search result into a C4
  document. Static HTML, Markdown, text, and PDF are supported; blocked,
  paywalled, dynamic-only, non-substantive access/error HTML, oversized, or
  unparseable content remains a lead or falls back to a credible indexed abstract.
- `literature_private_search` uses either the isolated private API adapter or an
  explicit mock file configured by `AI_COSCIENTIST_PRIVATE_KNOWLEDGE_MOCK`.
  Missing configuration is reported as unavailable and never fabricates content.
- If no active work unit, objective, or exact input defines a claim, return a
  bounded gap without publishing a pretend result.

## Trigger examples

### Should select

- The active hypothesis claims that a proposed interfacial mechanism suppresses
  the observed process; find independent literature that supports or contradicts
  that exact mechanism and publish the evidence trail.
- Verify whether the causal assertion in the supplied mind-map branch has public
  or private-source support, including contrary findings and unresolved gaps.

### Should not select

- Invent a new low-cost quantitative formula and rank it against the final KPI;
  that belongs to Final-KPI Proxy Discovery.
- Fact-check a claim that has not been stated by the objective, active work unit,
  or any exact visible artifact; the coordinator must first define the claim.

## Prompt and memory projection

The skill uses the common memory classes rather than a private memory system:

| Class | Content and unique authority | Retention and prompt use |
| --- | --- | --- |
| C0 | Objective and evaluation summary | Stable mission framing; no search results are copied here. |
| C1 | Exact active work unit plus the local four-round search quota | Non-persisted control projection; quota ends with this invocation. |
| C2 | One formal `literature_claim_evidence` artifact | Immutable result consumed by explicit ref. |
| C3 | Unused by the current bounded invocation | The skill does not overwrite shared compressible knowledge with its temporary search ledger. A future cross-invocation literature digest would require its own approved consumer and lifecycle. |
| C4 | Raw fetched file, normalized readable document, and exact metadata | Workspace authority; prompts receive bounded excerpts and refs only. |
| C5 | Skill-local copy of the caller-owned research-mode card, current candidates, fetched-document manifest, action ledger, synthesis, and local repair | The authoritative mode card remains on the active C1 LOOP step. The C5 copy and other local items are projected only to the stage that needs them and cleared when the skill invocation ends. |
| C6 | Raw HTTP events and common model prompt/response records | Append-only diagnostics; never semantic model input. |

The active work unit, exact claim artifacts, C5 action ledger, candidate leads,
and document excerpts are projected only into the stage that needs them. The C5
ledger retains each effective action input, outcome, and newly discovered lead;
candidate projections retain bounded source metadata and discovery-round
provenance. Full C4 documents remain in workspace. C6 never enters a production
prompt. Candidate and document projections are assembled item by item so exact
visible refs remain valid JSON; the workflow does not cut a serialized context
in the middle.

### LLM call contracts

| Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `resolve-research-mode` | Resolve the caller-owned research mode | Exact C1 structured research-mode card plus exact resolved C2 refs | Mechanically validate and copy the caller-owned mode card; old checkpoints alone use the compatibility classifier | Private C5 `{task_source, research_strategy, commissioned_input_refs}` mode card | Existing closed three-field schema and exact-ref subset | No semantic repair for a structured card | Remaining literature stages |
| `frame-delegated-literature-claim` | Isolate one claim and research question | C0 objective, exact C1 work unit, exact C2 inputs | Preserve delegated meaning and select visible source refs | Claim, question, exact source refs | Schema plus visible-ref subset | Common one-pass format repair | Search loop |
| `reconcile-exploratory-literature-framing` | Reconcile an independent P0 framing before retrieval | C5 independent framing plus the C2 shared research refs withheld from the first draft | Preserve a useful independent question while correcting duplication, contradiction, or an imprecise delegated gap | Same claim, question, and exact source-ref shape | Same framing schema and visible-ref subset | Common one-pass format repair | Search loop |
| `choose-literature-action-*` | Choose one bounded next research action | Claim, C1 quota, C5 leads/docs/exact recent action inputs and outcomes | Ask, fetch, read, or finish | One action card | Action-specific refs, quota, and no repeated effective action | One narrow action repair | Domain routes |
| `synthesize-literature-claim-evidence` | Judge the claim from stored evidence | Claim and bounded excerpts from exact C4 docs | Assign verdict, stance, locator, summary, and gaps | Internal synthesis card | Exact document refs; non-insufficient verdict requires evidence | One structural repair | Fidelity review |
| `review-literature-source-fidelity` | Check citation fidelity only | Synthesis plus exact cited C4 excerpts | Check support, contradiction, locator, and overclaim | Accepted, issues, reason | Schema | One synthesis repair, then one recheck | Publication mapping |
| `repair-literature-synthesis-structure` | Repair a structurally unusable synthesis | Original synthesis contract, exact C4 excerpts, and exact structural issues | Correct refs, duplicates, or evidence/verdict consistency only | Complete internal synthesis card | Same synthesis validator | No second structural repair | Fidelity review or honest insufficient result |
| `repair-literature-source-fidelity` | Repair a source-fidelity rejection | Original synthesis contract, exact cited C4 excerpts, and review issues | Remove overclaim or correct stance, locator, summary, verdict, and gaps | Complete internal synthesis card | Same synthesis validator, then one fidelity recheck | No second semantic repair | Publication mapping or honest insufficient result |

The workflow performs progressive disclosure through stage-specific instruction
pages rather than a second memory system:

- [`references/framing-stage.md`](references/framing-stage.md)
- [`references/framing-reconciliation-stage.md`](references/framing-reconciliation-stage.md)
- [`references/action-selection-stage.md`](references/action-selection-stage.md)
- [`references/synthesis-stage.md`](references/synthesis-stage.md)
- [`references/structural-repair-stage.md`](references/structural-repair-stage.md)
- [`references/fidelity-review-stage.md`](references/fidelity-review-stage.md)
- [`references/fidelity-repair-stage.md`](references/fidelity-repair-stage.md)

Each model call receives one of these pages and only the C0-C5 projection named
by its call contract. Moving instructions into pages does not change the formal
output or authority boundary.

Transport metadata is not model-authored. The workflow projects title, URL,
authors, publication date, DOI, site, and source kind from the exact stored C4
document into the public artifact.

## Skill-local workflow

The fixed internal workflow is:

```text
frame one delegated claim
-> dynamically choose up to four semantic search rounds
-> fetch/read exact candidate documents as needed
-> synthesize one bounded verdict
-> check source fidelity and repair once when needed
-> publish and immediately read back one formal artifact
```

Public search, private search, fetch, and read are not a fixed order. The local
model chooses among them from current evidence and remaining quota. Document
fetching is bounded and does not recursively crawl links. A repeated effective
action is identified only by the fields that the selected route consumes, so
rewriting `why` or filling unused fields cannot disguise a duplicate. Raising
the quota is not a no-progress repair.

Detailed route and dataflow design is in
[`references/design-brief.md`](references/design-brief.md).

## Formal output and handoff

Publish exactly one `literature_claim_evidence` artifact per delegated claim:

```text
machine_payload:
  artifact_kind: literature_claim_evidence
  claim: string
  verdict: supported | contradicted | mixed | insufficient
  rationale: string
  evidence_items:
    - document_ref
      title
      url
      source_kind
      stance: supporting | contradicting | context
      locator
      evidence_summary
      authors[]
      published
      doi
      site
  unresolved_gaps[]
```

Original claim-defining artifact refs remain in existing `depends_on`. Exact C4
document refs are in existing `trace_refs`. Markdown is a human rendering, not a
second content authority. The workflow immediately reads the exact published ref
and verifies kind, payload, dependencies, and trace refs before completion.

## Failure and repair

- Model output shape errors use the common one-pass local format repair.
- An invalid or repeated action receives one narrow action repair containing the
  exact issue; it does not restart the full skill prompt.
- Source-fidelity disagreement receives one bounded synthesis repair using the
  same documents and contract. A second rejection becomes an honest
  `insufficient` result rather than invented support.
- Missing SearXNG, private API, mock file, PDF parser, open content, or reachable
  static page is recorded as a source gap. The skill may search another source
  within quota; it may not claim the missing source was read.
- A missing claim context returns `bounded_gap`. Scientific route changes belong
  to the coordinator and graph, not this workflow.

## Validation evidence

- Project skill validator: frontmatter, sections, workflow entrypoint, and linked
  reference integrity.
- Deterministic route tests: source-group request, snippets-as-leads, exact fetch,
  C4 paging, SSRF rejection, missing private configuration, and explicit mock
  normalization.
- Deterministic workflow replay: iterative queries, exact document refs,
  source-owned metadata, one artifact per claim, dependencies, trace refs, and
  readback.
- Workflow visibility test: all four literature routes are visible only to this
  skill.
- Small real test: one claim through local SearXNG and the configured model. It
  proves only this skill boundary, not the full scientific workflow.
