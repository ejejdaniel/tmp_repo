from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from ai_coscientist.domain.research_modes import (
    initial_research_inputs,
    reconciliation_projection,
    resolve_research_mode,
)


_MAX_SEARCH_ROUNDS = 4
_MAX_ACTIONS = 20
_SOURCE_GROUPS = ("scholarly", "repositories", "web")
_VERDICTS = ("supported", "contradicted", "mixed", "insufficient")
_STANCES = ("supporting", "contradicting", "context")
_ACTION_CONTEXT_LIMIT = 32_000
_EVIDENCE_CONTEXT_LIMIT = 64_000
_FRAMING_INPUT_CONTEXT_LIMIT = 64_000
_STAGE_REFERENCE_DIR = Path(__file__).resolve().parent / "references"
_STAGE_PROMPT_FILES = {
    "framing": "framing-stage.md",
    "framing_reconciliation": "framing-reconciliation-stage.md",
    "action_selection": "action-selection-stage.md",
    "synthesis": "synthesis-stage.md",
    "structural_repair": "structural-repair-stage.md",
    "fidelity_review": "fidelity-review-stage.md",
    "fidelity_repair": "fidelity-repair-stage.md",
}


def run(payload: dict[str, Any], runtime: Any) -> dict[str, Any]:
    """Research one delegated claim and publish one source-grounded result."""
    active_work_unit = payload.get("active_work_unit")
    resolved_inputs = _resolved_inputs(payload.get("resolved_inputs"))
    research_mode = resolve_research_mode(
        payload,
        runtime,
        resolved_inputs,
        skill_id="literature-researcher",
    )
    initial_inputs = initial_research_inputs(
        research_mode,
        resolved_inputs,
        shared_artifact_kinds=(
            "hypothesis_mind_map",
            "hypothesis",
            "hypothesis_leaderboard",
            "proxy_formula_candidate",
            "proxy_formula_leaderboard",
            "scientific_method_review",
            "final_lca_judgment",
            "literature_claim_evidence",
        ),
        always_visible_artifact_kinds=("task_spec", "prepared_source_data"),
    )
    objective = str(payload.get("objective") or "").strip()
    if not isinstance(active_work_unit, Mapping) and not objective and not resolved_inputs:
        return {
            "status": "bounded_gap",
            "reason": "literature_research_claim_context_missing",
            "summary": "No active work unit, explicit objective, or exact input ref defines a claim to research.",
        }

    initial_source_refs = _artifact_refs(initial_inputs)
    framing = runtime.generate_json(
        _stage_prompt("framing"),
        _framing_context(
            objective=objective,
            active_work_unit=active_work_unit,
            resolved_inputs=initial_inputs,
            research_mode=research_mode.prompt_projection(),
        ),
        purpose="frame-delegated-literature-claim",
        schema=_framing_schema(initial_source_refs),
    )
    _validated_source_refs(
        framing.get("claim_source_refs"),
        allowed_refs=initial_source_refs,
    )
    source_refs = _artifact_refs(resolved_inputs)
    if (
        research_mode.research_strategy == "explore"
        and set(source_refs) != set(initial_source_refs)
    ):
        framing = runtime.generate_json(
            _stage_prompt("framing_reconciliation"),
            _framing_reconciliation_context(
                objective=objective,
                active_work_unit=active_work_unit,
                independent_framing=framing,
                resolved_inputs=resolved_inputs,
                research_mode=reconciliation_projection(research_mode),
            ),
            purpose="reconcile-exploratory-literature-framing",
            schema=_framing_schema(source_refs),
        )
    claim = str(framing["claim"]).strip()
    research_question = str(framing["research_question"]).strip()
    claim_source_refs = _validated_source_refs(
        framing.get("claim_source_refs"), allowed_refs=source_refs
    )

    candidates: dict[str, dict[str, Any]] = {}
    documents: dict[str, dict[str, Any]] = {}
    observations: list[dict[str, Any]] = []
    attempted_actions: set[str] = set()
    search_rounds = 0
    previous_issue = ""

    for action_index in range(_MAX_ACTIONS):
        action = _choose_action(
            runtime,
            claim=claim,
            research_question=research_question,
            search_rounds=search_rounds,
            action_index=action_index,
            candidates=candidates,
            documents=documents,
            observations=observations,
            previous_issue=previous_issue,
            attempted_actions=attempted_actions,
        )
        action_name = str(action["action"])
        if action_name == "finish":
            break

        action_key = _action_key(action)
        attempted_actions.add(action_key)
        try:
            result = _execute_action(
                runtime,
                action=action,
                candidates=candidates,
                documents=documents,
            )
        except Exception as exc:
            result = {
                "status": "route_error",
                "reason": f"{type(exc).__name__}: {exc}",
            }
        if action_name in {"public_search", "private_search"}:
            search_rounds += 1
        known_candidate_ids = set(candidates)
        _merge_action_result(
            action=action,
            result=result,
            candidates=candidates,
            documents=documents,
            search_round=(
                search_rounds
                if action_name in {"public_search", "private_search"}
                else None
            ),
        )
        new_candidate_ids = tuple(
            result_id
            for result_id in candidates
            if result_id not in known_candidate_ids
        )
        observations.append(
            {
                "action": action_name,
                "query": str(action.get("query") or "")[:2_000],
                "purpose": str(action.get("why") or "")[:1_000],
                "source_group": str(action.get("source_group") or "")[:120],
                "result_id": str(action.get("result_id") or "")[:500],
                "status": str(result.get("status") or "unknown"),
                "reason": str(result.get("reason") or "")[:2_000],
                "result_count": len(result.get("results") or ()),
                "document_ref": str(result.get("document_ref") or ""),
                "char_offset": int(action.get("char_offset") or 0),
                "search_round": (
                    search_rounds
                    if action_name in {"public_search", "private_search"}
                    else None
                ),
                "new_candidate_ids": new_candidate_ids,
            }
        )
        previous_issue = str(result.get("reason") or "").strip()
    evidence_documents = {
        ref: record
        for ref, record in documents.items()
        if bool(record.get("evidence_ready"))
    }
    if evidence_documents:
        synthesis = _synthesize(
            runtime,
            claim=claim,
            research_question=research_question,
            documents=evidence_documents,
            observations=observations,
        )
        synthesis = _repair_structural_synthesis(
            runtime,
            claim=claim,
            research_question=research_question,
            synthesis=synthesis,
            documents=evidence_documents,
            observations=observations,
        )
        review = _review_source_fidelity(
            runtime,
            claim=claim,
            synthesis=synthesis,
            documents=evidence_documents,
        )
        if not bool(review["accepted"]):
            synthesis = _repair_source_fidelity(
                runtime,
                claim=claim,
                research_question=research_question,
                synthesis=synthesis,
                documents=evidence_documents,
                observations=observations,
                issues=list(review["issues"]),
            )
            synthesis = _repair_structural_synthesis(
                runtime,
                claim=claim,
                research_question=research_question,
                synthesis=synthesis,
                documents=evidence_documents,
                observations=observations,
            )
            review = _review_source_fidelity(
                runtime,
                claim=claim,
                synthesis=synthesis,
                documents=evidence_documents,
            )
        if not bool(review["accepted"]):
            synthesis = _insufficient_synthesis(
                title=str(synthesis.get("title") or "Literature evidence review"),
                issues=list(review["issues"]),
            )
    else:
        review = {
            "accepted": True,
            "issues": [],
            "reason": "No evidence-ready documents were used.",
        }
        synthesis = _insufficient_synthesis(
            title="Literature evidence unavailable",
            issues=_search_gaps(observations),
        )

    machine_payload = _machine_payload(
        claim=claim,
        synthesis=synthesis,
        documents=evidence_documents,
    )
    trace_refs = tuple(
        item["document_ref"] for item in machine_payload["evidence_items"]
    )
    markdown = _render_markdown(machine_payload)
    summary = (
        f"{machine_payload['verdict']}: {machine_payload['rationale']}"
    )[:800]
    artifact_id = "literature-claim-" + hashlib.sha256(
        claim.encode("utf-8")
    ).hexdigest()[:16]
    receipt = runtime.publish_artifact(
        artifact_kind="literature_claim_evidence",
        artifact_id=artifact_id,
        title=str(synthesis["title"]),
        markdown=markdown,
        summary=summary,
        status="proposed",
        machine_payload=machine_payload,
        depends_on=claim_source_refs,
        trace_refs=trace_refs,
        self_review={
            "accepted": bool(review["accepted"]),
            "issues": list(review["issues"]),
            "reason": str(review.get("reason") or ""),
        },
    )
    artifact_ref = str(receipt["artifact_ref"])
    stored = runtime.read_artifact(artifact_ref)
    _validate_readback(
        stored,
        machine_payload=machine_payload,
        depends_on=claim_source_refs,
        trace_refs=trace_refs,
    )
    return {
        "status": "complete",
        "artifact_ref": artifact_ref,
        "summary": summary,
    }


def _stage_prompt(stage: str) -> str:
    filename = _STAGE_PROMPT_FILES.get(stage)
    if filename is None:
        raise ValueError(f"literature_stage_prompt_unknown:{stage}")
    path = _STAGE_REFERENCE_DIR / filename
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        raise ValueError(f"literature_stage_prompt_empty:{stage}")
    return text


def _framing_context(
    *,
    objective: str,
    active_work_unit: Any,
    resolved_inputs: Sequence[Mapping[str, Any]],
    research_mode: Mapping[str, Any],
) -> str:
    return (
        "Objective (C0):\n"
        + objective
        + "\n\nResearch mode (skill-local C5):\n"
        + _bounded_json(research_mode, 4_000)
        + "\n\nActive work unit (non-persisted C1 projection):\n"
        + _bounded_json(active_work_unit, 12_000)
        + "\n\nExact resolved artifacts (C2 stored content):\n"
        + _framing_inputs_context(resolved_inputs)
    )


def _framing_reconciliation_context(
    *,
    objective: str,
    active_work_unit: Any,
    independent_framing: Mapping[str, Any],
    resolved_inputs: Sequence[Mapping[str, Any]],
    research_mode: Mapping[str, Any],
) -> str:
    return (
        "Objective (C0):\n"
        + objective
        + "\n\nActive work unit (non-persisted C1 projection):\n"
        + _bounded_json(active_work_unit, 12_000)
        + "\n\nResearch mode transition (skill-local C5):\n"
        + _bounded_json(research_mode, 4_000)
        + "\n\nIndependent P0 framing (skill-local C5):\n"
        + _bounded_json(independent_framing, 8_000)
        + "\n\nExact resolved artifacts now visible for reconciliation (C2):\n"
        + _framing_inputs_context(resolved_inputs)
    )


def _framing_schema(source_refs: Sequence[str]) -> dict[str, Any]:
    ref_schema: dict[str, Any] = {"type": "string"}
    if source_refs:
        ref_schema["enum"] = list(source_refs)
    return {
        "type": "object",
        "properties": {
            "claim": {"type": "string", "minLength": 1, "maxLength": 4_000},
            "research_question": {
                "type": "string",
                "minLength": 3,
                "maxLength": 2_000,
            },
            "claim_source_refs": {
                "type": "array",
                "items": ref_schema,
                "maxItems": len(source_refs),
            },
        },
        "required": ["claim", "research_question", "claim_source_refs"],
        "additionalProperties": False,
    }


def _choose_action(
    runtime: Any,
    *,
    claim: str,
    research_question: str,
    search_rounds: int,
    action_index: int,
    candidates: Mapping[str, Mapping[str, Any]],
    documents: Mapping[str, Mapping[str, Any]],
    observations: Sequence[Mapping[str, Any]],
    previous_issue: str,
    attempted_actions: set[str],
) -> dict[str, Any]:
    allowed_actions = ["fetch_document", "read_document", "finish"]
    if search_rounds < _MAX_SEARCH_ROUNDS:
        allowed_actions[:0] = [
            action for action, route in (
                ("public_search", "literature_public_search"),
                ("private_search", "literature_private_search"),
            )
            if runtime.has_route(route)
        ]
    context = _action_context(
        claim=claim,
        research_question=research_question,
        search_rounds=search_rounds,
        candidates=candidates,
        documents=documents,
        observations=observations,
        previous_issue=previous_issue,
    )
    schema = _action_schema(allowed_actions)
    issues: list[str] = []
    for repair_index in range(2):
        user_prompt = context
        if issues:
            user_prompt += (
                "\n\nPrevious action was structurally unusable:\n- "
                + "\n- ".join(issues)
                + "\nReturn a different complete action using the same contract."
            )
        action = runtime.generate_json(
            _stage_prompt("action_selection"),
            user_prompt,
            purpose=(
                f"choose-literature-action-{action_index + 1}"
                if repair_index == 0
                else f"repair-literature-action-{action_index + 1}"
            ),
            schema=schema,
        )
        issues = _action_issues(
            action,
            search_rounds=search_rounds,
            candidates=candidates,
            documents=documents,
            attempted_actions=attempted_actions,
        )
        if str(action.get("action")) not in allowed_actions:
            issues.insert(0, "Selected action is not available in the current action schema.")
        if not issues:
            return action
    return {
        "action": "finish",
        "query": "",
        "why": "Repeated action payload could not be repaired locally.",
        "source_group": "scholarly",
        "result_id": "",
        "document_ref": "",
        "char_offset": 0,
    }


def _action_context(
    *,
    claim: str,
    research_question: str,
    search_rounds: int,
    candidates: Mapping[str, Mapping[str, Any]],
    documents: Mapping[str, Mapping[str, Any]],
    observations: Sequence[Mapping[str, Any]],
    previous_issue: str,
) -> str:
    visible_candidates = list(candidates.values())[-20:]
    candidate_excerpt_limit = _per_item_excerpt_limit(
        len(visible_candidates), total=3_000, minimum=80, maximum=300
    )
    candidate_projection = [
        {
            "result_id": str(item.get("result_id") or "")[:120],
            "title": str(item.get("title") or "")[:220],
            "abstract_excerpt": str(item.get("abstract") or "")[
                :candidate_excerpt_limit
            ],
            "source_kind": str(item.get("source_kind") or "")[:80],
            "url": str(item.get("url") or "")[:240],
            "site": str(item.get("site") or "")[:100],
            "published": str(item.get("published") or "")[:60],
            "doi": str(item.get("doi") or "")[:120],
            "engines": _prompt_string_list(
                item.get("engines"), maximum=4, item_limit=40
            ),
            "credible_abstract": bool(item.get("credible_abstract")),
            "discovered_in_search_rounds": _prompt_integer_list(
                item.get("_search_rounds"), maximum=4
            ),
        }
        for item in visible_candidates
    ]
    visible_documents = list(documents.items())[-12:]
    document_excerpt_limit = _per_item_excerpt_limit(
        len(visible_documents), total=4_200, minimum=200, maximum=700
    )
    document_projection = [
        {
            "document_ref": ref,
            "metadata": _prompt_metadata(item.get("metadata")),
            "content_excerpt": str(item.get("content_preview") or "")[
                :document_excerpt_limit
            ],
        }
        for ref, item in visible_documents
    ]
    recent_actions = [
        {
            "action": str(item.get("action") or "")[:80],
            "query": str(item.get("query") or "")[:2_000],
            "purpose": str(item.get("purpose") or "")[:240],
            "source_group": str(item.get("source_group") or "")[:120],
            "result_id": str(item.get("result_id") or "")[:500],
            "status": str(item.get("status") or "")[:120],
            "reason": str(item.get("reason") or "")[:400],
            "result_count": item.get("result_count"),
            "document_ref": str(item.get("document_ref") or "")[:500],
            "char_offset": item.get("char_offset"),
            "search_round": item.get("search_round"),
            "new_candidate_ids": _prompt_string_list(
                item.get("new_candidate_ids"), maximum=8, item_limit=120
            ),
        }
        for item in list(observations)[-6:]
    ]
    return _strict_json_projection(
        {
            "claim": claim,
            "research_question": research_question,
            "search_quota": {
                "used": search_rounds,
                "maximum": _MAX_SEARCH_ROUNDS,
            },
            "candidate_leads": candidate_projection,
            "evidence_ready_documents": document_projection,
            "recent_actions": recent_actions,
            "previous_issue": previous_issue[:1_000],
        },
        limit=_ACTION_CONTEXT_LIMIT,
        label="literature_action_context",
    )


def _action_schema(allowed_actions: Sequence[str]) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": list(allowed_actions)},
            "query": {"type": "string", "maxLength": 2_000},
            "why": {"type": "string", "maxLength": 2_000},
            "source_group": {"type": "string", "enum": list(_SOURCE_GROUPS)},
            "result_id": {"type": "string", "maxLength": 500},
            "document_ref": {"type": "string", "maxLength": 500},
            "char_offset": {"type": "integer", "minimum": 0},
        },
        "required": [
            "action",
            "query",
            "why",
            "source_group",
            "result_id",
            "document_ref",
            "char_offset",
        ],
        "additionalProperties": False,
    }


def _action_issues(
    action: Mapping[str, Any],
    *,
    search_rounds: int,
    candidates: Mapping[str, Mapping[str, Any]],
    documents: Mapping[str, Mapping[str, Any]],
    attempted_actions: set[str],
) -> list[str]:
    name = str(action.get("action") or "")
    issues: list[str] = []
    if name in {"public_search", "private_search"}:
        if search_rounds >= _MAX_SEARCH_ROUNDS:
            issues.append("search quota is exhausted")
        if len(str(action.get("query") or "").strip()) < 3:
            issues.append("query must contain the next natural-language question")
        if len(str(action.get("why") or "").strip()) < 3:
            issues.append("why must identify the evidence gap")
    elif name == "fetch_document":
        result_id = str(action.get("result_id") or "").strip()
        if result_id not in candidates:
            issues.append("result_id must name an exact visible candidate lead")
    elif name == "read_document":
        document_ref = str(action.get("document_ref") or "").strip()
        if document_ref not in documents:
            issues.append("document_ref must name an exact fetched document")
    elif name == "finish" and search_rounds == 0:
        issues.append("at least one source query must be attempted before finish")
    key = _action_key(action)
    if name != "finish" and key in attempted_actions:
        issues.append("unchanged action was already attempted")
    return issues


def _execute_action(
    runtime: Any,
    *,
    action: Mapping[str, Any],
    candidates: Mapping[str, Mapping[str, Any]],
    documents: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any]:
    name = str(action["action"])
    if name == "public_search":
        return runtime.call_route(
            "literature_public_search",
            {
                "query": str(action["query"]),
                "why": str(action["why"]),
                "source_group": str(action["source_group"]),
                "limit": 8,
            },
        )
    if name == "private_search":
        return runtime.call_route(
            "literature_private_search",
            {
                "question": str(action["query"]),
                "why": str(action["why"]),
            },
        )
    if name == "fetch_document":
        result_id = str(action["result_id"])
        if result_id not in candidates:
            raise ValueError(f"literature_candidate_not_visible:{result_id}")
        return runtime.call_route(
            "literature_document_fetch",
            {"result_id": result_id, "why": str(action["why"])},
        )
    if name == "read_document":
        document_ref = str(action["document_ref"])
        if document_ref not in documents:
            raise ValueError(f"literature_document_not_visible:{document_ref}")
        return runtime.call_route(
            "literature_document_read",
            {
                "document_ref": document_ref,
                "char_offset": int(action["char_offset"]),
                "char_limit": 8_000,
            },
        )
    raise ValueError(f"literature_action_unknown:{name}")


def _merge_action_result(
    *,
    action: Mapping[str, Any],
    result: Mapping[str, Any],
    candidates: dict[str, dict[str, Any]],
    documents: dict[str, dict[str, Any]],
    search_round: int | None,
) -> None:
    if str(action["action"]) == "public_search":
        for item in result.get("results") or ():
            if isinstance(item, Mapping):
                result_id = str(item.get("result_id") or "").strip()
                if result_id:
                    existing = candidates.get(result_id, {})
                    search_rounds = _prompt_integer_list(
                        existing.get("_search_rounds"), maximum=_MAX_SEARCH_ROUNDS
                    )
                    if search_round is not None and search_round not in search_rounds:
                        search_rounds.append(search_round)
                    candidates[result_id] = {
                        **existing,
                        **dict(item),
                        "_search_rounds": search_rounds,
                    }
    document_ref = str(result.get("document_ref") or "").strip()
    if document_ref and bool(result.get("evidence_ready")):
        existing = documents.get(document_ref, {})
        documents[document_ref] = {
            **existing,
            **dict(result),
        }
    if str(action["action"]) == "read_document" and document_ref in documents:
        current = documents[document_ref]
        page = str(result.get("content") or "")
        if page:
            current["content_preview"] = (
                str(current.get("content_preview") or "") + "\n" + page
            )[:12_000]


def _synthesize(
    runtime: Any,
    *,
    claim: str,
    research_question: str,
    documents: Mapping[str, Mapping[str, Any]],
    observations: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    return runtime.generate_json(
        _stage_prompt("synthesis"),
        _synthesis_context(
            claim=claim,
            research_question=research_question,
            documents=documents,
            observations=observations,
        ),
        purpose="synthesize-literature-claim-evidence",
        schema=_synthesis_schema(tuple(documents)),
    )


def _synthesis_context(
    *,
    claim: str,
    research_question: str,
    documents: Mapping[str, Mapping[str, Any]],
    observations: Sequence[Mapping[str, Any]],
) -> str:
    document_excerpt_limit = _per_item_excerpt_limit(
        len(documents), total=36_000, minimum=1_200, maximum=6_000
    )
    return _strict_json_projection(
        {
            "claim": claim,
            "research_question": research_question,
            "documents": [
                {
                    "document_ref": ref,
                    "metadata": _prompt_metadata(record.get("metadata")),
                    "content_excerpt": str(record.get("content_preview") or "")[
                        :document_excerpt_limit
                    ],
                }
                for ref, record in documents.items()
            ],
            "retrieval_notes": [
                {
                    "action": str(item.get("action") or "")[:80],
                    "status": str(item.get("status") or "")[:120],
                    "reason": str(item.get("reason") or "")[:600],
                    "document_ref": str(item.get("document_ref") or "")[:500],
                }
                for item in list(observations)[-8:]
            ],
        },
        limit=_EVIDENCE_CONTEXT_LIMIT,
        label="literature_synthesis_context",
    )


def _synthesis_schema(document_refs: Sequence[str]) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "title": {"type": "string", "minLength": 1, "maxLength": 240},
            "verdict": {"type": "string", "enum": list(_VERDICTS)},
            "rationale": {
                "type": "string",
                "minLength": 1,
                "maxLength": 5_000,
            },
            "evidence_assessments": {
                "type": "array",
                "maxItems": 16,
                "items": {
                    "type": "object",
                    "properties": {
                        "document_ref": {
                            "type": "string",
                            "enum": list(document_refs),
                        },
                        "stance": {"type": "string", "enum": list(_STANCES)},
                        "locator": {"type": "string", "maxLength": 1_000},
                        "evidence_summary": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 3_000,
                        },
                    },
                    "required": [
                        "document_ref",
                        "stance",
                        "locator",
                        "evidence_summary",
                    ],
                    "additionalProperties": False,
                },
            },
            "unresolved_gaps": {
                "type": "array",
                "maxItems": 20,
                "items": {"type": "string", "maxLength": 2_000},
            },
        },
        "required": [
            "title",
            "verdict",
            "rationale",
            "evidence_assessments",
            "unresolved_gaps",
        ],
        "additionalProperties": False,
    }


def _repair_structural_synthesis(
    runtime: Any,
    *,
    claim: str,
    research_question: str,
    synthesis: dict[str, Any],
    documents: Mapping[str, Mapping[str, Any]],
    observations: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    issues = _synthesis_issues(synthesis, document_refs=set(documents))
    if not issues:
        return synthesis
    repaired = runtime.generate_json(
        _stage_prompt("structural_repair"),
        _synthesis_context(
            claim=claim,
            research_question=research_question,
            documents=documents,
            observations=observations,
        )
        + "\n\nRejected synthesis:\n"
        + _json_text(synthesis)
        + "\n\nStructural issues:\n- "
        + "\n- ".join(issues),
        purpose="repair-literature-synthesis-structure",
        schema=_synthesis_schema(tuple(documents)),
        repair_call=True,
    )
    remaining = _synthesis_issues(repaired, document_refs=set(documents))
    if remaining:
        return _insufficient_synthesis(
            title=str(repaired.get("title") or "Literature evidence review"),
            issues=remaining,
        )
    return repaired


def _synthesis_issues(
    synthesis: Mapping[str, Any], *, document_refs: set[str]
) -> list[str]:
    assessments = synthesis.get("evidence_assessments")
    if not isinstance(assessments, list):
        return ["evidence_assessments must be a list"]
    seen: set[str] = set()
    issues: list[str] = []
    for item in assessments:
        if not isinstance(item, Mapping):
            issues.append("every evidence assessment must be an object")
            continue
        ref = str(item.get("document_ref") or "")
        if ref not in document_refs:
            issues.append(f"unknown document_ref: {ref}")
        if ref in seen:
            issues.append(f"duplicate document_ref: {ref}")
        seen.add(ref)
    if str(synthesis.get("verdict") or "") != "insufficient" and not assessments:
        issues.append("a non-insufficient verdict requires cited evidence")
    return issues


def _review_source_fidelity(
    runtime: Any,
    *,
    claim: str,
    synthesis: Mapping[str, Any],
    documents: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    cited = {
        str(item.get("document_ref")): documents[str(item.get("document_ref"))]
        for item in synthesis.get("evidence_assessments") or ()
        if isinstance(item, Mapping)
        and str(item.get("document_ref")) in documents
    }
    return runtime.generate_json(
        _stage_prompt("fidelity_review"),
        _fidelity_context(claim=claim, synthesis=synthesis, documents=cited),
        purpose="review-literature-source-fidelity",
        schema={
            "type": "object",
            "properties": {
                "accepted": {"type": "boolean"},
                "issues": {
                    "type": "array",
                    "maxItems": 12,
                    "items": {"type": "string", "maxLength": 2_000},
                },
                "reason": {"type": "string", "maxLength": 3_000},
            },
            "required": ["accepted", "issues", "reason"],
            "additionalProperties": False,
        },
    )


def _repair_source_fidelity(
    runtime: Any,
    *,
    claim: str,
    research_question: str,
    synthesis: Mapping[str, Any],
    documents: Mapping[str, Mapping[str, Any]],
    observations: Sequence[Mapping[str, Any]],
    issues: Sequence[str],
) -> dict[str, Any]:
    return runtime.generate_json(
        _stage_prompt("fidelity_repair"),
        _synthesis_context(
            claim=claim,
            research_question=research_question,
            documents=documents,
            observations=observations,
        )
        + "\n\nRejected synthesis:\n"
        + _json_text(synthesis)
        + "\n\nSource-fidelity issues:\n- "
        + "\n- ".join(str(issue) for issue in issues),
        purpose="repair-literature-source-fidelity",
        schema=_synthesis_schema(tuple(documents)),
        repair_call=True,
    )


def _insufficient_synthesis(
    *, title: str, issues: Sequence[str]
) -> dict[str, Any]:
    gaps = [str(issue).strip()[:2_000] for issue in issues if str(issue).strip()]
    if not gaps:
        gaps = ["No evidence-ready source was retrieved within the search quota."]
    return {
        "title": title[:240] or "Literature evidence unavailable",
        "verdict": "insufficient",
        "rationale": (
            "The bounded search did not produce source-grounded evidence that can "
            "support a stronger verdict."
        ),
        "evidence_assessments": [],
        "unresolved_gaps": gaps[:20],
    }


def _machine_payload(
    *,
    claim: str,
    synthesis: Mapping[str, Any],
    documents: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    evidence_items: list[dict[str, Any]] = []
    for assessment in synthesis.get("evidence_assessments") or ():
        if not isinstance(assessment, Mapping):
            continue
        document_ref = str(assessment["document_ref"])
        record = documents.get(document_ref)
        if not isinstance(record, Mapping):
            raise ValueError(f"literature_document_missing:{document_ref}")
        metadata = record.get("metadata")
        if not isinstance(metadata, Mapping):
            raise ValueError(f"literature_document_metadata_missing:{document_ref}")
        evidence_items.append(
            {
                "document_ref": document_ref,
                "title": str(metadata.get("title") or ""),
                "url": str(metadata.get("url") or ""),
                "source_kind": str(metadata.get("source_kind") or ""),
                "stance": str(assessment["stance"]),
                "locator": str(assessment["locator"]),
                "evidence_summary": str(assessment["evidence_summary"]),
                "authors": [str(value) for value in metadata.get("authors") or ()],
                "published": str(metadata.get("published") or ""),
                "doi": str(metadata.get("doi") or ""),
                "site": str(metadata.get("site") or ""),
            }
        )
    return {
        "artifact_kind": "literature_claim_evidence",
        "claim": claim,
        "verdict": str(synthesis["verdict"]),
        "rationale": str(synthesis["rationale"]),
        "evidence_items": evidence_items,
        "unresolved_gaps": [
            str(value) for value in synthesis.get("unresolved_gaps") or ()
        ],
    }


def _render_markdown(payload: Mapping[str, Any]) -> str:
    lines = [
        "# Literature claim evidence",
        "",
        "## Claim",
        "",
        str(payload["claim"]),
        "",
        "## Verdict",
        "",
        str(payload["verdict"]),
        "",
        "## Rationale",
        "",
        str(payload["rationale"]),
        "",
        "## Evidence",
        "",
    ]
    evidence_items = list(payload.get("evidence_items") or ())
    if not evidence_items:
        lines.append("No evidence-ready document was cited.")
    for index, item in enumerate(evidence_items, start=1):
        lines.extend(
            [
                f"### {index}. {item['title']}",
                "",
                f"- Stance: {item['stance']}",
                f"- Source: {item['url']}",
                f"- Locator: {item['locator']}",
                f"- Document ref: `{item['document_ref']}`",
                "",
                str(item["evidence_summary"]),
                "",
            ]
        )
    lines.extend(["## Unresolved gaps", ""])
    gaps = list(payload.get("unresolved_gaps") or ())
    lines.extend(f"- {gap}" for gap in gaps)
    if not gaps:
        lines.append("- None recorded.")
    return "\n".join(lines).strip() + "\n"


def _validate_readback(
    stored: Mapping[str, Any],
    *,
    machine_payload: Mapping[str, Any],
    depends_on: Sequence[str],
    trace_refs: Sequence[str],
) -> None:
    if str(stored.get("artifact_kind") or "") != "literature_claim_evidence":
        raise ValueError("literature_readback_kind_mismatch")
    if stored.get("machine_payload") != machine_payload:
        raise ValueError("literature_readback_payload_mismatch")
    if tuple(stored.get("depends_on") or ()) != tuple(depends_on):
        raise ValueError("literature_readback_dependencies_mismatch")
    if tuple(stored.get("trace_refs") or ()) != tuple(trace_refs):
        raise ValueError("literature_readback_trace_refs_mismatch")


def _search_gaps(observations: Sequence[Mapping[str, Any]]) -> list[str]:
    gaps = [
        f"{item.get('action')}: {item.get('status')} {item.get('reason')}".strip()
        for item in observations
        if str(item.get("status") or "")
        not in {
            "public_search_ready",
            "literature_document_ready",
            "literature_abstract_ready",
            "private_knowledge_ready",
            "literature_document_page",
        }
    ]
    return gaps or [
        "Searches produced no evidence-ready document within the bounded quota."
    ]


def _resolved_inputs(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return []
    return [dict(item) for item in value if isinstance(item, Mapping)]


def _artifact_refs(inputs: Sequence[Mapping[str, Any]]) -> tuple[str, ...]:
    return tuple(
        dict.fromkeys(
            str(item.get("artifact_ref") or "").strip()
            for item in inputs
            if str(item.get("artifact_ref") or "").strip()
        )
    )


def _validated_source_refs(value: Any, *, allowed_refs: Sequence[str]) -> tuple[str, ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise ValueError("literature_claim_source_refs_must_be_array")
    allowed = set(allowed_refs)
    refs = tuple(dict.fromkeys(str(item).strip() for item in value if str(item).strip()))
    unknown = [ref for ref in refs if ref not in allowed]
    if unknown:
        raise ValueError(f"literature_claim_source_ref_not_visible:{unknown}")
    return refs


def _framing_inputs_context(
    inputs: Sequence[Mapping[str, Any]],
) -> str:
    projections = [_framing_input_projection(item) for item in inputs]
    return _strict_json_projection(
        {
            "artifact_index": [
                {
                    "artifact_ref": item["artifact_ref"],
                    "artifact_kind": item["artifact_kind"],
                    "title": item["title"],
                }
                for item in projections
            ],
            "artifact_details": projections,
        },
        limit=_FRAMING_INPUT_CONTEXT_LIMIT,
        label="literature_framing_inputs",
    )


def _framing_input_projection(item: Mapping[str, Any]) -> dict[str, Any]:
    kind = str(item.get("artifact_kind") or "")
    payload = item.get("machine_payload")
    payload = payload if isinstance(payload, Mapping) else {}
    projection: dict[str, Any] = {
        "artifact_ref": item.get("artifact_ref"),
        "artifact_kind": kind,
        "title": str(item.get("title") or "")[:500],
        "summary": str(item.get("summary") or "")[:1_200],
    }
    research_content = _framing_research_content(kind, payload)
    if research_content:
        projection["research_content"] = research_content
    return projection


def _framing_research_content(
    kind: str,
    payload: Mapping[str, Any],
) -> dict[str, Any]:
    if kind == "task_spec":
        return _selected_prompt_fields(
            payload,
            ("goal", "constraints", "evaluation_priority", "output_format"),
        )
    if kind == "prepared_source_data":
        return _selected_prompt_fields(payload, ("prepared_outputs",))
    if kind == "hypothesis":
        return _selected_prompt_fields(
            payload,
            (
                "id",
                "title",
                "description",
                "mechanism",
                "core_claim",
                "risks",
                "verification_plan",
                "source_refs",
                "direction_card",
            ),
        )
    if kind == "hypothesis_mind_map":
        return _mind_map_framing_projection(payload)
    if kind == "proxy_formula_candidate":
        return _selected_prompt_fields(
            payload,
            (
                "formula_id",
                "version",
                "formula_expression",
                "expected_final_kpi_link",
                "expected_relation",
                "side_effect_notes",
                "claim_boundary",
                "validation_criteria",
                "target_kind",
                "target_id",
                "source_binding",
                "historical_variation_evidence",
            ),
        )
    if kind in {"hypothesis_leaderboard", "proxy_formula_leaderboard"}:
        return _selected_prompt_fields(payload, ("version", "ranked_entries"))
    if kind == "scientific_method_review":
        return _selected_prompt_fields(
            payload,
            ("version", "method_artifact_ref", "review_score", "reason"),
        )
    if kind == "final_lca_judgment":
        return _selected_prompt_fields(
            payload,
            ("status", "decision", "reason", "findings", "recommendations"),
        )
    if kind == "literature_claim_evidence":
        return _selected_prompt_fields(
            payload,
            (
                "claim",
                "verdict",
                "rationale",
                "evidence_items",
                "unresolved_gaps",
            ),
        )
    return {}


def _mind_map_framing_projection(
    payload: Mapping[str, Any],
) -> dict[str, Any]:
    landscape = payload.get("mechanism_landscape")
    if not isinstance(landscape, Mapping):
        return {}
    families = landscape.get("families")
    projected_families = []
    if isinstance(families, Sequence) and not isinstance(
        families, (str, bytes)
    ):
        for family in families[:12]:
            if not isinstance(family, Mapping):
                continue
            projected_families.append(
                _selected_prompt_fields(
                    family,
                    (
                        "family_id",
                        "title",
                        "causal_role",
                        "core_mechanism",
                        "main_bottleneck",
                        "expected_failure_mode",
                        "viability_band",
                    ),
                )
            )
    return {
        "mechanism_landscape_summary": _prompt_value(
            landscape.get("mechanism_landscape_summary")
        ),
        "families": projected_families,
        "supported_relationships": _prompt_value(
            landscape.get("supported_relationships")
        ),
        "unresolved_gaps": _prompt_value(landscape.get("unresolved_gaps")),
        "evidence_boundary_summary": _prompt_value(
            landscape.get("evidence_boundary_summary")
        ),
    }


def _selected_prompt_fields(
    payload: Mapping[str, Any],
    field_names: Sequence[str],
) -> dict[str, Any]:
    return {
        field: _prompt_value(payload.get(field))
        for field in field_names
        if field in payload
    }


def _prompt_value(
    value: Any,
    *,
    depth: int = 4,
    maximum_items: int = 12,
    string_limit: int = 1_200,
) -> Any:
    if depth < 0:
        return {"detail": "stored_outside_prompt", "type": type(value).__name__}
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        if len(value) <= string_limit:
            return value
        return value[:string_limit] + f"\n...[{len(value) - string_limit} chars omitted]"
    if isinstance(value, Mapping):
        return {
            str(key): _prompt_value(
                item,
                depth=depth - 1,
                maximum_items=maximum_items,
                string_limit=string_limit,
            )
            for key, item in value.items()
        }
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        projected = [
            _prompt_value(
                item,
                depth=depth - 1,
                maximum_items=maximum_items,
                string_limit=string_limit,
            )
            for item in value[:maximum_items]
        ]
        if len(value) <= maximum_items:
            return projected
        return {"count": len(value), "items": projected}
    return _prompt_value(
        str(value),
        depth=depth - 1,
        maximum_items=maximum_items,
        string_limit=string_limit,
    )


def _action_key(action: Mapping[str, Any]) -> str:
    name = str(action.get("action") or "").strip()
    identity: dict[str, Any] = {"action": name}
    if name == "public_search":
        identity.update(
            {
                "query": _normalized_action_text(action.get("query")),
                "source_group": str(action.get("source_group") or "")
                .strip()
                .casefold(),
            }
        )
    elif name == "private_search":
        identity["query"] = _normalized_action_text(action.get("query"))
    elif name == "fetch_document":
        identity["result_id"] = str(action.get("result_id") or "").strip()
    elif name == "read_document":
        identity.update(
            {
                "document_ref": str(action.get("document_ref") or "").strip(),
                "char_offset": int(action.get("char_offset") or 0),
            }
        )
    return json.dumps(identity, ensure_ascii=False, sort_keys=True)


def _normalized_action_text(value: Any) -> str:
    return " ".join(str(value or "").split()).casefold()


def _fidelity_context(
    *,
    claim: str,
    synthesis: Mapping[str, Any],
    documents: Mapping[str, Mapping[str, Any]],
) -> str:
    document_excerpt_limit = _per_item_excerpt_limit(
        len(documents), total=36_000, minimum=1_500, maximum=8_000
    )
    return _strict_json_projection(
        {
            "claim": claim,
            "synthesis": synthesis,
            "cited_documents": [
                {
                    "document_ref": ref,
                    "metadata": _prompt_metadata(record.get("metadata")),
                    "content_excerpt": str(record.get("content_preview") or "")[
                        :document_excerpt_limit
                    ],
                }
                for ref, record in documents.items()
            ],
        },
        limit=_EVIDENCE_CONTEXT_LIMIT,
        label="literature_fidelity_context",
    )


def _prompt_metadata(value: Any) -> dict[str, str]:
    metadata = value if isinstance(value, Mapping) else {}
    return {
        "title": str(metadata.get("title") or "")[:400],
        "source_kind": str(metadata.get("source_kind") or "")[:120],
        "published": str(metadata.get("published") or "")[:80],
        "site": str(metadata.get("site") or "")[:200],
    }


def _prompt_string_list(
    value: Any, *, maximum: int, item_limit: int
) -> list[str]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return []
    return [
        str(item).strip()[:item_limit]
        for item in value
        if str(item).strip()
    ][:maximum]


def _prompt_integer_list(value: Any, *, maximum: int) -> list[int]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return []
    integers: list[int] = []
    for item in value:
        try:
            number = int(item)
        except (TypeError, ValueError):
            continue
        if number not in integers:
            integers.append(number)
        if len(integers) >= maximum:
            break
    return integers


def _per_item_excerpt_limit(
    count: int, *, total: int, minimum: int, maximum: int
) -> int:
    if count <= 0:
        return 0
    return max(minimum, min(maximum, total // count))


def _json_text(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _strict_json_projection(value: Any, *, limit: int, label: str) -> str:
    text = _json_text(value)
    if len(text) > limit:
        raise ValueError(f"{label}_exceeds_budget:{len(text)}>{limit}")
    return text


def _bounded_json(value: Any, limit: int) -> str:
    text = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    if len(text) <= limit:
        return text
    return text[:limit] + "\n[projection truncated; stored authority unchanged]"
