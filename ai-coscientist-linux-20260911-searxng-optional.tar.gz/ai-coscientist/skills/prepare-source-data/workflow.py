from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from ai_coscientist.domain.prepared_evaluation import (
    evaluation_binding_schema, validate_evaluation_binding,
    validate_record_table, validate_paired_targets, final_kpi_target_metric,
)
from ai_coscientist.domain.prepared_sources import read_prepared_output
from ai_coscientist.domain.preparation_continuation import (
    source_bindings, restore_output,
)
from ai_coscientist.common.json_schema import json_schema_issues


_MAX_OUTPUTS = 8
_MAX_SOURCE_OBSERVATION_CHARS = 48_000
_MAX_SOURCE_OBSERVATION_CHARS_PER_FILE = 16_000
_SOURCE_OBSERVATION_PAGE_LINES = 200
_SOURCE_OBSERVATION_KIND = "source_observation"
_SOURCE_OBSERVATION_PAYLOAD_KEYS = {
    "artifact_kind",
    "completion_status",
    "source_structure",
    "data_quality",
    "useful_signals",
    "unknowns",
}
_STAGE_REFERENCE_DIR = Path(__file__).resolve().parent / "references"
_STAGE_PROMPT_FILES = {
    "source_selection": "source-selection-stage.md",
    "design": "design-stage.md",
    "design_continuation": "design-continuation-stage.md",
    "design_repair": "design-repair-stage.md",
    "output_authoring": "output-authoring-stage.md",
    "validator_authoring": "validator-authoring-stage.md",
    "validator_repair": "validator-repair-stage.md",
    "output_repair": "output-repair-stage.md",
}

_CODE_SCHEMA = {
    "type": "object",
    "properties": {"python_code": {"type": "string"}},
    "required": ["python_code"],
    "additionalProperties": False,
}

_DESIGN_SCHEMA = {
    "type": "object",
    "properties": {
        "status": {
            "type": "string",
            "enum": ["complete", "partial", "blocked"],
        },
        "summary": {"type": "string"},
        "evaluation_binding": {"anyOf": [evaluation_binding_schema(), {"type": "null"}]},
        "outputs": {
            "type": "array",
            "maxItems": _MAX_OUTPUTS,
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "media_type": {"type": "string"},
                    "description": {"type": "string"},
                    "source_paths": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "acceptance_checks": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                },
                "required": [
                    "name",
                    "media_type",
                    "description",
                    "source_paths",
                    "acceptance_checks",
                ],
                "additionalProperties": False,
            },
        },
        "residual_issues": {
            "type": "array",
            "items": {"type": "string"},
        },
    },
    "required": ["status", "summary", "evaluation_binding", "outputs", "residual_issues"],
    "additionalProperties": False,
}

_DESIGN_CONTINUATION_SCHEMA = {
    "type": "object",
    "properties": {
        "decision": {"type": "string", "enum": ["reuse", "revise"]},
        "design": _DESIGN_SCHEMA,
    },
    "required": ["decision"],
    "additionalProperties": False,
    "anyOf": [
        {"properties": {"decision": {"enum": ["reuse"]}}, "additionalProperties": False},
        {"properties": {"decision": {"enum": ["revise"]}}, "required": ["design"]},
    ],
}

_REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "accepted": {"type": "boolean"},
        "summary": {"type": "string"},
        "issues": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["accepted", "summary", "issues"],
    "additionalProperties": False,
}

_RECORD_IDENTITY_CHECK_CODE = r"""
import json

matches = list(SOURCE_ROOT.glob("probe/*/stdout.txt"))
if len(matches) != 1:
    raise RuntimeError(f"expected_one_prepared_body:{len(matches)}")
try:
    payload = json.loads(matches[0].read_text(encoding="utf-8"))
except json.JSONDecodeError as exc:
    print(json.dumps({
        "applicable": True,
        "issues": [f"application/json body is invalid: {exc}"],
    }))
else:
    records = payload.get("records") if isinstance(payload, dict) else None
    if not isinstance(records, list):
        print(json.dumps({"applicable": False, "issues": []}))
    else:
        issues = []
        seen = set()
        for index, record in enumerate(records):
            if not isinstance(record, dict):
                issues.append(f"records[{index}] must be an object")
                continue
            record_id = str(record.get("id", "")).strip()
            if not record_id:
                issues.append(f"records[{index}].id must be non-empty")
                continue
            if record_id in seen:
                issues.append(f"records[{index}].id is duplicated: {record_id}")
                continue
            seen.add(record_id)
        print(json.dumps({"applicable": True, "issues": issues}))
""".strip()

_SOURCE_PROBE_EXECUTION_ABI = (
    "Execution ABI: SOURCE_ROOT is already injected by the host as a "
    "pathlib.Path. Use it directly. The generated program must not assign, "
    "redefine, delete, import over, or shadow SOURCE_ROOT."
)


def run(payload: dict[str, Any], runtime: Any) -> dict[str, Any]:
    """Prepare C4 output bodies and publish one compact C2 manifest."""
    objective = str(payload.get("objective") or "").strip()
    if not objective:
        raise ValueError("source_preparation_objective_required")
    active_loop_step = payload.get("active_loop_step")
    step_purpose = (
        str(active_loop_step.get("purpose") or "").strip()
        if isinstance(active_loop_step, Mapping)
        else ""
    )
    preparation_request = step_purpose or objective
    evaluation = str(payload.get("evaluation_summary") or "").strip()
    plan = str(payload.get("plan_summary") or "").strip()
    active_work_unit = payload.get("active_work_unit")
    if not step_purpose and not isinstance(active_work_unit, Mapping) and evaluation:
        preparation_request += f"\nStandalone preparation completion evidence:\n{evaluation}"
    if isinstance(active_work_unit, Mapping):
        active_projection = {
            key: active_work_unit.get(key)
            for key in (
                "node_id",
                "outcome",
                "completion_condition",
                "addresses_criteria",
            )
        }
        plan = json.dumps(active_projection, ensure_ascii=False, indent=2)
        active_completion = str(
            active_work_unit.get("completion_condition") or ""
        ).strip()
        if active_completion:
            evaluation = active_completion
    prior_preparation = _prior_preparation(payload, runtime)
    dependency_refs = _explicit_formal_input_refs(payload)
    source_observations = _selected_source_observations(payload)

    catalog: dict[str, dict[str, Any]] = {}
    consulted_paths: set[str] = set()
    trace_refs: set[str] = set()

    def inspect_route(name: str, arguments: Mapping[str, Any]) -> Any:
        arguments = _inspection_arguments(name, arguments, catalog)
        result = runtime.call_route(name, arguments)
        if isinstance(result, Mapping):
            catalog.update(_source_catalog(result))
            if name == "source_read" and result.get("status") == "source_page_ready":
                ref = str(arguments.get("source_ref") or "")
                trace_refs.add(ref)
                consulted_paths.update(path for path, entry in catalog.items() if entry["source_ref"] == ref)
            if name == "source_probe":
                trace_refs.update(_probe_refs(result))
        return result

    selected_authorities = [raw for raw in payload.get("resolved_inputs") or ()
                            if isinstance(raw, Mapping) and raw.get("artifact_ref") in dependency_refs
                            and raw.get("artifact_kind") != _SOURCE_OBSERVATION_KIND
                            and (not prior_preparation or raw.get("artifact_ref") != prior_preparation["artifact_ref"])]
    target_authorities = _target_authorities(selected_authorities)
    restored_catalog = _continuation_catalog(prior_preparation, inspect_route)
    selection = {"outputs": [], "residual_issues": []} if restored_catalog else runtime.generate_json(
        _stage_prompt("source_selection"),
        _design_context(
            preparation_request=preparation_request,
            objective=objective, evaluation=evaluation, plan=plan, catalog={},
            source_findings="No sources inspected yet. Locate task-specific inputs first.",
            source_observations=source_observations, prior_preparation=prior_preparation,
            selected_authorities=selected_authorities,
        ),
        purpose="locate-preparation-sources", schema=_DESIGN_SCHEMA,
        inspection_routes=("source_inventory", "source_search", "source_read"),
        inspection_caller=inspect_route,
    )
    selection = _canonicalize_known_source_paths(selection, catalog)
    selected_catalog = restored_catalog or {path: catalog[path] for path in consulted_paths}
    selection_errors: list[str] = []
    for path in dict.fromkeys(str(path) for output in selection["outputs"] for path in output["source_paths"]):
        try:
            entries = _source_catalog(inspect_route("source_inventory", {"relative_path": path, "max_entries": 2}))
            # One declared source is one file, not the first page of a directory.
            if len(entries) != 1:
                raise ValueError(f"expected_exact_file:{path}")
            actual_path, entry = next(iter(entries.items()))
            if not (actual_path == _normalize_path(path) or (
                Path(path).is_absolute() and _normalize_path(path).endswith("/" + actual_path)
            )):
                raise ValueError(f"expected_exact_file:{path}:returned={actual_path}")
            selected_catalog[actual_path] = entry
        except Exception as exc:
            selection_errors.append(f"{path}: {type(exc).__name__}: {exc}")
    catalog = selected_catalog
    if selection_errors or not catalog:
        return _publish_result(
            runtime, summary="Preparation sources could not be located within the mission scope.",
            status="blocked", prepared_outputs=[],
            residual_issues=selection_errors or _strings(selection.get("residual_issues"), 12, 700)
            or ["No task-specific source selected."],
            trace_refs=trace_refs, output_reviews=[], requested_count=0,
            depends_on=sorted(dependency_refs),
        )
    trace_refs.update(str(item["source_ref"]) for item in catalog.values())
    if prior_preparation is not None:
        trace_refs.add(str(prior_preparation["artifact_ref"]))
        trace_refs.update(prior_preparation["trace_refs"])

    findings = []
    for path, entry in sorted(catalog.items()):
        inspection, inspection_error = _run_probe(
            runtime, purpose="inspect mounted sources for preparation",
            source_refs=[str(entry["source_ref"])],
            python_code=_structure_inspector_code([path]),
        )
        trace_refs.update(_probe_refs(inspection))
        if inspection_error:
            selection_errors.append(f"{path}: {inspection_error}")
            continue
        try:
            findings.append(_inspection_findings(runtime, str(inspection["stdout_ref"])))
        except Exception as exc:
            selection_errors.append(f"{path}: {type(exc).__name__}: {exc}")
    if selection_errors:
        return _publish_result(
            runtime, summary="Selected source inspection failed.", status="blocked",
            prepared_outputs=[], residual_issues=selection_errors, trace_refs=trace_refs,
            output_reviews=[], requested_count=0, depends_on=sorted(dependency_refs),
        )
    source_findings = "\n".join(findings)
    try:
        source_observation = _source_content_findings(runtime, catalog)
    except Exception as exc:
        return _publish_result(
            runtime, summary="Selected source content could not be read.", status="blocked",
            prepared_outputs=[], residual_issues=[f"{type(exc).__name__}: {exc}"],
            trace_refs=trace_refs, output_reviews=[], requested_count=0,
            depends_on=sorted(dependency_refs),
        )
    source_findings = _line_projection(
        source_findings + "\n" + source_observation,
        max_chars=_MAX_SOURCE_OBSERVATION_CHARS,
    )

    profiled_bindings = source_bindings(catalog)
    saved_design = prior_preparation.get("preparation_design") if prior_preparation else None
    design_selection = runtime.generate_json(
        _stage_prompt("design_continuation" if saved_design is not None else "design"),
        _design_context(
            preparation_request=preparation_request,
            objective=objective,
            evaluation=evaluation,
            plan=plan,
            catalog=catalog,
            source_findings=source_findings,
            source_observations=source_observations,
            prior_preparation=prior_preparation,
            selected_authorities=selected_authorities,
        ),
        purpose="continue-prepared-source-design" if saved_design is not None else "design-prepared-source-outputs",
        schema=_DESIGN_CONTINUATION_SCHEMA if saved_design is not None else _DESIGN_SCHEMA,
        inspection_routes=("source_inventory", "source_search", "source_read", "source_probe"),
        inspection_caller=inspect_route,
    )
    if saved_design is not None:
        design = (copy.deepcopy(saved_design) if design_selection["decision"] == "reuse"
                  else design_selection["design"])
    else:
        design = design_selection
    design = _canonicalize_known_source_paths(design, catalog)
    design_issues = _design_issues(
        design,
        catalog,
        target_ids=[item["target_id"] for item in target_authorities],
    )
    if design_issues:
        had_binding = design.get("evaluation_binding") is not None
        design = runtime.generate_json(
            _stage_prompt("design_repair"),
            _repair_design_context(
                preparation_request=preparation_request,
                objective=objective,
                evaluation=evaluation,
                plan=plan,
                catalog=catalog,
                source_findings=source_findings,
                source_observations=source_observations,
                design=design,
                issues=design_issues,
                prior_preparation=prior_preparation,
                selected_authorities=selected_authorities,
            ),
            purpose="repair-prepared-source-output-design",
            schema=_DESIGN_SCHEMA,
            repair_call=True,
        )
        design = _canonicalize_known_source_paths(design, catalog)
        design_issues = _design_issues(
            design,
            catalog,
            target_ids=[item["target_id"] for item in target_authorities],
            binding_required=had_binding,
        )
    if design_issues:
        raise ValueError(
            "source_preparation_design_invalid:" + ";".join(design_issues[:12])
        )

    # Newly selected files need the same exact observations as initial inputs.
    profiled = {item["relative_path"]: item["source_ref"] for item in profiled_bindings}
    additional = {path: entry for path, entry in catalog.items()
                  if profiled.get(path) != entry["source_ref"]}
    if additional:
        extra_findings = []
        for path, entry in sorted(additional.items()):
            inspection, failure = _run_probe(
                runtime, purpose="inspect mounted sources for preparation",
                source_refs=[entry["source_ref"]], python_code=_structure_inspector_code([path]),
            )
            trace_refs.update(_probe_refs(inspection))
            if failure:
                raise ValueError(f"source_preparation_new_source_inspection_failed:{path}:{failure}")
            extra_findings.append(_inspection_findings(runtime, inspection["stdout_ref"]))
        source_findings = _line_projection(
            source_findings + "\n" + "\n".join(extra_findings)
            + "\n" + _source_content_findings(runtime, additional),
            max_chars=_MAX_SOURCE_OBSERVATION_CHARS,
        )
        trace_refs.update(entry["source_ref"] for entry in additional.values())

    prepared_by_name: dict[str, dict[str, str]] = {}
    residual_issues = _strings(design.get("residual_issues"), 12, 700)
    review_by_name: dict[str, dict[str, Any]] = {}
    prior_issues_by_name: Mapping[str, Sequence[str]] = {}
    if prior_preparation is not None:
        prior_issues_by_name = prior_preparation["issues_by_name"]
    binding = design.get("evaluation_binding")
    contracts = list(design["outputs"])
    if binding:
        record_contract = next(item for item in contracts if item["name"] == binding["record_output_name"])
        # Only the declared pair imposes an order; other outputs keep their order.
        record_index = contracts.index(record_contract)
        target_index = next(i for i, item in enumerate(contracts) if item["name"] == binding["target_output_name"])
        if target_index < record_index:
            contracts.insert(target_index, contracts.pop(record_index))
    for index, raw_contract in enumerate(contracts, start=1):
        contract = dict(raw_contract)
        if design.get("evaluation_binding"):
            contract["evaluation_binding"] = dict(design["evaluation_binding"])
        name = str(contract["name"])
        record_output = None
        record_dependency_refs: list[str] = []
        bound_record_contract = None
        if binding and name == binding["target_output_name"]:
            record_output = prepared_by_name.get(binding["record_output_name"])
            if record_output is None:
                issue = f"Required record output not accepted: {binding['record_output_name']}"
                review_by_name[name] = {
                    "name": name, "accepted": False, "summary": issue, "issues": [issue],
                    "repair_used": False, "transformation_run_ref": None, "validation_run_ref": None,
                }
                residual_issues.append(issue)
                continue
            bound_record_contract = record_contract
            record_dependency_refs = _record_dependency_refs(record_output, record_contract, catalog)
        resumed = None
        if prior_preparation is not None:
            try:
                resumed = restore_output(runtime, prior_preparation, contract, catalog,
                                         dependency_refs=record_dependency_refs)
            except (ValueError, RuntimeError, KeyError, TypeError) as exc:
                issue = f"Preparation continuation unavailable for {name}: {exc}"
                review_by_name[name] = {
                    "name": name, "accepted": False, "summary": issue, "issues": [issue],
                    "repair_used": False, "transformation_run_ref": None, "validation_run_ref": None,
                }
                residual_issues.append(issue)
                continue
        if resumed and resumed["accepted_output"] and record_output is None:
            prepared_by_name[name] = dict(resumed["accepted_output"])
            review_by_name[name] = dict(prior_preparation["accepted_reviews"][name])
            continue
        outcome = _prepare_output(
            runtime,
            index=index,
            contract=contract,
            source_findings=source_findings,
            catalog=catalog,
            prior_issues=prior_issues_by_name.get(name, ()),
            resumed=resumed,
            record_output=record_output,
            record_contract=bound_record_contract,
        )
        trace_refs.update(outcome["trace_refs"])
        review_by_name[name] = outcome["review"]
        if outcome["prepared_output"]:
            prepared_by_name[name] = outcome["prepared_output"]
        else:
            residual_issues.append(outcome["issue"])

    requested_names = [str(item["name"]) for item in design["outputs"]]
    prepared_outputs = [
        prepared_by_name[name]
        for name in requested_names
        if name in prepared_by_name
    ]
    output_reviews = [
        review_by_name[name]
        for name in requested_names
        if name in review_by_name
    ]
    requested_count = len(requested_names)
    if (requested_count and len(prepared_outputs) == requested_count
            and design["status"] == "complete"):
        status = "complete"
    elif prepared_outputs:
        status = "partial"
    else:
        status = "blocked"

    return _publish_result(
        runtime,
        summary=_bounded(design.get("summary"), 1_500),
        status=status,
        prepared_outputs=prepared_outputs,
        residual_issues=residual_issues,
        trace_refs=trace_refs,
        output_reviews=output_reviews,
        requested_count=requested_count,
        evaluation_binding=design.get("evaluation_binding"),
        preparation_design=design,
        source_bindings=source_bindings(catalog),
        depends_on=sorted(
            {
                *dependency_refs,
                *(
                    [str(prior_preparation["artifact_ref"])]
                    if prior_preparation is not None
                    else []
                ),
            }
        ),
    )


def _continuation_catalog(prior: dict[str, Any] | None, inspect: Any) -> dict[str, Any]:
    if not prior or not prior.get("preparation_design"):
        return {}
    catalog: dict[str, Any] = {}
    issues: list[str] = []
    for binding in prior["source_bindings"]:
        path, ref = binding["relative_path"], binding["source_ref"]
        try:
            entries = _source_catalog(inspect("source_inventory", {"relative_path": path, "max_entries": 2}))
            if path not in entries or entries[path]["source_ref"] != ref:
                raise ValueError(f"preparation_source_changed_or_unavailable:{path}:expected={ref}")
            catalog[path] = entries[path]
        except Exception as exc:
            issues.append(f"{path}: {type(exc).__name__}: {exc}")
    if issues:
        prior["prompt_projection"]["continuation_issues"] = issues
        return {}
    return catalog


def _prior_preparation(
    payload: Mapping[str, Any],
    runtime: Any,
) -> dict[str, Any] | None:
    active = payload.get("active_work_unit")
    if not isinstance(active, Mapping):
        active = {}
    attempt_ref_list = [
        str(ref)
        for ref in active.get("attempt_refs") or ()
        if str(ref).startswith("artifact:")
    ]
    selected_input_refs = _selected_active_loop_input_refs(payload)
    resolved = payload.get("resolved_inputs")
    if not isinstance(resolved, Sequence) or isinstance(resolved, (str, bytes)):
        return None
    resolved_items = [dict(raw) for raw in resolved if isinstance(raw, Mapping)]
    resolved_refs = {
        str(raw.get("artifact_ref") or "") for raw in resolved_items
    }
    for artifact_ref in attempt_ref_list:
        if artifact_ref in resolved_refs:
            continue
        try:
            stored = runtime.read_artifact(artifact_ref)
        except Exception:
            continue
        if isinstance(stored, Mapping):
            resolved_items.append(dict(stored))
            resolved_refs.add(artifact_ref)
    eligible_refs = set(attempt_ref_list)
    eligible_refs.update(
        str(raw.get("artifact_ref") or "")
        for raw in resolved_items
        if raw.get("artifact_kind") == "prepared_source_data"
        and str(raw.get("artifact_ref") or "") in selected_input_refs
    )
    for raw in resolved_items:
        artifact_ref = str(raw.get("artifact_ref") or "")
        if (
            raw.get("artifact_kind") != "graph_revision_outcome"
            or artifact_ref not in selected_input_refs
        ):
            continue
        revision_payload = raw.get("machine_payload")
        if not isinstance(revision_payload, Mapping):
            continue
        eligible_refs.update(
            str(ref)
            for ref in revision_payload.get("still_usable_refs") or ()
            if str(ref).startswith("artifact:")
        )
    if not eligible_refs:
        return None

    for artifact_ref in sorted(eligible_refs):
        if artifact_ref in resolved_refs:
            continue
        try:
            stored = runtime.read_artifact(artifact_ref)
        except Exception:
            continue
        if isinstance(stored, Mapping):
            resolved_items.append(dict(stored))
            resolved_refs.add(artifact_ref)

    for raw in reversed(resolved_items):
        if not isinstance(raw, Mapping):
            continue
        artifact_ref = str(raw.get("artifact_ref") or "")
        if (
            artifact_ref not in eligible_refs
            or raw.get("artifact_kind") != "prepared_source_data"
        ):
            continue
        # Inline projections can be stale or bounded. The selected stored revision owns recovery.
        try:
            raw = runtime.read_artifact(artifact_ref)
        except Exception:
            continue
        self_review = raw.get("self_review")
        machine_payload = raw.get("machine_payload")
        if not isinstance(self_review, Mapping) or not isinstance(
            machine_payload, Mapping
        ):
            continue
        if self_review.get("preparation_status") not in {"complete", "partial", "blocked"}:
            continue
        reviews = self_review.get("output_reviews")
        outputs = machine_payload.get("prepared_outputs")
        if not isinstance(reviews, list) or not isinstance(outputs, list):
            continue

        normalized_reviews = [
            dict(item) for item in reviews if isinstance(item, Mapping)
        ]
        requested_names = [
            str(item.get("name") or "").strip()
            for item in normalized_reviews
            if str(item.get("name") or "").strip()
        ]
        if not requested_names or len(requested_names) != len(set(requested_names)):
            continue
        review_by_name = {
            str(item["name"]): item for item in normalized_reviews
        }
        output_by_name = {
            str(item.get("name") or ""): dict(item)
            for item in outputs
            if isinstance(item, Mapping)
            and str(item.get("name") or "").strip()
            and str(item.get("content_ref") or "").startswith("source_probe:")
        }
        accepted_outputs = {
            name: output_by_name[name]
            for name, review in review_by_name.items()
            if bool(review.get("accepted")) and name in output_by_name
        }
        accepted_reviews = {
            name: dict(review_by_name[name]) for name in accepted_outputs
        }
        issues_by_name = {
            name: _strings(review.get("issues"), 12, 1_000)
            for name, review in review_by_name.items()
            if not bool(review.get("accepted"))
        }
        trace_refs = {
            str(ref)
            for ref in raw.get("trace_refs") or ()
            if str(ref).strip()
        }
        saved_design = self_review.get("preparation_design")
        bindings = self_review.get("source_bindings")
        exact = (
            isinstance(saved_design, Mapping)
            and not json_schema_issues(saved_design, _DESIGN_SCHEMA)
            and isinstance(bindings, list) and bool(bindings)
            and all(isinstance(item, Mapping)
                    and set(item) == {"relative_path", "source_ref"}
                    and isinstance(item["relative_path"], str) and bool(item["relative_path"])
                    and isinstance(item["source_ref"], str) and item["source_ref"].startswith("source_file:")
                    for item in bindings)
        )
        if exact:
            paths = {item["relative_path"] for item in bindings}
            exact = (len(paths) == len(bindings)
                     and not _design_issues(saved_design, dict.fromkeys(paths, {})))
        return {
            "artifact_ref": artifact_ref,
            "evaluation_binding": machine_payload.get("evaluation_binding"),
            "requested_names": requested_names,
            "accepted_outputs": accepted_outputs,
            "accepted_reviews": accepted_reviews,
            "issues_by_name": issues_by_name,
            "trace_refs": trace_refs,
            "preparation_design": dict(saved_design) if exact else None,
            "source_bindings": list(bindings) if exact else [],
            "reviews_by_name": review_by_name,
            "prompt_projection": {
                "artifact_ref": artifact_ref,
                "evaluation_binding": machine_payload.get("evaluation_binding"),
                "preparation_status": self_review.get("preparation_status"),
                "requested_output_names": requested_names,
                "accepted_outputs": list(accepted_outputs.values()),
                "unresolved_output_names": [
                    name for name in requested_names if name not in accepted_outputs
                ],
                "preparation_design": dict(saved_design) if exact else None,
                "source_bindings": list(bindings) if exact else [],
                "continuation_issues": [] if exact else [
                    "Original preparation design/source bindings are absent or invalid. "
                    "This artifact is readable evidence, not an exact continuation checkpoint."
                ],
                "output_reviews": normalized_reviews,
            },
        }
    return None


def _explicit_formal_input_refs(payload: Mapping[str, Any]) -> set[str]:
    """Return exact selected formal inputs that the manifest actually depends on."""
    selected_refs = _selected_active_loop_input_refs(payload)
    if not selected_refs:
        return set()
    resolved = payload.get("resolved_inputs")
    if not isinstance(resolved, Sequence) or isinstance(resolved, (str, bytes)):
        return set()
    return {
        str(raw.get("artifact_ref") or "")
        for raw in resolved
        if isinstance(raw, Mapping)
        and str(raw.get("artifact_ref") or "") in selected_refs
        and raw.get("artifact_kind") != "graph_revision_outcome"
    }


def _selected_active_loop_input_refs(payload: Mapping[str, Any]) -> set[str]:
    active_step = payload.get("active_loop_step")
    if not isinstance(active_step, Mapping):
        return set()
    return {
        str(ref)
        for ref in active_step.get("input_refs") or ()
        if str(ref).startswith("artifact:")
    }


def _selected_source_observations(
    payload: Mapping[str, Any],
) -> list[dict[str, Any]]:
    selected_refs = _selected_active_loop_input_refs(payload)
    if not selected_refs:
        return []
    resolved = payload.get("resolved_inputs")
    if not isinstance(resolved, Sequence) or isinstance(resolved, (str, bytes)):
        return []

    by_ref = {
        str(raw.get("artifact_ref") or ""): raw
        for raw in resolved
        if isinstance(raw, Mapping)
        and str(raw.get("artifact_ref") or "") in selected_refs
        and raw.get("artifact_kind") == _SOURCE_OBSERVATION_KIND
    }
    observations: list[dict[str, Any]] = []
    for artifact_ref in sorted(by_ref):
        raw = by_ref[artifact_ref]
        machine_payload = raw.get("machine_payload")
        if not isinstance(machine_payload, Mapping) or set(machine_payload) != (
            _SOURCE_OBSERVATION_PAYLOAD_KEYS
        ):
            raise ValueError("source_preparation_source_observation_payload_invalid")
        if machine_payload.get("artifact_kind") != _SOURCE_OBSERVATION_KIND:
            raise ValueError("source_preparation_source_observation_kind_mismatch")
        completion_status = str(machine_payload.get("completion_status") or "")
        if completion_status not in {"complete", "partial", "blocked"}:
            raise ValueError("source_preparation_source_observation_status_invalid")
        projection = {
            "artifact_ref": artifact_ref,
            "completion_status": completion_status,
            "summary": str(raw.get("summary") or "").strip(),
            "source_structure": _source_observation_rows(
                machine_payload.get("source_structure"), "source_structure"
            ),
            "data_quality": _source_observation_rows(
                machine_payload.get("data_quality"), "data_quality"
            ),
            "useful_signals": _source_observation_rows(
                machine_payload.get("useful_signals"), "useful_signals"
            ),
            "unknowns": _source_observation_rows(
                machine_payload.get("unknowns"), "unknowns"
            ),
            "trace_refs": _source_observation_rows(
                raw.get("trace_refs"), "trace_refs"
            ),
        }
        if not projection["summary"] or not projection["trace_refs"]:
            raise ValueError("source_preparation_source_observation_evidence_invalid")
        observations.append(projection)
    return observations


def _source_observation_rows(value: Any, field: str) -> list[str]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise ValueError(f"source_preparation_source_observation_{field}_invalid")
    if any(not isinstance(item, str) for item in value):
        raise ValueError(f"source_preparation_source_observation_{field}_invalid")
    rows = [item.strip() for item in value]
    if any(not row for row in rows):
        raise ValueError(f"source_preparation_source_observation_{field}_invalid")
    return rows


_STRUCTURE_INSPECTOR_TEMPLATE = r"""
import csv
import json
import re
from pathlib import Path

SOURCE_PATHS = __SOURCE_PATHS__
MAX_LINES = 180
MAX_DEPTH = 10
lines = []
truncated = False


def emit(*parts):
    global truncated
    if len(lines) >= MAX_LINES:
        truncated = True
        return False
    cleaned = []
    for part in parts:
        text = str(part).replace("\t", " ").replace("\r", " ").replace("\n", " ")
        cleaned.append(text[:800])
    lines.append("\t".join(cleaned))
    return True


def scalar_type(value):
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, str):
        return "string"
    return type(value).__name__


def child_path(parent, key):
    name = str(key)
    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        return parent + "." + name
    return parent + "[" + json.dumps(name, ensure_ascii=True) + "]"


def walk_structure(file_label, value, path="$", depth=0):
    global truncated
    if depth > MAX_DEPTH:
        emit("PATH", file_label, path, "type=depth_limit")
        return
    if isinstance(value, dict):
        if not emit("PATH", file_label, path, "type=object", f"field_count={len(value)}"):
            return
        for key in sorted(value, key=lambda item: str(item)):
            if len(lines) >= MAX_LINES:
                truncated = True
                return
            walk_structure(
                file_label,
                value[key],
                child_path(path, key),
                depth + 1,
            )
        return
    if isinstance(value, list):
        item_types = sorted({scalar_type(item) if not isinstance(item, (dict, list)) else ("object" if isinstance(item, dict) else "array") for item in value})
        if not emit(
            "PATH",
            file_label,
            path,
            "type=array",
            f"count={len(value)}",
            "item_types=" + ",".join(item_types),
        ):
            return
        representative = next((item for item in value if item is not None), None)
        if representative is not None:
            walk_structure(file_label, representative, path + "[]", depth + 1)
        return
    emit("PATH", file_label, path, "type=" + scalar_type(value))


def inspect_json(file_label, path):
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    emit("FILE", file_label, "format=json", f"bytes={path.stat().st_size}")
    walk_structure(file_label, value)


def inspect_json_lines(file_label, path):
    records = []
    parse_errors = 0
    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            if not line.strip():
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                parse_errors += 1
    emit(
        "FILE",
        file_label,
        "format=json_lines",
        f"bytes={path.stat().st_size}",
        f"rows={len(records)}",
        f"parse_errors={parse_errors}",
    )
    walk_structure(file_label, records)


def inspect_table(file_label, path, delimiter):
    row_count = 0
    missing = {}
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as handle:
        reader = csv.DictReader(handle, delimiter=delimiter)
        fields = [str(item) for item in (reader.fieldnames or [])]
        missing = {field: 0 for field in fields}
        for row in reader:
            row_count += 1
            for field in fields:
                if row.get(field) in (None, ""):
                    missing[field] += 1
    emit(
        "FILE",
        file_label,
        "format=tsv" if delimiter == "\t" else "format=csv",
        f"bytes={path.stat().st_size}",
        f"rows={row_count}",
        f"columns={len(missing)}",
    )
    for field in missing:
        emit("COLUMN", file_label, field, f"missing={missing[field]}/{row_count}")


def inspect_text(file_label, path):
    data = path.read_bytes()
    if b"\x00" in data:
        emit("FILE", file_label, "format=binary_or_unsupported", f"bytes={len(data)}")
        return
    text = data.decode("utf-8-sig", errors="replace")
    heading_counts = {}
    for line in text.splitlines():
        match = re.match(r"^(#{1,6})\s+", line)
        if match:
            level = len(match.group(1))
            heading_counts[level] = heading_counts.get(level, 0) + 1
    emit(
        "FILE",
        file_label,
        "format=markdown" if path.suffix.lower() in {".md", ".markdown"} else "format=text",
        f"bytes={len(data)}",
        f"chars={len(text)}",
        f"lines={len(text.splitlines())}",
        "heading_counts=" + json.dumps(heading_counts, sort_keys=True),
    )


for relative_path in SOURCE_PATHS:
    path = SOURCE_ROOT / relative_path
    try:
        suffix = path.suffix.lower()
        if suffix == ".json":
            inspect_json(relative_path, path)
        elif suffix in {".jsonl", ".ndjson"}:
            inspect_json_lines(relative_path, path)
        elif suffix == ".csv":
            inspect_table(relative_path, path, ",")
        elif suffix in {".tsv", ".tab"}:
            inspect_table(relative_path, path, "\t")
        else:
            inspect_text(relative_path, path)
    except Exception as exc:
        emit(
            "FILE",
            relative_path,
            "format=unreadable",
            "error=" + type(exc).__name__ + ":" + str(exc),
        )

if truncated:
    lines.append("REPORT\ttruncated=true\tincrease targeted observation if needed")
print("\n".join(lines))
"""

def _stage_prompt(stage: str) -> str:
    filename = _STAGE_PROMPT_FILES.get(stage)
    if filename is None:
        raise ValueError(f"source_preparation_stage_prompt_unknown:{stage}")
    path = _STAGE_REFERENCE_DIR / filename
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        raise ValueError(f"source_preparation_stage_prompt_empty:{stage}")
    if stage == "design_continuation":
        text += "\n\n" + (_STAGE_REFERENCE_DIR / _STAGE_PROMPT_FILES["design"]).read_text(encoding="utf-8").strip()
    if stage == "validator_repair":
        text += "\n\n" + (_STAGE_REFERENCE_DIR / _STAGE_PROMPT_FILES["validator_authoring"]).read_text(encoding="utf-8").strip()
    text += "\n\n" + (_STAGE_REFERENCE_DIR / "source-facts.md").read_text(encoding="utf-8").strip()
    if stage not in {"validator_authoring", "validator_repair"}:
        text += "\n\n" + (_STAGE_REFERENCE_DIR / "evaluation-binding.md").read_text(encoding="utf-8").strip()
    return text


def _structure_inspector_code(paths: Sequence[str]) -> str:
    source_paths = [
        _normalize_path(path)
        for path in paths
        if _normalize_path(path)
    ]
    return _STRUCTURE_INSPECTOR_TEMPLATE.replace(
        "__SOURCE_PATHS__",
        json.dumps(source_paths, ensure_ascii=True),
    ).strip()


def _prepare_output(
    runtime: Any,
    *,
    index: int,
    contract: Mapping[str, Any],
    source_findings: str,
    catalog: Mapping[str, Mapping[str, Any]],
    prior_issues: Sequence[str] = (),
    resumed: Mapping[str, Any] | None = None,
    record_output: Mapping[str, str] | None = None,
    record_contract: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    paths = [_normalize_path(item) for item in contract["source_paths"]]
    refs = [_source_ref(path, catalog) for path in paths]
    dependency_context = ""
    record_rows = None
    dependency_trace_refs: Sequence[str] = ()
    if record_output is not None:
        if record_contract is None:
            raise ValueError("prepared_record_dependency_contract_required")
        refs = list(dict.fromkeys([*refs, *_record_dependency_refs(record_output, record_contract, catalog)]))
        paths = list(dict.fromkeys([*paths, *record_contract["source_paths"]]))
        record_body = read_prepared_output(runtime, record_output, consumer="prepare-source-data")
        record_rows = validate_record_table(record_body.content)
        dependency_trace_refs = record_body.trace_refs
        dependency_context = _record_dependency_context(record_output, record_contract, record_body.content)
    relevant_findings = _findings_for_paths(source_findings, paths)
    code = resumed["code"] if resumed else runtime.generate_json(
        _stage_prompt("output_authoring"),
        _output_authoring_context(
            contract=contract,
            source_findings=relevant_findings,
            prior_issues=prior_issues,
        ) + dependency_context,
        purpose=f"write-prepared-source-output-{index}",
        schema=_CODE_SCHEMA,
    )["python_code"]
    validator_code = resumed["validator_code"] if resumed else ""

    trace_refs = {*refs, *dependency_trace_refs}
    last_failure = ""
    last_evidence: Mapping[str, Any] = {
        "verified_source_findings": relevant_findings,
    }
    last_review: dict[str, Any] = {
        "name": str(contract["name"]),
        "accepted": False,
        "summary": "not executed",
        "issues": [],
    }
    validator_repair_used = False
    transformation_run_ref = None
    validation_run_ref = None
    for attempt in range(2):
        if attempt == 0 and resumed:
            probe = dict(resumed["probe"])
            failure = _probe_failure(probe)
        else:
            probe, failure = _run_probe(
                runtime,
                purpose=f"prepare named output {contract['name']}",
                source_refs=refs,
                python_code=str(code),
            )
        transformation_run_ref = probe.get("manifest_ref")
        validation_run_ref = None
        trace_refs.update(_probe_refs(probe))
        last_evidence = {
            "verified_source_findings": relevant_findings,
            "output_execution": probe,
        }
        if not failure:
            identity_issues: list[str] = []
            identity_failure = ""
            identity_probe: dict[str, Any] = {}
            if _is_json_media_type(contract.get("media_type")):
                identity_issues, identity_failure, identity_probe = (
                    _validate_prepared_record_identity(
                        runtime,
                        name=str(contract["name"]),
                        output_probe=probe,
                    )
                )
                trace_refs.update(_probe_refs(identity_probe))
            identity_rejected = bool(identity_issues)
            binding = contract.get("evaluation_binding")
            is_bound_record = bool(binding and contract["name"] == binding["record_output_name"])
            if not identity_failure and not identity_rejected and (record_rows is not None or is_bound_record):
                candidate = read_prepared_output(runtime, {
                    "name": str(contract["name"]), "content_ref": str(probe["stdout_ref"]),
                    "media_type": str(contract["media_type"]), "description": str(contract["description"]),
                }, consumer="prepare-source-data")
                trace_refs.update(candidate.trace_refs)
                try:
                    if is_bound_record:
                        validate_record_table(candidate.content)
                    else:
                        validate_paired_targets(record_rows, candidate.content)
                except ValueError as exc:
                    identity_issues = [str(exc)]
                    if record_rows is not None:
                        identity_issues.append(f"Expected {len(record_rows)} records; "
                                               f"first required ids: {[row['id'] for row in record_rows[:20]]}")
                    identity_rejected = True
            if identity_failure:
                review = {}
                validation_failure = (
                    "record identity check failed: " + identity_failure
                )
                validation_probe = identity_probe
            elif identity_rejected:
                review = {
                    "accepted": False,
                    "summary": (
                        "Prepared record identity or declared evaluation pair is invalid."
                    ),
                    "issues": identity_issues,
                }
                validation_failure = ""
                validation_probe = identity_probe
            elif attempt == 0 and resumed and resumed["validation_probe"]:
                validation_probe = dict(resumed["validation_probe"])
                review, validation_failure = _read_validation_verdict(runtime, validation_probe)
                validation_run_ref = validation_probe.get("manifest_ref")
            else:
                if not validator_code:
                    validator_code = runtime.generate_json(
                        _stage_prompt("validator_authoring"),
                        _validator_authoring_context(
                            contract=contract,
                            source_findings=relevant_findings,
                            source_paths=paths,
                            candidate_output=probe,
                        ) + dependency_context,
                        purpose=f"write-prepared-source-output-validator-{index}",
                        schema=_CODE_SCHEMA,
                        scientific_call=True,
                    )["python_code"]
                review, validation_failure, validation_probe = (
                    _validate_prepared_output(
                        runtime,
                        name=str(contract["name"]),
                        source_refs=refs,
                        output_probe=probe,
                        python_code=str(validator_code),
                    )
                )
                validation_run_ref = validation_probe.get("manifest_ref")
            trace_refs.update(_probe_refs(validation_probe))
            # Reconcile a model-authored check before changing the data it rejects.
            # A host identity-check failure cannot be fixed by that validator.
            if (
                not validator_repair_used
                and not identity_failure
                and not identity_rejected
                and (validation_failure or not review.get("accepted"))
            ):
                repaired_validator = runtime.generate_json(
                    _stage_prompt("validator_repair"),
                    _validator_repair_context(
                        source_findings=relevant_findings,
                        contract=contract,
                        validator_code=str(validator_code),
                        failure=validation_failure or "validation rejected",
                        verdict=review,
                        candidate_output=probe,
                        validator_evidence=validation_probe,
                        host_diagnosis=(
                            "The model-authored validator failed or rejected the "
                            "candidate. Compare the validator and delivered body "
                            "against the original sources and unchanged contract. Fix a validator defect; "
                            "if its rejection is correct, return the validator "
                            "unchanged so output repair can address the defect. "
                            "The host has not determined which program is wrong."
                        ),
                    ) + dependency_context,
                    purpose=f"repair-prepared-source-output-validator-{index}",
                    schema=_CODE_SCHEMA,
                    repair_call=True,
                )
                changed = repaired_validator["python_code"] != validator_code
                validator_code = repaired_validator["python_code"]
                validator_repair_used = True
                if changed:
                    review, validation_failure, validation_probe = (
                        _validate_prepared_output(
                            runtime,
                            name=str(contract["name"]),
                            source_refs=refs,
                            output_probe=probe,
                            python_code=str(validator_code),
                        )
                    )
                    validation_run_ref = validation_probe.get("manifest_ref")
            trace_refs.update(_probe_refs(validation_probe))
            last_evidence = {
                "verified_source_findings": relevant_findings,
                "output_execution": probe,
                "validation_execution": validation_probe,
                "validation_result": review,
            }
            if validation_failure:
                last_failure = "validator failed: " + validation_failure
                last_review.update(
                    {
                        "summary": _bounded(last_failure, 800),
                        "issues": [last_failure],
                        "repair_used": attempt > 0 or validator_repair_used,
                    }
                )
                break

            last_review = {
                "name": str(contract["name"]),
                "accepted": bool(review["accepted"]),
                "summary": _bounded(review.get("summary"), 800),
                "issues": _strings(review.get("issues"), 8, 500),
                "repair_used": attempt > 0 or validator_repair_used,
                "transformation_run_ref": transformation_run_ref,
                "validation_run_ref": validation_run_ref,
            }
            if review["accepted"]:
                return {
                    "prepared_output": {
                        "name": str(contract["name"]),
                        "content_ref": str(probe["stdout_ref"]),
                        "media_type": str(contract["media_type"]),
                        "description": str(contract["description"]),
                    },
                    "trace_refs": sorted(trace_refs),
                    "review": last_review,
                    "issue": "",
                }
            failure = "validation rejected: " + "; ".join(
                last_review["issues"] or [last_review["summary"]]
            )
        last_failure = failure
        if attempt == 1:
            break
        repaired = runtime.generate_json(
            _stage_prompt("output_repair"),
            _repair_context(
                purpose=f"prepare output {contract['name']}",
                source_findings=relevant_findings,
                previous_code=str(code),
                validator_code=str(validator_code),
                failure=failure,
                contract=contract,
                evidence=last_evidence,
            ) + dependency_context,
            purpose=f"repair-prepared-source-output-{index}",
            schema=_CODE_SCHEMA,
            repair_call=True,
        )
        code = str(repaired["python_code"])

    last_review.update(
        {
            "accepted": False,
            "summary": _bounded(last_failure, 800),
            "repair_used": True,
            "transformation_run_ref": transformation_run_ref,
            "validation_run_ref": validation_run_ref,
        }
    )
    return {
        "prepared_output": {},
        "trace_refs": sorted(trace_refs),
        "review": last_review,
        "issue": f"{contract['name']}: {last_failure}",
    }


def _record_dependency_refs(
    output: Mapping[str, str], contract: Mapping[str, Any],
    catalog: Mapping[str, Mapping[str, Any]],
) -> list[str]:
    return [*[_source_ref(path, catalog) for path in contract["source_paths"]], output["content_ref"]]


def _record_dependency_context(
    output: Mapping[str, str], contract: Mapping[str, Any], body: Any,
) -> str:
    ref = output["content_ref"]
    parts = ref.split(":")
    if len(parts) != 3 or parts[0] != "source_probe" or parts[2] != "stdout":
        raise ValueError(f"prepared_record_dependency_ref_invalid:{ref}")
    path = f"probe/{parts[1]}/stdout.txt"
    return (
        "\n\nBound record dependency (already accepted; identical in authoring and repair):\n"
        f"Exact record body ref: {ref}\n"
        f"Exact record body path relative to SOURCE_ROOT: {path}\n"
        f"Record output contract:\n{_json_exact(contract)}\n"
        "Record body preview (the full body is staged; never parse this preview as data):\n"
        f"{_line_projection(_json_exact(body), max_chars=16_000)}\n"
        "Read this record body and its original source files. Copy its ids exactly; "
        "map target values to those records using source evidence, not a separate id convention. "
        "Subset selection or reordering must retain the source-to-record association. "
        "For validation, the candidate target is the sole probe/*/stdout.txt file "
        "other than this exact record body path. Never take the first glob match. "
        "Compare source-derived expectations with the candidate, not hardcoded expected values."
    )


def _validate_prepared_output(
    runtime: Any,
    *,
    name: str,
    source_refs: Sequence[str],
    output_probe: Mapping[str, Any],
    python_code: str,
) -> tuple[dict[str, Any], str, dict[str, Any]]:
    output_ref = str(output_probe.get("stdout_ref") or "")
    if not output_ref.startswith("source_probe:"):
        return {}, "prepared output has no readable stdout ref", {}
    validation_probe, failure = _run_probe(
        runtime,
        purpose=f"validate prepared output {name}",
        source_refs=[*source_refs, output_ref],
        python_code=python_code,
    )
    review, failure = _read_validation_verdict(runtime, validation_probe, failure=failure)
    return review, failure, validation_probe


def _read_validation_verdict(
    runtime: Any, validation_probe: Mapping[str, Any], *, failure: str = "",
) -> tuple[dict[str, Any], str]:
    failure = failure or _probe_failure(validation_probe)
    if failure:
        return {}, failure
    page = runtime.call_route(
        "source_read",
        {
            "source_ref": str(validation_probe["stdout_ref"]),
            "line_offset": 0,
            "line_limit": 50,
        },
    )
    content = str(page.get("content") or "").strip()
    if page.get("truncated") or "[line clipped]" in content:
        return {}, "validator verdict exceeded the bounded result size"
    try:
        review = json.loads(content)
    except json.JSONDecodeError as exc:
        return {}, f"validator verdict is not JSON: {exc}"
    issues = _review_payload_issues(review)
    if issues:
        return {}, "validator verdict invalid: " + "; ".join(issues)
    return dict(review), ""


def _validate_prepared_record_identity(
    runtime: Any,
    *,
    name: str,
    output_probe: Mapping[str, Any],
) -> tuple[list[str], str, dict[str, Any]]:
    output_ref = str(output_probe.get("stdout_ref") or "")
    if not output_ref.startswith("source_probe:"):
        return [], "prepared output has no readable stdout ref", {}
    probe, failure = _run_probe(
        runtime,
        purpose=f"validate prepared record identity {name}",
        source_refs=[output_ref],
        python_code=_RECORD_IDENTITY_CHECK_CODE,
    )
    if failure:
        return [], failure, probe
    page = runtime.call_route(
        "source_read",
        {
            "source_ref": str(probe["stdout_ref"]),
            "line_offset": 0,
            "line_limit": 20,
        },
    )
    content = str(page.get("content") or "").strip()
    if page.get("truncated") or "[line clipped]" in content:
        return [], "record identity verdict exceeded result size", probe
    try:
        verdict = json.loads(content)
    except json.JSONDecodeError as exc:
        return [], f"record identity verdict is not JSON: {exc}", probe
    if not isinstance(verdict, Mapping):
        return [], "record identity verdict must be an object", probe
    applicable = verdict.get("applicable")
    raw_issues = verdict.get("issues")
    if not isinstance(applicable, bool) or not isinstance(raw_issues, list):
        return [], "record identity verdict shape invalid", probe
    if any(not isinstance(item, str) for item in raw_issues):
        return [], "record identity issues must be strings", probe
    return (
        [str(item) for item in raw_issues] if applicable else [],
        "",
        probe,
    )


def _is_json_media_type(value: Any) -> bool:
    media_type = str(value or "").lower().split(";", 1)[0].strip()
    return media_type == "application/json" or media_type.endswith("+json")


def _review_payload_issues(value: Any) -> list[str]:
    if not isinstance(value, Mapping):
        return ["verdict_must_be_object"]
    issues: list[str] = []
    if not isinstance(value.get("accepted"), bool):
        issues.append("accepted_must_be_boolean")
    if not str(value.get("summary") or "").strip():
        issues.append("summary_required")
    raw_issues = value.get("issues")
    if not isinstance(raw_issues, list) or any(
        not isinstance(item, str) for item in raw_issues
    ):
        issues.append("issues_must_be_string_array")
    return issues

def _run_probe(
    runtime: Any,
    *,
    purpose: str,
    source_refs: Sequence[str],
    python_code: str,
) -> tuple[dict[str, Any], str]:
    if not str(python_code).strip():
        return {}, "generated Python was empty"
    try:
        result = dict(
            runtime.call_route(
                "source_probe",
                {
                    "purpose": purpose,
                    "source_refs": list(source_refs),
                    "python_code": str(python_code),
                    "timeout_seconds": 120,
                },
            )
        )
    except Exception as exc:
        return {}, f"execution route failed: {type(exc).__name__}: {exc}"
    return result, _probe_failure(result)


def _probe_failure(result: Mapping[str, Any]) -> str:
    if result.get("status") != "source_probe_succeeded":
        return (
            "execution failed: "
            + _bounded(result.get("stderr_preview"), 2_000)
        )
    if not str(result.get("stdout_preview") or "").strip():
        return "execution produced empty standard output"
    return ""


def _publish_result(
    runtime: Any,
    *,
    summary: str,
    status: str,
    prepared_outputs: Sequence[Mapping[str, str]],
    residual_issues: Sequence[str],
    trace_refs: set[str],
    output_reviews: Sequence[Mapping[str, Any]],
    requested_count: int,
    depends_on: Sequence[str] = (),
    evaluation_binding: Mapping[str, Any] | None = None,
    preparation_design: Mapping[str, Any] | None = None,
    source_bindings: Sequence[Mapping[str, str]] = (),
) -> dict[str, Any]:
    machine_payload = {
        "artifact_kind": "prepared_source_data",
        "prepared_outputs": [dict(item) for item in prepared_outputs],
    }
    residual_issues = list(residual_issues)
    output_reviews = [{"transformation_run_ref": None, "validation_run_ref": None, **item}
                      for item in output_reviews]
    if evaluation_binding is not None:
        binding = validate_evaluation_binding(evaluation_binding)
        machine_payload["evaluation_binding"] = binding
        if status == "complete":
            try:
                # Read accepted C4 bodies without publishing an unverified C2 result.
                by_name = {item["name"]: item for item in prepared_outputs}
                names = [binding["record_output_name"], binding["target_output_name"]]
                if any(name not in by_name for name in names):
                    raise ValueError("prepared_evaluation_body_missing")
                inputs, target = [read_prepared_output(runtime, by_name[name], consumer="prepare_source_data")
                                  for name in names]
                trace_refs.update((*inputs.trace_refs, *target.trace_refs))
                records = validate_record_table(inputs.content)
                validate_paired_targets(records, target.content)
            except (KeyError, RuntimeError, ValueError) as exc:
                status = "partial"
                residual_issues.append(str(exc))
                for review in output_reviews:
                    if review.get("name") in (binding["record_output_name"], binding["target_output_name"]):
                        review["accepted"] = False
                        review["issues"] = [*review.get("issues", []), str(exc)]
    receipt = runtime.publish_artifact(
        artifact_kind="prepared_source_data",
        artifact_id="prepared-source-data",
        title="Prepared source data",
        markdown=_manifest_markdown(
            summary=summary,
            status=status,
            outputs=prepared_outputs,
            residual_issues=residual_issues,
        ),
        summary=summary,
        status={
            "complete": "proposed",
            "partial": "draft",
            "blocked": "rejected",
        }[status],
        machine_payload=machine_payload,
        trace_refs=sorted(ref for ref in trace_refs if ref),
        depends_on=[str(ref) for ref in depends_on if str(ref).strip()],
        self_review={
            "preparation_status": status,
            "requested_output_count": requested_count,
            "accepted_output_count": len(
                {item["name"] for item in prepared_outputs}
                & {item.get("name") for item in output_reviews if item.get("accepted")}
            ),
            "output_reviews": [dict(item) for item in output_reviews],
            "residual_issues": list(residual_issues),
            **({"preparation_design": dict(preparation_design),
                "source_bindings": [dict(item) for item in source_bindings]}
               if preparation_design is not None else {}),
        },
    )
    artifact_ref = str(receipt["artifact_ref"])
    stored = runtime.read_artifact(artifact_ref)
    if stored.get("artifact_kind") != "prepared_source_data":
        raise ValueError("source_preparation_readback_kind_mismatch")
    if stored.get("machine_payload") != machine_payload:
        raise ValueError("source_preparation_readback_payload_mismatch")
    review = stored.get("self_review", {})
    if (review.get("output_reviews") != output_reviews
            or (preparation_design is not None and (
                review.get("preparation_design") != dict(preparation_design)
                or review.get("source_bindings") != list(source_bindings)))):
        raise ValueError("source_preparation_readback_continuation_mismatch")

    return {
        "status": status,
        "summary": summary,
        "artifact_ref": artifact_ref,
        "prepared_output_count": len(prepared_outputs),
    }


def _design_issues(
    design: Mapping[str, Any],
    catalog: Mapping[str, Mapping[str, Any]],
    *,
    required_names: Sequence[str] = (),
    prior_binding: Mapping[str, Any] | None = None,
    target_ids: Sequence[str] = (),
    binding_required: bool = False,
) -> list[str]:
    outputs = design.get("outputs")
    if not isinstance(outputs, list):
        return ["outputs_must_be_array"]
    issues: list[str] = []
    if design.get("status") == "complete" and not outputs:
        issues.append("complete_status_requires_output")
    residual_issues = design.get("residual_issues")
    if design.get("status") == "complete" and isinstance(residual_issues, list) and any(
        str(item).strip() for item in residual_issues
    ):
        issues.append("complete_status_forbids_residual_issues")
    names: set[str] = set()
    for index, value in enumerate(outputs):
        if not isinstance(value, Mapping):
            issues.append(f"outputs[{index}]_must_be_object")
            continue
        name = str(value.get("name") or "").strip()
        if not name:
            issues.append(f"outputs[{index}].name_required")
        elif name in names:
            issues.append(f"outputs[{index}].duplicate_name:{name}")
        names.add(name)
        if not str(value.get("media_type") or "").strip():
            issues.append(f"outputs[{index}].media_type_required")
        if not str(value.get("description") or "").strip():
            issues.append(f"outputs[{index}].description_required")
        paths = value.get("source_paths")
        if not isinstance(paths, list) or not paths:
            issues.append(f"outputs[{index}].source_paths_required")
        else:
            for raw_path in paths:
                path = _normalize_path(raw_path)
                if path not in catalog:
                    issues.append(f"outputs[{index}].unknown_source_path:{path}")
        checks = value.get("acceptance_checks")
        if not isinstance(checks, list) or not any(
            str(item).strip() for item in checks
        ):
            issues.append(f"outputs[{index}].acceptance_checks_required")
    if "evaluation_binding" not in design:
        issues.append("evaluation_binding_answer_required:object_or_null")
    elif design["evaluation_binding"] is not None:
        try:
            binding = validate_evaluation_binding(design["evaluation_binding"])
            if target_ids and binding["target_id"] not in target_ids:
                issues.append(
                    "evaluation_binding_target_id_mismatch:"
                    f"expected_one_of={list(target_ids)}:actual={binding['target_id']}"
                )
            for key in ("record_output_name", "target_output_name"):
                if binding[key] not in names:
                    issues.append(f"evaluation_binding_output_not_designed:{binding[key]}")
        except ValueError as exc:
            issues.append(str(exc))
    if (binding_required or prior_binding is not None) and (
        design.get("status") == "complete" and design.get("evaluation_binding") is None
    ):
        issues.append("complete_repair_must_retain_evaluation_binding")
    if required_names:
        expected = [str(item).strip() for item in required_names if str(item).strip()]
        actual = [
            str(item.get("name") or "").strip()
            for item in outputs
            if isinstance(item, Mapping)
            and str(item.get("name") or "").strip()
        ]
        if not set(expected).issubset(actual):
            issues.append(
                "retry_must_retain_previous_output_names:"
                f"expected={expected}:actual={actual}"
            )
    return issues


def _source_catalog(inventory: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    catalog: dict[str, dict[str, Any]] = {}
    for raw in inventory.get("entries") or ():
        if not isinstance(raw, Mapping):
            continue
        path = _normalize_path(raw.get("relative_path"))
        ref = str(raw.get("source_ref") or "")
        if path and ref.startswith("source_file:"):
            catalog[path] = dict(raw)
    return catalog


def _canonicalize_known_source_paths(
    design: Mapping[str, Any],
    catalog: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    """Convert only current-inventory source refs back to their relative paths."""
    paths_by_ref: dict[str, list[str]] = {}
    for path, entry in catalog.items():
        ref = str(entry.get("source_ref") or "").strip()
        if ref.startswith("source_file:"):
            paths_by_ref.setdefault(ref, []).append(path)
    exact_aliases = {
        ref: paths[0]
        for ref, paths in paths_by_ref.items()
        if len(paths) == 1
    }
    normalized = dict(design)
    outputs = design.get("outputs")
    if not isinstance(outputs, list):
        return normalized
    normalized_outputs: list[Any] = []
    for raw_output in outputs:
        if not isinstance(raw_output, Mapping):
            normalized_outputs.append(raw_output)
            continue
        output = dict(raw_output)
        source_paths = raw_output.get("source_paths")
        if isinstance(source_paths, list):
            output["source_paths"] = [
                exact_aliases.get(str(value).strip(), value)
                for value in source_paths
            ]
        normalized_outputs.append(output)
    normalized["outputs"] = normalized_outputs
    return normalized


def _inspection_arguments(
    name: str,
    arguments: Mapping[str, Any],
    catalog: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    resolved = dict(arguments)

    def resolve(value: str) -> str:
        # Preserve supplied exact refs, including stale refs, for source validation.
        path = _normalize_path(value)
        return _source_ref(path, catalog) if path in catalog else value

    if name == "source_read" and isinstance(resolved.get("source_ref"), str):
        resolved["source_ref"] = resolve(resolved["source_ref"])
    if name in {"source_search", "source_probe"} and isinstance(resolved.get("source_refs"), list):
        resolved["source_refs"] = [resolve(value) for value in resolved["source_refs"]]
    return resolved


def _source_ref(
    relative_path: str,
    catalog: Mapping[str, Mapping[str, Any]],
) -> str:
    path = _normalize_path(relative_path)
    entry = catalog.get(path)
    if not entry:
        raise ValueError(f"source_preparation_unknown_path:{path}")
    ref = str(entry.get("source_ref") or "")
    if not ref.startswith("source_file:"):
        raise ValueError(f"source_preparation_invalid_source_ref:{path}")
    return ref


def _probe_refs(probe: Mapping[str, Any]) -> set[str]:
    return {
        str(probe.get(key) or "")
        for key in ("code_ref", "stdout_ref", "stderr_ref", "manifest_ref")
        if str(probe.get(key) or "")
    }


def _inspection_findings(runtime: Any, source_ref: str) -> str:
    pages: list[str] = []
    offset = 0
    used = 0
    while True:
        page = runtime.call_route("source_read", {
            "source_ref": source_ref, "line_offset": offset,
            "line_limit": _SOURCE_OBSERVATION_PAGE_LINES,
        })
        if not isinstance(page, Mapping) or page.get("status") != "source_page_ready":
            raise ValueError(f"source_preparation_inspection_page_invalid:ref={source_ref}:offset={offset}:result={page}")
        content = str(page.get("content") or "")
        if not content and not pages:
            raise ValueError(f"source_preparation_inspection_content_empty:ref={source_ref}")
        pages.append(content)
        used += len(content)
        next_offset = page.get("next_line_offset")
        if next_offset is None:
            break
        if isinstance(next_offset, bool) or not isinstance(next_offset, int) or next_offset <= offset:
            raise ValueError(f"source_preparation_inspection_pagination_stalled:ref={source_ref}:offset={offset}:next={next_offset}")
        if used >= _MAX_SOURCE_OBSERVATION_CHARS_PER_FILE:
            pages.append(f"REPORT\tinspection_excerpt_truncated=true\tref={source_ref}\tnext_line_offset={next_offset}")
            break
        offset = next_offset
    return "\n".join(pages)


def _source_content_findings(
    runtime: Any,
    catalog: Mapping[str, Mapping[str, Any]],
) -> str:
    """Read bounded source excerpts so the model can honor semantic transforms."""
    lines: list[str] = []
    used = 0
    globally_truncated = False
    for path in sorted(catalog):
        entry = catalog[path]
        if entry.get("text_likely") is not True:
            lines.append(f"CONTENT\t{path}\tstatus=not_text_likely")
            continue
        source_ref = str(entry.get("source_ref") or "").strip()
        if not source_ref:
            lines.append(f"CONTENT\t{path}\tstatus=source_ref_missing")
            continue

        offset = 0
        per_file_used = 0
        file_truncated = False
        while True:
            page = runtime.call_route(
                "source_read",
                {
                    "source_ref": source_ref,
                    "line_offset": offset,
                    "line_limit": _SOURCE_OBSERVATION_PAGE_LINES,
                },
            )
            if not isinstance(page, Mapping) or page.get("status") != "source_page_ready":
                raise ValueError(
                    f"source_preparation_source_page_invalid:path={path}:ref={source_ref}:offset={offset}:result={page}"
                )
            content = str(page.get("content") or "")
            for line_index, raw_line in enumerate(content.splitlines(), start=offset + 1):
                rendered = (
                    f"CONTENT\t{path}\tline={line_index}\t"
                    + raw_line.replace("\t", " ").replace("\r", " ")
                )
                addition = len(rendered) + (1 if lines else 0)
                if (
                    used + addition > _MAX_SOURCE_OBSERVATION_CHARS
                    or per_file_used + addition
                    > _MAX_SOURCE_OBSERVATION_CHARS_PER_FILE
                ):
                    file_truncated = True
                    globally_truncated = True
                    break
                lines.append(rendered)
                used += addition
                per_file_used += addition
            if file_truncated:
                break
            next_offset = page.get("next_line_offset")
            if next_offset is None:
                break
            if isinstance(next_offset, bool) or not isinstance(next_offset, int):
                raise ValueError(
                    f"source_preparation_source_next_offset_invalid:path={path}"
                )
            if next_offset <= offset:
                raise ValueError(
                    f"source_preparation_source_pagination_stalled:path={path}"
                )
            offset = next_offset
        if file_truncated:
            lines.append(f"REPORT\t{path}\tcontent_observation_truncated=true")
        if used >= _MAX_SOURCE_OBSERVATION_CHARS:
            break
    if globally_truncated:
        lines.append("REPORT\tcontent_observation_global_budget_reached=true")
    if not lines:
        return "REPORT\tno_text_source_content_observed=true"
    return "\n".join(lines)


def _findings_for_paths(
    source_findings: str,
    paths: Sequence[str],
) -> str:
    allowed = {_normalize_path(path) for path in paths}
    selected: list[str] = []
    for line in source_findings.splitlines():
        parts = line.split("\t", 2)
        if line.startswith("REPORT\t"):
            selected.append(line)
        elif len(parts) >= 2 and _normalize_path(parts[1]) in allowed:
            selected.append(line)
    if not selected:
        selected.append(
            "REPORT\tno_projected_structural_line_for_selected_paths=true"
        )
    return _line_projection("\n".join(selected), max_chars=24_000)


def _line_projection(value: str, *, max_chars: int) -> str:
    text = str(value or "").strip()
    if len(text) <= max_chars:
        return text
    kept: list[str] = []
    used = 0
    lines = text.splitlines()
    for line in lines:
        addition = len(line) + (1 if kept else 0)
        if used + addition > max_chars - 100:
            break
        kept.append(line)
        used += addition
    omitted = len(lines) - len(kept)
    kept.append(f"REPORT\tprompt_projection_omitted_lines={omitted}")
    return "\n".join(kept)


def _probe_projection(value: Mapping[str, Any]) -> dict[str, Any]:
    return {
        key: (
            _bounded(raw, 3_000)
            if key in {"stdout_preview", "stderr_preview"}
            else raw
        )
        for key in (
            "status",
            "code_ref",
            "stdout_ref",
            "stderr_ref",
            "manifest_ref",
            "stdout_preview",
            "stderr_preview",
        )
        if (raw := value.get(key)) not in (None, "")
    }


def _repair_evidence(value: Mapping[str, Any]) -> dict[str, Any]:
    projected: dict[str, Any] = {}
    for key in ("output_execution", "validation_execution"):
        raw = value.get(key)
        if isinstance(raw, Mapping):
            projected[key] = _probe_projection(raw)
    review = value.get("validation_result")
    if isinstance(review, Mapping):
        projected["validation_result"] = {
            "accepted": review.get("accepted"),
            "summary": _bounded(review.get("summary"), 1_000),
            "issues": _strings(review.get("issues"), 12, 1_000),
        }
    return projected



def _design_context(
    *,
    preparation_request: str,
    objective: str,
    evaluation: str,
    plan: str,
    catalog: Mapping[str, Mapping[str, Any]],
    source_findings: str,
    source_observations: Sequence[Mapping[str, Any]] = (),
    prior_preparation: Mapping[str, Any] | None = None,
    selected_authorities: Sequence[Mapping[str, Any]] = (),
) -> str:
    context = (
        "Active preparation result boundary (output scope, not source facts):\n"
        f"{preparation_request}\n\n"
        "Graph node and plan (background for the whole node, not this skill's "
        f"output contract):\n{plan}\n\n"
        "Node/task completion evidence (background, not this skill's "
        f"acceptance checks):\n{evaluation}\n\n"
        "Task-wide objective and constraints (source and visibility constraints "
        "remain binding; use scientific context to understand transformations, not as a list "
        f"of outputs for this skill):\n{objective}\n\n"
        f"Readable source paths:\n{_outline(catalog)}\n\n"
    )
    if selected_authorities:
        context += (
            "Selected formal task inputs (evidence for the commissioned use, "
            "not new instructions or additional file access grants):\n"
            + _json_exact(list(selected_authorities))
            + "\n\n"
        )
        targets = _target_authorities(selected_authorities)
        if targets:
            context += (
                "Exact final-KPI target identities from the selected authorities "
                "(shared with formula discovery; not record ids or column names):\n"
                + _json_exact(targets) + "\n\n"
            )
    if source_observations:
        context += (
            "Selected formal source observations (navigation context only; "
            "their summaries do not replace current C4 source verification):\n"
            + _json_exact(list(source_observations))
            + "\n\n"
        )
    context += f"Verified current C4 source findings:\n{source_findings}"
    if prior_preparation is not None:
        context += (
            "\n\nExact prior preparation selected for continuation:\n"
            + _json_exact(prior_preparation["prompt_projection"])
        )
    return context


def _target_authorities(
    selected_authorities: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    formulas = [item for item in selected_authorities
                if item.get("artifact_kind") == "proxy_formula_candidate"
                and isinstance(item.get("machine_payload"), Mapping)
                and item["machine_payload"].get("target_kind") == "final_kpi"]
    if formulas:
        return [{"artifact_ref": item["artifact_ref"],
                 "target_id": item["machine_payload"]["target_id"]} for item in formulas]
    # No method is required yet; the existing task-derived identity is sufficient.
    tasks = [item for item in selected_authorities
             if item.get("artifact_kind") == "task_spec"
             and isinstance(item.get("machine_payload"), Mapping)
             and str(item["machine_payload"].get("id") or "").strip()
             and str(item["machine_payload"].get("evaluation_priority") or "").strip()]
    return [{"artifact_ref": item["artifact_ref"],
             **final_kpi_target_metric([item], visible_historical={})} for item in tasks]


def _repair_design_context(
    *,
    preparation_request: str,
    objective: str,
    evaluation: str,
    plan: str,
    catalog: Mapping[str, Mapping[str, Any]],
    source_findings: str,
    source_observations: Sequence[Mapping[str, Any]] = (),
    design: Mapping[str, Any],
    issues: Sequence[str],
    prior_preparation: Mapping[str, Any] | None = None,
    selected_authorities: Sequence[Mapping[str, Any]] = (),
) -> str:
    return _design_context(
        preparation_request=preparation_request,
        objective=objective,
        evaluation=evaluation,
        plan=plan,
        catalog=catalog,
        source_findings=source_findings,
        source_observations=source_observations,
        prior_preparation=prior_preparation,
        selected_authorities=selected_authorities,
    ) + (
        "\n\n"
        f"Rejected design:\n{_json_exact(design)}\n\n"
        "Validation issues:\n- " + "\n- ".join(issues)
    )


def _validator_repair_context(
    *,
    source_findings: str,
    contract: Mapping[str, Any],
    validator_code: str,
    failure: str,
    verdict: Mapping[str, Any],
    candidate_output: Mapping[str, Any],
    validator_evidence: Mapping[str, Any],
    host_diagnosis: str,
) -> str:
    return (
        f"Output contract (output requirements; original sources own source facts):\n"
        f"{_json_exact(contract)}\n\n"
        f"{_SOURCE_PROBE_EXECUTION_ABI}\n\n"
        f"Verified source findings for the contract's paths:\n"
        f"{_line_projection(source_findings, max_chars=8_000)}\n\n"
        f"Exact host diagnosis:\n{host_diagnosis}\n\n"
        f"Exact validator failure or rejection:\n{failure}\n\n"
        f"Previous verdict:\n{_json_exact(verdict)}\n\n"
        "Candidate prepared-body execution and bounded preview:\n"
        f"{_json_exact(_probe_projection(candidate_output))}\n\n"
        "Validator execution evidence:\n"
        f"{_json_exact(_probe_projection(validator_evidence))}\n\n"
        f"Previous validator program (fallible, not authority):\n{validator_code}"
    )


def _repair_context(
    *,
    purpose: str,
    source_findings: str,
    previous_code: str,
    validator_code: str,
    failure: str,
    contract: Mapping[str, Any],
    evidence: Mapping[str, Any],
) -> str:
    return (
        f"Program purpose:\n{purpose}\n\n"
        f"Output contract (output requirements; original sources own source facts):\n"
        f"{_json_exact(contract)}\n\n"
        f"{_SOURCE_PROBE_EXECUTION_ABI}\n\n"
        f"Exact failure:\n{failure}\n\n"
        f"Execution evidence:\n{_json_exact(_repair_evidence(evidence))}\n\n"
        f"Verified source findings for the contract's paths:\n"
        f"{source_findings}\n\n"
        f"Current validator program (diagnostic, not a new contract):\n{validator_code}\n\n"
        f"Previous complete code:\n{previous_code}"
    )


def _output_authoring_context(
    *,
    contract: Mapping[str, Any],
    source_findings: str,
    prior_issues: Sequence[str] = (),
) -> str:
    context = (
        "Output contract (sole output scope for this call):\n"
        f"{_json_exact(contract)}\n\n"
        f"{_SOURCE_PROBE_EXECUTION_ABI}\n\n"
        "Verified source observation for this output's paths:\n"
        f"{source_findings}"
    )
    issues = [str(item).strip() for item in prior_issues if str(item).strip()]
    if issues:
        context += (
            "\n\nExact validator issues from the previous attempt at this "
            "same named output:\n- " + "\n- ".join(issues)
        )
    return context


def _validator_authoring_context(
    *,
    contract: Mapping[str, Any],
    source_findings: str,
    source_paths: Sequence[str],
    candidate_output: Mapping[str, Any],
) -> str:
    return (
        "Output contract (output requirements; original sources own source facts):\n"
        f"{_json_exact(contract)}\n\n"
        f"{_SOURCE_PROBE_EXECUTION_ABI}\n\n"
        "Verified source observation for this output's paths:\n"
        f"{source_findings}\n\n"
        "Authoritative source paths:\n- "
        + "\n- ".join(source_paths)
        + "\n\nActual candidate prepared-body execution and bounded preview "
        "(observed output, not the expected answer; full body is staged for validation):\n"
        + _json_exact(_probe_projection(candidate_output))
        + "\n\nRequired verdict shape:\n"
        + _json_exact(_REVIEW_SCHEMA)
    )


def _outline(catalog: Mapping[str, Mapping[str, Any]]) -> str:
    return _line_projection(
        "\n".join(
            f"- {path} | bytes={entry.get('size_bytes', '?')} | "
            f"media_type={entry.get('media_type', '?')} | "
            f"text_likely={entry.get('text_likely', '?')}"
            for path, entry in sorted(catalog.items())
        ),
        max_chars=24_000,
    )


def _manifest_markdown(
    *,
    summary: str,
    status: str,
    outputs: Sequence[Mapping[str, str]],
    residual_issues: Sequence[str],
) -> str:
    lines = ["# Prepared source data", "", f"Status: {status}", "", summary]
    if outputs:
        lines.extend(["", "## Outputs"])
        for output in outputs:
            lines.append(
                f"- {output['name']} ({output['media_type']}): "
                f"{output['description']} [{output['content_ref']}]"
            )
    if residual_issues:
        lines.extend(["", "## Residual issues"])
        lines.extend(f"- {item}" for item in residual_issues)
    return "\n".join(lines)[:8_000]


def _normalize_path(value: Any) -> str:
    path = str(value or "").replace("\\", "/").strip().strip("/")
    parts = [part for part in path.split("/") if part and part != "."]
    if not parts or any(part == ".." for part in parts):
        return ""
    return "/".join(parts)


def _strings(value: Any, count: int, chars: int) -> list[str]:
    if not isinstance(value, list):
        return []
    return [
        _bounded(item, chars)
        for item in value[:count]
        if _bounded(item, chars)
    ]


def _json_exact(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        default=str,
        indent=2,
    )


def _bounded(value: Any, limit: int) -> str:
    text = str(value or "").strip()
    return text if len(text) <= limit else text[:limit]
