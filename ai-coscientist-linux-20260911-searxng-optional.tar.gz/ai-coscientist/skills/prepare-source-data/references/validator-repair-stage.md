# Prepared-output validator repair stage

Reconcile a validator that failed to execute, returned a malformed verdict, or
rejected a prepared body. This is its one local repair opportunity, before any
output repair motivated by that rejection. The output contract and source paths
remain unchanged. A well-formed rejection proves neither program is correct.

Apply the accompanying validator-authoring authority unchanged. Compare the
original contract, the current validator, source findings, actual candidate
output and validator execution. The transformation program is not supplied.
Correct a validator implementation defect or a
check that exceeds or misreads the contract. If the rejection correctly identifies
an output defect, return the validator unchanged; output repair will address it.
Never loosen a required check, alter the data to fit a mistaken check, or replace
validation with unconditional acceptance. Contract requirements define the output,
not source facts; apply the shared source-facts rules when they conflict. Neither
the validator nor its error message adds requirements. A numerical check must
implement the contract's stated relation, not contradict it through inconsistent
representations or precision assumptions.

`SOURCE_ROOT` is injected by the host as a `pathlib.Path`. A replacement
validator must use it directly and must not assign, redefine, delete, import
over, or shadow it. If the exact failure is
`source_probe_reserved_name_assignment:SOURCE_ROOT`, remove the assignment and
rewrite later path access to use the injected `SOURCE_ROOT`; returning the same
forbidden binding is not a repair.

Return one complete replacement validator, not a patch or explanation. It must
read the full sources and prepared body and print only the required small JSON
verdict.
