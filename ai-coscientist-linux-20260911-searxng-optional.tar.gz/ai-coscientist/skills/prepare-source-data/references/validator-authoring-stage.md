# Prepared-output validator authoring stage

Write short executable Python that validates exactly one prepared body against
its description, media type, and acceptance checks.

The output contract defines the output requirements; original sources remain
the authority for source facts under the shared source-facts rules. The candidate
has already executed. Its exact ref and bounded preview show what was delivered,
not what is correct. The transformation program is deliberately not supplied.
Use the preview to locate fields, not to invent expected values or accommodate
an envelope outside the contract. First validate the body
itself according to the declared media type. For `text/markdown`, the body is
the Markdown text itself. For `application/json`, parse the body as the declared
JSON value.

For a JSON object with a top-level `records` array, also require every record to
have one non-empty id and require those ids to be unique. This is transport
identity, not scientific interpretation. Do not demand ids from JSON values
that do not expose a top-level `records` array.

`SOURCE_ROOT` is already injected as a `pathlib.Path`; never assign, redefine,
delete, import over, or shadow it. Original sources retain their listed relative
paths. Find the candidate body using `SOURCE_ROOT.glob("probe/*/stdout.txt")`,
excluding the exact bound record dependency path when the host supplies one.
Exactly one candidate must remain. The dependency is separately readable for
record-to-source mapping; never select the first glob match. Resolve the
candidate at runtime, not by inventing its probe id or reading standard input.
The current candidate ref in the prompt is for inspection and traceability,
not a constant to embed in validator code: the same validator must consume the
newly staged candidate after an output repair. Never read an older candidate.

The contract's `source_paths` are host-owned lineage metadata. Their presence
authorizes source reads and is not, by itself, a requirement that the prepared
body contain path strings, a provenance object, or a lineage section. Validate
body-embedded provenance only when an acceptance check explicitly requires it.

Read complete files. Parse JSON and other structured content before comparing
values or paths. Compute the expected content from those files using the declared
transformation, not copied per-record literals from the contract or candidate.
Apply that transformation to the source side only. Compare the expectation with
the delivered candidate values; do not complete a missing conversion, rescaling,
filtering, or derivation on the candidate side and then accept it. A body that
would become correct after such a repair is still incorrect as delivered.
Parsing and contract-permitted equivalent representations are allowed, but
must not conceal a missing required transformation. Report the exact field and
source-derived expectation for a mismatch; leave data correction to output repair.
Check row-specific mappings as well as counts and numeric values. Do not search
serialized JSON for unescaped values or assume a
root object is a record list. Treat the declared media type as part of the
interface. For text, account for UTF-8 BOM and universal-newline normalization;
use byte equality only when the contract explicitly requires an exact binary
copy.

For semantic text-preservation checks, normalize ordinary case and whitespace
differences. A phrase quoted inside an acceptance check is a semantic evidence
marker, not an implicit case-sensitive substring requirement. Enforce exact
spelling, case, whitespace, or bytes only when the contract explicitly requires
that exactness.

Do not turn open-ended prose meaning into a keyword-presence or keyword-absence
test. In particular, a sentence that explicitly says it does not assert a
hypothesis, formula, or conclusion satisfies that boundary; the noun appearing
inside the disclaimer is not itself a violation. Public definitions, targets,
and constants that the contract explicitly preserves are not private per-record
observations. Distinguish them by their source context instead of rejecting the
same number everywhere in the body.

When the contract describes source-preserving redaction or removal, validate a
conservation invariant instead of inventing semantic keywords or paraphrases:
after permitted encoding and newline normalization, every non-removed source
span remains in the output in source order, and only contract-authorized spans
are absent. Do not translate broad source sections into synonym lists. Do not
require wording that is absent from the source itself.

Treat each acceptance-check string as one logical condition. Alternatives
joined by words such as `or`, and non-binding examples introduced by `e.g.`,
must not be expanded into several conditions that all have to pass. Do not add
exact spelling, formatting, or content requirements that the contract does not
declare.

Print exactly one small JSON object with `accepted` as a boolean, `summary` as a
string, and `issues` as an array of strings. Do not rewrite the body, weaken an
acceptance check, or infer a downstream scientific conclusion. Return only the
existing `python_code` result shape.

Independently enforce every visibility and removal check against the complete
original sources and prepared body. When the contract distinguishes public
definitions or targets from withheld record observations, verify both sides:
the prohibited observations are absent and the required public meaning remains.
