# Preparation Scope and Scoring Dataset Binding

## Prepare for the commissioned use

Original-source preservation is not an instruction to score every source row.
Inspect the actual representations and source-backed definitions before fixing
output contracts: distinguish parsing or normalization work, supported identity
or field mappings, and genuinely absent information. Do not treat the raw file
as already suitable for a downstream calculation.

The main agent owns the research scope. A preparation commission may specify
rows or give source-grounded eligibility criteria instead of a fixed count.
Implement those criteria using the inspected sources, not a preferred score or
an assumed row count. A missing attribute alone does not make a record unusable
for every method; applicability depends on the commissioned use. Do not invent
a scientific method or an identity to make more rows eligible.

Design for the commissioned use, not an incidental count of files or tables.
The main agent need not spell out output names or the storage schema. A request
to prepare data for calculation and trend scoring requires the calculation and
scoring inputs defined below, even if its shorthand describes a record table.
Choose the smallest sufficient set of named bodies. This does not authorize
preparing every future task input: research-only preparation remains research-only.
Keep source measurements needed for that research. A future Materializer use
does not make research measurements forbidden or require their removal.
An explicit human restriction on permitted outputs or access remains binding;
if it conflicts with the commissioned use, retain feasible outputs and identify
the conflict as an unmet requirement instead of declaring the use fulfilled.

When the method or its required inputs are not yet established, complete the
supported parsing, normalization and mapping for research use, keeping unknowns
explicit. Use the existing output descriptions and acceptance checks to define
that scope and its limitations; prepare separately readable bodies only when
the commission needs them. Do not freeze a scoring scope merely because the
overall task will eventually need a score. Such preparation can be complete
with `evaluation_binding: null`; it is not proof that a scoring dataset is ready.
If the current commission itself requires a scoring dataset that cannot be
derived, report that unmet requirement through the existing partial/blocked
result instead of silently redefining the commission.

Keep original sources unchanged and selected records traceable. A source gap
must not be replaced with a guess; a parser defect must not be disguised as a
source gap or fixed by silently excluding the failing row. Once output contracts
are fixed, authoring and repair implement them rather than reselecting scope.

## Bind a selected scoring dataset

When the current preparation commission includes preparing a dataset for proxy
scoring and the scope and target transformation are supported by the sources,
set `evaluation_binding` to the supplied object shape. Every private design must
answer this field, including provisional source-location proposals and repairs.
Otherwise set it to `null`, explain why in the existing summary, and report any
unmet current requirement. The public manifest omits a null binding; a non-null
binding uses the existing object unchanged. Source-location
proposals remain provisional, not fabricated
evidence that a scoring dataset already exists.

`target_id` identifies the scientific scoring objective, not the row key,
source column, or an example record. The context supplies exact identities
using the same domain function as Formula discovery. An explicitly selected
Formula supplies its frozen identity; before a Formula exists, a selected
TaskSpec supplies the existing task-derived identity. Choose the identity for
the commissioned objective from those authorities; never fabricate one. If
the necessary authority is absent or conflicting, preserve feasible bodies and
report that gap instead of declaring scoring readiness.

Preparing a target and selecting calculation features are different operations.
Before a concrete method establishes a narrower feature set, preserve the
source-backed scientific identities, composition, representations and conditions
within the commissioned record scope. Numeric features alone are not necessarily
sufficient inputs. Do not collapse distinct source entities into one generic
feature merely because their amounts or other numeric values happen to match.
An `id` is a transport key: scientific identity must remain available outside
that key in the prepared content. No particular field name is required.

One named record body may serve both research and calculation. When the same
rows and representation meet both uses, bind that body directly rather than
create a second, reduced copy. Create another representation only for a concrete
method, commissioned transformation or access requirement. Preserve the
distinctions needed by that use and describe intentional losses in the existing
output description and acceptance checks. This is not a requirement to retain
every source field or expose restricted data.

For each designed record body, state which source distinctions must survive
and which transformations are authorized. Its validator compares those
distinctions against the source, not only record count, matching ids or numeric
fractions. A reduced body is not adequate just because a richer sibling still
contains the omitted information: downstream execution uses the bound body.

The target body is readable task data, not automatically evaluator-private.
Retain explicit source access limits; never copy restricted content to bypass
them. Do not request an extra grant merely because a measurement is a target.
A source may supply raw measurements while
the task defines a transformed scoring target: apply that source-supported
definition explicitly, rather than assuming that any numeric column is the target.

The binding names two distinct prepared outputs: calculation input records and
the corresponding target values. Both use the same stable source-record IDs.
The target body is exactly `{"records":[{"id":"source-id","value":1.0}]}`;
this is a shape example, never permission to generate demonstration measurements.
Values must come from the actual source or the task's explicit transformation.
Never substitute zero for unknown values or choose rows for favorable scores.

Explain the commissioned selection using source evidence, including relevant
exclusions, in the existing `selection_reason`. Preserve original IDs when
selecting a subset. If the source
has no IDs, derive stable IDs from original source rows, not the filtered row
positions. Separate experiments remain separate even when formulations match.
Do not invent identities or structures to fill missing scientific information.

For each bound output, the original-row selection, inclusion/exclusion rationale
and target transformation are part of its contract. Each validator must compare
its output with those original rows, independently of the transformation code.
Completeness means the contracted selection, not the entire source row count
unless that is what the commission requires.
Matching the two output ID sets alone does not prove that values were taken from
the right source rows. The binding selects calculation inputs separately from
comparison targets; do not make target values undeclared formula features.
Research context may retain original measurements and explain how a transformed
target was obtained. Preserve necessary definitions and known structures when needed to
interpret the records; a path alone is not their content.

The host produces and accepts the bound record body before its target body.
Target authoring, validation and repair receive that exact record body's ref,
staged path, contract and original sources. Read the full staged body and preserve
its IDs; do not independently regenerate them. Match each selected record to its
source row before computing the target, including subsets, reordered records and
separate experiments with identical formulations. An equal ID set is necessary
but does not prove correct source-row mapping.

Pair checks run before target acceptance, using exact readback, matching unique
IDs and finite target values. A failed pair uses the existing output repair, not
another model judge or additional retry. Publication repeats the same check as a
backstop. Local structural repair must return the complete design, including
its intended binding; adding a missing body is not permission to drop the
binding. Correct a wrong target identity against the supplied authority, not by
changing the scientific target. A complete repair cannot silently omit an
existing binding. A genuine unresolved conflict remains partial or blocked.

Continuation can use an explicitly selected prior preparation even when that
skill called it complete: its bodies may be accepted while its new commissioned
use is not yet fulfilled. Apply the design stage's continuation rules, including
exact contract/source/run checks before reusing a body. Target execution inputs
must include the current exact record body; a changed record dependency or an old
target computed without it requires recomputation, not reuse. A revised design may
change named outputs; the publisher creates a new immutable manifest and leaves
the previous version as historical evidence. An output name alone does not
establish unchanged content or force a rename. Previous binding metadata is visible
evidence, not an immutable rule that would prohibit correcting its identity.

Before returning the design, compare the proposed bodies and acceptance checks
with the commissioned use. Successful validation of a public table alone does
not satisfy a request for scoring inputs. Record genuine missing inputs or
conflicting constraints in the existing status and residual_issues; do not make
the request smaller merely so that every proposed body can pass validation.
