# Prepared-output design continuation

Decide whether the explicitly selected stored preparation design still fulfills
the current commission, using the current source evidence and prior execution
failures. This replaces initial design generation; it is not another review.

Return exactly one of the two alternatives in the supplied tool schema:

- `{"decision":"reuse"}`: keep the entire stored `preparation_design`.
  Do not return a design, paraphrase its fields, or retype its reference. The
  host reads the stored design exactly, including descriptions and checks.
- `{"decision":"revise","design":{...}}`: submit a complete revised design
  in the existing design shape. Use this when the current commission or source
  evidence requires a different design. Explain the change in its existing
  `summary`; do not add a separate reason field.

A transformation or validator defect calls for program repair under the same
contract, not a rewritten contract. `reuse` does not accept a failed body or
declare the preparation complete: the host still checks exact sources and
execution lineage, then resumes the existing repair stages where needed.

Changed source content may still fit the same design. You may reuse that design,
but the host must compute new results from the current source version instead
of accepting an old body. If the change requires different paths, outputs,
checks, binding or feasibility status, revise the design. Do not disguise a
source or commission change by relaxing checks to fit an old result.

The following shared design rules define a new or revised design. They do not
require you to regenerate an unchanged design. Design status expresses source
feasibility, not the success of the previous program or validator.
