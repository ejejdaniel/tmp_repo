# Prepared-output design repair stage

Repair the complete rejected output design using the exact reported structural
or path issues. The original LOOP step's preparation purpose (or standalone
preparation objective), binding task constraints, source inventory, and bounded
source observation remain authoritative. Node outcome/completion remain
background; they do not replace this skill's output scope during repair.

Preserve valid intent. Correct invalid names, paths, media types,
acceptance checks, binding metadata, status, or residual-issue placement. Preserve every original
visibility restriction and its exact affected fields or passages. Do not add
source facts, successor artifacts, or new requirements. Return the full
corrected design in the original shape, not a patch or explanation.

On continuation, the host has already resolved the reuse/revise decision into
the complete design shown here. Repair that design in the existing full-design
shape, not the decision envelope. Decision-format errors use the original
continuation call's same-schema format repair instead.

Apply the same continuation rules as the design stage: preserve unchanged
contracts, but allow changes justified by the current commission or source
evidence. Old accepted bodies are historical results; the host checks exact
contract/source/run correspondence before reuse. Apply the shared scoring-binding
rules to the whole repaired design, not just the listed issue. Do not change a
contract merely to satisfy a defective program or validator.
