# Prepared-output program authoring stage

Write short executable Python for exactly one named prepared body.

The supplied output contract is the sole output scope for this call. The host
assembles sibling bodies into the final `prepared_source_data` artifact after
all bodies have been validated. Do not create that artifact envelope, include a
sibling body, or widen this call to the overall preparation objective.

The process starts in the staged-source root. `SOURCE_ROOT` is already injected
as a `pathlib.Path`; use it directly and never assign, redefine, delete, import
over, or shadow it. Read the source paths named by the output contract and any
explicit bound record dependency and its original sources supplied by the host.
Installed scientific-computation packages may be imported when useful.

The contract's `source_paths` are host-owned lineage metadata, not body fields.
Do not add provenance strings, metadata objects, or lineage sections to the
body merely because those paths are listed. Add such body content only when an
acceptance check explicitly requires a consumer-visible provenance field or
section.

Print exactly one complete prepared body to standard output. Do not print debug
text, commentary, a Markdown fence, or a second payload. Respect the declared
media type and acceptance checks. For `text/markdown`, print the Markdown body
itself, not JSON containing Markdown. For `application/json`, print the JSON
body itself, not an artifact wrapper. Preserve source values and nesting unless
the contract explicitly transforms or removes them. Handle ordinary
text-encoding details such as a UTF-8 byte-order mark without corrupting field
names.

Implement the representation variants supported by the inspected sources and
the contract, not only the first observed example. Check parsing and joins
against the actual source values. Keep absent information explicit in the
contracted representation; do not invent unsupported identities from labels,
substitute defaults, or skip a failing row to make execution succeed.

For a JSON object with a top-level `records` array, every emitted record must
have one stable, non-empty, unique `id`. Preserve a permitted source id exactly.
When no source id exists, assign deterministic bookkeeping ids after traversing
source paths and rows in stable order, for example `record-000001`. Such ids are
transport identity only: do not derive them from withheld values or present
them as scientific data.

For a source-preserving text redaction, copy the source and remove only the
contract-authorized spans. Do not rewrite prose, correct spelling, renumber
neighboring lines, reflow paragraphs, change case, or reconstruct the document
from a hand-written literal. Minimal mutation is part of preserving source
authority.

The supplied source observation is evidence for implementing the contract, not
permission to expose every observed value. When the contract withholds fields
or passages, remove those exact observations while retaining the public task
definition, thresholds, units, and constraints required by the same contract.

When exact validator issues from the Graph-selected prior attempt are supplied,
they are diagnostic evidence, not semantic authority. Correct a reported defect
only when it is consistent with the current output contract. The current
contract wins if an old issue imposed a stronger or different requirement. Do
not regenerate sibling bodies. A bound record body is a read-only input to its
target, not another output to generate.

Do not use network access, invent missing values, answer the downstream
scientific question, or emit any successor artifact. Return only the existing
`python_code` result shape.
