# Source facts and output requirements

The commission defines the intended use and permitted transformations. The
output contract defines the body shape, selected scope and transformation rules;
it is not a second copy of source facts. Original files own their row identities,
labels and values. A model-written description, acceptance check or prior verdict
cannot override those facts. This distinction applies during design, authoring,
validation, repair and continuation.

Describe checks as relations to source rows, fields and source-backed definitions,
not a hand-transcribed table of expected records. Constants that define an
authorized transformation are legitimate; copied observations are not new
constants. Derive each row's labels and values from that row, including variants
that differ from the first example. Do not impose the first row's keys on others.

Validation must independently derive expected content from the original sources
and the declared transformation. Reading a source file without using its contents
in comparisons is not source validation. Agreement with the candidate program or
an expected-value table copied from the design proves neither source fidelity nor
correct row mapping.

If a design assertion contradicts the source rather than defining a permitted
transformation, do not make either program enforce the false assertion. During
design or continuation, correct that assertion against the source. During program
validation, report the exact conflict through the existing rejected verdict and
issues; program repair must not silently redesign the output or fabricate data.
An unresolved conflict remains a partial/blocked preparation through the existing
bounded workflow. No new verdict type or review stage is required.
