# Prepare Source Data Design Brief

## Responsibility

`prepare-source-data` owns one bounded data-preparation result:

```text
mounted source files
-> bounded model-owned source location
-> structural inspection
-> named output design
-> executable transformation
-> independent validation
-> prepared_source_data publication and readback
```

It does not formulate the scientific task, build a mind map, draw scientific
conclusions, choose the next production skill, or replace open-ended source
exploration.

## Authority and handoff

| Input | Authority | Missing behavior |
| --- | --- | --- |
| Preparation output scope | Existing C1 `active_loop_step.purpose`; for standalone invocation, the explicit preparation objective and completion evidence | Report an unclear or unsupported preparation request, not a successor deliverable |
| Node and task context | Graph outcome/completion describe the larger result; C0 source, visibility, and user constraints remain binding | Do not promote the whole node outcome into this skill's output contract |
| Source content | Exact mission-mounted `source_file:*` refs in C4 | Do not use examples or synthesize values |
| Source observation | Mechanical structure plus bounded source excerpts retained only for this invocation in C5 | Treat observation failure as an implementation defect |
| Prepared body | Exact successful `source_probe:*:stdout` C4 ref | Do not substitute a preview or Markdown restatement |
| Scoring target identity | Explicit selected Formula target, otherwise the existing task-derived identity shared with Formula discovery | Do not substitute a row id or column name; unresolved scoring authority remains a gap |

The formal output is one immutable C2 `prepared_source_data` manifest. Its
`prepared_outputs` entries point to exact C4 bodies. Problem Formulation, Mind
Map Builder, and other authorized consumers resolve those refs through
`resolve_prepared_source_data`.

Publishing a revision creates a new artifact identity. Consumers must use the
explicitly supplied artifact ref; the workflow never guesses a global latest
manifest.

Continuation uses an explicitly selected complete, partial, or blocked
preparation, always read from the stored C2 revision. The approved optional
`self_review.preparation_design` retains the existing full design schema and
`self_review.source_bindings` is `[{relative_path, source_ref}]` for the selected
C4 versions. Each output review adds nullable `transformation_run_ref` and
`validation_run_ref`, both exact C4 probe-manifest refs. Unexecuted programs have
no run ref. No code or data is copied into C2; execution records stay in C4.

The design stage compares the original contract and observed failures with the
current commission. With a complete saved design/binding checkpoint, its output
is exactly `{"decision":"reuse"}` or `{"decision":"revise","design":{...}}`.
The host resolves reuse directly from stored C2; a revision uses the existing
design schema. This replaces, not follows, initial design generation. The
decision is transient C5, not a new persisted field. Common format repair uses
the same decision schema; full-design path/structure repair runs only after the
decision has been resolved. First preparation and legacy records without an
exact checkpoint retain the original design entry. Python checks equality
only to decide result reuse, not to reject a changed design. Accepted bodies retain
their refs only under the same per-output contract (including evaluation binding),
source versions, candidate and validation execution. Unresolved outputs restore
their executed programs and results before using the same local repair stages.
Legacy manifests remain readable, but without an exact design/binding/run chain
do not qualify for automatic reuse. No history is reconstructed from C3 or C6.
Reusing a design does not accept an output. If source content changes but the
design remains suitable, the model may reuse the design while the host computes
new results for the new exact source version.

This boundary covers a normal partial/blocked return, not a process killed before
publication. Skill-local and Node LOOP quotas do not increase. Producing every
body does not override a design that still reports a partial commission.

## C0-C6 mapping

| Class | Content | Retention and prompt use |
| --- | --- | --- |
| C0 | Objective, task constraints, completion condition | Exact relevant subset in every semantic stage; never rewritten |
| C1 | Active Graph node and current LOOP step | Step purpose defines this invocation's output scope; node outcome/completion stay background; Common owns lifecycle |
| C2 | `prepared_source_data` manifest, saved design, source bindings and per-output run refs | Immutable formal cross-skill and continuation authority |
| C3 | Unused by this bounded workflow | No temporary inspection ledger or completion receipt is written here |
| C4 | Mounted sources, generated code, stdout, stderr, manifests, prepared bodies | Full content remains behind exact refs; prompts receive paths and bounded structural projections |
| C5 | Structural findings, bounded source excerpts, output contracts, current programs, validator verdict, exact local repair issue | Replaced stage by stage and cleared when the skill returns |
| C6 | Prompt snapshots, model turns, route calls, and errors | Append-only diagnostics; never semantic model input |

## Model-call contracts

| Stage | Purpose | Inputs | Output | Validation and repair |
| --- | --- | --- | --- | --- |
| Source location | Locate task-specific inputs before profiling | Current LOOP step purpose, node background, binding C0 constraints, selected task artifacts, existing scoped source inventory/search/read tools | Existing preparation-design shape as provisional proposal | Exact path resolution; bounded tool calls retain precise failures |
| Output design | Define the smallest independently consumable prepared bodies on first preparation or without a complete checkpoint | Same step-scoped request and node/task context, C4 inventory/findings, selected C2 evidence | Existing preparation-design shape | Mechanical path/name/check validation; one same-contract design repair |
| Design continuation (instead of output design) | Keep the stored design or submit a justified revision | Same current request and source evidence, exact C2 saved design/bindings and execution gaps | `{decision: reuse}` or `{decision: revise, design: existing design}` | Same-schema format repair; resolve reuse from C2; resolved design gets existing validation and repair; result reuse still requires exact sources and runs |
| Output authoring | Write one executable transformation | One accepted output contract plus relevant C5 findings; a bound target also receives the accepted record body, its contract and original sources | Existing `{python_code}` shape | Execute through `source_probe`; identity/pairing failures use the same one program repair |
| Validator authoring | Write one validator after a candidate body has executed successfully and passed existing transport checks, using the existing scientific reasoning profile | Same contract and record dependency as authoring, original source findings/paths, exact candidate body ref and bounded preview; no transformation program | Existing `{python_code}` shape | Execute on complete staged source and candidate files and parse the existing verdict; judge delivered values, not a corrected candidate |
| Validator repair | Reconcile a failed or rejecting validator before output repair | Original contract, validator program only, exact failure/verdict and candidate/validation evidence; no transformation program | Existing complete validator code; unchanged if rejection is correct | Same validation authority as authoring; one repair on the same body, with no weakened contract |
| Output repair | Repair transformation mechanics or remaining contract mismatch | Original contract, transformation program, current validator if already created, exact failure and execution evidence | Existing complete transformation code | Re-execute; create the validator only when a usable body exists, otherwise reuse the current validator against the new exact body |

Source facts share the authority in `source-facts.md`. Data readiness and scoring
scope share the authority in `evaluation-binding.md`.
That same authority defines shared research/calculation bodies and preservation
of source distinctions. Design descriptions and acceptance checks carry these
requirements into authoring and validation; no new output fields, checker or
model stage is introduced. A scoring binding may select the research record
body itself when the commissioned rows and representation are the same.
Source location and design inspect representations and source-backed mappings
against the commission, not a presumed all-row scoring scope. The existing
descriptions and acceptance checks carry the selected preparation scope and
known limitations. Authoring, validation and repair implement that same scope;
they cannot drop a row to conceal a parser defect. An unresolved future method
does not invalidate a completed, faithfully limited research-data preparation,
but it cannot be presented as a completed scoring dataset. No new schema,
semantic validator, model call or production schedule is introduced.

Each stage loads its directly referenced prompt page and shared authority pages. Repair pages preserve
the original stage contract and add only the rejected program, exact issue, and
execution evidence.
Validator repair also loads `validator-authoring-stage.md` as its shared
validation authority. Both validator stages load `source-facts.md`, but not
`evaluation-binding.md`: their contract and bound record dependency already
define the selected output, and validators cannot redesign its scope or the
continuation plan. All other stages keep the full scope/binding guidance.
Validator authoring uses `scientific_call=True` and the configured
`scientific_reasoning_effort`; validator repair keeps the existing repair
profile. No new configuration, model call or output field is introduced.
The validator derives expected values by applying the
contract's transformation to original sources; it compares the resulting
expectation to values actually delivered. It must not apply a missing
transformation to the candidate to make it pass. Parsing and explicitly allowed
equivalent representations remain permitted. No Python semantic rule enforces
this principle; the model owns the validator implementation.
An execution or transport failure before a usable candidate does not spend a
validator-authoring call. Existing accepted results are not rewritten or
retroactively recertified by this change; exact continuation rules still apply.

Source location, output design, and design repair share the same context
projection. A Graph node may contain several skills; its outcome is not this
skill's deliverable. The current step's purpose is supplied by Common, not
inferred from node names or scientific keywords. Standalone calls use the
explicit preparation objective within this skill's responsibility. No new
payload fields are introduced for step scoping. The approved private design
requires `evaluation_binding`: the existing object defined in
`domain/prepared_evaluation.py`, or `null` when no scoring pair is commissioned
(explain in the existing summary). Initial design, continuation revisions and
repair use this same schema. The public binding stays optional and object-only.
Its C2 metadata points to two existing C4
bodies; no new memory class or scoring actor is added. All stage prompts load
`source-facts.md`; non-validator stages additionally load `evaluation-binding.md`.
Output authoring and validation receive the binding as
part of the same private output contract. The accepted record output is produced
before its bound target regardless of list order. Its exact C4 ref, contract and
original sources are shared by target authoring, validation and both repairs.
Pair shape/ID checks run before acceptance and feed the existing local repair;
publication retains the same check as a backstop. Scientific row mapping remains
the model-authored validator's responsibility. A failed record output blocks only
its dependent target, not unrelated outputs. No new repair quota is added.

Continuation reuses a target only when its recorded transformation/validation
inputs include the current exact record ref. Changed or previously unstaged
record dependencies require recomputation, even if original source refs match.
Older designs missing the binding answer remain readable but need a new design;
old artifacts and run history are never rewritten.

Skill-local source inspection uses the existing Common visible-tool-protocol
detector. When an assistant inspection turn includes bare wire-format control
text alongside native tool calls, only its malformed prose is omitted from the
next prompt. Native call identity, arguments, quota, and tool observations are
unchanged. Normal prose and quoted code examples remain. The raw model turn is
recorded in C6 before projection; this is not scientific summarization or an
additional model review.

## Fixed local workflow

The fixed sequence is valid because every stage jointly completes one formal
preparation responsibility. Source location uses a bounded tool conversation;
search order belongs to the model inside the skill. Later scientific work and
the next production skill remain outside this workflow. Per-file profiler
coverage and source_read pagination are separate bounded observations; neither
changes the complete files staged for transformation and validation.

The workflow permits one design repair, one validator reconciliation per
output, and one transformation repair per output. Continued failure is
published as a residual issue instead of leaking retries into the Common
planner.

## Validation

- Project skill structural validator.
- Focused workflow tests for exact refs, C3 non-pollution, stage disclosure,
  validation ownership, and local repair.
- Exact C4 producer-to-consumer replay.
- Small real-model preparation boundary using the two raw photolithography
  files, followed by `resolve_prepared_source_data` readback.
