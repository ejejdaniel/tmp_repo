# Prepared-output design stage

Design the smallest set of independently consumable named data bodies that
fulfills the active preparation result using only the supplied source authority.
This stage defines output contracts; it does not write code or data. Context is
ordered by authority: the current LOOP step's purpose defines the preparation
output scope; a standalone invocation uses its explicit preparation objective.
The Graph node's outcome and completion condition are background for the larger
result, not this skill's deliverable or acceptance checks. Task-wide source and
visibility constraints remain binding; later scientific outcomes stay context.

An explicitly selected `source_observation` is traceable navigation context,
not input-content authority. Use it to notice relevant structure, quality risks,
signals, and unresolved gaps, but resolve every output contract against the
current readable-source list and verified C4 findings. When an observation and
current source evidence differ, current source evidence wins. Do not copy an
observation claim into an output merely because it appears in a formal C2
envelope.

Structural profiles and content excerpts are bounded observations, not the
complete source. A REPORT truncation/depth marker or representative array item
means coverage is incomplete, not that the file is invalid. Use the supplied
source_read/source_probe tools for a focused additional observation when a
contract depends on an unobserved field or passage. Follow next_line_offset for
read pagination. In this skill's inspection calls, source_ref/source_refs accept
the exact paths in the readable-source list; the host resolves them to the
inventoried content references. Do not construct hashes. Full selected sources, not prompt excerpts, are staged for
transformation and validation. Do not require complete profiling of unrelated
regions before defining a supported transformation.

Apply the shared preparation-scope rules before choosing bodies and acceptance
checks. Use focused source inspection to resolve representation variants and
mapping evidence relevant to the requested transformation; a first example is
not evidence that every row has the same syntax. Do not turn unknown inputs to
an as-yet unselected scientific method into a blanket requirement to drop rows
or to declare ordinary research-data preparation impossible.

The preparation request is the output boundary. Node and task text may describe
later scientific work, but do not create a task specification, mind map,
hypothesis, formula, review, report, or any other successor result.

Each output must be one complete downstream-readable body. Use separate bodies
only when the preparation request or a named downstream interface actually requires
separately readable forms. Do not create a human-readable companion merely to
restate an existing task specification or describe a structured body. When both
interfaces are explicitly required, keep them separate. The publisher will create one
formal `prepared_source_data` manifest around those bodies, so never add a body
named `prepared_source_data` merely to represent the manifest.

For every body:

- choose a concise unique name;
- describe the emitted media type rather than copying the input media type;
- use only exact paths from the readable-source list;
- state the body meaning without claiming a downstream scientific conclusion;
- give concrete acceptance checks, including exact known structured paths when
  preservation, removal, or comparison is required.

Specify how to derive and compare the output from its sources, not the resulting
records. Even for a small source, do not restate every row's expected labels and
values in acceptance_checks. Follow the shared source-facts rules: this stage
designs a transformation, not a replacement dataset.

When an `application/json` body exposes a top-level `records` array for later
scientific processing, include an acceptance check that every record has one
stable, non-empty, unique `id`. Preserve an existing permitted source id. When
the source has no id, require the transformation to assign a deterministic
bookkeeping id from stable source and row order; the id carries no scientific
meaning and must not encode withheld values.

Formal lineage and body content are separate interfaces. `source_paths` and the
host-owned trace refs record where a body came from; they are not fields or text
that the generated body must repeat. Do not add an acceptance check requiring
source-path strings, provenance metadata, a lineage section, or source refs
inside the body unless the active preparation result explicitly requires that
consumer-visible content. In particular, do not append provenance prose to a
source-preserving redaction: its formal lineage is already retained by the host.

For text preservation, distinguish semantic fidelity from byte-for-byte or
case-sensitive copying. Use meaning-preserving checks unless the authoritative
objective explicitly requires exact text. Never combine contradictory wording
such as "verbatim in meaning"; state either the semantic content that must remain
or the exact source span and exactness requirement.

When one text output is a source-preserving redaction or field removal, express
one conservation rule: after newline and encoding normalization, the output
preserves the source in order with only the explicitly restricted spans removed.
Name those removable spans precisely. Do not expand all retained source content
into a long synonym or keyword checklist; the conservation rule covers it more
faithfully and is mechanically testable.

Every visibility, withholding, redaction, or allowed-field restriction in the
preparation objective is part of the output contract, within its stated
consumer and use scope. A scoring role alone is not a restriction, and a
calculation-input requirement must not be applied to research context. Use the bounded source
observation to identify the exact affected fields or source passages. State
their removal in the relevant acceptance checks and retain public definitions,
targets, units, and constraints that are not themselves withheld observations.
Do not copy a withheld value into a description, summary, or acceptance check.
Do not preserve every source field merely because it exists.

Use `application/json` for JSON and an appropriate `text/*` media type for
readable text. Use `application/octet-stream` only for opaque binary bytes.
Do not embed source data, infer missing values, or hide one requested interface
inside another.

Use `complete` only when every declared body is derivable from mounted sources.
`complete` must have no residual issues. A design that still names a missing
source, future artifact, or unresolved feasibility gap is `partial` or `blocked`.
Use `partial` or `blocked` for a real source or feasibility gap.
`residual_issues` contains only defects that would remain after the declared
bodies are generated and validated; it does not contain workflow steps or
future publication actions.

These rules also apply when a continuation decision submits a revised design.
A program or validator error does not redefine the promised data; repair that
program under the original contract. Change a contract, add or remove an output
only when the current commission or source evidence warrants it, and explain
that change in summary. An old output remains historical evidence, not automatic
satisfaction of a changed contract. Design status expresses source feasibility,
not whether a previous program ran successfully.

The host reuses only work with matching contracts and exact sources, and reads
the explicitly linked C4 executions before resuming. Changed contracts are
allowed, not rejected by a text-equality gate. Missing saved design/bindings
means fresh design from current sources, not reconstructed history. Source
inventory/search/read remain available for a newly needed file; unchanged
sources do not need another source-location model call.
