# Prepared-output program repair stage

Repair the complete transformation program for the same named output using the
exact execution failure or remaining validator rejection. The current validator
program is included so its diagnostic can be traced to the actual check. The
validator had its one reconciliation opportunity when its own rejection occurred;
it does not replace the original output requirements or source facts.

The supplied output contract defines this repair's output requirements;
original sources own source facts under the shared source-facts rules.
do not reopen task-wide output design. Correct only the implementation needed
to satisfy the source-backed contract and the exact failure. `SOURCE_ROOT` is already injected
as a `pathlib.Path`; use it directly and never assign, redefine, delete, import
over, or shadow it.

The failure is diagnostic evidence rather than a new requirement. If it asks
for wording, formatting, or semantics not required by the current contract, do
not propagate that addition. For source-preserving redaction, retain the source
in order and alter only contract-authorized spans.

Return one complete replacement program, not a patch or explanation. Standard
output must contain only the requested prepared body. Do not change the
scientific task, acceptance checks, data values, or output identity to make the
failure disappear.

For a parsing or mapping failure, compare the exact failing source value with
the program's format or lookup assumption and the source-backed contract.
Correct a supported representation mismatch in the implementation. Adding an
exception guard or dropping that row does not repair a required transformation.
If the information is truly absent, retain the precise unresolved reason rather
than inventing a value or broadening the accepted format without evidence.

If the exact failure reports missing or duplicate ids in a top-level `records`
array, preserve every permitted existing id and add only deterministic,
non-scientific bookkeeping ids where they were absent. Do not derive ids from
withheld values.
