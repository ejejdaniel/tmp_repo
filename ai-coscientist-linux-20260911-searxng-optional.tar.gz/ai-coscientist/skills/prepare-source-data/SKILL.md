---
name: prepare-source-data
description: "Produces prepared_source_data with validated named bodies. Requires authorized sources and intended use (research, calculation, or calculation plus scoring). Scoring includes paired inputs and targets via evaluation_binding; a research table alone is insufficient. Boundary: no invented data, method, result, or conclusion."
estimated_complexity: high
---

# Prepare Source Data

## Responsibility and boundary

Transform mission-scoped source files into one or more named, validated data
outputs and publish a small formal manifest that points to their exact stored
content.

Apply the shared [source-facts rules](references/source-facts.md)
at every internal stage. The design owns output requirements, not source facts;
validation derives expected content from sources rather than a copied answer table.
The [preparation scope rules](references/evaluation-binding.md) define record
sufficiency: retain source distinctions until
a concrete use justifies reducing them; research and calculation may share one
named body, with scientific identity preserved outside bookkeeping `id`.

This skill owns data preparation as one complete work unit: inspect enough of
the mounted sources to understand their real shape, design the requested
transformation, execute it with Python, validate each produced body, and publish
the result. It does not decide the downstream scientific conclusion, perform a
literature survey, replace a general source observation, or prescribe the next
production skill. It must not invent missing source values.

Source preservation and downstream eligibility are different. Apply the shared
[preparation scope rules](references/evaluation-binding.md) to distinguish
source-backed transformations, real information gaps and method-dependent
scoring selection. The main agent commissions the use; this skill implements
the corresponding preparation, not a fixed all-row or smallest-subset policy.

Simple incidental edits may use general coding capabilities directly. Select
this skill when preparation itself needs an independently reviewable output,
bounded local repair, and a formal downstream handoff.

## Entry conditions and authority

The mission must provide an explicit preparation request, plus at least one
file or directory through the mission source allowlist. In a LOOP, the current
step's `purpose` defines this skill's output scope. The Graph node's outcome and
completion condition describe the larger result, possibly shared with other
skills; they are background, not this skill's deliverable or acceptance checks.
A standalone invocation uses its explicit preparation objective and completion evidence. C0 source,
visibility, and user constraints remain binding in either case, but later
scientific outcomes cannot add successor outputs here. Mounted source files are
the only input-content authority.

Use the shared [preparation scope rules](references/evaluation-binding.md) to
translate the intended use into sufficient bodies and acceptance checks. The
commission need not dictate storage fields or output counts. Measurements in
task-scoped sources are ordinary research data unless explicitly restricted.
Scoring roles define use, not access. Research-only preparation does not promise
scoring readiness and must not redact measurements for a future consumer.

An exact selected `source_observation` C2 ref may provide navigation context
only when the current LOOP step lists it in `input_refs`. The workflow projects
its bounded structure, quality, signals, unknowns, and trace refs into the design
stage, then verifies current C4 sources independently. Observation prose never
overrides mounted content, and an unselected observation is invisible.

On a later attempt, an exact prior `prepared_source_data` is also an
input authority for retry state only when it is listed in the same Graph node's
`attempt_refs`, selected directly by the current LOOP step, or listed in
`still_usable_refs` by a `graph_revision_outcome` selected by that LOOP step. The workflow reads the
stored C2 design and source bindings, then restores linked C4 executions.
Unchanged contracts and sources may reuse accepted bodies or repair the unresolved
programs. Changed contracts/sources require fresh computation. Legacy manifests
without a saved design remain readable but cannot certify exact continuation.
It never treats an
arbitrary resolved artifact, revision dependency, or failed attempt result as a
retry predecessor.

The workflow uses source_inventory to obtain readable paths and exact source
refs. It uses source_probe from the staged-copy root. The route injects
SOURCE_ROOT as an existing pathlib.Path; generated programs may read through it
but must not assign or shadow it. The workflow retains code, standard output,
standard error, and a manifest as C4 refs. A validation probe consumes the exact
prior output ref plus
its authoritative source refs, reads their full staged copies, and emits a small
verdict. read_ref inspects that bounded verdict before acceptance; it is not
used to pretend that a clipped large-output preview is the complete body.

The model chooses readable relative paths. The workflow resolves those paths to
exact refs mechanically; the model never copies opaque hashes. Prepared content
is the exact source_probe stdout body. A preview, receipt, or Markdown
restatement is not a substitute. Output-contract `source_paths` and manifest
trace refs are host-owned lineage; they do not require source-path strings or a
provenance block inside a prepared body unless the active result explicitly asks
for consumer-visible provenance content.

If no source is mounted, a format is unsupported, or a transformation depends
on absent information, publish an honest partial or blocked result. Never fall
back to demo or synthetic data.

## Trigger examples

### Should select

- A mission mounts a CSV and asks for a downstream-ready table with selected
  columns, normalized values, and an independently reviewable output ref.
- A mission mounts mixed JSON and Markdown and asks for two named data products,
  each validated and formally handed to another agent.

### Should not select

- The user asks only what files and fields exist; source-observation owns that
  read-only working observation.
- The request asks to prepare a file that has not been mounted; the parent must
  mount the source first.

## Prompt and memory projection

| Class | Content and unique location | Prompt use and metabolism |
|---|---|---|
| C0 | Preparation objective, limits, and completion evidence in agent core state | Every internal decision receives only the relevant subset. It is not rewritten. |
| C1 | Current LOOP step purpose, active Graph node, and current issue in common state | Step purpose scopes preparation; node outcome/completion stay background; never a fixed next-skill instruction. |
| C2 | Selected `source_observation` and immutable `prepared_source_data`, including saved design, source bindings and output run refs | Observation is navigation; prepared data and continuation metadata have exact stored authority. |
| C3 | Unused by this bounded invocation | The skill does not place temporary inspection findings or completion receipts in shared knowledge. |
| C4 | Mounted sources and probe code/stdout/stderr/manifest | Prompts receive paths, refs, and bounded excerpts. Full bodies stay behind refs. |
| C5 | Structural findings, bounded source excerpts, transformation design, one output program, validation findings, and one repair | Replaced between stages and cleared when the skill ends. |
| C6 | Full prompts, responses, route calls, receipts, and errors | Append-only audit; never normal task evidence. |

Source selection first uses the existing inventory/search/read routes and the
existing preparation-design shape as a provisional proposal. It does not profile
an arbitrary inventory page. Selected files then use a fixed, value-free
structural profiler, one bounded file batch at a time, plus bounded
pages read from text-like C4 sources. Python reports structure and transports
source excerpts; it does not infer scientific meaning. The excerpts let the
design model translate task-level visibility and transformation requirements
into exact acceptance checks instead of guessing from field names. This bounded
observation is retained in C5 for this invocation only. Transformation design
receives C0 plus that C5 observation, the C4 inventory, and any explicitly
selected bounded C2 `source_observation`, then translates the current preparation
request and binding task constraints into one contract per named output. Output authoring,
validator authoring, and local repair receive that designed output contract,
exact paths, and the observation lines relevant to those paths. For a bound
target, all four stages additionally receive the same accepted record body,
its contract and original sources. It is a read-only dependency, not another
output to generate. They
do not receive the task-wide objective again because the host, not an individual
output program, assembles the final manifest. Validator Python reads the
complete C4 output and authoritative sources; the following prompt receives
only the small verdict. No stage receives full raw logs, unrelated formal
artifacts, duplicated complete source bodies, or a shared C3 ledger.
Validator authoring occurs after successful output execution and transport
checks. It receives the exact candidate body ref and bounded preview, not the
transformation program. Validator repair also excludes that program and uses
the same [validation authority](references/validator-authoring-stage.md): compare
source-derived expectations to delivered values without correcting the candidate
inside the check. Output repair still receives its own code and any existing
validator for diagnosis.
Validator authoring uses the configured scientific reasoning profile; repair
keeps the configured repair profile. Both validator stages load source-facts
and validation rules, not the scope-design or continuation instructions in
`evaluation-binding.md`. The unchanged per-output contract and bound record
dependency remain visible; other stages retain the full scope/binding guidance.

Each model stage loads its instruction page and shared authority pages under
`references/`; the compact root contract remains authoritative. See
`references/design-brief.md` for the complete ownership and call-contract map.

### LLM call contracts

| Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
|---|---|---|---|---|---|---|---|
| `prepare-source-data` | `locate-preparation-sources` | C0 constraints, current C1 LOOP step purpose, node background, selected formal task inputs and navigation observations, scoped C4 tools | Locate relevant files and propose named bodies; no source fact inference | Existing preparation-design shape plus existing source tool interfaces | Exact scoped inventory resolution; no filename substitution | Common format repair and bounded tool error feedback | Selected files only, then structural profiling and final design |
| `prepare-source-data` | `design-prepared-source-outputs` | Exact C0 task constraints, current C1 LOOP step purpose, node outcome/completion as background, optional explicitly selected C2 `source_observation` navigation context, mechanical C4 inventory, and bounded C5 structure/content observation | Design the smallest set of named output bodies owned by the current preparation request, including exact visibility checks; verify against C4 and do not add successor artifacts, write code, or infer values | Existing preparation-design shape | Exact path, unique-name, non-empty requirement, and status checks | One full-design correction with exact issues | Per-output code authoring |
| `prepare-source-data` | `repair-prepared-source-output-design` | Rejected C5 design, exact deterministic issues, and unchanged C0/C4/C5 authority | Repair only design/path defects without adding source facts | Complete existing design shape | Same deterministic design validation | No second design repair | Per-output code authoring |
| `prepare-source-data` | `continue-prepared-source-design` (replaces initial design on an exact checkpoint) | Current commission, C4 findings, exact selected C2 design/bindings and execution gaps | Choose unchanged design or submit a justified revision; no result acceptance | `{decision: reuse}` or `{decision: revise, design: existing design}` | Common schema check; resolved full design uses existing path/name/status checks | Same decision schema for format errors; resolved design uses the existing full-design correction | Exact run restoration or fresh per-output authoring |
| `prepare-source-data` | `write-prepared-source-output-*` | One accepted C5 output contract as sole scope, relevant C5 source findings, and named C4 paths | Write one complete transformation program that prints only that body in its declared media type; never assemble the final manifest or sibling bodies | Existing `{python_code}` shape | Code schema plus actual isolated execution and separate validator verdict | Common same-stage format repair; later one full-program repair for execution or valid output rejection | Exact C4 output body and validator execution |
| `prepare-source-data` | `write-prepared-source-output-validator-*` | Sole C5 output contract, relevant source findings, exact successful candidate body ref and bounded preview, source paths, verdict schema; no transformation program | Validate delivered content under the shared validation authority, not a corrected version | Existing `{python_code}` shape producing `{accepted, summary, issues}` | Actual execution, bounded parse, and exact verdict shape | One validator reconciliation on failure, malformed verdict, or rejection | Output acceptance decision |
| `prepare-source-data` | `repair-prepared-source-output-validator-*` | Validator program, original output contract, exact failure/verdict, candidate preview and validation execution, relevant source findings; no transformation program | Fix a validator defect under the same authority; return unchanged if rejection is correct | Existing `{python_code}` shape | Execute a changed validator against the same exact candidate body; unchanged code retains its verdict | No second validator repair | Accept unchanged data only after passing validation, or hand the defect to output repair |
| `prepare-source-data` | `repair-prepared-source-output-*` | Transformation program, current validator if created, exact execution error or rejection, sole output contract, source findings and bounded evidence | Repair output without changing contract, source facts, media type, or validator | Existing `{python_code}` shape | Re-execution followed by first validator authoring if none exists, otherwise current validator execution on the new exact body | One output-program repair | C4 prepared body and compact C2 manifest |

## Skill-local workflow

1. Let the source-selection model locate task-specific inputs using existing
   inventory/search/read tools, at most eight calls. Exact paths use targeted
   inventory; directory-only tasks may narrow the scope or search. It returns a
   provisional design in the existing format. Python resolves selected file
   paths to exact refs, retaining any task documents read during selection.
2. Mechanically compose the fixed structural profiler for each selected file,
   execute it through source_probe, and read its paged output. JSON paths are recursively reported;
   CSV/TSV columns and text dimensions use format-neutral summaries. Then read
   bounded pages from text-like sources so semantic transformations can be
   grounded in source content. Unknown formats are reported as unsupported
   instead of guessed.
   Pagination cursors are followed within the observation budget, not rejected.
   Profiler limits and unobserved regions remain explicit. The final design model
   may use bounded source_read/source_probe calls for targeted follow-up; full
   source bodies remain available to transformation and validation programs.
3. Retain the bounded structure/content observation in C5 for this invocation;
   do not write it into shared C3.
4. Design the smallest list of named outputs needed by the preparation request.
   Each item declares media type, description, source paths and acceptance checks.
   On continuation, the same stage sees the saved design, source bindings and
   observed gaps. Choose `reuse` without retyping the design, or `revise` with
   a full revised design justified by the current commission or source evidence,
   not to accommodate a faulty program. The host resolves `reuse` from stored
   C2; it does not accept failed output. Existing
   source inventory/search/read tools can locate newly needed inputs. Validated
   unchanged bindings skip the separate source-location model stage.
5. Mechanically reject unknown paths, duplicate names, empty requirements, or a
   complete design with no output. Give the design one local correction.
6. Produce the bound record output before its target; leave unrelated output
   ordering unchanged. If the record fails, preserve its issue and skip only
   the dependent target. For each output, reuse only when the saved contract, source refs and exact
   execution chain agree. Accepted bodies retain their refs. Unresolved work
   restores the executed programs/results into the existing repair stages;
   unexecuted code may need authoring. New or changed contracts generate Python
   from current sources. Prior failures are diagnostics, not new requirements.
   A target's execution chain must include the current record body ref. Changed
   or previously unstaged record dependencies require a fresh target program
   and validator, even when the target's original files are unchanged.
7. Execute through source_probe and retain its exact stdout ref as the prepared
   body.
8. Generate and execute a small Python validator that derives expected content
   from original sources and compares it with the complete output ref. On failure
   or rejection, its existing repair stage sees
   the validator, actual body and execution evidence against the unchanged contract,
   without the transformation program. Fix only
   a validator defect; otherwise return it unchanged. Execute changed code on the
   same body, preserving all execution refs. Before target acceptance, apply the
   existing exact pair shape/ID check; send a mismatch to the same output repair.
   A host record-identity or pairing check is not
   this model-authored validator and cannot be bypassed by repairing it.
9. An output execution failure or remaining rejection gets one output-code repair,
   then the current validator checks the replacement. There is at most one repair
   of each program, no body-fingerprint prerequisite, and no automatic acceptance.
   A still-broken validator stops this output rather than demanding data changes
   without a usable check. Continued failure is published as a residual issue.
10. Publish one manifest, record the prior manifest in `depends_on` when
    retrying, preserve exact explicitly selected formal input refs such as the
    task specification or `source_observation` in `depends_on`, read back its
    exact artifact ref, and return control.

The planner dynamically decides whether this capability is needed. Only the
bounded sequence inside this selected skill is fixed.

## Formal output and handoff

Publish prepared_source_data through artifact_publish. Its complete machine
payload is intentionally small:

    artifact_kind: prepared_source_data
    prepared_outputs:
      - name
      - content_ref
      - media_type
      - description

Every private design must answer `evaluation_binding` with the existing object
or `null` (explain non-scoring scope in summary). A public manifest still omits
null. For a source-supported scoring preparation, `evaluation_binding`
contains `record_output_name`, `target_output_name`, `target_id`, and
`selection_reason`. The authoritative schema is `evaluation_binding_schema()` in
`domain/prepared_evaluation.py`, shared by design, repair and publication.
See [preparation scope and scoring binding](references/evaluation-binding.md) for body pairing,
source-row provenance, visibility and partial-result handling. No other payload
fields are added. All internal stages load this shared contract.

content_ref must be an exact successful source_probe stdout C4 ref. Source and
probe refs use the existing trace_refs. Validation status and residual issues
use self_review. Its approved optional `preparation_design` uses the existing
design schema, and `source_bindings` contains `{relative_path, source_ref}` entries.
Each output review adds nullable `transformation_run_ref` and `validation_run_ref`
pointing to the exact executed C4 manifests; unexecuted operations have null refs.
The design's status is not execution acceptance. Do not copy code or large bodies
into C2. See [design brief](references/design-brief.md) for the continuation boundary.

Use envelope status proposed for complete, draft for partial, and rejected for
blocked. Read the exact newly published artifact before completion. A parent may
accept the C2 ref after child review; consumers resolve named C4 refs rather than
reconstructing data from prose.

## Failure and repair

- Structured format errors receive the common one-attempt stage repair.
- A fixed-profiler execution failure is reported as a skill implementation defect;
  it is not handed to the model as a source-content repair.
- Transformation design receives one local path/structure correction.
- Each named output receives at most one local implementation repair.
- Unsupported formats, missing sources, and impossible transformations become
  explicit residual issues and partial or blocked publication.
- Scientific interpretation gaps belong to downstream domain capabilities.
- Report a bounded gap when this work unit cannot contribute
  to the evaluation condition.

## Validation evidence

- Structural validation checks regular skill design and workflow entrypoint.
- Focused tests check exact path resolution, C4 output, local repair, compact C2
  publication, and mandatory readback.
- A child handoff test checks white-room execution and parent review of the exact
  C2 ref.
- The smallest real-model test prepares two named outputs from the pinned
  five-record chemistry sources. It proves only preparation and handoff, not the
  downstream scientific workflow.

## Bundled references

- [Design brief](references/design-brief.md)
- [Design continuation](references/design-continuation-stage.md)
- [Source selection](references/source-selection-stage.md)
- [Output-design stage](references/design-stage.md)
- [Output-design repair](references/design-repair-stage.md)
- [Output-program authoring](references/output-authoring-stage.md)
- [Output-program repair](references/output-repair-stage.md)
- [Validator authoring](references/validator-authoring-stage.md)
- [Validator repair](references/validator-repair-stage.md)
