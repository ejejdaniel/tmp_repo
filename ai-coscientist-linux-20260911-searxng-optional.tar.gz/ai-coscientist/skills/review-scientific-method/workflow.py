from __future__ import annotations

from typing import Any, Mapping, Sequence

from ai_coscientist.domain.proxy_formula_ranking import (
    terminal_proxy_formula_leaderboard,
    update_proxy_formula_leaderboard,
)
from ai_coscientist.domain.scientific_review import review_scientific_method


_METHOD_KINDS = {"hypothesis", "proxy_formula_candidate"}
_PUBLIC_EVIDENCE_KINDS = {
    "task_spec",
    "hypothesis_mind_map",
    "quantitative_proxy_materialization_result",
    "scientific_method_review",
    "hypothesis_leaderboard",
    "proxy_formula_leaderboard",
}


def run(payload: dict[str, Any], runtime: Any) -> dict[str, Any]:
    """Review one exact scientific method without blocking its producer."""
    raw_inputs = payload.get("resolved_inputs", [])
    resolved = _resolved_inputs(runtime, raw_inputs)
    methods = [item for item in resolved if item["artifact_kind"] in _METHOD_KINDS]
    if not methods:
        return {
            "status": "bounded_gap",
            "reason": "review_scientific_method_exact_method_required",
        }
    if len(methods) != 1:
        raise ValueError(
            "scientific_method_review_exactly_one_method_required:"
            f"refs={[str(item['artifact_ref']) for item in methods]}"
        )
    method = methods[0]
    method_ref = str(method["artifact_ref"])
    public_evidence = [
        item
        for item in resolved
        if item["artifact_kind"] in _PUBLIC_EVIDENCE_KINDS
        and item["artifact_ref"] != method_ref
    ]
    if method["artifact_kind"] == "hypothesis":
        public_evidence = _hydrate_hypothesis_formula_evidence(
            runtime,
            hypothesis=method,
            resolved=resolved,
            public_evidence=public_evidence,
        )
    else:
        # Formula review remains independent of held-out trend evidence. The
        # ranking stage consumes an explicit board only after this review call.
        public_evidence = [
            item
            for item in public_evidence
            if item["artifact_kind"] != "proxy_formula_leaderboard"
        ]
    review = review_scientific_method(
        runtime,
        method=method,
        public_evidence=public_evidence,
    )
    version = _next_review_version(runtime, method_ref)
    review_payload = {
        "artifact_kind": "scientific_method_review",
        "version": version,
        "method_artifact_ref": method_ref,
        "review_score": review["review_score"],
        "reason": review["reason"],
    }
    review_receipt = runtime.publish_artifact(
        artifact_kind="scientific_method_review",
        artifact_id=f"scientific-method-review-{_ref_slug(method_ref)}-v{version}",
        title=f"Scientific method review: {method.get('title') or method_ref}",
        markdown=_render_review_markdown(method, review_payload),
        summary=(
            f"Public method-quality score {review['review_score']:.1f}/100 for "
            f"{method_ref}. This score ranks but does not reject the method."
        ),
        status="reviewed",
        machine_payload=review_payload,
        depends_on=[method_ref, *_unique_refs(public_evidence)],
        self_review={
            "non_blocking_review": True,
            "private_kpi_evidence_absent": True,
        },
    )
    review_ref = str(review_receipt["artifact_ref"])
    stored_review = runtime.read_artifact(review_ref)
    _validate_review_readback(stored_review, review_payload)

    result = {
        "status": "complete",
        "artifact_ref": review_ref,
        "summary": str(review["reason"])[:500],
    }
    if method["artifact_kind"] == "hypothesis":
        leaderboard_ref = _publish_hypothesis_leaderboard(runtime)
        result["summary"] = (
            f"Published review {review_ref} and refreshed hypothesis "
            f"leaderboard {leaderboard_ref}."
        )
    else:
        materialization = _matching_formula_materialization(
            resolved,
            formula_ref=method_ref,
        )
        prior_leaderboard = terminal_proxy_formula_leaderboard(resolved)
        leaderboard_ref = update_proxy_formula_leaderboard(
            runtime,
            formula=method,
            materialization=materialization,
            review=stored_review,
            prior_leaderboard=prior_leaderboard,
        )
        if leaderboard_ref:
            result["summary"] = (
                f"Published review {review_ref} and refreshed proxy formula "
                f"leaderboard {leaderboard_ref}."
            )
    return result


def _resolved_inputs(runtime: Any, raw_inputs: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_inputs, list):
        raise ValueError("scientific_method_review_resolved_inputs_invalid")
    resolved: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in raw_inputs:
        if not isinstance(raw, Mapping):
            continue
        artifact_ref = str(raw.get("artifact_ref") or "").strip()
        artifact_kind = str(raw.get("artifact_kind") or "").strip()
        if not artifact_ref.startswith("artifact:") or not artifact_kind:
            continue
        if artifact_ref in seen:
            continue
        artifact = dict(raw)
        if not isinstance(artifact.get("machine_payload"), Mapping):
            artifact = dict(runtime.read_artifact(artifact_ref))
        if artifact.get("artifact_ref") != artifact_ref:
            raise ValueError("scientific_method_review_ref_mismatch")
        if artifact.get("artifact_kind") != artifact_kind:
            raise ValueError("scientific_method_review_kind_mismatch")
        if not isinstance(artifact.get("machine_payload"), Mapping):
            raise ValueError("scientific_method_review_payload_required")
        resolved.append(artifact)
        seen.add(artifact_ref)
    return resolved


def _hydrate_hypothesis_formula_evidence(
    runtime: Any,
    *,
    hypothesis: Mapping[str, Any],
    resolved: Sequence[Mapping[str, Any]],
    public_evidence: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Follow one explicit board/materialization pair without changing target."""
    materializations = [
        dict(item)
        for item in resolved
        if item.get("artifact_kind")
        == "quantitative_proxy_materialization_result"
    ]
    if not materializations:
        return [dict(item) for item in public_evidence]
    if len(materializations) != 1:
        raise ValueError(
            "hypothesis_review_materialization_selection_ambiguous:"
            f"actual={len(materializations)}"
        )
    boards = _terminal_explicit_artifacts(
        resolved,
        artifact_kind="proxy_formula_leaderboard",
    )
    if len(boards) != 1:
        raise ValueError(
            "hypothesis_review_proxy_leaderboard_selection_required:"
            f"actual={len(boards)}"
        )
    materialization = materializations[0]
    materialization_ref = str(materialization["artifact_ref"])
    materialization_dependencies = _dependency_refs(materialization)
    formula_refs = [
        ref
        for ref in materialization_dependencies
        if runtime.read_artifact(ref).get("artifact_kind")
        == "proxy_formula_candidate"
    ]
    if len(formula_refs) != 1:
        raise ValueError(
            "hypothesis_review_materialization_formula_required:"
            f"actual={len(formula_refs)}"
        )
    formula_ref = formula_refs[0]
    formula = dict(runtime.read_artifact(formula_ref))
    hypothesis_ref = str(hypothesis["artifact_ref"])
    if hypothesis_ref not in _dependency_refs(formula):
        raise ValueError(
            "hypothesis_review_formula_lineage_mismatch:"
            f"hypothesis={hypothesis_ref}:formula={formula_ref}"
        )

    board = boards[0]
    board_payload = board.get("machine_payload")
    entries = (
        board_payload.get("ranked_entries")
        if isinstance(board_payload, Mapping)
        else None
    )
    if not isinstance(entries, list):
        raise ValueError("hypothesis_review_leaderboard_entries_required")
    matching_entries = [
        entry
        for entry in entries
        if isinstance(entry, Mapping)
        and entry.get("formula_artifact_ref") == formula_ref
        and entry.get("materialization_artifact_ref") == materialization_ref
    ]
    if len(matching_entries) != 1:
        raise ValueError(
            "hypothesis_review_ranked_formula_pair_required:"
            f"actual={len(matching_entries)}"
        )
    review_ref = str(matching_entries[0].get("review_artifact_ref") or "")
    if not review_ref.startswith("artifact:"):
        raise ValueError("hypothesis_review_formula_review_ref_required")
    formula_review = dict(runtime.read_artifact(review_ref))
    review_payload = formula_review.get("machine_payload")
    if (
        formula_review.get("artifact_kind") != "scientific_method_review"
        or not isinstance(review_payload, Mapping)
        or review_payload.get("method_artifact_ref") != formula_ref
        or formula_ref not in _dependency_refs(formula_review)
    ):
        raise ValueError("hypothesis_review_formula_review_lineage_invalid")

    hydrated = [dict(item) for item in public_evidence]
    by_ref = {
        str(item.get("artifact_ref") or ""): item for item in hydrated
    }
    for artifact in (formula, formula_review):
        artifact_ref = str(artifact.get("artifact_ref") or "")
        if artifact_ref and artifact_ref not in by_ref:
            hydrated.append(artifact)
            by_ref[artifact_ref] = artifact
    return hydrated


def _terminal_explicit_artifacts(
    artifacts: Sequence[Mapping[str, Any]],
    *,
    artifact_kind: str,
) -> list[dict[str, Any]]:
    candidates = [
        dict(item)
        for item in artifacts
        if item.get("artifact_kind") == artifact_kind
    ]
    candidate_refs = {str(item.get("artifact_ref") or "") for item in candidates}
    superseded = {
        ref
        for item in candidates
        for ref in _dependency_refs(item)
        if ref in candidate_refs
    }
    return [
        item
        for item in candidates
        if str(item.get("artifact_ref") or "") not in superseded
    ]


def _matching_formula_materialization(
    artifacts: Sequence[Mapping[str, Any]],
    *,
    formula_ref: str,
) -> dict[str, Any] | None:
    matches = [
        dict(item)
        for item in artifacts
        if item.get("artifact_kind")
        == "quantitative_proxy_materialization_result"
        and formula_ref in _dependency_refs(item)
    ]
    if len(matches) > 1:
        raise ValueError(
            "formula_review_materialization_selection_ambiguous:"
            f"formula={formula_ref}:actual={len(matches)}"
        )
    return matches[0] if matches else None


def _dependency_refs(artifact: Mapping[str, Any]) -> list[str]:
    raw_refs = artifact.get("depends_on")
    if isinstance(raw_refs, (str, bytes)) or not isinstance(raw_refs, Sequence):
        return []
    return [
        str(ref).strip()
        for ref in raw_refs
        if str(ref).strip().startswith("artifact:")
    ]


def _next_review_version(runtime: Any, method_ref: str) -> int:
    versions: list[int] = []
    for receipt in runtime.artifact_index():
        if receipt.get("artifact_kind") != "scientific_method_review":
            continue
        artifact_ref = str(receipt.get("artifact_ref") or "")
        artifact = runtime.read_artifact(artifact_ref)
        review = artifact.get("machine_payload")
        if not isinstance(review, Mapping):
            raise ValueError(f"scientific_method_review_payload_missing:{artifact_ref}")
        if review.get("method_artifact_ref") != method_ref:
            continue
        _validate_review_payload(review, expected_method_ref=method_ref)
        versions.append(int(review["version"]))
    return max(versions, default=0) + 1


def _publish_hypothesis_leaderboard(runtime: Any) -> str:
    latest_reviews: dict[str, dict[str, Any]] = {}
    leaderboard_versions: list[int] = []
    for receipt in runtime.artifact_index():
        kind = receipt.get("artifact_kind")
        artifact_ref = str(receipt.get("artifact_ref") or "")
        if kind == "hypothesis_leaderboard":
            board = runtime.read_artifact(artifact_ref)
            payload = board.get("machine_payload")
            version = payload.get("version") if isinstance(payload, Mapping) else None
            if isinstance(version, bool) or not isinstance(version, int) or version < 1:
                raise ValueError(f"hypothesis_leaderboard_version_invalid:{artifact_ref}")
            leaderboard_versions.append(version)
            continue
        if kind != "scientific_method_review":
            continue
        review_artifact = runtime.read_artifact(artifact_ref)
        review = review_artifact.get("machine_payload")
        if not isinstance(review, Mapping):
            raise ValueError(f"scientific_method_review_payload_missing:{artifact_ref}")
        method_ref = str(review.get("method_artifact_ref") or "")
        if not method_ref.startswith("artifact:"):
            raise ValueError(
                f"scientific_method_review_method_ref_invalid:{artifact_ref}"
            )
        method = runtime.read_artifact(method_ref)
        if method.get("artifact_kind") != "hypothesis":
            continue
        _validate_review_payload(review, expected_method_ref=method_ref)
        prior = latest_reviews.get(method_ref)
        if prior is None or int(review["version"]) > int(
            prior["machine_payload"]["version"]
        ):
            latest_reviews[method_ref] = review_artifact

    if not latest_reviews:
        raise ValueError("hypothesis_leaderboard_requires_review")
    ordered = sorted(
        latest_reviews.items(),
        key=lambda item: (
            -float(item[1]["machine_payload"]["review_score"]),
            item[0],
        ),
    )
    ranked_entries = [
        {
            "rank": rank,
            "hypothesis_artifact_ref": hypothesis_ref,
            "review_artifact_ref": str(review_artifact["artifact_ref"]),
            "review_score": float(
                review_artifact["machine_payload"]["review_score"]
            ),
        }
        for rank, (hypothesis_ref, review_artifact) in enumerate(
            ordered,
            start=1,
        )
    ]
    board_version = max(leaderboard_versions, default=0) + 1
    board_payload = {
        "artifact_kind": "hypothesis_leaderboard",
        "version": board_version,
        "ranked_entries": ranked_entries,
    }
    dependencies: list[str] = []
    for entry in ranked_entries:
        dependencies.extend(
            [entry["hypothesis_artifact_ref"], entry["review_artifact_ref"]]
        )
    receipt = runtime.publish_artifact(
        artifact_kind="hypothesis_leaderboard",
        artifact_id=f"hypothesis-leaderboard-v{board_version}",
        title=f"Hypothesis leaderboard v{board_version}",
        markdown=_render_hypothesis_leaderboard(board_payload),
        summary=(
            f"Public ranking of {len(ranked_entries)} hypothesis methods by "
            "shared scientific-review score."
        ),
        status="reviewed",
        machine_payload=board_payload,
        depends_on=_deduplicated(dependencies),
    )
    board_ref = str(receipt["artifact_ref"])
    stored = runtime.read_artifact(board_ref)
    if stored.get("machine_payload") != board_payload:
        raise ValueError("hypothesis_leaderboard_readback_mismatch")
    return board_ref


def _validate_review_readback(
    artifact: Mapping[str, Any],
    expected_payload: Mapping[str, Any],
) -> None:
    if artifact.get("artifact_kind") != "scientific_method_review":
        raise ValueError("scientific_method_review_readback_kind_invalid")
    if artifact.get("machine_payload") != expected_payload:
        raise ValueError("scientific_method_review_readback_payload_mismatch")


def _validate_review_payload(
    payload: Mapping[str, Any],
    *,
    expected_method_ref: str,
) -> None:
    expected = {
        "artifact_kind",
        "version",
        "method_artifact_ref",
        "review_score",
        "reason",
    }
    if set(payload) != expected:
        raise ValueError("scientific_method_review_shape_invalid")
    if payload.get("artifact_kind") != "scientific_method_review":
        raise ValueError("scientific_method_review_kind_invalid")
    if payload.get("method_artifact_ref") != expected_method_ref:
        raise ValueError("scientific_method_review_method_ref_mismatch")
    version = payload.get("version")
    if isinstance(version, bool) or not isinstance(version, int) or version < 1:
        raise ValueError("scientific_method_review_version_invalid")
    score = payload.get("review_score")
    if isinstance(score, bool) or not isinstance(score, (int, float)):
        raise ValueError("scientific_method_review_score_invalid")
    if not 0 <= float(score) <= 100:
        raise ValueError("scientific_method_review_score_out_of_range")
    if not str(payload.get("reason") or "").strip():
        raise ValueError("scientific_method_review_reason_required")


def _render_review_markdown(
    method: Mapping[str, Any],
    review: Mapping[str, Any],
) -> str:
    return (
        "# Scientific method review\n\n"
        f"- Method: `{review['method_artifact_ref']}`\n"
        f"- Method kind: `{method['artifact_kind']}`\n"
        f"- Review version: {review['version']}\n"
        f"- Public quality score: {float(review['review_score']):.1f}/100\n\n"
        "## Reason\n"
        f"{review['reason']}\n\n"
        "This review ranks the method. It is not a producer red-line gate and "
        "does not claim held-out KPI performance.\n"
    )


def _render_hypothesis_leaderboard(payload: Mapping[str, Any]) -> str:
    rows = [
        "| Rank | Hypothesis | Review | Score |",
        "| ---: | --- | --- | ---: |",
    ]
    rows.extend(
        "| {rank} | `{hypothesis_artifact_ref}` | `{review_artifact_ref}` | "
        "{review_score:.1f} |".format(**entry)
        for entry in payload["ranked_entries"]
    )
    return (
        f"# Hypothesis leaderboard v{payload['version']}\n\n"
        + "\n".join(rows)
        + "\n"
    )


def _unique_refs(artifacts: Sequence[Mapping[str, Any]]) -> list[str]:
    return _deduplicated(
        str(item.get("artifact_ref") or "")
        for item in artifacts
        if str(item.get("artifact_ref") or "").startswith("artifact:")
    )


def _deduplicated(values: Any) -> list[str]:
    return list(dict.fromkeys(str(value) for value in values if str(value)))


def _ref_slug(artifact_ref: str) -> str:
    return artifact_ref.removeprefix("artifact:").replace(":", "-")[-120:]
