---
name: review-scientific-method
description: Produces a NEW scientific_method_review with public method-quality score/reason. Requires one exact hypothesis or formula. Every call reassesses quality. With complete materialization and evaluation_binding, also ranks proxy-versus-target trend agreement. To retain an existing review, use rank-proxy-formula. Boundary: no implementation/routing; reviewer LLM sees no private KPI.
estimated_complexity: medium
---

# Review Scientific Method

## Responsibility and boundary

Score one already published scientific method as public comparison evidence. A method is either an exact `hypothesis` or an exact `proxy_formula_candidate`. The score helps both researchers compare methods; it never rejects, repairs, rewrites, materializes, or chooses the next workflow action. Producer-owned red-line review remains inside `hypothesis-gen` or `final-kpi-proxy-discovery`. After the public formula review is frozen, a separate mechanical ranking stage may call the private evaluator with an exact formula/materialization pair and refresh the formula leaderboard. The reviewer model never sees that private result.

Formula ranking measures agreement between computed proxy values and the
execution-selected dataset's measured target values, using the formula's stated
direction. Its dataset-level `trend_alignment_score` is distinct from both
per-record `proxy_values_by_sample` and the LLM's public `review_score`.
Materialized numbers supply the comparison inputs, not its result. The existing
private evaluator computes rank-correlation diagnostics; the ranking stage
converts them to the leaderboard score. This is fit on the selected dataset,
not evidence of independent validation. One supplied formula is sufficient to
establish its score and a one-entry leaderboard; multiple formulas are not a
prerequisite.

The reason states the score basis, strongest remaining public-evidence gap, and
the kind of evidence that would improve confidence without naming a next skill
or workflow route. A score of 100 is reserved for a method whose material claims
have explicit public support and no meaningful evidence gap within its scope.

## Entry conditions and authority

Each invocation creates a new scientific review. A prior review supplied as
evidence is not an instruction to preserve its identity or score. To retain a
chosen review while updating only formula scoring and ranking, select
`rank-proxy-formula` instead; this does not require a separate Graph node.

The active work unit must provide exactly one stored method artifact by exact ref through `resolved_inputs_for_active_skill`; review only that method. Relevant `task_spec`, `hypothesis_mind_map`, public materialization, prior `scientific_method_review`, and method-leaderboard artifacts may accompany it as explicit evidence refs. Other raw hypothesis or formula artifacts must not accompany the target; their comparison information travels through the existing public review and leaderboard artifacts. Stored artifacts own content; summaries, receipts, unrelated board entries, and global latest-of-kind lookup do not substitute for those inputs. Formula ranking occurs only when one exact matching complete materialization is explicitly supplied, or when an explicitly supplied leaderboard already contains that exact formula and only its public review version must be refreshed.

For formula ranking, the materialization's exact execution observation selects
the prepared source. It must contain a valid `evaluation_binding` joining
calculation records to a separate comparison-target body. This binding selects
data roles, not access permissions; ordinary task measurements do not become
restricted merely because they are used for scoring. Explicit task/source
restrictions and the private reviewer-stage boundary still apply. The Formula's
research dependencies do not select this dataset. Supplying another prepared
artifact cannot rebind a past execution; execute the same applicable Formula
on the new prepared source first. Rankings compare the same execution-selected
scope and target; prior board versions remain historical evidence.
When this prerequisite is absent, the public method review remains valid, but
no `proxy_formula_leaderboard` can be published from that Formula/materialization
pair.

If no exact method was supplied, return a bounded gap. If more than one method was supplied, reject the ambiguous invocation. Do not guess from titles, select a method globally, or infer scientific priority from artifact order. Held-out final-KPI values and private trend scores are intentionally unavailable.

## Trigger examples

### Should select

- Review exact hypothesis `artifact:...:hypothesis-a` using its task, mind map, and cited public evidence, then publish a public score and refresh the hypothesis leaderboard.
- Give exact formula `artifact:...:formula-b` an independent scientific-quality score without seeing its private historical KPI correlation.
- Compute trend agreement for an already executed formula against the measured targets paired with that execution's input records, then publish its formula leaderboard entry. Supply the exact formula and complete materialization; do not rerun the formula merely to rename its proxy values as scores.

### Should not select

- Repair a hypothesis whose mechanism violates a producer red line; `hypothesis-gen` owns that repair before publication.
- Rank a formula that has not yet been published as an exact `proxy_formula_candidate`; the required method authority is absent.

## Prompt and memory projection

- **C0 fixed core:** active objective and evaluation summary supplied by common skill execution; they orient the review but do not override the method artifact.
- **C1 current control:** active work unit and any exact resolved method/evidence refs; no next-skill field is produced.
- **C2 formal artifacts:** the method, public evidence, `scientific_method_review`, and applicable method leaderboard are immutable artifacts. This is the semantic source of truth.
- **C3 compressible knowledge:** the bounded private-evaluator aggregate is consumed only by the post-review formula-ranking stage and is never placed in the reviewer prompt.
- **C4 large workspace data:** unused; large evidence must already be represented by an explicit formal ref or bounded public artifact.
- **C5 temporary state:** one transient `{review_score, reason}` result exists only during this selected skill execution and is cleared after publication.
- **C6 raw audit:** the exact review prompt, response, validation issue, publication receipt, and readback trace remain in the common execution log. They are not semantic inputs to later calls.

The review call receives only the exact method and bounded public evidence. Formula review never receives a private trend score, final-KPI values, or a formula leaderboard score. The output request and validator both require only `review_score` from 0 to 100 and a non-empty `reason`. Only after that call returns may the host use the exact formula, materialization, review, and prior leaderboard refs to update formula ranking.

### LLM call contracts

| Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
|---|---|---|---|---|---|---|---|
| `review-scientific-method` | `review-{method_kind}-method-quality` | C0 task boundary; C1 one exact target ref; C2 stored target plus explicitly supplied public review, task, map, background, or materialization evidence; C5 transient score request | Assess scientific-method quality without changing the method or workflow | Existing `{review_score, reason}` | Numeric 0-100 score and non-empty bounded reason | Common same-stage structured-output repair only; it cannot add evidence or choose a different method | Stored `scientific_method_review`; the host then refreshes the applicable leaderboard from exact refs |

## Skill-local workflow

1. Resolve exactly one explicitly targeted method plus only its explicitly supplied public evidence.
2. Ask the shared reviewer for one non-blocking score and reason.
3. Mechanically assign the next review version for that exact method.
4. Publish and read back `scientific_method_review`.
5. For a hypothesis, rebuild and read back `hypothesis_leaderboard` using the newest review version per exact hypothesis ref.
6. For a formula with exact ranking evidence, call the private evaluator with `formula_artifact_ref` and `materialization_artifact_ref` only after public review, validate the returned aggregate without exposing raw KPI values, and rebuild `proxy_formula_leaderboard`. If the formula is already ranked, reuse its exact private observation and update only the public-review axis.

This bounded sequence belongs inside the selected skill. The production coordinator remains free to choose whether and when to select it.

## Formal output and handoff

`scientific_method_review` contains exactly `artifact_kind`, `version`, `method_artifact_ref`, `review_score`, and `reason`; evidence refs are stored in `depends_on`. A hypothesis review additionally publishes `hypothesis_leaderboard`. A formula review with complete explicit ranking evidence additionally publishes `proxy_formula_leaderboard` using the existing formula/materialization/evaluation/review entry shape.

Publish these fields as the complete `machine_payload`. Markdown is a human-readable projection and cannot replace or redefine stored content. Immediately call `read_ref` on every published ref; a missing ref, mismatched kind, or mismatched payload is incomplete.

Both hypothesis and final-KPI proxy researchers may read both method leaderboards. Formula ranking treats the public review score and private trend score as separate Pareto dimensions. Sample may use a reviewed hypothesis as the frozen method sponsor, but the review score is not itself a sample score.

## Failure and repair

Malformed score or reason is repaired by the existing bounded structured-output retry inside the same LLM stage. Absence of an exact method returns a bounded gap to the planner; multiple supplied methods or materializations are ambiguous invocation errors. A formula without matching materialization still receives a public review but is not ranked. An execution whose selected source lacks a valid scoring pair fails ranking with the exact source ref and missing requirement; new preparation must be explicitly selected by a new execution, not attached to old numbers. Older prepared-data executions without recorded selection must be re-executed, not relabeled. Artifact publication or readback mismatch fails the skill. Scientific disagreement never becomes rejection here; only the producer's internal red-line workflow can block its own method before publication.

## Validation evidence

- Structural validation proves folder/frontmatter/required-section and workflow-entrypoint conformance.
- Focused deterministic tests prove exact-ref selection, version increments, hypothesis leaderboard replacement, and formula-review privacy.
- A producer-to-consumer replay proves a matching formula review joins the exact formula/materialization/private-evaluation tuple without alias reconstruction.
- The smallest real-model test reviews one stored hypothesis and one stored formula; it does not prove the entire scientific workflow.
