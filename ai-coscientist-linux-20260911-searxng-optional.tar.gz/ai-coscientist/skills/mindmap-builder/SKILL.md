---
name: mindmap-builder
description: "Produces one formal hypothesis_mind_map. Requires exact task_spec plus either prepared_source_data containing one directly readable record-table body or sanitized historical-source access. A manifest/index body without records is not usable source data. Boundary: it maps qualitative method embryos and relations, but does not produce a formal hypothesis or proxy_formula_candidate."
estimated_complexity: medium
accepts_research_mode: true
---

# Mind-map builder

## Responsibility and boundary

Create one authoritative `hypothesis_mind_map` that defines the scientific search landscape as qualitative method embryos and gives each direction a stable family identity. A family is an independently actionable system-level intervention class or reusable strategy that interacts meaningfully with another family and can support multiple future hypotheses or quantitative methods. It is not merely the name of a material, component, variable, model, current candidate, intermediate quantity, process stage, constraint, or known mechanism. Properties caused by the same controllable subsystem belong inside one family rather than becoming peer families.

This skill does not generate a finished candidate hypothesis or proxy formula, execute validation, back-infer families from titles, or choose the next skill.

## Research modes

`task_source` and `research_strategy` are independent caller-owned axes. An
autonomous invocation chooses a useful landscape question inside the active
node; a commissioned invocation addresses the named question or exact refs.
Deepen mode may use shared maps, hypotheses, formulas, rankings, and reviews in
the upper-system draft. Explore mode hides non-commissioned shared research from
that draft, then restores it for the existing architecture-and-evidence
deepening pass. Task authority and inspected source data are never hidden.
Before invocation, common classifies the node-scoped candidate refs and derives
the final exact inputs; this skill consumes that decision and does not reclassify
the caller's authority.

The formal-result boundary is strict: a method embryo may contain a plausible causal statement, prerequisites, and an expected failure mode, but it remains a search direction. No family item, relationship, Markdown sentence, or complete `hypothesis_mind_map` is a formal `hypothesis`. A later researcher must select and deepen one family into an independently published `hypothesis` before a hypothesis deliverable is satisfied.

## Entry conditions and authority

- Read the exact `task_spec` and any relevant `prepared_source_data` refs from `resolved_inputs_for_active_skill`. When one exact prepared source is supplied, its stored C4 body is the source-content authority and the skill must not independently reread a competing historical payload.
- Existing `hypothesis`, `hypothesis_leaderboard`, `proxy_formula_candidate`, and `proxy_formula_leaderboard` artifacts are optional public research assets. When explicitly supplied, project them into a compact list of occupied research directions. Use that list to diversify, reconcile, or challenge the landscape; it must not define the family taxonomy or make the current best candidate the center of the map.
- Use an explicitly supplied `prepared_source_data` record table; only when none is supplied may the skill inspect `scientific_source_visible_historical`. Formal-index summaries and runtime wiki do not substitute for stored content.
- Task-scoped prepared measurements are ordinary readable research data; their scoring role does not require a new task grant. An explicit `task_spec.data_use_authorizations` grant retains its named use and claim limit through observation, authoring, deepening and repair. Reading measurements does not establish causality or independent validation; cite the source instead of duplicating whole tables.
- Prepared-source provenance comes from that exact artifact and its body refs, not an independently configured source manifest. Its row count need not equal another dataset. A malformed or ambiguous explicit prepared source is a handoff failure, not permission to fall back to configured data.
- The observation stage may use `source_inventory`, `source_search`, and `source_read` to inspect task-linked definitions, structures, units, or methods absent from the prepared table. Follow exact source refs or locate the task's named path within the mission. Reading explanatory source pages does not replace the selected dataset or reopen preparation. Unread is not absent; source documents do not override the current task's requirements or permissions.
- When `evaluation_binding` is present, its `record_output_name` selects the input table. Other named bodies, including paired targets, retain their exact source identity and meaning in every authoring stage. They are direct source content, not model interpretation. Preserve any explicit source restriction; the binding itself is not a privacy rule.
- Supported mechanisms, alternatives, tensions, and evidence gaps come only from exact formal artifacts and the sanitized source actually inspected. Prompt assembly mechanically keeps the formal task, direct sanitized records, model extraction, model interpretation, and unknown or withheld information in separate authority sections. A later stage must verify a model summary against the direct source instead of treating the summary as a new source.

## Trigger examples

### Should select

- An exact `task_spec` plus either relevant `prepared_source_data` or sanitized historical-source access is available, and the current work needs an authoritative mechanism-family landscape.
- The available task and inspected evidence must be organized into stable method-embryo families and relationships before any individual hypothesis or proxy formula is designed.

### Should not select

- A valid mind map already exists and the current work is to produce one concrete testable candidate within an existing family.
- Neither relevant `prepared_source_data` nor sanitized historical-source access is available, so the landscape would have no inspected evidence basis.

## Prompt and memory projection

- **C0:** task objective, explicit constraints, and evaluation/visibility boundary.
- **C1:** the current landscape-construction work unit and exact input refs.
- **C2:** stored task, optional prepared-source envelope, shared hypothesis/formula artifacts actually used, and the published `hypothesis_mind_map`.
- **C3:** only bounded processed observations relevant to unresolved landscape gaps; they remain non-authoritative.
- **C4:** the exact prepared-source body, fallback sanitized historical data, and long documents remain behind routes or refs. Once inspected, a bounded direct-source projection remains visible to every scientific authoring stage that must verify factual claims.
- **C5:** the skill-local copy of the caller-owned research-mode card, fallible source extraction, scientific interpretations, family drafts, relationship drafts, validation issues, and readback issues exist only during this invocation. The authoritative card remains on the active C1 LOOP step; only the C5 copy is cleared on exit. These items are visibly separated from C4 direct evidence and cannot acquire source authority through repetition.
- **C6:** raw model turns, prompts, receipts, and errors remain audit-only.

### LLM call contracts

| Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
|---|---|---|---|---|---|---|---|
| `mindmap-builder` | `resolve-research-mode` | Exact C1 structured research-mode card plus exact resolved C2 refs | Mechanically validate and copy the caller-owned mode card; old checkpoints alone use the compatibility classifier | Private C5 `{task_source, research_strategy, commissioned_input_refs}` mode card | Existing closed three-field schema and exact-ref subset | No semantic repair for a structured card | Remaining mind-map stages |
| `mindmap-builder` | `observe-source-for-method-embryos` | Exact C2 task plus prepared C4 source; otherwise sanitized C4 historical source and manifest; task/prepared source refs and pages actually read through existing read-only tools | Inspect relevant missing definitions within the existing inspection quota; separate direct facts from interpretations and unknowns; do not author methods | Existing compact observation shape | Structured schema only; claims remain bounded by inspected source | Common same-stage format repair preserves tool messages | Mind-map authoring and deepening receive the exact read pages alongside the fallible extraction |
| `mindmap-builder` | `mindmap-upper-system-skeleton` | Exact bounded C2 task and C4 sanitized records; separate C5 extraction, interpretation, and unknown sections; compact prior-map architecture summaries and occupied directions | Verify summaries against direct evidence, then organize a stable upper-system landscape; observed columns, intermediate quantities, and current candidate variables remain evidence inside families | Existing title, summary, families, relationships, gaps, and evidence-boundary shape | Structured schema plus deterministic unique-family checks | One exact same-stage repair | Mechanism-and-evidence deepening |
| `mindmap-builder` | `mindmap-architecture-audit-and-evidence-deepening` | The same separated C2/C4/C5 authority projection, C5 draft skeleton, full bounded prior maps, and occupied directions | Recheck factual claims against direct source, audit peer-level families, retain valid ids, reorganize wrong-level families when needed, and deepen mechanisms and limits without promoting interpretations into observations | Complete existing mind-map scientific-content shape | Same schema and deterministic unique-family checks; exact ids only in explicitly requested content-only mode | One exact same-stage repair | Host-owned map assembly and publication |

## Skill-local workflow

1. Resolve the exact task, the authoritative prepared or sanitized source, shared research assets, and every visible terminal mind-map version for that task.
2. With no existing map, initialize from inspected evidence. With existing terminal maps, enter update or merge mode: give the skeleton call only their compact architecture summaries, preserve a family id only when it still names the same useful system-level intervention class, and reorganize narrow, redundant, or incomplete taxonomies when needed. Task-authorized but currently unvaried intervention classes may remain research families with an explicit evidence gap. If public hypotheses or formulas are supplied, use their compact projections to expose occupied methods, tensions, and missing alternatives without converting them into map families by copy.
3. Build an upper-system skeleton of supported observations, qualitative judgments, alternatives, tensions, evidence gaps, and exploitable opportunities; define each method-embryo family only here with a stable `family_id`.
4. In a second private call, treat the skeleton as a draft: first audit whether its families are peers at the intended system level, retaining valid ids and reorganizing wrong-level families when needed; then deepen each controllable-variable to intermediate-quantity to target-observable chain, including scope, competing mechanisms, bottlenecks, and falsifiable failure modes. Only explicit content-only mode freezes every incoming family id.
5. Represent breadth and depth explicitly so later hypotheses can cite `family_id` and `lineage_role`.
6. Publish once with every exact artifact ref actually used. In update or merge mode, `depends_on` must include every superseded terminal mind-map ref as well as the task and newly used evidence; this creates one authoritative terminal lineage. Immediately read back the exact result.

If a valid terminal map already covers the current evidence and there is no actual update objective, do not publish a parallel duplicate. Report the precise fact that the requested landscape already exists. If multiple terminal maps cannot be scientifically reconciled, report that bounded conflict instead of guessing a winner.

This skill uses one private three-stage workflow after selection:

1. The first model call sees the exact task and the authoritative prepared or sanitized source in mechanically labeled sections. It may inspect relevant original source pages using the read-only tools above. The host carries each successful page, its source ref and page bounds into both later stages and adds the read source refs to publication provenance. No source read means no inferred source content. The model returns the existing observations, interpretations and gaps shape; availability statements retain inspected-source and consumer scope. Unread or intentionally withheld content is not evidence of global absence.
2. The second model call sees the exact bounded task and sanitized records again, plus separately labeled model extraction, model interpretation, and unknown sections, compact prior-map architecture summaries, and compact occupied-direction projections. It verifies summaries against source and returns the upper-system family skeleton; old long-form map prose and full hypothesis, formula, review, and leaderboard payloads are not replayed into this architecture decision.
3. The third model call sees the same authority-separated source projection, the draft skeleton, and the full bounded prior-map authority. It performs the final factual and peer-level architecture audit, retains valid identities, reorganizes wrong-level families when required, recovers useful supported detail, and deepens the mechanisms, interactions, limits, and evidence gaps in the same existing content shape. Explicit content-only mode instead preserves every required family id.
4. Trusted Python assembles the existing artifact envelope and Markdown from the final scientific content, publishes once, and reads back the exact ref.

The first-stage raw source stays C4, both temporary stage results stay C5, raw prompts and turns stay C6, and only the final mind map becomes C2. The host owns transport fields; neither model call writes an artifact envelope, refs, dependencies, Markdown document, or next action.

## Formal output and handoff

Publish `hypothesis_mind_map` with one `artifact_publish` call. Use the existing tool shape exactly:

- top-level `artifact_kind` is `hypothesis_mind_map`;
- top-level `artifact_id` is a concise stable id, not an `artifact:...` ref;
- top-level `title` is non-empty;
- top-level `markdown` is the complete human-readable map;
- top-level `depends_on` lists every exact formal ref used;
- top-level `machine_payload` is the complete structured map.

Do not put `title`, `markdown`, or `depends_on` inside `machine_payload`. The structured payload contains `artifact_kind`, `mechanism_landscape`, and any existing direction-card container. `mechanism_landscape` persists `families`, `mechanism_landscape_summary`, `supported_relationships`, `unresolved_gaps`, and `evidence_boundary_summary`; these scientific contents must not exist only in Markdown. Markdown alone is not a machine payload, and the machine payload does not replace the required top-level Markdown.

Each `families` item under `mechanism_landscape` uses `family_id`, `title`, `causal_role`, `interaction_motif`, `scope_mode`, `tension_strategy`, `tension_ids`, `core_mechanism`, `mechanism_chain`, `key_prerequisites`, `main_bottleneck`, `expected_failure_mode`, `viability_band`, and existing lineage fields.

Use the existing fields with these meanings:

- `title` names the research direction or exploitable idea, not an inventory item.
- `core_mechanism` is a concise natural-language qualitative chain: what is observed or plausibly judged, why it may happen, and what method opportunity follows. Do not reduce it to a noun, label, or snake-case mechanism name.
- `mechanism_chain` is the machine-readable projection of that same narrative. `inputs_or_controls` names interventions, inputs, external conditions, or comparison states; `intermediate_processes` names mechanism steps or latent quantities; `target_observables` names quantities that can actually be observed or computed. All three lists are nonempty. This projection must preserve uncertainty and must not introduce claims absent from `core_mechanism`.
- `causal_role` and `interaction_motif` orient the physical or logical role of the direction.
- `key_prerequisites` states what must be true or available before the direction can work.
- `main_bottleneck` and `expected_failure_mode` make the idea falsifiable enough for later researchers to challenge.
- Every `supported_relationships` item uses exact ids from the same map in one drawable form: `source_family_id -> target_family_id: 說明` for directional influence or dependency, or `source_family_id <-> target_family_id: 說明` for mutual coupling, competition, or confounding. Unsupported relations remain absent rather than being added for visual completeness.
- Human-readable titles, summaries, mechanisms, relationships, gaps, and evidence boundaries use Traditional Chinese. Stable ids, formulas, symbols, units, abbreviations, chemical or material names, and scientific terms without an accurate Chinese equivalent retain their precise original form.

Named materials, components, variables, models, or known mechanisms may appear as evidence or prerequisites inside a family. They are not by themselves valid families. A useful test is whether a later researcher can answer: "What new design or low-cost quantitative proxy could I try because this branch exists?" If the branch only answers "what entities are present?", deepen it before publication.

The next call after publication must be `read_ref` on the exact returned ref. Return that ref and unresolved landscape gaps.

## Failure and repair

If the exact task or both admissible evidence paths are unavailable, report that precise gap. Repair structural omissions or failed readback inside this invocation. Scientific uncertainty remains an explicit map gap.

## Validation evidence

Completion requires readable stored content whose `machine_payload.mechanism_landscape.families` contains stable family identifiers, qualitative method embryos, and a `mechanism_chain` consistent with each `core_mechanism`, so later consumers can draw or inspect the causal skeleton without reinterpreting prose. Dependencies must name every formal artifact used, and claims must remain within inspected evidence. A component dictionary or list of known mechanisms is not complete merely because every field is populated. Missing families, mechanism chains, machine payload, or readback is incomplete.
