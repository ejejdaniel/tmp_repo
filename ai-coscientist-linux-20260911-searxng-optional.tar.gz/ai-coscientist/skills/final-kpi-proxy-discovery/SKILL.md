---
name: final-kpi-proxy-discovery
description: "Produces one frozen final-KPI proxy_formula_candidate. Requires exact task_spec and research evidence; evidence mode needs a hypothesis plus unmet review or Final LCA. Retains research provenance; execution selects its own compatible dataset. Ranking needs paired scoring data and its materialization. Boundary: no implementation, review, evaluation, ranking, or routing."
estimated_complexity: high
accepts_research_mode: true
---

# Final KPI Proxy Discovery

## Responsibility and boundary

Design and publish one interpretable, low-computation formula that may track the task's final-KPI trend. This skill owns scientific quantity selection, source grounding, formula composition, bounded producer self-review, and immutable formula publication.

It does not implement the formula, calculate record values, perform the shared method review, access ungranted target values, evaluate correlation, update a leaderboard, or choose the next workflow action. Materializer owns implementation. Reviewer and evaluator evidence later determine ranking.

The skill has two modes under the same output contract:

- **Autonomous discovery:** seek a final-KPI proxy from task meaning, public research assets, and sanitized sources.
- **Hypothesis evidence support:** only when the main agent explicitly supplies one hypothesis plus its unmet review or non-released Final LCA finding, seek a calculable substitute for that hypothesis's difficult physical quantity while retaining the final KPI as the formula target.

The skill never chooses its own recovery mission. Detailed ownership and mode rules are in [design-brief.md](references/design-brief.md).

## Research modes

The task-source axis is separate from the existing scientific mission: an
autonomous invocation searches broadly within the active formula node, while a
commissioned invocation follows the named gap and exact refs. The strategy axis
controls prior exposure. Deepen gives P1 the selected shared research and ranked
history. Explore gives P1 only target authority, source-independent task context,
and exact commissioned refs; P2 still grounds against real sanitized records,
and P3 restores the full public context and ranked history before composing and
reviewing the frozen formula.
Before invocation, common classifies the node-scoped candidate refs and derives
the final exact inputs. Task and sanitized-source authority remain visible in an
explore draft; shared evidence and comparison baselines return before P3.

## Entry conditions and authority

- An explicitly supplied `prepared_source_data` owns the visible record body and its provenance through exact artifact and body refs. It does not require a configured source manifest or a row count matching another dataset. Only when no prepared source is supplied do `scientific_source_manifest` and `scientific_source_visible_historical` establish the configured sanitized source. Malformed or ambiguous explicit prepared data must not silently fall back to configured data.
- With `evaluation_binding`, use its exact input table and target identity. Other task-scoped named bodies, including paired targets, preserve direct source content separately from model interpretation, starting at P2 and continuing through authoring, explanation and local review. P1 still does not see source records or source-derived background: this is independent exploration, not a permanent read prohibition. A matching `task_spec.data_use_authorizations` grant retains its named use and claim limit; ordinary measurements need no new grant. Dataset fit is not independent validation. State fitting explicitly; do not substitute target lookup for a scientific formula. A published formula retains its exact research-source dependency. Materializer may select another compatible prepared dataset for execution; scoring and Sample follow that execution's source. Do not rewrite an unchanged relation merely to change its calculation dataset.
- An explicit prepared source without `evaluation_binding` may support a scientifically valid exploratory Formula, but that Formula is not ready for private trend ranking. Preparing a scoring pair later does not mutate or rebind the immutable Formula. A scoreable successor must be authored from the scoring-ready prepared source while preserving earlier research provenance through its existing lineage.
- `resolved_inputs_for_active_skill` must contain one exact `task_spec`. Explicit `hypothesis_mind_map`, `hypothesis`, `hypothesis_leaderboard`, and `literature_claim_evidence` artifacts are optional public scientific context.
- A hypothesis-evidence mission additionally requires one unambiguous hypothesis lineage and the exact unmet `scientific_method_review` or non-released `final_lca_judgment`.
- Challenger discovery requires the current `proxy_formula_leaderboard`; its ranked formula history is read-only comparative evidence.
- Stored artifacts own content. Receipts, summaries, logs, and chat text do not replace exact stored refs.
- P2 may inspect task-scoped original definitions with the existing read-only source tools. A prepared table is the execution dataset, not a declaration that its columns contain all research knowledge. Keep the exact read pages through authoring, explanation and review, and publish their refs through existing `trace_refs`. Detailed source interpretation uses the shared `SOURCE_CONTEXT_GUIDE` rendered into these stages.
- Resolved inputs carry exact refs, while the stored content of each artifact remains the scientific authority used by every consuming stage.
- Final-KPI meaning, published leaderboard evidence and ordinary task measurements are readable. Explicit restrictions, evaluator-private sources and any named authorization's use limits remain in force; readable data does not authorize answer lookup or undeclared fitting.

If required authority is missing or ambiguous, return a bounded gap without publishing.

## Trigger examples

### Should select

- The task and sanitized source are available and the current node needs a new interpretable final-KPI proxy formula.
- A ranked formula history exists and the current node requests a scientifically distinct challenger.
- The main agent explicitly requests calculable evidence for one reviewed hypothesis gap.

### Should not select

- A formula is already frozen and needs code, execution, evaluation, or ranking.
- The task target or sanitized source is missing.
- Several possible hypothesis evidence lineages are supplied without an exact selection.

## Prompt and memory projection

- **C0:** objective, target meaning, user constraints, hidden-value boundary, and evaluation rule.
- **C1:** active formula-production node and exact input refs.
- **C2:** field-level projections of the exact task, mind map, hypotheses, literature evidence, and public leaderboards. Artifact refs remain visible; duplicate Markdown, receipts, and unrelated payload fields do not.
- **C3:** unused by formula production.
- **C4:** selected records, other prepared bodies and original source files remain source-owned. The record table is revealed to P2; definitions are read by exact source ref and page. P2-read page projections continue through later stages, including repair; no C6 replay or previous skill's observations substitute for these reads.
- **C5:** skill-local copy of the caller-owned research-mode card, P1 ideas, P2 grounding, invocation-local source-page projections, runtime-derived Materializer capability text, formula core, explanation, validator issues, three private review verdicts, and at most one stage-local repair chain. The authoritative mode card remains on the active C1 LOOP step; clear the C5 copy and other local items on exit.
- **C6:** full prompts, model turns, route receipts, and errors are audit-only.

Every model call receives a stage-specific projection. A later call does not inherit the full earlier prompt merely because the data remains stored. Evidence-language rules are defined once in [scientific-claim-calibration.md](references/scientific-claim-calibration.md).

### LLM call contracts

| Stage | Visible authority | Work and output | Validation and repair |
|---|---|---|---|
| Mode resolution | Exact C1 structured research-mode card plus exact resolved C2 refs | Mechanically validate and copy the caller-owned card; only old checkpoints use the compatibility classifier | Existing closed `{task_source, research_strategy, commissioned_input_refs}` schema and exact-ref subset; no semantic repair for a structured card |
| P1 first-principles discovery | Target plus compact public scientific context; no historical records | Propose candidate physical quantities, not a formula | Existing JSON schema; one same-stage format repair only when needed |
| P2 historical grounding | Task authority, P1, records, other prepared bodies, source-path catalog, scoped original-source navigation and Materializer capability | Inspect relevant source pages as needed; ground quantities against records plus explicit definitions | Existing inspection quota and source access rules; Python checks shape and exact record paths; one local grounding repair with the same sources and tools |
| P3 formula authoring | Target, compact public context, P1, accepted P2 grounding, Materializer capability and compact evaluated history | Compose one scalar formula using exact grounded names | Formula syntax, declared variables, grounding, target authority, and duplicate-computation checks; one local formula repair |
| Explanation deepening | Frozen candidate, exact grounding, Materializer capability and compact public assets | Deepen only meanings, target link, limitations, claim boundary, and text-valued criteria | Frozen identity, mathematics, source binding, direction, and non-text criteria; one same-stage repair |
| P4 producer reviews | Focused candidate projections plus only each review's required authority | Independently review relationship, operationalization, and observability | Each returns 0 for a hard producer defect or 4 otherwise. One complete-core repair and fresh reviews after any 0 |

Only a score of 0 is a red line in these producer reviews. A score 4 means no hard producer defect was established by that focused review; it is not a claim of perfect scientific quality.
Operationalization is admissible when at least one plausible faithful low-cost route exists within the declared source boundary; Materializer owns selecting and testing its concrete implementation.

Full stage contracts and review boundaries are in [p1-p4-stage-contracts.md](references/p1-p4-stage-contracts.md).
Available implementations and task-relative cost follow
[implementation-capability.md](references/implementation-capability.md), with
actual runtime metadata supplied from P2 onward. Materializer can develop code
using installed libraries directly; a matching prebuilt Route is not required.

## Skill-local workflow

1. Resolve exact task, optional public context, source authority, and optional explicit evidence-support lineage.
2. Run shared `develop_proxy_formula`: P1 discovery, P2 source grounding with optional read-only source inspection, P3 composition, explanation deepening, and three independent P4 producer reviews. P2 source pages survive each later projection; absence from a record is not proof of absence from the original sources.
3. Mechanically derive source binding and `materialization_contract` from accepted P2 grounding. Do not ask a model to re-copy transport fields.
4. Keep target identity host-controlled. The model cannot rename `target_kind` or `target_id`.
5. For a challenger, reject the same operational computation even if names, parentheses, scale, or version differ.
6. Publish one validated artifact and immediately read back the exact ref.

Scientific uncertainty is legal. Weak evidence, no measured optimum, uncertain direction outside the stated regime, or poor later correlation does not justify fabricated calibration. A producer review blocks only a hard defect in the candidate as written.

## Formal output and handoff

Publish the existing `proxy_formula_candidate` format through `artifact_publish`:

The host stores the following structured fields under `machine_payload`; the
model does not author the artifact envelope or transport metadata.
An artifact with an incomplete `machine_payload` is not a valid formula result.

- identity and target: `artifact_kind`, `target_kind`, `target_id`, `formula_id`, `version`
- computation: `formula_expression`, `selected_candidate_proxy_quantity_refs`, `input_variables`
- provenance: `source_binding`, `historical_variation_evidence`, `materialization_contract`
- scientific claim: `expected_final_kpi_link`, `expected_relation`, `side_effect_notes`, `claim_boundary`, `validation_criteria`

`formula_expression` is one Python/SciPy scalar expression using declared names and numeric constants. `higher_proxy_higher_kpi` means larger is expected to satisfy the current target better; `lower_proxy_higher_kpi` means smaller is expected to satisfy it better. The statement is a falsifiable expectation, not proof of correlation.

Set `depends_on` to exact formal refs actually used and preserve prepared-source trace refs. Read back the published ref before returning it. Never return a prescribed next skill.
The readback is the exact `read_ref` boundary: publication is incomplete until
the stored artifact is read and its structured content matches the candidate.

## Failure and repair

Format and structural defects stay within their producing stage for one bounded repair. A P4 score of 0 receives one formula-core repair, explanation refresh, and three fresh reviews. A second red line, missing source authority, ambiguous evidence lineage, unavailable low-cost route, or duplicate challenger returns a precise gap without publication.

P2 can return an empty grounded set with the existing summary/exclusions when
no suitable quantity is available. The shared stage contract distinguishes
missing selected-table inputs from missing inspected-source information.
This exits as `bounded_gap` before P3; a nonempty usable set may still proceed
when other P1 ideas were excluded.

This skill never repairs Materializer code, changes the target, invents missing values, evaluates held-out KPI evidence, or routes around a real capability gap.

## Validation evidence

Before publication, prove exact target authority, formula syntax, declared-variable use, source binding, mechanically assembled materialization contract, no duplicate computation, three completed producer reviews without a remaining red line, exact dependency closure, and readback equality. Deterministic tests cover stage visibility and repair boundaries. A real-model boundary test proves only formula production; it does not prove Materializer execution, ranking, or end-to-end completion.

## References

- [Design brief](references/design-brief.md)
- [P1-P4 stage contracts](references/p1-p4-stage-contracts.md)
- [Scientific claim calibration](references/scientific-claim-calibration.md)
- [Implementation capability](references/implementation-capability.md)
