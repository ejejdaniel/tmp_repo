"""Validation helpers for final-KPI proxy discovery artifacts."""

from __future__ import annotations

import ast
import json
import math
import re
from typing import Any, Mapping, Sequence


_REQUIRED_FIELDS = (
    "artifact_kind",
    "formula_id",
    "version",
    "formula_expression",
    "selected_candidate_proxy_quantity_refs",
    "input_variables",
    "source_binding",
    "historical_variation_evidence",
    "expected_final_kpi_link",
    "expected_relation",
    "side_effect_notes",
    "claim_boundary",
    "validation_criteria",
    "materialization_contract",
)
_FORBIDDEN_KEYS = {
    "ground_truth_kpi",
    "avg_score",
    "score_MoO3",
    "score_WO3",
    "substrate_scores",
    "proxy_values_by_sample",
    "component_values_by_sample",
}
_ALLOWED_FUNCTIONS = {"abs", "clip", "exp", "log", "max", "min", "sqrt"}
_ALLOWED_MODULES = {"math", "np", "numpy", "scipy"}
_ALLOWED_AST_NODES = (
    ast.Expression,
    ast.BinOp,
    ast.UnaryOp,
    ast.Call,
    ast.Name,
    ast.Load,
    ast.Constant,
    ast.Attribute,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.Pow,
    ast.Mod,
    ast.USub,
    ast.UAdd,
)


class OuterFormulaValidationError(ValueError):
    pass


def validate_formula_candidate(candidate: Mapping[str, Any]) -> list[str]:
    return _deduplicated(
        [
            *validate_formula_core(candidate),
            *validate_materialization_contract(candidate),
        ]
    )


def validate_formula_core(candidate: Mapping[str, Any]) -> list[str]:
    issues: list[str] = []
    for field in _REQUIRED_FIELDS:
        if field == "materialization_contract":
            continue
        if not _present(candidate.get(field)):
            issues.append(f"missing_or_empty:{field}")
    if candidate.get("artifact_kind") != "proxy_formula_candidate":
        issues.append("artifact_kind_must_be_proxy_formula_candidate")
    version = candidate.get("version")
    if isinstance(version, bool) or not isinstance(version, int) or version < 1:
        issues.append("version_must_be_positive_integer")

    expression = str(candidate.get("formula_expression") or "").strip()
    input_names, input_issues = _input_variable_names(candidate.get("input_variables"))
    issues.extend(input_issues)
    expression_names: set[str] = set()
    if expression:
        expression_names, expression_issues = _expression_names(expression)
        issues.extend(expression_issues)
    if input_names:
        unknown = sorted(expression_names - set(input_names))
        unused = sorted(set(input_names) - expression_names)
        if unknown:
            issues.append(f"formula_uses_undeclared_variables:{unknown}")
        if unused:
            issues.append(f"declared_variables_not_used_by_formula:{unused}")

    selected = candidate.get("selected_candidate_proxy_quantity_refs")
    selected_names = (
        [str(value).strip() for value in selected]
        if isinstance(selected, Sequence) and not isinstance(selected, (str, bytes))
        else []
    )
    if input_names and set(selected_names) != set(input_names):
        issues.append("selected_quantity_refs_must_match_input_variables")

    source_binding = candidate.get("source_binding")
    if isinstance(source_binding, Mapping):
        for name in input_names:
            if not _present(source_binding.get(name)):
                issues.append(f"missing_source_binding:{name}")
    elif input_names:
        issues.append("source_binding_must_be_object")

    relation = str(candidate.get("expected_relation") or "").strip()
    if relation not in {"higher_proxy_higher_kpi", "lower_proxy_higher_kpi"}:
        issues.append("expected_relation_unsupported")
    leaked = sorted(_find_forbidden_keys(candidate))
    if leaked:
        issues.append(f"forbidden_private_or_materialized_fields:{leaked}")
    return _deduplicated(issues)


def validate_materialization_contract(candidate: Mapping[str, Any]) -> list[str]:
    issues: list[str] = []
    expression = str(candidate.get("formula_expression") or "").strip()
    input_names, _ = _input_variable_names(candidate.get("input_variables"))
    contract = candidate.get("materialization_contract")
    if not _present(contract):
        return ["missing_or_empty:materialization_contract"]
    if not isinstance(contract, Mapping):
        return ["materialization_contract_must_be_object"]
    contract_inputs = contract.get("inputs")
    contract_names = (
        [str(value).strip() for value in contract_inputs]
        if isinstance(contract_inputs, Sequence)
        and not isinstance(contract_inputs, (str, bytes))
        else []
    )
    if input_names and set(contract_names) != set(input_names):
        issues.append("materialization_contract_inputs_must_match_formula")
    if str(contract.get("formula_expression") or "").strip() != expression:
        issues.append("materialization_contract_formula_expression_mismatch")
    if not _present(contract.get("output")):
        issues.append("materialization_contract_output_required")
    if not _present(contract.get("missing_value_policy")):
        issues.append("materialization_contract_missing_value_policy_required")
    candidate_contracts = contract.get("candidate_contracts")
    if not isinstance(candidate_contracts, Mapping):
        issues.append("materialization_contract_candidate_contracts_required")
    else:
        for name in input_names:
            item = candidate_contracts.get(name)
            if not isinstance(item, Mapping) or not item:
                issues.append(f"materialization_candidate_contract_required:{name}")
                continue
            if not _present(item.get("required_inputs")):
                issues.append(f"materialization_required_inputs_required:{name}")
            if not _present(item.get("algorithmic_steps")):
                issues.append(f"materialization_algorithmic_steps_required:{name}")
            if not _present(item.get("missing_value_policy")):
                issues.append(f"materialization_missing_value_policy_required:{name}")
            if item.get("external_data_or_measurement_required") is True:
                issues.append(f"external_measurement_not_supported:{name}")
    return _deduplicated(issues)

def require_valid_formula_candidate(candidate: Mapping[str, Any]) -> None:
    issues = validate_formula_candidate(candidate)
    if issues:
        raise OuterFormulaValidationError("; ".join(issues))


def render_formula_markdown(candidate: Mapping[str, Any]) -> str:
    variables = []
    bindings = candidate.get("source_binding")
    bindings = bindings if isinstance(bindings, Mapping) else {}
    for item in candidate.get("input_variables") or []:
        if isinstance(item, Mapping):
            name = str(item.get("name") or "").strip()
            meaning = str(item.get("meaning") or "").strip()
        else:
            name = str(item).strip()
            meaning = ""
        if not name:
            continue
        binding = bindings.get(name)
        binding_text = json.dumps(binding, ensure_ascii=False, sort_keys=True)
        variables.append(f"- `{name}`: {meaning} Source: `{binding_text}`")
    side_effects = [
        f"- {str(value)}" for value in candidate.get("side_effect_notes") or []
    ]
    return "\n".join(
        [
            "# Proxy Formula Candidate",
            "",
            f"Formula: `{candidate.get('formula_expression', '')}`",
            f"Expected relation: `{candidate.get('expected_relation', '')}`",
            "",
            "## Inputs",
            *(variables or ["- No declared inputs."]),
            "",
            "## Scientific link",
            str(candidate.get("expected_final_kpi_link") or ""),
            "",
            "## Limits",
            *(side_effects or ["- No limits declared."]),
            "",
            "## Claim boundary",
            str(candidate.get("claim_boundary") or ""),
        ]
    ).strip()


def _input_variable_names(value: Any) -> tuple[list[str], list[str]]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return [], ["input_variables_must_be_array"]
    names: list[str] = []
    issues: list[str] = []
    for index, item in enumerate(value):
        if isinstance(item, Mapping):
            name = str(item.get("name") or "").strip()
            if not _present(item.get("meaning")):
                issues.append(f"input_variable_meaning_required:{index}")
        else:
            name = str(item).strip()
        if not name or not name.isidentifier():
            issues.append(f"input_variable_name_invalid:{index}:{name}")
            continue
        if name in names:
            issues.append(f"input_variable_name_duplicate:{name}")
            continue
        names.append(name)
    if not names:
        issues.append("at_least_one_input_variable_required")
    return names, issues


def _expression_names(expression: str) -> tuple[set[str], list[str]]:
    if len(expression) > 500:
        return set(), ["formula_expression_too_long"]
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        return set(), [f"formula_expression_invalid:{exc.msg}"]
    issues: list[str] = []
    if any(not isinstance(node, _ALLOWED_AST_NODES) for node in ast.walk(tree)):
        issues.append("formula_expression_contains_unsupported_syntax")
    function_names: set[str] = set()
    module_names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant):
            if isinstance(node.value, bool) or not isinstance(node.value, (int, float)):
                issues.append("formula_constants_must_be_numeric")
            elif not math.isfinite(float(node.value)):
                issues.append("formula_constants_must_be_finite")
        if not isinstance(node, ast.Call):
            continue
        if isinstance(node.func, ast.Name):
            function_names.add(node.func.id)
            if node.func.id not in _ALLOWED_FUNCTIONS:
                issues.append(f"formula_function_unsupported:{node.func.id}")
        elif isinstance(node.func, ast.Attribute):
            root = node.func.value
            while isinstance(root, ast.Attribute):
                root = root.value
            if not isinstance(root, ast.Name) or root.id not in _ALLOWED_MODULES:
                issues.append("formula_function_module_unsupported")
            elif isinstance(root, ast.Name):
                module_names.add(root.id)
        else:
            issues.append("formula_callable_unsupported")
    names = {
        node.id
        for node in ast.walk(tree)
        if isinstance(node, ast.Name)
        and node.id not in function_names
        and node.id not in module_names
    }
    return names, issues


def _find_forbidden_keys(value: Any) -> set[str]:
    found: set[str] = set()
    if isinstance(value, Mapping):
        for key, item in value.items():
            if str(key) in _FORBIDDEN_KEYS:
                found.add(str(key))
            found.update(_find_forbidden_keys(item))
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        for item in value:
            found.update(_find_forbidden_keys(item))
    return found


def _present(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, Mapping):
        return bool(value)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return bool(value)
    return True


def _deduplicated(values: Sequence[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        if value not in result:
            result.append(value)
    return result
