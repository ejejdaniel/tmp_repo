"""Skill-local workflow for final-KPI proxy discovery."""

from __future__ import annotations

import ast
from typing import Any, Mapping, Sequence

from ai_coscientist.domain.proxy_formula_contract import (
    render_formula_markdown,
    validate_formula_candidate,
    validate_formula_core,
)
from ai_coscientist.domain.proxy_discovery import (
    ProxySourceGroundingGap,
    develop_proxy_formula,
)
from ai_coscientist.domain.prepared_sources import (
    PreparedSourceData,
    resolve_prepared_source_data,
)
from ai_coscientist.domain.prepared_evaluation import (
    prepared_historical_data, prepared_background,
    final_kpi_target_metric as _final_kpi_target_metric,
)
from ai_coscientist.domain.data_use_authorization import resolve_task_authorized_prepared_data
from ai_coscientist.domain.source_inspection import SourceInspection
from ai_coscientist.domain.proxy_formula_ranking import (
    terminal_proxy_formula_leaderboard,
    validate_proxy_formula_leaderboard,
)
from ai_coscientist.domain.scientific_review import (
    validate_scientific_method_review,
)
from ai_coscientist.domain.research_modes import (
    ResearchMode,
    initial_research_inputs,
    resolve_research_mode,
)


def run(payload: dict[str, Any], runtime: Any) -> dict[str, Any]:
    resolved = _resolve_explicit_final_kpi_proxy_artifacts(
        runtime,
        list(payload.get("resolved_inputs") or []),
    )
    research_mode = resolve_research_mode(
        payload,
        runtime,
        resolved,
        skill_id="final-kpi-proxy-discovery",
    )
    initial_resolved = initial_research_inputs(
        research_mode,
        resolved,
        shared_artifact_kinds=(
            "hypothesis_mind_map",
            "hypothesis",
            "hypothesis_leaderboard",
            "proxy_formula_candidate",
            "quantitative_proxy_materialization_result",
            "proxy_formula_leaderboard",
            "scientific_method_review",
            "final_lca_judgment",
            "literature_claim_evidence",
        ),
        always_visible_artifact_kinds=("task_spec", "prepared_source_data"),
    )
    prepared_source = resolve_prepared_source_data(
        runtime,
        resolved,
        consumer="final_kpi_proxy",
    )
    if prepared_source is not None:
        visible_historical = _prepared_historical_data(prepared_source)
        _validate_visible_records(visible_historical)
        manifest = prepared_source.prompt_projection()
        for output in manifest["prepared_outputs"]:
            del output["content"]
    else:
        manifest = runtime.call_route("scientific_source_manifest", {})
        visible_historical = runtime.call_route("scientific_source_visible_historical", {})
        _validate_visible_source(manifest, visible_historical)
    leaderboard = terminal_proxy_formula_leaderboard(resolved)
    return _draft_formula(
        runtime,
        resolved=resolved,
        initial_resolved=initial_resolved,
        research_mode=research_mode,
        bookkeeping_artifacts=resolved,
        manifest=manifest,
        visible_historical=visible_historical,
        leaderboard=leaderboard,
        prepared_source=prepared_source,
    )


def _draft_formula(
    runtime: Any,
    *,
    resolved: Sequence[Mapping[str, Any]],
    initial_resolved: Sequence[Mapping[str, Any]] | None = None,
    research_mode: ResearchMode | None = None,
    bookkeeping_artifacts: Sequence[Mapping[str, Any]],
    manifest: Mapping[str, Any],
    visible_historical: Mapping[str, Any],
    leaderboard: Mapping[str, Any] | None = None,
    prepared_source: PreparedSourceData | None = None,
) -> dict[str, Any]:
    mode = research_mode or ResearchMode(
        task_source="autonomous",
        research_strategy="deepen",
        commissioned_input_refs=(),
        explicit_selection=False,
    )
    formal_context = _required_drafting_context(resolved)
    task = next(item for item in resolved if item.get("artifact_ref") == formal_context[0]["artifact_ref"])
    authorized_data = resolve_task_authorized_prepared_data(
        runtime, task=task, resolved_inputs=resolved,
        consumer_skill_id="final-kpi-proxy-discovery", require_grant=False,
    )
    initial_context = _required_drafting_context(
        initial_resolved if initial_resolved is not None else resolved
    )
    commissioned_refs = set(mode.commissioned_input_refs)
    support_inputs = (
        [
            item
            for item in resolved
            if str(item.get("artifact_ref") or "") in commissioned_refs
        ]
        if mode.explicit_selection and mode.task_source == "commissioned"
        else resolved
    )
    support_resolution = (
        _resolve_evidence_support_mission(support_inputs)
        if not mode.explicit_selection or mode.task_source == "commissioned"
        else {"status": "autonomous", "mission": None}
    )
    if support_resolution.get("status") == "bounded_gap":
        return {
            "status": "bounded_gap",
            "reason": str(support_resolution["reason"]),
        }
    support_mission = support_resolution.get("mission")
    if isinstance(support_mission, Mapping):
        formal_context.append(dict(support_mission["prompt_context"]))
        initial_context.append(dict(support_mission["prompt_context"]))
    target_metric = _final_kpi_target_metric(
        formal_context,
        visible_historical=visible_historical,
    )
    direct_formulas = [
        dict(item)
        for item in _terminal_artifacts_by_kind(
            _deduplicated_artifacts(bookkeeping_artifacts)
        ).get("proxy_formula_candidate", [])
    ]
    ranked_formulas: list[dict[str, Any]] = []
    if leaderboard is not None:
        ranked_formulas = _leaderboard_formula_artifacts(
            runtime, leaderboard, bookkeeping_artifacts
        )
        if not ranked_formulas:
            raise ValueError("proxy_formula_leaderboard_formula_refs_required")
    existing_formulas = list(
        {
            str(item["artifact_ref"]): item
            for item in [*ranked_formulas, *direct_formulas]
        }.values()
    )
    evaluated_history = _leaderboard_prompt_context(
        leaderboard,
        ranked_formulas,
    )
    initial_refs = {
        str(item.get("artifact_ref") or "")
        for item in (
            initial_resolved if initial_resolved is not None else resolved
        )
    }
    initial_evaluated_history = (
        evaluated_history
        if leaderboard is not None
        and str(leaderboard.get("artifact_ref") or "") in initial_refs
        else []
    )

    def validate_challenger_core(core: Mapping[str, Any]) -> list[str]:
        issues = list(validate_formula_core(core))
        if any(
            _same_materialized_formula(item["machine_payload"], core)
            for item in existing_formulas
        ):
            issues.append(
                "formula_duplicates_evaluated_history: the proposed formula "
                "has the same operational expression, variables, source "
                "paths, and direction as an evaluated formula"
            )
        return issues

    inspection = SourceInspection(runtime, resolved)
    source_background = (
        prepared_background(prepared_source) if prepared_source is not None else {}
    )
    source_background["source_transport_metadata"] = {
        "content": {"trace_refs": inspection.source_refs},
    }
    source_background["inspected_source_pages"] = inspection.page_projection()
    try:
        candidate = develop_proxy_formula(
            runtime,
            target_metric=target_metric,
            formal_scientific_context=formal_context,
            first_principles_scientific_context=initial_context,
            source_manifest=manifest,
            sanitized_historical_data=visible_historical,
            source_background=source_background,
            source_inspection=inspection,
            authorized_task_data=(authorized_data.prompt_projection() if authorized_data is not None else None),
            evaluated_formula_history=evaluated_history,
            first_principles_formula_history=initial_evaluated_history,
            research_mode=mode.prompt_projection(),
            validate_formula_core=validate_challenger_core,
            validate_formula_candidate=validate_formula_candidate,
            purpose_prefix=(
                "draft-hypothesis-evidence-proxy"
                if isinstance(support_mission, Mapping)
                else "draft-proxy"
            ),
        )
    except ProxySourceGroundingGap as exc:
        return {
            "status": "bounded_gap",
            "reason": (
                f"Selected prepared source: {prepared_source.artifact_ref}. "
                if prepared_source is not None else ""
            ) + str(exc),
        }
    except ValueError as exc:
        if (
            existing_formulas
            and "formula_duplicates_evaluated_history" in str(exc)
        ):
            return _duplicate_formula_result()
        if "proxy_formula_private_redline_after_local_repair" in str(exc):
            return {
                "status": "bounded_gap",
                "reason": (
                    "The drafted proxy and one local scientific repair both "
                    "failed target-coherence review, so Final-KPI Proxy "
                    "Discovery has no "
                    "publishable formula for this route. New scientific "
                    "evidence or a different grounded construction is required "
                    "before another attempt. Details: "
                    + str(exc)
                ),
            }
        raise

    if existing_formulas:
        candidate = dict(candidate)
        formula_id = str(candidate.get("formula_id") or "").strip()
        lineage_versions = [
            int(item["machine_payload"].get("version") or 0)
            for item in existing_formulas
            if str(item["machine_payload"].get("formula_id") or "").strip()
            == formula_id
        ]
        candidate["version"] = (
            max(lineage_versions) + 1 if lineage_versions else 1
        )
        if any(
            _same_materialized_formula(item["machine_payload"], candidate)
            for item in existing_formulas
        ):
            return _duplicate_formula_result()
    depends_on = [
        str(item["artifact_ref"])
        for item in formal_context
        if str(item.get("artifact_ref") or "").startswith("artifact:")
    ]
    if isinstance(support_mission, Mapping):
        depends_on.extend(str(ref) for ref in support_mission["depends_on"])
    if leaderboard is not None:
        depends_on.append(str(leaderboard["artifact_ref"]))
    if prepared_source is not None:
        depends_on.append(prepared_source.artifact_ref)
    depends_on = list(dict.fromkeys(depends_on))
    return _publish_formula(
        runtime,
        candidate=candidate,
        depends_on=depends_on,
        trace_refs=(
            tuple(dict.fromkeys((
                *(prepared_source.trace_refs if prepared_source is not None else ()),
                *(authorized_data.prepared_source.trace_refs if authorized_data is not None else ()),
                *inspection.read_refs,
            )))
        ),
    )


def _resolve_explicit_final_kpi_proxy_artifacts(
    runtime: Any, resolved: Sequence[Mapping[str, Any]]
) -> list[dict[str, Any]]:
    relevant_kinds = {
        "task_spec",
        "hypothesis_mind_map",
        "hypothesis",
        "hypothesis_leaderboard",
        "prepared_source_data",
        "proxy_formula_candidate",
        "quantitative_proxy_materialization_result",
        "proxy_formula_leaderboard",
        "scientific_method_review",
        "final_lca_judgment",
        "literature_claim_evidence",
    }
    by_ref: dict[str, dict[str, Any]] = {}
    for raw in resolved:
        if not isinstance(raw, Mapping):
            continue
        kind = str(raw.get("artifact_kind") or "")
        if kind not in relevant_kinds:
            continue
        artifact_ref = str(raw.get("artifact_ref") or "")
        if not artifact_ref.startswith("artifact:"):
            raise ValueError(
                "final_kpi_proxy_resolved_artifact_ref_invalid"
            )
        artifact = dict(raw)
        if not isinstance(artifact.get("machine_payload"), Mapping):
            artifact = dict(runtime.read_artifact(artifact_ref))
        if artifact.get("artifact_kind") != kind:
            raise ValueError(
                "final_kpi_proxy_resolved_artifact_kind_mismatch"
            )
        by_ref[artifact_ref] = artifact

    return list(by_ref.values())


def _resolve_evidence_support_mission(
    explicit: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Resolve one optional hypothesis evidence objective from explicit refs."""
    hypotheses = [
        dict(item) for item in explicit if item.get("artifact_kind") == "hypothesis"
    ]
    hypothesis_by_ref = {
        str(item.get("artifact_ref") or ""): item for item in hypotheses
    }
    reviews_by_hypothesis: dict[str, list[dict[str, Any]]] = {}
    judgments_by_hypothesis: dict[str, list[dict[str, Any]]] = {}
    evidence_by_hypothesis: dict[str, list[dict[str, Any]]] = {}

    for item in explicit:
        if item.get("artifact_kind") == "scientific_method_review":
            try:
                review = validate_scientific_method_review(item)
            except ValueError:
                raise
            method_ref = str(review["method_artifact_ref"])
            if method_ref not in hypothesis_by_ref:
                continue
            reviews_by_hypothesis.setdefault(method_ref, []).append(dict(item))
            continue
        if item.get("artifact_kind") != "final_lca_judgment":
            continue
        judgment_payload = item.get("machine_payload")
        judgment = (
            judgment_payload.get("final_lca_judgment")
            if isinstance(judgment_payload, Mapping)
            else None
        )
        if not isinstance(judgment, Mapping):
            raise ValueError("proxy_evidence_support_final_lca_payload_invalid")
        if judgment.get("outcome") == "released":
            continue
        matching_refs = sorted(
            set(_artifact_dependency_refs(item)) & set(hypothesis_by_ref)
        )
        if len(matching_refs) > 1:
            return {
                "status": "bounded_gap",
                "reason": (
                    "proxy_evidence_support_final_lca_hypothesis_ambiguous:"
                    f"refs={matching_refs}"
                ),
            }
        if matching_refs:
            judgments_by_hypothesis.setdefault(matching_refs[0], []).append(
                dict(item)
            )

    for hypothesis_ref, reviews in reviews_by_hypothesis.items():
        versions = [
            int(validate_scientific_method_review(item)["version"])
            for item in reviews
        ]
        latest_version = max(versions)
        latest = [
            item
            for item, version in zip(reviews, versions)
            if version == latest_version
        ]
        if len(latest) != 1:
            return {
                "status": "bounded_gap",
                "reason": (
                    "proxy_evidence_support_review_version_ambiguous:"
                    f"hypothesis={hypothesis_ref}:version={latest_version}"
                ),
            }
        latest_payload = validate_scientific_method_review(latest[0])
        if float(latest_payload["review_score"]) < 100.0:
            evidence_by_hypothesis.setdefault(hypothesis_ref, []).append(
                latest[0]
            )

    for hypothesis_ref, judgments in judgments_by_hypothesis.items():
        if len(judgments) != 1:
            return {
                "status": "bounded_gap",
                "reason": (
                    "proxy_evidence_support_final_lca_selection_ambiguous:"
                    f"hypothesis={hypothesis_ref}:actual={len(judgments)}"
                ),
            }
        evidence_by_hypothesis.setdefault(hypothesis_ref, []).append(
            judgments[0]
        )

    sponsored_refs = sorted(evidence_by_hypothesis)
    if not sponsored_refs:
        return {"status": "autonomous", "mission": None}
    if len(sponsored_refs) != 1:
        return {
            "status": "bounded_gap",
            "reason": (
                "proxy_evidence_support_hypothesis_selection_ambiguous:"
                f"refs={sponsored_refs}"
            ),
        }
    hypothesis_ref = sponsored_refs[0]
    evidence = evidence_by_hypothesis[hypothesis_ref]

    hypothesis = hypothesis_by_ref[hypothesis_ref]
    evidence_refs = [
        str(item.get("artifact_ref") or "")
        for item in evidence
        if str(item.get("artifact_ref") or "").startswith("artifact:")
    ]
    return {
        "status": "evidence_support",
        "mission": {
            "depends_on": [hypothesis_ref, *evidence_refs],
            "prompt_context": {
                "context_role": "hypothesis_evidence_support",
                "hypothesis": _drafting_context_projection(
                    hypothesis,
                    kind="hypothesis",
                ),
                "quality_findings": [
                    _drafting_context_projection(
                        item,
                        kind=str(item["artifact_kind"]),
                    )
                    for item in evidence
                ],
                "reasoning_objective": (
                    "Trace the hypothesis claim to a difficult physical "
                    "quantity, identify a faithful low-cost computable "
                    "substitute, explain how it represents the original "
                    "mechanism and may track the final KPI, and state its "
                    "failure boundary. Treat the hypothesis and findings as "
                    "nonbinding evidence needs, not as permission to force an "
                    "unsupported formula."
                ),
            },
        },
    }


def _artifact_dependency_refs(artifact: Mapping[str, Any]) -> list[str]:
    raw_refs = artifact.get("depends_on")
    if isinstance(raw_refs, (str, bytes)) or not isinstance(raw_refs, Sequence):
        return []
    return [
        str(ref).strip()
        for ref in raw_refs
        if str(ref).strip().startswith("artifact:")
    ]


def _leaderboard_formula_artifacts(
    runtime: Any,
    leaderboard: Mapping[str, Any],
    artifacts: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    payload = leaderboard.get("machine_payload")
    validate_proxy_formula_leaderboard(payload)
    by_ref = {
        str(item.get("artifact_ref") or ""): dict(item)
        for item in artifacts
        if item.get("artifact_kind") == "proxy_formula_candidate"
    }
    result: list[dict[str, Any]] = []
    for entry in payload["ranked_entries"]:
        formula_ref = str(entry["formula_artifact_ref"])
        formula = by_ref.get(formula_ref)
        if formula is None:
            formula = dict(runtime.read_artifact(formula_ref))
            if formula.get("artifact_kind") != "proxy_formula_candidate":
                raise ValueError(
                    "proxy_formula_leaderboard_formula_kind_mismatch:"
                    + formula_ref
                )
        if not isinstance(formula.get("machine_payload"), Mapping):
            raise ValueError(
                "proxy_formula_leaderboard_formula_payload_required:"
                + formula_ref
            )
        result.append(formula)
    return result


def _leaderboard_prompt_context(
    leaderboard: Mapping[str, Any] | None,
    formulas: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    if leaderboard is None:
        return []
    entries = leaderboard["machine_payload"]["ranked_entries"]
    result: list[dict[str, Any]] = []
    for entry, formula in zip(entries, formulas):
        payload = formula["machine_payload"]
        result.append(
            {
                "rank": entry["rank"],
                "trend_alignment_score": entry["trend_alignment_score"],
                "review_score": entry["review_score"],
                "pareto_tier": entry["pareto_tier"],
                "formula_artifact_ref": entry["formula_artifact_ref"],
                "formula_expression": payload.get("formula_expression"),
                "input_variables": payload.get("input_variables"),
                "expected_final_kpi_link": payload.get(
                    "expected_final_kpi_link"
                ),
                "expected_relation": payload.get("expected_relation"),
            }
        )
    return result


def _same_materialized_formula(
    prior: Mapping[str, Any], candidate: Mapping[str, Any]
) -> bool:
    return _materialized_formula_signature(prior) == _materialized_formula_signature(
        candidate
    )


def _materialized_formula_signature(candidate: Mapping[str, Any]) -> dict[str, Any]:
    contract = candidate.get("materialization_contract")
    contract = contract if isinstance(contract, Mapping) else {}
    candidate_contracts = contract.get("candidate_contracts")
    candidate_contracts = (
        candidate_contracts if isinstance(candidate_contracts, Mapping) else {}
    )
    source_binding = candidate.get("source_binding")
    source_binding = source_binding if isinstance(source_binding, Mapping) else {}
    variables = sorted(
        str(name)
        for name in candidate.get("selected_candidate_proxy_quantity_refs") or []
    )
    source_paths: dict[str, list[str]] = {}
    for name in variables:
        route = candidate_contracts.get(name)
        if not isinstance(route, Mapping):
            route = source_binding.get(name)
        route = route if isinstance(route, Mapping) else {}
        paths = route.get("required_inputs")
        if paths is None:
            paths = route.get("source_inputs")
        source_paths[name] = sorted(str(path) for path in paths or [])
    expression = str(candidate.get("formula_expression") or "").strip()
    try:
        expression_tree = ast.dump(
            ast.parse(expression, mode="eval"),
            annotate_fields=True,
            include_attributes=False,
        )
    except SyntaxError:
        expression_tree = expression
    return {
        "formula_expression_ast": expression_tree,
        "selected_candidate_proxy_quantity_refs": variables,
        "source_paths": source_paths,
        "expected_relation": candidate.get("expected_relation"),
    }


def _duplicate_formula_result() -> dict[str, Any]:
    return {
        "status": "bounded_gap",
        "reason": (
            "The proposed computation duplicates an evaluated formula. "
            "One local P4 repair did not yield a distinct computation. The "
            "attempt produced no new proxy formula candidate."
        ),
    }


def _publish_formula(
    runtime: Any,
    *,
    candidate: Mapping[str, Any],
    depends_on: Sequence[str],
    trace_refs: Sequence[str],
    summary: str | None = None,
) -> dict[str, Any]:
    issues = validate_formula_candidate(candidate)
    if issues:
        raise ValueError("proxy_formula_publication_blocked:" + "; ".join(issues))
    formula_id = str(candidate.get("formula_id") or "proxy-formula")
    target_kind = str(candidate.get("target_kind") or "unspecified")
    target_id = str(candidate.get("target_id") or "unspecified")
    receipt = runtime.publish_artifact(
        artifact_kind="proxy_formula_candidate",
        artifact_id=f"{formula_id}-v{candidate.get('version')}",
        title=f"Proxy Formula Candidate {formula_id}",
        markdown=render_formula_markdown(candidate),
        summary=summary
        or (
            "Interpretable low-cost proxy formula with source-bound inputs "
            "and a materialization handoff. "
            f"Target: target_kind={target_kind}; target_id={target_id}."
        ),
        machine_payload=dict(candidate),
        depends_on=depends_on,
        trace_refs=trace_refs,
        self_review={"formula_contract_validated": True},
    )
    stored = runtime.read_artifact(receipt["artifact_ref"])
    if stored.get("machine_payload") != dict(candidate):
        raise ValueError("published_proxy_formula_readback_mismatch")
    return {
        "status": "completed",
        "summary": "Published and read back a validated proxy formula candidate.",
        "artifact_ref": receipt["artifact_ref"],
    }


def _required_drafting_context(
    resolved: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    required = ("task_spec",)
    resolved = _deduplicated_artifacts(resolved)
    terminal_by_kind = _terminal_artifacts_by_kind(resolved)
    result: list[dict[str, Any]] = []
    for kind in required:
        matches = terminal_by_kind.get(kind, [])
        if len(matches) != 1:
            raise ValueError(
                "final_kpi_proxy_requires_one_resolved_"
                f"{kind}:actual={len(matches)}"
            )
        result.append(_drafting_context_projection(matches[0], kind=kind))
    for kind in (
        "hypothesis_mind_map",
        "hypothesis",
        "hypothesis_leaderboard",
        "literature_claim_evidence",
        "proxy_formula_candidate",
    ):
        for artifact in terminal_by_kind.get(kind, []):
            if artifact.get("artifact_kind") == kind:
                result.append(_drafting_context_projection(artifact, kind=kind))
    return result


def _deduplicated_artifacts(
    artifacts: Sequence[Mapping[str, Any]],
) -> list[Mapping[str, Any]]:
    by_ref: dict[str, Mapping[str, Any]] = {}
    for artifact in artifacts:
        artifact_ref = str(artifact.get("artifact_ref") or "")
        if not artifact_ref:
            raise ValueError("final_kpi_proxy_context_artifact_ref_required")
        by_ref[artifact_ref] = artifact
    return list(by_ref.values())


def _terminal_artifacts_by_kind(
    artifacts: Sequence[Mapping[str, Any]],
) -> dict[str, list[Mapping[str, Any]]]:
    grouped: dict[str, list[Mapping[str, Any]]] = {}
    for artifact in artifacts:
        kind = str(artifact.get("artifact_kind") or "")
        grouped.setdefault(kind, []).append(artifact)

    terminal: dict[str, list[Mapping[str, Any]]] = {}
    for kind, candidates in grouped.items():
        candidate_refs = {
            str(candidate.get("artifact_ref") or "") for candidate in candidates
        }
        superseded_refs = {
            str(dependency)
            for candidate in candidates
            for dependency in candidate.get("depends_on", [])
            if str(dependency) in candidate_refs
        }
        terminal[kind] = [
            candidate
            for candidate in candidates
            if str(candidate.get("artifact_ref") or "") not in superseded_refs
        ]
    return terminal


def _drafting_context_projection(
    artifact: Mapping[str, Any],
    *,
    kind: str,
) -> dict[str, Any]:
    payload = artifact.get("machine_payload")
    if not isinstance(payload, Mapping) or not payload:
        raise ValueError(
            f"final_kpi_proxy_input_machine_payload_required:{kind}"
        )
    return {
        "artifact_ref": artifact.get("artifact_ref"),
        "artifact_kind": kind,
        "summary": artifact.get("summary", ""),
        "machine_payload": dict(payload),
    }


def _prepared_historical_data(
    prepared_source: PreparedSourceData,
) -> dict[str, Any]:
    return prepared_historical_data(prepared_source)


def _validate_visible_source(
    manifest: Mapping[str, Any], visible_historical: Mapping[str, Any]
) -> None:
    historical_manifest = manifest.get("historical_data")
    if not isinstance(historical_manifest, Mapping):
        raise ValueError("scientific_source_historical_manifest_required")
    _validate_visible_records(visible_historical)
    if historical_manifest.get("record_count") != len(visible_historical["records"]):
        raise ValueError("scientific_source_visible_record_count_mismatch")
    # This legacy route promises redacted data; prepared data has no such ban.
    forbidden = {
        "ground_truth_kpi",
        "ground_truth_description",
        "avg_score",
        "score_MoO3",
        "score_WO3",
        "substrate_scores",
    }
    leaked = sorted(_forbidden_field_paths(visible_historical, forbidden))
    if leaked:
        raise ValueError(f"scientific_source_private_field_leak:{leaked}")


def _validate_visible_records(visible_historical: Mapping[str, Any]) -> None:
    records = visible_historical.get("records")
    if not isinstance(records, list) or not records:
        raise ValueError("scientific_source_visible_records_required")


def _forbidden_field_paths(
    value: Any,
    forbidden: set[str],
    *,
    path: str = "$",
) -> list[str]:
    matches: list[str] = []
    if isinstance(value, Mapping):
        for key, child in value.items():
            child_path = f"{path}.{key}"
            if str(key) in forbidden:
                matches.append(child_path)
            matches.extend(
                _forbidden_field_paths(child, forbidden, path=child_path)
            )
    elif isinstance(value, Sequence) and not isinstance(
        value, (str, bytes, bytearray)
    ):
        for index, child in enumerate(value):
            matches.extend(
                _forbidden_field_paths(child, forbidden, path=f"{path}[{index}]")
            )
    return matches
