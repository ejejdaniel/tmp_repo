# Design brief

## Ownership

Final-KPI Proxy Discovery defines a low-cost scientific quantity and a complete frozen formula. Materializer chooses a faithful implementation for each declared quantity and executes it. Shared review judges the published method, evaluation compares the executed proxy with the designated dataset's measurements, and the leaderboard ranks complete evidence chains. A task may authorize this researcher to observe named measurements from P2 onward; the resulting dataset fit must not be described as independent validation.

The formula artifact is a definition and handoff, not proof that its values exist. Conversely, Materializer may choose libraries, parsers, numerical methods, transparent approximations, reference scales, and regimes needed to compute the declared quantity, but it may not change the target, formula, direction, or scientific concept.

## Implementation visibility

P1 remains independent of concrete execution inventory. After P1, the host reads
installed distribution metadata from Materializer's actual fixed runtime, not
from the developer host or a Dockerfile. It combines this with the existing
consumer-scoped code-callable Route summaries, including exact pending candidate
references where already visible. This information is kept in the existing
invocation-local `materializer_capability` text. It reaches P2, P3, explanation,
operationalization review and their repairs without a new model stage.

The registry owns runtime identity, the skill catalog owns Route visibility,
and the formula skill owns scientific suitability and cost reasoning. Installed
packages do not establish a scientific result. An inventory read failure is
unknown availability, not grounds to invent an absence. DFT can be appropriate
within a task budget, but neither availability nor a Route title mandates its
use. Direct implementation using installed libraries remains available.

The common layer performs only metadata reading and visibility projection. The
file-backed [implementation guide](implementation-capability.md) owns the domain
instructions. No public artifact, approval state or caller action space changes.

## Discovery modes

Autonomous mode may use task, mind map, hypotheses, and rankings as nonbinding research context. It does not owe lineage to any one hypothesis.

Hypothesis evidence-support mode begins only from one explicit hypothesis plus its exact unmet review or non-released Final LCA finding. It traces:

```text
hypothesis claim
-> difficult physical quantity
-> faithful low-cost substitute
-> relationship to the original mechanism
-> expected relationship to the final KPI
-> failure boundary
```

The result is still a final-KPI proxy formula. A low review score does not mechanically force this route; the main agent may choose another route.

## Challenger identity

`formula_id` names one scientific method lineage. `version` orders revisions inside that lineage and does not encode quality. A distinct challenger receives a distinct identity. A local repair before publication keeps identity and version.

Duplicate detection compares operational expression structure, selected quantities, exact source paths, and expected direction. Cosmetic rewrites do not create new evidence and must not trigger implementation.
