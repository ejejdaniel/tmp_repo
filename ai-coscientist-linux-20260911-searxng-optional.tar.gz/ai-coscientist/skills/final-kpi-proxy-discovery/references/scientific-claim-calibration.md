# Scientific claim calibration

Use the following evidence vocabulary throughout P1-P4 and explanation deepening:

- **Observed:** directly present in supplied records, explicitly authorized task data, or public research artifacts.
- **Expected or hypothesized:** derived from a physical mechanism but not directly established by supplied evidence.
- **Prospective design choice:** an author-selected coefficient, cutoff, normalization, comparison point, or reference used to create a falsifiable candidate.
- **Validated:** supported by later execution or review evidence that is actually supplied. Formula authorship alone is not validation.

Confounded record differences do not isolate one variable's effect. A fixed process value is context, not observed variation. Mathematical resemblance to a target does not establish an optimum, threshold, sign, symmetry, conversion coefficient, or monotonic law.

Task-authorized measurements retain their named source, allowed use, and claim limit from P2 through authoring, explanation, review and repair. P1 receives no measurement body. Agreement on an observed dataset is dataset fit, not independent validation. Coefficients proposed from scientific reasoning are not fitted coefficients unless actual fitting evidence is supplied. Measurements must not be silently turned into answer-table calculation inputs.

When available evidence cannot establish one direction, state the uncertainty and propose a regime-bounded relation or discriminating comparison. Do not manufacture precision to make the candidate look complete. These distinctions live in existing prose fields and do not add public fields.
