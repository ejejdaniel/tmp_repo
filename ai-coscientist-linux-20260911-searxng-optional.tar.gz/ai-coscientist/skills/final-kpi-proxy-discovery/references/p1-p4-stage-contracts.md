# P1-P4 stage contracts

## P1: first-principles quantity discovery

P1 sees target meaning and compact public scientific assets but no historical record body or authorized measurement body. It proposes several physically meaningful, low-cost quantity directions. A molecular representation may motivate a computable descriptor, but P1 must not claim the descriptor already exists as a column or draft the final formula.

## P2: historical grounding

P2 receives the selected records, exact source-path catalog, task authority, other prepared bodies, P1 ideas, and the declared Materializer capability. It can use `source_inventory`, `source_search`, and `source_read` within the existing stage inspection quota and source permissions, without a separate mandatory model stage. The shared `SOURCE_CONTEXT_GUIDE` defines how read source definitions support existing `record.*` inputs without changing the selected dataset. Each retained quantity identifies a scientific concept, actual record paths, its source-linked calculation method, and visible variation. It must not calculate per-record descriptors or proxy outputs; execution belongs to Materializer. P3 combines the grounded primitive quantities.

The host retains exact successful source pages and their refs, not just the model's extraction. The same pages reach P2 repair, P3, explanation, P4 and repairs. Only actual reads become additional publication `trace_refs`; a source name or an unread ref is not inspected evidence. Page limits and read failures retain their actual scope. The record table is not modified or replaced by inspection.

Python validates only structure, identifier form, and source-path existence. It does not infer whether a scientific surrogate is valid. P4 operationalization review owns that scientific red line.

The private P2 schema permits `grounded_quantities: []`. P2 and its repair use
the same contract: distinguish information missing from the selected table from
information absent in a source actually inspected, and explain the missing
scientific input, table ref and read source refs in `historical_summary` and
`excluded_quantities`. Empty grounding returns the existing skill `bounded_gap`
with that explanation, without P3 or publication. It does not prescribe a next
skill. Available quantities may proceed even when other P1 ideas are excluded.
The executable P2 prompt owns the effort standard for this exit: investigate
source-supported derivations and plausible alternatives before concluding none
are suitable, without demanding finished code, numerical certainty or exhaustive
search. Missing a ready-made column/function alone is not a scientific gap.

The host reads the fixed runtime's installed distribution metadata once after P1,
and combines it with the existing code-callable Route summaries visible to
Materializer. [Implementation capability](implementation-capability.md) defines
how to use this information. The same `materializer_capability` text reaches P2,
P3, explanation, P4 operationalization and their repairs. It is invocation-local
context, not an extra model stage or a new tool. P1 receives no runtime inventory.
Pending Route refs keep their candidate provenance. Missing inventory means
unknown availability, not absent capability. DFT is eligible, not required;
low cost is judged against the task and method, not a universal simulation ban.

When a task grant supplies `authorized_task_data`, P2 may observe its exact named bodies within the stated allowed use and claim limit. The same labeled section remains available in P3, explanation, P4 and their repairs; it is not a new calculation input or evidence that a proposed computation has executed. Ordinary task measurements do not require an extra grant. Official scoring still belongs to the evaluator, and fit on an observed dataset is not independent validation.

## P3: formula authoring

P3 receives target authority, compact public context, P1, accepted P2 grounding, other prepared bodies, exact P2-read source pages and compact evaluated formula history. It does not receive the raw record table or source-shape catalog again. It uses only exact grounded quantity names and returns the existing formula-core shape. Read source definitions remain direct evidence; a grounding interpretation does not override their content.

The route host injects target identity and projects source binding, historical variation, and the materialization contract from P2. A local repair receives the rejected core, exact validator issues, and the same narrow authoring authority.

## Explanation deepening

The explanation pass receives the frozen candidate, exact grounding, and compact shared assets. It may deepen variable meaning, target linkage, side effects, claim boundary, and text-valued validation criteria. It cannot change formula identity, expression, variables, target, expected direction, source binding, materialization contract, or non-text criteria.

## P4: producer reviews

Three independent calls prevent one judgment from silently controlling unrelated boundaries:

1. **Scientific relationship:** follows the complete formula numerically and checks target direction, commensurability, unsupported target-shaped transformations, and contradiction with grounded effects.
2. **Operationalization:** checks whether at least one faithful objective low-cost implementation is plausible from the visible source boundary. Method non-uniqueness belongs to Materializer and is not itself a defect.
3. **Observability:** checks whether complete output can vary across visible records and whether evaluation would avoid ungranted target data, circular proof, or wrong-entity attribution. Authorized retrospective observation is not itself a violation; it limits the validation claim.

Each call returns only `{score, reason}`, where score is 0 or 4. Any 0 triggers one complete-core repair, a refreshed explanation, and three fresh reviews. A second 0 ends the skill without publication.
