---
name: ai-coscientist-skill-creator
description: Creates or audits project-local ai-coscientist production skills and reusable routes. Use when adding, redesigning, reviewing, or onboarding a third-party skill or route, especially when ownership, artifact dataflow, C0-C6 memory, prompt stages, validators, or skill-local workflow boundaries must be made consistent.
estimated_complexity: high
---

# AI Coscientist Skill Creator

Create and review project-local skills without weakening the common-agent architecture. This is a developer meta-skill, not a production scientific skill. Never add it to the production `skills/` catalog or treat it as a workflow stage.

## Read project authority first

Before proposing files or edits, read:

1. The nearest `AGENTS.md`.
2. `docs/common_memory_constitution_zh-TW.md`.
3. `docs/materializer_responsibility_constitution_zh-TW.md` when the change
   touches formula operationalization, Materializer, or review of materialized
   evidence.
4. `references/project-authoring-contract.md` in this skill.
5. The most similar existing production skill, its `workflow.py`, routes, validators, and tests.
6. The common interfaces the proposed skill will actually call.

Treat current code that conflicts with the constitution as an implementation gap, not a precedent.

## Classify the capability before creating files

Decide whether the requested capability is:

- a production skill: one dynamically selectable, agent-level responsibility with a formal result;
- a skill-local workflow: a bounded fixed sequence owned by one production skill;
- a route: a reusable callable operation behind a skill or generated program;
- common infrastructure: science-neutral behavior required across domains;
- a child agent: an isolated objective that needs its own LOOP, plan, evaluation, and white-room context; or
- an ordinary helper/reference that does not deserve a skill boundary.

Do not scaffold a skill until this classification is defensible. If ownership or the common/domain boundary remains unclear, stop and ask the user. Never move a domain convenience into common merely to make one test pass.

## Establish concrete use cases

Collect or derive at least:

- two positive trigger examples;
- one adjacent request that must not trigger the skill;
- one malformed-input or missing-prerequisite case;
- the expected formal result and the downstream consumer.

Use these examples to define the frontmatter description. The description must state what the skill produces, what it requires, and its boundary. Keep triggering detail in the description because the body is revealed only after selection.

Also classify expected execution load as `low`, `medium`, or `high`. This is a
planning hint, not algorithmic Big-O and not a promise about exact token or wall
time:

- `low`: one bounded model or mechanical operation, normally without iteration;
- `medium`: several internal calls or data operations, or one execution with
  bounded repair;
- `high`: multi-stage reasoning, code execution, iterative search, or several
  rounds may be required.

Store the cases in the skill's `## Trigger examples` section:

- `### Should select` contains at least two differently worded requests whose authoritative prerequisites are visibly available.
- `### Should not select` contains one adjacent responsibility and one request whose prerequisite must be produced first.

Trigger evaluation sees only the production skill summaries and the case text. It must not receive the target skill body, expected answer, prior evaluation report, or hidden reasoning.

## Design responsibility and dataflow

Before implementation, write a compact design brief containing:

1. Owned responsibility and prohibited behavior.
2. Exact input authorities: formal artifact refs, workspace refs, routes, or task constraints.
3. Expected formal output and downstream consumer.
4. Immutable identity transitions: whether publishing a new result invalidates prior code, evidence, or consumer inputs, even when semantic content is unchanged.
5. Every named intermediate/output mapped to C0-C6, including storage and metabolism. List C0 through C6 explicitly and mark unused classes instead of omitting them.
6. Every LLM call: purpose, prompt sources, output shape, validator, local repair, and retained C5/C3/C4 state.
7. Any fixed skill-local workflow and any independently callable routes.
8. Failure ownership: repair locally, return a structured gap, request replan, or fail to parent.
9. Deterministic tests, boundary replay, and smallest real-model forward test.

Do not turn this design brief into a new persisted schema. It is an authoring and review artifact.

## Design prompt stages before prose

Treat every LLM call as one causal contract, not as independent prompt text,
schema, validator, repair, and consumer implementations. Before editing any of
those surfaces, write one call-contract row that names:

- the call's sole purpose and owning stage;
- authoritative inputs and their C0-C6 projections;
- allowed judgment or transformation;
- requested output and its exact shape;
- deterministic and LLM-owned validation responsibilities;
- local repair behavior using the same contract;
- the downstream consumer and the facts it reads.

One requirement must have one authoritative definition. Prompt pages may explain
or project that definition for their audience, but must not independently restate
it with different scope. Repair prompts may add the rejected payload and exact
issues; they must not introduce new requirements, weaken the original contract,
or change stage ownership. If two existing sources disagree, remove the stale
rule and resolve ownership before adding another instruction.

Before blaming model behavior or adding a validator, inspect the final assembled
prompt actually sent to the model. Then trace the returned value through the
validator, repair call, publication, and consumer. A local source fragment is
insufficient evidence that the complete call is coherent.

For each LLM call, verify that:

- the instruction describes the actual responsibility of that stage;
- the prompt receives only the relevant C0-C5 projections;
- C6 raw audit data is never normal model input;
- the requested output matches the validator and downstream consumer;
- every validator requirement has one visible prompt authority and every prompt
  requirement has an owning validator or downstream consumer;
- all prompt fragments agree on stage ownership, allowed changes, and failure
  behavior;
- the validator does not demand fields or semantics absent from the instruction;
- every finite output string limit that can reject a result is projected into
  the assembled prompt from the same schema authority; do not maintain a second
  manually copied numeric limit in skill prose;
- a string-length-only failure remains a local format repair with the actual
  length, hard maximum, and a conservative target visible to the repair call;
  it must not be reported as a scientific or graph-node failure;
- any exact multiline edit receives directly copyable stored source, not only an escaped or truncated serialization;
- a newly published immutable identity does not silently reuse evidence bound to an older identity;
- a deterministic lineage rejection exposes the expected and actual refs needed for recovery;
- an unresolved failure diagnostic remains visible across inspection and skill selection until a repairing result is published and read back; reading the conflicting inputs is not itself a repair;
- local format repair remains in the same stage;
- text-package repair uses ordinary invocation-local file read, create, and
  exact-edit operations; do not ask an LLM to regenerate every unchanged file
  merely because one validator issue names one file-local defect;
- every described failure branch names an existing executable handoff: a host-supported workflow result, an exposed control action, or publication of the formal result; prose such as "report a gap" is not an interface when no consumer can receive it;
- scientific semantic judgment remains with the responsible LLM;
- Python performs only structural validation, bookkeeping, execution, and provenance checks.

Multiple LLM calls inside one skill are valid. The skill chooses which semantic state continues; common memory rules still govern C0-C6 storage, metabolism, and prompt projection.

## Scaffold only after design approval

For a new production skill, run:

```powershell
python .agents/skills/ai-coscientist-skill-creator/scripts/init_project_skill.py <name> --project-root . --description "Produces ... Requires ... Boundary: ..." --estimated-complexity medium [--with-workflow] [--with-references]
```

The initializer creates only the files selected by the author. Remove all TODO markers before validation. Production frontmatter requires `name`, `description`, and `estimated_complexity`. Add optional `accepts_research_mode: true` only when the skill consumes the caller-owned two-axis research-mode card; use the initializer flag `--accepts-research-mode`. Absence means `false` and must remain the default for ordinary skills. Such a skill must also document which structural authorities stay visible in an explore-mode first draft and where withheld shared context returns. Common binds candidate refs once; the skill must not add a competing semantic classifier.

Routes are not scaffolded as production skills. Put a route at the owning domain boundary, give it an explicit callable interface, and expose it only through the owning skill or generated code path.

## Implement with progressive disclosure

- Keep metadata short and sufficient for selection.
- Keep essential workflow, authority, C0-C6 mapping, formal output, failure
  boundary, and model-call ledger in `SKILL.md` even when a skill uses dynamic
  disclosure.
- Put detailed variants and long engineering references one level under `references/` and link them directly.
- A `disclosure.py` may select directly referenced stage pages at runtime. Its
  literal `.md` page names count as executable references, but the root contract
  may not delegate its core responsibility or formal handoff to those pages.
- Put deterministic reusable operations under `scripts/` or a project package.
- Use `workflow.py` only when one selected skill genuinely owns a bounded internal sequence.
- Keep `workflow.py` entrypoint exactly `run(payload, runtime)`.
- Never let a skill output prescribe the next production skill.
- Never duplicate formal artifact content in prompt prose, receipts, or local state.
- Treat the prompt, requested output, validator, local repair, formal publication, and downstream read as one causal contract. Do not review any one of them in isolation.

## Validate in increasing-cost order

1. Run this skill's project validator.
2. Run syntax and focused deterministic tests.
3. Run a deterministic producer-to-consumer boundary replay.
4. Forward-test the skill with a real task and the minimum honest context.
5. Run a broader workflow only after the earliest affected boundary passes.

```powershell
python .agents/skills/ai-coscientist-skill-creator/scripts/validate_project_skill.py skills/<name>
```

The validator checks structural invariants only. A passing validator does not prove scientific quality, correct semantic ownership, or real-model success.

Run the centralized evaluation after structural validation:

```powershell
python .agents/skills/ai-coscientist-skill-creator/scripts/evaluate_project_skill.py skills/<name> --project-root . --config config_gemma.cfg
```

This evaluation performs two advisory real-model checks:

1. Summary-only trigger selection over the declared positive and negative cases.
2. Prompt-contract review over a bounded source packet containing `SKILL.md`, relevant workflow prompt/schema/validator/publication code, exact named route implementations, and focused test references.
The alignment packet must prioritize the target skill's exact executable route implementations over neighboring contracts. A packet truncated before the called route is insufficient evidence, not a valid defect report.


Each run writes an immutable source snapshot, exact raw model request/response JSONL, a bounded audit packet, and a short report under `outputs/skill-creator/`. Raw records are C6 developer diagnostics and must never be production prompt input. The report is review evidence, not a formal scientific artifact.

For a skill without `workflow.py`, the evaluator also projects the bounded common selected-skill prompt, resolved-input path, publication/readback tools, and stored-artifact projection. Absence of a private Python workflow is not itself a defect.

## Iterate without training on the answer

Use this loop:

```text
baseline snapshot and evaluation
-> identify the earliest responsibility, selection, prompt, validation, or handoff mismatch
-> edit the owning skill or route
-> rerun the same cases from a clean source snapshot
-> compare trigger outcomes, alignment issues, boundary replay, and real forward behavior
```

Do not automatically rewrite a skill from the evaluator's prose. The author decides the correction from source evidence. Do not feed prior reports or expected decisions into the next model evaluation. If two revisions fail in the same functional block, stop local patching and re-read that skill, its callers, routes, validators, publication path, and consumer end to end.

Compare two runs only when they used the same trigger cases and evaluator source:

```powershell
python .agents/skills/ai-coscientist-skill-creator/scripts/compare_project_skill_runs.py <baseline-report.md> <candidate-report.md>
```

## Audit existing skills

When reviewing an existing skill, trace:

```text
producer authority
-> stored artifact/workspace authority
-> exact ref and visibility boundary
-> selected skill prompt projection
-> LLM output
-> validator/gate
-> local repair
-> formal publication
-> immutable identity transition and invalidated dependencies
-> downstream consumer
```

Find the earliest divergence. Do not begin by adding another rejection rule.

## Report

Report:

- capability classification and why;
- files created or changed;
- responsibility, inputs, output, and prohibited behavior;
- C0-C6 mapping and prompt-stage map;
- tests that passed;
- what remains unproven;
- any requested schema/common/runtime change that still needs user approval.

## Bundled resources

- Read `references/project-authoring-contract.md` for the complete engineering contract and review checklist.
- Use `scripts/init_project_skill.py` to create a production skill skeleton.
- Use `scripts/validate_project_skill.py` for deterministic structural validation.
- Use `scripts/evaluate_project_skill.py` for summary-trigger and prompt-contract forward evaluation with append-only diagnostics.
- Use `scripts/compare_project_skill_runs.py` to compare unchanged cases under the same evaluator revision.
- Use `scripts/audit_project_llm_calls.py` to inventory production model-call
  sites before auditing their complete prompt, validation, repair, and consumer
  chains. The inventory locates calls; it does not prove semantic alignment.
