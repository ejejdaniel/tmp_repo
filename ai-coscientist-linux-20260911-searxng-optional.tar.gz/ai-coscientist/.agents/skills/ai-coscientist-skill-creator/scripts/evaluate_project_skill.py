#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import configparser
import hashlib
import importlib.util
import json
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence


NONE_SKILL = "__none__"
MODEL_ATTEMPTS = 2
MAX_ALIGNMENT_PACKET_CHARS = 60_000
MAX_ROUTE_SOURCE_CHARS = 24_000
MAX_COMMON_INTERFACE_SOURCE_CHARS = 28_000
MAX_CROSS_SKILL_CONTRACT_CHARS = 12_000
COMMON_RUNTIME_CONSTANTS = (
    "_BASE_SYSTEM_PROMPT",
    "_ACTIVE_SKILL_PROMPT",
    "BASE_SYSTEM_PROMPT",
    "ACTIVE_SKILL_PROMPT",
)
COMMON_PROMPT_CONSTANTS = ("FOCUSED_C4_SOURCE_PREFIX",)
COMMON_RUNTIME_METHODS = (
    "_render_messages",
    "_runtime_prompt_sources",
    "_tool_specs",
    "_validate_transition",
    "_dispatch",
    "_read_exact_ref",
    "_exact_ref_prompt_projection",
)
RELEVANT_CALLS = {
    "generate_json",
    "publish_artifact",
    "read_artifact",
    "call_route",
}
RELEVANT_FUNCTION_WORDS = {
    "assemble",
    "build",
    "repair",
    "review",
    "validate",
}


@dataclass(frozen=True)
class TriggerCase:
    case_id: str
    request: str
    should_select: bool


@dataclass(frozen=True)
class TriggerOutcome:
    case: TriggerCase
    selected_skill: str
    reason: str
    passed: bool


@dataclass(frozen=True)
class StructuralResult:
    errors: tuple[str, ...]
    warnings: tuple[str, ...]

    @property
    def passed(self) -> bool:
        return not self.errors


RecordEvent = Callable[[Mapping[str, Any]], None]


def markdown_section(markdown: str, heading: str) -> str:
    start = markdown.find(heading)
    if start < 0:
        return ""
    start += len(heading)
    level = len(heading) - len(heading.lstrip("#"))
    if level <= 0:
        return ""
    match = re.search(
        rf"^#{{1,{level}}}\s",
        markdown[start:],
        flags=re.MULTILINE,
    )
    end = start + match.start() if match else len(markdown)
    return markdown[start:end].strip()


def parse_trigger_cases(markdown: str) -> tuple[TriggerCase, ...]:
    trigger_section = markdown_section(markdown, "## Trigger examples")
    cases: list[TriggerCase] = []
    for prefix, heading, should_select in (
        ("select", "### Should select", True),
        ("reject", "### Should not select", False),
    ):
        content = markdown_section(trigger_section, heading)
        examples = [
            line[2:].strip()
            for line in content.splitlines()
            if line.startswith("- ") and line[2:].strip()
        ]
        for index, request in enumerate(examples, start=1):
            cases.append(
                TriggerCase(
                    case_id=f"{prefix}-{index}",
                    request=request,
                    should_select=should_select,
                )
            )
    return tuple(cases)


def discover_skill_summaries(skills_root: Path) -> tuple[dict[str, str], ...]:
    summaries: list[dict[str, str]] = []
    for path in sorted(skills_root.resolve().glob("*/SKILL.md")):
        metadata = parse_frontmatter(path.read_text(encoding="utf-8"))
        skill_id = metadata.get("name", "").strip()
        description = metadata.get("description", "").strip()
        estimated_complexity = metadata.get(
            "estimated_complexity", ""
        ).strip()
        if (
            not skill_id
            or not description
            or estimated_complexity not in {"low", "medium", "high"}
        ):
            raise ValueError(f"invalid_skill_summary:{path}")
        summaries.append(
            {
                "skill_id": skill_id,
                "description": description,
                "estimated_complexity": estimated_complexity,
            }
        )
    return tuple(summaries)


def parse_frontmatter(markdown: str) -> dict[str, str]:
    lines = markdown.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}
    metadata: dict[str, str] = {}
    for line in lines[1:]:
        if line.strip() == "---":
            return metadata
        key, separator, value = line.partition(":")
        if separator:
            metadata[key.strip()] = value.strip().strip("\"'")
    return {}


def evaluate_trigger_cases(
    *,
    skill_id: str,
    summaries: Sequence[Mapping[str, str]],
    cases: Sequence[TriggerCase],
    model: Any,
    record_event: RecordEvent | None = None,
) -> tuple[TriggerOutcome, ...]:
    if not cases:
        raise ValueError("trigger_cases_missing")
    valid_skills = sorted({str(item.get("skill_id") or "") for item in summaries})
    if skill_id not in valid_skills:
        raise ValueError(f"target_skill_not_discovered:{skill_id}")
    case_ids = [case.case_id for case in cases]
    schema = {
        "type": "object",
        "properties": {
            "decisions": {
                "type": "array",
                "minItems": len(cases),
                "maxItems": len(cases),
                "items": {
                    "type": "object",
                    "properties": {
                        "case_id": {"type": "string", "enum": case_ids},
                        "selected_skill": {
                            "type": "string",
                            "enum": [*valid_skills, NONE_SKILL],
                        },
                        "reason": {"type": "string"},
                    },
                    "required": ["case_id", "selected_skill", "reason"],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["decisions"],
        "additionalProperties": False,
    }
    messages = [
        {
            "role": "system",
            "content": (
                "Evaluate summary-only production-skill selection. Do not solve "
                "the requests and do not assume any SKILL.md detail. For each "
                "case, choose the single skill whose complete declared result "
                "matches the immediate work and whose declared prerequisites are "
                "available in the case. Choose __none__ when no listed skill is "
                "eligible. Adjacent work and missing prerequisites must not be "
                "assigned to a skill merely because its domain sounds related."
            ),
        },
        {
            "role": "user",
            "content": json.dumps(
                {
                    "skill_menu": list(summaries),
                    "cases": [
                        {"case_id": case.case_id, "request": case.request}
                        for case in cases
                    ],
                },
                ensure_ascii=False,
                indent=2,
            ),
        },
    ]

    def validate(arguments: Mapping[str, Any]) -> list[str]:
        decisions = arguments.get("decisions")
        if not isinstance(decisions, list):
            return ["decisions_must_be_array"]
        issues: list[str] = []
        seen: set[str] = set()
        for index, decision in enumerate(decisions):
            if not isinstance(decision, Mapping):
                issues.append(f"decision_{index}_must_be_object")
                continue
            case_id = str(decision.get("case_id") or "")
            selected = str(decision.get("selected_skill") or "")
            reason = str(decision.get("reason") or "").strip()
            if case_id not in case_ids:
                issues.append(f"unknown_case_id:{case_id}")
            elif case_id in seen:
                issues.append(f"duplicate_case_id:{case_id}")
            seen.add(case_id)
            if selected not in {*valid_skills, NONE_SKILL}:
                issues.append(f"unknown_selected_skill:{selected}")
            if not reason:
                issues.append(f"selection_reason_missing:{case_id}")
        for missing in sorted(set(case_ids) - seen):
            issues.append(f"decision_missing:{missing}")
        return issues

    arguments = call_structured_model(
        model=model,
        purpose=f"skill-creator.trigger-selection.{skill_id}",
        messages=messages,
        tool_name="return_skill_trigger_decisions",
        schema=schema,
        validator=validate,
        record_event=record_event,
    )
    indexed = {str(item["case_id"]): item for item in arguments["decisions"]}
    outcomes: list[TriggerOutcome] = []
    for case in cases:
        decision = indexed[case.case_id]
        selected = str(decision["selected_skill"])
        passed = selected == skill_id if case.should_select else selected != skill_id
        outcomes.append(
            TriggerOutcome(
                case=case,
                selected_skill=selected,
                reason=str(decision["reason"]).strip(),
                passed=passed,
            )
        )
    return tuple(outcomes)


def evaluate_alignment(
    *,
    skill_id: str,
    audit_packet: str,
    model: Any,
    record_event: RecordEvent | None = None,
) -> Mapping[str, Any]:
    schema = {
        "type": "object",
        "properties": {
            "verdict": {
                "type": "string",
                "enum": [
                    "aligned",
                    "needs_revision",
                    "insufficient_evidence",
                ],
            },
            "issues": {"type": "array", "items": {"type": "string"}},
            "strengths": {"type": "array", "items": {"type": "string"}},
        },
        "required": ["verdict", "issues", "strengths"],
        "additionalProperties": False,
    }
    messages = [
        {
            "role": "system",
            "content": (
                "Audit one production skill as a developer reviewer. Use only "
                "the supplied source packet. Check responsibility and authority, "
                "prompt inputs, requested output, validator or deterministic "
                "checks and every deterministic rejection condition, local repair, publication, readback, and downstream "
                "handoff as one causal chain. Treat each LLM call as one causal "
                "contract. Inspect the final assembled prompt, tool schema, "
                "validator, repair prompt, publication mapping, and consumer "
                "together. Report an exact issue when active surfaces assign "
                "conflicting responsibilities, requirements, allowed changes, or "
                "failure behavior. A repeated requirement is not a new authority; "
                "identify its intended owner and stale conflicting projections. "
                "Verify that every validator rejection was stated and supplied to "
                "the model, and that repair adds only the rejected result and exact "
                "issues without redefining the task. Check immutable artifact identity "
                "transitions: a newly published ref must not silently reuse code "
                "or evidence bound to an older ref, and a lineage rejection must "
                "expose the expected and actual refs needed for recovery. Check "
                "that an unresolved failure diagnostic remains visible through "
                "inspection and the next capability selection until repairing "
                "evidence is published and read back. Check that every described "
                "failure branch names an existing executable handoff: a "
                "host-supported workflow result, an exposed control action, or "
                "publication of the formal result. Plain-text advice to report a "
                "gap is not an interface when no consumer can receive it. Check "
                "that C0-C6 are used as memory "
                "classes rather than duplicated authorities. If a route requires "
                "exact multiline text from a stored "
                "artifact, verify the selected-skill prompt exposes directly "
                "copyable source rather than only escaped or truncated JSON. Do not infer missing "
                "code. Use insufficient_evidence when the packet cannot prove an "
                "alignment. A structural heading or schema keyword alone is not "
                "proof of semantic alignment. A missing workflow.py is not itself "
                "a defect: SKILL.md is the executable instruction for a selected "
                "common-agent turn, so assess it with the supplied common execution "
                "projection. Do not propose a next skill or common-runtime patch."
            ),
        },
        {"role": "user", "content": audit_packet},
    ]

    def validate(arguments: Mapping[str, Any]) -> list[str]:
        verdict = str(arguments.get("verdict") or "")
        issues = arguments.get("issues")
        strengths = arguments.get("strengths")
        found: list[str] = []
        if verdict not in {
            "aligned",
            "needs_revision",
            "insufficient_evidence",
        }:
            found.append(f"alignment_verdict_invalid:{verdict}")
        if not isinstance(issues, list) or not all(
            isinstance(item, str) and item.strip() for item in issues
        ):
            found.append("alignment_issues_must_be_string_array")
        if not isinstance(strengths, list) or not all(
            isinstance(item, str) and item.strip() for item in strengths
        ):
            found.append("alignment_strengths_must_be_string_array")
        if verdict == "aligned" and issues:
            found.append("aligned_verdict_cannot_have_issues")
        if verdict != "aligned" and not issues:
            found.append("non_aligned_verdict_requires_issues")
        return found

    return call_structured_model(
        model=model,
        purpose=f"skill-creator.contract-alignment.{skill_id}",
        messages=messages,
        tool_name="return_skill_alignment_review",
        schema=schema,
        validator=validate,
        record_event=record_event,
    )


def call_structured_model(
    *,
    model: Any,
    purpose: str,
    messages: Sequence[Mapping[str, Any]],
    tool_name: str,
    schema: Mapping[str, Any],
    validator: Callable[[Mapping[str, Any]], list[str]],
    record_event: RecordEvent | None = None,
) -> Mapping[str, Any]:
    record = record_event or (lambda _event: None)
    tools = [
        {
            "type": "function",
            "function": {
                "name": tool_name,
                "description": "Return the developer evaluation result.",
                "parameters": dict(schema),
            },
        }
    ]
    base_messages = [dict(message) for message in messages]
    current_messages = list(base_messages)
    last_issues: list[str] = []
    for attempt in range(MODEL_ATTEMPTS):
        attempt_purpose = purpose if attempt == 0 else f"{purpose}.repair"
        record(
            {
                "event": "model_request",
                "purpose": attempt_purpose,
                "messages": current_messages,
                "tools": tools,
            }
        )
        turn = model.complete(
            messages=current_messages,
            tools=tools,
            purpose=attempt_purpose,
            tool_choice="required",
        )
        calls = list(getattr(turn, "tool_calls", ()) or ())
        record(
            {
                "event": "model_response",
                "purpose": attempt_purpose,
                "content": str(getattr(turn, "content", "") or ""),
                "tool_calls": [
                    {
                        "name": str(getattr(call, "name", "") or ""),
                        "arguments": dict(getattr(call, "arguments", {}) or {}),
                    }
                    for call in calls
                ],
                "usage": dict(getattr(turn, "usage", {}) or {}),
            }
        )
        issues: list[str] = []
        arguments: Mapping[str, Any] = {}
        if len(calls) != 1:
            issues.append(f"exactly_one_tool_call_required:actual={len(calls)}")
        else:
            call = calls[0]
            if str(getattr(call, "name", "")) != tool_name:
                issues.append(
                    "wrong_tool_call:"
                    f"expected={tool_name}:actual={getattr(call, 'name', '')}"
                )
            raw_arguments = getattr(call, "arguments", {})
            if not isinstance(raw_arguments, Mapping):
                issues.append("tool_arguments_must_be_object")
            else:
                arguments = dict(raw_arguments)
                issues.extend(validator(arguments))
        if not issues:
            return arguments
        last_issues = issues
        if attempt + 1 >= MODEL_ATTEMPTS:
            break
        current_messages = [
            *base_messages,
            {
                "role": "user",
                "content": (
                    "Your previous result was rejected only for these output "
                    "contract issues. Return the complete corrected result without "
                    "changing the evaluation task:\n- " + "\n- ".join(issues[:16])
                ),
            },
        ]
    raise RuntimeError(
        "skill_creator_model_result_invalid:" + ";".join(last_issues[:16])
    )


def build_alignment_packet(skill_dir: Path, project_root: Path) -> str:
    skill_dir = skill_dir.resolve()
    project_root = project_root.resolve()
    skill_md = (skill_dir / "SKILL.md").read_text(encoding="utf-8")
    metadata = parse_frontmatter(skill_md)
    sections = [
        "# Skill alignment audit packet",
        "",
        f"- Skill: `{metadata.get('name', skill_dir.name)}`",
        f"- Skill directory: `{skill_dir.relative_to(project_root).as_posix()}`",
        "- This packet is a developer audit projection, not production evidence.",
        "",
        "## SKILL.md",
        "",
        "```markdown",
        skill_md.rstrip(),
        "```",
        "",
        "## Bundled files",
        "",
    ]
    for path in sorted(item for item in skill_dir.rglob("*") if item.is_file()):
        if "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        relative = path.relative_to(skill_dir).as_posix()
        sections.append(
            f"- `{relative}`: {path.stat().st_size} bytes, "
            f"sha256 `{hashlib.sha256(path.read_bytes()).hexdigest()}`"
        )
    workflow_path = skill_dir / "workflow.py"
    sections.extend(["", "## Executable workflow projection", ""])
    if workflow_path.is_file():
        source = workflow_path.read_text(encoding="utf-8")
        projection = workflow_source_projection(source, workflow_path)
        sections.extend(["```python", projection.rstrip(), "```"])
    else:
        sections.append(
            "No `workflow.py` is present. The selected common-agent turn uses "
            "SKILL.md directly; prompt/output alignment therefore depends on the "
            "skill instructions, visible route contracts, and focused tests."
        )
        common_projection = common_skill_execution_projection(project_root)
        sections.extend(["", "## Common selected-skill execution projection", ""])
        if common_projection:
            sections.extend(
                [
                    "This is the shared execution interface for SKILL.md-only skills.",
                    "",
                    "```python",
                    common_projection.rstrip(),
                    "```",
                ]
            )
        else:
            sections.append("- Common selected-skill runtime source not found.")
    sections.extend(["", "## Cross-skill exact-artifact contracts", ""])
    contract_projections = cross_skill_contract_projections(
        skill_dir=skill_dir,
        skills_root=project_root / "skills",
        skill_markdown=skill_md,
    )
    if contract_projections:
        for relative_path, artifact_kinds, projection in contract_projections:
            sections.extend(
                [
                    f"### `{relative_path}`",
                    "",
                    "Shared exact artifact identifiers: "
                    + ", ".join(f"`{kind}`" for kind in artifact_kinds),
                    "",
                    projection.rstrip(),
                    "",
                ]
            )
    else:
        sections.append(
            "- No neighboring skill shares the produced artifact identifier."
        )
    sections.extend(["", "## Exact route source projections", ""])
    route_projections = exact_route_source_projections(
        skill_markdown=skill_md,
        source_root=project_root / "src",
    )
    if route_projections:
        for relative_path, route_names, projection in route_projections:
            sections.extend(
                [
                    f"### `{relative_path}`",
                    "",
                    "Exact Route declarations referenced by SKILL.md: "
                    + ", ".join(f"`{name}`" for name in route_names),
                    "",
                    "```python",
                    projection.rstrip(),
                    "```",
                    "",
                ]
            )
    else:
        sections.append(
            "- No exact backticked SKILL.md identifier matched a Python "
            "`Route(name=...)` declaration."
        )
    sections.extend(["", "## Focused test files", ""])
    matches = focused_test_files(skill_dir.name, project_root / "tests")
    if matches:
        sections.extend(f"- `{path.as_posix()}`" for path in matches)
    else:
        sections.append("- None discovered by skill-id reference.")
    packet = "\n".join(sections).rstrip() + "\n"
    if len(packet) > MAX_ALIGNMENT_PACKET_CHARS:
        packet = (
            packet[:MAX_ALIGNMENT_PACKET_CHARS]
            + "\n\n[Packet truncated at the developer audit budget.]\n"
        )
    return packet


def cross_skill_contract_projections(
    *,
    skill_dir: Path,
    skills_root: Path,
    skill_markdown: str,
) -> tuple[tuple[str, tuple[str, ...], str], ...]:
    """Project exact artifact identifiers into neighboring skill contracts.

    This is an engineering cross-reference. It does not infer domain meaning or
    compatibility from similar names.
    """
    produced = set(produced_artifact_identifiers(skill_markdown))
    if not produced or not skills_root.is_dir():
        return ()
    remaining = MAX_CROSS_SKILL_CONTRACT_CHARS
    projections: list[tuple[str, tuple[str, ...], str]] = []
    target = skill_dir.resolve()
    for path in sorted(skills_root.glob("*/SKILL.md")):
        if path.parent.resolve() == target:
            continue
        markdown = path.read_text(encoding="utf-8", errors="replace")
        shared = tuple(
            sorted(
                kind
                for kind in produced
                if re.search(rf"\b{re.escape(kind)}\b", markdown)
            )
        )
        if not shared or remaining <= 0:
            continue
        neighbor_metadata = parse_frontmatter(markdown)
        blocks = [
            "Description: " + neighbor_metadata.get("description", ""),
        ]
        for heading in (
            "## Entry conditions and authority",
            "## Formal output and handoff",
            "## Failure and repair",
        ):
            content = markdown_section(markdown, heading)
            if content:
                blocks.extend(["", heading, "", content])
        projection = "\n".join(blocks).strip()
        if len(projection) > remaining:
            projection = projection[:remaining] + "\n[Projection truncated.]"
        projections.append(
            (
                path.relative_to(skills_root.parent).as_posix(),
                shared,
                projection,
            )
        )
        remaining -= min(len(projection), remaining)
    return tuple(projections)


def produced_artifact_identifiers(skill_markdown: str) -> tuple[str, ...]:
    description = parse_frontmatter(skill_markdown).get("description", "")
    clause = description.partition(" Requires ")[0]
    tokens = re.findall(r"[a-z][a-z0-9_]*", clause.lower())
    underscored = tuple(dict.fromkeys(token for token in tokens if "_" in token))
    if underscored:
        return underscored
    for marker in ("artifact", "iteration"):
        if marker not in tokens:
            continue
        index = tokens.index(marker)
        if index > 0:
            return (tokens[index - 1],)
    return ()


def common_skill_execution_projection(project_root: Path) -> str:
    common_root = project_root / "src" / "ai_coscientist" / "common"
    runtime_paths = (
        common_root / "runtime.py",
        common_root / "_runtime_prompts.py",
        common_root / "_runtime_prompting.py",
        common_root / "_runtime_tools.py",
    )
    prompt_path = common_root / "memory_lifecycle" / "prompt.py"
    if not runtime_paths[0].is_file():
        return ""

    blocks: list[tuple[int, str, str]] = []
    source_root = project_root / "src" / "ai_coscientist"
    for runtime_path in runtime_paths:
        if not runtime_path.is_file():
            continue
        source = runtime_path.read_text(encoding="utf-8", errors="replace")
        label = runtime_path.relative_to(source_root).as_posix()
        try:
            tree = ast.parse(source, filename=str(runtime_path))
        except SyntaxError:
            blocks.append(
                (0, label, source[:MAX_COMMON_INTERFACE_SOURCE_CHARS])
            )
            continue

        for node in tree.body:
            if isinstance(node, (ast.Assign, ast.AnnAssign)):
                names = assignment_names(node)
                if set(names) & set(COMMON_RUNTIME_CONSTANTS):
                    segment = ast.get_source_segment(source, node)
                    if segment:
                        blocks.append((node.lineno, label, segment))
                continue
            if not isinstance(node, ast.ClassDef):
                continue
            methods = {
                child.name: child
                for child in node.body
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))
            }
            for method_name in COMMON_RUNTIME_METHODS:
                method = methods.get(method_name)
                if method is None:
                    continue
                segment = ast.get_source_segment(source, method)
                if segment:
                    blocks.append((method.lineno, label, segment))

    if prompt_path.is_file():
        prompt_source = prompt_path.read_text(encoding="utf-8", errors="replace")
        try:
            prompt_tree = ast.parse(prompt_source, filename=str(prompt_path))
        except SyntaxError:
            prompt_tree = None
        if prompt_tree is not None:
            for node in prompt_tree.body:
                if isinstance(node, (ast.Assign, ast.AnnAssign)):
                    names = assignment_names(node)
                    if set(names) & set(COMMON_PROMPT_CONSTANTS):
                        segment = ast.get_source_segment(prompt_source, node)
                        if segment:
                            blocks.append(
                                (
                                    node.lineno,
                                    "common/memory_lifecycle/prompt.py",
                                    segment,
                                )
                            )
                    continue
                if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue
                if node.name not in {
                    "artifact_prompt_projection",
                    "code_artifact_prompt_projection",
                    "focused_code_source_prompt",
                }:
                    continue
                segment = ast.get_source_segment(prompt_source, node)
                if segment:
                    blocks.append(
                        (
                            node.lineno,
                            "common/memory_lifecycle/prompt.py",
                            segment,
                        )
                    )

    rendered: list[str] = []
    total = 0
    for line, label, segment in blocks:
        block = f"# src/ai_coscientist/{label} line {line}\n{segment.strip()}\n"
        if total + len(block) > MAX_COMMON_INTERFACE_SOURCE_CHARS:
            rendered.append(
                "# Additional common selected-skill interface source omitted by budget."
            )
            break
        rendered.append(block)
        total += len(block)
    return "\n\n".join(rendered)


def exact_route_source_projections(
    *,
    skill_markdown: str,
    source_root: Path,
) -> tuple[tuple[str, tuple[str, ...], str], ...]:
    """Return bounded source for exact Route names named by the skill.

    This is an engineering cross-reference only. It never infers a route from
    scientific words or from a capability description.
    """
    if not source_root.is_dir():
        return ()
    mentioned = set(re.findall(r"`([a-z][a-z0-9_]{2,})`", skill_markdown))
    if not mentioned:
        return ()
    remaining = MAX_ROUTE_SOURCE_CHARS
    projections: list[tuple[str, tuple[str, ...], str]] = []
    for path in sorted(source_root.rglob("*.py")):
        source = path.read_text(encoding="utf-8", errors="replace")
        declared = declared_route_names(source, path)
        matched = tuple(sorted(mentioned & declared))
        if not matched:
            continue
        if remaining <= 0:
            break
        projection = route_source_projection(source, path, matched)
        if len(projection) > remaining:
            projection = projection[:remaining] + "\n# Route projection truncated.\n"
        projections.append(
            (
                path.relative_to(source_root.parent).as_posix(),
                matched,
                projection,
            )
        )
        remaining -= min(len(projection), remaining)
    return tuple(projections)


def declared_route_names(source: str, path: Path) -> set[str]:
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return set()
    names: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not _is_route_constructor(node.func):
            continue
        for keyword in node.keywords:
            if (
                keyword.arg == "name"
                and isinstance(keyword.value, ast.Constant)
                and isinstance(keyword.value.value, str)
            ):
                names.add(keyword.value.value)
    return names


def _is_route_constructor(node: ast.expr) -> bool:
    if isinstance(node, ast.Name):
        return node.id == "Route"
    return isinstance(node, ast.Attribute) and node.attr == "Route"


def route_source_projection(
    source: str,
    path: Path,
    route_names: Sequence[str],
) -> str:
    """Render only top-level owners that declare the exact requested routes."""
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return source[:MAX_ROUTE_SOURCE_CHARS]
    requested = set(route_names)
    selected: list[tuple[int, str]] = []
    handler_names: set[str] = set()
    for node in tree.body:
        declared: set[str] = set()
        for child in ast.walk(node):
            if not isinstance(child, ast.Call) or not _is_route_constructor(child.func):
                continue
            for keyword in child.keywords:
                if keyword.arg == "handler" and isinstance(keyword.value, ast.Name):
                    handler_names.add(keyword.value.id)
                    continue
                if (
                    keyword.arg == "name"
                    and isinstance(keyword.value, ast.Constant)
                    and isinstance(keyword.value.value, str)
                ):
                    declared.add(keyword.value.value)
        if not declared.intersection(requested):
            continue
        segment = ast.get_source_segment(source, node)
        if segment:
            selected.append((getattr(node, "lineno", 0), segment))
    selected_lines = {line for line, _segment in selected}
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if node.name not in handler_names or node.lineno in selected_lines:
            continue
        segment = ast.get_source_segment(source, node)
        if segment:
            selected.append((node.lineno, segment))
    if not selected:
        return source[:MAX_ROUTE_SOURCE_CHARS]
    return "\n\n".join(
        f"# source line {line}\n{segment.strip()}" for line, segment in selected
    )


def workflow_source_projection(source: str, path: Path) -> str:
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return source[:MAX_ALIGNMENT_PACKET_CHARS]
    functions = {
        node.name: node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    selected_functions = {
        name
        for name, node in functions.items()
        if (
            name == "run"
            or any(word in name.lower() for word in RELEVANT_FUNCTION_WORDS)
            or function_has_relevant_call(node)
        )
    }
    pending = list(selected_functions)
    while pending:
        caller = functions[pending.pop()]
        for child in ast.walk(caller):
            if not isinstance(child, ast.Call) or not isinstance(child.func, ast.Name):
                continue
            callee = child.func.id
            if callee in functions and callee not in selected_functions:
                selected_functions.add(callee)
                pending.append(callee)

    referenced_names = {
        child.id
        for name in selected_functions
        for child in ast.walk(functions[name])
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load)
    }
    selected_nodes: list[ast.AST] = []
    for node in tree.body:
        include = False
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            names = assignment_names(node)
            include = bool(
                set(names) & referenced_names
                or any(
                    any(
                        word in name.upper()
                        for word in ("PROMPT", "SCHEMA", "CONTRACT")
                    )
                    for name in names
                )
            )
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            include = node.name in selected_functions
        if include:
            selected_nodes.append(node)
    selected = [
        (getattr(node, "lineno", 0), segment)
        for node in selected_nodes
        for segment in [ast.get_source_segment(source, node)]
        if segment
    ]
    if not selected:
        return source[:MAX_ALIGNMENT_PACKET_CHARS]
    rendered: list[str] = []
    total = 0
    for line, segment in selected:
        block = f"# source line {line}\n{segment.strip()}\n"
        if total + len(block) > 42_000:
            rendered.append("# Additional relevant workflow nodes omitted by budget.")
            break
        rendered.append(block)
        total += len(block)
    return "\n\n".join(rendered)


def assignment_names(node: ast.Assign | ast.AnnAssign) -> tuple[str, ...]:
    targets = node.targets if isinstance(node, ast.Assign) else [node.target]
    names = [target.id for target in targets if isinstance(target, ast.Name)]
    return tuple(names)


def function_has_relevant_call(node: ast.AST) -> bool:
    for child in ast.walk(node):
        if not isinstance(child, ast.Call) or not isinstance(child.func, ast.Attribute):
            continue
        if child.func.attr in RELEVANT_CALLS:
            return True
    return False


def focused_test_files(skill_id: str, tests_root: Path) -> tuple[Path, ...]:
    if not tests_root.is_dir():
        return ()
    needles = {skill_id, skill_id.replace("-", "_")}
    matches: list[Path] = []
    for path in sorted(tests_root.glob("test_*.py")):
        text = path.read_text(encoding="utf-8", errors="replace")
        if any(needle in text or needle in path.name for needle in needles):
            matches.append(path.relative_to(tests_root.parent))
    return tuple(matches)


def skill_digest(skill_dir: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(item for item in skill_dir.rglob("*") if item.is_file()):
        if "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        digest.update(path.relative_to(skill_dir).as_posix().encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()[:16]


def prepare_run_directory(*, output_root: Path, skill_dir: Path, digest: str) -> Path:
    base = output_root.resolve() / skill_dir.name / digest
    base.mkdir(parents=True, exist_ok=True)
    index = 1
    while (base / f"run-{index:03d}").exists():
        index += 1
    run_dir = base / f"run-{index:03d}"
    run_dir.mkdir()
    shutil.copytree(
        skill_dir,
        run_dir / "snapshot",
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
    )
    return run_dir


class JsonlRecorder:
    def __init__(self, path: Path) -> None:
        self.path = path

    def __call__(self, event: Mapping[str, Any]) -> None:
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(dict(event), ensure_ascii=False) + "\n")


def load_structural_validator(script_path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(
        "ai_coscientist_project_skill_validator", script_path
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot_load_validator:{script_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def structural_validation(skill_dir: Path, creator_root: Path) -> StructuralResult:
    validator = load_structural_validator(
        creator_root / "scripts" / "validate_project_skill.py"
    )
    result = validator.validate_skill(skill_dir)
    return StructuralResult(tuple(result.errors), tuple(result.warnings))


def render_report(
    *,
    skill_id: str,
    digest: str,
    evaluator_digest: str,
    structural: StructuralResult,
    triggers: Sequence[TriggerOutcome] | None,
    alignment: Mapping[str, Any] | None,
) -> str:
    trigger_passed = sum(outcome.passed for outcome in triggers or ())
    trigger_total = len(triggers or ())
    lines = [
        f"# Skill evaluation: {skill_id}",
        "",
        f"- Source digest: `{digest}`",
        f"- Evaluator digest: `{evaluator_digest}`",
        f"- Structural result: {'pass' if structural.passed else 'fail'}",
        (
            f"- Trigger result: {trigger_passed}/{trigger_total}"
            if triggers is not None
            else "- Trigger result: not-run"
        ),
        (
            f"- Alignment result: {alignment.get('verdict', 'invalid')}"
            if alignment is not None
            else "- Alignment result: not-run"
        ),
        "",
        "This is developer evaluation evidence. It is not a production artifact "
        "and must not be used as scientific workflow input.",
        "",
        "## Structural validation",
        "",
    ]
    if structural.errors:
        lines.extend(f"- ERROR: `{issue}`" for issue in structural.errors)
    else:
        lines.append("- No structural errors.")
    lines.extend(f"- WARNING: `{issue}`" for issue in structural.warnings)
    lines.extend(["", "## Summary-only trigger evaluation", ""])
    if triggers is None:
        lines.append("- Not run.")
    else:
        lines.extend(
            [
                "| Case | Expected target | Selected | Result | Reason |",
                "|---|---:|---|---|---|",
            ]
        )
        for outcome in triggers:
            reason = outcome.reason.replace("|", "\\|").replace("\n", " ")
            selected = outcome.selected_skill.replace("|", "\\|")
            lines.append(
                f"| `{outcome.case.case_id}` | "
                f"{'yes' if outcome.case.should_select else 'no'} | "
                f"`{selected}` | {'pass' if outcome.passed else 'fail'} | "
                f"{reason} |"
            )
            lines.append(f"\nRequest: {outcome.case.request}\n")
    lines.extend(["", "## Prompt and contract alignment", ""])
    if alignment is None:
        lines.append("- Not run.")
    else:
        lines.append(f"- Verdict: `{alignment.get('verdict')}`")
        for issue in alignment.get("issues") or []:
            lines.append(f"- Issue: {issue}")
        for strength in alignment.get("strengths") or []:
            lines.append(f"- Strength: {strength}")
    lines.extend(
        [
            "",
            "## Interpretation limits",
            "",
            "- Structural success proves only authoring invariants.",
            "- Trigger evaluation tests summary selection, not full skill execution.",
            "- Alignment review is an advisory LLM judgment over the bounded source packet.",
            "- A producer-consumer boundary replay and real forward task remain required.",
        ]
    )
    return "\n".join(lines).rstrip() + "\n"


def load_model(config_path: Path, project_root: Path) -> Any:
    parser = configparser.ConfigParser()
    if not parser.read(config_path, encoding="utf-8") or "LLM" not in parser:
        raise ValueError(f"invalid_llm_config:{config_path}")
    section = parser["LLM"]
    src = str((project_root / "src").resolve())
    if src not in sys.path:
        sys.path.insert(0, src)
    from ai_coscientist.common.openai_compatible import OpenAICompatibleModel

    def status(event: Mapping[str, Any]) -> None:
        if event.get("event") in {"start", "finish", "error"}:
            print(
                "[llm] "
                + str(event.get("event"))
                + " purpose="
                + str(event.get("purpose") or "")
            )

    return OpenAICompatibleModel(
        base_url=section["api_base"].strip(),
        model=section["model_name"].strip(),
        api_key=section.get("api_key", "").strip(),
        timeout_seconds=float(section.get("timeout", "1800")),
        max_tokens=int(section.get("max_tokens", "7000")),
        temperature=float(section.get("temperature", "0")),
        reasoning_effort=section.get("reasoning_effort", "").strip(),
        stream=True,
        on_status=status,
    )


def run_evaluation(
    *,
    project_root: Path,
    creator_root: Path,
    skill_dir: Path,
    output_root: Path,
    model: Any | None,
) -> tuple[
    Path, StructuralResult, tuple[TriggerOutcome, ...] | None, Mapping[str, Any] | None
]:
    project_root = project_root.resolve()
    skill_dir = skill_dir.resolve()
    digest = skill_digest(skill_dir)
    evaluator_digest = skill_digest(creator_root.resolve())
    run_dir = prepare_run_directory(
        output_root=output_root,
        skill_dir=skill_dir,
        digest=digest,
    )
    audit_packet = build_alignment_packet(skill_dir, project_root)
    (run_dir / "audit-packet.md").write_text(audit_packet, encoding="utf-8")
    recorder = JsonlRecorder(run_dir / "raw-model-events.jsonl")
    structural = structural_validation(skill_dir, creator_root)
    triggers: tuple[TriggerOutcome, ...] | None = None
    alignment: Mapping[str, Any] | None = None
    if model is not None:
        markdown = (skill_dir / "SKILL.md").read_text(encoding="utf-8")
        cases = parse_trigger_cases(markdown)
        summaries = discover_skill_summaries(project_root / "skills")
        triggers = evaluate_trigger_cases(
            skill_id=skill_dir.name,
            summaries=summaries,
            cases=cases,
            model=model,
            record_event=recorder,
        )
        alignment = evaluate_alignment(
            skill_id=skill_dir.name,
            audit_packet=audit_packet,
            model=model,
            record_event=recorder,
        )
    report = render_report(
        skill_id=skill_dir.name,
        digest=digest,
        evaluator_digest=evaluator_digest,
        structural=structural,
        triggers=triggers,
        alignment=alignment,
    )
    (run_dir / "report.md").write_text(report, encoding="utf-8")
    return run_dir, structural, triggers, alignment


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate one project skill with structural checks, summary-only "
            "trigger cases, and an advisory prompt-contract review."
        )
    )
    parser.add_argument("skill_directory", type=Path)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--config", type=Path)
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("outputs") / "skill-creator",
    )
    args = parser.parse_args()
    project_root = args.project_root.resolve()
    creator_root = Path(__file__).resolve().parents[1]
    skill_dir = (
        args.skill_directory
        if args.skill_directory.is_absolute()
        else project_root / args.skill_directory
    ).resolve()
    model = load_model(args.config.resolve(), project_root) if args.config else None
    try:
        run_dir, structural, triggers, alignment = run_evaluation(
            project_root=project_root,
            creator_root=creator_root,
            skill_dir=skill_dir,
            output_root=(
                args.output_root
                if args.output_root.is_absolute()
                else project_root / args.output_root
            ),
            model=model,
        )
    except Exception as exc:
        print(f"[FAILED] {exc}")
        return 1
    print(f"[REPORT] {run_dir / 'report.md'}")
    if not structural.passed:
        return 1
    if triggers is not None and not all(item.passed for item in triggers):
        return 1
    if alignment is not None and alignment.get("verdict") != "aligned":
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
