#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ReportMetrics:
    skill_id: str
    digest: str
    evaluator_digest: str
    structural: str
    trigger_passed: int | None
    trigger_total: int | None
    alignment: str
    cases: tuple[tuple[str, str, str], ...]


def parse_report(path: Path) -> ReportMetrics:
    text = path.read_text(encoding="utf-8")
    title = re.search(r"^# Skill evaluation: (.+)$", text, flags=re.MULTILINE)
    digest = re.search(r"^- Source digest: `([^`]+)`$", text, flags=re.MULTILINE)
    evaluator_digest = re.search(
        r"^- Evaluator digest: `([^`]+)`$", text, flags=re.MULTILINE
    )
    structural = re.search(
        r"^- Structural result: (\S+)$", text, flags=re.MULTILINE
    )
    trigger = re.search(
        r"^- Trigger result: (?:(\d+)/(\d+)|(not-run))$",
        text,
        flags=re.MULTILINE,
    )
    alignment = re.search(
        r"^- Alignment result: (\S+)$", text, flags=re.MULTILINE
    )
    if not all((title, digest, evaluator_digest, structural, trigger, alignment)):
        raise ValueError(f"evaluation_report_header_invalid:{path}")
    case_rows = re.findall(
        r"^\| `([^`]+)` \| (yes|no) \| `[^`]+` \| (?:pass|fail) \|.*$",
        text,
        flags=re.MULTILINE,
    )
    requests = re.findall(r"^Request: (.+)$", text, flags=re.MULTILINE)
    if case_rows and len(case_rows) != len(requests):
        raise ValueError(f"evaluation_report_case_requests_invalid:{path}")
    cases = tuple(
        (case_id, expected, request)
        for (case_id, expected), request in zip(case_rows, requests, strict=True)
    )
    return ReportMetrics(
        skill_id=title.group(1).strip(),
        digest=digest.group(1),
        evaluator_digest=evaluator_digest.group(1),
        structural=structural.group(1),
        trigger_passed=int(trigger.group(1)) if trigger.group(1) else None,
        trigger_total=int(trigger.group(2)) if trigger.group(2) else None,
        alignment=alignment.group(1),
        cases=cases,
    )


def compare_reports(baseline: ReportMetrics, candidate: ReportMetrics) -> str:
    if baseline.skill_id != candidate.skill_id:
        raise ValueError(
            "comparison_skill_mismatch:"
            f"{baseline.skill_id}:{candidate.skill_id}"
        )
    if baseline.evaluator_digest != candidate.evaluator_digest:
        raise ValueError("comparison_evaluator_changed")
    if baseline.cases != candidate.cases:
        raise ValueError("comparison_trigger_cases_changed")
    rows = [
        ("Structural", baseline.structural, candidate.structural),
        (
            "Trigger",
            format_trigger(baseline),
            format_trigger(candidate),
        ),
        ("Alignment", baseline.alignment, candidate.alignment),
    ]
    lines = [
        f"# Skill evaluation comparison: {baseline.skill_id}",
        "",
        f"- Baseline digest: `{baseline.digest}`",
        f"- Candidate digest: `{candidate.digest}`",
        f"- Evaluator digest: `{baseline.evaluator_digest}`",
        "- Trigger cases: unchanged",
        "",
        "| Dimension | Baseline | Candidate | Change |",
        "|---|---|---|---|",
    ]
    for dimension, before, after in rows:
        lines.append(
            f"| {dimension} | `{before}` | `{after}` | "
            f"{change_label(dimension, baseline, candidate, before, after)} |"
        )
    lines.extend(
        [
            "",
            "This comparison does not prove scientific quality or forward-task "
            "success. Mixed changes require source review; they are not averaged "
            "into one score.",
        ]
    )
    return "\n".join(lines) + "\n"


def format_trigger(metrics: ReportMetrics) -> str:
    if metrics.trigger_passed is None or metrics.trigger_total is None:
        return "not-run"
    return f"{metrics.trigger_passed}/{metrics.trigger_total}"


def change_label(
    dimension: str,
    baseline: ReportMetrics,
    candidate: ReportMetrics,
    before: str,
    after: str,
) -> str:
    if before == after:
        return "unchanged"
    if dimension == "Structural":
        order = {"fail": 0, "pass": 1}
        return ranked_change(before, after, order)
    if dimension == "Alignment":
        order = {
            "not-run": -1,
            "needs_revision": 0,
            "insufficient_evidence": 1,
            "aligned": 2,
        }
        return ranked_change(before, after, order)
    if dimension == "Trigger":
        if (
            baseline.trigger_passed is None
            or baseline.trigger_total in {None, 0}
            or candidate.trigger_passed is None
            or candidate.trigger_total in {None, 0}
        ):
            return "not-comparable"
        before_ratio = baseline.trigger_passed / baseline.trigger_total
        after_ratio = candidate.trigger_passed / candidate.trigger_total
        return "improved" if after_ratio > before_ratio else "regressed"
    return "changed"


def ranked_change(before: str, after: str, order: dict[str, int]) -> str:
    if before not in order or after not in order:
        return "changed"
    return "improved" if order[after] > order[before] else "regressed"


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Compare two project skill evaluation reports."
    )
    parser.add_argument("baseline_report", type=Path)
    parser.add_argument("candidate_report", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        comparison = compare_reports(
            parse_report(args.baseline_report),
            parse_report(args.candidate_report),
        )
    except (OSError, UnicodeError, ValueError) as exc:
        print(f"[FAILED] {exc}")
        return 1
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(comparison, encoding="utf-8")
        print(f"[REPORT] {args.output.resolve()}")
    else:
        print(comparison, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
