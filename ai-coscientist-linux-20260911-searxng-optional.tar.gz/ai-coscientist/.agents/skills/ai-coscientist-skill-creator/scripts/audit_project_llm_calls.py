#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class LlmCallSite:
    path: str
    line: int
    enclosing_function: str
    interface: str
    purpose: str
    prompt_source: str
    output_contract_source: str


class _CallVisitor(ast.NodeVisitor):
    def __init__(self, *, path: Path, project_root: Path, source: str) -> None:
        self._path = path
        self._project_root = project_root
        self._source = source
        self._functions: list[str] = []
        self.calls: list[LlmCallSite] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._functions.append(node.name)
        self.generic_visit(node)
        self._functions.pop()

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._functions.append(node.name)
        self.generic_visit(node)
        self._functions.pop()

    def visit_Call(self, node: ast.Call) -> None:
        if isinstance(node.func, ast.Attribute):
            interface = node.func.attr
            if interface in {"complete", "generate_json"}:
                self.calls.append(self._describe(node, interface=interface))
        self.generic_visit(node)

    def _describe(self, node: ast.Call, *, interface: str) -> LlmCallSite:
        keywords = {
            item.arg: item.value for item in node.keywords if item.arg is not None
        }
        purpose = _expression(self._source, keywords.get("purpose"))
        if interface == "generate_json":
            prompt_nodes = node.args[:2]
            output_node = keywords.get("schema")
        else:
            prompt_nodes = tuple(
                item for item in (keywords.get("messages"),) if item is not None
            )
            output_node = keywords.get("tools")
        prompt_source = " | ".join(
            _expression(self._source, item) for item in prompt_nodes
        )
        return LlmCallSite(
            path=self._path.relative_to(self._project_root).as_posix(),
            line=int(getattr(node, "lineno", 0)),
            enclosing_function=(self._functions[-1] if self._functions else "<module>"),
            interface=interface,
            purpose=purpose,
            prompt_source=prompt_source,
            output_contract_source=_expression(self._source, output_node),
        )


def _expression(source: str, node: ast.AST | None) -> str:
    if node is None:
        return "<missing>"
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    segment = ast.get_source_segment(source, node)
    if segment:
        return " ".join(segment.split())
    try:
        return ast.unparse(node)
    except (AttributeError, ValueError):
        return f"<{type(node).__name__}>"


def audit_project(
    project_root: Path,
    *,
    roots: Iterable[str] = ("src/ai_coscientist", "skills"),
) -> list[LlmCallSite]:
    project_root = project_root.resolve()
    calls: list[LlmCallSite] = []
    for relative_root in roots:
        root = (project_root / relative_root).resolve()
        if not root.is_relative_to(project_root) or not root.exists():
            continue
        for path in sorted(root.rglob("*.py")):
            if "__pycache__" in path.parts:
                continue
            source = path.read_text(encoding="utf-8", errors="replace")
            try:
                tree = ast.parse(source, filename=str(path))
            except SyntaxError:
                continue
            visitor = _CallVisitor(
                path=path,
                project_root=project_root,
                source=source,
            )
            visitor.visit(tree)
            calls.extend(visitor.calls)
    return sorted(calls, key=lambda item: (item.path, item.line))


def _markdown(calls: Iterable[LlmCallSite]) -> str:
    rows = [
        "| File | Line | Function | Interface | Purpose |",
        "|---|---:|---|---|---|",
    ]
    for item in calls:
        values = (
            item.path,
            str(item.line),
            item.enclosing_function,
            item.interface,
            item.purpose,
        )
        rows.append("| " + " | ".join(value.replace("|", "\\|") for value in values) + " |")
    return "\n".join(rows)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Inventory production LLM call sites for contract auditing."
    )
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--format", choices=("json", "markdown"), default="markdown")
    args = parser.parse_args()
    calls = audit_project(args.project_root)
    if args.format == "json":
        print(json.dumps([asdict(item) for item in calls], ensure_ascii=False, indent=2))
    else:
        print(_markdown(calls))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
