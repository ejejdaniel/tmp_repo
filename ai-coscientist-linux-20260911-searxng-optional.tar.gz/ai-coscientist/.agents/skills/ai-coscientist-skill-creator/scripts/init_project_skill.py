#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import textwrap
from pathlib import Path


NAME_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
COMPLEXITY_VALUES = {"low", "medium", "high"}


def normalize_name(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", value.strip().lower())
    return re.sub(r"-{2,}", "-", normalized).strip("-")


def validate_description(description: str) -> None:
    if len(description) > 400:
        raise ValueError("description_exceeds_400_characters")
    if not description.startswith("Produces "):
        raise ValueError("description_must_start_with_Produces")
    if " Requires " not in description:
        raise ValueError("description_requires_clause_missing")
    if " Boundary: " not in description:
        raise ValueError("description_boundary_clause_missing")


def skill_template(
    name: str,
    description: str,
    estimated_complexity: str,
    accepts_research_mode: bool = False,
) -> str:
    title = " ".join(part.capitalize() for part in name.split("-"))
    research_mode_line = (
        "accepts_research_mode: true\n" if accepts_research_mode else ""
    )
    return textwrap.dedent(
        f'''\
        ---
        name: {name}
        description: {description}
        estimated_complexity: {estimated_complexity}
        {research_mode_line.rstrip()}
        ---

        # {title}

        ## Responsibility and boundary

        [TODO: State the one responsibility this skill owns and the adjacent work it must not perform.]

        ## Entry conditions and authority

        [TODO: Name every required exact artifact/workspace/route authority, visibility boundary, and missing-input behavior.]

        ## Trigger examples

        ### Should select

        - [TODO: Give one realistic request with every authoritative prerequisite available.]
        - [TODO: Give a differently worded request for the same owned result.]

        ### Should not select

        - [TODO: Give one adjacent request owned by another capability.]
        - [TODO: Give one request missing a prerequisite that must be produced first.]

        ## Prompt and memory projection

        [TODO: List C0 through C6 explicitly, map each prompt source and named intermediate/output, and mark unused classes. Explain what each LLM stage receives and what is intentionally absent.]

        ### LLM call contracts

        [TODO: Add one row per LLM call. If this skill has no internal LLM call, state that explicitly.]

        | Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
        |---|---|---|---|---|---|---|---|
        | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] | [TODO] |

        ## Skill-local workflow

        [TODO: Describe bounded internal stages. Keep planner-level skill choice outside this workflow.]

        ## Formal output and handoff

        [TODO: Name the existing formal artifact kind, authoritative content, dependencies, readback, and downstream consumer.]

        ## Failure and repair

        [TODO: Separate local payload/format repair, implementation repair, structured capability gaps, replan, and parent failure.]

        ## Validation evidence

        [TODO: List deterministic tests, boundary replay, smallest real-model test, and what each proves.]
        '''
    )


def workflow_template() -> str:
    return textwrap.dedent(
        '''\
        from __future__ import annotations

        from typing import Any


        def run(payload: dict[str, Any], runtime: Any) -> dict[str, Any]:
            """Execute one bounded skill-local workflow."""
            raise NotImplementedError("replace_with_skill_local_workflow")
        '''
    )


def create_skill(
    *,
    project_root: Path,
    raw_name: str,
    description: str,
    estimated_complexity: str,
    with_workflow: bool,
    with_references: bool,
    with_scripts: bool,
    accepts_research_mode: bool = False,
) -> Path:
    project_root = project_root.resolve()
    name = normalize_name(raw_name)
    if not name or len(name) > 64 or not NAME_PATTERN.fullmatch(name):
        raise ValueError(f"invalid_skill_name:{raw_name}")
    validate_description(description)
    if estimated_complexity not in COMPLEXITY_VALUES:
        raise ValueError(
            f"estimated_complexity_invalid:{estimated_complexity}"
        )

    skills_root = (project_root / "skills").resolve()
    target = (skills_root / name).resolve()
    if not target.is_relative_to(skills_root):
        raise ValueError("skill_path_outside_project_catalog")
    if target.exists():
        raise FileExistsError(f"skill_already_exists:{target}")

    target.mkdir(parents=True)
    (target / "SKILL.md").write_text(
        skill_template(
            name,
            description,
            estimated_complexity,
            accepts_research_mode=accepts_research_mode,
        ),
        encoding="utf-8",
    )
    if with_workflow:
        (target / "workflow.py").write_text(workflow_template(), encoding="utf-8")
    if with_references:
        (target / "references").mkdir()
    if with_scripts:
        (target / "scripts").mkdir()
    return target


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Create an ai-coscientist production skill skeleton."
    )
    parser.add_argument("skill_name")
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--description", required=True)
    parser.add_argument(
        "--estimated-complexity",
        choices=sorted(COMPLEXITY_VALUES),
        required=True,
    )
    parser.add_argument("--with-workflow", action="store_true")
    parser.add_argument("--with-references", action="store_true")
    parser.add_argument("--with-scripts", action="store_true")
    parser.add_argument("--accepts-research-mode", action="store_true")
    args = parser.parse_args()

    try:
        target = create_skill(
            project_root=args.project_root,
            raw_name=args.skill_name,
            description=args.description.strip(),
            estimated_complexity=args.estimated_complexity,
            with_workflow=args.with_workflow,
            with_references=args.with_references,
            with_scripts=args.with_scripts,
            accepts_research_mode=args.accepts_research_mode,
        )
    except (FileExistsError, OSError, ValueError) as exc:
        print(f"[ERROR] {exc}")
        return 1

    print(f"[OK] Created {target}")
    print("[NEXT] Complete every TODO, then run validate_project_skill.py.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
