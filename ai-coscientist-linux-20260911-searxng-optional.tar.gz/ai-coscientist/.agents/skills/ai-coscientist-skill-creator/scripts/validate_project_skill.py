#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import re
from dataclasses import dataclass, field
from pathlib import Path


NAME_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
COMPLEXITY_VALUES = {"low", "medium", "high"}
FRONTMATTER_PATTERN = re.compile(r"\A---\r?\n(.*?)\r?\n---\r?\n", re.DOTALL)
REQUIRED_HEADINGS = (
    "## Responsibility and boundary",
    "## Entry conditions and authority",
    "## Trigger examples",
    "## Prompt and memory projection",
    "## Skill-local workflow",
    "## Formal output and handoff",
    "## Failure and repair",
    "## Validation evidence",
)
DYNAMIC_CONTROL_TOKENS = {"next_skill", "next_action", "allowed_actions"}
TRIGGER_SUBHEADINGS = (
    "### Should select",
    "### Should not select",
)


@dataclass
class ValidationResult:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def valid(self) -> bool:
        return not self.errors


def parse_frontmatter(markdown: str) -> tuple[dict[str, str], str]:
    match = FRONTMATTER_PATTERN.match(markdown)
    if match is None:
        raise ValueError("frontmatter_missing_or_invalid")
    metadata: dict[str, str] = {}
    for raw_line in match.group(1).splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        key, separator, value = line.partition(":")
        if not separator:
            raise ValueError(f"frontmatter_line_invalid:{raw_line}")
        key = key.strip()
        if key in metadata:
            raise ValueError(f"frontmatter_key_duplicate:{key}")
        metadata[key] = value.strip().strip("\"'")
    return metadata, markdown[match.end():]


def section(markdown: str, heading: str) -> str:
    start = markdown.find(heading)
    if start < 0:
        return ""
    start += len(heading)
    level = len(heading) - len(heading.lstrip("#"))
    if level <= 0:
        return ""
    match = re.search(
        rf"^#{{1,{level}}}\s",
        markdown[start:],
        flags=re.MULTILINE,
    )
    end = start + match.start() if match else len(markdown)
    return markdown[start:end].strip()


def validate_skill(skill_dir: Path) -> ValidationResult:
    result = ValidationResult()
    skill_dir = skill_dir.resolve()
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.is_file():
        result.errors.append("SKILL.md_missing")
        return result

    try:
        markdown = skill_md.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        result.errors.append(f"SKILL.md_unreadable:{exc}")
        return result

    try:
        metadata, body = parse_frontmatter(markdown)
    except ValueError as exc:
        result.errors.append(str(exc))
        return result

    required_metadata = {"name", "description", "estimated_complexity"}
    optional_metadata = {"accepts_research_mode"}
    extra = sorted(set(metadata) - required_metadata - optional_metadata)
    if extra:
        result.errors.append("frontmatter_extra_keys:" + ",".join(extra))
    missing = sorted(required_metadata - set(metadata))
    if missing:
        result.errors.append("frontmatter_missing_keys:" + ",".join(missing))

    name = metadata.get("name", "").strip()
    description = metadata.get("description", "").strip()
    estimated_complexity = metadata.get("estimated_complexity", "").strip()
    accepts_research_mode = metadata.get("accepts_research_mode")
    if not NAME_PATTERN.fullmatch(name) or len(name) > 64:
        result.errors.append(f"skill_name_invalid:{name}")
    if name and skill_dir.name != name:
        result.errors.append(
            f"skill_directory_name_mismatch:directory={skill_dir.name}:name={name}"
        )
    if len(description) > 400:
        result.errors.append(
            "description_exceeds_400_characters:"
            f"actual={len(description)}:max=400:safe_target=320"
        )
    if not description.startswith("Produces "):
        result.errors.append("description_must_start_with_Produces")
    if " Requires " not in description:
        result.errors.append("description_requires_clause_missing")
    if " Boundary: " not in description:
        result.errors.append("description_boundary_clause_missing")
    if estimated_complexity not in COMPLEXITY_VALUES:
        result.errors.append(
            f"estimated_complexity_invalid:{estimated_complexity}"
        )
    if accepts_research_mode is not None and accepts_research_mode not in {
        "true",
        "false",
    }:
        result.errors.append(
            f"accepts_research_mode_invalid:{accepts_research_mode}"
        )

    if "[TODO" in markdown or "TODO:" in markdown:
        result.errors.append("unfinished_TODO_marker")
    if len(markdown.splitlines()) > 500:
        result.errors.append("SKILL.md_exceeds_500_lines")
    for heading in REQUIRED_HEADINGS:
        if heading not in body:
            result.errors.append(f"required_heading_missing:{heading}")

    _validate_trigger_examples(body, result)

    memory_section = section(body, "## Prompt and memory projection")
    missing_memory_classes = [
        memory_class
        for memory_class in (f"C{index}" for index in range(7))
        if not re.search(rf"\b{memory_class}\b", memory_section)
    ]
    if missing_memory_classes:
        result.errors.append(
            "memory_projection_missing_classes:"
            + ",".join(missing_memory_classes)
        )
    if "### LLM call contracts" not in memory_section:
        result.warnings.append("llm_call_contract_ledger_missing")

    for token in sorted(DYNAMIC_CONTROL_TOKENS):
        if re.search(rf"\b{re.escape(token)}\b", body):
            result.warnings.append(
                f"review_dynamic_workflow_token_in_SKILL.md:{token}"
            )

    _validate_references(skill_dir, body, result)
    _validate_workflow(skill_dir, body, result)
    return result


def _validate_trigger_examples(body: str, result: ValidationResult) -> None:
    trigger_section = section(body, "## Trigger examples")
    if not trigger_section:
        return
    for heading in TRIGGER_SUBHEADINGS:
        content = section(trigger_section, heading)
        examples = [
            line[2:].strip()
            for line in content.splitlines()
            if line.startswith("- ") and line[2:].strip()
        ]
        if len(examples) < 2:
            key = heading.removeprefix("### ").lower().replace(" ", "_")
            result.errors.append(
                f"trigger_examples_{key}_requires_at_least_two"
            )
        for example in examples:
            if len(example) < 24:
                result.errors.append("trigger_example_too_short")


def _validate_references(
    skill_dir: Path, body: str, result: ValidationResult
) -> None:
    references = skill_dir / "references"
    if not references.exists():
        return
    links = {
        match.group(1).split("#", 1)[0].replace("\\", "/")
        for match in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", body)
    }
    links.update(_disclosure_reference_links(skill_dir, result))
    for path in sorted(item for item in references.rglob("*") if item.is_file()):
        relative = path.relative_to(skill_dir).as_posix()
        if len(path.relative_to(references).parts) != 1:
            result.errors.append(f"nested_reference_not_allowed:{relative}")
        if relative not in links:
            result.errors.append(f"reference_not_linked_from_SKILL.md:{relative}")
    for link in sorted(links):
        if link.startswith(("http://", "https://", "#")):
            continue
        if link.startswith(("references/", "scripts/", "assets/")):
            target = (skill_dir / link).resolve()
            if not target.is_relative_to(skill_dir) or not target.exists():
                result.errors.append(f"linked_resource_missing:{link}")


def _disclosure_reference_links(
    skill_dir: Path,
    result: ValidationResult,
) -> set[str]:
    """Treat literal disclosure-page names as executable references."""
    path = skill_dir / "disclosure.py"
    if not path.exists():
        return set()
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except (OSError, UnicodeError, SyntaxError) as exc:
        result.errors.append(f"disclosure_unreadable_or_invalid:{exc}")
        return set()
    return {
        f"references/{node.value}"
        for node in ast.walk(tree)
        if isinstance(node, ast.Constant)
        and isinstance(node.value, str)
        and node.value.endswith(".md")
        and "/" not in node.value
        and "\\" not in node.value
    }


def _validate_workflow(
    skill_dir: Path, body: str, result: ValidationResult
) -> None:
    path = skill_dir / "workflow.py"
    if not path.exists():
        return
    try:
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
    except (OSError, UnicodeError, SyntaxError) as exc:
        result.errors.append(f"workflow_unreadable_or_invalid:{exc}")
        return

    runs = [
        node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == "run"
    ]
    if len(runs) != 1:
        result.errors.append(f"workflow_run_count_invalid:{len(runs)}")
        return
    run = runs[0]
    positional = [*run.args.posonlyargs, *run.args.args]
    if (
        [argument.arg for argument in positional] != ["payload", "runtime"]
        or run.args.vararg is not None
        or run.args.kwarg is not None
        or run.args.kwonlyargs
        or run.args.defaults
    ):
        result.errors.append("workflow_run_signature_must_be_run_payload_runtime")

    generate_calls = []
    publish_calls = []
    read_calls = []
    # Helper functions are part of the trusted workflow implementation. Audit
    # the complete module so moving a model call behind a helper cannot bypass
    # the prompt/schema/readback checks.
    for node in ast.walk(tree):
        if isinstance(node, ast.Raise) and isinstance(node.exc, ast.Call):
            if isinstance(node.exc.func, ast.Name) and node.exc.func.id == "NotImplementedError":
                result.errors.append("workflow_still_not_implemented")
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr == "generate_json":
            generate_calls.append(node)
            keywords = {item.arg for item in node.keywords if item.arg}
            if "purpose" not in keywords:
                result.errors.append("generate_json_purpose_missing")
            if "schema" not in keywords:
                result.errors.append("generate_json_schema_missing")
        elif node.func.attr == "publish_artifact":
            publish_calls.append(node)
        elif node.func.attr == "read_artifact":
            read_calls.append(node)

    if len(generate_calls) > 1 and "C5" not in body:
        result.errors.append("multi_call_workflow_missing_C5_continuity_contract")
    prompt_projection = section(body, "## Prompt and memory projection")
    for call in generate_calls:
        purpose = _literal_keyword(call, "purpose")
        if purpose and purpose not in prompt_projection:
            result.warnings.append(
                f"llm_call_purpose_not_documented:{purpose}"
            )
    if publish_calls and not read_calls:
        result.errors.append("workflow_publish_without_exact_readback")

    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            if node.value in DYNAMIC_CONTROL_TOKENS:
                result.errors.append(
                    f"workflow_emits_dynamic_control_token:{node.value}"
                )


def _literal_keyword(call: ast.Call, name: str) -> str:
    for keyword in call.keywords:
        if keyword.arg != name:
            continue
        if isinstance(keyword.value, ast.Constant) and isinstance(
            keyword.value.value, str
        ):
            return keyword.value.value
    return ""


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate an ai-coscientist production skill."
    )
    parser.add_argument("skill_directory", type=Path)
    args = parser.parse_args()

    result = validate_skill(args.skill_directory)
    for issue in result.errors:
        print(f"[ERROR] {issue}")
    for issue in result.warnings:
        print(f"[WARNING] {issue}")
    if result.valid:
        print("[OK] Project skill structure is valid.")
        return 0
    print(f"[FAILED] {len(result.errors)} error(s), {len(result.warnings)} warning(s).")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
