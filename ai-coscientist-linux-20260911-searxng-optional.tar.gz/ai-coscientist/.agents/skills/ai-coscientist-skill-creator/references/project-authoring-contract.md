# Project Skill Authoring Contract

Use this contract for production skills under `skills/` and for reusable domain routes that those skills consume. The project memory constitution remains higher authority.

## 1. Capability classification

| Type | Use when | Must not do |
|---|---|---|
| Production skill | The coordinator should dynamically choose one agent-level responsibility that creates or revises a formal result | Encode the next production action or absorb unrelated responsibilities |
| Skill-local workflow | One selected skill owns a bounded internal sequence whose intermediate stages are not independent planner choices | Leak internal retries into the main planner |
| Route | A reusable callable operation has explicit inputs/outputs and can sit behind a skill or generated program | Become a planner-visible stage merely because it is reusable |
| Common infrastructure | The behavior is science-neutral and required across domains for LOOP, refs, visibility, memory, prompts, tools, or closure | Contain domain semantics or solve one skill's test |
| Child agent | A delegated objective requires its own task contract, evaluation, plan, loop, and white-room workspace | Inherit parent memory, plan, gate, hidden reasoning, or full workspace |
| Helper/reference | A local deterministic function or document supports one owner without independent orchestration value | Pretend to be a skill |

Classification is an architecture decision. Do not use file size or implementation convenience as the deciding criterion.

## 2. Required production skill structure

A newly authored production `SKILL.md` requires `name`, `description`, and
`estimated_complexity` frontmatter. It may additionally declare
`accepts_research_mode: true` only when the skill consumes the caller-owned
two-axis research-mode card; absence means `false`. `estimated_complexity` is
one of `low`, `medium`, or `high`; it estimates execution load for planning and
is neither algorithmic Big-O nor a binding node-splitting rule. Its body must
contain:

For a skill with `accepts_research_mode: true`, the common planner performs a
second, private binding stage. It classifies every node-scoped candidate ref as
commission authority, required authority, shared context, comparison baseline,
or irrelevant; Python then derives the final `input_refs` and the existing
three-field research-mode card. The skill contract must state which required
structural inputs remain visible in an explore-mode first draft, which shared
inputs are withheld, and where they return for reconciliation. Do not add a
second classifier inside the skill or infer these roles from scientific
keywords.

- `Responsibility and boundary`
- `Entry conditions and authority`
- `Trigger examples`
- `Prompt and memory projection`
- `Skill-local workflow`
- `Formal output and handoff`
- `Failure and repair`
- `Validation evidence`

The description uses this compact form:

```text
Produces <formal result and purpose>. Requires <authoritative prerequisites>. Boundary: <what it does not own>.
```

Keep the description under 400 characters. Keep the body under 500 lines. Put detailed variants in directly linked files under `references/`.

For a dynamically disclosed skill, `SKILL.md` still contains every required
section as the compact root contract. `disclosure.py` may reveal one stage page
at a time and its literal `.md` page names count as executable references. Stage
pages may refine the current action, but may not redefine responsibility,
authority, formal output, C0-C6 ownership, or failure ownership from the root
contract.

### Trigger examples

The body records at least four selection cases without leaking them into the summary-only production prompt:

- two complete, realistic requests that should select the skill;
- one adjacent request owned by another capability;
- one request whose declared prerequisite is absent and must be produced first.

A trigger test is valid only when the selector sees the same summaries available in production and does not see the skill body, expected label, or prior report. Trigger success proves selection quality only; it does not prove skill execution.

## 3. Responsibility review

Answer before editing:

1. What single responsibility does the skill own?
2. Which neighboring skill, route, common capability, or child owns adjacent work?
3. What is the formal output?
4. Who consumes it?
5. What behavior is explicitly forbidden?
6. Can a result be partial or blocked without pretending to be complete?

Reject the design when the skill is only a fixed stage name, a bag of unrelated tools, a wrapper around another skill, or a workaround for missing common transport.

## 4. Input authority and dynamic dataflow

For every input, document:

| Input | Authority | How selected | Visibility | Missing behavior |
|---|---|---|---|---|
| Example | exact stored artifact or workspace ref | active mission/plan ref | agent/skill/child scope | local gap, replan, or parent failure |

Rules:

- Stored artifacts own formal semantic content.
- Workspace files own large content.
- Receipts, summaries, inline copies, and raw events are not substitute authorities.
- Consumers use explicit mission/active refs, not global latest-of-kind guesses.
- Pending child output is review-only until accepted.
- A child receives only mission-scoped refs and builds its own task contract, evaluation, and plan.

## 5. C0-C6 output and intermediate mapping
An artifact publication creates a new immutable identity even when its semantic payload is unchanged. If downstream code, evidence, or materialization is bound to an exact prior ref, the producer must make that invalidation visible and the consumer must reject the stale pair with the expected and actual refs. Do not silently treat equivalent content as the same identity. The coordinator may dynamically obtain a fresh prerequisite within the current plan work unit; this does not by itself require a replan.

A producer-to-consumer boundary replay must include a version transition whenever the producer can publish revisions. At minimum, verify that `v1 dependency + v2 result` is either accepted by an explicit existing contract or rejected with enough exact-ref evidence to recover.


Map every named item. List C0 through C6 explicitly and mark any unused class:

| Item | C class | Unique store | Retention/metabolism | Prompt exposure | Consumer |
|---|---|---|---|---|---|

Use the meanings in `docs/common_memory_constitution_zh-TW.md`:

- C0 fixed core
- C1 current control state
- C2 formal artifact
- C3 compressible knowledge/observation
- C4 large workspace data
- C5 skill-local temporary state
- C6 append-only raw audit

Do not assign one content body to multiple classes. Refs, manifests, indexes, and bounded summaries are projections, not copies of authority.

For a large result plus a small descriptor, normally store the descriptor as C2 and the large body as C4 under one logical artifact identity. Do not create a new class merely to represent grouping.

## 6. Prompt-stage map

### Single authority for one LLM call

For every LLM call, document one authoritative call contract before writing or
changing prompt prose:

| Contract owner | Stage purpose | Authoritative inputs and C0-C6 projections | Allowed work | Output shape | Validator | Local repair | Downstream consumer |
|---|---|---|---|---|---|---|---|

The call contract is the sole semantic authority for that call. The following
surfaces are projections or implementations of it and must not define competing
requirements:

- system and user prompt fragments;
- tool description and output schema;
- deterministic validator or LLM reviewer;
- local format or payload repair prompt;
- publication mapping and downstream read.

Do not maintain the same rule independently in several Markdown pages or Python
validators. If repetition is necessary for model visibility, render or quote the
same authoritative rule without changing its scope. When a requirement changes,
update the owner first and then inspect every projection and consumer.

### Consistency audit procedure

For each call, inspect the complete causal chain in this order:

1. Render the final messages and tools exactly as sent to the model.
2. Identify the authority and lifecycle of every included value; remove stale or
   unrelated context before adding prohibitions.
3. Compare every requested output property with the actual tool schema and every
   validator rejection.
4. Verify that local repair receives the original contract, rejected result, and
   exact issues only. It must not become a second task definition.
5. For an unsealed text package, expose ordinary invocation-local file read,
   create, and exact-edit operations. Preserve every unchanged file
   mechanically instead of asking the model to regenerate the complete package.
6. Trace the accepted result into publication and the downstream consumer. The
   consumer must not require information that the call was never asked to supply.
7. Search sibling prompt pages and validators for older versions of the same
   rule. Resolve contradictions by ownership and delete stale text.
8. When model behavior appears irrational, audit the actual prompt snapshot and
   data projection before adding a runtime gate or another negative instruction.

The audit fails when two active surfaces disagree, even if a model occasionally
chooses the intended interpretation. A passing schema check proves shape only;
it does not prove prompt, validation, and consumer semantics are aligned.

Review questions:

- Does the instruction explain the stage's real purpose?
- Does the model receive every authority needed to produce the requested output?
- Is unrelated or stale context absent?
- Does the output request exactly match the validator?
- Does each requirement have one owner, with no contradictory restatement in a
  sibling prompt, validator, repair page, or consumer?
- Does every validator rejection correspond to an instruction and input visible
  in the final assembled prompt?
- Does the repair prompt preserve the same responsibility instead of defining a
  stricter, weaker, or different task?
- Is every deterministic route rejection precondition stated in model-visible skill or tool instructions?
- When a route needs exact multiline text, is the stored source directly copyable rather than visible only as escaped or truncated JSON?
- Can the downstream consumer use the accepted result without reconstructing transport?
- Is a format failure repaired inside the same stage?
- If publication creates a new immutable identity, which prior dependencies become stale?
- Does a lineage rejection expose both the requested ref and the refs actually implemented or evidenced?
- Does the actionable failure remain visible through evidence inspection and the next capability selection until a repairing formal result is published and read back?
- Is a semantic failure returned to the owning workflow rather than hidden by Python?
- Does every failure instruction map to an existing executable exit: a host-supported workflow result, an exposed control action, or publication of the formal result? Plain-text advice to "report a gap" is not an interface by itself.

Each call may use a different prompt template. All calls still use the common C0-C6 lifecycle.

## 7. Skill-local workflow and routes

A fixed workflow is valid inside one skill when all stages jointly complete that skill's responsibility. It may reveal information gradually, call multiple LLM stages, use deterministic routes, validate intermediate output, and make bounded local repairs.

A route must have:

- one explicit callable interface;
- deterministic or clearly bounded behavior;
- an owning domain/package;
- no planner authority;
- no access to unrelated artifacts or private values;
- tests independent of the production planner.

Do not duplicate route logic in prompt prose and Python. The prompt should describe when and why to use the route; the package owns the executable behavior.

Developer alignment review must resolve an exact route name from SKILL.md to its `Route(name=...)` source before judging route parameters, handler behavior, or failure handling. Missing route source is an evidence gap in the review, not automatically a production-skill defect.

## 8. Workflow entrypoint contract

When present, `workflow.py` must expose:

Developer review packets must include the exact called route's defining function or class before optional neighboring context. Never diagnose missing behavior from a packet that truncated the executable owner.

```python
def run(payload, runtime):
    ...
```

Use runtime APIs rather than reaching into common private state. Every `runtime.generate_json(...)` call must declare a stable `purpose` and an object `schema`. Multiple calls must explicitly carry only the needed C5/C3/C4 state.

Publish formal output only after deterministic or LLM-owned validation appropriate to the responsibility. Read back the exact published artifact before completion.

## 9. Dynamic workflow rules

- The production coordinator chooses the next skill from current plan and formal state.
- The plan describes work units and evidence, not action IDs.
- A skill output must not contain `next_skill`, `next_action`, or an action allowlist.
- A fixed internal sequence stays inside the selected skill.
- Replan is for a changed or blocked route, not artifact aliases or transport repair.
- Domain scientific routing remains with the responsible LLM.

## 10. Validation ladder

1. Structural validator.
2. Summary-only positive/negative trigger evaluation.
3. Prompt/output/validator/publication/consumer alignment review.
4. Syntax and focused route/workflow tests.
5. Producer-to-consumer boundary replay using stored refs.
6. Small real-model skill test from a clean source snapshot.
7. Broader workflow test.

A segmented test proves only that segment. Report the earliest remaining failing boundary and what is still unproven.

Each model-backed developer evaluation stores the exact source snapshot and raw prompt/response as C6 diagnostic material. Evaluators never read a prior run's report as semantic input. A candidate revision is compared against the same cases and boundary evidence; changing cases merely to make a score pass invalidates the comparison.

## 11. Third-party submission checklist

A third-party skill is not ready until:

- its folder name and frontmatter name match;
- its summary explains output, prerequisites, and boundary;
- it has two positive and two negative trigger cases and passes summary-only selection evaluation;
- all inputs have explicit authorities;
- every output/intermediate has one C0-C6 class;
- every LLM stage has aligned instructions, output shape, validator, and local repair;
- any workflow uses the required entrypoint;
- any route has an explicit callable interface and owning boundary;
- it does not modify public schemas or common runtime without approval;
- it has deterministic evidence and a realistic forward-test plan;
- its prompt/output/validator/publication chain has been reviewed from actual source, not only prose;
- it introduces no final-KPI leakage, demo fallback, or hidden next-action control.

## 12. Rejection conditions

Stop and request redesign or user approval when:

- ownership is ambiguous;
- a schema, artifact kind, persisted field, enum, or common capability must change;
- the proposal duplicates an existing authority;
- data would cross a child/review/private boundary without explicit refs;
- the validator asks for information the prompt does not supply;
- raw C6 logs would become semantic input;
- a domain-specific condition would be added to common;
- a route is being disguised as a production skill, or vice versa.
