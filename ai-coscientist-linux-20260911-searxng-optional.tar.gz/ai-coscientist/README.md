# Pure Python Dynamic Scientific Workflow

This worktree replaces the OpenCode runtime in
`../opencode-dynamic-full-workflow` with a project-owned pure Python common
agent. The scientific skills and their artifact contracts remain project-local;
the common runtime does not absorb their domain logic.

## Reference boundary

| Reference | Used for | Not used for |
|---|---|---|
| `../opencode-dynamic-full-workflow` | Coordinator behavior, eight skill boundaries, artifact and route behavior | Runtime dependency |
| `../final-kpi-route-evolver-rewrite` | Proven Python helpers and failure evidence | Direct import or wholesale copy |

## Target mapping

| OpenCode responsibility | Pure Python owner |
|---|---|
| Primary coordinator loop | `CommonAgent` |
| Initial plan, status maintenance, and explicit replanning | Private bounded `write_plan` calls in `CommonAgent`; normal rounds only receive the `replan` control action || Native skill discovery/load | `SkillCatalog` |
| Tool calling | `RouteRegistry` |
| Formal artifact board | `ArtifactStore` |
| Recent native tool turns and LLM compaction | `MemoryStore` and prompt renderer |
| Run transcript | append-only diagnostic event log |
| Closure invocation | agent-local evaluator route |

The common agent dynamically chooses a skill from summary cards. Full
`SKILL.md` content is loaded only after selection. Once selected, that skill
owns its local workflow and any task-specific executable input/output
requirements.

## Development order

1. Reproduce OpenCode's observable coordinator behavior with fake skills and
   fake artifact kinds.
2. Port the eight project-local skills without moving their domain contracts
   into common prompts.
3. Port deterministic scientific routes to Python.
4. Run deterministic boundary tests, then segmented real-model tests, then one
   complete workflow.

Run the deterministic tests with:

```powershell
$env:PYTHONPATH = (Resolve-Path .\src)
python -m unittest discover -s tests -v
```

## Clean Linux execution

The interactive Linux entry point is `scripts/run_scientific_chat_linux.sh`.
It delegates directly to the production CLI: discuss first, then let the
system formulate a research task. A goal file and historical-data file are
not required to enter chat. Reusing `--output` resumes the same conversation.

After installing Python 3.12 and the project dependencies:

```bash
python3.12 -m pip install -e .
./scripts/run_scientific_chat_linux.sh \
  --output ./runs/my-first-chat \
  --config ./config_deepseek_v4_flash.cfg \
  --source-root /data/my-scientific-task
```

The default scientific environment is `ai-coscientist-native-science:py312-v2`.
Managed Routes may require additional exact runtime identities. See
[Linux deployment](docs/linux_deployment_zh-TW.md) for image transfer, Route
runtime arguments, PDF browser dependencies and clean-release commands.

Run `python3.12 scripts/check_linux_deployment.py` before starting research.
It checks released file hashes, Python dependencies, the CLI parser, Docker
and the production PDF renderer without calling an LLM or creating a task.

Create an archive with `scripts/package_linux_release.py --output PATH.tar.gz`.
It packages current production files, including untracked source, and excludes
old run artifacts, caches and Windows scripts. SHA256SUMS identifies exact
released bytes. Commit the release sources as well for recoverability.

The older `run_scientific_workflow_linux.sh` remains a batch entry for an
already specified goal and historical JSON, with explicit `--resume` support.
It is not the interactive chat entry.


## Plan lifecycle

The private `write_plan` path has three distinct modes:

- initial planning and explicit `replan` rebuild a complete bounded plan from
  current objective, evaluation, artifact state, issues, and capabilities;
- exact artifact readback performs status-only progress maintenance;
- normal production rounds never receive `write_plan` directly.
