# 受管能力目錄

本檔由專案能力登錄器自動產生，請勿手動編輯。

- `active`：已核准，會由 `active.json` 提供給一般研究流程。
- `approved`：已核准但目前未被選為生效版本。
- `pending`：尚未核准；只有某次任務明確持有完全相符的 `capability_candidate` artifact 時，才能在該任務內帶 lineage 使用。

| 種類 | 套件 | 狀態 | 對外名稱 | 套件 hash | 基底 hash | 來源 | 人類核准者 | 實體位置 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Route 套件 | dft-route-package | active | dft_single_point_energy, dft_conformer_geometry_optimization | cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d | - | task_authored | project-owner | routes/approved/dft-route-package/cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d |
| Route 套件 | ase-gpaw-periodic-dft | pending | gpaw_periodic_single_point_energy, gpaw_periodic_geometry_relaxation | 0c1644cf5d63a0261a1238f84bf684b55a7ca760b8a9c3a974bb4bf503abd30b | - | task_authored | - | routes/pending/ase-gpaw-periodic-dft/0c1644cf5d63a0261a1238f84bf684b55a7ca760b8a9c3a974bb4bf503abd30b |
| Skill | finite-cluster-adsorption-energy | pending | finite-cluster-adsorption-energy | 498bd77691a544b43894474bd1030f074fc0749028acd9995dd9477187691a1e | - | task_authored | - | skills/pending/finite-cluster-adsorption-energy/498bd77691a544b43894474bd1030f074fc0749028acd9995dd9477187691a1e |
| Skill | finite-cluster-adsorption-energy | pending | finite-cluster-adsorption-energy | 6761d195406f4ee234e2d722b72000a743b3f556f8b647fac46c39f1062a7e88 | - | task_authored | - | skills/pending/finite-cluster-adsorption-energy/6761d195406f4ee234e2d722b72000a743b3f556f8b647fac46c39f1062a7e88 |
| Skill | finite-cluster-adsorption-energy | pending | finite-cluster-adsorption-energy | b12aa130d3708f9d99277781810ae624a1df888875ea624cc1e3a795795acf1f | - | task_authored | - | skills/pending/finite-cluster-adsorption-energy/b12aa130d3708f9d99277781810ae624a1df888875ea624cc1e3a795795acf1f |
| Skill | finite-cluster-adsorption-energy | pending | finite-cluster-adsorption-energy | c89cd28dbf1bddfdd001ed2109cb1dbf2d139939c1f1e221f0aa5a44f6a1276b | - | task_authored | - | skills/pending/finite-cluster-adsorption-energy/c89cd28dbf1bddfdd001ed2109cb1dbf2d139939c1f1e221f0aa5a44f6a1276b |
| Skill | finite-cluster-adsorption-energy | pending | finite-cluster-adsorption-energy | e66aed6f59daab1607e8dfe91ff20e896945721ae8525436d0453b3b1bb3748f | - | task_authored | - | skills/pending/finite-cluster-adsorption-energy/e66aed6f59daab1607e8dfe91ff20e896945721ae8525436d0453b3b1bb3748f |
| Skill | finite-cluster-adsorption-energy | pending | finite-cluster-adsorption-energy | e8a003553325a95507c7694c4862cb18cc2c8e4de98a0c558a97107da317c798 | - | task_authored | - | skills/pending/finite-cluster-adsorption-energy/e8a003553325a95507c7694c4862cb18cc2c8e4de98a0c558a97107da317c798 |
| Skill | finite-cluster-adsorption-energy | pending | finite-cluster-adsorption-energy | eda586d8fef39ac6f5a19d47e68f0745c438112e3279a98eb3e6aa1d957bb7d0 | - | task_authored | - | skills/pending/finite-cluster-adsorption-energy/eda586d8fef39ac6f5a19d47e68f0745c438112e3279a98eb3e6aa1d957bb7d0 |
| Skill | periodic-slab-adsorption-energy | pending | periodic-slab-adsorption-energy | 1719da8df2a39868fc450195cd8f08ed3e5e8ec5a0a230d0a234af8a4e152417 | e9ffe012a8412b09b5055a9d140f71191f6dfc787daed4298ae05c6274f25b14 | experience_evolved | - | skills/pending/periodic-slab-adsorption-energy/1719da8df2a39868fc450195cd8f08ed3e5e8ec5a0a230d0a234af8a4e152417 |
| Skill | periodic-slab-adsorption-energy | pending | periodic-slab-adsorption-energy | 8efd95ffae8948bdb5c4c0733636e7dab8e6776c1f12e118c110324ad42e80cf | 9650cb8310db88e6013e8f7fc53ef5819e96c71844c09a39b0ff9e7115215eb5 | experience_evolved | - | skills/pending/periodic-slab-adsorption-energy/8efd95ffae8948bdb5c4c0733636e7dab8e6776c1f12e118c110324ad42e80cf |
| Skill | periodic-slab-adsorption-energy | pending | periodic-slab-adsorption-energy | 9650cb8310db88e6013e8f7fc53ef5819e96c71844c09a39b0ff9e7115215eb5 | - | task_authored | - | skills/pending/periodic-slab-adsorption-energy/9650cb8310db88e6013e8f7fc53ef5819e96c71844c09a39b0ff9e7115215eb5 |
| Skill | periodic-slab-adsorption-energy | pending | periodic-slab-adsorption-energy | e9ffe012a8412b09b5055a9d140f71191f6dfc787daed4298ae05c6274f25b14 | 8efd95ffae8948bdb5c4c0733636e7dab8e6776c1f12e118c110324ad42e80cf | experience_evolved | - | skills/pending/periodic-slab-adsorption-energy/e9ffe012a8412b09b5055a9d140f71191f6dfc787daed4298ae05c6274f25b14 |

全域核准能力以 `active.json` 為權威；任務內 pending 能力的權威是該任務可見、內容與套件完全相符的 `capability_candidate` artifact。本檔只做人類可讀盤點，不授予執行權。
