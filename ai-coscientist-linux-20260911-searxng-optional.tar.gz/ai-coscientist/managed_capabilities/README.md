# 受管能力

此目錄是專案自行建立或匯入之 Skill 與 Route 的正式保存位置。每個版本以精確
套件 hash 識別，並受獨立審查與人類核准流程管理。

- `routes/` 保存可執行的 Route 套件。
- `skills/` 保存受管的 Skill 套件。
- 每一類能力都分成 `pending/`（待核准）與 `approved/`（已核准）。
- `active.json` 是全域已核准能力的唯一 runtime 權威來源。任務內使用 pending
  能力時，權威是該任務 C2 中與 immutable package 完全相符的
  `capability_candidate` artifact；這不會修改 `active.json`。
- `CAPABILITY_CATALOG.md` 是由登錄器產生、供人查閱的總覽。

執行輸出可以保存收據或歷史 registry 快照，但 `outputs/` 內的內容不是正式能力
來源，也不會因為曾經測通就自動升格。
