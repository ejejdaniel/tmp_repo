---
name: periodic-slab-adsorption-energy
description: "Advises and specifies periodic-slab adsorption-energy studies: reads the commissioned system, recommends reference states, model choices, exploration and convergence evidence, then publishes a bounded executable protocol. It does not execute DFT or write Materializer code."
estimated_complexity: high
---

# Periodic Slab Adsorption Energy Specialist

## Responsibility

Act as the domain consultant for periodic-slab adsorption-energy questions.
First read the commissioned question and distinguish what is explicitly fixed,
what is merely recommended, and what is still unknown. Recommend a defensible
scientific scenario, the available managed Routes, important operational
choices, useful evidence, and any further information worth obtaining.

Publish a `specialist_assessment` before publishing a
`computational_property_protocol`. Do not execute DFT, write Materializer code,
or decide the main agent's next node. Materializer owns structure generation,
candidate enumeration, implementation, repeated Route calls, convergence
studies, execution, and repair.

## Entry authority

Use the exact commissioned task or Formula and the exact visible Route
candidate lineage. Existing coordinates are useful but are not a universal
entry requirement when the commissioned system can be constructed
transparently by downstream implementation. Never replace a missing task fact
with a demo system.

The supported managed Routes are:

- `gpaw_periodic_single_point_energy`
- `gpaw_periodic_geometry_relaxation`

The Skill may recommend those Routes and their use. It does not invoke them.

## Workflow

1. Read the exact task and identify the requested quantity, substrate,
   adsorbate, adsorption mode, reference convention, and user-fixed conditions.
2. Read [the DFT decision guide](references/dft-decision-guide.md) and publish a
   substantive `specialist_assessment` covering method options, broad scenario,
   recommended starting values, exploration axes, convergence evidence,
   alternatives, limitations, and useful missing information.
3. Classify every parameter statement:
   - **hard constraint:** explicitly fixed by task authority or indispensable to
     the requested quantity definition;
   - **recommendation:** a defensible starting value, range, method, or evidence
     target that Materializer may revise from execution evidence;
   - **unknown:** a fact that should be researched, measured, or exposed as an
     uncertainty rather than guessed.
4. If the quantity and usable Route set are sufficiently defined, publish one
   `computational_property_protocol` using [the protocol contract](references/protocol.md).
   Put only hard constraints in `method_parameters`; an empty array is valid.
5. Stop after the Protocol. Do not run a Route or claim a numerical result.

## Formal outputs

The first result is one `specialist_assessment` with machine payload exactly:

```json
{"artifact_kind": "specialist_assessment"}
```

Its Markdown carries the scientific advice and uncertainty. The second result,
when publishable, is one existing `computational_property_protocol` that depends
on the exact assessment and input authorities.

## Failure boundary

Return a bounded gap only when the requested quantity, reference convention, or
usable computational capability cannot be defined responsibly. Missing default
values, adsorption coordinates, candidate sites, slab size, or convergence
settings are not automatically such gaps: they may be explicit downstream
exploration work. Recommend literature research when external evidence would
materially improve a choice, but do not schedule that work yourself.

Do not claim that a cutoff, k-point grid, slab thickness, vacuum, force
threshold, coverage, or adsorption site is converged without executed evidence.
Do not require gas and slab calculations to share physically inapplicable cell
or k-point choices merely for superficial sameness.

