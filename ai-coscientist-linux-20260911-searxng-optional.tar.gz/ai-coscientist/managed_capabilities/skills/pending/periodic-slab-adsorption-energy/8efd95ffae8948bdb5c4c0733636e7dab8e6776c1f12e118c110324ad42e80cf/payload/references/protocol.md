# Periodic Slab Adsorption Energy Protocol Contract

Use the existing `computational_property_protocol` shape exactly; do not add
fields:

```json
{
  "artifact_kind": "computational_property_protocol",
  "protocol_id": "...",
  "version": 1,
  "quantity_id": "...",
  "scientific_definition": "...",
  "required_inputs": [
    {"input_id": "...", "role": "...", "requirements": "..."}
  ],
  "method_parameters": [
    {"name": "...", "value": "...", "unit": "...", "rationale": "..."}
  ],
  "route_bindings": [
    {"route_ref": "pending_route:...", "purpose": "..."}
  ],
  "calculation_steps": [
    {
      "step_id": "...",
      "route_ref": "...",
      "input_roles": ["..."],
      "parameter_names": ["..."],
      "output_id": "..."
    }
  ],
  "result_contract": {
    "output_id": "...",
    "unit": "eV",
    "calculation_expression": "...",
    "interpretation": "..."
  },
  "validity_conditions": ["..."],
  "failure_conditions": ["..."],
  "limitations": ["..."]
}
```

## Authority rules

Use `method_parameters` only for values explicitly fixed by task authority or
indispensable to the requested quantity definition. It may be empty. Do not put
ordinary recommendations, initial guesses, scan ranges, or unverified
convergence settings there. Put those in the assessment and Protocol Markdown.

The machine payload freezes:

- the physical quantity and reference-state arithmetic;
- formal input roles;
- exact managed Route set;
- explicit hard constraints;
- terminal result expression, unit, interpretation, and validity boundary.

The Markdown should summarize the question first, then recommendations,
exploration and convergence evidence, alternatives, limitations, and unresolved
uncertainty. It must not claim numerical execution.

## Formal dataflow

For adsorption energy, define the exact commissioned reference convention. A
common convention is:

`E_ads = E_combined - E_clean_surface - E_isolated_adsorbate`

but dissociation, normalization, fragment references, coadsorption, charge, and
thermal corrections can change the required expression. Follow the task rather
than forcing the common convention.

`calculation_steps` names the formal terminal outputs needed by the result
expression. It does not list every structure candidate, parameter trial,
convergence run, cache operation, or diagnostic that Materializer may perform.
The same bound Route may be invoked repeatedly before selecting the terminal
outputs.

Bind exact available Routes as needed:

- `pending_route:gpaw_periodic_single_point_energy:0c1644cf5d63a0261a1238f84bf684b55a7ca760b8a9c3a974bb4bf503abd30b`
- `pending_route:gpaw_periodic_geometry_relaxation:0c1644cf5d63a0261a1238f84bf684b55a7ca760b8a9c3a974bb4bf503abd30b`

Every `calculation_steps[].input_roles[]` must refer to a declared input role or
an earlier step output. Every `parameter_names[]` entry must refer to a hard
parameter actually present in `method_parameters`. Every step output id must be
unique, and the result expression must use the relevant terminal output ids.

## Scientific boundaries

Fixed-geometry and relaxed-geometry adsorption energies are distinct. State
which quantity is commissioned. Keep combined and clean slab reference models
compatible. Treat isolated-reference boundary conditions according to their
physical role rather than requiring the same slab cell and k-point grid.

Validity and failure conditions may require executed convergence and
comparability evidence, but they must not falsely assert that one untested
setting is already converged. Limitations must name omitted physical effects and
remaining model dependence.

