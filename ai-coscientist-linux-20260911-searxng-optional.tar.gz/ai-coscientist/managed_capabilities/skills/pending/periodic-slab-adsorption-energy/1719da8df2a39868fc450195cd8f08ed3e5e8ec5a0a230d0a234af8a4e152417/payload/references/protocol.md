# Periodic Slab Adsorption Energy Protocol Contract

Use the existing `computational_property_protocol` shape exactly. Do not add
fields. When calling `artifact_publish`, supply this complete object as
`machine_payload`:

```json
{
  "artifact_kind": "computational_property_protocol",
  "quantity_id": "...",
  "scientific_definition": "...",
  "required_inputs": [
    {
      "input_id": "...",
      "requirements": "..."
    }
  ],
  "result_contract": {
    "output_id": "...",
    "unit": "...",
    "calculation_expression": "...",
    "interpretation": "..."
  }
}
```

Every string must be non-empty. `required_inputs` is required but may be `[]`.
Each `input_id` must be unique.

## Field authority

- `quantity_id`: use the exact identifier supplied by the commissioned Formula
  or task when one exists.
- `scientific_definition`: define the physical quantity, reference convention,
  sign convention, normalization, and scientific boundary.
- `required_inputs`: list only separately supplied formal Artifacts that are
  indispensable to the calculation. Do not list values, structures, candidate
  configurations, or settings that Materializer can construct or explore from
  the task, Formula, visible Routes, and executable implementation.
- `result_contract`: define the output identity, unit, reference arithmetic,
  and interpretation. Its `calculation_expression` must be explicit enough for
  Materializer to implement and test without inventing a different quantity.

Do not put Routes, code steps, method parameters, convergence settings,
validity claims, failure conditions, or limitations into the machine payload.
Put those recommendations and uncertainties in the assessment Markdown. They
guide Materializer but do not precompile its workflow.

## Adsorption-energy boundary

Use the exact commissioned reference convention. A common convention is:

`E_ads = E_combined - E_clean_surface - E_isolated_adsorbate`

Dissociation, normalization, fragment references, coadsorption, charge, and
thermal corrections can change this expression. Follow the task rather than
forcing the common convention.

Combined and clean slab references normally require compatible substrate
models and numerical precision. An isolated adsorbate may need different cell
and k-point treatment to represent isolation. Describe these recommendations,
their evidence needs, and remaining limitations in Markdown; do not claim they
have already been executed.
