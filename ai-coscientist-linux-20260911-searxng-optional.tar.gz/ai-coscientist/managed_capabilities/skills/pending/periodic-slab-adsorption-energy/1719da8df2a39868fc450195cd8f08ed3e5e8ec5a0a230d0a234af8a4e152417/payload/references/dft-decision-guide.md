# Periodic Adsorption DFT Decision Guide

Use this page while authoring the specialist assessment. It guides scientific
judgment; it is not a fixed workflow for Materializer.

## Read the question first

State the requested observable before choosing settings. Distinguish molecular
adsorption, dissociative adsorption, reaction energy, activation barrier,
coverage study, site preference, and parameter sensitivity. They are not
interchangeable quantities.

Identify user-fixed facts separately from defaults. Examples include facet,
adsorption mode, charge state, temperature correction, coverage, or a required
electronic-structure method. Do not promote an unverified default into task
authority.

## Give recommendations at the right resolution

Recommend a broad physical model and an executable starting point. Explain why
the selected Routes can represent it and which choices may materially change
the answer. At minimum consider, when relevant:

- reference-state arithmetic and normalization per adsorbate;
- plausible adsorption sites, orientations, and dissociation products;
- surface-cell size and coverage or lateral interactions;
- slab thickness, fixed versus relaxed layers, vacuum, and dipole treatment;
- k-point density, basis or plane-wave cutoff, SCF and force convergence;
- spin, charge, smearing, exchange-correlation model, and dispersion treatment;
- whether zero-point, thermal, solvation, field, or kinetic-barrier effects are
  inside or outside the commissioned quantity.

For each important item, separate:

- recommended starting choice;
- comparison or convergence evidence that should be collected;
- expected failure signal;
- alternative if the first choice is inadequate.

The purpose is to help Materializer design an auditable project, not to list
every possible parameter.

## Reference-state consistency

The combined and clean slab states normally need compatible surface cells,
substrate models, electronic-structure conventions, and numerical precision.
An isolated adsorbate may require a different cell and k-point treatment to
represent isolation. Consistency means that the energy subtraction is
scientifically controlled, not that every input value is textually identical.

## Evidence and uncertainty

Never call a setting converged merely because it is common. Say whether the
value is a starting recommendation or supported by supplied evidence. If the
available budget cannot complete every study, prioritize the choices most
likely to change the scientific conclusion and state which uncertainties remain.

If literature, prior calculations, or experiment would materially constrain a
choice, name the specific question to investigate. The main agent decides
whether to commission that research.

