---
name: periodic-slab-adsorption-energy
description: "Produces a periodic slab adsorption energy protocol (E_ads = E_slab+adsorbate - E_slab - E_adsorbate, eV) with fixed- and relaxed-geometry variants. Requires slab+adsorbate, clean slab, and isolated adsorbate reference states with comparable DFT settings. Boundary: defines the protocol only; does not execute GPAW or write Materializer code."
estimated_complexity: medium
---

# Periodic Slab Adsorption Energy Protocol Skill

## Responsibility and boundary

This Skill's single production responsibility is to define a reusable, scientifically
valid periodic slab adsorption energy protocol: the reference states, the shared
DFT settings that make the three energies comparable, the fixed- versus
relaxed-geometry variants, the calculation steps, validity, failure, and
limitations. Its formal result is the existing `computational_property_protocol`
artifact.

It must not absorb adjacent work: it does not execute GPAW, does not run the
bound Routes itself, does not write Materializer assembly code, does not repair
implementation defects in Materializer programs, and does not replace or
impersonate the existing `finite-cluster-adsorption-energy` Skill. The Skill owns
the scientific reference-state arithmetic and protocol definition; Materializer
owns writing the assembly program, calling the Routes, executing, reading back,
and repairing implementation defects.

## Entry conditions and authority

This Skill may run only when the following are present:

- A task authority requesting a periodic slab adsorption energy protocol for a
  specific slab+adsorbate system, clean slab, and isolated adsorbate reference
  state.
- The exact pending Route package `ase-gpaw-periodic-dft`
  (`0c1644cf5d63a0261a1238f84bf684b55a7ca760b8a9c3a974bb4bf503abd30b`) is part of
  the task input lineage, providing the two managed Route dependencies:
  - `gpaw_periodic_single_point_energy`
  - `gpaw_periodic_geometry_relaxation`
- The three reference structures (combined system, clean slab, isolated
  adsorbate) are supplied or derivable with explicit coordinates, cell, and
  settings.

Missing authority must not be replaced with a demo or guessed input. If the
pending Route package or any reference state is absent, the Skill returns a
bounded gap to its parent rather than fabricating a protocol.

## Trigger examples

### Should select

- "Define a periodic slab adsorption energy protocol for CO on a Pt(111) slab,
  with the pending ase-gpaw-periodic-dft Routes available, using PBE, a 400 eV
  cutoff, and a 4x4x1 k-point grid."
- "Produce a computational_property_protocol for the relaxed-geometry adsorption
  energy of H2O on a TiO2(110) slab, binding the supplied single-point and
  geometry-relaxation Routes."

### Should not select

- "Run the GPAW single-point calculation for the clean slab now and return the
  energy" (execution is Materializer's responsibility, not this Skill's).
- "Define the adsorption energy for a finite molecular cluster without periodic
  boundary conditions" (that is the existing `finite-cluster-adsorption-energy`
  Skill's responsibility).
- "Write the Materializer assembly program that calls the Routes" (Materializer
  owns implementation).
- "Define the protocol before the pending ase-gpaw-periodic-dft Route package is
  supplied" (the prerequisite Route lineage is absent).

## Prompt and memory projection

- **C0:** fixed task authority (the protocol request), the evaluation boundary
  (protocol definition only, no execution), the constitution (this Skill's
  responsibility and boundary), and explicit user constraints (system, reference
  states, DFT settings, variant).
- **C1:** its current node (`skill-creation`), the bounded work unit (author one
  protocol), and current control state (drafting, validating, repairing).
- **C2:** exact accepted formal inputs (the three reference structures and shared
  settings) and the formal result it publishes (the
  `computational_property_protocol` artifact).
- **C3:** bounded, compressible observations useful to its work (system identity,
  variant choice, shared settings, reference-state roles).
- **C4:** large source data, code, or results retained behind exact refs (the
  pending Route package ref and any supplied structure files).
- **C5:** only its current skill-local draft, validator issue, and bounded repair
  continuity; cleared when the invocation ends.
- **C6:** raw prompts, model turns, tool logs, and failures retained for audit
  only and never used as normal semantic input.

### LLM call contracts

This Skill makes one LLM call: authoring the `computational_property_protocol`
from the supplied reference states and settings. Its projected authority is the
task authority plus the exact pending Route lineage. Its output shape is the
protocol JSON defined in [protocol details](references/protocol.md). Validation
checks structural joins (roles, parameter names, step output ids, derived
calculation expression) and scientific comparability. Bounded local repair fixes
protocol-internal inconsistencies only. The downstream consumer is Materializer,
which reads the exact result ref to write and run the assembly program. No
parallel memory system is invented.

## Skill-local workflow

1. Confirm the pending Route package and both managed Route dependencies are in
   the task lineage; otherwise return a bounded gap.
2. Identify the three reference states: combined system (slab+adsorbate), clean
   slab, and isolated adsorbate, each with explicit coordinates, cell, and PBC.
3. Fix the shared DFT settings that make the three energies comparable: XC
   functional, PAW setups, plane-wave cutoff, cell, k-points, spin, smearing, and
   SCF convergence. These must be identical across all three reference states.
4. Select the protocol variant: fixed-geometry or relaxed-geometry. These are
   distinct physical quantities and must not be mixed.
5. For the fixed-geometry variant, bind `gpaw_periodic_single_point_energy` for
   all three reference states at the fixed geometry.
6. For the relaxed-geometry variant, bind `gpaw_periodic_geometry_relaxation`
   first for each reference state, then bind `gpaw_periodic_single_point_energy`
   at the relaxed geometry to obtain consistent reference energies.
7. Assemble the `computational_property_protocol` with the exact protocol shape
   and joins defined in [protocol details](references/protocol.md).
8. Validate the protocol structurally and scientifically; repair bounded
   protocol-internal issues only.
9. Publish the protocol as the formal result. Do not execute any Route and do
   not write Materializer code.

## Formal output and handoff

This Skill's formal result is the existing `computational_property_protocol`
artifact. The full protocol shape and field guidance are in
[protocol details](references/protocol.md). The consumer is Materializer, which
reads the exact result ref to write the assembly program, call the Routes,
execute, read back, and repair implementation defects. The Skill does not expose
its own numerical result and does not claim to execute the bound Routes; actual
invocation is controlled by each Route's `visible_to_skill_ids`,
`agent_callable`, and `code_callable` settings.

## Failure and repair

- **Missing input:** if the pending Route package, a reference state, or the
  shared settings are absent, return a bounded gap to the parent; do not
  fabricate a protocol.
- **Execution failure:** the Skill does not execute Routes; any Route failure,
  non-convergence, or incomparable reference settings reported by Materializer
  makes the overall protocol fail explicitly rather than producing a partial or
  fabricated result.
- **Validation failure:** if the protocol fails structural or scientific
  validation, perform bounded local repair of protocol-internal inconsistencies
  only; if the defect is in the Route package or Materializer implementation,
  fail to the parent rather than repairing outside this Skill's boundary.
- The Skill never fabricates completion; it fails to its parent when it cannot
  produce a valid, comparable protocol.

## Validation evidence

- **Structural tests:** verify the protocol JSON matches the exact
  `computational_property_protocol` shape, all roles/parameter names/step output
  ids join exactly, and the derived `calculation_expression` names the step
  output ids exactly.
- **Deterministic boundary replay:** replay the protocol assembly with fixed
  inputs to confirm the same protocol is produced and the fixed- versus
  relaxed-geometry variants remain distinct.
- **Smallest honest real case:** a single small periodic slab+adsorbate system
  (e.g., H on a small metal slab) with the pending Routes, confirming the three
  reference energies are comparable and the protocol is executable by
  Materializer. Package creation alone is not production evidence.
