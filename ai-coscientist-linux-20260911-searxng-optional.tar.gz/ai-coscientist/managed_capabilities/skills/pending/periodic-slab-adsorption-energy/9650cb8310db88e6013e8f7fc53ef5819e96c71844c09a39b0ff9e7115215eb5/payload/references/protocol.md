# Periodic Slab Adsorption Energy Protocol Details

This page defines the full `computational_property_protocol` shape and field
guidance for the periodic slab adsorption energy Skill. The root `SKILL.md`
reveals this page via [protocol details](protocol.md).

## Public protocol shape

Use exactly this shape; do not add fields:

```json
{
  "artifact_kind": "computational_property_protocol",
  "protocol_id": "...",
  "version": 1,
  "quantity_id": "...",
  "scientific_definition": "...",
  "required_inputs": [
    {"input_id": "...", "role": "...", "requirements": "..."}
  ],
  "method_parameters": [
    {"name": "...", "value": "...", "unit": "...", "rationale": "..."}
  ],
  "route_bindings": [
    {"route_ref": "pending_route:...", "purpose": "..."}
  ],
  "calculation_steps": [
    {
      "step_id": "...",
      "route_ref": "...",
      "input_roles": ["..."],
      "parameter_names": ["..."],
      "output_id": "..."
    }
  ],
  "result_contract": {
    "output_id": "...",
    "unit": "eV",
    "calculation_expression": "...",
    "interpretation": "..."
  },
  "validity_conditions": ["..."],
  "failure_conditions": ["..."],
  "limitations": ["..."]
}
```

## Field guidance

- `protocol_id`: a stable identifier for this protocol, e.g.
  `periodic-slab-adsorption-energy-<system>-<variant>`.
- `quantity_id`: the physical quantity, e.g. `adsorption_energy`.
- `scientific_definition`: `E_ads = E_slab+adsorbate - E_slab - E_adsorbate`,
  in eV, where a negative value indicates stabilization.
- `required_inputs`: the three reference states with short machine-identifier
  roles:
  - `slab_adsorbate` (combined system),
  - `clean_slab`,
  - `adsorbate` (isolated adsorbate).
  Each declares its structure requirements (coordinates, cell, PBC).
- `method_parameters`: the shared DFT settings that make the three energies
  comparable: XC functional, PAW setups, plane-wave cutoff, cell, k-points,
  spin, smearing, and SCF convergence. These must be identical across all three
  reference states.
- `route_bindings`: bind the exact pending Routes:
  - `pending_route:gpaw_periodic_single_point_energy:0c1644cf5d63a0261a1238f84bf684b55a7ca760b8a9c3a974bb4bf503abd30b`
  - `pending_route:gpaw_periodic_geometry_relaxation:0c1644cf5d63a0261a1238f84bf684b55a7ca760b8a9c3a974bb4bf503abd30b`
- `calculation_steps`: one step per reference energy. For the fixed-geometry
  variant, all three steps use the single-point Route at the fixed geometry. For
  the relaxed-geometry variant, each reference state first uses the geometry
  relaxation Route, then the single-point Route at the relaxed geometry to obtain
  consistent reference energies.
- `result_contract`: `output_id` is the derived high-level quantity
  `e_ads`; `calculation_expression` explicitly combines the step output ids:
  `E_slab_adsorbate - E_clean_slab - E_adsorbate` (naming the exact step output
  ids). `unit` is `eV`; `interpretation` states that a negative value indicates
  stabilization.

## Exact joins

- each `required_inputs[].role` is a short machine identifier;
- every `calculation_steps[].input_roles[]` exactly matches one declared role;
- every `calculation_steps[].parameter_names[]` exactly matches one declared
  `method_parameters[].name`;
- every step output id is unique; and
- the derived `result_contract.calculation_expression` names the relevant step
  output ids exactly.

## Variants

- **fixed-geometry:** all three reference energies computed at the fixed input
  geometry via the single-point Route.
- **relaxed-geometry:** each reference state is first relaxed via the geometry
  relaxation Route, then its energy is computed via the single-point Route at the
  relaxed geometry. These are distinct physical quantities and must not be mixed
  in one protocol.

## Limitations

- Vacuum layer thickness, slab thickness, and surface area must be large enough
  to avoid spurious interactions.
- k-point sampling, plane-wave cutoff, finite-size effects, dipole correction,
  spin, and convergence must be tested and reported.
- The three reference energies are comparable only if all shared settings are
  identical.
