---
name: finite-cluster-adsorption-energy
description: "Produces an executable computational_property_protocol that defines finite-cluster adsorption energy from combined, substrate, and adsorbate single-point DFT energies. Requires the approved dft_single_point_energy Route and a fully specified fixed-geometry cluster. Boundary: defines the scientific protocol only; Materializer calls the Route, executes, and repairs code."
estimated_complexity: high
---

# Finite-Cluster Adsorption Energy Skill

## Responsibility and boundary

This Skill's single production responsibility is to define and publish an
executable scientific protocol for the finite-cluster adsorption energy. Its
formal product is the existing `computational_property_protocol` artifact, not
an adsorption energy numerical value, not Materializer Python code, and not an
execution result.

This Skill binds the approved catalog Route `dft_single_point_energy` into the
protocol for three reference single-point calculations (combined, substrate,
adsorbate) and defines the derived result contract
`E_ads = E_combined - E_substrate - E_adsorbate`. It owns the scientific
definition, reference states, method parameters, exact Route bindings,
validity, failure, and limitations.

This Skill does **not** implement any quantum-chemistry solver, does **not**
call the DFT Route itself, does **not** write or repair Materializer code, and
does **not** execute or replay any calculation. Direct Route invocation remains
exclusively controlled by the Route's `visible_to_skill_ids`,
`agent_callable`, and `code_callable` settings and is performed only by the
Materializer. This Skill does not relax geometries, does not apply counterpoise
corrections, and does not establish general material ordering.

## Entry conditions and authority

- The active node must name one bounded missing capability (finite-cluster
  adsorption energy) and its expected consumer (the Materializer handoff).
- The approved catalog Route `dft_single_point_energy` must be available with
  the exact route name and package hash below.
- A frozen formula reference and the reference states (combined, substrate,
  adsorbate) must be available or derivable; missing formula, reference state,
  or Route identity is a bounded gap, not a fabricated completion.
- Exact visible artifacts and user-provided source paths may inform the
  package.
- Existing approved Route dependencies use exact name and package hash.

## Trigger examples

### Should select

- A task requests a reusable high-level finite-cluster adsorption energy
  protocol that binds combined/substrate/adsorbate single-point DFT energies
  into a `computational_property_protocol`, and the approved
  `dft_single_point_energy` Route is available.
- A bounded research responsibility with a formal reusable protocol result
  (adsorption energy from combined/substrate/adsorbate single-point energies)
  is required, and no approved Skill owns that responsibility.

### Should not select

- Improve the wording of an existing production Skill from execution history;
  that belongs to skill-optimization.
- Wrap one supplied Python function behind a JSON callable interface; that
  belongs to route-onboarding.

### Should not select (prerequisite absent)

- A request for a finite-cluster adsorption energy protocol when the approved
  `dft_single_point_energy` Route identity is unavailable or the frozen formula
  reference is missing; this is a bounded gap reported to the parent, not a
  fabricated protocol.

## Prompt and memory projection

- **C0:** fixed task authority, evaluation boundary, constitution, and explicit
  user constraints needed by this capability (the finite-cluster adsorption
  energy protocol definition).
- **C1:** its current node, bounded work unit (one protocol definition), and
  current control state.
- **C2:** exact accepted formal inputs (the three reference systems and shared
  method/basis) and the formal result it publishes (the
  `computational_property_protocol` artifact).
- **C3:** bounded, compressible observations useful to its work (reference
  state definitions, sign convention, unit conversion).
- **C4:** large source data, code, or results retained behind exact refs (the
  frozen formula reference and this pending Skill candidate lineage).
- **C5:** only its current skill-local draft, validator issue, and bounded
  repair continuity; clear this when the invocation ends.
- **C6:** raw prompts, model turns, tool logs, and failures retained for audit
  only and never used as normal semantic input.

Each LLM call in this capability's invocation has a bounded purpose: to
instantiate the protocol contract for the finite-cluster adsorption energy,
project the C0-C6 memory layers, and produce the formal
`computational_property_protocol` artifact. No parallel memory system is
invented.

## Approved Route dependency

This Skill binds exactly one approved catalog Route for all per-system DFT
total energies:

- route_name: `dft_single_point_energy`
- package_hash: `cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d`

No quantum-chemistry solver is re-implemented here, and no other hash is
guessed. Binding this Route into the protocol does not grant this Skill
invocation authority; actual Route invocation remains controlled exclusively by
the Route's `visible_to_skill_ids`, `agent_callable`, and `code_callable`
settings and is performed only by the Materializer.

## Physical definition

### Reference states and combination formula

For a finite-cluster model, the adsorption energy is defined as

```text
E_ads = E_combined - E_substrate - E_adsorbate
```

where:

- `E_combined` is the total energy of the combined system (substrate cluster
  plus adsorbate in its adsorbed geometry);
- `E_substrate` is the total energy of the isolated substrate cluster in the
  same geometry it has within the combined system;
- `E_adsorbate` is the total energy of the isolated adsorbate in the same
  geometry it has within the combined system.

### Sign convention

A **negative** `E_ads` corresponds to an exothermic (energetically favorable)
adsorption. A **positive** `E_ads` corresponds to an endothermic (unfavorable)
adsorption. The sign is reported exactly as computed by the formula above; no
sign flip is applied.

### Energy units

All per-system total energies are returned by the DFT Route in **Hartree**
(`total_energy_hartree`). The protocol's derived result `E_ads` is in Hartree
and reported as `adsorption_energy_hartree`. An optional human-readable
conversion to **kJ/mol** is provided as `adsorption_energy_kj_per_mol` using
the exact factor `1 Hartree = 2625.4996394799 kJ/mol`; the Hartree value is
authoritative.

## Cross-system consistency (mandatory)

`method`, `basis`, and the fixed-geometry policy must be identical across the
three reference calculations (combined, substrate, adsorbate). These are the
cross-system consistency requirements:

- `method` (DFT functional, used verbatim);
- `basis` (basis set, used verbatim);
- geometry handling level (all three use the same fixed geometry snapshot;
  `geometry_level = fixed`).

`charge` and `spin_multiplicity` must each be explicitly specified for each
system and must be consistent with the chosen reference state. They are **not**
required to be numerically equal across the three systems; each system's charge
and spin multiplicity are set according to its own physical reference state.
The protocol records each system's explicit charge and spin multiplicity and
validates that they are physically consistent with the partitioning, not that
they are identical.

## Inputs

The Skill accepts a single structured request containing:

- `combined`: `elements` (list of atomic symbols), `coordinates` (Cartesian in
  Angstrom), `charge` (integer), `spin_multiplicity` (integer);
- `substrate`: `elements`, `coordinates`, `charge`, `spin_multiplicity`;
- `adsorbate`: `elements`, `coordinates`, `charge`, `spin_multiplicity`;
- `method` (DFT functional name, used verbatim);
- `basis` (basis set name, used verbatim);
- `geometry_level` (must be `fixed` for this Skill; see Geometry relaxation);
- optional `report_units` (default `hartree`; may be `kj_per_mol` to also emit
  the converted value).

All three systems must be fully specified. Missing or empty fields are a
failure.

## Skill-local workflow

```text
accept the single structured request (combined, substrate, adsorbate, method,
basis, geometry_level, optional report_units)
-> validate the three reference states are complete and cross-system consistent
   (identical method, basis, geometry_level=fixed; explicit per-system charge
   and spin multiplicity)
-> bind the approved dft_single_point_energy Route into the protocol
-> instantiate the computational_property_protocol artifact with exactly three
   calculation steps (combined, substrate, adsorbate) and the derived result
   contract E_ads = E_combined - E_substrate - E_adsorbate
-> publish the protocol artifact for the Materializer handoff
```

The workflow does not author, validate, seal, or publish any pending Skill
package, does not return `capability_candidate`, and never writes `active.json`.
It does not call the DFT Route, does not write Materializer code, and does not
produce an adsorption energy numerical value. Its single production result is
the `computational_property_protocol` artifact.

## Formal output and handoff

On success the Skill publishes a single formal result: the existing
`computational_property_protocol` artifact. The full protocol shape and field
guidance are in [protocol details](references/protocol.md). The protocol
contains exactly three `dft_single_point_energy` calculation steps (combined,
substrate, adsorbate) with the verbatim `method` and `basis`, the per-system
`elements`, `coordinates`, `charge`, and `spin_multiplicity`, and the derived
result contract `E_ads = E_combined - E_substrate - E_adsorbate`.

The protocol's `route_bindings` reference the exact approved Route
`approved_route:dft_single_point_energy:cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d`.
The protocol's dependencies include the frozen formula reference and this
pending Skill candidate lineage.

The Materializer is the only consumer authorized to read the protocol, write
code, call the three DFT Route invocations, execute, and repair. The Skill
itself never executes the DFT capability and never exposes its own numerical
result.

## Failure and repair

Missing authority or an unclear capability boundary fails to the parent. An
invalid manifest, path, dependency, or Skill structure receives at most one
same-stage complete-draft repair using the exact packaging or validator error.
If the second submission is still invalid, it fails to the parent and no
invalid pending package is sealed. The registry contract is never weakened.

The Skill **fails explicitly** and returns a bounded gap (no protocol) when any
of the following holds:

- the frozen formula reference is missing or not exact;
- any reference state (combined, substrate, or adsorbate) is incomplete
  (missing elements, coordinates, charge, spin multiplicity, method, basis, or
  geometry_level);
- the `method`, `basis`, or `geometry_level` settings are not identical across
  the three systems (incomparable settings);
- `geometry_level` is not `fixed`;
- the exact Route identity (`dft_single_point_energy` with its package hash) is
  unavailable.

In every such case the Skill returns an explicit bounded-gap result with a
reason and **never** fills in a default value, substitutes a different
method/basis, guesses a Route identity, or fabricates a protocol.

## Validation evidence

Structural tests validate the protocol shape, the exact joins between
`required_inputs[].role`, `calculation_steps[].input_roles[]`, and
`method_parameters[].name`, the uniqueness of step output ids, and the derived
`result_contract.calculation_expression` naming the step output ids exactly.
Deterministic boundary replay checks the cross-system consistency rules and the
bounded-gap failure behavior. The smallest honest real-model case is the
H-on-H2 connectivity case below, which exercises the protocol contract, the
approved DFT Route, and the downstream Materializer handoff end to end.
Candidate creation alone does not prove that the new Skill works; the true
pass condition is verified by a later independent real LLM checkpoint in which
the Common Agent obtains this Skill's formal protocol and the Materializer
writes code, calls the three DFT Routes, executes/repairs, and publishes a
quantitative materialization result.

## Applicability boundaries

- **Finite-cluster approximation:** results are valid only for the specific
  finite cluster supplied; they are not periodic-surface values and must not be
  extrapolated to an infinite surface.
- **Basis-set superposition error (BSSE):** the raw `E_ads` above does not
  include a counterpoise correction. BSSE is a known source of error for
  finite-cluster adsorption energies; the protocol reports the uncorrected
  value and flags that a counterpoise correction is out of scope.
- **Geometry relaxation:** this Skill accepts only a fixed geometry snapshot
  (`geometry_level = fixed`). It does not relax geometries. Geometry relaxation
  is out of scope; a relaxed adsorption energy requires a different capability.
- **Single-point only:** no vibrational, zero-point, or thermal corrections are
  included.
- **No ranking claims:** the Skill does not establish general material
  ordering; it defines one adsorption energy protocol for one supplied cluster.

## H-on-H2 finite-cluster integration case (connectivity proof only)

A small H-on-H2 finite-cluster case is provided as a low-cost integration test.
It exercises the Skill contract, the approved DFT Route, and the downstream
Materializer handoff end to end. The case is a **connectivity proof only**: it
shows that the Skill contract, the existing DFT Route, and the downstream
handoff can be joined. It does **not** represent real surface adsorption
accuracy and must **not** be used to form any general material ranking.

### Case definition

- Substrate: H2 molecule (two hydrogen atoms) as the finite cluster.
- Adsorbate: a single hydrogen atom H.
- Combined: H3 (the H atom placed near the H2 cluster).
- All three systems use the same `method`, `basis`, and fixed geometry
  snapshot. Each system's `charge` and `spin_multiplicity` are set explicitly
  according to its own reference state.
- `E_ads = E_combined - E_substrate - E_adsorbate` in Hartree.

### Usage

1. Supply the three systems (H3, H2, H) with their elements, coordinates,
   charge, spin multiplicity, and a shared `method`/`basis`.
2. The Skill publishes the `computational_property_protocol` with three
   `dft_single_point_energy` calculation steps.
3. The Materializer reads the protocol, writes code, and executes the three
   DFT Route calls.
4. The Materializer combines the three total energies per the formula and
   publishes a quantitative materialization result.

### Non-claims

This case is **not** evidence of surface adsorption accuracy, does not
represent any real surface, and must not be used to rank materials. It only
demonstrates that the Skill contract, the approved DFT Route, and the
downstream handoff can be connected.
