---
name: finite-cluster-adsorption-energy
description: "Produces the computational_property_protocol for finite-cluster adsorption energy from combined/substrate/adsorbate dft_single_point_energy single-point energies and the derived E_ads result contract. Requires the approved dft_single_point_energy Route and a fixed-geometry cluster. Boundary: defines the protocol only; Materializer alone calls the Route and executes code."
estimated_complexity: high
---

# Finite-Cluster Adsorption Energy Skill

## Responsibility and boundary

This Skill's single production responsibility is to define and publish the
**executable scientific protocol** for a finite-cluster adsorption energy as an
existing `computational_property_protocol` artifact. The protocol fixes the
scientific definition, the three reference single-point calculations, the
method/basis/fixed-geometry policy, the charge and spin-multiplicity reference
states, the exact Route bindings, the derived `E_ads` result contract, validity,
failure, and limitations.

This Skill does **not** produce an adsorption energy number, does **not** write
Materializer Python code, and does **not** execute any DFT calculation. All
per-system total energies are obtained by the approved catalog Route
`dft_single_point_energy` (exact route name and package hash below). The
Materializer is the only consumer authorized to call that Route, write the
implementation, execute it, and repair the code. This Skill binds the Route into
the protocol but never invokes it.

This Skill does not relax geometries, does not apply counterpoise corrections,
and does not establish general material ordering. It defines one adsorption
energy protocol for one supplied fixed-geometry cluster.

## Entry conditions and authority

- The active node must name one bounded missing capability (finite-cluster
  adsorption energy protocol) and its expected consumer (the Materializer
  handoff).
- The approved catalog Route `dft_single_point_energy` must be available with
  the exact route name and package hash below.
- The frozen formula reference (`E_ads = E_combined - E_substrate -
  E_adsorbate`) and the chosen reference states (charge and spin multiplicity
  per system) must be available. Missing formula, reference state, or Route
  identity is a bounded gap, not a fabricated protocol.
- Exact visible artifacts and user-provided source paths may inform the
  package.
- Existing approved Route dependencies use exact name and package hash.

## Trigger examples

### Should select

- A task requests a reusable high-level finite-cluster adsorption energy
  protocol that binds the approved `dft_single_point_energy` Route for
  combined/substrate/adsorbate single-point energies and a derived `E_ads`
  result contract, and the approved Route is available.
- A bounded research responsibility with a formal reusable
  `computational_property_protocol` result (adsorption energy from
  combined/substrate/adsorbate single-point energies) is required, and no
  approved Skill owns that responsibility.

### Should not select

- A request to actually compute an adsorption energy number or to write and run
  the Materializer implementation; that belongs to the Materializer, which
  alone calls the Route and executes code.
- Improve the wording of an existing production Skill from execution history;
  that belongs to skill-optimization.
- Wrap one supplied Python function behind a JSON callable interface; that
  belongs to route-onboarding.

### Should not select (prerequisite absent)

- A request for a finite-cluster adsorption energy protocol when the approved
  `dft_single_point_energy` Route identity, the frozen formula reference, or
  the reference states are not available; this Skill reports a bounded gap
  rather than guessing.

## Prompt and memory projection

- **C0:** fixed task authority, evaluation boundary, constitution, and explicit
  user constraints needed by this capability (the protocol must be the
  `computational_property_protocol` artifact; Materializer owns execution).
- **C1:** its current node (skill-creation), the bounded work unit (one
  finite-cluster adsorption energy protocol), and current control state.
- **C2:** exact accepted formal inputs (the three reference systems, method,
  basis, fixed-geometry policy, charge and spin-multiplicity reference states)
  and the formal result it publishes (the `computational_property_protocol`).
- **C3:** bounded, compressible observations useful to its work (the frozen
  formula, the Route binding, the consistency policy).
- **C4:** large source data, code, or results retained behind exact refs (the
  pending Skill candidate lineage and the frozen formula reference).
- **C5:** only its current skill-local draft, validator issue, and bounded
  repair continuity; clear this when the invocation ends.
- **C6:** raw prompts, model turns, tool logs, and failures retained for audit
  only and never used as normal semantic input.

Each LLM call in this capability's eventual invocation has a bounded purpose:
selecting the protocol responsibility, projecting the exact inputs and result
contract, validating the protocol structure, and performing at most one bounded
local repair. No parallel memory system is invented.

## Skill-local workflow

```text
author one bounded Skill package (SKILL.md + references/protocol.md)
-> run the project Skill structural validator over the complete draft tree
-> if invalid, repair the complete draft once and run the same validator again
-> seal exact valid files and manifest in pending registry
-> publish capability_candidate
-> read back exact candidate ref
```

The workflow does not execute candidate Python and never writes `active.json`.
It does not call the DFT Route and does not produce an adsorption energy number.

## Formal output and handoff

On success the Skill publishes a single formal result: the existing
`computational_property_protocol` artifact. The full protocol shape and field
guidance are in [protocol details](references/protocol.md). The protocol
includes:

- the scientific definition of finite-cluster adsorption energy;
- three `dft_single_point_energy` reference calculations (combined, substrate,
  adsorbate) with exact Route bindings;
- the derived result contract `E_ads = E_combined - E_substrate - E_adsorbate`;
- the method/basis/fixed-geometry consistency policy;
- explicit per-system charge and spin-multiplicity reference states;
- validity, failure, and limitation conditions.

The protocol's `route_bindings` reference the exact approved Route
`approved_route:dft_single_point_energy:cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d`.
The protocol's dependencies include the frozen formula reference and this
pending Skill candidate lineage. The Materializer is the only consumer that
reads the protocol and is authorized to call the Route, write the
implementation, execute it, and repair the code. This Skill never executes the
DFT capability.

## Failure and repair

Missing authority or an unclear capability boundary fails to the parent. An
invalid manifest, path, dependency, or Skill structure receives at most one
same-stage complete-draft repair using the exact packaging or validator error.
If the second submission is still invalid, it fails to the parent and no invalid
pending package is sealed. The registry contract is never weakened.

The Skill **fails explicitly** and returns a bounded gap (no protocol) when any
of the following holds:

- the frozen formula reference is missing or ambiguous;
- a reference state (per-system charge or spin multiplicity) is missing or
  inconsistent with the chosen reference state;
- the exact Route identity (name and package hash) is unavailable;
- the method, basis, or fixed-geometry policy is not consistent across the
  three reference calculations;
- the geometry level is not `fixed`.

In every such case the Skill returns an explicit bounded-gap result with a
reason and **never** fills in a default value, substitutes a different
method/basis, guesses a Route identity, or fabricates a protocol.

## Validation evidence

Validate the protocol contract against the approved `dft_single_point_energy`
catalog Route (exact route name and package hash), the three-reference
calculation structure, the derived `E_ads` result contract, the
method/basis/fixed-geometry consistency policy, the per-system charge and
spin-multiplicity reference states, the explicit bounded-gap failure behavior,
and the H-on-H2 connectivity case. Candidate creation alone does not prove that
the protocol works; the real pass condition is a later independent LLM
checkpoint in which the Common Agent obtains this protocol and the Materializer
writes, calls the Route three times, executes/repairs, and publishes a
quantitative materialization result.

## Applicability boundaries

- **Finite-cluster approximation:** the protocol is valid only for the specific
  finite cluster supplied; results are not periodic-surface values and must not
  be extrapolated to an infinite surface.
- **Basis-set superposition error (BSSE):** the raw `E_ads` does not include a
  counterpoise correction. BSSE is a known source of error for finite-cluster
  adsorption energies; the protocol reports the uncorrected value and flags that
  a counterpoise correction is out of scope.
- **Geometry relaxation:** the protocol accepts only a fixed geometry snapshot
  (`geometry_level = fixed`). It does not relax geometries. Geometry relaxation
  is out of scope; a relaxed adsorption energy requires a different capability.
- **Single-point only:** no vibrational, zero-point, or thermal corrections are
  included.
- **No ranking claims:** the protocol does not establish general material
  ordering; it defines one adsorption energy for one supplied cluster.
- **Execution boundary:** the protocol binds the Route but does not call it;
  direct Route execution and code writing/repair belong exclusively to the
  Materializer.

## H-on-H2 finite-cluster integration case (connectivity proof only)

A small H-on-H2 finite-cluster case is provided as a low-cost integration test.
It exercises the protocol contract, the approved DFT Route, and the downstream
Materializer handoff end to end. The case is a **connectivity proof only**: it
shows that the protocol, the existing DFT Route, and the downstream handoff can
be joined. It does **not** represent real surface adsorption accuracy and must
**not** be used to form any general material ranking.

### Case definition

- Substrate: H2 molecule (two hydrogen atoms) as the finite cluster.
- Adsorbate: a single hydrogen atom H.
- Combined: H3 (the H atom placed near the H2 cluster).
- All three systems use the same `method`, `basis`, and fixed geometry snapshot.
- Each system has its own explicit charge and spin-multiplicity reference state
  consistent with the chosen reference state; they are not required to be
  numerically identical across the three systems.
- `E_ads = E(H3) - E(H2) - E(H)` in Hartree.

### Usage

1. Supply the three systems (H3, H2, H) with their elements, coordinates,
   per-system charge and spin multiplicity, and a shared `method`/`basis`.
2. The Skill publishes the protocol with three `dft_single_point_energy`
   reference calculations and the derived `E_ads` result contract.
3. The Materializer reads the protocol, writes the implementation, calls the
   Route three times, executes, and repairs the code.
4. The Materializer combines the three total energies per the formula and
   publishes the quantitative materialization result.

### Non-claims

This case is **not** evidence of surface adsorption accuracy, does not represent
any real surface, and must not be used to rank materials. It only demonstrates
that the protocol, the approved DFT Route, and the downstream handoff can be
connected.
