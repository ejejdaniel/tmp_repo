# Finite-Cluster Adsorption Energy Protocol

This page is the full `computational_property_protocol` shape and field guidance
for the finite-cluster adsorption energy capability. The root `SKILL.md` is the
thin entry point; this page is revealed from it via
`[protocol details](references/protocol.md)`.

## Public protocol shape

Use exactly this shape; do not add fields.

```json
{
  "artifact_kind": "computational_property_protocol",
  "protocol_id": "finite-cluster-adsorption-energy",
  "version": 1,
  "quantity_id": "adsorption_energy",
  "scientific_definition": "For a finite-cluster model, the adsorption energy is E_ads = E_combined - E_substrate - E_adsorbate, where each E is the total single-point DFT energy of the combined system, the isolated substrate cluster, and the isolated adsorbate, each in the same fixed geometry it has within the combined system. A negative E_ads is exothermic (favorable); a positive E_ads is endothermic (unfavorable). No sign flip is applied.",
  "required_inputs": [
    {"input_id": "combined", "role": "combined_system", "requirements": "elements, Cartesian coordinates in Angstrom, charge, spin_multiplicity for the combined system (substrate cluster plus adsorbate in its adsorbed geometry)"},
    {"input_id": "substrate", "role": "substrate_system", "requirements": "elements, Cartesian coordinates in Angstrom, charge, spin_multiplicity for the isolated substrate cluster in the same geometry it has within the combined system"},
    {"input_id": "adsorbate", "role": "adsorbate_system", "requirements": "elements, Cartesian coordinates in Angstrom, charge, spin_multiplicity for the isolated adsorbate in the same geometry it has within the combined system"},
    {"input_id": "method", "role": "dft_method", "requirements": "DFT functional name used verbatim, identical across the three reference calculations"},
    {"input_id": "basis", "role": "basis_set", "requirements": "basis set name used verbatim, identical across the three reference calculations"},
    {"input_id": "geometry_level", "role": "geometry_policy", "requirements": "must be 'fixed'; all three systems use the same fixed geometry snapshot"}
  ],
  "method_parameters": [
    {"name": "method", "value": "<verbatim DFT functional>", "unit": "none", "rationale": "DFT functional used identically across combined, substrate, and adsorbate single-point calculations"},
    {"name": "basis", "value": "<verbatim basis set>", "unit": "none", "rationale": "basis set used identically across the three reference calculations"},
    {"name": "geometry_level", "value": "fixed", "unit": "none", "rationale": "all three systems use the same fixed geometry snapshot; no relaxation"},
    {"name": "charge_combined", "value": "<integer>", "unit": "e", "rationale": "total charge of the combined system, set consistently with the chosen reference state"},
    {"name": "spin_multiplicity_combined", "value": "<integer>", "unit": "none", "rationale": "spin multiplicity of the combined system, set consistently with the chosen reference state"},
    {"name": "charge_substrate", "value": "<integer>", "unit": "e", "rationale": "total charge of the isolated substrate, set consistently with the chosen reference state"},
    {"name": "spin_multiplicity_substrate", "value": "<integer>", "unit": "none", "rationale": "spin multiplicity of the isolated substrate, set consistently with the chosen reference state"},
    {"name": "charge_adsorbate", "value": "<integer>", "unit": "e", "rationale": "total charge of the isolated adsorbate, set consistently with the chosen reference state"},
    {"name": "spin_multiplicity_adsorbate", "value": "<integer>", "unit": "none", "rationale": "spin multiplicity of the isolated adsorbate, set consistently with the chosen reference state"}
  ],
  "route_bindings": [
    {"route_ref": "approved_route:dft_single_point_energy:cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d", "purpose": "per-system single-point DFT total energy for each of the three reference systems; bound into the protocol but callable only by the Materializer"}
  ],
  "calculation_steps": [
    {"step_id": "combined_energy", "route_ref": "approved_route:dft_single_point_energy:cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d", "input_roles": ["combined_system", "dft_method", "basis_set", "geometry_policy"], "parameter_names": ["method", "basis", "geometry_level", "charge_combined", "spin_multiplicity_combined"], "output_id": "E_combined"},
    {"step_id": "substrate_energy", "route_ref": "approved_route:dft_single_point_energy:cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d", "input_roles": ["substrate_system", "dft_method", "basis_set", "geometry_policy"], "parameter_names": ["method", "basis", "geometry_level", "charge_substrate", "spin_multiplicity_substrate"], "output_id": "E_substrate"},
    {"step_id": "adsorbate_energy", "route_ref": "approved_route:dft_single_point_energy:cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d", "input_roles": ["adsorbate_system", "dft_method", "basis_set", "geometry_policy"], "parameter_names": ["method", "basis", "geometry_level", "charge_adsorbate", "spin_multiplicity_adsorbate"], "output_id": "E_adsorbate"}
  ],
  "result_contract": {
    "output_id": "adsorption_energy_hartree",
    "unit": "hartree",
    "calculation_expression": "E_ads = E_combined - E_substrate - E_adsorbate",
    "interpretation": "Negative E_ads is exothermic (favorable); positive E_ads is endothermic (unfavorable). The Hartree value is authoritative. An optional human-readable conversion to kJ/mol uses 1 Hartree = 2625.4996394799 kJ/mol."
  },
  "validity_conditions": [
    "method is identical across combined, substrate, and adsorbate",
    "basis is identical across the three reference calculations",
    "geometry_level is 'fixed' and all three systems use the same fixed geometry snapshot",
    "each system's charge and spin multiplicity are explicit and consistent with the chosen reference state",
    "all three dft_single_point_energy calls report scf_converged = true"
  ],
  "failure_conditions": [
    "any of the three dft_single_point_energy calls reports scf_converged = false or otherwise fails",
    "any input is incomplete (missing elements, coordinates, charge, spin multiplicity, method, basis, or geometry_level)",
    "method, basis, or geometry_level is not identical across the three reference calculations",
    "geometry_level is not 'fixed'",
    "a per-system charge or spin multiplicity is missing or inconsistent with the chosen reference state"
  ],
  "limitations": [
    "valid only for the specific finite cluster supplied; not a periodic-surface value and must not be extrapolated to an infinite surface",
    "no counterpoise (BSSE) correction is included",
    "no geometry relaxation; fixed geometry only",
    "no vibrational, zero-point, or thermal corrections",
    "does not establish general material ordering",
    "the protocol binds the Route but does not call it; direct Route execution and code writing/repair belong exclusively to the Materializer"
  ]
}
```

## Field guidance

- `protocol_id` is the exact asset id `finite-cluster-adsorption-energy`.
- `quantity_id` is `adsorption_energy`.
- Each `required_inputs[].role` is a short machine identifier; every
  `calculation_steps[].input_roles[]` exactly matches one declared role.
- Every `calculation_steps[].parameter_names[]` exactly matches one declared
  `method_parameters[].name`.
- Every step output id is unique (`E_combined`, `E_substrate`, `E_adsorbate`).
- The derived `result_contract.calculation_expression` names the step output ids
  exactly: `E_ads = E_combined - E_substrate - E_adsorbate`.
- `result_contract.output_id` is the derived high-level quantity
  `adsorption_energy_hartree`; the calculation expression combines the three
  step output ids. Route calls remain numerical kernels; the Skill owns the
  scientific reference-state arithmetic.
- `route_bindings` and each `route_ref` use the exact approved Route ref
  `approved_route:dft_single_point_energy:cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d`.
- The protocol's published dependencies include the frozen formula reference and
  this pending Skill candidate lineage.
- Charge and spin multiplicity are per-system reference states; they are each
  explicit and consistent with the chosen reference state, and are **not**
  required to be numerically identical across the three systems.
