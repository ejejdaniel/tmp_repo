---
name: finite-cluster-adsorption-energy
description: "Defines and supports finite-cluster adsorption energy calculations: reference states, combination formula, sign convention, energy units, cross-system consistency, inputs/outputs, Materializer handoff, applicability boundaries, and explicit failure behavior, referencing the catalog DFT single-point energy capability."
---

# Finite-Cluster Adsorption Energy

## Responsibility and boundary

This Skill defines the contract for computing an adsorption energy on a finite
cluster model and produces an executable handoff for the Materializer. It does
not implement or re-implement any quantum-chemical solver. All reference
energies are obtained by calling the approved catalog DFT capability
(`dft_single_point_energy`); this Skill never fabricates, substitutes, or
defaults a physical result.

This Skill is a pending candidate. It does not approve, activate, or promote
itself, and it does not modify the active capability registry. Its outputs are
not scientific evidence and must not be used as production evidence until a
human approves the exact candidate version.

## Entry conditions and authority

- The active node must name a bounded finite-cluster adsorption energy
  responsibility and its expected consumer (the Materializer).
- The catalog DFT capability `dft_single_point_energy` must be available as an
  approved Route dependency with an exact package hash.
- The three systems (combined, substrate, adsorbate) must be fully specified
  before any calculation is requested.

## Trigger examples

### Should select

- The task asks to compute the adsorption energy of a hydrogen atom on a small
  finite cluster (e.g., H on H2) using the catalog DFT single-point capability
  and to hand the executable job to the Materializer.
- The task requires a reusable, human-approvable definition of finite-cluster
  adsorption energy with explicit reference states, sign convention, and
  failure behavior, and no approved Skill owns that responsibility.

### Should not select

- The task asks to improve the wording of an existing production adsorption
  Skill from execution history; that belongs to skill-optimization.
- The task asks to wrap a supplied Python function behind a JSON callable
  interface; that belongs to route-onboarding.

## Memory use (C0-C6)

- **C0:** sanitized task, exact authorization, evaluation boundary, and
  constitution.
- **C1:** one current capability-creation node and its explicit dependencies.
- **C2:** exact public requirement or design artifacts used by the candidate.
- **C3:** bounded authoring summary only; it is not candidate authority.
- **C4:** exact package bytes live in the pending registry behind `package_ref`.
- **C5:** one draft and local format repair exist only during this invocation.
- **C6:** raw prompts, model turns, registry receipts, and failures remain
  audit-only.

## Physical model and definitions

### Reference states

For a finite-cluster adsorption energy, the three reference states are:

1. **Combined system** `S`: the adsorbate bound to the substrate cluster at the
   adsorption geometry.
2. **Substrate** `B`: the bare finite cluster at the same geometry it has in
   the combined system (frozen, not re-relaxed).
3. **Adsorbate** `A`: the isolated adsorbate at the same geometry it has in the
   combined system (frozen, not re-relaxed).

All three reference states must be computed with the **same** method, basis,
charge, spin multiplicity, and geometry-handling level (see Consistency).

### Combination formula and sign convention

Adsorption energy is defined as:

```text
E_ads = E(S) - E(B) - E(A)
```

where `E(S)`, `E(B)`, and `E(A)` are the total energies of the combined system,
substrate, and adsorbate, respectively. A negative `E_ads` indicates an
exothermic (favorable) adsorption; a positive value indicates endothermic
(unfavorable) adsorption. This sign convention is fixed and must not be
reversed.

### Energy units

All input and output energies are expressed in **Hartree** (atomic units). The
final `E_ads` is reported in Hartree. If a consumer requires another unit, the
conversion is performed downstream by the Materializer and must be labeled
with the source unit; this Skill always emits Hartree.

## Cross-system consistency (mandatory)

The three reference states must be mutually comparable. The following settings
must be identical across `S`, `B`, and `A`:

- **method** (DFT functional, used verbatim)
- **basis** (basis set name, used verbatim)
- **geometry handling level** (all three use the same frozen geometry taken
  from the combined system; no independent relaxation of `B` or `A`)
- **charge** (total charge of each system as specified)
- **spin multiplicity** (spin multiplicity of each system as specified)

If any of these settings differ between the three systems, the calculation is
not comparable and the Skill must fail explicitly (see Failure behavior).

## Inputs

A complete request must provide, for each of the three systems, a machine-
readable specification:

- `system_id`: one of `combined`, `substrate`, `adsorbate`
- `elements`: list of atomic symbols
- `coordinates_angstrom`: Cartesian coordinates in Angstrom
- `charge`: integer total charge
- `spin_multiplicity`: integer spin multiplicity
- `method`: DFT functional name used verbatim
- `basis`: basis set name used verbatim
- `geometry_level`: must be `frozen` for all three systems

The combined-system geometry is the source of truth; the substrate and
adsorbate coordinates must be extracted from it without re-relaxation.

## Formal output

On success, the Skill emits a structured result:

- `e_combined_hartree`: total energy of the combined system (Hartree)
- `e_substrate_hartree`: total energy of the substrate (Hartree)
- `e_adsorbate_hartree`: total energy of the adsorbate (Hartree)
- `e_ads_hartree`: `E(S) - E(B) - E(A)` (Hartree)
- `sign_convention`: `negative_is_exothermic`
- `units`: `hartree`
- `method_used`, `basis_used`: verbatim method and basis
- `geometry_level`: `frozen`
- `scf_converged`: true for all three reference calculations
- `provenance`: per-system traceable inputs (elements, coordinates, charge,
  spin) and the exact catalog DFT capability reference

## Materializer handoff

This Skill produces an executable handoff for the Materializer: a structured
job that calls the approved catalog DFT capability `dft_single_point_energy`
three times (combined, substrate, adsorbate) with the exact inputs above, then
combines the returned `total_energy_hartree` values into `E_ads`. The handoff
must pass the verbatim method and basis and the exact per-system
charge/spin/geometry to the catalog capability. The Materializer executes the
handoff; this Skill does not execute the DFT solver itself.

## Applicability boundaries

- **Finite-cluster approximation:** results describe a finite cluster, not an
  extended surface. They are not a general material ranking and must not be
extrapolated to surface adsorption accuracy.
- **Basis-set superposition error (BSSE):** the frozen-geometry definition
  above does not include a counterpoise correction. BSSE is a known source of
  error and must be reported as an unquantified limitation unless a
  counterpoise correction is explicitly requested and computed.
- **Geometry relaxation:** the reference states use frozen geometries from the
  combined system. Relaxation of the substrate or adsorbate is out of scope
  for this Skill; if relaxation is required, it must be requested as a
  separate capability.
- **Small-molecule scope:** the catalog DFT capability is validated for small
  molecules; large clusters or periodic systems are out of scope.

## Failure behavior

This Skill must fail explicitly and must never fill in a default value or
fabricate a physical result. Explicit failure occurs when any of the following
holds:

- Any reference calculation does not converge (`scf_converged` is false for
  `S`, `B`, or `A`).
- Any required input is missing or incomplete for any of the three systems.
- The method, basis, charge, spin multiplicity, or geometry level differs
  between the three systems (incomparable settings).
- The catalog DFT capability returns an error or an unsupported method/basis.

On failure, the Skill returns a structured error identifying the failing
system and the reason; it never emits a numeric `E_ads`.

## H-on-H2 finite-cluster integration case

A small H-on-H2 finite-cluster case is provided as a low-cost integration
case. It exercises the Skill contract, the existing catalog DFT capability,
and the downstream Materializer handoff end to end. The case is a
**connectivity proof only**: it demonstrates that the contract, the catalog
DFT capability, and the handoff can be joined. It does **not** represent real
surface adsorption accuracy, and it must **not** be used to form a general
material ranking.

In this case the substrate `B` is the H2 molecule, the adsorbate `A` is a
single H atom, and the combined system `S` is the H3 cluster at the adsorption
geometry. All three systems use the same verbatim method, basis, charge, spin
multiplicity, and frozen geometry level. The three single-point energies are
obtained from the catalog DFT capability and combined as `E_ads = E(S) -
E(B) - E(A)`. The result is reported only as a connectivity check, never as a
surface-accuracy or ranking claim.

## Validation evidence

This Skill validates SKILL.md structure, pending invisibility, exact package
hash, C2 readback, child authorization subset, and one real-model
candidate-authoring case. Candidate creation alone does not prove that the new
Skill works; the H-on-H2 case is a connectivity proof, not a scientific
validation.
