# Computational Property Protocol: Finite-Cluster Adsorption Energy

This page defines the full `computational_property_protocol` artifact shape and
field guidance for the finite-cluster adsorption energy capability. The root
`SKILL.md` is the source of truth for responsibility, boundary, and workflow;
this page carries the detailed protocol schema.

## Protocol shape

```json
{
  "artifact_kind": "computational_property_protocol",
  "protocol_id": "finite-cluster-adsorption-energy",
  "version": 1,
  "quantity_id": "adsorption_energy",
  "scientific_definition": "E_ads = E_combined - E_substrate - E_adsorbate for a finite-cluster model; negative is exothermic.",
  "required_inputs": [
    {"input_id": "combined", "role": "combined_system", "requirements": "elements, coordinates (Angstrom), charge, spin_multiplicity for the combined system in its adsorbed geometry"},
    {"input_id": "substrate", "role": "substrate_system", "requirements": "elements, coordinates (Angstrom), charge, spin_multiplicity for the isolated substrate in the same geometry as in the combined system"},
    {"input_id": "adsorbate", "role": "adsorbate_system", "requirements": "elements, coordinates (Angstrom), charge, spin_multiplicity for the isolated adsorbate in the same geometry as in the combined system"},
    {"input_id": "method", "role": "dft_method", "requirements": "DFT functional name used verbatim"},
    {"input_id": "basis", "role": "basis_set", "requirements": "basis set name used verbatim"},
    {"input_id": "geometry_level", "role": "geometry_policy", "requirements": "must be 'fixed'"}
  ],
  "method_parameters": [
    {"name": "method", "value": "<verbatim functional>", "unit": "none", "rationale": "identical across the three reference calculations"},
    {"name": "basis", "value": "<verbatim basis>", "unit": "none", "rationale": "identical across the three reference calculations"},
    {"name": "geometry_level", "value": "fixed", "unit": "none", "rationale": "fixed geometry snapshot; no relaxation"},
    {"name": "charge_combined", "value": "<integer>", "unit": "e", "rationale": "explicit charge of the combined reference state"},
    {"name": "spin_multiplicity_combined", "value": "<integer>", "unit": "none", "rationale": "explicit spin multiplicity of the combined reference state"},
    {"name": "charge_substrate", "value": "<integer>", "unit": "e", "rationale": "explicit charge of the substrate reference state"},
    {"name": "spin_multiplicity_substrate", "value": "<integer>", "unit": "none", "rationale": "explicit spin multiplicity of the substrate reference state"},
    {"name": "charge_adsorbate", "value": "<integer>", "unit": "e", "rationale": "explicit charge of the adsorbate reference state"},
    {"name": "spin_multiplicity_adsorbate", "value": "<integer>", "unit": "none", "rationale": "explicit spin multiplicity of the adsorbate reference state"}
  ],
  "route_bindings": [
    {"route_ref": "approved_route:dft_single_point_energy:cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d", "purpose": "per-system single-point DFT total energy for combined, substrate, and adsorbate"}
  ],
  "calculation_steps": [
    {
      "step_id": "combined_energy",
      "route_ref": "approved_route:dft_single_point_energy:cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d",
      "input_roles": ["combined_system", "dft_method", "basis_set", "geometry_policy"],
      "parameter_names": ["method", "basis", "geometry_level", "charge_combined", "spin_multiplicity_combined"],
      "output_id": "E_combined"
    },
    {
      "step_id": "substrate_energy",
      "route_ref": "approved_route:dft_single_point_energy:cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d",
      "input_roles": ["substrate_system", "dft_method", "basis_set", "geometry_policy"],
      "parameter_names": ["method", "basis", "geometry_level", "charge_substrate", "spin_multiplicity_substrate"],
      "output_id": "E_substrate"
    },
    {
      "step_id": "adsorbate_energy",
      "route_ref": "approved_route:dft_single_point_energy:cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d",
      "input_roles": ["adsorbate_system", "dft_method", "basis_set", "geometry_policy"],
      "parameter_names": ["method", "basis", "geometry_level", "charge_adsorbate", "spin_multiplicity_adsorbate"],
      "output_id": "E_adsorbate"
    }
  ],
  "result_contract": {
    "output_id": "adsorption_energy_hartree",
    "unit": "hartree",
    "calculation_expression": "E_combined - E_substrate - E_adsorbate",
    "interpretation": "negative is exothermic (favorable); positive is endothermic (unfavorable); no sign flip applied"
  },
  "validity_conditions": [
    "method identical across combined, substrate, adsorbate",
    "basis identical across combined, substrate, adsorbate",
    "geometry_level is 'fixed' for all three systems",
    "each system's charge and spin_multiplicity explicitly specified and consistent with its reference state",
    "all three dft_single_point_energy calls report scf_converged = true"
  ],
  "failure_conditions": [
    "any input incomplete (missing elements, coordinates, charge, spin_multiplicity, method, basis, or geometry_level)",
    "method, basis, or geometry_level not identical across the three systems",
    "geometry_level is not 'fixed'",
    "any dft_single_point_energy call reports scf_converged = false or otherwise fails",
    "frozen formula reference or exact Route identity unavailable"
  ],
  "limitations": [
    "finite-cluster approximation; not periodic-surface values",
    "no counterpoise (BSSE) correction",
    "no geometry relaxation",
    "single-point only; no vibrational, zero-point, or thermal corrections",
    "no general material ordering claims"
  ]
}
```

## Field guidance

- `protocol_id` is the exact asset id `finite-cluster-adsorption-energy`.
- `quantity_id` is `adsorption_energy`.
- Each `required_inputs[].role` is a short machine identifier; every
  `calculation_steps[].input_roles[]` exactly matches one declared role.
- Every `calculation_steps[].parameter_names[]` exactly matches one declared
  `method_parameters[].name`.
- Every step output id (`E_combined`, `E_substrate`, `E_adsorbate`) is unique.
- The derived `result_contract.calculation_expression` names the step output
  ids exactly: `E_combined - E_substrate - E_adsorbate`.
- `result_contract.output_id` is the derived high-level quantity
  `adsorption_energy_hartree`, not a single Route output.
- Route calls remain numerical kernels; the Skill owns the scientific
  reference-state arithmetic.

## Route binding and invocation authority

Binding the exact approved Route
`approved_route:dft_single_point_energy:cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d`
into this protocol fixes identity and compatibility. It does not grant this
Skill invocation authority. Actual Route invocation is controlled exclusively
by the Route's `visible_to_skill_ids`, `agent_callable`, and `code_callable`
settings and is performed only by the Materializer. This Skill must not claim
to execute the Route or expose its own numerical result.

## Dependencies of the published protocol

The published protocol's dependencies include the frozen formula reference
(`E_ads = E_combined - E_substrate - E_adsorbate`) and this pending Skill
candidate lineage. Missing exact formula, reference state, or Route identity is
a bounded gap reported to the parent, not a fabricated protocol.
