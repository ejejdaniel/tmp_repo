---
name: finite-cluster-adsorption-energy
description: "Produces a finite-cluster adsorption energy from substrate and adsorbate single-point DFT energies. Requires the approved dft_single_point_energy catalog capability and a fully specified fixed-geometry cluster. Boundary: never re-implements a quantum-chemistry solver, never relaxes geometry, and never fabricates a result on failure."
estimated_complexity: high
---

# Finite-Cluster Adsorption Energy Skill

## Responsibility and boundary

This Skill defines and supports the computation of adsorption energy for a
finite-cluster model of a substrate plus an adsorbate. It is a high-level
physical-property Skill: it does **not** implement any quantum-chemistry solver.
All per-system total energies are obtained by calling the approved catalog DFT
capability `dft_single_point_energy` (exact route name and package hash below).
This Skill combines those energies, enforces cross-system consistency, defines
inputs and formal outputs, states applicability boundaries, and fails explicitly
rather than fabricating results.

This Skill does not relax geometries, does not apply counterpoise corrections,
and does not establish general material ordering. It reports one adsorption
energy for one supplied fixed-geometry cluster.

## Entry conditions and authority

- The active node must name one bounded missing capability (finite-cluster
  adsorption energy) and its expected consumer (the Materializer handoff).
- The approved catalog capability `dft_single_point_energy` must be available
  with the exact route name and package hash below.
- Exact visible artifacts and user-provided source paths may inform the package.
- Existing approved Route dependencies use exact name and package hash.

## Trigger examples

### Should select

- A task requests a reusable high-level finite-cluster adsorption energy
  computation from substrate and adsorbate single-point DFT energies, and the
  approved `dft_single_point_energy` capability is available.
- A bounded research responsibility with a formal reusable result (adsorption
  energy from combined/substrate/adsorbate single-point energies) is required,
  and no approved Skill owns that responsibility.

### Should not select

- Improve the wording of an existing production Skill from execution history;
  that belongs to skill-optimization.
- Wrap one supplied Python function behind a JSON callable interface; that
  belongs to route-onboarding.

## Prompt and memory projection

- **C0:** sanitized task, exact authorization, evaluation boundary, and
  constitution.
- **C1:** one current capability-creation node and its explicit dependencies.
- **C2:** exact public requirement or design artifacts used by the candidate.
- **C3:** bounded authoring summary only; it is not candidate authority.
- **C4:** exact package bytes live in the pending registry behind `package_ref`.
- **C5:** one draft and local format repair exist only during this invocation.
- **C6:** raw prompts, model turns, registry receipts, and failures remain
  audit-only.

## Approved Route dependency

This Skill consumes exactly one approved catalog capability for all per-system
DFT total energies:

- route_name: `dft_single_point_energy`
- package_hash: `cc0727f3d5bc42df05c3f1a40ce2be0f96017cbaec501fa4e5d56e112bc3c19d`

No quantum-chemistry solver is re-implemented here, and no other hash is guessed.

## Physical definition

### Reference states and combination formula

For a finite-cluster model, the adsorption energy is defined as

```text
E_ads = E(combined) - E(substrate) - E(adsorbate)
```

where:

- `E(combined)` is the total energy of the combined system (substrate cluster
  plus adsorbate in its adsorbed geometry);
- `E(substrate)` is the total energy of the isolated substrate cluster in the
  same geometry it has within the combined system;
- `E(adsorbate)` is the total energy of the isolated adsorbate in the same
  geometry it has within the combined system.

### Sign convention

A **negative** `E_ads` corresponds to an exothermic (energetically favorable)
adsorption. A **positive** `E_ads` corresponds to an endothermic (unfavorable)
adsorption. The sign is reported exactly as computed by the formula above; no
sign flip is applied.

### Energy units

All per-system total energies are returned by the DFT capability in **Hartree**
(`total_energy_hartree`). The Skill computes `E_ads` in Hartree and reports it as
`adsorption_energy_hartree`. An optional human-readable conversion to
**kJ/mol** is provided as `adsorption_energy_kj_per_mol` using the exact factor
`1 Hartree = 2625.4996394799 kJ/mol`; the Hartree value is authoritative.

## Cross-system consistency (mandatory)

The three systems (combined, substrate, adsorbate) must be computed under
physically comparable conditions. The Skill requires that all three single-point
calculations use **identical** values for:

- `method` (DFT functional, used verbatim);
- `basis` (basis set, used verbatim);
- geometry handling level (all three use the same fixed geometry snapshot; see
  Geometry relaxation below);
- `charge` (total charge of each system, set consistently with the physical
  partitioning);
- `spin_multiplicity` (set consistently with the physical partitioning).

If any of these settings differ across the three systems, the Skill **fails
explicitly** and does not produce an adsorption energy.

## Inputs

The Skill accepts a single structured request containing:

- `combined`: `elements` (list of atomic symbols), `coordinates` (Cartesian in
  Angstrom), `charge` (integer), `spin_multiplicity` (integer);
- `substrate`: `elements`, `coordinates`, `charge`, `spin_multiplicity`;
- `adsorbate`: `elements`, `coordinates`, `charge`, `spin_multiplicity`;
- `method` (DFT functional name, used verbatim);
- `basis` (basis set name, used verbatim);
- `geometry_level` (must be `fixed` for this Skill; see Geometry relaxation);
- optional `report_units` (default `hartree`; may be `kj_per_mol` to also emit
  the converted value).

All three systems must be fully specified. Missing or empty fields are a failure.

## Skill-local workflow

```text
author one bounded Skill package
-> run the project Skill structural validator over the complete draft tree
-> if invalid, repair the complete draft once and run the same validator again
-> seal exact valid files and manifest in pending registry
-> publish capability_candidate
-> read back exact candidate ref
```

The workflow does not execute candidate Python and never writes `active.json`.

## Formal output and handoff

On success the Skill emits a single structured result:

- `adsorption_energy_hartree` (float, authoritative);
- `adsorption_energy_kj_per_mol` (float, converted, present when requested);
- `sign_convention` (string, `"negative = exothermic"`);
- `formula` (string, `"E_ads = E(combined) - E(substrate) - E(adsorbate)"`);
- `units` (string, `"hartree"`);
- `per_system_energies` (object with `combined`, `substrate`, `adsorbate`, each
  holding `total_energy_hartree`, `scf_converged`, `method_used`, `basis_used`);
- `consistency` (object confirming identical `method`, `basis`, `geometry_level`,
  `charge`, `spin_multiplicity` across the three systems);
- `provenance` (route name and package hash of the DFT capability used).

The Skill emits an executable handoff for the Materializer containing exactly
three `dft_single_point_energy` calls (combined, substrate, adsorbate) with the
verbatim `method` and `basis`, the per-system `elements`, `coordinates`,
`charge`, and `spin_multiplicity`, and the combination formula. The Materializer
is the only consumer authorized to execute these calls. The Skill itself never
executes the DFT capability.

## Failure and repair

Missing authority or an unclear capability boundary fails to the parent. An
invalid manifest, path, dependency, or Skill structure receives at most one
same-stage complete-draft repair using the exact packaging or validator error.
If the second submission is still invalid, it fails to the parent and no invalid
pending package is sealed. The registry contract is never weakened.

The Skill **fails explicitly** and returns no adsorption energy when any of the
following holds:

- any of the three `dft_single_point_energy` calls reports `scf_converged = false`
  or otherwise fails;
- any input is incomplete (missing elements, coordinates, charge, spin
  multiplicity, method, basis, or geometry_level);
- the `method`, `basis`, `geometry_level`, `charge`, or `spin_multiplicity`
  settings are not identical across the three systems (incomparable settings);
- `geometry_level` is not `fixed`.

In every such case the Skill returns an explicit failure result with a reason and
**never** fills in a default value, substitutes a different method/basis, or
fabricates a physical result.

## Validation evidence

Validate the Skill contract against the approved `dft_single_point_energy`
catalog capability, the exact route name and package hash, the cross-system
consistency rules, the explicit failure behavior, and the H-on-H2 connectivity
case. Candidate creation alone does not prove that the new Skill works.

## Applicability boundaries

- **Finite-cluster approximation:** results are valid only for the specific
  finite cluster supplied; they are not periodic-surface values and must not be
  extrapolated to an infinite surface.
- **Basis-set superposition error (BSSE):** the raw `E_ads` above does not
  include a counterpoise correction. BSSE is a known source of error for
  finite-cluster adsorption energies; the Skill reports the uncorrected value and
  flags that a counterpoise correction is out of scope.
- **Geometry relaxation:** this Skill accepts only a fixed geometry snapshot
  (`geometry_level = fixed`). It does not relax geometries. Geometry relaxation
  is out of scope; a relaxed adsorption energy requires a different capability.
- **Single-point only:** no vibrational, zero-point, or thermal corrections are
  included.
- **No ranking claims:** the Skill does not establish general material ordering;
  it reports one adsorption energy for one supplied cluster.

## H-on-H2 finite-cluster integration case (connectivity proof only)

A small H-on-H2 finite-cluster case is provided as a low-cost integration test.
It exercises the Skill contract, the approved DFT capability, and the downstream
Materializer handoff end to end. The case is a **connectivity proof only**: it
shows that the Skill contract, the existing DFT capability, and the downstream
handoff can be joined. It does **not** represent real surface adsorption accuracy
and must **not** be used to form any general material ranking.

### Case definition

- Substrate: H2 molecule (two hydrogen atoms) as the finite cluster.
- Adsorbate: a single hydrogen atom H.
- Combined: H3 (the H atom placed near the H2 cluster).
- All three systems use the same `method`, `basis`, fixed geometry snapshot,
  `charge`, and `spin_multiplicity`.
- `E_ads = E(H3) - E(H2) - E(H)` in Hartree.

### Usage

1. Supply the three systems (H3, H2, H) with their elements, coordinates,
   charge, spin multiplicity, and a shared `method`/`basis`.
2. The Skill emits the Materializer handoff with three `dft_single_point_energy`
   calls.
3. The Materializer executes the calls and returns the three total energies.
4. The Skill combines them per the formula and reports `adsorption_energy_hartree`.

### Non-claims

This case is **not** evidence of surface adsorption accuracy, does not represent
any real surface, and must not be used to rank materials. It only demonstrates
that the Skill contract, the approved DFT capability, and the downstream handoff
can be connected.
