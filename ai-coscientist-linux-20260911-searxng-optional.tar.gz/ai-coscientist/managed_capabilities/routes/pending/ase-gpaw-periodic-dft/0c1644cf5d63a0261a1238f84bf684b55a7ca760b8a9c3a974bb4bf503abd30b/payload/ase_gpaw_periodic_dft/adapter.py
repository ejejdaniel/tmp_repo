"""Adapters for the ASE + GPAW periodic DFT routes.

Each adapter entrypoint is called by the host as function(route_input) where
route_input is the single JSON object validated by that Route's input schema.
"""

from __future__ import annotations

from typing import Any, Dict

from ase_gpaw_periodic_dft.source import geometry_relaxation as _geometry_relaxation
from ase_gpaw_periodic_dft.source import single_point as _single_point


def single_point_energy(route_input: Dict[str, Any]) -> Dict[str, Any]:
    """Adapter for gpaw_periodic_single_point_energy."""
    return _single_point(route_input)


def geometry_relaxation(route_input: Dict[str, Any]) -> Dict[str, Any]:
    """Adapter for gpaw_periodic_geometry_relaxation."""
    return _geometry_relaxation(route_input)
