"""Shared source for ASE + GPAW periodic plane-wave DFT.

Both routes use real GPAW periodic plane-wave DFT. No EMT, force fields,
tables, constants, fake data, or finite-cluster PySCF are used. All scientific
parameters are explicit in the contract or fixed by the implementation.
"""

from __future__ import annotations

import os
from typing import Any, Dict

import numpy as np
from ase import Atoms
from gpaw import GPAW
from ase.optimize import BFGS, FIRE, LBFGS

# Fixed scientific choice: plane-wave mode is the only supported GPAW mode.
MODE = "pw"


class RouteInputError(ValueError):
    """Raised for invalid or unsupported route input."""


class RouteRuntimeError(RuntimeError):
    """Raised when required runtime data (e.g. PAW setups) is missing."""


class NonConvergenceError(RuntimeError):
    """Raised when SCF or geometry does not converge."""


def _validate_common(ri: Dict[str, Any]) -> None:
    elements = ri["elements"]
    positions = ri["positions"]
    cell = ri["cell"]
    pbc = ri["pbc"]

    if len(elements) != len(positions):
        raise RouteInputError("elements and positions must have the same length")
    if len(elements) == 0:
        raise RouteInputError("at least one atom is required")
    if len(cell) != 3 or any(len(row) != 3 for row in cell):
        raise RouteInputError("cell must be a 3x3 matrix")
    if len(pbc) != 3 or not all(pbc):
        raise RouteInputError("this periodic DFT route requires all three PBC axes to be true")
    if ri["cutoff"] <= 0:
        raise RouteInputError("cutoff must be positive")
    if len(ri["kpoints"]) != 3 or any(k <= 0 for k in ri["kpoints"]):
        raise RouteInputError("kpoints must be a 3-vector of positive integers")
    if ri.get("mode", MODE) != MODE:
        raise RouteInputError(f"only mode '{MODE}' is supported")

    occ = ri["occupations"]
    if occ["name"] in ("fermi-dirac", "methfessel-paxton"):
        if "width" not in occ or occ["width"] <= 0:
            raise RouteInputError(f"occupations '{occ['name']}' requires a positive width")
    if ri["spin"] not in ("none", "collinear"):
        raise RouteInputError("spin must be 'none' or 'collinear'")

    scf = ri["scf_convergence"]
    for key in ("energy", "density", "eigenstate"):
        if scf[key] <= 0:
            raise RouteInputError(f"scf_convergence.{key} must be positive")
    if scf["max_iterations"] <= 0:
        raise RouteInputError("scf_convergence.max_iterations must be positive")


def _build_atoms(ri: Dict[str, Any]) -> Atoms:
    _validate_common(ri)
    return Atoms(
        symbols=ri["elements"],
        positions=ri["positions"],
        cell=ri["cell"],
        pbc=ri["pbc"],
    )


def _occupations_kwargs(occ: Dict[str, Any]) -> Dict[str, Any]:
    name = occ["name"]
    if name in ("fermi-dirac", "methfessel-paxton"):
        return {"name": name, "width": occ["width"]}
    return {"name": name}


def _ensure_setup_path() -> None:
    """Point GPAW at the offline PAW setup data shipped with gpaw_data."""
    try:
        import gpaw_data
        setups_dir = os.path.join(os.path.dirname(gpaw_data.__file__), "setups")
        if os.path.isdir(setups_dir):
            from gpaw.setup_data import setup_paths
            if setups_dir not in setup_paths:
                setup_paths.append(setups_dir)
    except Exception:
        pass


def _build_calculator(ri: Dict[str, Any]) -> GPAW:
    _ensure_setup_path()
    kwargs: Dict[str, Any] = {
        "mode": {"name": MODE, "ecut": ri["cutoff"]},
        "xc": ri["xc"],
        "kpts": ri["kpoints"],
        "occupations": _occupations_kwargs(ri["occupations"]),
        "convergence": {
            "energy": ri["scf_convergence"]["energy"],
            "density": ri["scf_convergence"]["density"],
            "eigenstates": ri["scf_convergence"]["eigenstate"],
            "maximum iterations": ri["scf_convergence"]["max_iterations"],
        },
    }
    if ri["spin"] == "collinear":
        kwargs["spinpol"] = True
    if ri.get("gpts") is not None:
        kwargs["gpts"] = ri["gpts"]
    return GPAW(**kwargs)


def _paw_provenance(calc: GPAW) -> Dict[str, Any]:
    """Return PAW setup provenance from the GPAW calculator."""
    setup_path = None
    setup_version = None
    try:
        setup_path = os.environ.get("GPAW_SETUP_PATH")
    except Exception:
        setup_path = None
    try:
        setup_version = getattr(calc, "version", None)
    except Exception:
        setup_version = None
    if setup_path is None:
        try:
            from gpaw.setup import setup_paths
            setup_path = str(setup_paths[0])
        except Exception:
            setup_path = "unknown"
    if setup_version is None:
        setup_version = "unknown"
    return {
        "setup_path": setup_path,
        "setup_version": setup_version,
        "elements": list(dict.fromkeys(calc.atoms.get_chemical_symbols())),
    }


def _check_scf_converged(calc: GPAW) -> None:
    if not calc.scf.converged:
        raise NonConvergenceError("SCF did not converge within the requested max_iterations")


def single_point(ri: Dict[str, Any]) -> Dict[str, Any]:
    """Run a single-point GPAW periodic plane-wave DFT calculation."""
    atoms = _build_atoms(ri)
    calc = _build_calculator(ri)
    atoms.calc = calc
    try:
        energy = atoms.get_potential_energy()
    except Exception as exc:
        raise RouteRuntimeError(f"GPAW calculation failed: {exc}") from exc
    _check_scf_converged(calc)
    forces = atoms.get_forces()
    return {
        "total_energy_eV": float(energy),
        "forces_eV_per_angstrom": forces.tolist(),
        "scf_converged": bool(calc.scf.converged),
        "scf_iterations": int(calc.get_number_of_iterations()),
        "structure": {
            "elements": list(atoms.get_chemical_symbols()),
            "positions": atoms.get_positions().tolist(),
            "cell": atoms.get_cell().tolist(),
            "pbc": [bool(p) for p in atoms.get_pbc()],
        },
        "settings": {
            "xc": ri["xc"],
            "cutoff_eV": ri["cutoff"],
            "kpoints": ri["kpoints"],
            "occupations": ri["occupations"],
            "spin": ri["spin"],
            "scf_convergence": ri["scf_convergence"],
            "mode": MODE,
        },
        "paw_setup_provenance": _paw_provenance(calc),
    }


def geometry_relaxation(ri: Dict[str, Any]) -> Dict[str, Any]:
    """Run a GPAW periodic plane-wave DFT geometry relaxation."""
    atoms = _build_atoms(ri)
    calc = _build_calculator(ri)
    atoms.calc = calc

    optimizer_name = ri["optimizer"]
    fmax = ri["fmax"]
    max_steps = ri["max_steps"]
    if fmax <= 0:
        raise RouteInputError("fmax must be positive")
    if max_steps <= 0:
        raise RouteInputError("max_steps must be positive")

    optimizer_cls = {"BFGS": BFGS, "LBFGS": LBFGS, "FIRE": FIRE}[optimizer_name]
    opt = optimizer_cls(atoms)
    try:
        converged = opt.run(fmax=fmax, steps=max_steps)
    except Exception as exc:
        raise RouteRuntimeError(f"geometry relaxation failed: {exc}") from exc

    _check_scf_converged(calc)
    final_forces = atoms.get_forces()
    max_force = float(np.max(np.linalg.norm(final_forces, axis=1)))
    final_energy = float(atoms.get_potential_energy())

    return {
        "optimized_positions": atoms.get_positions().tolist(),
        "final_energy_eV": final_energy,
        "final_max_force_eV_per_angstrom": max_force,
        "geometry_converged": bool(converged),
        "scf_converged": bool(calc.scf.converged),
        "actual_steps": int(getattr(opt, "nsteps", 0)),
        "structure": {
            "elements": list(atoms.get_chemical_symbols()),
            "positions": atoms.get_positions().tolist(),
            "cell": atoms.get_cell().tolist(),
            "pbc": [bool(p) for p in atoms.get_pbc()],
        },
        "settings": {
            "xc": ri["xc"],
            "cutoff_eV": ri["cutoff"],
            "kpoints": ri["kpoints"],
            "occupations": ri["occupations"],
            "spin": ri["spin"],
            "scf_convergence": ri["scf_convergence"],
            "mode": MODE,
            "optimizer": optimizer_name,
            "fmax": fmax,
            "max_steps": max_steps,
        },
        "method_provenance": {
            "optimizer": optimizer_name,
            "force_method": "GPAW periodic plane-wave DFT",
            "paw_setup_path": _paw_provenance(calc)["setup_path"],
            "paw_setup_version": _paw_provenance(calc)["setup_version"],
        },
    }
