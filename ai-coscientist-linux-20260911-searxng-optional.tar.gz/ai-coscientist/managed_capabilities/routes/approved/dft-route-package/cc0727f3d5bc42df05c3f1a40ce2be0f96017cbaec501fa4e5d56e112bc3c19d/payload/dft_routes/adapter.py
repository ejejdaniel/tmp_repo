import math

from rdkit import Chem
from rdkit.Chem import AllChem

from pyscf import gto, dft
from pyscf.geomopt import optimize


def _build_mol(
    elements,
    coordinates_angstrom,
    charge,
    spin_multiplicity,
    basis,
):
    if len(elements) != len(coordinates_angstrom):
        raise ValueError("elements and coordinates must have equal length")
    if len(elements) == 0:
        raise ValueError("molecule must have at least one atom")
    for coord in coordinates_angstrom:
        if len(coord) != 3:
            raise ValueError("each coordinate must be [x, y, z]")
    mol = gto.M(
        atom=list(zip(elements, coordinates_angstrom)),
        charge=charge,
        spin=spin_multiplicity - 1,
        unit="Angstrom",
        basis=basis,
    )
    return mol


def _run_dft(mol, method, basis):
    mf = dft.RKS(mol) if mol.spin == 0 else dft.UKS(mol)
    mf.xc = method
    mf.verbose = 0
    energy = mf.kernel()
    if energy is None or not math.isfinite(float(energy)) or not mf.converged:
        raise RuntimeError(
            f"SCF did not converge for method={method!r} basis={basis!r}"
        )
    return mf, energy


def single_point_energy(route_input):
    elements = route_input["elements"]
    coordinates = route_input["coordinates"]
    charge = route_input["charge"]
    spin_multiplicity = route_input["spin_multiplicity"]
    method = route_input["method"]
    basis = route_input["basis"]

    mol = _build_mol(
        elements,
        coordinates,
        charge,
        spin_multiplicity,
        basis,
    )
    mf, energy = _run_dft(mol, method, basis)

    return {
        "total_energy_hartree": float(energy),
        "scf_converged": bool(mf.converged),
        "method_used": method,
        "basis_used": basis,
        "input_geometry": {
            "elements": list(elements),
            "coordinates_angstrom": [list(c) for c in coordinates],
            "charge": charge,
            "spin_multiplicity": spin_multiplicity,
        },
    }


def conformer_geometry_optimization(route_input):
    mol_smiles = route_input["mol"]
    charge = route_input["charge"]
    spin_multiplicity = route_input["spin_multiplicity"]
    num_conformers = route_input["num_conformers"]
    method = route_input["method"]
    basis = route_input["basis"]

    mol = Chem.MolFromSmiles(mol_smiles)
    if mol is None:
        raise ValueError(f"invalid SMILES: {mol_smiles!r}")
    mol = Chem.AddHs(mol)

    params = AllChem.ETKDGv3()
    params.randomSeed = 0xC0FFEE
    cids = AllChem.EmbedMultipleConfs(mol, numConfs=num_conformers, params=params)
    if len(cids) == 0:
        raise RuntimeError("conformer generation failed")

    energies = []
    for cid in cids:
        ff = AllChem.MMFFGetMoleculeForceField(
            mol, AllChem.MMFFGetMoleculeProperties(mol), confId=cid
        )
        if ff is None:
            raise RuntimeError("MMFF94 force field unavailable")
        ff.Minimize()
        energies.append(ff.CalcEnergy())

    best_idx = min(range(len(cids)), key=lambda i: energies[i])
    best_cid = cids[best_idx]
    best_energy = energies[best_idx]

    conf = mol.GetConformer(best_cid)
    coords = [list(conf.GetAtomPosition(i)) for i in range(mol.GetNumAtoms())]
    elements = [atom.GetSymbol() for atom in mol.GetAtoms()]

    dft_mol = _build_mol(
        elements,
        coords,
        charge,
        spin_multiplicity,
        basis,
    )
    initial_mf, _ = _run_dft(dft_mol, method, basis)

    # optimize() returns the optimized Mole. The original SCF object still
    # represents the pre-optimization geometry, so recompute the final SCF on
    # the returned Mole before publishing the final energy.
    optimized_mol = optimize(initial_mf)
    if optimized_mol is None:
        raise RuntimeError("DFT geometry optimization returned no molecule")
    _, final_energy = _run_dft(optimized_mol, method, basis)
    final_coords = optimized_mol.atom_coords(unit="Angstrom").tolist()
    dft_optimization_converged = True

    return {
        "selected_conformer": {
            "index": int(best_cid),
            "mmff_energy_kcal_mol": float(best_energy),
        },
        "optimized_coordinates_angstrom": final_coords,
        "final_energy_hartree": float(final_energy),
        "conformer_converged": True,
        "dft_optimization_converged": dft_optimization_converged,
        "method_provenance": {
            "method": method,
            "basis": basis,
            "conformer_generator": "RDKit ETKDGv3",
            "conformer_ranker": "MMFF94",
        },
    }
