﻿# Pure Python common-agent workflow

This worktree is a clean implementation. It must not import either reference
worktree as a runtime:

- `../opencode-dynamic-full-workflow` is the behavioral reference.
- `../final-kpi-route-evolver-rewrite` is an implementation reference only.

## Constitutional design authority

- `docs/common_memory_constitution_zh-TW.md` is the constitution-level source
  of truth for memory classes, storage authority, metabolism, prompt projection,
  skill-local memory, and large-content handling in this worktree.
- `docs/long_term_memory_governance_constitution_zh-TW.md` is the
  constitution-level source of truth for cross-project LLM Wiki governance,
  including the human-only `@wiki` write authority, read-only retrieval,
  provenance, child-agent visibility, and the boundary with project-local C0-C6.
- `docs/materializer_responsibility_constitution_zh-TW.md` is the
  constitution-level source of truth for the scientific producer / Materializer /
  reviewer / coordinator responsibility boundary. Materializer owns faithful
  computational operationalization, including disclosed scientific approximations;
  it must not be reduced to copying a fully specified upstream algorithm.
- Read and follow that document before changing common memory, prompt assembly,
  skill-local workflow state, compaction, artifact/workspace storage, or event
  logging.
- Read and follow the long-term-memory constitution before adding or changing
  cross-project knowledge storage, Wiki search/read/write behavior, Wiki skills,
  or any automatic knowledge-persistence mechanism.
- Existing code that conflicts with the constitution is an implementation gap;
  it is not permission to weaken or silently reinterpret the constitution.
- Read and follow the Materializer constitution before changing formula
  operationalization review, Materializer prompts or tools, implementation-gap
  handling, Materializer tests, or downstream review of materialized evidence.
- Any change to that responsibility boundary requires explicit user approval.
- Common C0-C6 lifecycle and metabolism implementation belongs only under
  `src/ai_coscientist/common/memory_lifecycle/`. Callers may select prompt
  inputs, but must not reimplement revision selection, compaction, prompt
  budgeting, C5 cleanup, or C6 replay elsewhere.
- If the constitution is insufficient, conflicting, or requires another memory
  class or lifecycle, stop and obtain explicit user approval before editing it
  or implementing the deviation.
- `docs/pending_security_label_design_zh-TW.md` records a valuable but explicitly
  pending design for security labels, child authorization, protected routes, and
  evaluator-private data. Read it before revisiting data-access control. It is
  not permission to implement C7, security fields, clearance checks, or a new
  persisted security contract without renewed explicit approval.

## Project skill authoring authority

- Use `.agents/skills/ai-coscientist-skill-creator/SKILL.md` before creating,
  materially redesigning, or accepting a third-party production skill or route.
- The project skill creator is developer-facing meta-skill infrastructure. It
  must never be added to the production `skills/` catalog, selected by the
  scientific coordinator, or treated as a scientific workflow stage.
- Passing its structural validator does not authorize a schema, artifact kind,
  common-runtime, memory-class, child-agent, or public-contract change. Those
  changes still require the approvals defined by this file and the memory

## Boundaries

- Runtime code is pure Python. This describes the implementation language, not
  a standard-library-only restriction: scientific execution may import any
  installed scientific computation package required by the task. Do not
  install, shell out to, wrap, or embed OpenCode, Node.js, or TypeScript.
- The common agent replaces only the OpenCode coordinator/runtime role.
- Project-local `SKILL.md` files own domain instructions, local workflows, and
  domain output requirements.
- Common code owns the LOOP, progressive skill disclosure, prompt and memory
  lifecycle, exact artifact references, provenance, tool routing, and closure
  bookkeeping. It must not infer scientific meaning.
- Common code owns initial-plan creation and progress-based plan maintenance through a private bounded `write_plan` call that is never available as a production action. A
  runner may supply the objective, evaluator description, and source files, but
  must not author or inject the plan.
- Objective, evaluation anchor, and current plan remain persistent prompt anchors.
  Recent completed tool interactions remain visible in native chat/tool roles.
  Ordinary main-loop response content is saved as unverified C3 work notes;
  hidden reasoning and private judge/repair responses remain audit-only.
  Work notes and exact operation receipts survive skill release and attempt expiry.
  The approved precise v16 changes are defined in
  `docs/memory_governance_long_running_work_schema_plan_zh-TW.md`.
- A skill may contain a fixed local workflow, but neither a skill output nor a
  runner may prescribe the next production skill.
- Child delegation and local execution are alternatives at the Graph-node
  boundary. A child receives the whole active node as its mission and builds
  its own Graph and LOOP. Never use a child to execute one skill or one
  node-local LOOP step.
- Stored formal artifacts are the cross-skill semantic authority. Receipts,
  raw logs, summaries, and conversation text are not substitutes.
- Keep output storage classes mutually exclusive. Raw execution records may be
  retained for diagnostics but are not semantic workflow inputs.
- Do not add or expand public artifact schemas without explicit approval.
- Diagnose the earliest incorrect boundary before rerunning an expensive real
  model test.


## Replanning

At a skill-selection boundary, the model may choose the argument-free `replan`
control action after a fresh artifact list when current evidence shows that the
existing route cannot reach evaluation. Initial planning and replanning share the
same private workflow; ordinary artifact progress may update statuses only.

