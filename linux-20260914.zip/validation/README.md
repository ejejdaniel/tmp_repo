# Linux 交付包檢查

日期：2026-09-14。

- Git commit：`7f6a9f6988ab78db17ba55ec46b881c331ec5f44`。
- 壓縮包：`ai-coscientist-linux-20260914-7f6a9f6.tar.gz`，998,801 bytes。
- SHA-256：`7754ab20954dfc3c5e474e806aff3a2243da0662c7a815deb2b7e73d0aa9f39d`。
- 本次包含的正式檔案均受 Git 追蹤；沒有未提交的正式程式或技能。
- 包含 Dockerfile、既有已核准與待核准能力；不含任務成果、對話、快取、Python 環境、Docker 映像或 Windows 執行檔。

以既有 Linux/amd64 科研映像執行一次性容器，未掛 Docker socket，未修改原映像：

1. 解壓後核對 343 項 SHA256SUMS，全數相符。
2. Python compileall 與兩個 shell 入口的 bash 語法檢查通過。
3. 依 pyproject.toml 安裝專案依賴，正式 CLI parser 可載入。
4. 14 份受管理能力的 manifest 與 payload 雜湊通過原驗證器。
5. 由正式 Linux chat 腳本啟動空白工作階段，執行 `/status`、`/exit`，沒有建立 C0、Global Evaluation、Graph 或正式任務狀態，也沒有發出 LLM 請求。

容器已正常結束並移除。檢查輸出保存於本目錄，不屬於壓縮包內容。

此為部署與空白啟動檢查，不是科研端到端驗證。本次容器未驗 Docker 計算及 PDF 渲染，目的 Linux 主機的模型連線、私有資料中心與計算權限也尚未驗證。已知 Materializer 特定探查引用格式測試失敗已記於包內 `docs/linux_deployment_zh-TW.md`，不宣稱全套測試通過。
