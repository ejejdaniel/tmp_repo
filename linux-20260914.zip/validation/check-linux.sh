#!/usr/bin/env bash
set -Eeuo pipefail
mkdir -p /tmp/release
tar -xzf /release.tar.gz -C /tmp/release
cd /tmp/release/ai-coscientist
sha256sum -c SHA256SUMS > /validation/file-hashes.log
python -m compileall -q src skills .agents/skills scripts
bash -n scripts/run_scientific_chat_linux.sh scripts/run_scientific_workflow_linux.sh
python -m pip install --disable-pip-version-check -e . > /validation/python-install.log 2>&1
python scripts/check_linux_deployment.py --skip-docker --skip-pdf | tee /validation/deployment-check.log
PYTHON_BIN=python bash scripts/run_scientific_chat_linux.sh --help > /validation/cli-help.txt
printf '/status\n/exit\n' | PYTHON_BIN=python bash scripts/run_scientific_chat_linux.sh --output /tmp/clean-chat --source-root /tmp/release/ai-coscientist --capability-docker-base-image-reference sha256:71b5dd7483fb8aa1bc9c027fb117fa2e5cb36f78537beb9f2d47fa3f91b04752 | tee /validation/cli-session.txt
test ! -e /tmp/clean-chat/agent-state.json
test ! -s /tmp/clean-chat/llm-reasoning-debug.jsonl
printf 'Linux/amd64 release hashes, compilation, dependencies and clean CLI passed. No model request. Docker execution and PDF not tested in this container.\n' | tee /validation/result.txt
